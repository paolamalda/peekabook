# Tu Turno, Tu Dinero, Tu Futuro: contenido completo

Versión 1.3 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Módulo 1. Tu quincena rinde

## M1 U01. ¿Cuánto entra de verdad?

**Lo que lograrás:** Saber cuánto dinero te llega de verdad cada quincena, después de descuentos, y compararlo con el salario mínimo 2026.

**Para empezar:** Don Chuy dice que gana «como 10 mil», pero a su cuenta le llegan 4,100 cada quincena. Nunca ha revisado por qué. En esta lección sabrás cuánto entra de verdad a tu bolsillo.

### Lo esencial (5 minutos)

#### Lo que ganas y lo que te llega

Tu salario no es lo que llega a tu cuenta. Antes pueden restarse descuentos: préstamos, adelantos, uniformes, faltas o impuestos. Lo que importa para tu presupuesto es lo que **te llega**.



#### La quincena de Don Chuy

Don Chuy revisa su recibo.
- Salario de la quincena: **4,790**
- Adelanto que pidió: **690**
- Lo que le llega: **4,100**
Para su presupuesto usa 4,100, no 4,790.


#### El salario mínimo 2026

El salario mínimo general es de 315.04 pesos diarios, unos 9,582 al mes. En la frontera norte es de 440.87 diarios.

Si en el mes solo ganas el salario mínimo, no te deben descontar ISR. Si ganas más, puede haber descuento de ISR.

> **Dato vigente:** salario mínimo general 2026 de 315.04 pesos diarios (9,582.47 al mes) y de 440.87 diarios en la Zona Libre de la Frontera Norte. Con el salario mínimo no se retiene ISR (Ley del ISR, artículo 96). Consultado el 29 de septiembre de 2026 a través de la CONASAMI y la Ley del ISR.



#### Un caso en un minuto

Don Chuy pidió su recibo y vio el adelanto que se descuenta cada quincena. Ahora hace sus cuentas con lo que de verdad le llega.

> **Idea clave:** haz tus cuentas con lo que te llega, no con lo que dices que ganas.



#### Comprueba lo que entendiste

1. ¿Con qué cifra haces tu presupuesto?
*Respuesta:* Con lo que te llega después de descuentos.

2. ¿Dónde ves tus descuentos?
*Respuesta:* En tu recibo de pago.


#### Para recordar

- Lo que ganas no es lo que te llega.
- Revisa tu recibo.
- Presupuesto con lo que llega.



### Profundiza (5 minutos más)

#### Descuentos comunes

| Descuento | Qué es |
|---|---|
| Adelanto de nómina | Dinero que pediste antes y se descuenta |
| Préstamo de la empresa | Se descuenta en partes |
| Uniforme o equipo | Si tu contrato lo indica |
| Faltas | Días no trabajados |
| ISR | Solo si ganas más del salario mínimo |



#### Pide tu recibo

Tienes derecho a saber cuánto te pagan y por qué te descuentan. Pide tu recibo cada quincena y guárdalo en una foto en tu celular.



#### Casos


**Caso 1. La quincena de Don Chuy**

Don Chuy hace sus cuentas con «10 mil», pero le llegan 4,100 por quincena.
- *¿Qué hace?* Hace su presupuesto con lo que le llega de verdad.


**Caso 2. El descuento de Karla**

A Karla le descontaron algo que no entiende.
- *¿Qué hace?* Pide su recibo y pregunta qué es el descuento.


**Caso 3. El adelanto de Beto**

Beto pide un adelanto cada quincena y siempre le falta.
- *¿Qué hace?* Suma cuánto le descuentan y hace un plan para dejar de pedirlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar con lo que ganas | Te falta | Usa lo que llega |
| No ver el recibo | No sabes qué te descuentan | Pídelo |
| Adelantos cada quincena | Nunca alcanza | Planea salir |
| No guardar recibos | Sin pruebas | Foto en tu celular |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Con qué cifra haces tu presupuesto? a) Con tu salario antes de descuentos, porque es lo que ganas · b) Con lo que te llega · c) Con lo que ganan tus compañeros
2. Tu salario de quincena es 4,800 y te descuentan 600. ¿Cuánto te llega? a) 5,400 · b) 4,800 · c) 4,200
3. ¿Dónde revisas tus descuentos? a) En tu recibo de pago · b) Preguntando a un compañero del turno · c) En tu celular
**Respuestas:** 1-b: es el dinero real. 2-c: 4,800 menos 600. 3-a: ahí aparecen.



#### Ponlo en práctica

Tu salario de quincena es 4,790; te descuentan 300 de uniforme y 500 de un préstamo. ¿Cuánto te llega?
**Respuesta:** 4,790 menos 800: 3,990.



#### A tu plan

Revisa tu último recibo y anota cuánto te llega de verdad cada quincena.



### Para saber más

- **Salarios mínimos** (CONASAMI · español): https://www.gob.mx/conasami — **Qué buscar:** salarios mínimos 2026.

### Palabras clave

- *Salario:* lo que te pagan por tu trabajo antes de descuentos.
- *Recibo de pago:* documento que muestra lo que ganas, lo que te descuentan y lo que te llega.

### Fuentes

CONASAMI, consultado el 29 de septiembre de 2026.

---

## M1 U02. Tu presupuesto de turno

**Lo que lograrás:** Hacer un presupuesto que funcione con turnos de 24 por 24: cuánto gastas en cada turno y cuánto en la casa.

**Para empezar:** Karla trabaja unos 15 turnos al mes. En cada turno gasta en comida y transporte, y en la casa tiene renta, luz y lo de su hija. A mitad de quincena siempre se queda sin dinero. En esta lección harás su presupuesto de turno.

### Lo esencial (5 minutos)

#### Tus turnos al mes

Con turnos de 24 por 24 trabajas unos **15 turnos al mes**. Cada turno tiene sus gastos: pasajes, comida, café, recargas. Multiplica lo que gastas por turno por 15.



#### El gasto del turno de Karla

- Pasajes y comida por turno: **120**
- Turnos al mes: **15**
- Gasto de turnos al mes: **1,800**
Karla lo suma a los gastos de su casa para saber cuánto necesita.


#### Tu presupuesto en tres partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Turno | Pasajes, comida, recargas. | Por 15 al mes. |
| Casa | Renta, luz, gas, comida, escuela. | Lo fijo primero. |
| Ahorro | Aunque sea poco. | Lo apartas primero. |

#### Un caso en un minuto

Karla anotó su gasto de turnos y de la casa. Descubrió que le faltaban 400 al mes. Empezó a llevar comida de casa algunos turnos y ya le alcanza.

> **Idea clave:** calcula tus gastos de turno por 15 y súmalos a los de tu casa.



#### Comprueba lo que entendiste

1. ¿Cuántos turnos haces al mes con 24 por 24?
*Respuesta:* Unos 15.

2. ¿Por qué multiplicar el gasto del turno?
*Respuesta:* Porque un gasto chico se repite 15 veces al mes.


#### Para recordar

- Unos 15 turnos al mes.
- Turno, casa y ahorro.
- Lo fijo primero.



### Profundiza (5 minutos más)

#### Tu presupuesto

| Concepto | Al mes |
|---|---|
| Lo que te llega | |
| Gastos del turno (por 15) | |
| Renta, luz, gas | |
| Comida de la casa | |
| Escuela y otros | |
| Pagos de deudas | |
| Ahorro | |



#### Si no alcanza

Empieza por los gastos del turno: llevar comida y agua de casa puede ahorrar mucho. Después revisa tus deudas (módulo 3). Evita pedir adelantos para cubrir la diferencia.



#### Casos


**Caso 1. La quincena de Karla**

A Karla se le acaba el dinero a mitad de quincena.
- *¿Qué hace?* Calcula su gasto de turnos por 15 y lo suma a los gastos de la casa.


**Caso 2. La comida de Don Chuy**

Don Chuy gasta 90 en comida en cada turno.
- *¿Qué hace?* Calcula que son 1,350 al mes y lleva comida de casa algunos turnos.


**Caso 3. La falta de Beto**

A Beto le faltan 500 al mes y pide un adelanto.
- *¿Qué hace?* Ajusta sus gastos del turno en lugar de pedir adelantos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No contar el gasto del turno | Te falta dinero | Por 15 |
| Cubrir con adelantos | Deuda cada quincena | Ajusta gastos |
| Dejar el ahorro al final | No ahorras | Apártalo primero |
| Presupuesto de memoria | No es real | Escríbelo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Don Chuy y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastas 100 por turno y haces 15 turnos. ¿Cuánto al mes? a) 1,500 · b) 100 · c) 3,000
2. Te falta dinero cada mes. ¿Qué haces primero? a) Pides un adelanto cada quincena · b) Ajustas tus gastos del turno · c) Dejas de pagar la luz un mes
3. ¿Qué apartas primero? a) El dinero para salir el fin de semana · b) Lo que sobre al final · c) El ahorro, aunque sea poco
**Respuestas:** 1-a: 100 por 15. 2-b: son los más fáciles de ajustar. 3-c: si lo dejas al final, no ahorras.



#### Ponlo en práctica

Gastas 140 por turno y trabajas 15 turnos. Los gastos de tu casa son 6,500. ¿Cuánto necesitas al mes?
**Respuesta:** 140 por 15 son 2,100; más 6,500: 8,600.



#### A tu plan

Llena tu presupuesto con tus gastos de turno por 15 y los de tu casa.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto personal».

### Palabras clave

- *Presupuesto:* plan de cuánto entra y en qué se usa.
- *Gasto fijo:* gasto que se repite igual, como la renta.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U03. Los gastos del turno que no ves

**Lo que lograrás:** Detectar los gastos pequeños del turno (refrescos, antojos, recargas, apuestas) y cuánto suman al mes.

**Para empezar:** Beto compra un refresco, unas papas y un café en cada turno. «Son 60 pesos, nada». Al mes, con 15 turnos, son 900. En esta lección verás tus gastos pequeños.

### Lo esencial (5 minutos)

#### Pequeños, pero muchos

Un gasto hormiga parece poco, pero se repite en cada turno. Lo importante no es prohibirte todo, sino saber cuánto suma y decidir.



#### Los antojos de Beto

- Refresco, papas y café por turno: **60**
- Turnos al mes: **15**
- Al mes: **900**
Al año son 10,800 pesos.


#### Gastos hormiga comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Antojos y refrescos | En cada turno. | Lleva agua y comida. |
| Recargas y apps | Datos, juegos, suscripciones. | Plan fijo. |
| Apuestas | Casinos en línea, rifas. | Suelen perder. |
| Taxis | Por prisa. | Planea el traslado. |

#### Un caso en un minuto

Beto dejó el refresco y lleva agua. Solo compra café. Ahorra unos 600 al mes y los aparta para su fondo.

> **Idea clave:** multiplica tus gastos pequeños por 15 turnos y decide cuáles valen la pena.



#### Comprueba lo que entendiste

1. ¿Qué es un gasto hormiga?
*Respuesta:* Un gasto pequeño que se repite y al mes suma mucho.

2. ¿Hay que prohibirse todo?
*Respuesta:* No; se trata de saber cuánto suma y decidir.


#### Para recordar

- Pequeño por turno, grande al mes.
- Por 15 turnos.
- Tú decides cuáles valen la pena.



### Profundiza (5 minutos más)

#### Tus gastos hormiga

| Gasto | Por turno | Al mes (por 15) |
|---|---|---|
| Refrescos y antojos | | |
| Café | | |
| Recargas | | |
| Otros | | |



#### Apuestas en línea

Las apps de apuestas y casinos en línea están diseñadas para que sigas jugando. Si juegas, pon un límite pequeño y nunca pidas prestado para apostar. Si sientes que no puedes parar, busca ayuda.



#### Casos


**Caso 1. Los antojos de Beto**

Beto gasta 60 por turno en antojos y dice que no es nada.
- *¿Qué hace?* Calcula que son 900 al mes y decide cuáles deja.


**Caso 2. Las recargas de Karla**

Karla recarga 50 cada tercer día.
- *¿Qué hace?* Compara con un plan fijo mensual más barato.


**Caso 3. La apuesta de Ramiro**

Ramiro apuesta en una app para «recuperar» lo que perdió.
- *¿Qué hace?* Deja de apostar para recuperar y pone un límite o busca ayuda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar «es poquito» | Al mes es mucho | Por 15 |
| Prohibirte todo | No lo sostienes | Elige |
| Apostar para recuperar | Pierdes más | Detente |
| Pedir prestado para gustos | Deuda | Solo con lo que tienes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Karla y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastas 40 en refresco por turno, 15 turnos. ¿Cuánto al mes? a) 400 · b) 600 · c) 40
2. Perdiste en una app de apuestas. ¿Qué haces? a) Apuestas más para recuperar lo perdido pronto · b) Pides prestado para seguir · c) Dejas de apostar para recuperar
3. ¿Qué haces con tus gastos hormiga? a) Los calculas y decides cuáles dejar · b) Te prohíbes todo desde hoy · c) Nada, son poquitos
**Respuestas:** 1-b: 40 por 15. 2-c: perseguir pérdidas empeora. 3-a: sabes y decides.



#### Ponlo en práctica

Gastas 35 en café y 25 en papas por turno. ¿Cuánto al mes y al año?
**Respuesta:** 60 por 15: 900 al mes; por 12: 10,800 al año.



#### A tu plan

Anota tus gastos hormiga de tres turnos y multiplícalos por 15.



### Para saber más

- **Gastos hormiga** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «gastos hormiga».

### Palabras clave

- *Gasto hormiga:* gasto pequeño que se repite y al mes suma mucho.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U04. Aparta primero

**Lo que lograrás:** Apartar tu ahorro el mismo día de pago, aunque sea poco, antes de gastar.

**Para empezar:** Karla siempre dice «ahorro lo que sobre», pero nunca sobra. Su compañera le dijo: «aparta primero, aunque sean 100». En esta lección verás por qué funciona.

### Lo esencial (5 minutos)

#### Primero tú

Si esperas a que sobre, casi nunca sobra. Aparta tu ahorro el **mismo día de pago**, antes de gastar. Aunque sean 100 pesos por quincena.



#### Formas de apartar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta aparte | Una cuenta solo para ahorro. | No la cargas en la tarjeta. |
| Automático | Transferencia programada el día de pago. | Sin pensarlo. |
| Sobre | Si cobras en efectivo, un sobre cerrado. | Guárdalo seguro. |
| Meta | Para qué ahorras. | Te motiva. |

#### 100 por quincena

- Por quincena: **100**
- Quincenas al año: **24**
- Al año: **2,400**
Con 200 por quincena, serían 4,800.


#### Un caso en un minuto

Karla programó en su app una transferencia de 150 a una cuenta aparte cada día de pago. En seis meses juntó 1,800 sin darse cuenta.

> **Idea clave:** aparta el día de pago, aunque sea poco; lo que esperas a que sobre, no sobra.



#### Comprueba lo que entendiste

1. ¿Cuándo apartas tu ahorro?
*Respuesta:* El mismo día de pago, antes de gastar.

2. ¿Cuánto son 100 por quincena en un año?
*Respuesta:* 2,400.


#### Para recordar

- Aparta primero.
- Aunque sea poco.
- Automático si puedes.



### Profundiza (5 minutos más)

#### Una meta

Ponle nombre a tu ahorro: «fondo para emergencias», «útiles de mi hija». Una meta clara te ayuda a no tocarlo.



#### Cuánto juntas

| Por quincena | En 6 meses | En un año |
|---|---|---|
| 100 | 1,200 | 2,400 |
| 200 | 2,400 | 4,800 |
| 300 | 3,600 | 7,200 |



#### Casos


**Caso 1. El «lo que sobre» de Karla**

Karla ahorra «lo que sobre» y nunca sobra.
- *¿Qué hace?* Aparta 150 el mismo día de pago antes de gastar.


**Caso 2. El efectivo de Don Chuy**

A Don Chuy le pagan una parte en efectivo.
- *¿Qué hace?* Separa en un sobre cerrado su ahorro el día que cobra.


**Caso 3. La cuenta de Beto**

Beto ahorra en la misma cuenta que usa con su tarjeta y se lo gasta.
- *¿Qué hace?* Abre una cuenta aparte solo para ahorrar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar a que sobre | No sobra | Aparta primero |
| Ahorro en la misma cuenta | Te lo gastas | Cuenta aparte |
| Sin meta | Lo tocas | Ponle nombre |
| Creer que poco no sirve | No empiezas | 100 cuentan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Don Chuy y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo apartas tu ahorro? a) El día de pago · b) Al final del mes, con lo que sobre · c) Cuando haya una emergencia
2. Ahorras 200 por quincena. ¿Cuánto juntas en un año? a) 2,400 · b) 4,800 · c) 200
3. Te gastas el ahorro porque está en tu cuenta de siempre. ¿Qué haces? a) Dejas de ahorrar · b) Lo guardas debajo del colchón para no verlo · c) Abres una cuenta aparte para ahorro
**Respuestas:** 1-a: antes de gastar. 2-b: 200 por 24. 3-c: separarlo ayuda.



#### Ponlo en práctica

Quieres juntar 3,000 en un año. ¿Cuánto apartas por quincena?
**Respuesta:** 3,000 entre 24: 125 por quincena.



#### A tu plan

Decide cuánto apartarás cada quincena y prográmalo para tu próximo día de pago.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ahorro» y consejos.

### Palabras clave

- *Ahorro:* dinero que apartas para usarlo después.
- *Transferencia programada:* envío automático de dinero en una fecha fija.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U05. Dinero y estrés: cómo hablarlo en casa

**Lo que lograrás:** Reconocer cuándo el dinero te está causando estrés, hablarlo en casa sin pleitos y saber dónde pedir apoyo.

**Para empezar:** Don Chuy llega cansado del turno de 24 horas y su esposa le pregunta por el pago de la tienda. Terminan discutiendo. Él no duerme pensando en las deudas. En esta lección verás cómo hablar de dinero sin pelear.

### Lo esencial (5 minutos)

#### Señales de estrés por dinero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| No duermes | Piensas en deudas en el descanso. | Tu cuerpo lo resiente. |
| Discusiones | Cada plática de dinero termina en pleito. | Nadie decide. |
| Evitas ver | No abres mensajes del banco. | La deuda crece. |
| Hablarlo con calma | Un momento fijo, con números. | Baja la tensión. |

#### La plática de dinero de 20 minutos

1. Elijan un día fijo, lejos del turno y del cansancio.
2. Pongan los números sobre la mesa: lo que entra, lo que sale y lo que se debe.
3. Cada quien dice una preocupación, sin culpar.
4. Acuerden una sola acción para la semana.



#### Un caso en un minuto

Don Chuy y su esposa acordaron hablar de dinero cada domingo de descanso, 20 minutos, con su presupuesto en la mano. La primera semana decidieron pagar primero la tienda en abonos. Las discusiones bajaron.

> **Idea clave:** el dinero se habla con números y en un momento fijo, no a la salida del turno ni en medio de un pleito.



#### Comprueba lo que entendiste

1. ¿Cuándo conviene hablar de dinero en casa?
*Respuesta:* En un momento fijo y con calma, no al llegar cansado del turno.

2. ¿Con qué se termina la plática?
*Respuesta:* Con una sola acción acordada para la semana.


#### Para recordar

- Día fijo, 20 minutos.
- Números sobre la mesa.
- Una acción por semana.



### Profundiza (5 minutos más)

#### Si el estrés no baja

Si llevas semanas sin dormir, sientes que no hay salida o piensas en hacerte daño, busca ayuda de inmediato. La Línea de la Vida (800 911 2000) atiende sin costo las 24 horas. Pedir ayuda es parte de cuidar a tu familia.



#### Hablar con los hijos

Los hijos notan el estrés. Explícales, según su edad, que la familia tiene un plan y que todos ayudan: apagar luces, cuidar útiles, no pedir antojos cada día.



#### Casos


**Caso 1. La discusión de Don Chuy**

Don Chuy y su esposa discuten de dinero al salir él del turno.
- *¿Qué hacen?* Eligen un día fijo de descanso para hablarlo con números.


**Caso 2. Los mensajes de Beto**

Beto no abre los mensajes de su app de préstamos porque le da miedo.
- *¿Qué hace?* Los revisa, anota cuánto debe y busca ayuda (M3 y M6).


**Caso 3. La niña de Karla**

La hija de Karla le pide algo en cada salida y Karla se siente culpable al decir que no.
- *¿Qué hace?* Le explica que tienen un plan y acuerdan un gusto a la semana.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Hablar cansado | Pleito seguro | Día fijo |
| Evitar los números | La deuda crece | Números sobre la mesa |
| Culpar | Nadie decide | Una preocupación cada quien |
| Callar el estrés | Te enfermas | Pide ayuda |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Beto y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo conviene hablar de dinero en pareja? a) Al llegar del turno de 24 horas · b) En un día fijo y con calma · c) Solo cuando llega un cobro
2. ¿Con qué termina una buena plática de dinero? a) Con una acción acordada para la semana · b) Con quién tiene la culpa · c) Con la promesa de no volver a hablar del tema
3. Llevas semanas sin dormir por las deudas y sientes que no hay salida. ¿Qué haces? a) Aguantas solo · b) Pides otro préstamo para calmarte · c) Buscas ayuda, por ejemplo en la Línea de la Vida
**Respuestas:** 1-b: sin cansancio ni pleito. 2-a: avanzar poco a poco. 3-c: pedir ayuda es cuidarte.



#### Ponlo en práctica

Si hablan de dinero 20 minutos cada domingo, ¿cuántas horas le dedican al mes?
**Respuesta:** Unas 4 pláticas: 80 minutos, poco más de una hora.



#### A tu plan

Acuerda con tu familia un día fijo para su plática de dinero y anoten la primera acción.



### Para saber más

- **Línea de la Vida** (Secretaría de Salud · español): 800 911 2000 | Atención sin costo las 24 horas.
- **Finanzas personales** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto familiar».

### Palabras clave

- *Estrés financiero:* preocupación constante por el dinero que afecta tu sueño, tu salud o tus relaciones.

### Fuentes

Secretaría de Salud · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M1 U06. Compra inteligente: precio por unidad, publicidad y pagos chiquitos

**Lo que lograrás:** Comparar el precio por unidad, reconocer la presión de la publicidad y calcular cuánto cuestan de verdad las suscripciones y los pagos en abonos antes de comprar.

**Para empezar:** Beto vio en redes unos audífonos «a solo 99 a la semana». Los pidió en abonos y además paga tres plataformas de video que casi no usa. Al final del mes no sabe por qué no le alcanza. En esta lección aprenderás a ver el precio completo.

### Lo esencial (5 minutos)

#### Precio por unidad

El paquete grande no siempre sale más barato. Divide el precio entre la cantidad (kilos, litros, piezas) y compara. Así sabes cuál conviene de verdad.



#### El café de Don Chuy

Don Chuy compara dos frascos de café.
- Frasco de 200 gramos: **90**
- gramos: **200**
- pesos por gramo: **0.45**
El frasco de 500 gramos cuesta 250: 0.50 por gramo. El chico le sale más barato.


#### Lo que te hace gastar de más

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Publicidad y redes | «Últimas piezas», «solo hoy». | Crean prisa. |
| Suscripciones | Poquito cada mes. | Suman mucho al año. |
| Abonos semanales | «Solo 99 a la semana». | Pagas más en total. |
| Espera un día | Antes de una compra no planeada. | Decides con calma. |

#### Un caso en un minuto

Beto sumó los abonos: 99 a la semana por 52 semanas son 5,148 pesos por unos audífonos que de contado costaban 2,300. Canceló dos plataformas que no usaba y ahorró 300 al mes.

> **Idea clave:** compara el precio por unidad, suma el costo total de los abonos y las suscripciones, y espera un día antes de comprar lo que no planeaste.



#### Comprueba lo que entendiste

1. ¿Cómo sabes qué paquete conviene?
*Respuesta:* Divides el precio entre la cantidad y comparas.

2. ¿Cómo sabes cuánto pagarás en abonos?
*Respuesta:* Multiplicas el abono por el número de pagos.


#### Para recordar

- Precio por unidad.
- Costo total de los abonos.
- Espera un día.



### Profundiza (5 minutos más)

#### Lo que gastas en algo ya no está para otra cosa

Si gastas 300 al mes en plataformas, son 3,600 al año que no van a tu fondo de emergencia o a tus deudas. Pregúntate: ¿qué dejo de hacer con este dinero?



#### Lo que sigue costando después

Algunas compras traen gastos después: una moto necesita gasolina, servicio y seguro; un celular, plan de datos y funda. Súmalos antes de decidir.



#### Revisa tus pagos que se repiten

| Pago | Cuánto al mes | Cuánto al año | ¿Lo uso? |
|---|---|---|---|
| Plataforma de video | | | |
| Plan del celular | | | |
| Abonos | | | |
| Otros | | | |

> **Antes de actuar, verifica:** el precio de contado, el número de pagos y lo que cuesta cancelar una suscripción.



#### Casos


**Caso 1. Los audífonos de Beto**

Beto quiere unos audífonos «a solo 99 a la semana» durante un año.
- *¿Qué hace?* Suma el costo total, lo compara con el de contado y espera un día.


**Caso 2. El café de Don Chuy**

Don Chuy cree que el frasco grande siempre sale más barato.
- *¿Qué hace?* Calcula el precio por gramo de cada frasco y compara.


**Caso 3. Las plataformas de Karla**

Karla paga tres plataformas de video y solo usa una.
- *¿Qué hace?* Cancela las que no usa y aparta ese dinero para su fondo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el abono | Pagas el doble | Suma el total |
| Creer que lo grande es más barato | Pagas de más | Precio por unidad |
| Suscripciones olvidadas | Fugas cada mes | Revisa y cancela |
| Comprar con prisa | Te arrepientes | Espera un día |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Don Chuy y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un producto cuesta 99 a la semana durante 52 semanas. ¿Cuánto pagas en total? a) 99 · b) 1,188, lo mismo que 12 pagos · c) 5,148
2. ¿Cómo comparas dos tamaños de un producto? a) Por el precio por unidad · b) Siempre el más grande · c) Por el que tenga más publicidad
3. Un anuncio dice «solo hoy». ¿Qué haces? a) Compras antes de que se acabe · b) Esperas un día y revisas si lo necesitas · c) Pides prestado para aprovechar
**Respuestas:** 1-c: 99 por 52. 2-a: así ves cuál rinde más. 3-b: la prisa es una técnica de venta.



#### Ponlo en práctica

Pagas dos plataformas de 150 al mes. ¿Cuánto es al año?
**Respuesta:** 3,600 pesos.



#### A tu plan

Haz la lista de tus pagos que se repiten y cancela al menos uno que no uses.



### Para saber más

- **Quién es quién en los precios** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** «Quién es quién en los precios».
- **Compras en abonos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «compras a plazos» y «CAT».

### Palabras clave

- *Precio por unidad:* precio dividido entre la cantidad; sirve para comparar tamaños.
- *Suscripción:* pago que se repite cada mes hasta que lo cancelas.
- *Costo de oportunidad:* lo que dejas de hacer con el dinero que gastas.

### Fuentes

Profeco · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 2. Módulo 2. Tu cuenta y tu dinero

## M2 U01. Una cuenta sin comisiones

**Lo que lograrás:** Conocer la cuenta básica que los bancos deben ofrecer sin comisiones y revisar si tu cuenta de nómina te cobra.

**Para empezar:** A Ramiro su banco le cobra 120 pesos al mes por «saldo mínimo». No sabía que existe una cuenta que no cobra comisiones. En esta lección sabrás cómo pedirla.

### Lo esencial (5 minutos)

#### La cuenta básica

Por ley, los bancos deben ofrecer una cuenta básica: sin comisión por abrirla, por manejo, ni por retiros y consultas en sus propios cajeros. Tiene un límite de depósitos al mes.

> **Dato vigente:** los bancos deben ofrecer una cuenta básica sin comisiones de apertura, manejo, retiros y consultas en sus cajeros; la de nivel 2 permite depósitos de hasta unos 26,000 pesos al mes. Consultado el 29 de septiembre de 2026 a través de Banxico y la Ley de Instituciones de Crédito (art. 48 Bis 2).



#### Qué revisar en tu cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión por manejo | Cobro cada mes. | La básica no cobra. |
| Cajeros | En los de tu banco, sin costo. | En otros, sí cobran. |
| Protección | Si es banco, la protege el IPAB. | Tu dinero seguro. |
| App | Para ver tus movimientos. | Actívala. |

#### Un caso en un minuto

Ramiro pidió en su banco la cuenta básica. Ya no le cobran los 120 al mes: 1,440 al año que se quedan en su bolsillo.

> **Idea clave:** pide la cuenta básica si tu cuenta te cobra comisiones; es tu derecho.



#### Comprueba lo que entendiste

1. ¿La cuenta básica cobra por manejo?
*Respuesta:* No.

2. ¿Dónde retiras sin costo?
*Respuesta:* En los cajeros de tu propio banco.


#### Para recordar

- Cuenta básica: sin comisiones.
- Cajeros de tu banco.
- Protegida por el IPAB.



### Profundiza (5 minutos más)

#### Tu cuenta de nómina

Si te pagan en una cuenta de nómina, revisa si te cobra algo. Tienes derecho a cambiar tu nómina a otro banco sin que te cobren, con la portabilidad de nómina.



#### Cajeros de otros bancos

Retirar en cajeros de otros bancos puede costar entre 20 y 40 pesos o más. Si retiras dos veces por semana, al mes es mucho. Usa los de tu banco o paga con tarjeta.



#### Casos


**Caso 1. La comisión de Ramiro**

El banco le cobra a Ramiro 120 al mes por saldo mínimo.
- *¿Qué hace?* Pide la cuenta básica, que no cobra comisiones.


**Caso 2. El cajero de Karla**

Karla retira en el cajero más cercano, de otro banco, y le cobran 35 cada vez.
- *¿Qué hace?* Retira en los cajeros de su banco o paga con tarjeta.


**Caso 3. La nómina de Don Chuy**

A Don Chuy no le gusta el banco donde le pagan.
- *¿Qué hace?* Pide la portabilidad de su nómina al banco que prefiera.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar comisiones sin saber | Pierdes cada mes | Pide la básica |
| Cajeros de otros bancos | Cobran cada vez | Usa los tuyos |
| No revisar tu cuenta | No ves cobros | Revisa movimientos |
| Creer que no puedes cambiar | Te quedas | Portabilidad de nómina |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es la cuenta básica? a) Una cuenta con comisiones bajas pero con tarjeta de crédito · b) Una cuenta sin comisiones de manejo · c) Una cuenta solo para empresas
2. Te cobran 35 por retiro en otro banco, 8 veces al mes. ¿Cuánto pagas? a) 280 · b) 35 · c) 350
3. No te gusta tu banco de nómina. ¿Qué puedes hacer? a) Nada, lo elige la empresa · b) Pedir la portabilidad de nómina · c) Cobrar en efectivo
**Respuestas:** 1-b: es tu derecho. 2-a: 35 por 8. 3-b: puedes cambiarla.



#### Ponlo en práctica

Tu cuenta cobra 120 al mes. ¿Cuánto ahorras al año con una cuenta básica?
**Respuesta:** 120 por 12: 1,440.



#### A tu plan

Revisa si tu cuenta te cobra comisiones y, si sí, pide la cuenta básica.



### Para saber más

- **Cuentas básicas** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «productos básicos» y comisiones.

### Palabras clave

- *Cuenta básica:* cuenta sin comisiones por apertura, manejo, retiros y consultas en los cajeros del banco.
- *Portabilidad de nómina:* cambiar tu cuenta de nómina a otro banco sin costo.

### Fuentes

Banco de México · Ley de Instituciones de Crédito, consultados el 29 de septiembre de 2026.

---

## M2 U02. Cobrar y pagar sin perder dinero

**Lo que lograrás:** Pagar y recibir dinero por transferencia sin errores, guardar comprobantes y evitar cargar mucho efectivo en el turno.

**Para empezar:** A Don Chuy le pagaron una parte en efectivo y la trajo todo el turno en la cartera. Además, cada semana va a pagar sus abonos en persona. En esta lección verás cómo mover tu dinero con menos riesgo.

### Lo esencial (5 minutos)

#### Transferir

Con la app de tu banco puedes enviar dinero con la CLABE de la otra persona. Revisa el nombre que aparece antes de enviar y guarda el comprobante.



#### Menos efectivo, menos riesgo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Menos robos | No cargas dinero en el turno. | Más seguro. |
| Comprobante | Queda registro de cada pago. | Prueba. |
| Menos filas | Pagas desde tu celular. | Ahorras tiempo. |
| Revisa el nombre | Antes de confirmar. | Evitas errores. |

#### Un caso en un minuto

Don Chuy le pidió a su hija que le enseñara a transferir. Ahora paga sus abonos desde el celular y guarda la foto del comprobante.

> **Idea clave:** transfiere revisando el nombre, guarda tu comprobante y carga poco efectivo en el turno.



#### Comprueba lo que entendiste

1. ¿Qué revisas antes de enviar una transferencia?
*Respuesta:* El nombre de la persona que aparece en la app.

2. ¿Por qué guardar el comprobante?
*Respuesta:* Es la prueba de que pagaste.


#### Para recordar

- CLABE de 18 dígitos.
- Revisa el nombre.
- Guarda el comprobante.



### Profundiza (5 minutos más)

#### El comprobante oficial

Las transferencias entre bancos tienen un comprobante oficial de Banxico (CEP) que puedes descargar en su sitio con los datos de la operación.



#### Cuentas que «cambian»

Si alguien a quien le pagas te dice por mensaje que cambió de cuenta, confirma por teléfono antes de pagar. Es un fraude común.



#### Casos


**Caso 1. El efectivo de Don Chuy**

Don Chuy trae todo su pago en efectivo durante el turno.
- *¿Qué hace?* Deposita o recibe por transferencia y carga poco efectivo.


**Caso 2. El abono de Karla**

Karla paga sus abonos en persona cada semana.
- *¿Qué hace?* Pregunta si puede pagar por transferencia y guarda el comprobante.


**Caso 3. La cuenta nueva del casero de Beto**

El casero de Beto le escribe que cambió de cuenta.
- *¿Qué hace?* Le llama para confirmar antes de pagar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cargar mucho efectivo | Robo | Transfiere |
| No revisar el nombre | Llega a otra persona | Revísalo |
| No guardar comprobante | Sin prueba | Foto o CEP |
| Creer cambios de cuenta por mensaje | Fraude | Llama |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuántos dígitos tiene la CLABE? a) 16 · b) 18 · c) 10
2. Te avisan por mensaje que cambió la cuenta de tu casero. ¿Qué haces? a) Le llamas para confirmar · b) Pagas a la cuenta nueva para no atrasarte · c) Contestas el mensaje
3. ¿Qué haces después de transferir? a) Nada · b) Borras el mensaje del banco para tener espacio · c) Guardas el comprobante
**Respuestas:** 1-b: 18 dígitos. 2-a: es un fraude común. 3-c: es tu prueba.



#### Ponlo en práctica

Escribe los tres pasos de una transferencia segura.
**Respuesta:** Pedir la CLABE por escrito, revisar el nombre antes de enviar y guardar el comprobante.



#### A tu plan

Registra en tu app a las personas a las que pagas cada mes.



### Para saber más

- **CEP** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «CEP».

### Palabras clave

- *CLABE:* número de 18 dígitos para recibir transferencias.
- *Comprobante:* prueba de que hiciste un pago.

### Fuentes

Banco de México, consultado el 29 de septiembre de 2026.

---

## M2 U03. Quién te protege y dónde reclamar

**Lo que lograrás:** Saber qué hace la CONDUSEF, cómo verificar que una institución existe y cómo reclamar un cobro indebido.

**Para empezar:** A Karla le cobran un «seguro» en su tarjeta que nunca pidió. En el banco le dijeron que no se puede quitar. Sí se puede. En esta lección sabrás a quién acudir.

### Lo esencial (5 minutos)

#### La CONDUSEF

La CONDUSEF orienta y defiende sin costo a quienes usan servicios financieros. No vende nada ni presta dinero.



#### Tres cosas que puedes hacer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Verificar | Si una financiera existe, en el SIPRES. | Antes de pedir un préstamo. |
| Reclamar | Primero en el banco, por escrito. | Pide folio. |
| Pedir ayuda | CONDUSEF: 55 5340 0999 u 800 999 8080. | Sin costo. |

#### Cómo reclamar

1) Reclama en la unidad de atención del banco, por escrito, y pide folio. 2) Si no te resuelven, acude a la CONDUSEF con tu folio.



#### Un caso en un minuto

Karla reclamó por escrito y guardó el folio. Como no le resolvieron, acudió a la CONDUSEF. Le devolvieron los cobros del seguro que no pidió.

> **Idea clave:** reclama por escrito con folio; si no te resuelven, la CONDUSEF te ayuda sin costo.



#### Comprueba lo que entendiste

1. ¿La CONDUSEF presta dinero?
*Respuesta:* No. Orienta y defiende sin costo.

2. ¿Qué pides al reclamar?
*Respuesta:* Un folio.


#### Para recordar

- CONDUSEF: sin costo.
- Reclama por escrito con folio.
- Verifica en el SIPRES.



### Profundiza (5 minutos más)

#### El SIPRES

Antes de pedir un préstamo, busca el nombre de la financiera en el SIPRES de la CONDUSEF. Si no aparece, no le des tus datos ni le pagues nada.



#### Nadie cobra por reclamar

Reclamar no tiene costo. Si un «gestor» te cobra por reclamar o por «arreglar» algo con el banco, desconfía.



#### Casos


**Caso 1. El seguro de Karla**

Le cobran a Karla un seguro que no pidió y le dicen que no se puede quitar.
- *¿Qué hace?* Reclama por escrito con folio y, si no le resuelven, va a la CONDUSEF.


**Caso 2. La financiera de Beto**

Beto quiere pedir un préstamo a una financiera que vio en redes.
- *¿Qué hace?* Busca su nombre en el SIPRES antes de dar sus datos.


**Caso 3. El gestor de Don Chuy**

Un gestor le ofrece a Don Chuy «arreglar» un cobro por 500 pesos.
- *¿Qué hace?* Reclama él mismo sin costo, primero en el banco y luego en la CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar «no se puede» | Pagas lo que no pediste | Reclama |
| Reclamar sin folio | Sin prueba | Pide folio |
| No verificar financieras | Fraude | SIPRES |
| Pagar a gestores | Es sin costo | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Beto y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué hace la CONDUSEF? a) Presta dinero en emergencias a quien lo necesita · b) Orienta y defiende sin costo · c) Cobra deudas
2. ¿Dónde verificas que una financiera existe? a) En sus redes sociales · b) En el SIPRES · c) Preguntando a un conocido que ya le pidió prestado
3. ¿Qué pides al reclamar en el banco? a) Un folio · b) Un descuento en tu próximo pago · c) Nada
**Respuestas:** 1-b: no tiene costo. 2-b: el registro oficial. 3-a: es tu constancia.



#### Ponlo en práctica

Te cobraron 89 al mes durante 10 meses por un seguro que no pediste. ¿Cuánto reclamas?
**Respuesta:** 89 por 10: 890.



#### A tu plan

Guarda en tu celular el teléfono de la CONDUSEF: 55 5340 0999 u 800 999 8080.



### Para saber más

- **SIPRES y reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES» y «reclamación».

### Palabras clave

- *CONDUSEF:* institución del gobierno que orienta y defiende sin costo a los usuarios de bancos y otras financieras.
- *SIPRES:* registro de la CONDUSEF donde aparecen las financieras que existen.
- *Folio:* número de tu reclamación.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M2 U04. ¿A quién le crees? Información confiable y cambios que te afectan

**Lo que lograrás:** Distinguir información confiable de publicidad y rumores, saber dónde preguntar sin costo y ajustar tu plan cuando cambian los precios, las tasas o las reglas.

**Para empezar:** En el grupo de WhatsApp del turno circula que «el banco va a congelar las cuentas» y que un tal asesor «multiplica tu aguinaldo». Ramiro no sabe qué creer. En esta lección verás cómo informarte bien.

### Lo esencial (5 minutos)

#### ¿Quién te está hablando?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fuentes oficiales | CONDUSEF, Banxico, SAT, IMSS, Profeco. | Sin costo y sin venderte nada. |
| Publicidad | Te informa, pero quiere venderte. | Compara antes. |
| Rumores y cadenas | Sin fuente ni fecha. | No reenvíes. |
| «Asesores» que prometen | Ganancias seguras y rápidas. | Casi siempre fraude. |

#### Antes de creer o reenviar

1. ¿Quién lo dice? Busca la fuente y la fecha.
2. ¿Qué gana esa persona si le crees?
3. Confírmalo en el sitio oficial o llamando a CONDUSEF.
4. Si no puedes confirmarlo, no lo reenvíes.



#### Cuando cambia la economía

Si suben los precios, las tasas de interés o cambian las reglas de un apoyo o del IMSS, tu plan también cambia. Revisa tu presupuesto, tus deudas con tasa variable y tus metas, y ajusta una cosa a la vez.



#### Un caso en un minuto

Ramiro buscó el aviso en el sitio de CONDUSEF: no existía ningún congelamiento. Salió del grupo del «asesor» y reportó el número. Cuando subieron los precios del transporte, ajustó su presupuesto en lugar de endeudarse.

> **Idea clave:** confirma en la fuente oficial antes de creer o reenviar, y cuando cambie la economía, ajusta tu plan con calma.



#### Comprueba lo que entendiste

1. ¿Dónde confirmas un aviso sobre bancos?
*Respuesta:* En el sitio oficial de CONDUSEF o de tu banco.

2. ¿Qué haces si suben los precios?
*Respuesta:* Revisas tu presupuesto y ajustas.


#### Para recordar

- Fuente y fecha.
- Confirma en lo oficial.
- Ajusta tu plan con calma.



### Profundiza (5 minutos más)

#### Orientación sin costo

CONDUSEF orienta sin costo sobre bancos, créditos y seguros; Profeco, sobre compras; el SAT, sobre impuestos. Nadie de ellos te cobra por orientarte ni te pide contraseñas.



#### Sigue aprendiendo

Cada vez que tomes una decisión grande, pregúntate qué aprendiste la última vez. Enséñale a tus hijos lo que ya sabes: hablar de dinero en casa también es educación.

> **Antes de actuar, verifica:** que la información tenga fuente oficial y fecha; ninguna autoridad te pide datos por WhatsApp.



#### Casos


**Caso 1. El rumor del grupo**

En el grupo del turno dicen que el banco va a congelar las cuentas.
- *¿Qué hace Ramiro?* Lo confirma en el sitio de CONDUSEF y no lo reenvía.


**Caso 2. El «asesor» del aguinaldo**

Un contacto le ofrece a Beto duplicar su aguinaldo en un mes.
- *¿Qué hace?* No invierte y lo reporta: nadie garantiza ganancias así.


**Caso 3. Los precios de Karla**

Subió el precio del transporte y del gas en la casa de Karla.
- *¿Qué hace?* Revisa su presupuesto y ajusta un gasto antes de endeudarse.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Reenviar sin confirmar | Asustas a otros | Fuente oficial |
| Creer en ganancias seguras | Fraude | Desconfía |
| Ignorar cambios | El plan ya no sirve | Ajusta |
| Pagar por orientación | Fraude | Es sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Beto y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te llega una cadena que dice que el banco congelará cuentas. ¿Qué haces? a) Lo confirmas en la fuente oficial y no lo reenvías · b) Sacas todo tu dinero hoy · c) Lo reenvías para avisar a todos
2. ¿Quién orienta sin costo sobre créditos y seguros? a) Un gestor que cobra por adelantado · b) CONDUSEF · c) El vendedor del crédito
3. Suben los precios del transporte. ¿Qué haces? a) Pides prestado para cubrir la diferencia · b) Sigues igual · c) Ajustas tu presupuesto
**Respuestas:** 1-a: confirma antes. 2-b: sin costo y sin venderte nada. 3-c: el plan se ajusta.



#### Ponlo en práctica

Tu transporte subió de 40 a 50 al día y trabajas 15 días al mes. ¿Cuánto más gastas al mes?
**Respuesta:** 150 pesos más al mes.



#### A tu plan

Guarda en tu celular los teléfonos de CONDUSEF y Profeco y revisa tu presupuesto la próxima vez que suba un precio.



### Para saber más

- **Orientación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «asesoría» y «alertas».
- **Inflación** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «inflación».

### Palabras clave

- *Fuente oficial:* autoridad o institución que publica la información con su nombre y fecha.
- *Rumor:* información sin fuente que no se puede confirmar.

### Fuentes

CONDUSEF · Profeco · Banco de México, consultados el 30 de septiembre de 2026.

---

## M2 U05. El dinero pierde valor: inflación e interés compuesto

**Lo que lograrás:** Entender cómo la inflación le quita valor al dinero guardado, qué es la tasa real y cómo el interés compuesto hace crecer tu ahorro o tu deuda.

**Para empezar:** Don Chuy guarda 10,000 pesos en un cajón desde hace tres años «para una emergencia». Hoy con ese dinero compra menos que cuando lo guardó. En esta lección verás por qué y qué hacer.

### Lo esencial (5 minutos)

#### La inflación

La inflación hace que con el mismo dinero compres menos. Si los precios suben 4% en un año, lo que costaba 100 ahora cuesta 104. El dinero en efectivo no crece: pierde valor cada año.

> **Dato vigente:** la meta de inflación del Banco de México es de 3% anual, con un margen de un punto hacia arriba o hacia abajo. Consultado el 30 de septiembre de 2026 a través del Banco de México.



#### La tasa real

Si tu ahorro gana intereses, réstale la inflación para saber si de verdad crece. Ejemplo:
- Lo que te paga tu ahorro al año: **7%**
- Inflación del año: **4%**
- Lo que de verdad crece: **3%**
Si tu ahorro paga menos que la inflación, pierdes poder de compra aunque veas más pesos.


#### El interés compuesto

Con el interés compuesto, tu ahorro gana intereses sobre los intereses. Con el tiempo crece cada vez más rápido. En una deuda pasa lo mismo, pero en tu contra.



#### Un caso en un minuto

Don Chuy pasó su fondo de emergencia del cajón a una opción protegida y con rendimiento (M7 U01). Ahora su dinero gana algo cada mes en lugar de perder valor, y sigue disponible si lo necesita.

> **Idea clave:** el dinero en efectivo pierde valor con la inflación; busca que tu ahorro gane al menos lo que suben los precios y paga pronto las deudas, que crecen con interés compuesto.



#### Comprueba lo que entendiste

1. ¿Qué hace la inflación con tu dinero guardado?
*Respuesta:* Le quita poder de compra.

2. ¿Qué es la tasa real?
*Respuesta:* Lo que te paga tu ahorro menos la inflación.


#### Para recordar

- Los precios suben: tu efectivo pierde valor.
- Tasa real = interés menos inflación.
- El interés compuesto ayuda al ahorro y castiga a la deuda.



### Profundiza (5 minutos más)

#### 1,000 pesos al 10% anual, con interés compuesto

| Año | Saldo |
|---|---|
| 0 | 1,000 |
| 1 | 1,100 |
| 2 | 1,210 |
| 3 | 1,331 |
| 5 | 1,611 |
| 10 | 2,594 |



#### En tu contra

Una deuda con interés alto crece igual de rápido. Si solo pagas el mínimo, los intereses se suman a lo que debes y pagas intereses sobre intereses. Por eso conviene pagar primero la deuda más cara (M3 U04).



#### Empieza pronto

Con el interés compuesto, el tiempo pesa más que el monto. Ahorrar poco desde hoy puede rendir más que ahorrar mucho dentro de diez años.

> **Antes de actuar, verifica:** la tasa que te paga tu ahorro y la inflación publicada por el Banco de México o el INEGI.



#### Casos


**Caso 1. El cajón de Don Chuy**

Don Chuy tiene 10,000 pesos en un cajón desde hace tres años.
- *¿Qué hace?* Los pasa a una opción protegida que pague al menos la inflación.


**Caso 2. El ahorro de Karla**

La cuenta de Karla paga 1% al año y la inflación es de 4%.
- *¿Qué entiende?* Que pierde poder de compra y compara otras opciones protegidas.


**Caso 3. La tarjeta de Beto**

Beto paga solo el mínimo de su tarjeta cada mes.
- *¿Qué entiende?* Que su deuda crece con interés compuesto y debe pagar más del mínimo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar todo en efectivo | Pierde valor | Opción protegida |
| Ver solo los pesos | No ves la pérdida | Tasa real |
| Pagar solo el mínimo | La deuda crece | Paga más |
| Esperar para ahorrar | Pierdes tiempo | Empieza hoy |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu ahorro paga 2% al año y la inflación es de 4%. ¿Qué pasa? a) Tu dinero crece 6% · b) Pierdes poder de compra · c) No pasa nada
2. ¿Qué es el interés compuesto? a) Una comisión del banco por abrir tu cuenta · b) Un impuesto · c) Interés sobre el dinero y sobre los intereses ya ganados
3. ¿Qué pasa con una deuda si solo pagas el mínimo? a) Crece con interés sobre interés · b) Se paga sola · c) Baja más rápido
**Respuestas:** 1-b: 2 menos 4 es menos 2. 2-c: por eso crece cada vez más. 3-a: el interés compuesto trabaja en tu contra.



#### Ponlo en práctica

Guardas 5,000 y la inflación es de 4% al año. ¿Cuánto necesitarías el año siguiente para comprar lo mismo?
**Respuesta:** 5,200 pesos.



#### A tu plan

Revisa cuánto paga el lugar donde guardas tu ahorro y compáralo con la inflación del último año.



### Para saber más

- **Inflación** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «inflación» y «calculadora de inflación».
- **Índice de precios** (INEGI · español): https://www.inegi.org.mx — **Qué buscar:** «INPC».

### Palabras clave

- *Inflación:* aumento general de los precios con el tiempo.
- *Tasa real:* lo que gana tu ahorro después de restar la inflación.
- *Interés compuesto:* interés que se calcula sobre el dinero y sobre los intereses que ya ganó.

### Fuentes

Banco de México · INEGI, consultados el 30 de septiembre de 2026.

---

## M2 U06. Tu dinero a trabajar: primeros pasos para invertir

**Lo que lograrás:** Distinguir ahorrar de invertir, conocer riesgo, rendimiento, plazo y diversificación, y dar un primer paso seguro con Cetes cuando ya tienes tu fondo de emergencia.

**Para empezar:** A Ramiro le sobran 500 pesos cada quincena desde que terminó su deuda. Un compañero le dice que meta todo a una criptomoneda «que va a subir». Ramiro no sabe por dónde empezar. En esta lección verás los primeros pasos.

### Lo esencial (5 minutos)

#### Antes de invertir

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fondo de emergencia | Primero, tu colchón disponible. | M7 U01. |
| Deudas caras pagadas | Ninguna inversión gana lo que cobra una tarjeta. | M3 U04. |
| Meta y plazo | ¿Para qué y cuándo lo necesitas? | Define el tipo de inversión. |
| Dinero que puedes necesitar mañana | No lo arriesgues. | Déjalo disponible. |

#### Riesgo y rendimiento van juntos

Invertir no es ahorrar: el valor puede subir o bajar. Si te prometen ganar mucho, también puedes perder mucho. No existen inversiones de bajo riesgo y alto rendimiento.



#### Un primer paso con respaldo del gobierno

Los Cetes son préstamos que le haces al gobierno federal a un plazo, y él te paga intereses. En Cetesdirecto abres tu cuenta en el sitio oficial, sin comisiones y con montos pequeños.



#### Un caso en un minuto

Ramiro ya tenía su fondo. Abrió Cetesdirecto y programó 500 cada quincena a Cetes con reinversión. No metió su dinero en la criptomoneda porque no podía explicar cómo ganaba ni quién la respaldaba.

> **Idea clave:** invierte solo después de tu fondo y tus deudas caras, en lo que puedas explicar, con una meta y un plazo, y poco a poco.



#### Comprueba lo que entendiste

1. ¿Qué va primero: el fondo de emergencia o invertir?
*Respuesta:* El fondo de emergencia.

2. ¿Existe una inversión segura que gane mucho y rápido?
*Respuesta:* No: más rendimiento significa más riesgo.


#### Para recordar

- Primero fondo y deudas caras.
- Riesgo y rendimiento van juntos.
- Poco a poco y con regularidad.



### Profundiza (5 minutos más)

#### No todo en un solo lugar

Diversificar reduce el golpe si una inversión baja. Con poco dinero, empezar en Cetes y tu AFORE ya es repartir.



#### Invertir cada quincena

Poner la misma cantidad cada quincena, sin importar si suben o bajan las tasas, te ayuda a ser constante y a no decidir con prisa o con miedo.



#### Revisa tu inversión

Cada mes, revisa tu estado de cuenta en Cetesdirecto: cuánto pusiste, cuánto ganaste y cuándo vence cada plazo. Lo que ganas en un Cete se vuelve tuyo al vencer; si retiras antes, puedes ganar menos. Si tu meta o tu plazo cambian, ajusta.



#### Tus emociones también invierten

El miedo te hace vender cuando algo baja; la emoción, comprar cuando «todos» compran. Decide con tu meta y tu plazo, no con lo que dicen en el grupo.

> **Antes de actuar, verifica:** que la institución esté autorizada en el padrón de la CNBV y que el sitio sea el oficial; en Cetesdirecto nadie te pide pagar para abrir tu cuenta.



#### Casos


**Caso 1. La criptomoneda de Ramiro**

Un compañero le dice a Ramiro que meta todo a una criptomoneda «que va a subir».
- *¿Qué hace?* No invierte en lo que no puede explicar y empieza con Cetes.


**Caso 2. El fondo de Karla**

Karla quiere invertir, pero todavía no tiene fondo de emergencia.
- *¿Qué hace?* Primero junta su fondo y después invierte.


**Caso 3. El miedo de Don Chuy**

Don Chuy oye en la tele que «todo va a bajar» y quiere sacar su dinero de Cetes antes del plazo.
- *¿Qué hace?* Revisa su meta y su plazo y no decide con miedo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Invertir sin fondo | Vendes en mal momento | Fondo primero |
| Todo en un solo lugar | Pierdes mucho | Diversifica |
| Creer en ganancias seguras | Fraude | Riesgo y rendimiento |
| Decidir con miedo | Pierdes | Tu meta y tu plazo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces antes de invertir? a) Pides un préstamo para empezar · b) Juntas tu fondo de emergencia y pagas tus deudas caras · c) Inviertes lo de la renta
2. Te ofrecen 10% al mes «sin riesgo». ¿Qué es? a) Casi seguro un fraude · b) Una buena oportunidad · c) Una inversión del gobierno
3. ¿Qué es diversificar? a) Poner todo en lo que más sube · b) Cambiar de inversión cada semana · c) Repartir tu dinero en distintas inversiones
**Respuestas:** 1-b: primero tu colchón. 2-a: nadie garantiza tanto. 3-c: así no dependes de una sola.



#### Ponlo en práctica

Inviertes 500 cada quincena durante un año. ¿Cuánto pusiste, sin contar intereses?
**Respuesta:** 12,000 pesos (24 quincenas).



#### A tu plan

Si ya tienes tu fondo de emergencia, entra a Cetesdirecto desde el sitio oficial y conoce cómo funciona antes de invertir.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com.
- **Padrón de entidades** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «padrón de entidades supervisadas».
- **Inversiones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «invertir» y «fraudes de inversión».

### Palabras clave

- *Invertir:* poner dinero a trabajar para que crezca, aceptando algo de riesgo.
- *Cetes:* préstamos que le haces al gobierno federal a un plazo a cambio de intereses.
- *Diversificar:* repartir tu dinero en distintas inversiones para no depender de una sola.

### Fuentes

Cetesdirecto · CNBV · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 3. Módulo 3. Tus deudas claras

## M3 U01. ¿Cuánto debes en total?

**Lo que lograrás:** Hacer la lista de todas tus deudas: a quién, cuánto, cuánto pagas y cada cuándo.

**Para empezar:** Don Chuy tiene una deuda con una tienda en abonos, un adelanto de nómina y un préstamo con un conocido. Si le preguntas cuánto debe, dice «poquito en cada lado». Nunca lo ha sumado. En esta lección harás tu lista.

### Lo esencial (5 minutos)

#### La lista primero

No puedes salir de lo que no ves. Haz una lista con todas tus deudas: bancos, tiendas, apps, empeño, adelantos, préstamos con familiares o conocidos, y tandas que debes.



#### Qué anotar de cada deuda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| A quién | Tienda, banco, app, persona. | Todas. |
| Cuánto debes | El saldo de hoy. | Aproximado está bien. |
| Pago y fecha | Cuánto y cada cuándo. | Semanal, quincenal. |
| Cuánto te cuesta | Intereses o lo que pagas de más. | M3 U02. |

#### Las deudas de Don Chuy

- Tienda en abonos: **7,200**
- Adelanto de nómina: **1,380**
- Préstamo de un conocido: **3,000**
- Total: **11,580**
Don Chuy nunca lo había visto junto.


#### Un caso en un minuto

Al ver el total, Don Chuy entendió por qué nunca le alcanza: paga casi 1,800 al mes en abonos. Con la lista, pudo hacer un plan (M3 U04).

> **Idea clave:** suma todas tus deudas en una lista; es el primer paso para salir.



#### Comprueba lo que entendiste

1. ¿Qué deudas van en la lista?
*Respuesta:* Todas: bancos, tiendas, apps, empeño, adelantos y préstamos con personas.

2. ¿Necesitas el saldo exacto?
*Respuesta:* No, uno aproximado está bien para empezar.


#### Para recordar

- Todas las deudas.
- A quién, cuánto y cuándo.
- Súmalas.



### Profundiza (5 minutos más)

#### Tu lista de deudas

| A quién | Debo | Pago | Cada cuándo |
|---|---|---|---|
| | | | |
| | | | |
| **Total** | | | |



#### ¿Cuánto de tu ingreso se va en deudas?

Suma lo que pagas al mes en todas tus deudas y divídelo entre lo que te llega al mes. Si pasa de un tercio, es momento de dejar de pedir prestado y hacer un plan.



#### Casos


**Caso 1. El «poquito» de Don Chuy**

Don Chuy dice que debe «poquito en cada lado».
- *¿Qué hace?* Hace su lista y suma el total de sus deudas.


**Caso 2. La tanda de Karla**

Karla ya cobró su tanda y todavía debe cuatro pagos.
- *¿Qué hace?* La anota en su lista como deuda.


**Caso 3. La app de Beto**

Beto no incluye el préstamo de la app porque le da pena.
- *¿Qué hace?* Lo anota: todas las deudas cuentan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No sumar | No ves el problema | Haz la lista |
| Olvidar deudas con personas | Lista incompleta | Todas |
| Olvidar la tanda cobrada | Deuda oculta | Anótala |
| Esconder deudas por pena | No puedes planear | Todas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué va en tu lista de deudas? a) Todas tus deudas, incluidas las de personas · b) Solo las del banco · c) Solo las grandes, las chicas no importan
2. Ya cobraste tu tanda y debes pagos. ¿Qué es? a) Ahorro · b) Una deuda · c) Un regalo
3. Pagas 3,000 al mes en deudas y te llegan 8,000. ¿Qué parte se va en deudas? a) Menos de una cuarta parte · b) Casi la mitad · c) Más de un tercio
**Respuestas:** 1-a: todas cuentan. 2-b: debes pagos. 3-c: 3,000 de 8,000 es 37.5%.



#### Ponlo en práctica

Debes 5,000 en una tienda, 2,000 en una app y 1,500 a tu cuñado. ¿Total?
**Respuesta:** 8,500.



#### A tu plan

Llena tu lista de deudas con todas, aunque sean chicas, y suma el total.



### Para saber más

- **Deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «sobreendeudamiento».

### Palabras clave

- *Deuda:* dinero que debes pagar.
- *Saldo:* lo que debes hoy.
- *Abono:* pago parcial de una deuda.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U02. Lo que de verdad cuesta un préstamo

**Lo que lograrás:** Calcular cuánto pagas en total por un préstamo o una compra en abonos, y comparar con el CAT.

**Para empezar:** Karla compró una pantalla de 6,000 «a 52 abonos de 190». Sonaba barato. En total pagará 9,880. En esta lección aprenderás a ver el costo total antes de firmar.

### Lo esencial (5 minutos)

#### La pantalla de Karla

- Abono semanal: **190**
- Semanas: **52**
- Lo que pagará en total: **9,880**
Pagará 3,880 más que el precio de contado.


#### Mira el total, no el abono

Un abono chico puede esconder un costo grande. Siempre multiplica el pago por el número de pagos y compáralo con el precio de contado o con lo que te prestan.



#### Préstamos comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tiendas en abonos | Pagos semanales por muchas semanas. | Mira el total. |
| Adelanto de nómina | Te descuentan después. | A veces con comisión. |
| Empeño | Dejas algo y pagas intereses. | Puedes perderlo. |
| Apps | Rápido y caro; algunas extorsionan. | Módulo 6. |

#### El CAT

El CAT te dice cuánto cuesta un crédito al año, con intereses y comisiones. Sirve para comparar: mientras más alto, más caro.



#### Un caso en un minuto

Karla ahora multiplica antes de comprar. La próxima vez ahorró 12 semanas y compró de contado.

> **Idea clave:** multiplica el abono por los pagos y compara con el contado; el abono chico engaña.



#### Comprueba lo que entendiste

1. ¿Cómo sabes cuánto pagas en total?
*Respuesta:* Multiplicando el pago por el número de pagos.

2. ¿Para qué sirve el CAT?
*Respuesta:* Para comparar cuánto cuesta un crédito al año.


#### Para recordar

- Pago por número de pagos.
- Compara con el contado.
- CAT para comparar.



### Profundiza (5 minutos más)

#### Compara dos opciones

| Opción | Pago | Número de pagos | Total |
|---|---|---|---|
| Tienda A | 190 semanal | 52 | 9,880 |
| Tienda B | 350 semanal | 20 | 7,000 |
| Ahorrar y comprar de contado | 500 semanal | 12 | 6,000 |



#### Empeño

En una casa de empeño dejas algo de valor y te prestan una parte. Si no pagas a tiempo, lo pierdes. Revisa el contrato, el costo y el plazo; Profeco supervisa a las casas de empeño.



#### Casos


**Caso 1. La pantalla de Karla**

Le ofrecen a Karla una pantalla a 52 abonos de 190.
- *¿Qué hace?* Multiplica y compara con el precio de contado antes de firmar.


**Caso 2. El adelanto de Beto**

Beto pide un adelanto de 1,000 y le descuentan 1,150.
- *¿Qué hace?* Calcula que le cuesta 150 y busca no depender de adelantos.


**Caso 3. El reloj de Ramiro**

Ramiro quiere empeñar su reloj para pagar otra deuda.
- *¿Qué hace?* Revisa el costo y el plazo, y evalúa si podrá recuperarlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el abono | Pagas mucho más | Mira el total |
| No comparar | Eliges lo caro | Compara el CAT |
| Empeñar sin plan | Pierdes tu prenda | Revisa el plazo |
| Adelanto tras adelanto | Nunca alcanza | Planea salir |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Beto y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. 40 abonos semanales de 150. ¿Cuánto pagas? a) 6,000 · b) 150 · c) 4,000
2. ¿Qué indica un CAT más alto? a) Un crédito más barato y conveniente · b) Un crédito más caro · c) Más plazo para pagar
3. Algo cuesta 4,000 de contado y en abonos pagas 6,500. ¿Cuánto pagas de más? a) 6,500 · b) 2,500 · c) 4,000
**Respuestas:** 1-a: 150 por 40. 2-b: mide el costo. 3-b: 6,500 menos 4,000.



#### Ponlo en práctica

Te ofrecen un celular de 5,000 a 48 abonos semanales de 160. ¿Cuánto pagas y cuánto de más?
**Respuesta:** 160 por 48: 7,680. Pagas 2,680 de más.



#### A tu plan

Antes de tu próxima compra en abonos, multiplica y compara con el precio de contado.



### Para saber más

- **Simuladores de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador de crédito» y CAT.
- **Casas de empeño** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** «casas de empeño».

### Palabras clave

- *CAT:* Costo Anual Total: lo que cuesta un crédito al año, con intereses y comisiones.
- *Empeño:* préstamo en el que dejas algo de valor como garantía.
- *Precio de contado:* lo que cuesta si pagas todo de una vez.

### Fuentes

CONDUSEF · Profeco, consultados el 29 de septiembre de 2026.

---

## M3 U03. Prestamistas y «gota a gota»

**Lo que lograrás:** Reconocer los préstamos «gota a gota» y de prestamistas informales, por qué son peligrosos y qué hacer si ya tienes uno.

**Para empezar:** A Ramiro le ofrecieron 3,000 «sin papeles» a pagar 150 diarios durante un mes. Suena fácil. En realidad pagaría 4,500 y, si se atrasa, lo pueden amenazar. En esta lección verás por qué no conviene.

### Lo esencial (5 minutos)

#### Qué es el «gota a gota»

El préstamo gota a gota es un préstamo rápido, sin requisitos, con pagos diarios o semanales e intereses altísimos. Si te atrasas, los cobradores amenazan y extorsionan.

> **Dato vigente:** autoridades y la CONDUSEF alertan sobre préstamos informales «gota a gota» con intereses de hasta 20% diario o semanal, cobrados con amenazas y extorsión; recomiendan pedir crédito solo a instituciones registradas en el SIPRES. Consultado el 29 de septiembre de 2026 a través de la CONDUSEF y medios nacionales.



#### El préstamo a Ramiro

- Pago diario: **150**
- Días: **30**
- Lo que pagaría: **4,500**
Por 3,000 que le prestan, pagaría 1,500 de más en un mes.


#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sin papeles ni contrato | Nadie sabe quién presta. | No hay protección. |
| Pagos diarios | Difíciles de sostener. | Te atrapan. |
| Amenazas | Si te atrasas. | Delito. |
| No aparece en el SIPRES | No es institución. | No pidas. |

#### Un caso en un minuto

Ramiro no aceptó. Habló con su supervisor sobre un adelanto y ajustó su presupuesto. Pagó menos de lo que le habría costado el préstamo.

> **Idea clave:** un préstamo sin contrato, con pagos diarios y cobro con amenazas es una trampa; busca otra salida.



#### Comprueba lo que entendiste

1. ¿Por qué son peligrosos los «gota a gota»?
*Respuesta:* Por sus intereses altísimos y porque cobran con amenazas.

2. ¿Dónde verificas si quien presta es una institución?
*Respuesta:* En el SIPRES de la CONDUSEF.


#### Para recordar

- Sin contrato = sin protección.
- Pagos diarios = trampa.
- Amenazas = delito.



### Profundiza (5 minutos más)

#### Si ya tienes uno

No pidas otro préstamo para pagarlo. Guarda evidencia de pagos y de amenazas. Si te amenazan, denuncia ante la fiscalía o llama al 089 (denuncia anónima) o al 911 si hay riesgo. Avisa a tu familia para que no la presionen.



#### Otras salidas

Hablar con tu empleador sobre un adelanto, pedir prestado a un familiar con un acuerdo claro, vender algo que no usas o ajustar tu presupuesto suelen costar mucho menos.



#### Casos


**Caso 1. Los 3,000 de Ramiro**

Le ofrecen a Ramiro 3,000 a pagar 150 diarios por un mes, sin contrato.
- *¿Qué hace?* No lo acepta y busca una salida más barata.


**Caso 2. Las amenazas a Don Chuy**

Un prestamista amenaza a Don Chuy porque se atrasó.
- *¿Qué hace?* Guarda evidencia y denuncia; si hay riesgo, llama al 911.


**Caso 3. El segundo préstamo de Beto**

Beto quiere pedir otro «gota a gota» para pagar el primero.
- *¿Qué hace?* No pide otro y busca ayuda para salir de la deuda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar sin contrato | Sin protección | No aceptes |
| Pedir otro para pagar | Deuda crece | Busca otra salida |
| Callar las amenazas | Te siguen presionando | Denuncia |
| Creer que es rápido y fácil | Es caro | Calcula el total |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Don Chuy y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prestan 2,000 a pagar 100 diarios por 30 días. ¿Cuánto pagas? a) 2,000 · b) 3,000 · c) 2,100
2. Un prestamista te amenaza. ¿Qué haces? a) Guardas evidencia y denuncias · b) Pides otro préstamo para pagarle rápido · c) No dices nada a nadie
3. ¿Qué es una señal de préstamo peligroso? a) Contrato por escrito · b) Aparece en el SIPRES · c) Pagos diarios sin contrato
**Respuestas:** 1-b: 100 por 30. 2-a: las amenazas son delito. 3-c: es la trampa típica.



#### Ponlo en práctica

Te prestan 1,500 a pagar 90 diarios por 25 días. ¿Cuánto pagas de más?
**Respuesta:** 90 por 25: 2,250. Pagas 750 de más.



#### A tu plan

Si alguien te ofrece un préstamo sin contrato, calcula el total y búscalo en el SIPRES antes de decidir.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES» y alertas sobre préstamos fraudulentos.

### Palabras clave

- *Préstamo gota a gota:* préstamo informal de pagos diarios con intereses muy altos, cobrado con amenazas.
- *Usura:* cobrar intereses abusivos.

### Fuentes

CONDUSEF · medios nacionales, consultados el 29 de septiembre de 2026.

---

## M3 U04. Tu plan para salir de deudas

**Lo que lograrás:** Elegir un método para salir de deudas (bola de nieve o avalancha), negociar con tus acreedores y dejar de pedir nuevos préstamos.

**Para empezar:** Don Chuy ya tiene su lista: 11,580 en tres deudas. No sabe por cuál empezar. Si paga un poco a todas, nunca termina ninguna. En esta lección harás tu plan.

### Lo esencial (5 minutos)

#### Dos métodos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bola de nieve | Pagas primero la deuda más chica. | Ves avances rápido. |
| Avalancha | Pagas primero la más cara. | Pagas menos intereses. |
| Mínimo en las demás | A las otras les pagas lo acordado. | No te atrasas. |
| Sin nuevas deudas | Mientras sales. | Si no, no avanzas. |

#### Cómo funciona

Paga lo mínimo o acordado en todas, y todo lo extra a una sola. Cuando la terminas, lo que pagabas a esa lo sumas a la siguiente. Así cada vez pagas más rápido.



#### Negocia

Si no puedes pagar, habla antes de atrasarte. Muchas tiendas y bancos ofrecen reestructuras o convenios. Pide todo por escrito.



#### Un caso en un minuto

Don Chuy eligió la bola de nieve: primero el adelanto (1,380), después el préstamo del conocido (3,000) y al final la tienda. En cinco meses terminó dos deudas y ya ve el final.

> **Idea clave:** todo lo extra a una deuda, lo mínimo a las demás y ningún préstamo nuevo.



#### Comprueba lo que entendiste

1. ¿Qué deuda pagas primero con la bola de nieve?
*Respuesta:* La más chica.

2. ¿Qué haces si no puedes pagar?
*Respuesta:* Negociar antes de atrasarte y pedirlo por escrito.


#### Para recordar

- Bola de nieve o avalancha.
- Lo extra a una sola.
- Sin nuevas deudas.



### Profundiza (5 minutos más)

#### Tu plan

| Orden | Deuda | Debo | Pago extra |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |



#### Consolidar

Juntar varias deudas en un solo préstamo puede ayudar si el nuevo cuesta menos en total. Calcula el total antes; si el plazo es mucho más largo, puedes pagar más.



#### Casos


**Caso 1. Las tres deudas de Don Chuy**

Don Chuy paga un poco a cada deuda y no termina ninguna.
- *¿Qué hace?* Elige un método y pone todo lo extra en una sola deuda.


**Caso 2. La tienda de Karla**

Karla no podrá pagar su abono la próxima semana.
- *¿Qué hace?* Llama antes a la tienda para negociar y pide el acuerdo por escrito.


**Caso 3. La tarjeta nueva de Beto**

Mientras paga sus deudas, a Beto le ofrecen una tarjeta nueva.
- *¿Qué hace?* No la acepta hasta salir de sus deudas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar poquito a todas | No terminas | Lo extra a una |
| Atrasarte sin avisar | Cargos y Buró | Negocia antes |
| Nuevas deudas | No avanzas | Pausa |
| Acuerdos de palabra | Sin prueba | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Con la avalancha, ¿cuál pagas primero? a) La más cara · b) La más chica · c) La más reciente
2. No podrás pagar la próxima semana. ¿Qué haces? a) Esperas a que te llamen de cobranza · b) Negocias antes y pides el acuerdo por escrito · c) Pides otro préstamo
3. ¿Qué haces con lo que pagabas a una deuda terminada? a) Te lo gastas en algo que te guste · b) Lo guardas debajo del colchón · c) Lo sumas a la siguiente deuda
**Respuestas:** 1-a: ahorras intereses. 2-b: evitas cargos. 3-c: así aceleras.



#### Ponlo en práctica

Debes 1,000, 4,000 y 7,000, y puedes pagar 600 extra al mes. Con bola de nieve, ¿en cuántos meses terminas la primera (sin intereses)?
**Respuesta:** 1,000 entre 600: en unos 2 meses.



#### A tu plan

Ordena tus deudas con un método y decide cuánto extra pagarás cada quincena.



### Para saber más

- **Salir de deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «reestructura» y «salir de deudas».

### Palabras clave

- *Bola de nieve:* método para pagar primero la deuda más chica.
- *Avalancha:* método para pagar primero la deuda más cara.
- *Reestructura:* cambio de condiciones de una deuda para poder pagarla.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U05. Apuestas en línea: cuando el juego se vuelve deuda

**Lo que lograrás:** Reconocer los riesgos de las apuestas y casinos en línea, poner límites y saber dónde pedir ayuda si el juego ya se volvió un problema.

**Para empezar:** Beto empezó apostando 50 pesos a los partidos en sus horas muertas del turno. Tres meses después debe 9,000 en una app de préstamos que usó para «recuperar» lo que perdió. En esta lección verás cómo pasa y cómo frenarlo.

### Lo esencial (5 minutos)

#### Por qué enganchan

Las apps de apuestas y casinos en línea están a un toque, 24 horas, con bonos de bienvenida y avisos de «apuesta ahora». En turnos largos con tiempo muerto, es fácil apostar sin darte cuenta de cuánto va. A la larga, la casa siempre gana.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Quieres recuperar lo perdido | Apuestas más para «desquitarte». | Es la trampa principal. |
| Apuestas con crédito | Préstamos o tarjeta para jugar. | Deuda segura. |
| Lo escondes | No le dices a tu familia cuánto apuestas. | Señal de problema. |
| Límite y pausa | Tope al mes y días sin apostar. | Control. |

#### Si decides apostar, pon candados

1. Solo en sitios con permiso de la Secretaría de Gobernación.
2. Un tope al mes que salga de tus gustos, nunca de la renta ni del ahorro.
3. Nunca con préstamos ni con tarjeta de crédito.
4. Usa los límites de depósito y la autoexclusión de la app.



#### Un caso en un minuto

Beto borró las apps de apuestas, pidió la autoexclusión en su cuenta y le contó a su hermano cuánto debía. Hizo un plan para pagar la deuda (M3 U04) y cambió sus horas muertas por un curso en el celular.

> **Idea clave:** apostar para recuperar lo perdido y apostar con crédito son las dos señales de que el juego ya es un problema.



#### Comprueba lo que entendiste

1. ¿Cuál es la trampa principal de las apuestas?
*Respuesta:* Apostar más para recuperar lo perdido.

2. ¿De dónde nunca debe salir el dinero para apostar?
*Respuesta:* De préstamos, tarjeta, renta o ahorro.


#### Para recordar

- La casa siempre gana.
- Nunca con crédito.
- Límite, pausa y ayuda.



### Profundiza (5 minutos más)

#### Sitios sin permiso

Hay apps y páginas de apuestas que no tienen permiso para operar en México. Si ganas, pueden no pagarte; si hay un problema, no tienes a quién reclamar, y tus datos quedan expuestos. La Secretaría de Gobernación publica la lista de permisionarios.



#### Pedir ayuda

El juego compulsivo es un problema de salud, no de falta de voluntad. Los Centros de Integración Juvenil y la Línea de la Vida (800 911 2000) orientan sin costo. Contarle a alguien de confianza es el primer paso.

> **Antes de actuar, verifica:** que el sitio aparezca en la lista de permisionarios de la Secretaría de Gobernación antes de registrar tus datos o tu tarjeta.



#### Casos


**Caso 1. La deuda de Beto**

Beto perdió 3,000 pesos y quiere pedir un préstamo para «recuperarlos».
- *¿Qué hace?* No pide el préstamo, deja de apostar y busca ayuda.


**Caso 2. El bono de Ramiro**

A Ramiro le ofrecen un bono de bienvenida si deposita 500 en una app.
- *¿Qué revisa?* Si el sitio tiene permiso y si ese dinero sale de sus gustos, no del ahorro.


**Caso 3. El compañero de Karla**

Un compañero de Karla le pide prestado para apostar en el partido.
- *¿Qué hace?* No le presta y, si la confianza lo permite, le comparte dónde pedir ayuda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Recuperar lo perdido | Pierdes más | Para |
| Apostar con crédito | Deuda | Nunca |
| Esconderlo | Crece el problema | Cuéntalo |
| Sitios sin permiso | No te pagan | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Ramiro y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Perdiste en las apuestas este mes. ¿Qué haces? a) Apuestas más para recuperarlo · b) Paras y revisas tu presupuesto · c) Pides un préstamo rápido
2. ¿Cuál es una señal de que el juego ya es un problema? a) Apostar una vez al año en la quiniela de la oficina · b) Revisar los resultados del partido · c) Apostar con préstamos o tarjeta
3. ¿Qué revisas antes de registrarte en una app de apuestas? a) Que tenga permiso de la Secretaría de Gobernación · b) Que tenga muchos anuncios · c) Que el bono sea grande
**Respuestas:** 1-b: recuperar es la trampa. 2-c: deuda segura. 3-a: sin permiso no hay a quién reclamar.



#### Ponlo en práctica

Apuestas 50 pesos al día en tus 15 turnos del mes. ¿Cuánto apuestas al mes y al año?
**Respuesta:** 750 al mes; 9,000 al año.



#### A tu plan

Si apuestas, fija un tope al mes que salga de tus gustos y activa los límites de la app; si ya es un problema, habla hoy con alguien de confianza.



### Para saber más

- **Línea de la Vida** (Secretaría de Salud · español): 800 911 2000 | Atención sin costo las 24 horas.
- **Centros de Integración Juvenil** (español): https://www.gob.mx/salud/cij — **Qué buscar:** «juego patológico».
- **Permisionarios de juegos y sorteos** (Secretaría de Gobernación · español): https://www.gob.mx/segob — **Qué buscar:** «juegos y sorteos permisionarios».

### Palabras clave

- *Autoexclusión:* opción para bloquear tu propia cuenta de apuestas por un tiempo.
- *Juego compulsivo:* cuando no puedes dejar de apostar aunque te cause problemas.

### Fuentes

Secretaría de Gobernación · Secretaría de Salud · Centros de Integración Juvenil, consultados el 29 de septiembre de 2026.

---


# Parte 4. Módulo 4. Tandas y ahorro en grupo

## M4 U01. Tandas: cómo funcionan y qué puede salir mal

**Lo que lograrás:** Entender cómo funciona una tanda, cuándo es ahorro y cuándo es deuda, y qué riesgos tiene.

**Para empezar:** Karla organiza una tanda de 10 compañeras con 500 cada quincena. Una compañera cobró en el turno 2 y dejó de pagar. Karla tuvo que poner de su bolsa. En esta lección verás qué puede salir mal.

### Lo esencial (5 minutos)

#### Cómo funciona

En una tanda, cada persona aporta lo mismo cada periodo y, por turnos, una se lleva todo. No paga intereses: recibes lo mismo que pones.



#### Ahorro o deuda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Si cobras al final | Es como ahorro. | Pones antes de recibir. |
| Si cobras al principio | Es como un préstamo. | Recibes antes de pagar. |
| Si alguien deja de pagar | Pierden los demás. | El mayor riesgo. |
| Sin protección | No hay institución detrás. | Solo confianza. |

#### La tanda de Karla

- Aportación por quincena: **500**
- Personas: **10**
- Lo que cobra cada una: **5,000**
Quien cobra primero debe 4,500 en nueve quincenas.


#### Un caso en un minuto

Karla perdió 500 cuando una compañera dejó de pagar. En la siguiente tanda puso reglas por escrito (M4 U02).

> **Idea clave:** una tanda no paga intereses y depende de que todas cumplan; si cobras primero, tienes una deuda.



#### Comprueba lo que entendiste

1. ¿Una tanda paga intereses?
*Respuesta:* No. Recibes lo mismo que pones.

2. ¿Qué pasa si cobras primero?
*Respuesta:* Tienes una deuda con el grupo.


#### Para recordar

- Sin intereses.
- Cobrar primero = deuda.
- Depende de la confianza.



### Profundiza (5 minutos más)

#### Riesgos de una tanda

| Riesgo | Qué pasa |
|---|---|
| Alguien deja de pagar | Pierden quienes cobran después |
| Quien organiza desaparece | Se pierde todo |
| Sin registro | Discusiones sobre quién pagó |
| Cambios de trabajo o turno | Alguien se va del grupo |



#### Tanda contra cuenta

En una cuenta de ahorro, tu dinero está protegido y solo depende de ti. En una tanda, depende del grupo. La tanda ayuda a ahorrar por compromiso, pero tiene más riesgo.



#### Casos


**Caso 1. La compañera de Karla**

Una compañera cobró en el turno 2 y dejó de pagar.
- *¿Qué hace Karla la próxima vez?* Pone reglas por escrito y deja los primeros turnos a personas de confianza.


**Caso 2. El turno de Beto**

Beto quiere el primer turno para comprarse un celular.
- *¿Qué hace?* Entiende que es una deuda y revisa si podrá pagar todas las quincenas.


**Caso 3. El organizador de Don Chuy**

El organizador de la tanda de Don Chuy cambió de trabajo.
- *¿Qué hace?* Pide que se nombre a otra persona y se lleve un registro de pagos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que da intereses | No es inversión | Es ahorro en grupo |
| Cobrar primero sin plan | No puedes pagar | Es deuda |
| Sin registro | Discusiones | Anota cada pago |
| Entrar con desconocidos | Riesgo alto | Solo gente de confianza |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Beto y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tanda de 8 personas con 400 cada quincena. ¿Cuánto cobra cada una? a) 3,200 · b) 400 · c) 4,000
2. Cobraste primero. ¿Qué tienes? a) Una ganancia · b) Una deuda con el grupo · c) Un ahorro protegido por el banco
3. ¿Cuál es el mayor riesgo de una tanda? a) Los intereses que cobra · b) Que alguien deje de pagar · c) Que el banco la cancele
**Respuestas:** 1-a: 400 por 8. 2-b: debes los pagos. 3-b: pierden los demás.



#### Ponlo en práctica

Tanda de 12 personas con 300 cada quincena. Cobras en el turno 3. ¿Cuánto has puesto al cobrar y cuánto te falta pagar?
**Respuesta:** Cobras 3,600. Al cobrar has puesto 900; te faltan 9 pagos: 2,700.



#### A tu plan

Si estás en una tanda, anota en tu lista cuánto has puesto, cuándo cobras y cuánto te falta.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «tandas» y ahorro formal.

### Palabras clave

- *Tanda:* ahorro en grupo en el que cada persona aporta lo mismo y cada turno una cobra todo.
- *Turno de la tanda:* el momento en que te toca cobrar.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M4 U02. Tu tanda con reglas o tu propio ahorro

**Lo que lograrás:** Organizar una tanda con reglas claras por escrito, o ahorrar lo mismo por tu cuenta en una cuenta protegida.

**Para empezar:** Karla quiere volver a organizar una tanda, pero esta vez sin perder. También piensa si le conviene ahorrar sola. En esta lección verás las dos opciones.

### Lo esencial (5 minutos)

#### Reglas para una tanda más segura

1. Solo personas de confianza que conozcas bien.
2. Reglas por escrito: monto, fechas, turnos y qué pasa si alguien no paga.
3. Registro de cada pago, con foto o transferencia.
4. Los primeros turnos, para quienes tienen más antigüedad y confianza.



#### Tu propio ahorro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta aparte | El mismo monto cada quincena. | Protegida por el IPAB. |
| Automático | Transferencia programada. | Como una tanda, sin grupo. |
| Meta | Para qué ahorras. | Te motiva. |
| Sin esperar tu turno | El dinero es tuyo cuando lo necesites. | Más libertad. |

#### Cuál elegir

Si te cuesta ahorrar sola, la tanda con reglas puede ayudarte. Si puedes apartar tú misma, una cuenta aparte tiene menos riesgo.



#### Un caso en un minuto

Karla organizó una tanda con reglas escritas y pagos por transferencia. Al mismo tiempo, abrió una cuenta aparte con 100 por quincena para emergencias.

> **Idea clave:** si haces tanda, que sea con reglas escritas y registro; si puedes, ahorra también por tu cuenta.



#### Comprueba lo que entendiste

1. ¿Qué debe estar por escrito en una tanda?
*Respuesta:* Monto, fechas, turnos y qué pasa si alguien no paga.

2. ¿Qué ventaja tiene ahorrar en una cuenta?
*Respuesta:* Tu dinero está protegido y solo depende de ti.


#### Para recordar

- Reglas por escrito.
- Registro de pagos.
- O tu propio ahorro.



### Profundiza (5 minutos más)

#### Reglas de la tanda

| Regla | Acuerdo |
|---|---|
| Monto por quincena | |
| Fechas de pago | |
| Orden de turnos | |
| Qué pasa si alguien no paga | |
| Cómo se registran los pagos | |



#### Pagos por transferencia

Pagar la tanda por transferencia deja registro de cada pago y evita cargar efectivo en el turno.



#### Casos


**Caso 1. La nueva tanda de Karla**

Karla quiere organizar otra tanda sin perder dinero.
- *¿Qué hace?* Pone las reglas por escrito y registra cada pago.


**Caso 2. El ahorro de Ramiro**

Ramiro puede apartar 300 cada quincena sin problema.
- *¿Qué hace?* Ahorra por su cuenta en una cuenta aparte, sin depender de un grupo.


**Caso 3. El desconocido en la tanda de Don Chuy**

Un desconocido quiere entrar a la tanda de Don Chuy con el primer turno.
- *¿Qué hace?* No lo acepta en los primeros turnos o no lo acepta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Reglas de palabra | Discusiones | Por escrito |
| Sin registro | No sabes quién pagó | Transferencias |
| Primeros turnos a desconocidos | Se van | Confianza |
| Solo tandas | Riesgo concentrado | Ahorra también aparte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Ramiro y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién debe tener los primeros turnos? a) Quien los pida primero · b) Personas de confianza · c) Un desconocido que los necesite con urgencia
2. ¿Cómo registras los pagos? a) Con transferencia o foto · b) De memoria · c) No hace falta
3. Puedes apartar 200 cada quincena sin problema. ¿Qué te conviene? a) Solo entrar a más tandas · b) Esperar a que sobre · c) Ahorrar también en una cuenta aparte
**Respuestas:** 1-b: menos riesgo. 2-a: queda prueba. 3-c: protegido y tuyo.



#### Ponlo en práctica

Ahorras 250 por quincena en una cuenta aparte. ¿Cuánto tienes en 10 quincenas?
**Respuesta:** 2,500.



#### A tu plan

Si participas en una tanda, propón escribir las reglas; y abre una cuenta aparte para tu propio ahorro.



### Para saber más

- **Cuentas de ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuentas de ahorro».

### Palabras clave

- *Registro de pagos:* lista de quién pagó y cuándo.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M4 U03. Tu casa: Infonavit y el crédito de 100 puntos

**Lo que lograrás:** Conocer cómo revisar tus puntos y tu ahorro de vivienda en Infonavit, las nuevas reglas para salarios bajos y cómo evitar coyotes.

**Para empezar:** Karla cotiza en el IMSS desde hace dos años. Siempre creyó que «nunca juntaría los puntos» para una casa. Una compañera le dijo que las reglas cambiaron. En esta lección verás qué revisar.

### Lo esencial (5 minutos)

#### Tu ahorro de vivienda

Si tu empresa te da de alta en el IMSS, también aporta el 5% de tu salario a tu subcuenta de vivienda en Infonavit. Ese dinero sirve para un crédito de vivienda y, si nunca lo usas, se entrega al retirarte.



#### Qué revisar en Mi Cuenta Infonavit

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tus puntos | Precalificación para un crédito. | Con tu NSS. |
| Tu ahorro | Saldo de la subcuenta de vivienda. | Crece cada bimestre. |
| Cuánto te prestan | Según tu salario y edad. | Simulador oficial. |
| Coyotes | Cobran por «ayudarte». | El trámite no tiene costo. |

> **Dato vigente:** con el modelo de 100 puntos de Infonavit, quienes ganan entre uno y dos salarios mínimos, tienen al menos seis meses seguidos cotizando y no tienen vivienda propia pueden precalificar con 100 puntos en lugar de 1,080; la tasa es fija y va de 3.69% a 10.45% anual según el salario. Consultado el 29 de septiembre de 2026 a través de Infonavit y medios especializados.

#### Un caso en un minuto

Karla entró a Mi Cuenta Infonavit con su NSS. Tiene más de seis meses cotizando, gana menos de dos salarios mínimos y no tiene casa: ya precalifica. Usará el simulador para ver cuánto le prestan y cuánto le descontarían de su quincena antes de decidir.

> **Idea clave:** revisa tus puntos y tu ahorro en Mi Cuenta Infonavit; el trámite no tiene costo y las reglas cambiaron para salarios bajos.



#### Comprueba lo que entendiste

1. ¿Cuánto aporta tu empresa a tu subcuenta de vivienda?
*Respuesta:* El 5% de tu salario.

2. ¿Qué pasa con tu ahorro de vivienda si nunca pides crédito?
*Respuesta:* Se entrega al retirarte.


#### Para recordar

- 5% de tu salario para vivienda.
- Mi Cuenta Infonavit con tu NSS.
- El trámite no tiene costo.



### Profundiza (5 minutos más)

#### Antes de firmar

Revisa cuánto te descontarán de la quincena: con un descuento alto puede no alcanzarte para lo demás (M1). Pregunta el costo total, la tasa, el plazo y qué seguros incluye el crédito. Visita la zona y la vivienda antes de decidir: transporte al trabajo, servicios y seguridad.



#### Coyotes y fraudes

Hay personas que cobran por «sacarte los puntos» o prometen casas que no existen. Los trámites se hacen en Mi Cuenta Infonavit o en sus oficinas, sin costo. Nunca entregues dinero ni tu contraseña a un intermediario.

> **Antes de actuar, verifica:** tus requisitos y montos en Mi Cuenta Infonavit; las reglas pueden cambiar.



#### Casos


**Caso 1. Los puntos de Karla**

Karla cree que nunca podrá tener un crédito de vivienda.
- *¿Qué hace?* Revisa sus puntos y requisitos en Mi Cuenta Infonavit.


**Caso 2. El coyote de Beto**

Alguien le ofrece a Beto «adelantarle» su crédito por 3,000 pesos.
- *¿Qué hace?* No paga: el trámite no tiene costo y se hace directo en Infonavit.


**Caso 3. El descuento de Don Chuy**

A Don Chuy le prestan para una casa, pero el descuento sería de 30% de su quincena.
- *¿Qué revisa?* Si su presupuesto aguanta ese descuento antes de firmar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar tus puntos | Pierdes la opción | Mi Cuenta Infonavit |
| Pagar coyotes | Fraude | Sin costo |
| Firmar sin ver el descuento | No te alcanza | Revisa tu presupuesto |
| No visitar la casa | Mala ubicación | Visítala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Beto y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde revisas tus puntos y tu ahorro de vivienda? a) Con un gestor · b) En tu banco · c) En Mi Cuenta Infonavit con tu NSS
2. Alguien te cobra por «sacarte» tu crédito Infonavit. ¿Qué haces? a) No pagas: el trámite no tiene costo · b) Pagas la mitad · c) Le das tu contraseña para agilizar
3. ¿Qué revisas antes de firmar un crédito de vivienda? a) Solo el color de la casa · b) Cuánto te descontarán de la quincena y si te alcanza · c) Lo que opine el vendedor
**Respuestas:** 1-c: sitio oficial. 2-a: sin intermediarios. 3-b: tu presupuesto manda.



#### Ponlo en práctica

Ganas 9,600 al mes. ¿Cuánto aporta tu empresa a tu subcuenta de vivienda al mes y al año?
**Respuesta:** 5% de 9,600: 480 al mes; 5,760 al año.



#### A tu plan

Entra a Mi Cuenta Infonavit con tu NSS y anota tus puntos y el saldo de tu subcuenta de vivienda.



### Para saber más

- **Mi Cuenta Infonavit** (Infonavit · español): https://micuenta.infonavit.org.mx — **Qué buscar:** «precalificación» y «saldo de vivienda».
- **Infonavit** (español): https://portalmx.infonavit.org.mx — **Qué buscar:** «crédito Infonavit» y «evita fraudes».

### Palabras clave

- *Subcuenta de vivienda:* ahorro en Infonavit que tu empresa deposita con el 5% de tu salario.
- *Precalificación:* puntos que indican si ya puedes pedir un crédito de vivienda.
- *Coyote:* intermediario que cobra por trámites que no tienen costo.

### Fuentes

Infonavit, consultado el 29 de septiembre de 2026.

---


# Parte 5. Módulo 5. Buró de Crédito sin miedo

## M5 U01. Qué es el Buró de Crédito

**Lo que lograrás:** Entender qué es el Buró de Crédito, qué guarda y qué no hace, para perderle el miedo.

**Para empezar:** Beto cree que está «boletinado en el Buró» y que por eso nunca le prestarán. Otros le dicen que el Buró es una lista negra. En esta lección verás qué es de verdad.

### Lo esencial (5 minutos)

#### No es una lista negra

El Buró de Crédito guarda tu historial de créditos: lo que pediste y cómo pagaste, lo bueno y lo malo. No presta dinero y no decide si te prestan: decide cada institución.



#### Lo que guarda y lo que no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tus créditos | Tarjetas, préstamos, tiendas. | Y cómo pagas. |
| Atrasos | Cuándo y cuánto. | Se borran con el tiempo. |
| No es lista negra | Todos los que tienen crédito están ahí. | También con buen historial. |
| No presta | Solo guarda información. | Decide quien presta. |

#### También hay Círculo

Hay dos empresas que guardan historiales: Buró de Crédito y Círculo de Crédito. Puedes tener información en una, en otra o en las dos.



#### Un caso en un minuto

Beto pidió su reporte sin costo. No estaba «boletinado»: tenía un atraso en una tienda. Al pagarlo y mantener sus pagos a tiempo, su historial empezó a mejorar.

> **Idea clave:** el Buró no es lista negra; es tu historial, y tu historial mejora con pagos a tiempo.



#### Comprueba lo que entendiste

1. ¿El Buró decide si te prestan?
*Respuesta:* No. Decide cada institución.

2. ¿Solo aparecen quienes deben?
*Respuesta:* No. Aparece todo el que ha tenido crédito, también con buen historial.


#### Para recordar

- Es un historial, no una lista negra.
- No presta ni decide.
- Buró y Círculo.



### Profundiza (5 minutos más)

#### Los atrasos no son para siempre

Los atrasos se eliminan del historial después de un tiempo que depende del monto: de uno a seis años. Pagar no los borra de inmediato, pero mejora tu historial hacia adelante.



#### Tener historial ayuda

Tener créditos pequeños bien pagados te ayuda a conseguir mejores condiciones después. No tener historial también puede dificultar un crédito.



#### Casos


**Caso 1. El «boletinado» de Beto**

Beto cree que está en una lista negra y que nunca le prestarán.
- *¿Qué hace?* Pide su reporte sin costo para ver qué hay de verdad.


**Caso 2. El crédito de Karla**

Karla nunca ha tenido crédito y le negaron uno.
- *¿Qué hace?* Entiende que sin historial también cuesta y empieza con algo pequeño que pueda pagar.


**Caso 3. El atraso de Don Chuy**

Don Chuy pagó un atraso y cree que se borra al instante.
- *¿Qué hace?* Sabe que el registro se elimina con el tiempo y sigue pagando a tiempo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es lista negra | Miedo sin razón | Pide tu reporte |
| Creer que el Buró presta | Confusión | Decide quien presta |
| Esperar borrado inmediato | Frustración | Se elimina con el tiempo |
| Evitar todo crédito | Sin historial | Algo pequeño bien pagado |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el Buró de Crédito? a) Una lista negra de personas que no pagan sus deudas · b) Un historial de tus créditos y pagos · c) Un banco
2. ¿Quién decide si te prestan? a) La institución que presta · b) El Buró · c) El gobierno
3. ¿Qué mejora tu historial? a) Pedir muchos créditos · b) Cancelar todas tus tarjetas · c) Pagar a tiempo
**Respuestas:** 1-b: guarda lo bueno y lo malo. 2-a: el Buró solo informa. 3-c: los pagos puntuales cuentan.



#### Ponlo en práctica

Escribe dos mitos del Buró que escuchaste y la realidad.
**Respuesta:** Por ejemplo: «es lista negra» (es un historial); «el Buró te niega el crédito» (decide quien presta).



#### A tu plan

Anota qué créditos crees que aparecen en tu historial para compararlo con tu reporte (M5 U02).



### Para saber más

- **Buró de Crédito** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** «qué es el Buró».

### Palabras clave

- *Buró de Crédito:* empresa que guarda tu historial de créditos y pagos, buenos y malos.
- *Historial de crédito:* registro de tus créditos y cómo los pagaste.

### Fuentes

Buró de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M5 U02. Tu reporte sin costo y cómo reclamar

**Lo que lograrás:** Pedir tu reporte de crédito sin costo una vez al año en Buró y en Círculo, leerlo y reclamar si hay errores.

**Para empezar:** En el reporte de Karla aparece una deuda de una tienda que ya pagó. Si no la reclama, le puede afectar al pedir un crédito. En esta lección sabrás cómo pedir tu reporte y reclamar.

### Lo esencial (5 minutos)

#### Sin costo una vez al año

Puedes pedir un reporte de crédito sin costo una vez al año en Buró de Crédito y otro en Círculo de Crédito, en sus sitios oficiales.

> **Dato vigente:** Buró de Crédito y Círculo de Crédito entregan un reporte sin costo una vez al año, en sus sitios oficiales. Consultado el 29 de septiembre de 2026 a través de sus sitios y la CONDUSEF.



#### Qué revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tus créditos | ¿Todos son tuyos? | Si no, reclama. |
| Tus pagos | ¿Están bien los atrasos? | Si no, reclama. |
| Consultas | Quién revisó tu historial. | ¿Las autorizaste? |
| Saldos | ¿Coinciden? | Con tus comprobantes. |

#### Reclamar no tiene costo

Si hay un error, presenta una reclamación en la sociedad que lo reporta y en la institución, con tus comprobantes. No necesitas gestores.



#### Un caso en un minuto

Karla reclamó en línea con su comprobante de pago. En unas semanas corrigieron su reporte.

> **Idea clave:** pide tu reporte sin costo cada año y reclama tú misma cualquier error.



#### Comprueba lo que entendiste

1. ¿Cada cuánto puedes pedir tu reporte sin costo?
*Respuesta:* Una vez al año en cada sociedad.

2. ¿Cuánto cuesta reclamar un error?
*Respuesta:* Nada.


#### Para recordar

- Sin costo una vez al año.
- Revisa créditos, pagos y consultas.
- Reclama con comprobantes.



### Profundiza (5 minutos más)

#### Tu revisión

| Pregunta | Sí o no |
|---|---|
| ¿Todos los créditos son míos? | |
| ¿Los atrasos son correctos? | |
| ¿Reconozco las consultas? | |
| ¿Los saldos coinciden? | |



#### Solo sitios oficiales

Hay páginas que cobran por «tu Buró» o que lo imitan. Entra solo a burodecredito.com.mx y circulodecredito.com.mx, escribiendo tú la dirección.



#### Casos


**Caso 1. La tienda de Karla**

Aparece en el reporte de Karla una deuda que ya pagó.
- *¿Qué hace?* Reclama con su comprobante en la sociedad y en la tienda.


**Caso 2. La página de Beto**

Beto encuentra una página que le cobra 200 por su reporte.
- *¿Qué hace?* Lo pide sin costo en el sitio oficial.


**Caso 3. La consulta de Ramiro**

En el reporte de Ramiro hay una consulta de una financiera que no conoce.
- *¿Qué hace?* Reclama la consulta y revisa si alguien usó sus datos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No pedir tu reporte | No ves errores | Una vez al año |
| Pagar por el reporte | Es sin costo | Sitio oficial |
| Aceptar errores | Te afectan | Reclama |
| Pagar a gestores | Es sin costo | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Beto y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuántos reportes sin costo puedes pedir al año? a) Ninguno · b) Uno en total, en cualquiera de las dos · c) Uno en Buró y uno en Círculo
2. Hay un crédito que no es tuyo. ¿Qué haces? a) Lo reclamas · b) Lo pagas para que se borre · c) Lo ignoras
3. ¿Dónde pides tu reporte? a) En la página que te llegó por mensaje · b) En los sitios oficiales · c) Con un gestor
**Respuestas:** 1-c: uno en cada una. 2-a: reclamar no tiene costo. 3-b: evitas fraudes.



#### Ponlo en práctica

Llena la tabla de revisión con tu último reporte o con uno de ejemplo.
**Respuesta:** Por ejemplo: todos los créditos son míos; un atraso que ya pagué aparece mal; reconozco las consultas; saldos coinciden salvo el de la tienda.



#### A tu plan

Pide tu reporte sin costo este mes en el sitio oficial de Buró de Crédito o de Círculo de Crédito.



### Para saber más

- **Reporte de Crédito Especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** reporte sin costo y reclamaciones.
- **Reporte** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** reporte sin costo.

### Palabras clave

- *Reporte de crédito:* documento con tus créditos, pagos y consultas.
- *Consulta:* registro de quién revisó tu historial.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M5 U03. Cómo mejorar tu historial

**Lo que lograrás:** Mejorar tu historial con pagos a tiempo y uso moderado del crédito, y reconocer a los despachos que prometen «limpiar tu Buró».

**Para empezar:** A Don Chuy le ofrecieron «limpiar su Buró» por 2,500 pesos. Suena tentador. Pero nadie puede borrar información correcta. En esta lección verás cómo mejorar de verdad.

### Lo esencial (5 minutos)

#### Lo que sí mejora tu historial

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pagos a tiempo | Lo más importante. | Cada mes cuenta. |
| Uso moderado | No usar todo tu límite. | Menos de un tercio. |
| Paciencia | Los atrasos se eliminan con el tiempo. | No hay atajos. |
| Pocas solicitudes | Pedir muchos créditos seguidos. | Resta. |

#### Nadie borra lo correcto

Los despachos que prometen «limpiar tu Buró» a cambio de dinero no pueden borrar información correcta. Si hay un error, lo reclamas tú, sin costo (M5 U02).



#### Un caso en un minuto

Don Chuy no pagó al despacho. Puso recordatorios para pagar a tiempo y dejó de pedir créditos nuevos. En un año su historial mejoró.

> **Idea clave:** tu historial mejora con pagos a tiempo y tiempo; nadie puede borrar lo correcto a cambio de dinero.



#### Comprueba lo que entendiste

1. ¿Qué es lo más importante para mejorar tu historial?
*Respuesta:* Pagar a tiempo.

2. ¿Un despacho puede borrar información correcta?
*Respuesta:* No.


#### Para recordar

- Pagos a tiempo.
- Uso moderado.
- Sin atajos pagados.



### Profundiza (5 minutos más)

#### Recordatorios

Pon alarmas en tu celular dos días antes de cada pago, o domicilia los pagos si tienes el dinero en tu cuenta.



#### Uso moderado

Si tienes una tarjeta de 10,000, trata de no deber más de 3,000. Usar todo tu límite indica riesgo.



#### Casos


**Caso 1. El despacho de Don Chuy**

Le ofrecen a Don Chuy «limpiar su Buró» por 2,500.
- *¿Qué hace?* No paga y mejora su historial con pagos a tiempo.


**Caso 2. La tarjeta de Karla**

Karla usa casi todo el límite de su tarjeta cada mes.
- *¿Qué hace?* Trata de no deber más de un tercio de su límite.


**Caso 3. Las solicitudes de Beto**

Beto pidió cinco créditos en un mes para ver cuál le daban.
- *¿Qué hace?* Deja de pedir créditos seguidos y paga a tiempo lo que ya tiene.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar a despachos | Pierdes dinero | Mejora con tiempo |
| Pagos tarde | Historial peor | Recordatorios |
| Usar todo el límite | Señal de riesgo | Menos de un tercio |
| Pedir muchos créditos | Resta | Pocas solicitudes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te ofrecen «limpiar tu Buró» por dinero. ¿Qué es? a) Un servicio legítimo si tienen oficina · b) Un engaño: nadie borra lo correcto · c) Un trámite del gobierno
2. Tu tarjeta es de 9,000. ¿Cuánto conviene deber como máximo? a) 3,000 · b) 9,000 · c) 8,000
3. ¿Qué te ayuda a pagar a tiempo? a) Esperar a que te llamen · b) Recordatorios en tu celular · c) Pedir otro crédito
**Respuestas:** 1-b: no pueden borrar lo correcto. 2-a: un tercio. 3-b: no se te pasa la fecha.



#### Ponlo en práctica

Tu tarjeta es de 12,000 y debes 9,000. ¿Cuánto tendrías que bajar para quedar en un tercio?
**Respuesta:** Un tercio de 12,000 es 4,000; tendrías que bajar 5,000.



#### A tu plan

Pon alarmas en tu celular dos días antes de cada pago.



### Para saber más

- **Despachos que «limpian»** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «reparadoras de crédito».

### Palabras clave

- *Uso del límite:* cuánto de tu crédito disponible estás usando.
- *Domiciliar:* pagar automáticamente desde tu cuenta.

### Fuentes

CONDUSEF · Buró de Crédito, consultados el 29 de septiembre de 2026.

---

## M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?

**Lo que lograrás:** Distinguir aval, obligado solidario, fiador, garantía y referencia personal, saber qué te pueden cobrar en cada caso y decidir antes de firmar por otra persona.

**Para empezar:** Un compañero le pide a Beto que sea su aval para un préstamo de nómina, y a Karla la pusieron de referencia en una tarjeta sin preguntarle. Ninguno sabe qué le pueden cobrar. En esta lección verás qué implica cada papel.

### Lo esencial (5 minutos)

#### Cada papel, una responsabilidad

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aval | Firma el pagaré: si no pagan, te cobran a ti todo. | Aparece en tu historial. |
| Obligado solidario | Respondes por todo el contrato como si fueras quien pidió. | Te pueden cobrar directo. |
| Fiador | Común en rentas: pagas si la otra persona no paga. | Revisa el contrato. |
| Referencia personal | Solo das tus datos de contacto. | No te pueden cobrar. |

#### «Garante» y «garantía»

«Garante» es una palabra general para quien respalda un crédito: en el contrato aparece como aval, obligado solidario o fiador. Una garantía es distinta: es un bien que puedes perder si no pagas.



#### Ser referencia no es ser aval

Cuando alguien pide una tarjeta o un préstamo, le piden referencias: nombre y teléfono de personas que lo conocen. Ser referencia personal no te obliga a pagar nada. Si no firmaste como aval, obligado solidario o fiador, esa deuda no es tuya.

> **Dato vigente:** las reglas de la CONDUSEF para despachos de cobranza solo les permiten cobrar al deudor, a sus avales y a sus obligados solidarios; no pueden cobrar a referencias personales ni amenazar a familiares o compañeros de trabajo. Las quejas se presentan en el REDECO. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF.



#### Un caso en un minuto

Beto le dijo a su compañero que no podía firmar una deuda que no podría pagar, y lo acompañó a comparar créditos. Karla supo que, como referencia, no le pueden cobrar nada.

> **Idea clave:** aval, obligado solidario y fiador pagan si la otra persona no paga; una referencia solo da sus datos y no le pueden cobrar. Lee qué firmas y hazlo solo si podrías pagar esa deuda.



#### Comprueba lo que entendiste

1. ¿Te pueden cobrar si solo fuiste referencia personal?
*Respuesta:* No. Solo diste tus datos; no firmaste ninguna obligación.

2. ¿Qué pasa si firmas como aval y la otra persona no paga?
*Respuesta:* Te pueden cobrar a ti y puede aparecer en tu historial.


#### Para recordar

- Aval, obligado solidario y fiador: pagan si el otro no paga.
- Referencia: solo datos; no te cobran.
- Firma solo si podrías pagar.



### Profundiza (5 minutos más)

#### ¿Qué firmas?

| Papel | ¿Firmas? | ¿Te pueden cobrar? | ¿Afecta tu historial? |
|---|---|---|---|
| Aval | Sí, el pagaré | Sí, todo | Puede aparecer |
| Obligado solidario | Sí, el contrato | Sí, directo | Puede aparecer |
| Fiador | Sí, el contrato | Sí, si el otro no paga | Puede aparecer |
| Referencia personal | No | No | No |
| Titular con tarjeta adicional | Sí, como titular | Sí, todo lo que gaste la adicional | Sí |



#### Cómo decir que no

Pedirte que seas aval es pedirte que te hagas cargo de una deuda. Puedes decir: «Te quiero ayudar, pero no puedo firmar una deuda que no podría pagar». Ofrece otra ayuda: acompañarle a comparar créditos o armar un presupuesto.



#### Si te llaman como referencia

Si un despacho te presiona para pagar una deuda de la que solo eres referencia, no pagues ni des datos de más. Pide el nombre del despacho, anota fecha y hora y preséntalo en el REDECO de la CONDUSEF.

> **Antes de actuar, verifica:** qué dice el documento que te piden firmar (pagaré, contrato, solicitud) y en qué papel apareces.



#### Casos


**Caso 1. El préstamo de Beto**

Un compañero le pide a Beto que firme como aval de un préstamo de 15,000.
- *¿Qué hace Beto?* Dice que no puede firmar una deuda que no podría pagar y ofrece otra ayuda.


**Caso 2. La solicitud de Karla**

A Karla le piden firmar «como referencia» una hoja que dice «obligado solidario».
- *¿Qué hace?* No firma: ese papel la obliga a pagar todo el contrato.


**Caso 3. La llamada a Don Chuy**

Un despacho llama a Don Chuy para cobrarle la deuda de un compañero del que solo fue referencia.
- *¿Qué hace?* No paga, pide el nombre del despacho y se queja en el REDECO.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin leer | Deuda ajena | Lee tu papel |
| Creer que la referencia paga | Pagas sin deber | No te obliga |
| Aval por compromiso | Pagas tú | Solo si podrías pagar |
| Adicional sin límite | Tu deuda crece | Límite bajo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Diste tu nombre y teléfono como referencia para la tarjeta de un amigo. ¿Te pueden cobrar? a) Sí, la mitad · b) Sí, si él no paga · c) No, solo diste tus datos
2. ¿Quién responde por todo el contrato como si hubiera pedido el crédito? a) El obligado solidario · b) La referencia personal · c) El vendedor
3. Un despacho te presiona para pagar una deuda de la que solo eres referencia. ¿Qué haces? a) Pagas para que dejen de llamar · b) No pagas y te quejas en el REDECO · c) Das los datos de tu amigo y los de su familia
**Respuestas:** 1-c: la referencia no se obliga. 2-a: por eso le pueden cobrar directo. 3-b: no pueden cobrar a referencias.



#### Ponlo en práctica

Te piden ser aval de un préstamo de 30,000 a 24 meses. Si la otra persona deja de pagar a la mitad, ¿cuánto podrían cobrarte, sin contar intereses?
**Respuesta:** Unos 15,000 pesos: lo que falte por pagar, más intereses y cargos.



#### A tu plan

Antes de firmar por alguien, pregunta en qué papel apareces y decide solo si podrías pagar esa deuda.



### Para saber más

- **Aval y obligado solidario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «aval» y «obligado solidario».
- **Quejas contra despachos de cobranza** (CONDUSEF, REDECO · español): https://redeco.condusef.gob.mx.

### Palabras clave

- *Aval:* persona que firma un pagaré y se obliga a pagar si quien pidió el crédito no paga.
- *Obligado solidario:* persona que responde por todo el contrato como si hubiera pedido el crédito.
- *Fiador:* persona que se obliga a pagar si el deudor no paga; común en contratos de renta.
- *Referencia personal:* persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no se obliga a pagar.

### Fuentes

CONDUSEF (disposiciones para despachos de cobranza y REDECO), consultados el 30 de septiembre de 2026.

---


# Parte 6. Módulo 6. Que no te extorsionen

## M6 U01. Llamadas y mensajes falsos

**Lo que lograrás:** Reconocer las llamadas y mensajes falsos que imitan a bancos, paqueterías o premios, y responder colgando y verificando tú.

**Para empezar:** Durante un turno de noche, a Don Chuy le llamaron «del banco» porque había «un cargo raro». Le pidieron el código que le llegó por mensaje. Estaba cansado y casi lo da. En esta lección verás por qué nunca debes darlo.

### Lo esencial (5 minutos)

#### La regla de oro

Si te llaman o escriben pidiendo un código, tu NIP, una contraseña o dinero: **cuelga y verifica tú**, llamando al número de atrás de tu tarjeta. Tu banco nunca te pide códigos.



#### Engaños comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Del banco» | Te piden el código para «cancelar un cargo». | Cuelga. |
| Paquetería | «Paga 30 pesos para tu envío». | Roban tu tarjeta. |
| Premio | «Ganaste, paga el envío». | Nadie regala así. |
| Familiar con número nuevo | Te pide dinero urgente. | Llámale a su número de siempre. |

#### Cuidado en la noche

Muchos fraudes llegan de noche o en madrugada, cuando estás cansado. Si te piden algo urgente, espera a verificar.



#### Un caso en un minuto

Don Chuy colgó y llamó al número de atrás de su tarjeta. No había ningún cargo. El código era para sacar dinero de su cuenta.

> **Idea clave:** el código es como tu firma: nunca lo das; cuelga y verifica tú.



#### Comprueba lo que entendiste

1. ¿Tu banco te pide códigos por teléfono?
*Respuesta:* Nunca.

2. ¿Qué haces si te piden algo urgente?
*Respuesta:* Cuelgo y verifico por el número de atrás de mi tarjeta.


#### Para recordar

- El código nunca se da.
- Cuelga y verifica.
- No abras enlaces de mensajes.



### Profundiza (5 minutos más)

#### Enlaces

No abras enlaces de mensajes que dicen ser de tu banco o de una paquetería. Si te preocupa, abre tú la app de tu banco.



#### Avisa a tus compañeros

Si recibes un fraude, avisa en tu turno para que nadie caiga. Los estafadores suelen llamar a varios en la misma zona.



#### Casos


**Caso 1. La llamada nocturna a Don Chuy**

«Del banco» le piden a Don Chuy el código que le llegó.
- *¿Qué hace?* No lo da, cuelga y llama al número de atrás de su tarjeta.


**Caso 2. El paquete de Karla**

Le llega a Karla un mensaje para pagar 30 pesos por un paquete que no espera.
- *¿Qué hace?* Lo borra sin pagar.


**Caso 3. El primo de Beto**

Su «primo» le escribe a Beto desde un número nuevo pidiéndole dinero.
- *¿Qué hace?* Le llama a su número de siempre antes de enviar nada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar el código | Te vacían la cuenta | Nunca |
| Abrir enlaces | Página falsa | Usa tu app |
| Actuar con prisa | Caes | Verifica |
| No avisar | Otros caen | Cuéntalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden el código que te llegó «para cancelar un cargo». ¿Qué haces? a) Lo das si la persona sabe tu nombre completo · b) Cuelgas y llamas a tu banco · c) Das la mitad
2. ¿Qué haces con un mensaje de paquetería que no esperas? a) Lo borras · b) Pagas los 30 pesos · c) Abres el enlace
3. Un familiar con número nuevo te pide dinero. ¿Qué haces? a) Envías para ayudar · b) Le preguntas por mensaje si es él · c) Le llamas a su número de siempre
**Respuestas:** 1-b: el banco no pide códigos. 2-a: buscan tu tarjeta. 3-c: confirma por un medio conocido.



#### Ponlo en práctica

Escribe la frase que usarás para colgar a una llamada sospechosa.
**Respuesta:** Por ejemplo: «Gracias, llamo yo al número de mi tarjeta». Y cuelgas.



#### A tu plan

Guarda en tus contactos el número de atrás de tu tarjeta como «Mi banco».



### Para saber más

- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «Portal de Fraudes Financieros».

### Palabras clave

- *Código de verificación:* número que te llega para autorizar una operación; es como tu firma.
- *Phishing:* engaño con mensajes o páginas falsas para robar tus datos.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M6 U02. Apps «montadeudas»

**Lo que lograrás:** Reconocer las apps de préstamos fraudulentas que piden acceso a tus contactos y fotos, y saber qué hacer si ya caíste.

**Para empezar:** Beto pidió 2,000 en una app que le depositó en minutos. A la semana le exigían 4,500 y empezaron a escribir a sus contactos diciendo que era un ladrón. En esta lección sabrás cómo evitarlas y qué hacer si ya pasó.

### Lo esencial (5 minutos)

#### Cómo operan

Las apps montadeudas prestan rápido, pero cobran mucho más de lo acordado. Al instalarlas piden acceso a tus contactos y fotos. Si no pagas lo que exigen, amenazan y exhiben.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Piden tus contactos y fotos | Para extorsionarte. | No la instales. |
| Plazos de 7 días | Con cobros que suben. | Trampa. |
| No aparece en el SIPRES | No es institución. | Fraude. |
| Te depositan menos | Y te cobran de más. | Engaño. |

#### No pagues la extorsión

Pagar no detiene la extorsión; la alimenta. La CONDUSEF recomienda no pagar a apps fraudulentas y denunciar.



#### Un caso en un minuto

Beto dejó de pagar lo que le exigían, avisó a sus contactos que no respondieran y denunció. Desinstaló la app y quitó los permisos. Las amenazas bajaron con el tiempo.

> **Idea clave:** si una app de préstamos pide tus contactos y fotos, no la instales; si ya caíste, no pagues la extorsión y denuncia.



#### Comprueba lo que entendiste

1. ¿Por qué piden tus contactos?
*Respuesta:* Para extorsionarte si no pagas lo que exigen.

2. ¿Pagar detiene la extorsión?
*Respuesta:* No, la alimenta.


#### Para recordar

- Contactos y fotos = alerta.
- Verifica en el SIPRES.
- No pagues la extorsión: denuncia.



### Profundiza (5 minutos más)

#### Si ya caíste

1. No pagues lo que exigen de más.
2. Avisa a tus contactos que no respondan.
3. Guarda capturas de amenazas.
4. Denuncia ante la fiscalía y reporta a la CONDUSEF y al 088.
5. Desinstala la app y quita los permisos.



#### Antes de pedir

Busca el nombre de la empresa en el SIPRES. Revisa qué permisos pide la app antes de instalarla. Si pide contactos o fotos, no la uses.



#### Casos


**Caso 1. Los 4,500 de Beto**

La app le exige a Beto 4,500 por 2,000 y escribe a sus contactos.
- *¿Qué hace?* No paga la extorsión, avisa a sus contactos y denuncia.


**Caso 2. La app de Karla**

Karla quiere instalar una app de préstamos que pide acceso a sus contactos.
- *¿Qué hace?* No la instala y verifica la empresa en el SIPRES.


**Caso 3. El compañero de Don Chuy**

Un compañero de Don Chuy está desesperado por las amenazas de una app.
- *¿Qué hace?* Le explica que no pague más y lo acompaña a denunciar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar permisos de contactos | Extorsión | No instales |
| Pagar lo que exigen | Piden más | No pagues |
| Callar | Te sientes solo | Avisa y denuncia |
| No verificar | Fraude | SIPRES |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Una app de préstamos pide acceso a tus contactos. ¿Qué haces? a) La instalas si el préstamo es chico · b) No la instalas · c) Le das acceso solo un día
2. Te extorsionan por una app. ¿Qué recomienda la CONDUSEF? a) No pagar y denunciar · b) Pagar para que se detengan · c) Pedir otro préstamo
3. ¿Dónde verificas a una financiera? a) En las reseñas de la tienda de apps · b) En el SIPRES · c) Con amigos
**Respuestas:** 1-b: los contactos son para extorsionarte. 2-a: pagar la alimenta. 3-b: el registro oficial.



#### Ponlo en práctica

Escribe los cinco pasos si ya caíste en una app montadeudas.
**Respuesta:** No pagar lo que exigen de más, avisar a contactos, guardar capturas, denunciar y reportar, y desinstalar la app quitando permisos.



#### A tu plan

Revisa los permisos de las apps de tu celular y quita el acceso a contactos a las que no lo necesitan.



### Para saber más

- **Apps fraudulentas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «montadeudas» y SIPRES.

### Palabras clave

- *Montadeudas:* apps de préstamos que cobran de más y extorsionan usando tus contactos y fotos.
- *Permisos:* accesos que das a una app en tu celular.

### Fuentes

CONDUSEF · medios nacionales, consultados el 29 de septiembre de 2026.

---

## M6 U03. Extorsión telefónica

**Lo que lograrás:** Reconocer la extorsión telefónica y el secuestro virtual, y actuar: colgar, localizar a tu familiar y denunciar.

**Para empezar:** Karla recibió una llamada en su turno: una voz de niña llorando y un hombre que decía tener a su hija. Pedía 20,000 y que no colgara. Su hija estaba en la escuela. En esta lección sabrás qué hacer en esos minutos.

### Lo esencial (5 minutos)

#### Qué es

En la extorsión telefónica te asustan para que pagues rápido. En el secuestro virtual nadie está secuestrado: te hacen creer que sí.



#### Qué hacer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuelga | Aunque te digan que no. | Es para que no verifiques. |
| Localiza | Llama a tu familiar o a su escuela. | Por otro medio. |
| Palabra clave | Una que solo tu familia conozca. | Tu defensa. |
| Denuncia | 089 o 911. | No es tu culpa. |

#### Un caso en un minuto

Karla colgó y llamó a la escuela. Su hija estaba bien. Denunció al 089 y acordó con su familia una palabra clave.

> **Idea clave:** cuelga, localiza a tu familiar por otro medio y denuncia; nunca pagues por miedo.



#### Comprueba lo que entendiste

1. ¿Por qué te piden que no cuelgues?
*Respuesta:* Para que no puedas localizar a tu familiar.

2. ¿A dónde denuncias?
*Respuesta:* Al 089 o al 911.


#### Para recordar

- Cuelga.
- Localiza a tu familiar.
- Palabra clave y denuncia.



### Profundiza (5 minutos más)

#### Cuida lo que publicas

No publiques en redes horarios, escuelas ni ubicaciones de tu familia. Menos información, menos material para un engaño.



#### En tu trabajo

Si te llaman al teléfono de tu caseta o de tu trabajo con amenazas, avisa a tu supervisor y sigue los protocolos de tu empresa.



#### Casos


**Caso 1. La llamada a Karla**

Le dicen a Karla que tienen a su hija y que no cuelgue.
- *¿Qué hace?* Cuelga y llama a la escuela para localizar a su hija.


**Caso 2. La palabra de Ramiro**

Ramiro quiere proteger a su familia de estas llamadas.
- *¿Qué hace?* Acuerda una palabra clave con su familia.


**Caso 3. Las fotos de Beto**

Beto publica en redes dónde trabaja y a qué hora sale.
- *¿Qué hace?* Deja de publicar horarios y ubicaciones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No colgar | Te mantienen asustado | Cuelga |
| Pagar | Piden más | Localiza primero |
| Publicar horarios | Material para el engaño | Privacidad |
| Callar | Siguen llamando | Denuncia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Ramiro y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te dicen que tienen a tu familiar y que no cuelgues. ¿Qué haces? a) Cuelgas y lo localizas · b) Pagas rápido para que no le pase nada · c) Negocias sin colgar
2. ¿Para qué sirve la palabra clave? a) Para tu banco · b) Para confirmar que de verdad es tu familiar · c) Para tu celular
3. ¿A dónde denuncias una extorsión? a) A la CONDUSEF · b) A tu banco · c) Al 089 o al 911
**Respuestas:** 1-a: localizar primero. 2-b: quien no la sabe, no es tu familiar. 3-c: son los números de denuncia y emergencia.



#### Ponlo en práctica

Escribe tu plan de tres minutos: a quién llamas primero y qué números usas.
**Respuesta:** Por ejemplo: cuelgo; llamo a mi hija y a su escuela; si está bien, denuncio al 089.



#### A tu plan

Acuerda hoy una palabra clave con tu familia.



### Para saber más

- **Denuncia anónima 089** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «089».

### Palabras clave

- *Extorsión telefónica:* amenaza por teléfono para que pagues, muchas veces fingiendo tener a un familiar.
- *Secuestro virtual:* engaño en el que fingen tener a un familiar sin que sea cierto.

### Fuentes

Gobierno de México, consultado el 29 de septiembre de 2026.

---

## M6 U04. Si ya te pasó: qué hacer

**Lo que lograrás:** Seguir en orden los pasos si ya fuiste víctima de un fraude: bloquear, reclamar con folio, acudir a la CONDUSEF, reportar y denunciar.

**Para empezar:** Don Chuy dio su NIP a alguien que se hizo pasar por el banco. Esa madrugada le sacaron 3,000. Le dio vergüenza y pensó en no decir nada. En esta lección verás qué hacer rápido.

### Lo esencial (5 minutos)

#### Tu plan en orden

1. Bloquea tu tarjeta desde la app o el número de atrás de la tarjeta.
2. Cambia tu NIP y contraseñas.
3. Reclama por escrito en tu banco y guarda el folio.
4. Si no te resuelven, ve a la CONDUSEF.
5. Reporta al 088 y denuncia.



#### Rápido

Mientras más rápido bloquees, menos te pueden sacar. No esperes al estado de cuenta.



#### Sin vergüenza

Los fraudes los hacen profesionales. Contarlo te protege y protege a tus compañeros.



#### Un caso en un minuto

Don Chuy bloqueó su tarjeta en cuanto vio el cargo, reclamó con folio y denunció. Avisó en su turno para que nadie más cayera.

> **Idea clave:** bloquea, reclama con folio, CONDUSEF, 088 y denuncia; sin vergüenza.



#### Comprueba lo que entendiste

1. ¿Qué haces primero?
*Respuesta:* Bloquear la tarjeta.

2. ¿Qué guardas al reclamar?
*Respuesta:* El folio.


#### Para recordar

- Bloquea.
- Reclama con folio.
- CONDUSEF, 088 y denuncia.



### Profundiza (5 minutos más)

#### Tu hoja de emergencia

| Qué | Teléfono |
|---|---|
| Mi banco (atrás de la tarjeta) | |
| CONDUSEF | 55 5340 0999 u 800 999 8080 |
| Delitos en línea | 088 |
| Emergencias | 911 |



#### Evidencia

Guarda capturas, números, fechas y montos. Ayudan a tu reclamación.



#### Casos


**Caso 1. Los 3,000 de Don Chuy**

A Don Chuy le sacaron 3,000 después de dar su NIP.
- *¿Qué hace?* Bloquea la tarjeta, reclama con folio y denuncia.


**Caso 2. La espera de Karla**

Karla vio un cargo raro y quiere esperar al estado de cuenta.
- *¿Qué hace?* Reclama de inmediato, sin esperar.


**Caso 3. La vergüenza de Beto**

A Beto le da vergüenza contar que cayó en un fraude.
- *¿Qué hace?* Lo cuenta y sigue su plan: no es su culpa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar | Te sacan más | Bloquea ya |
| Sin folio | Sin prueba | Pide folio |
| Callar | Otros caen | Cuéntalo |
| Sin evidencia | Reclamación débil | Guarda capturas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Ves un cargo que no hiciste. ¿Qué haces primero? a) Bloqueas la tarjeta · b) Esperas al estado de cuenta · c) Llamas al número del mensaje
2. ¿A dónde reportas delitos en línea? a) Al 088 · b) Al 070 · c) A tu jefe
3. ¿Qué guardas como evidencia? a) Solo tu estado de cuenta del mes · b) Capturas, fechas, montos y folios · c) Nada
**Respuestas:** 1-a: frena el daño. 2-a: recibe delitos en línea. 3-b: ayudan a reclamar.



#### Ponlo en práctica

Llena tu hoja de emergencia con el número de tu banco.
**Respuesta:** Por ejemplo: banco (número de atrás de la tarjeta), CONDUSEF, 088 y 911.



#### A tu plan

Guarda tu hoja de emergencia en una foto en tu celular.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** reclamación y fraudes.

### Palabras clave

- *Evidencia:* pruebas de lo que pasó.
- *Denuncia:* aviso formal de un delito ante la autoridad.

### Fuentes

CONDUSEF · Guardia Nacional, consultados el 29 de septiembre de 2026.

---

## M6 U05. Tu identidad y que dejen de llamarte

**Lo que lograrás:** Cuidar tu INE, CURP y firma, detectar créditos o líneas de celular a tu nombre, activar el bloqueo en Buró de Crédito y dar de alta tus números en el REPEP y el REUS.

**Para empezar:** A Beto le llegó una llamada de cobranza por un crédito de 8,000 pesos que nunca pidió. Hace meses dejó copia de su INE en tres agencias de seguridad cuando buscaba trabajo. Además, entre turno y turno le llaman diario para ofrecerle préstamos. En esta lección verás cómo protegerte de las dos cosas.

### Lo esencial (5 minutos)

#### Qué es el robo de identidad

El robo de identidad pasa cuando alguien usa tu INE, tu CURP o tu firma para pedir créditos, abrir cuentas o contratar celulares. Casi siempre te enteras tarde: por una llamada de cobranza o al pedir un crédito.



#### Cómo te proteges

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Copias con leyenda | Escribe sobre la copia de tu INE para qué es y la fecha. | Así no sirve para otra cosa. |
| Reporte de crédito | Sin costo una vez al año en Buró y en Círculo. | Revisa que todo sea tuyo. |
| Bloqueo en Buró | Nadie consulta tu historial sin ti. | Frena créditos a tu nombre. |
| Líneas con tu CURP | Consulta qué celulares están a tu nombre. | Sin costo. |

> **Dato vigente:** en 2026 cada línea de celular se vincula con la CURP de su titular, con plazo final el 31 de diciembre de 2026; consultar qué líneas están a tu nombre y desvincular las que no son tuyas no tiene costo en portal.crt.gob.mx. Consultado el 29 de septiembre de 2026 a través de la Comisión Reguladora de Telecomunicaciones.

#### Que dejen de llamarte

Hay dos registros sin costo. En el REPEP de Profeco inscribes tu celular para que las empresas no te ofrezcan productos. En el REUS de CONDUSEF lo inscribes para que bancos y financieras no te llamen con ofertas.

> **Dato vigente:** REPEP: sin costo, fijo o celular, en repep.profeco.gob.mx o al 55 5568 8722 u 800 468 8722; en 30 días deben dejar de llamarte; no vence. REUS: sin costo, surte efecto en hasta 45 días y dura dos años; 55 5340 0999 u 800 999 8080. Consultado el 29 de septiembre de 2026 a través de Profeco y la CONDUSEF.



#### Un caso en un minuto

Beto pidió su reporte sin costo y encontró el crédito que no pidió. Reclamó por escrito a la financiera y al Buró, presentó denuncia y activó el bloqueo. Luego inscribió su celular en el REPEP y el REUS. Las llamadas bajaron en un mes.

> **Idea clave:** revisa tu reporte cada año, marca tus copias de INE y registra tu número en el REPEP y el REUS; si una llamada sigue después, casi seguro es fraude.



#### Comprueba lo que entendiste

1. ¿Cómo te enteras si alguien pidió un crédito a tu nombre?
*Respuesta:* Revisando tu reporte de crédito sin costo en Buró y en Círculo.

2. ¿Qué registro usas para que bancos y financieras no te llamen con ofertas?
*Respuesta:* El REUS de la CONDUSEF.


#### Para recordar

- Copias de INE con leyenda.
- Reporte sin costo cada año.
- REPEP y REUS sin costo.



### Profundiza (5 minutos más)

#### Si ya usaron tus datos

1. Pide tu reporte de crédito y ubica lo que no reconoces.
2. Reclama por escrito a la empresa que dio el crédito y guarda el folio.
3. Presenta una reclamación ante el Buró o Círculo.
4. Presenta denuncia ante la fiscalía y guarda la copia.
5. Activa el bloqueo y acude a la CONDUSEF si no te resuelven.



#### Lo que no cubren los registros

El REPEP y el REUS no frenan la cobranza de deudas reales, las llamadas de partidos, encuestas o beneficencia, ni los fraudes: quien estafa no respeta registros. Si alguien te llama «del banco» después de registrarte, cuelga y llama tú al número de tu tarjeta.



#### Tus datos al buscar trabajo

Entrega copias solo a empresas que puedas verificar, nunca fotos de tu INE por WhatsApp a reclutadores desconocidos, y pregunta para qué usarán tus datos. Si una «agencia» te pide pagar o dar datos bancarios antes de contratarte, es fraude.

> **Antes de actuar, verifica:** los números oficiales del REPEP, del REUS y de Buró de Crédito en sus sitios oficiales; hay páginas falsas que cobran por inscribirte.



#### Casos


**Caso 1. El crédito de Beto**

Beto recibe una llamada de cobranza por un crédito que no pidió.
- *¿Qué hace?* Pide su reporte, reclama por escrito, denuncia y activa el bloqueo.


**Caso 2. Las llamadas de Karla**

A Karla le llaman diario de bancos y tiendas para ofrecerle créditos.
- *¿Qué hace?* Inscribe su celular en el REPEP y el REUS.


**Caso 3. El reclutador de Don Chuy**

Un reclutador pide a Don Chuy foto de su INE por WhatsApp y 300 pesos para «apartar la vacante».
- *¿Qué hace?* No manda nada ni paga; verifica la empresa por su cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Copias sin leyenda | Las usan para créditos | Escribe para qué es |
| Nunca revisar tu reporte | Te enteras tarde | Sin costo cada año |
| Pagar por inscribirte | Fraude | REPEP y REUS no tienen costo |
| Creer que el registro frena fraudes | Caes | Cuelga y verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta inscribirte en el REPEP? a) Nada · b) 150 pesos al año · c) Lo que cobre tu compañía de celular
2. ¿Qué haces con la copia de tu INE que entregas? a) La entregas limpia para que no la rechacen · b) Le escribes para qué es y la fecha · c) Mandas mejor una foto por WhatsApp
3. Después de registrarte en el REUS, te llama alguien «del banco» pidiendo un código. ¿Qué es? a) Una llamada normal del banco · b) Un error del registro · c) Casi seguro un fraude: cuelga y llama tú
**Respuestas:** 1-a: no tiene costo. 2-b: así no sirve para otra cosa. 3-c: los registros no frenan fraudes.



#### Ponlo en práctica

Te inscribes en el REPEP el 1 de octubre. ¿A partir de qué fecha, más o menos, deben dejar de llamarte con publicidad?
**Respuesta:** En 30 días: hacia el 31 de octubre.



#### A tu plan

Esta semana inscribe tu celular en el REPEP y el REUS y pide tu reporte de crédito sin costo.



### Para saber más

- **REPEP** (Profeco · español): https://repep.profeco.gob.mx — **Qué buscar:** «inscribir número».
- **REUS** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REUS».
- **Reporte de crédito y bloqueo** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** reporte sin costo y «Bloqueo Buró».
- **Líneas con tu CURP** (Comisión Reguladora de Telecomunicaciones · español): https://portal.crt.gob.mx.

### Palabras clave

- *Robo de identidad:* uso de tus datos para hacerse pasar por ti y pedir créditos o hacer trámites.
- *REPEP:* Registro Público para Evitar Publicidad de Profeco: para que las empresas no te llamen ni te manden mensajes con publicidad.
- *REUS:* Registro Público de Usuarios de CONDUSEF: para que bancos y financieras no te llamen con publicidad.
- *Bloqueo en Buró:* servicio para que nadie consulte tu historial de crédito sin tu autorización.

### Fuentes

Profeco · CONDUSEF · Buró de Crédito · Comisión Reguladora de Telecomunicaciones, consultados el 29 de septiembre de 2026.

---

## M6 U06. Voces y videos falsos con inteligencia artificial

**Lo que lograrás:** Reconocer los fraudes que usan voces o videos falsos hechos con inteligencia artificial y protegerte con una palabra clave familiar.

**Para empezar:** A Don Chuy le llegó un audio con la voz de su hijo: «Papá, choqué, deposítame 8,000 ya». Sonaba igualito. Pero su hijo estaba en clase. En esta lección verás cómo funcionan estos fraudes.

### Lo esencial (5 minutos)

#### Qué es una voz clonada

Con unos segundos de tu voz tomados de redes sociales o de una llamada, la inteligencia artificial puede imitar a un familiar pidiendo dinero con urgencia. También hay videos falsos de artistas o políticos que «recomiendan» inversiones.



#### Cómo te protegen

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Palabra clave familiar | Solo la familia la conoce. | Si no la dice, no es. |
| Cuelga y llama tú | Al número que tienes guardado. | Confirma por otro medio. |
| Urgencia | «Deposita ya, no le digas a nadie». | Señal de fraude. |
| Famoso que ofrece inversión | Video falso. | No es real. |

#### Un caso en un minuto

Don Chuy colgó y marcó al celular de su hijo, que contestó desde la escuela. Esa noche la familia acordó una palabra clave para emergencias. Don Chuy también puso privadas sus redes.

> **Idea clave:** si una voz conocida te pide dinero con urgencia, cuelga y llama tú; si no dice la palabra clave, no es tu familiar.



#### Comprueba lo que entendiste

1. ¿Qué haces si una voz conocida te pide dinero urgente?
*Respuesta:* Cuelgas y llamas tú al número que tienes guardado.

2. ¿Para qué sirve la palabra clave familiar?
*Respuesta:* Para confirmar que de verdad es tu familiar.


#### Para recordar

- La voz puede ser falsa.
- Palabra clave familiar.
- Cuelga y llama tú.



### Profundiza (5 minutos más)

#### Menos voz y datos en redes

Pon privadas tus redes, evita publicar audios y videos con tu voz y la de tus hijos, y no digas en redes dónde trabajas ni tus horarios de turno. Entre menos datos, menos creíble es el engaño.



#### En el trabajo

También imitan a jefes o supervisores pidiendo transferencias o datos de acceso. Si te piden algo fuera de lo normal, confirma en persona o por el canal oficial de tu empresa.

> **Antes de actuar, verifica:** cualquier pedido de dinero por otro medio, aunque la voz o la cara sean conocidas.



#### Casos


**Caso 1. El audio de Don Chuy**

Llega un audio con la voz del hijo de Don Chuy pidiendo 8,000 urgentes.
- *¿Qué hace?* Cuelga y llama al celular de su hijo antes de depositar.


**Caso 2. El video de Beto**

Beto ve un video de un futbolista famoso recomendando una inversión que «duplica» el dinero.
- *¿Qué hace?* No invierte: es un video falso y un fraude.


**Caso 3. El supervisor de Ramiro**

Una llamada con la voz del jefe de Ramiro le pide los códigos del sistema de acceso.
- *¿Qué hace?* No los da y confirma en persona por el canal oficial.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confiar en la voz | Depositas | Llama tú |
| Sin palabra clave | No puedes confirmar | Acuérdala |
| Creer videos de famosos | Pierdes todo | Es falso |
| Redes abiertas | Más material para copiar | Privadas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Beto y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te llega un audio con la voz de tu hija pidiendo dinero urgente. ¿Qué haces? a) Depositas: es su voz · b) Cuelgas y la llamas tú al número guardado · c) Respondes el audio pidiendo el número de cuenta
2. ¿Para qué sirve una palabra clave familiar? a) Para confirmar que es tu familiar de verdad · b) Para entrar al banco · c) Para desbloquear el celular
3. Un famoso recomienda en video una inversión que duplica tu dinero. ¿Qué es? a) Una oportunidad real · b) Una inversión segura del gobierno · c) Casi seguro un video falso y un fraude
**Respuestas:** 1-b: confirma por otro medio. 2-a: si no la dice, no es. 3-c: nadie duplica dinero.



#### Ponlo en práctica

Si el audio te pide 8,000 y cada colgada y llamada te toma un minuto, ¿qué es más caro: un minuto o 8,000 pesos?
**Respuesta:** Un minuto para confirmar siempre sale más barato.



#### A tu plan

Hoy acuerda una palabra clave con tu familia y pon privadas tus redes.



### Para saber más

- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes con inteligencia artificial».
- **Denuncia** (Guardia Nacional · español): 088.

### Palabras clave

- *Inteligencia artificial:* programas que imitan voces, caras o textos de forma muy realista.
- *Voz clonada:* imitación de la voz de una persona hecha por computadora.
- *Palabra clave familiar:* palabra secreta que solo tu familia conoce para confirmar emergencias.

### Fuentes

CONDUSEF · Guardia Nacional, consultados el 29 de septiembre de 2026.

---


# Parte 7. Módulo 7. Tu familia y los imprevistos

## M7 U01. Tu fondo de emergencia, de poco a poco

**Lo que lograrás:** Empezar un fondo de emergencia con metas pequeñas y guardarlo donde esté seguro y disponible.

**Para empezar:** A Karla se le descompuso el refrigerador y no tenía ni 500 pesos. Pidió prestado en una app y terminó pagando el doble. En esta lección empezarás tu fondo, aunque sea de a poco.

### Lo esencial (5 minutos)

#### Qué es

Tu fondo de emergencia es dinero apartado solo para imprevistos: una enfermedad, una reparación, un día sin trabajo. Con él no tienes que pedir prestado caro.



#### Metas por etapas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Meta 1 | 1,000 pesos. | Para lo más urgente. |
| Meta 2 | Un mes de gastos. | Más tranquilidad. |
| Meta 3 | Tres meses de gastos. | Protección real. |
| Dónde | Cuenta aparte, protegida. | Disponible pronto. |

#### La primera meta de Karla

- Por quincena: **100**
- Quincenas: **10**
- Su primera meta: **1,000**
En cinco meses tendrá su primer colchón.


#### Un caso en un minuto

Karla aparta 100 cada quincena. Cuando su hija se enfermó, pagó la consulta con su fondo sin pedir prestado.

> **Idea clave:** empieza con 1,000 pesos; tu fondo te evita préstamos caros.



#### Comprueba lo que entendiste

1. ¿Para qué es tu fondo de emergencia?
*Respuesta:* Solo para imprevistos.

2. ¿Cuál es una buena primera meta?
*Respuesta:* 1,000 pesos.


#### Para recordar

- Primera meta: 1,000.
- Cuenta aparte.
- Solo para imprevistos.



### Profundiza (5 minutos más)

#### Si lo usas

Si lo usas, vuelve a llenarlo antes de otros gastos. Es tu primera protección.



#### Dónde no

No lo pongas en una tanda ni lo prestes. Debe estar disponible cuando lo necesites.



#### Casos


**Caso 1. El refrigerador de Karla**

Karla no tenía ahorro y pidió en una app.
- *¿Qué hace ahora?* Aparta 100 por quincena para su fondo.


**Caso 2. El préstamo del compañero de Ramiro**

Un compañero le pide a Ramiro prestado su fondo.
- *¿Qué hace?* No presta su fondo de emergencia.


**Caso 3. La tanda de Beto**

Beto quiere meter su fondo en una tanda.
- *¿Qué hace?* Lo deja en una cuenta aparte, disponible.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener nada | Préstamos caros | Empieza con poco |
| Prestarlo | No está cuando lo necesitas | Solo para ti |
| En la tanda | No disponible | Cuenta aparte |
| No reponerlo | Sin protección | Llénalo primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Ramiro y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde guardas tu fondo? a) En una tanda con tus compañeros · b) En una cuenta aparte · c) Prestado a un amigo
2. Apartas 150 por quincena. ¿En cuántas quincenas juntas 1,500? a) 10 · b) 15 · c) 5
3. Usaste tu fondo. ¿Qué haces? a) Lo dejas así · b) Pides prestado para llenarlo · c) Lo repones antes de otros gastos
**Respuestas:** 1-b: seguro y disponible. 2-a: 1,500 entre 150. 3-c: es tu primera protección.



#### Ponlo en práctica

Tus gastos de un mes son 8,000. ¿Cuánto es un fondo de tres meses?
**Respuesta:** 24,000.



#### A tu plan

Define tu primera meta y cuánto apartarás cada quincena.



### Para saber más

- **Ahorro para emergencias** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Fondo de emergencia:* dinero apartado solo para imprevistos.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M7 U02. Tu salud y la de tu familia: estar preparado

**Lo que lograrás:** Prepararte para una emergencia de salud: saber a dónde ir, tener los documentos a la mano y apartar dinero para medicinas y consultas.

**Para empezar:** La hija de Ramiro se enfermó de madrugada. No sabían a qué clínica ir ni dónde estaban sus papeles. Gastaron de más en taxis y en una consulta privada. En esta lección prepararás tu plan de salud.

### Lo esencial (5 minutos)

#### Tu plan de salud

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| A dónde ir | Tu clínica o centro de salud, y un hospital cercano. | Anótalo. |
| Documentos | Identificación, CURP y carnet de citas. | En una carpeta. |
| Dinero para salud | Parte de tu fondo. | Medicinas y consultas. |
| Teléfonos | Emergencias 911 y tu clínica. | En tu celular. |

#### Antes de la emergencia

Averigua hoy cuál es tu clínica o centro de salud y el hospital más cercano, cómo llegar y su horario. En una emergencia no hay tiempo para buscar.



#### Un caso en un minuto

Ramiro anotó en su celular su clínica, el hospital cercano y los teléfonos. Guardó los documentos de su familia en una carpeta. Aparta parte de su fondo para medicinas.

> **Idea clave:** prepara hoy a dónde ir, tus documentos y un dinero para salud.



#### Comprueba lo que entendiste

1. ¿Cuándo averiguas a dónde ir?
*Respuesta:* Antes de la emergencia.

2. ¿Qué documentos preparas?
*Respuesta:* Identificación, CURP y carnet de citas.


#### Para recordar

- A dónde ir.
- Documentos listos.
- Dinero para salud.



### Profundiza (5 minutos más)

#### Medicinas

Pregunta por medicamentos genéricos: tienen la misma sustancia y suelen costar menos. Compara precios entre farmacias.



#### Cuida tu salud en el turno

Dormir poco y comer mal en turnos largos afecta tu salud. Revisiones sencillas (presión, azúcar) en tu centro de salud ayudan a prevenir gastos mayores.



#### Casos


**Caso 1. La madrugada de Ramiro**

Ramiro no sabía a dónde llevar a su hija de madrugada.
- *¿Qué hace ahora?* Anota su clínica y el hospital cercano, con teléfonos.


**Caso 2. La receta de Don Chuy**

Don Chuy gasta mucho en una medicina de marca.
- *¿Qué hace?* Pregunta por el genérico y compara precios.


**Caso 3. Los papeles de Karla**

Karla no encuentra el carnet de su hija cuando lo necesita.
- *¿Qué hace?* Guarda los documentos de su familia en una carpeta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Buscar en la emergencia | Gastas de más | Prepara hoy |
| Documentos perdidos | Retrasos | Carpeta |
| Solo marcas | Más caro | Genéricos |
| No revisarte | Gastos mayores | Revisiones |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Don Chuy y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo averiguas a dónde ir en una emergencia? a) Antes de que pase · b) Cuando pase · c) Nunca
2. ¿Qué es un medicamento genérico? a) Uno con la misma sustancia que suele costar menos · b) Uno de menor calidad y más barato · c) Uno sin receta
3. ¿Dónde guardas los documentos de tu familia? a) Sueltos en casa · b) En la cartera del turno · c) En una carpeta a la mano
**Respuestas:** 1-a: no hay tiempo en la emergencia. 2-a: misma sustancia. 3-c: los encuentras rápido.



#### Ponlo en práctica

Anota tu clínica, el hospital cercano y tres teléfonos de emergencia.
**Respuesta:** Por ejemplo: clínica (dirección), hospital (dirección), 911, clínica y un familiar.



#### A tu plan

Guarda en tu celular tu clínica, el hospital cercano y los teléfonos de emergencia.



### Para saber más

- **Salud** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** centros de salud de tu estado.

### Palabras clave

- *Medicamento genérico:* medicina con la misma sustancia que la de marca, que suele costar menos.

### Fuentes

Gobierno de México, consultado el 29 de septiembre de 2026.

---

## M7 U03. Seguro de vida, gastos funerarios y beneficiarios

**Lo que lograrás:** Conocer seguros de bajo costo para proteger a tu familia, y dejar claro quiénes son tus beneficiarios.

**Para empezar:** Don Chuy piensa: «si me pasa algo en el turno, ¿qué va a hacer mi familia?». Tiene tres hijos y nadie sabe qué seguros tiene. En esta lección verás cómo proteger a tu familia con poco.

### Lo esencial (5 minutos)

#### Protección de bajo costo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguro de vida | Paga a tu familia si faltas. | Algunos cuestan poco al mes. |
| Gastos funerarios | Cubre el funeral. | Evita deudas a tu familia. |
| Seguro de tu trabajo | Revisa si tu empresa tiene uno. | Pregunta en recursos humanos. |
| Beneficiarios | Quién recibe el pago. | Anótalos y avísales. |

#### Tus beneficiarios

Un beneficiario recibe el dinero si tú faltas. Revisa quiénes son en tus seguros y en tu cuenta, y díselo a tu familia.



#### Un caso en un minuto

Don Chuy preguntó en su trabajo y supo que tenía un seguro de vida. Revisó sus beneficiarios, contrató un seguro funerario barato con una aseguradora autorizada y le dijo a su esposa dónde están los papeles.

> **Idea clave:** con poco puedes proteger a tu familia; revisa tus seguros y deja claros tus beneficiarios.



#### Comprueba lo que entendiste

1. ¿Qué hace un beneficiario?
*Respuesta:* Recibe el dinero del seguro o la cuenta si faltas.

2. ¿Dónde preguntas si tienes seguro por tu trabajo?
*Respuesta:* En recursos humanos de tu empresa.


#### Para recordar

- Seguro de vida y funerario.
- Pregunta en tu trabajo.
- Beneficiarios claros.



### Profundiza (5 minutos más)

#### Aseguradora autorizada

Contrata solo con aseguradoras autorizadas; verifícalas en la CNSF. Desconfía de «planes» sin contrato ni póliza.



#### Que tu familia sepa

Guarda las pólizas en una carpeta y dile a tu familia dónde están y a quién llamar.



#### Casos


**Caso 1. La preocupación de Don Chuy**

Don Chuy no sabe qué pasaría con su familia si falta.
- *¿Qué hace?* Pregunta por el seguro de su trabajo y revisa sus beneficiarios.


**Caso 2. El plan de Karla**

A Karla le ofrecen un «plan funerario» sin contrato.
- *¿Qué hace?* Busca uno con póliza de una aseguradora autorizada.


**Caso 3. Los papeles de Ramiro**

La familia de Ramiro no sabe dónde están sus pólizas.
- *¿Qué hace?* Las guarda en una carpeta y avisa dónde están.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber qué tienes | Tu familia no cobra | Pregunta |
| Planes sin contrato | Fraude | Aseguradora autorizada |
| Beneficiarios viejos | Pago a quien no quieres | Actualiza |
| No avisar | Nadie busca | Díselo a tu familia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién recibe el dinero de tu seguro si faltas? a) Tus beneficiarios · b) La aseguradora · c) Tu jefe
2. Te ofrecen un plan funerario sin contrato. ¿Qué haces? a) Lo contratas porque es barato · b) Pagas solo el primer mes · c) Buscas uno con póliza de una aseguradora autorizada
3. ¿Dónde verificas una aseguradora? a) En la CNSF · b) En sus anuncios de redes · c) Con el vendedor
**Respuestas:** 1-a: por eso deben estar claros. 2-c: evita fraudes. 3-a: es la autoridad de seguros.



#### Ponlo en práctica

Anota tus seguros, sus beneficiarios y dónde guardas las pólizas.
**Respuesta:** Por ejemplo: seguro de vida del trabajo (beneficiaria mi esposa), seguro funerario (mis hijos); pólizas en la carpeta del ropero.



#### A tu plan

Pregunta en tu trabajo si tienes seguro de vida y revisa a tus beneficiarios.



### Para saber más

- **Aseguradoras autorizadas** (CNSF · español): https://www.gob.mx/cnsf — **Qué buscar:** aseguradoras autorizadas.
- **Seguros básicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguros básicos estandarizados».

### Palabras clave

- *Beneficiario:* persona que recibe el dinero de un seguro o una cuenta si tú faltas.
- *Póliza:* contrato de un seguro.

### Fuentes

CNSF · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U04. Si llega un desastre: sismo, inundación o incendio

**Lo que lograrás:** Preparar tus documentos, tu dinero y tu familia para un desastre, y saber qué hacer después para recuperarte sin caer en fraudes.

**Para empezar:** En la colonia de Ramiro se inundaron varias casas. Sus vecinos perdieron actas, la tarjeta del banco y el efectivo guardado. Ramiro se preguntó qué pasaría con su familia. En esta lección verás cómo prepararte.

### Lo esencial (5 minutos)

#### Tu mochila de emergencia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Copias de documentos | Actas, INE, CURP, escrituras o contrato de renta. | En bolsa contra agua. |
| Copia digital protegida | Fotos en tu correo o nube con contraseña. | Por si se pierde el papel. |
| Algo de efectivo | Para los primeros días. | Poco y en billetes chicos. |
| Contactos | Banco, aseguradora, familiares. | En papel también. |

#### Tu dinero en una emergencia

1. Ten tu fondo de emergencia en una cuenta, no todo en efectivo en casa (M7 U01).
2. Si tienes seguro de casa o de vida, guarda el número de póliza y el teléfono.
3. Toma fotos de tus cosas de valor: te sirven para reclamar.
4. Acuerda con tu familia un punto de reunión.



#### Un caso en un minuto

Ramiro armó una bolsa con copias de actas, INE y CURP, y guardó fotos de los documentos en su correo con contraseña. Su fondo está en una cuenta, con la tarjeta y la app. Si algo pasa, puede disponer de su dinero desde cualquier cajero.

> **Idea clave:** documentos a salvo, dinero en una cuenta y un plan familiar: así te recuperas más rápido.



#### Comprueba lo que entendiste

1. ¿Por qué guardar el fondo en una cuenta y no en efectivo en casa?
*Respuesta:* Porque en un desastre el efectivo se puede perder; la cuenta la usas desde la app o un cajero.

2. ¿Para qué sirven las fotos de tus cosas?
*Respuesta:* Para reclamar al seguro o pedir apoyos.


#### Para recordar

- Documentos en bolsa contra agua.
- Copia digital protegida.
- Dinero en cuenta.



### Profundiza (5 minutos más)

#### Después del desastre

En emergencias grandes, los bancos suelen ofrecer programas para aplazar pagos: pregunta a tu banco por escrito y guarda el folio. Los apoyos del gobierno se piden solo en módulos oficiales y no tienen costo.



#### Fraudes después del desastre

Aparecen falsos gestores de apoyos, falsos albañiles que cobran por adelantado y colectas falsas. Nadie debe cobrarte por anotarte en un apoyo del gobierno.

> **Antes de actuar, verifica:** los apoyos en los sitios oficiales del gobierno y de Protección Civil; desconfía de quien cobra por «registrarte».



#### Casos


**Caso 1. La bolsa de Ramiro**

Ramiro guarda todos sus documentos originales en un cajón.
- *¿Qué hace?* Hace copias en bolsa contra agua y fotos protegidas en su correo.


**Caso 2. El gestor de Karla**

Después de una inundación, alguien le cobra a Karla 500 pesos por anotarla en un apoyo.
- *¿Qué hace?* No paga y acude al módulo oficial, donde no tiene costo.


**Caso 3. El préstamo de Don Chuy**

Tras el sismo, Don Chuy no puede pagar su crédito este mes.
- *¿Qué hace?* Pide por escrito a su banco un programa de aplazamiento y guarda el folio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo en papel en casa | Lo pierdes | Copias y digital |
| Todo en efectivo | Se pierde o se lo roban | Cuenta |
| Pagar gestores | Fraude | Apoyos sin costo |
| No avisar al banco | Recargos | Pide aplazamiento |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde guardas tu fondo de emergencia? a) Todo en efectivo en la casa · b) En una cuenta que puedas usar desde la app o el cajero · c) Con un vecino de confianza
2. Alguien te cobra por anotarte en un apoyo del gobierno. ¿Qué es? a) Un fraude: los apoyos no tienen costo · b) Un trámite normal · c) Una comisión del banco
3. ¿Qué te sirve para reclamar al seguro? a) Recordar lo que tenías · b) El testimonio de un vecino · c) Fotos de tus cosas y la póliza
**Respuestas:** 1-b: disponible aunque pierdas la casa. 2-a: nadie cobra. 3-c: prueba de lo perdido.



#### Ponlo en práctica

Quieres tener 300 pesos en efectivo en tu mochila y apartas 50 por quincena. ¿En cuántas quincenas lo juntas?
**Respuesta:** 6 quincenas: 3 meses.



#### A tu plan

Esta semana arma tu bolsa de documentos y guarda fotos protegidas de ellos.



### Para saber más

- **Plan familiar de protección civil** (Protección Civil · español): https://www.gob.mx/cenapred — **Qué buscar:** «plan familiar».
- **Seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de casa».

### Palabras clave

- *Mochila de emergencia:* bolsa con documentos, dinero y artículos básicos para salir rápido.
- *Aplazamiento de pagos:* permiso del banco para pagar después sin recargos en una emergencia.

### Fuentes

CENAPRED · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U05. Salud para tu familia: el seguro del IMSS que pagas tú

**Lo que lograrás:** Conocer el Seguro de Salud para la Familia del IMSS, que puedes pagar por tu cuenta para tus papás, tu pareja o tus hijos si no tienen seguridad social, y el IMSS-Bienestar como opción sin costo.

**Para empezar:** La mamá de Don Chuy tiene 67 años, diabetes y no tiene seguridad social. Cada mes él paga consultas y medicinas en farmacias privadas: unos 1,800 pesos. En esta lección verás otras opciones.

### Lo esencial (5 minutos)

#### Un seguro que pagas tú

El Seguro de Salud para la Familia del IMSS da consultas, hospital y medicinas a personas sin seguridad social. Se paga una cuota al año por cada persona que inscribes, según su edad.



#### Cuota anual por persona en 2026

| Edad | Cuota al año |
|---|---|
| 0 a 19 | 9,300 |
| 20 a 29 | 11,550 |
| 30 a 39 | 11,850 |
| 40 a 49 | 13,800 |
| 50 a 59 | 14,250 |
| 60 a 69 | 19,800 |
| 70 a 79 | 20,650 |
| 80 o más | 21,300 |

> **Dato vigente:** cuotas anuales del Seguro de Salud para la Familia (Modalidad 33) por persona según la edad, vigentes desde el 1 de marzo de 2026. Consultado el 30 de septiembre de 2026 a través de medios nacionales que citan las tablas del IMSS; confirma en el IMSS antes de pagar.



#### Lo que da y lo que no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sí da | Consultas, hospital y medicinas. | Para cada persona inscrita. |
| Periodos de espera | Algunas atenciones se cubren después de meses. | Pregunta cuáles. |
| Enfermedades previas | Algunas no se cubren al inicio. | Pregunta antes. |
| No da | Incapacidades ni pensión. | Solo salud. |

#### Si no alcanza: IMSS-Bienestar

Las personas sin seguridad social pueden atenderse sin costo en centros de salud y hospitales públicos: en muchos estados, con IMSS-Bienestar. Solo necesitan su CURP.



#### Un caso en un minuto

Don Chuy preguntó en el IMSS: por su mamá pagaría 19,800 al año, unos 1,650 al mes, menos de lo que gasta ahora. Antes de pagar confirmó si su diabetes se cubre desde el inicio. Mientras, la llevó a su centro de salud para su control.

> **Idea clave:** si alguien de tu familia no tiene seguridad social, puedes pagarle el Seguro de Salud para la Familia del IMSS por edad o llevarle al centro de salud sin costo; pregunta antes qué cubre y desde cuándo.



#### Comprueba lo que entendiste

1. ¿Qué da el Seguro de Salud para la Familia?
*Respuesta:* Consultas, hospital y medicinas.

2. ¿Qué preguntas antes de pagar?
*Respuesta:* Qué cubre, desde cuándo y si cubre enfermedades previas.


#### Para recordar

- Cuota al año por persona y edad.
- Solo salud.
- Centro de salud sin costo.



### Profundiza (5 minutos más)

#### Compara

| Opción | Costo | Qué da |
|---|---|---|
| Consultorio privado | Cada consulta | Rápido, pero caro si es seguido |
| Seguro de Salud para la Familia | Cuota al año | Médico, hospital y medicinas del IMSS |
| Centro de salud o IMSS-Bienestar | Sin costo | Atención para quien no tiene seguridad social |



#### Junta la cuota

Divide la cuota entre 24 quincenas y apártala como gasto fijo: 19,800 al año son 825 por quincena.



#### Casos


**Caso 1. La mamá de Don Chuy**

La mamá de Don Chuy no tiene seguridad social y él paga consultas privadas.
- *¿Qué hace?* Compara el seguro familiar del IMSS con lo que gasta y pregunta qué cubre.


**Caso 2. La hija de Karla**

La hija de Karla no tiene seguro y se enferma seguido.
- *¿Qué hace?* La lleva al centro de salud con su CURP o revisa la cuota del seguro familiar.


**Caso 3. El gestor de Beto**

Un gestor le ofrece a Beto «meter a su papá al IMSS» por 3,000.
- *¿Qué hace?* No paga: el trámite se hace directo en el IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar consultas privadas sin comparar | Gastas de más | Compara |
| No preguntar por enfermedades previas | Sorpresas | Pregunta |
| Pagar a gestores | Te cobran de más | Directo en el IMSS |
| Creer que sin IMSS no hay atención | No te atiendes | Centro de salud |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Karla y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta en 2026 el seguro familiar del IMSS para una persona de 65 años? a) 9,300 · b) 13,800 · c) 19,800
2. ¿Qué NO da el Seguro de Salud para la Familia? a) Pensión · b) Consultas · c) Medicinas
3. ¿Dónde se atiende sin costo quien no tiene seguridad social? a) En farmacias privadas · b) En el centro de salud · c) En cualquier hospital privado
**Respuestas:** 1-c: de 60 a 69 años. 2-a: solo es salud. 3-b: o IMSS-Bienestar.



#### Ponlo en práctica

Quieres inscribir a tu hijo de 10 años y a tu pareja de 35. ¿Cuánto pagas al año y por quincena?
**Respuesta:** 9,300 más 11,850: 21,150 al año; entre 24: unos 881 por quincena.



#### A tu plan

Anota quién en tu familia no tiene seguridad social y calcula su cuota.



### Para saber más

- **Seguro de Salud para la Familia** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «Seguro de Salud para la Familia».
- **IMSS-Bienestar** (Gobierno de México · español): https://www.gob.mx/imss-bienestar — **Qué buscar:** «unidades médicas».

### Palabras clave

- *Seguro de Salud para la Familia:* seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- *IMSS-Bienestar:* servicio de salud para personas sin seguridad social.

### Fuentes

IMSS · IMSS-Bienestar · medios nacionales que citan las cuotas 2026, consultados el 30 de septiembre de 2026.

---

## M7 U06. Que tu familia no quede atorada: beneficiarios y testamento

**Lo que lograrás:** Nombrar beneficiarios en tu cuenta, tu Afore, tus seguros y con tu empresa, y hacer tu testamento para que tu familia reciba lo tuyo sin juicios largos.

**Para empezar:** Un compañero de Ramiro falleció. Su cuenta, su Afore y los pagos pendientes de la empresa quedaron «atorados» un año. Su pareja vivía con él en unión libre y tuvo que ir a juicio. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Dónde nombrar beneficiarios

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta de banco | Tu nómina y tus ahorros. | Pídelo en tu banco. |
| Afore | En AforeMóvil o en tu Afore. | Actualízalos. |
| Seguros | Vida y funerarios. | En la póliza. |
| Con tu empresa | Quién recibe tus pagos pendientes. | La ley lo permite. |

#### Beneficiarios: rápido y sin juicio

Un beneficiario recibe tu dinero directo, sin juicio. En la Afore, la ley da primero el dinero a tus beneficiarios legales (pareja, hijos y, a falta de ellos, tus papás); las personas que tú nombras reciben si no hay beneficiarios legales.



#### Tu testamento

Un testamento evita juicios y peleas. En septiembre, Mes del Testamento, muchas notarías dan descuentos. Ahí nombras también a quien cuidaría a tus hijos menores.

> **Dato vigente:** en el Mes del Testamento 2026 hubo descuentos de hasta 50%, con testamentos desde unos 2,750 pesos según el estado. Consultado el 30 de septiembre de 2026 a través de la Secretaría de Gobernación y medios nacionales.



#### Un caso en un minuto

Ramiro nombró a su pareja y a sus hijos en su cuenta, su Afore y su seguro, y pidió a recursos humanos registrar a sus beneficiarios. En septiembre hizo su testamento y nombró a su hermana como tutora de sus hijos.

> **Idea clave:** nombra beneficiarios en tu cuenta, tu Afore, tus seguros y con tu empresa, y haz tu testamento; así tu familia recibe lo tuyo sin juicio.



#### Comprueba lo que entendiste

1. ¿Qué ventaja tiene nombrar beneficiarios?
*Respuesta:* Tu familia recibe el dinero sin juicio.

2. ¿Qué nombras en tu testamento además de tus bienes?
*Respuesta:* Quién cuidaría a tus hijos menores.


#### Para recordar

- Beneficiarios en todo.
- Testamento en septiembre.
- Tutor para tus hijos.



### Profundiza (5 minutos más)

#### Tu lista

| Dónde | ¿Tiene beneficiarios? | Quiénes y qué parte |
|---|---|---|
| Cuenta de nómina | | |
| Afore | | |
| Seguro de vida | | |
| Empresa | | |
| Testamento | | |



#### Si vives en unión libre

Tu pareja en unión libre puede heredar si cumple lo que pide la ley de tu estado, como tiempo viviendo juntos o hijos en común. Nombrarla como beneficiaria y en tu testamento lo deja claro.



#### Casos


**Caso 1. La cuenta de Don Chuy**

Don Chuy nunca nombró beneficiarios en su cuenta de nómina.
- *¿Qué hace?* Los nombra en su banco con nombres completos.


**Caso 2. La pareja de Ramiro**

Ramiro vive en unión libre y no tiene testamento.
- *¿Qué hace?* Hace su testamento y nombra a su pareja como beneficiaria.


**Caso 3. La hija de Karla**

Karla es mamá sola y le preocupa quién cuidaría a su hija.
- *¿Qué hace?* Nombra en su testamento a quien la cuidaría.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No nombrar a nadie | Juicio largo | Beneficiarios |
| Beneficiarios viejos | El dinero va a otra persona | Actualízalos |
| Sin testamento | Peleas | Hazlo en septiembre |
| Hijos sin tutor nombrado | Incertidumbre | Nómbralo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy, Ramiro y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si nombras beneficiarios en tu cuenta? a) Reciben el dinero sin juicio · b) Pagan más impuestos cuando lo reciben · c) No cambia nada
2. ¿Qué mes tiene descuentos para hacer testamento? a) Enero · b) Septiembre · c) Diciembre
3. ¿Qué puedes nombrar en tu testamento? a) Solo tu cuenta de banco y ninguna otra cosa más · b) Tu número de NIP · c) Quién cuidaría a tus hijos menores
**Respuestas:** 1-a: es lo más rápido. 2-b: Mes del Testamento. 3-c: un tutor.



#### Ponlo en práctica

Tienes 40,000 en tu Afore y nombras a tus dos hijos: 50% y 50%. ¿Cuánto recibiría cada uno?
**Respuesta:** 20,000 cada uno.



#### A tu plan

Llena tu lista y corrige esta semana los beneficiarios que falten.



### Para saber más

- **Beneficiarios en la Afore** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «designar beneficiarios».
- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento».

### Palabras clave

- *Beneficiario:* persona que nombras para recibir el dinero de una cuenta, Afore o seguro si faltas.
- *Testamento:* documento ante notario en el que dices quién recibe tus bienes y quién cuida a tus hijos menores.
- *Tutor:* persona que cuida a un menor de edad y sus intereses.

### Fuentes

CONSAR · CONDUSEF · Secretaría de Gobernación · Ley Federal del Trabajo (artículo 25), consultados el 30 de septiembre de 2026.

---

## M7 U07. Tu casa, tu tierra y lo que se hereda

**Lo que lograrás:** Poner en orden los papeles de tu casa o terreno (escrituras, tierra ejidal), saber qué pasa si no hay testamento y qué pasa con las deudas y los impuestos al heredar.

**Para empezar:** Don Chuy vive en la casa que era de sus papás, pero sigue a nombre de su papá, que ya falleció. Su hermano dice que para pasarla a su nombre «hay que pagar 30% de impuestos». En esta lección verás qué es cierto.

### Lo esencial (5 minutos)

#### Cada bien, su camino

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Casa con escrituras | Se hereda con testamento o juicio. | Revisa a nombre de quién. |
| Casa sin escrituras | En papel no hay qué heredar. | Primero regulariza. |
| Tierra ejidal | Se hereda con la lista de sucesión. | Registro Agrario Nacional. |
| Sin testamento | Juicio o trámite ante notario. | Más largo y caro. |

#### Impuestos y deudas al heredar

Recibir una herencia **no paga ISR** en México; si pasa de 500,000 pesos y presentas declaración anual, hay que informarla. Lo que sí cuesta es pasar la casa a tu nombre: impuesto estatal por adquirir el inmueble, notario y registro. Las deudas de quien fallece se pagan con lo que deja; la familia no las paga con su dinero, salvo quien firmó como aval u obligado solidario.

> **Dato vigente:** los ingresos por herencia están exentos de ISR (Ley del ISR, artículo 93, fracción XXII); quien presenta declaración anual debe informarlos si pasan de 500,000 pesos. Consultado el 30 de septiembre de 2026 a través del SAT y medios nacionales.



#### Un caso en un minuto

Don Chuy y su hermano preguntaron en una notaría: no pagan ISR por heredar; el trámite sucesorio, el impuesto estatal y el notario suman unos 25,000. Lo dividieron entre los dos y ahorran 500 por quincena cada uno para hacerlo este año.

> **Idea clave:** revisa a nombre de quién están tu casa y tu tierra; heredar no paga ISR, pero escriturar sí cuesta, y tu familia no paga tus deudas con su dinero salvo quien firmó como aval.



#### Comprueba lo que entendiste

1. ¿Se paga ISR por recibir una herencia en México?
*Respuesta:* No, está exenta.

2. ¿Cómo se heredan los derechos ejidales?
*Respuesta:* Con la lista de sucesión en el Registro Agrario Nacional.


#### Para recordar

- Revisa los papeles de la casa.
- Heredar no paga ISR; escriturar sí cuesta.
- Deudas: solo con lo que dejó, salvo el aval.



### Profundiza (5 minutos más)

#### Costos al pasar una casa a tu nombre

| Concepto | Quién lo cobra |
|---|---|
| Impuesto por adquirir el inmueble | Estado o municipio |
| Honorarios del notario | Notaría |
| Registro | Registro Público de la Propiedad |
| Avalúo | Perito |



#### La parcela del pueblo

Si alguien de tu familia tiene tierra ejidal, pregunta en el Registro Agrario Nacional si tiene lista de sucesión. Si no la hay, la ley decide el orden y puede haber pleitos.



#### Casos


**Caso 1. La casa de los papás de Don Chuy**

La casa sigue a nombre del papá de Don Chuy, que ya falleció.
- *¿Qué hace?* Pregunta en una notaría el trámite sucesorio y cuánto cuesta escriturar.


**Caso 2. El 30% del hermano**

El hermano de Don Chuy cree que hay que pagar 30% de ISR por heredar.
- *¿Qué aprende?* Que heredar no paga ISR; solo cuestan los gastos de escriturar.


**Caso 3. La deuda del papá de Karla**

Un despacho le cobra a Karla la tarjeta de su papá, que falleció.
- *¿Qué hace?* Revisa si firmó como aval; si no, no paga con su dinero.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar la casa a nombre de quien falleció | Problema para tus hijos | Escritura |
| Creer que heredar paga 30% | No escrituras | Pregunta en una notaría |
| Pagar deudas ajenas sin haber firmado | Pierdes tu dinero | Revisa |
| Parcela sin lista de sucesión | Pleitos | RAN |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chuy y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto ISR pagas por recibir una herencia? a) 30% · b) 10% · c) Nada, está exenta
2. ¿Quién paga las deudas de alguien que falleció si no alcanza lo que dejó? a) Nadie de la familia, salvo el aval · b) Sus hijos, con su propio dinero y sus ahorros · c) Sus vecinos
3. ¿Con qué se heredan los derechos de una parcela ejidal? a) Con un recibo de luz · b) Con la lista de sucesión · c) Con una carta escrita a mano por el ejidatario
**Respuestas:** 1-c: artículo 93 de la Ley del ISR. 2-a: se paga con lo que dejó. 3-b: se registra en el RAN.



#### Ponlo en práctica

Escriturar la casa cuesta 25,000 y lo dividen entre dos hermanos. Si cada uno aparta 500 por quincena, ¿en cuántas quincenas lo juntan?
**Respuesta:** 12,500 cada uno; entre 500: 25 quincenas, casi un año.



#### A tu plan

Revisa a nombre de quién están tu casa o tu terreno y anota qué papeles faltan.



### Para saber más

- **Herencias e impuestos** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «herencias» e «ingresos exentos».
- **Lista de sucesión** (Registro Agrario Nacional · español): https://www.gob.mx/ran — **Qué buscar:** «lista de sucesión».
- **Regularización de vivienda** (INSUS · español): https://www.gob.mx/insus — **Qué buscar:** «regularización».

### Palabras clave

- *Herencia:* bienes y derechos que recibe una persona cuando otra fallece.
- *Escriturar:* pasar legalmente una casa o terreno a tu nombre ante notario.
- *Lista de sucesión:* lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.

### Fuentes

Ley del ISR (artículo 93) · SAT · Registro Agrario Nacional · INSUS · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 8. Módulo 8. Tu futuro

## M8 U01. Ahorro para el retiro por tu cuenta

**Lo que lograrás:** Conocer las aportaciones voluntarias a la AFORE, desde 50 pesos en tiendas, para ahorrar para tu retiro por tu cuenta.

**Para empezar:** Ramiro tiene 36 años y piensa que el retiro «está lejos». Pero cada año que pasa sin ahorrar cuenta. Le dijeron que puede ahorrar en la AFORE desde 50 pesos en la tienda. En esta lección verás cómo.

### Lo esencial (5 minutos)

#### Tu AFORE

Una AFORE guarda e invierte dinero para tu retiro. Si ya tienes una, puedes sumarle ahorro voluntario. Si no sabes cuál es, la localizas con tu CURP en e-SAR.



#### Cómo aportar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En tiendas | Desde 50 pesos con tu CURP. | Pide tu comprobante. |
| En AforeMóvil | Desde tu celular. | Automático. |
| Cada quincena | Aunque sea poco. | Suma con los años. |
| Para después | Es para tu retiro. | No lo toques. |

> **Dato vigente:** puedes hacer aportaciones voluntarias a tu AFORE desde 50 pesos en tiendas participantes con tu CURP, o desde la app AforeMóvil. Consultado el 29 de septiembre de 2026 a través de la CONSAR.

#### 100 por quincena

- Por quincena: **100**
- Quincenas al año: **24**
- Al año, sin contar rendimiento: **2,400**
En 20 años serían 48,000 aportados, más lo que ganen.


#### Un caso en un minuto

Ramiro localizó su AFORE con su CURP y descargó AforeMóvil. Programó 100 pesos por quincena.

> **Idea clave:** con 50 o 100 pesos por quincena en tu AFORE, empiezas tu retiro hoy.



#### Comprueba lo que entendiste

1. ¿Desde cuánto puedes aportar en tiendas?
*Respuesta:* Desde 50 pesos.

2. ¿Qué necesitas en la tienda?
*Respuesta:* Tu CURP.


#### Para recordar

- Desde 50 pesos.
- Con tu CURP o AforeMóvil.
- Poco, pero cada quincena.



### Profundiza (5 minutos más)

#### Si no sabes tu AFORE

Entra a e-SAR o a AforeMóvil con tu CURP para saber en qué AFORE estás. Es sin costo. Si nunca has tenido AFORE, pregunta en e-SAR cómo registrarte.



#### Cuidado con gestores

Nadie debe cobrarte por localizar tu AFORE o hacer aportaciones. Si alguien te ofrece regalos por cambiarte de AFORE, compara primero en la CONSAR.



#### Casos


**Caso 1. El retiro de Ramiro**

Ramiro cree que el retiro está lejos y no ahorra.
- *¿Qué hace?* Empieza con aportaciones voluntarias pequeñas cada quincena.


**Caso 2. La AFORE de Karla**

Karla no sabe en qué AFORE está.
- *¿Qué hace?* La localiza sin costo con su CURP en e-SAR.


**Caso 3. El regalo de Don Chuy**

Un agente le ofrece a Don Chuy una despensa si se cambia de AFORE.
- *¿Qué hace?* Compara rendimientos en la CONSAR antes de decidir.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que falta mucho | Pierdes años | Empieza hoy |
| Pagar a gestores | Es sin costo | Hazlo tú |
| Cambiarte por regalos | Menos rendimiento | Compara |
| Tocar el ahorro | No llega al retiro | Es para después |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Karla y Don Chuy. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Desde cuánto puedes aportar a tu AFORE en tiendas? a) 50 pesos · b) 1,000 pesos · c) 500 pesos
2. ¿Cómo sabes en qué AFORE estás? a) Preguntas en tu trabajo o a un gestor que cobra poco · b) Con tu CURP en e-SAR · c) No se puede saber
3. Te ofrecen un regalo por cambiarte de AFORE. ¿Qué haces? a) Te cambias por el regalo · b) Aceptas y regresas luego · c) Comparas rendimientos primero
**Respuestas:** 1-a: desde 50. 2-b: no tiene costo. 3-c: el regalo no mejora tu retiro.



#### Ponlo en práctica

Aportas 50 por quincena. ¿Cuánto aportas en 10 años, sin rendimiento?
**Respuesta:** 50 por 24 son 1,200 al año; por 10: 12,000.



#### A tu plan

Localiza tu AFORE con tu CURP y decide cuánto aportarás cada quincena.



### Para saber más

- **e-SAR** (CONSAR · español): https://www.e-sar.com.mx — **Qué buscar:** localizar AFORE.
- **Ahorro voluntario** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** aportaciones voluntarias en tiendas.

### Palabras clave

- *AFORE:* administradora que guarda e invierte tu ahorro para el retiro.
- *Aportación voluntaria:* ahorro extra que haces tú en tu AFORE.

### Fuentes

CONSAR, consultado el 29 de septiembre de 2026.

---

## M8 U02. Un ingreso extra en tus días de descanso

**Lo que lograrás:** Evaluar un ingreso extra en tus días de descanso: cuánto ganas de verdad, qué costos tiene y cuidar tu descanso.

**Para empezar:** Ramiro quiere lavar autos en sus días libres. Piensa que ganará 2,000 a la semana, pero no ha contado jabón, agua, transporte ni el cansancio. En esta lección calcularás si le conviene.

### Lo esencial (5 minutos)

#### Ganancia, no venta

Lo que importa no es cuánto cobras, sino cuánto te **queda** después de los costos. Esa es tu ganancia.



#### Los autos de Ramiro

- Lo que cobra a la semana: **2,000**
- Jabón, agua, transporte: **600**
- Su ganancia: **1,400**
Por unas 16 horas de trabajo, son unos 87 pesos por hora.


#### Antes de empezar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Costos | Materiales, transporte, permisos. | Réstalos. |
| Tiempo | Cuántas horas. | Ganancia por hora. |
| Descanso | Los turnos de 24 horas cansan. | Tu salud primero. |
| Deudas para empezar | Mejor empieza con poco. | Sin préstamos caros. |

#### Un caso en un minuto

Ramiro calculó su ganancia y decidió trabajar solo un día de descanso a la semana para no agotarse. Aparta una parte de lo que gana para su fondo.

> **Idea clave:** calcula tu ganancia por hora, empieza sin deudas y cuida tu descanso.



#### Comprueba lo que entendiste

1. ¿Qué es la ganancia?
*Respuesta:* Lo que te queda después de pagar los costos.

2. ¿Por qué cuidar tu descanso?
*Respuesta:* Porque los turnos de 24 horas cansan y tu salud es lo primero.


#### Para recordar

- Ganancia, no venta.
- Por hora.
- Sin deudas y con descanso.



### Profundiza (5 minutos más)

#### Tu cálculo

| Concepto | A la semana |
|---|---|
| Lo que cobras | |
| Materiales | |
| Transporte | |
| Otros costos | |
| **Ganancia** | |
| Horas trabajadas | |
| **Ganancia por hora** | |



#### Siguiente paso

Si tu ingreso extra crece, el curso de emprendimiento te enseña a separar el dinero del negocio, poner precios y formalizarte.



#### Casos


**Caso 1. Los autos de Ramiro**

Ramiro cree que ganará 2,000 a la semana lavando autos.
- *¿Qué hace?* Resta sus costos y calcula su ganancia por hora.


**Caso 2. El préstamo de Beto**

Beto quiere pedir un préstamo caro para empezar a vender comida.
- *¿Qué hace?* Empieza con poco, sin préstamos caros.


**Caso 3. El cansancio de Karla**

Karla trabaja todos sus días de descanso y está agotada.
- *¿Qué hace?* Reduce los días de trabajo extra para cuidar su salud.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar solo lo que cobras | Crees ganar más | Resta costos |
| Empezar con deudas | Riesgo | Empieza con poco |
| No descansar | Tu salud sufre | Días libres |
| Gastar todo lo extra | No avanzas | Aparta una parte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Beto y Karla. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 1,500 a la semana y gastas 500 en materiales. ¿Cuál es tu ganancia? a) 1,000 · b) 1,500 · c) 2,000
2. ¿Cómo conviene empezar un ingreso extra? a) Con un préstamo grande para crecer rápido · b) Con poco, sin deudas caras · c) Con la tarjeta de un amigo
3. Ganas 1,200 en 15 horas. ¿Cuánto por hora? a) 1,200 · b) 120 · c) 80
**Respuestas:** 1-a: 1,500 menos 500. 2-b: menos riesgo. 3-c: 1,200 entre 15.



#### Ponlo en práctica

Vendes comida: cobras 1,800 a la semana, gastas 900 en ingredientes y 100 en transporte, y trabajas 10 horas. ¿Ganancia por hora?
**Respuesta:** 1,800 menos 1,000: 800; entre 10 horas: 80 por hora.



#### A tu plan

Si tienes o quieres un ingreso extra, llena la tabla con tus números.



### Para saber más

- **Emprender** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «negocio» y guías para emprender.

### Palabras clave

- *Ganancia:* lo que te queda después de pagar los costos.
- *Costo:* lo que gastas para poder vender.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026 · Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera».

---

## M8 U03. Tu plan de una página

**Lo que lograrás:** Reunir en una hoja tu presupuesto, tus deudas, tu ahorro, tu protección y tu retiro, con fechas para revisarlo.

**Para empezar:** Karla ya tiene su presupuesto, su lista de deudas, su fondo y su AFORE, pero en notas sueltas del celular. Quiere verlo todo junto. En esta lección harás tu plan de una página.

### Lo esencial (5 minutos)

#### Las cinco partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Quincena | Lo que te llega y tu presupuesto. | Módulo 1. |
| Deudas | Lista y orden para pagar. | Módulo 3. |
| Ahorro | Fondo y meta. | Módulos 4 y 7. |
| Protección y futuro | Seguros, beneficiarios, AFORE. | Módulos 6 a 8. |

#### Revisa cada quincena

Tu plan de una página se revisa rápido cada día de pago: ¿aparté mi ahorro? ¿pagué mis deudas a tiempo? ¿cuánto me falta?



#### Un caso en un minuto

Karla llenó su plan y le tomó una foto. Cada día de pago lo revisa en cinco minutos. En seis meses terminó una deuda y juntó su primer fondo.



#### Tu compromiso

Escribe una meta con nombre («fondo para la escuela de mi hija»), cuánto apartarás y cada cuándo. Díselo a alguien de confianza que te pregunte cómo vas. Aparta el ahorro el mismo día de pago, antes de gastar, y pon un recordatorio mensual en tu celular con el nombre de tu meta.

> **Idea clave:** tu plan en una hoja, revisado cada día de pago, te dice dónde estás y qué sigue; un compromiso con nombre, testigo y recordatorio te ayuda a cumplirlo.



#### Comprueba lo que entendiste

1. ¿Cada cuándo revisas tu plan?
*Respuesta:* Cada día de pago.

2. ¿Qué no va en tu plan?
*Respuesta:* Contraseñas, NIP ni números completos de cuenta.


#### Para recordar

- Cinco partes en una hoja.
- Meta con nombre, testigo y recordatorio.
- Sin datos sensibles.



### Profundiza (5 minutos más)

#### Tu plan

| Parte | Hoy | Siguiente paso |
|---|---|---|
| Lo que me llega | | |
| Ahorro por quincena | | |
| Deudas (total y la que pago primero) | | |
| Fondo de emergencia | | |
| Seguros y beneficiarios | | |
| AFORE | | |
| Mi compromiso: meta, monto, fecha y testigo | | |



#### Por qué funciona

Estudios en varios países encontraron que ponerle nombre a una meta, comprometerse con alguien y recibir un recordatorio mensual con esa meta ayuda a ahorrar más. Apartar el dinero de forma automática, antes de verlo, también ayuda: no tienes que decidir cada vez.



#### Celebra tus avances

Cada deuda terminada y cada meta de ahorro cuentan. Anótalas en tu plan.



#### Casos


**Caso 1. Las notas de Karla**

Karla tiene todo en notas sueltas del celular.
- *¿Qué hace?* Llena su plan de una página y le toma una foto.


**Caso 2. La revisión de Don Chuy**

Don Chuy hizo su plan pero nunca lo vuelve a ver.
- *¿Qué hace?* Lo revisa cinco minutos cada día de pago.


**Caso 3. El NIP de Beto**

Beto quiere anotar su NIP en su plan.
- *¿Qué hace?* No lo anota: el plan no lleva datos sensibles.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo suelto | No ves el conjunto | Una hoja |
| No revisarlo | Se olvida | Cada quincena |
| Datos sensibles | Riesgo | Sin NIP ni cuentas |
| No celebrar | Te desanimas | Anota avances |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Karla, Don Chuy y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cada cuándo revisas tu plan? a) Una vez al año, en diciembre · b) Cada día de pago · c) Nunca
2. ¿Qué va en tu plan? a) Tu NIP · b) Tus contraseñas · c) Tu presupuesto, deudas, ahorro, protección y AFORE
3. Terminaste una deuda. ¿Qué haces? a) Lo anotas y sumas ese pago a la siguiente · b) Pides otro crédito para celebrar · c) Nada
**Respuestas:** 1-b: cinco minutos cada quincena. 2-c: son sus partes. 3-a: así avanzas más rápido.



#### Ponlo en práctica

Llena tu plan con al menos un siguiente paso en cada parte.
**Respuesta:** Por ejemplo: apartar 150 por quincena; terminar el adelanto en dos meses; juntar 1,000 de fondo; revisar mi seguro del trabajo; aportar 50 a la AFORE.



#### A tu plan

Llena tu plan de una página y tómale una foto para revisarlo cada día de pago.



### Para saber más

- **Guías y herramientas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** herramientas de planeación.

### Palabras clave

- *Plan de una página:* resumen de tus decisiones de dinero en una sola hoja.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 9. Materiales de apoyo

## Bienvenida

**Tu Turno, Tu Dinero, Tu Futuro** es un programa de finanzas personales para guardias de seguridad y personas con turnos largos en México.

Aquí aprenderás a que tu quincena rinda, a usar una cuenta sin comisiones, a salir de deudas, a organizar tandas con reglas, a entender el Buró, a protegerte de fraudes y extorsiones, a cuidar a tu familia y a ahorrar para tu futuro.

Cada lección dura unos 5 minutos y está hecha para el celular: puedes tomarla en un descanso.

Versión 1.2 · Septiembre de 2026.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos |
| **¿Qué harías?** | Tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todo el módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 minutos |

### Los personajes

- **Don Chuy** (52): guardia en una plaza comercial; tiene tres deudas.
- **Karla** (29): guardia en un edificio de oficinas, mamá sola; organiza una tanda.
- **Ramiro** (36): supervisor de turno; quiere un ingreso extra y ahorrar para su retiro.
- **Beto** (23): guardia nuevo; cayó en una app de préstamos.

### Tres reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP ni montos reales de tus deudas.
2. **No te vendemos nada**, ni préstamos.
3. **Tu información es tuya.** Si tu empresa te ofrece el curso, no recibe datos personales ni financieros de nadie.

### Los datos cambian

Los datos del programa se consultaron el **29 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa la información vigente en la **CONDUSEF** o el sitio oficial de la institución.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay ocho insignias. Al aprobar las ocho autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. La quincena de Karla (Módulos 1 y 2)

**Datos.** A Karla le llegan 4,300 por quincena. Hace 15 turnos al mes y gasta 110 por turno en pasajes y comida. Los gastos de su casa son 5,600 al mes. Su cuenta le cobra 90 al mes de manejo.

**Tareas.**

1. ¿Cuánto le llega al mes?
2. ¿Cuánto gasta en turnos al mes?
3. ¿Cuánto le queda después de turnos y casa?
4. ¿Qué hace con la comisión de su cuenta?

**Clave.**

- 4,300 por 2: 8,600.
- 110 por 15: 1,650.
- 8,600 menos 1,650 menos 5,600: 1,350.
- Pide la cuenta básica sin comisiones: ahorra 1,080 al año.

### E2. Las deudas de Don Chuy (Módulos 3 y 4)

**Datos.** Don Chuy debe 7,200 a una tienda (360 por quincena), 1,380 de un adelanto (690 por quincena) y 3,000 a un conocido (sin fecha). También cobró primero en una tanda de 10 personas con 400 por quincena.

**Tareas.**

1. ¿Cuánto debe en total, sin la tanda?
2. ¿Cuánto debe de la tanda si ya pagó 2 quincenas?
3. ¿Qué deuda paga primero con la bola de nieve?
4. ¿Qué no debe hacer mientras sale?

**Clave.**

- 7,200 más 1,380 más 3,000: 11,580.
- Cobró 4,000; ya pagó 800; debe 7 pagos más de 400: 2,800.
- El adelanto (1,380).
- Pedir nuevos préstamos, incluidos los «gota a gota».

### E3. La app de Beto (Módulos 5 y 6)

**Datos.** Beto pidió 2,000 en una app que le pidió acceso a sus contactos. Ahora le exigen 4,500 y escriben a sus contactos. Además, cree que está «boletinado» en el Buró.

**Tareas.**

1. ¿Qué señales de alerta tenía la app?
2. ¿Qué hace ahora?
3. ¿Qué hace para saber si está en el Buró?
4. ¿Cómo mejora su historial?

**Clave.**

- Pedía contactos y fotos, cobraba de más y probablemente no está en el SIPRES.
- No paga la extorsión, avisa a sus contactos, guarda capturas, denuncia y reporta, y desinstala la app.
- Pide su reporte sin costo en el sitio oficial.
- Pagando a tiempo, usando poco su límite y sin pedir muchos créditos.

### E4. El futuro de Ramiro (Módulos 7 y 8)

**Datos.** Ramiro gasta 9,000 al mes. Quiere un fondo de tres meses, ahorrar 100 por quincena en su AFORE y lavar autos en un día de descanso: cobra 1,000, gasta 300 y trabaja 8 horas.

**Tareas.**

1. ¿Cuánto es su fondo de tres meses?
2. ¿Cuánto aporta al año a su AFORE?
3. ¿Cuál es su ganancia por hora lavando autos?
4. ¿Qué parte del ingreso extra aparta?

**Clave.**

- 27,000.
- 100 por 24: 2,400.
- 700 entre 8: 87.50 por hora.
- Una parte fija para su fondo hasta completarlo, por ejemplo la mitad.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Salario de quincena 4,790, descuentos 800. ¿Cuánto te llega? |
| P02 | M1 U02 | 130 por turno, 15 turnos. ¿Gasto al mes? |
| P03 | M1 U03 | 50 en antojos por turno, 15 turnos. ¿Al mes y al año? |
| P04 | M1 U04 | 150 por quincena. ¿Cuánto al año? |
| P05 | M2 U01 | Comisión de 120 al mes. ¿Cuánto al año? |
| P06 | M3 U02 | 45 abonos semanales de 170. ¿Total? |
| P07 | M3 U03 | Préstamo de 2,500 a 120 diarios por 30 días. ¿Cuánto de más? |
| P08 | M4 U01 | Tanda de 12 con 350 por quincena. ¿Cuánto cobra cada una? |
| P09 | M5 U03 | Tarjeta de 15,000. ¿Cuánto deber como máximo (un tercio)? |
| P10 | M7 U01 | Gastos de 8,500 al mes. ¿Fondo de tres meses? |
| P11 | M8 U01 | 50 por quincena en la AFORE. ¿Cuánto en 5 años, sin rendimiento? |
| P12 | M8 U02 | Cobras 1,600, gastas 500, trabajas 10 horas. ¿Ganancia por hora? |

### Respuestas

- **P01:** 3,990.
- **P02:** 1,950.
- **P03:** 750 al mes; 9,000 al año.
- **P04:** 3,600.
- **P05:** 1,440.
- **P06:** 7,650.
- **P07:** 120 por 30 son 3,600; pagas 1,100 de más.
- **P08:** 4,200.
- **P09:** 5,000.
- **P10:** 25,500.
- **P11:** 50 por 24 son 1,200 al año; por 5: 6,000.
- **P12:** 1,100 entre 10: 110 por hora.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu quincena rinde

- **Ahorro:** dinero que apartas para usarlo después.
- **Costo de oportunidad:** lo que dejas de hacer con el dinero que gastas.
- **Estrés financiero:** preocupación constante por el dinero que afecta tu sueño, tu salud o tus relaciones.
- **Gasto fijo:** gasto que se repite igual, como la renta.
- **Gasto hormiga:** gasto pequeño que se repite y al mes suma mucho.
- **Precio por unidad:** precio dividido entre la cantidad; sirve para comparar tamaños.
- **Presupuesto:** plan de cuánto entra y en qué se usa.
- **Recibo de pago:** documento que muestra lo que ganas, lo que te descuentan y lo que te llega.
- **Salario:** lo que te pagan por tu trabajo antes de descuentos.
- **Suscripción:** pago que se repite cada mes hasta que lo cancelas.
- **Transferencia programada:** envío automático de dinero en una fecha fija.

### Tu cuenta y tu dinero

- **Cetes:** préstamos que le haces al gobierno federal a un plazo a cambio de intereses.
- **CLABE:** número de 18 dígitos para recibir transferencias.
- **Comprobante:** prueba de que hiciste un pago.
- **CONDUSEF:** institución del gobierno que orienta y defiende sin costo a los usuarios de bancos y otras financieras.
- **Cuenta básica:** cuenta sin comisiones por apertura, manejo, retiros y consultas en los cajeros del banco.
- **Diversificar:** repartir tu dinero en distintas inversiones para no depender de una sola.
- **Folio:** número de tu reclamación.
- **Fuente oficial:** autoridad o institución que publica la información con su nombre y fecha.
- **Inflación:** aumento general de los precios con el tiempo.
- **Interés compuesto:** interés que se calcula sobre el dinero y sobre los intereses que ya ganó.
- **Invertir:** poner dinero a trabajar para que crezca, aceptando algo de riesgo.
- **Portabilidad de nómina:** cambiar tu cuenta de nómina a otro banco sin costo.
- **Rumor:** información sin fuente que no se puede confirmar.
- **SIPRES:** registro de la CONDUSEF donde aparecen las financieras que existen.
- **Tasa real:** lo que gana tu ahorro después de restar la inflación.

### Tus deudas claras

- **Abono:** pago parcial de una deuda.
- **Autoexclusión:** opción para bloquear tu propia cuenta de apuestas por un tiempo.
- **Avalancha:** método para pagar primero la deuda más cara.
- **Bola de nieve:** método para pagar primero la deuda más chica.
- **CAT:** Costo Anual Total: lo que cuesta un crédito al año, con intereses y comisiones.
- **Deuda:** dinero que debes pagar.
- **Empeño:** préstamo en el que dejas algo de valor como garantía.
- **Juego compulsivo:** cuando no puedes dejar de apostar aunque te cause problemas.
- **Precio de contado:** lo que cuesta si pagas todo de una vez.
- **Préstamo gota a gota:** préstamo informal de pagos diarios con intereses muy altos, cobrado con amenazas.
- **Reestructura:** cambio de condiciones de una deuda para poder pagarla.
- **Saldo:** lo que debes hoy.
- **Usura:** cobrar intereses abusivos.

### Tandas y ahorro en grupo

- **Coyote:** intermediario que cobra por trámites que no tienen costo.
- **Precalificación:** puntos que indican si ya puedes pedir un crédito de vivienda.
- **Registro de pagos:** lista de quién pagó y cuándo.
- **Subcuenta de vivienda:** ahorro en Infonavit que tu empresa deposita con el 5% de tu salario.
- **Tanda:** ahorro en grupo en el que cada persona aporta lo mismo y cada turno una cobra todo.
- **Turno de la tanda:** el momento en que te toca cobrar.

### Buró de Crédito sin miedo

- **Aval:** persona que firma un pagaré y se obliga a pagar si quien pidió el crédito no paga.
- **Buró de Crédito:** empresa que guarda tu historial de créditos y pagos, buenos y malos.
- **Consulta:** registro de quién revisó tu historial.
- **Domiciliar:** pagar automáticamente desde tu cuenta.
- **Fiador:** persona que se obliga a pagar si el deudor no paga; común en contratos de renta.
- **Historial de crédito:** registro de tus créditos y cómo los pagaste.
- **Obligado solidario:** persona que responde por todo el contrato como si hubiera pedido el crédito.
- **Referencia personal:** persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no se obliga a pagar.
- **Reporte de crédito:** documento con tus créditos, pagos y consultas.
- **Uso del límite:** cuánto de tu crédito disponible estás usando.

### Que no te extorsionen

- **Bloqueo en Buró:** servicio para que nadie consulte tu historial de crédito sin tu autorización.
- **Código de verificación:** número que te llega para autorizar una operación; es como tu firma.
- **Denuncia:** aviso formal de un delito ante la autoridad.
- **Evidencia:** pruebas de lo que pasó.
- **Extorsión telefónica:** amenaza por teléfono para que pagues, muchas veces fingiendo tener a un familiar.
- **Inteligencia artificial:** programas que imitan voces, caras o textos de forma muy realista.
- **Montadeudas:** apps de préstamos que cobran de más y extorsionan usando tus contactos y fotos.
- **Palabra clave familiar:** palabra secreta que solo tu familia conoce para confirmar emergencias.
- **Permisos:** accesos que das a una app en tu celular.
- **Phishing:** engaño con mensajes o páginas falsas para robar tus datos.
- **REPEP:** Registro Público para Evitar Publicidad de Profeco: para que las empresas no te llamen ni te manden mensajes con publicidad.
- **REUS:** Registro Público de Usuarios de CONDUSEF: para que bancos y financieras no te llamen con publicidad.
- **Robo de identidad:** uso de tus datos para hacerse pasar por ti y pedir créditos o hacer trámites.
- **Secuestro virtual:** engaño en el que fingen tener a un familiar sin que sea cierto.
- **Voz clonada:** imitación de la voz de una persona hecha por computadora.

### Tu familia y los imprevistos

- **Aplazamiento de pagos:** permiso del banco para pagar después sin recargos en una emergencia.
- **Beneficiario:** persona que recibe el dinero de un seguro o una cuenta si tú faltas.
- **Escriturar:** pasar legalmente una casa o terreno a tu nombre ante notario.
- **Fondo de emergencia:** dinero apartado solo para imprevistos.
- **Herencia:** bienes y derechos que recibe una persona cuando otra fallece.
- **IMSS-Bienestar:** servicio de salud para personas sin seguridad social.
- **Lista de sucesión:** lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.
- **Medicamento genérico:** medicina con la misma sustancia que la de marca, que suele costar menos.
- **Mochila de emergencia:** bolsa con documentos, dinero y artículos básicos para salir rápido.
- **Póliza:** contrato de un seguro.
- **Seguro de Salud para la Familia:** seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- **Testamento:** documento ante notario en el que dices quién recibe tus bienes y quién cuida a tus hijos menores.
- **Tutor:** persona que cuida a un menor de edad y sus intereses.

### Tu futuro

- **AFORE:** administradora que guarda e invierte tu ahorro para el retiro.
- **Aportación voluntaria:** ahorro extra que haces tú en tu AFORE.
- **Costo:** lo que gastas para poder vender.
- **Ganancia:** lo que te queda después de pagar los costos.
- **Plan de una página:** resumen de tus decisiones de dinero en una sola hoja.


## Dónde encontrar ayuda

Todas las opciones de esta tabla son oficiales y sin costo. Información consultada el 29 de septiembre de 2026; confírmala en el sitio oficial.

| Necesidad | Dónde | Qué verificar |
|---|---|---|
| Reclamar a un banco o financiera | Unidad de atención del banco y CONDUSEF: 55 5340 0999 u 800 999 8080 | Folio de tu reclamación |
| Saber si una financiera existe | SIPRES de la CONDUSEF | Nombre exacto |
| Tu reporte de crédito | Buró de Crédito y Círculo de Crédito (uno sin costo al año en cada uno) | Solo sitios oficiales |
| Fraudes y delitos en línea | 088 | Evidencia |
| Extorsión | 089 (denuncia anónima) y 911 | Localiza primero a tu familiar |
| Amenazas de prestamistas | Fiscalía de tu estado, 089 y 911 | Capturas y fechas |
| Casas de empeño | Profeco | Contrato y boleta |
| Precios y compras | Profeco, «Quién es quién en los precios» | Sin costo |
| Invertir poco a poco | Cetesdirecto (sitio oficial) | Sin comisiones; nadie te cobra por abrir tu cuenta |
| Llamadas de publicidad | REPEP de Profeco (55 5568 8722 u 800 468 8722) y REUS de la CONDUSEF | Nadie cobra por inscribirte |
| Líneas de celular con tu CURP | Comisión Reguladora de Telecomunicaciones (portal.crt.gob.mx) | Desvincula las que no son tuyas |
| Créditos que no pediste | Reclamación a la empresa, al Buró o Círculo y denuncia; CONDUSEF | Folios y copia de la denuncia |
| Tu AFORE | e-SAR y AforeMóvil | Tu CURP |
| Tu crédito y ahorro de vivienda | Mi Cuenta Infonavit (con tu NSS) | Trámite sin costo, sin coyotes |
| Apuestas que se salen de control | Línea de la Vida (800 911 2000) y Centros de Integración Juvenil | Atención sin costo |
| Desastres | Protección Civil y módulos oficiales de apoyo | Nadie cobra por anotarte |
| Aseguradoras | CNSF | Que esté autorizada |
| Apoyo emocional | Línea de la Vida: 800 911 2000 | Atención 24 horas |

---

## Preguntas frecuentes

**¿Mi empresa ve mis respuestas o mis deudas?** No. El curso no comparte información personal ni financiera con nadie.

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados.

**¿El curso me presta dinero o me recomienda préstamos?** No. Te enseña a comparar y a salir de deudas.

**¿Qué hago si una app me está extorsionando?** No pagues lo que exigen de más, avisa a tus contactos, guarda capturas y denuncia (M6 U02).

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso; cada lección dura unos 5 minutos.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.


## Referencias

Fuentes que usamos en el curso, consultadas el 29 de septiembre de 2026.

### Instituciones

- **I01** CONASAMI: salarios mínimos 2026.
- **I02** CONDUSEF: SIPRES, reclamaciones, alertas sobre préstamos fraudulentos y montadeudas.
- **I03** Banco de México: cuentas básicas, CAT, CEP.
- **I04** Buró de Crédito y Círculo de Crédito: reportes sin costo.
- **I05** CONSAR, e-SAR y AforeMóvil: aportaciones voluntarias.
- **I06** CNSF: aseguradoras autorizadas.
- **I07** Profeco: casas de empeño y REPEP.
- **I08** Comisión Reguladora de Telecomunicaciones: líneas móviles y CURP.
- **I09** Infonavit: subcuenta de vivienda y modelo de 100 puntos.
- **I10** Secretaría de Gobernación: permisionarios de juegos y sorteos; Secretaría de Salud: Línea de la Vida; CENAPRED: plan familiar de protección civil.
- **I11** Guardia Nacional: 088.
- **I12** IPAB: seguro de depósitos.
- **I13** Banco de México e INEGI: inflación e INPC; Cetesdirecto; CNBV: padrón de entidades supervisadas.
- **I14** Innovations for Poverty Action y J-PAL: *Nudges para una óptima salud financiera* (compromiso, opciones por defecto y recordatorios).

### Leyes

- **L01** Ley de Instituciones de Crédito (cuenta básica, art. 48 Bis 2).
- **L02** Ley de Protección y Defensa al Usuario de Servicios Financieros.

### Medios consultados

- **M01** Notas informativas sobre préstamos «gota a gota» y alertas de la CONDUSEF sobre apps de préstamo.
- **M02** Notas informativas sobre aportaciones voluntarias a la AFORE en tiendas.


# Parte 10. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. ¿Cuánto entra de verdad?

**Caso 1. La quincena de Don Chuy.** Don Chuy hace sus cuentas con «10 mil», pero le llegan 4,100 por quincena. **¿Qué hace?**

- ✔ Hace su presupuesto con lo que le llega de verdad.
- Hace cuentas con los 10 mil que dice ganar.
- Pide un adelanto para completar la quincena.

**Caso 2. El descuento de Karla.** A Karla le descontaron algo que no entiende. **¿Qué hace?**

- ✔ Pide su recibo y pregunta.
- No pregunta para no tener problemas en el trabajo.
- Supone que es un impuesto y lo deja pasar.

**Caso 3. El adelanto de Beto.** Beto pide un adelanto cada quincena y siempre le falta. **¿Qué hace?**

- ✔ Suma lo que le descuentan y planea dejar de pedirlo.
- Pide un adelanto más grande para no quedarse corto.
- Pide adelantos solo en quincenas difíciles.

## M1 U02. Tu presupuesto de turno

**Caso 1. La quincena de Karla.** A Karla se le acaba el dinero a mitad de quincena. **¿Qué hace?**

- ✔ Calcula su gasto de turnos por 15 y lo suma a la casa.
- Pide un adelanto cada mitad de quincena.
- Deja de comer en los turnos para ahorrar.

**Caso 2. La comida de Don Chuy.** Don Chuy gasta 90 en comida en cada turno. **¿Qué hace?**

- ✔ Calcula el total y lleva comida algunos turnos.
- No cambia nada; son solo 90 pesos al día.
- Deja de comer en el turno para ahorrar todo.

**Caso 3. La falta de Beto.** A Beto le faltan 500 al mes y pide un adelanto. **¿Qué hace?**

- ✔ Ajusta sus gastos del turno.
- Pide el adelanto; es solo un mes.
- Pide prestado a un compañero cada quincena para cubrir lo que falta.

## M1 U03. Los gastos del turno que no ves

**Caso 1. Los antojos de Beto.** Beto gasta 60 por turno en antojos y dice que no es nada. **¿Qué hace?**

- ✔ Calcula el total del mes y decide cuáles deja.
- Sigue igual; son solo 60 pesos por turno.
- Deja todo de golpe desde mañana.

**Caso 2. Las recargas de Karla.** Karla recarga 50 cada tercer día. **¿Qué hace?**

- ✔ Compara con un plan fijo mensual.
- Sigue recargando cada tercer día.
- Pide datos prestados a sus compañeros del turno.

**Caso 3. La apuesta de Ramiro.** Ramiro apuesta en una app para «recuperar» lo que perdió. **¿Qué hace?**

- ✔ Deja de apostar para recuperar y busca ayuda.
- Apuesta más para recuperar lo perdido.
- Pide prestado para seguir jugando esta semana.

## M1 U04. Aparta primero

**Caso 1. El «lo que sobre» de Karla.** Karla ahorra «lo que sobre» y nunca sobra. **¿Qué hace?**

- ✔ Aparta 150 el día de pago, antes de gastar.
- Sigue ahorrando lo que sobre al final del mes.
- Ahorra solo en diciembre con el aguinaldo.

**Caso 2. El efectivo de Don Chuy.** A Don Chuy le pagan una parte en efectivo. **¿Qué hace?**

- ✔ Separa su ahorro en un sobre el día que cobra.
- Guarda el ahorro en la cartera del turno.
- Lo gasta y ahorra el próximo mes.

**Caso 3. La cuenta de Beto.** Beto ahorra en la misma cuenta que usa con su tarjeta y se lo gasta. **¿Qué hace?**

- ✔ Abre una cuenta aparte para ahorrar.
- Sigue en la misma cuenta, con fuerza de voluntad.
- Se lo da a un amigo para que se lo guarde.

## M1 U05. Dinero y estrés: cómo hablarlo en casa

**Caso 1. La discusión de Don Chuy.** Don Chuy y su esposa discuten de dinero al salir él del turno. **¿Qué hacen?**

- ✔ Eligen un día fijo para hablarlo con números.
- Lo hablan al salir él del turno.
- Dejan de hablar de dinero para no pelear.

**Caso 2. Los mensajes de Beto.** Beto no abre los mensajes de su app de préstamos porque le da miedo. **¿Qué hace?**

- ✔ Los revisa y anota cuánto debe.
- Los sigue sin abrir para no estresarse.
- Cambia de número para que no le escriban.

**Caso 3. La niña de Karla.** La hija de Karla le pide algo en cada salida y Karla se siente culpable al decir que no. **¿Qué hace?**

- ✔ Le explica el plan y acuerdan un gusto.
- Le compra todo para no sentirse mal.
- Le dice que no hay dinero y ya.

## M1 U06. Compra inteligente: precio por unidad, publicidad y pagos chiquitos

**Caso 1. Los audífonos de Beto.** Beto quiere unos audífonos «a solo 99 a la semana» durante un año. **¿Qué hace?**

- ✔ Suma el total, compara con el contado y espera.
- Los compra: 99 a la semana casi no se siente.
- Pide un adelanto para comprarlos hoy.

**Caso 2. El café de Don Chuy.** Don Chuy cree que el frasco grande siempre sale más barato. **¿Qué hace?**

- ✔ Calcula el precio por gramo de cada uno.
- Compra el grande: siempre sale más barato.
- Compra el que tiene más publicidad.

**Caso 3. Las plataformas de Karla.** Karla paga tres plataformas de video y solo usa una. **¿Qué hace?**

- ✔ Cancela las que no usa y aparta ese dinero.
- Las deja: son poquito cada mes.
- Contrata una más con descuento.

## M2 U01. Una cuenta sin comisiones

**Caso 1. La comisión de Ramiro.** El banco le cobra a Ramiro 120 al mes por saldo mínimo. **¿Qué hace?**

- ✔ Pide la cuenta básica sin comisiones.
- Sigue pagando; así es en todos los bancos.
- Cierra la cuenta y guarda todo en efectivo en su casa.

**Caso 2. El cajero de Karla.** Karla retira en el cajero más cercano, de otro banco, y le cobran 35 cada vez. **¿Qué hace?**

- ✔ Retira en cajeros de su banco o paga con tarjeta.
- Sigue en el cajero más cercano, aunque cobre.
- Retira todo de una vez y lo carga en el turno.

**Caso 3. La nómina de Don Chuy.** A Don Chuy no le gusta el banco donde le pagan. **¿Qué hace?**

- ✔ Pide la portabilidad de su nómina.
- Se queda; la empresa elige el banco.
- Pide que le paguen todo en efectivo.

## M2 U02. Cobrar y pagar sin perder dinero

**Caso 1. El efectivo de Don Chuy.** Don Chuy trae todo su pago en efectivo durante el turno. **¿Qué hace?**

- ✔ Recibe por transferencia y carga poco efectivo.
- Trae todo en la cartera para tenerlo a la mano.
- Esconde el efectivo en su casillero.

**Caso 2. El abono de Karla.** Karla paga sus abonos en persona cada semana. **¿Qué hace?**

- ✔ Pregunta si puede transferir y guarda el comprobante.
- Sigue pagando en persona cada semana.
- Deja de pagar hasta que le cobren.

**Caso 3. La cuenta nueva del casero de Beto.** El casero de Beto le escribe que cambió de cuenta. **¿Qué hace?**

- ✔ Llama para confirmar antes de pagar.
- Paga a la cuenta nueva para no atrasarse.
- Contesta el mensaje para confirmar los datos de la cuenta nueva.

## M2 U03. Quién te protege y dónde reclamar

**Caso 1. El seguro de Karla.** Le cobran a Karla un seguro que no pidió y le dicen que no se puede quitar. **¿Qué hace?**

- ✔ Reclama con folio y luego va a la CONDUSEF.
- Acepta que no se puede quitar y sigue pagando.
- Deja de pagar la tarjeta en protesta.

**Caso 2. La financiera de Beto.** Beto quiere pedir un préstamo a una financiera que vio en redes. **¿Qué hace?**

- ✔ Busca la financiera en el SIPRES.
- Pide el préstamo porque tiene muchos seguidores.
- Pide el préstamo pequeño para probar.

**Caso 3. El gestor de Don Chuy.** Un gestor le ofrece a Don Chuy «arreglar» un cobro por 500 pesos. **¿Qué hace?**

- ✔ Reclama él mismo sin costo.
- Paga los 500 para que se lo arreglen.
- Paga la mitad y el resto al terminar el trámite con el banco.

## M2 U04. ¿A quién le crees? Información confiable y cambios que te afectan

**Caso 1. El rumor del grupo.** En el grupo del turno dicen que el banco va a congelar las cuentas. **¿Qué hace Ramiro?**

- ✔ Lo confirma en CONDUSEF y no lo reenvía.
- Saca todo su dinero del banco hoy mismo.
- Lo reenvía a todos para que se cuiden.

**Caso 2. El «asesor» del aguinaldo.** Un contacto le ofrece a Beto duplicar su aguinaldo en un mes. **¿Qué hace?**

- ✔ No invierte y reporta el número.
- Invierte la mitad para probar.
- Le da su aguinaldo si le firma un recibo.

**Caso 3. Los precios de Karla.** Subió el precio del transporte y del gas en la casa de Karla. **¿Qué hace?**

- ✔ Revisa su presupuesto y ajusta un gasto.
- Pide un préstamo para cubrir la diferencia.
- Deja de pagar el gas un mes.

## M2 U05. El dinero pierde valor: inflación e interés compuesto

**Caso 1. El cajón de Don Chuy.** Don Chuy tiene 10,000 pesos en un cajón desde hace tres años. **¿Qué hace?**

- ✔ Los pasa a una opción protegida con rendimiento.
- Los deja en el cajón; ahí nadie los toca.
- Los presta a un conocido con interés.

**Caso 2. El ahorro de Karla.** La cuenta de Karla paga 1% al año y la inflación es de 4%. **¿Qué entiende?**

- ✔ Que pierde poder de compra y compara opciones.
- Que su dinero crece porque ve más pesos.
- Que la inflación no afecta a las cuentas.

**Caso 3. La tarjeta de Beto.** Beto paga solo el mínimo de su tarjeta cada mes. **¿Qué entiende?**

- ✔ Que su deuda crece y debe pagar más del mínimo.
- Que el mínimo es lo que le conviene pagar.
- Que la deuda se detiene si no la usa.

## M2 U06. Tu dinero a trabajar: primeros pasos para invertir

**Caso 1. La criptomoneda de Ramiro.** Un compañero le dice a Ramiro que meta todo a una criptomoneda «que va a subir». **¿Qué hace?**

- ✔ Empieza con Cetes, que sí puede explicar.
- Mete todo a la criptomoneda antes de que suba.
- Pide prestado para invertir más.

**Caso 2. El fondo de Karla.** Karla quiere invertir, pero todavía no tiene fondo de emergencia. **¿Qué hace?**

- ✔ Primero junta su fondo y después invierte.
- Invierte todo y usa la tarjeta si hay emergencia.
- Invierte lo de la renta del mes.

**Caso 3. El miedo de Don Chuy.** Don Chuy oye en la tele que «todo va a bajar» y quiere sacar su dinero de Cetes antes del plazo. **¿Qué hace?**

- ✔ Revisa su meta y su plazo; no decide con miedo.
- Saca todo antes del plazo por si acaso.
- Pasa todo a lo que dicen en la tele.

## M3 U01. ¿Cuánto debes en total?

**Caso 1. El «poquito» de Don Chuy.** Don Chuy dice que debe «poquito en cada lado». **¿Qué hace?**

- ✔ Hace su lista y suma el total.
- Sigue pagando poquito a cada uno.
- Pide otro préstamo para juntar todo en uno.

**Caso 2. La tanda de Karla.** Karla ya cobró su tanda y todavía debe cuatro pagos. **¿Qué hace?**

- ✔ La anota en su lista como deuda.
- No la cuenta porque es entre compañeras.
- La cuenta como ahorro, porque es una tanda entre amigas.

**Caso 3. La app de Beto.** Beto no incluye el préstamo de la app porque le da pena. **¿Qué hace?**

- ✔ La anota: todas las deudas cuentan.
- La deja fuera para no sentirse mal.
- La paga primero sin anotarla.

## M3 U02. Lo que de verdad cuesta un préstamo

**Caso 1. La pantalla de Karla.** Le ofrecen a Karla una pantalla a 52 abonos de 190. **¿Qué hace?**

- ✔ Multiplica y compara con el contado.
- Compra porque el abono es bajo.
- Compra y paga abonos dobles cuando pueda para terminar antes.

**Caso 2. El adelanto de Beto.** Beto pide un adelanto de 1,000 y le descuentan 1,150. **¿Qué hace?**

- ✔ Calcula el costo y busca dejar los adelantos.
- Sigue pidiendo; son solo 150.
- Pide un adelanto más grande.

**Caso 3. El reloj de Ramiro.** Ramiro quiere empeñar su reloj para pagar otra deuda. **¿Qué hace?**

- ✔ Revisa costo y plazo, y si podrá recuperarlo.
- Lo empeña sin preguntar nada.
- Empeña también otras cosas.

## M3 U03. Prestamistas y «gota a gota»

**Caso 1. Los 3,000 de Ramiro.** Le ofrecen a Ramiro 3,000 a pagar 150 diarios por un mes, sin contrato. **¿Qué hace?**

- ✔ No lo acepta y busca otra salida.
- Lo acepta; 150 diarios se pagan fácil.
- Lo acepta y paga solo cuando pueda.

**Caso 2. Las amenazas a Don Chuy.** Un prestamista amenaza a Don Chuy porque se atrasó. **¿Qué hace?**

- ✔ Guarda evidencia y denuncia.
- Pide otro préstamo para pagarle.
- No dice nada a nadie y sigue pagando lo que le pidan.

**Caso 3. El segundo préstamo de Beto.** Beto quiere pedir otro «gota a gota» para pagar el primero. **¿Qué hace?**

- ✔ No pide otro y busca ayuda para salir.
- Pide otro para salir del primero.
- Pide dos más pequeños.

## M3 U04. Tu plan para salir de deudas

**Caso 1. Las tres deudas de Don Chuy.** Don Chuy paga un poco a cada deuda y no termina ninguna. **¿Qué hace?**

- ✔ Elige un método y pone lo extra en una deuda.
- Sigue pagando un poco a cada una.
- Pide un préstamo para pagarlas todas juntas.

**Caso 2. La tienda de Karla.** Karla no podrá pagar su abono la próxima semana. **¿Qué hace?**

- ✔ Llama antes a la tienda y pide el acuerdo por escrito.
- Espera a que lo llamen de cobranza.
- No paga y cambia de número.

**Caso 3. La tarjeta nueva de Beto.** Mientras paga sus deudas, a Beto le ofrecen una tarjeta nueva. **¿Qué hace?**

- ✔ No la acepta hasta salir de deudas.
- La acepta para emergencias.
- La acepta y solo la usa para pagar sus otras deudas cada mes.

## M3 U05. Apuestas en línea: cuando el juego se vuelve deuda

**Caso 1. La deuda de Beto.** Beto perdió 3,000 pesos y quiere pedir un préstamo para «recuperarlos». **¿Qué hace?**

- ✔ No pide el préstamo y busca ayuda.
- Pide el préstamo para recuperar lo perdido.
- Apuesta el doble en el siguiente partido.

**Caso 2. El bono de Ramiro.** A Ramiro le ofrecen un bono de bienvenida si deposita 500 en una app. **¿Qué revisa?**

- ✔ Si tiene permiso y sale de sus gustos.
- Nada: el bono vale la pena.
- Solo si el partido es importante.

**Caso 3. El compañero de Karla.** Un compañero de Karla le pide prestado para apostar en el partido. **¿Qué hace?**

- ✔ No le presta y le comparte dónde pedir ayuda.
- Le presta porque es compañero.
- Le presta con intereses.

## M4 U01. Tandas: cómo funcionan y qué puede salir mal

**Caso 1. La compañera de Karla.** Una compañera cobró en el turno 2 y dejó de pagar. **¿Qué hace Karla la próxima vez?**

- ✔ Pone reglas por escrito y da los primeros turnos a gente de confianza.
- Cancela todas las tandas para siempre.
- Cobra una multa a todas las compañeras.

**Caso 2. El turno de Beto.** Beto quiere el primer turno para comprarse un celular. **¿Qué hace?**

- ✔ Entiende que es deuda y revisa si podrá pagar.
- Pide el primer turno sin pensarlo.
- Pide el primer turno y luego deja de pagar.

**Caso 3. El organizador de Don Chuy.** El organizador de la tanda de Don Chuy cambió de trabajo. **¿Qué hace?**

- ✔ Pide nombrar a otra persona y registrar pagos.
- Deja de pagar su parte.
- Sigue dándole su dinero al organizador aunque ya no trabaje con ellos.

## M4 U02. Tu tanda con reglas o tu propio ahorro

**Caso 1. La nueva tanda de Karla.** Karla quiere organizar otra tanda sin perder dinero. **¿Qué hace?**

- ✔ Pone las reglas por escrito y registra cada pago.
- Organiza igual que antes, de palabra.
- Solo invita a compañeras nuevas.

**Caso 2. El ahorro de Ramiro.** Ramiro puede apartar 300 cada quincena sin problema. **¿Qué hace?**

- ✔ Ahorra por su cuenta en una cuenta aparte.
- Entra a tres tandas a la vez.
- Guarda el efectivo en su casillero.

**Caso 3. El desconocido en la tanda de Don Chuy.** Un desconocido quiere entrar a la tanda de Don Chuy con el primer turno. **¿Qué hace?**

- ✔ No lo acepta en los primeros turnos.
- Le da el primer turno para ayudarlo.
- Le da el primer turno si deja su credencial.

## M4 U03. Tu casa: Infonavit y el crédito de 100 puntos

**Caso 1. Los puntos de Karla.** Karla cree que nunca podrá tener un crédito de vivienda. **¿Qué hace?**

- ✔ Revisa sus puntos en Mi Cuenta Infonavit.
- Supone que nunca podrá.
- Paga a un gestor para que revise.

**Caso 2. El coyote de Beto.** Alguien le ofrece a Beto «adelantarle» su crédito por 3,000 pesos. **¿Qué hace?**

- ✔ No paga: el trámite no tiene costo.
- Paga los 3,000 para adelantarlo.
- Le da su contraseña al gestor.

**Caso 3. El descuento de Don Chuy.** A Don Chuy le prestan para una casa, pero el descuento sería de 30% de su quincena. **¿Qué revisa?**

- ✔ Si su presupuesto aguanta el descuento.
- Solo si la casa le gusta.
- Firma rápido para no perder la casa.

## M5 U01. Qué es el Buró de Crédito

**Caso 1. El «boletinado» de Beto.** Beto cree que está en una lista negra y que nunca le prestarán. **¿Qué hace?**

- ✔ Pide su reporte sin costo para ver qué hay.
- Da por hecho que nunca le prestarán.
- Paga a alguien para que lo saque de la lista.

**Caso 2. El crédito de Karla.** Karla nunca ha tenido crédito y le negaron uno. **¿Qué hace?**

- ✔ Empieza con algo pequeño que pueda pagar.
- Pide muchos créditos hasta que le den uno.
- Deja de intentarlo para siempre.

**Caso 3. El atraso de Don Chuy.** Don Chuy pagó un atraso y cree que se borra al instante. **¿Qué hace?**

- ✔ Sigue pagando a tiempo; el registro se elimina con el tiempo.
- Reclama que borren el atraso ya.
- Paga a un despacho para borrarlo.

## M5 U02. Tu reporte sin costo y cómo reclamar

**Caso 1. La tienda de Karla.** Aparece en el reporte de Karla una deuda que ya pagó. **¿Qué hace?**

- ✔ Reclama con su comprobante.
- Paga otra vez la deuda para que se borre.
- Lo deja así; ya lo pagó una vez y no quiere problemas.

**Caso 2. La página de Beto.** Beto encuentra una página que le cobra 200 por su reporte. **¿Qué hace?**

- ✔ Lo pide sin costo en el sitio oficial.
- Paga los 200; es más rápido.
- Pide a un amigo que lo saque por él.

**Caso 3. La consulta de Ramiro.** En el reporte de Ramiro hay una consulta de una financiera que no conoce. **¿Qué hace?**

- ✔ Reclama la consulta y revisa sus datos.
- Ignora la consulta.
- Llama a la financiera al número que encontró en un anuncio.

## M5 U03. Cómo mejorar tu historial

**Caso 1. El despacho de Don Chuy.** Le ofrecen a Don Chuy «limpiar su Buró» por 2,500. **¿Qué hace?**

- ✔ No paga y mejora con pagos a tiempo.
- Paga los 2,500 para limpiar su historial.
- Paga la mitad para ver si funciona.

**Caso 2. La tarjeta de Karla.** Karla usa casi todo el límite de su tarjeta cada mes. **¿Qué hace?**

- ✔ Trata de deber menos de un tercio del límite.
- Usa todo el límite; para eso es.
- Pide que le suban el límite.

**Caso 3. Las solicitudes de Beto.** Beto pidió cinco créditos en un mes para ver cuál le daban. **¿Qué hace?**

- ✔ Deja de pedir y paga a tiempo.
- Pide más créditos hasta que le den.
- Pide créditos en apps que no revisan historial y prestan rápido.

## M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?

**Caso 1. El préstamo de Beto.** Un compañero le pide a Beto que firme como aval de un préstamo de 15,000. **¿Qué hace Beto?**

- ✔ Dice que no y ofrece otra ayuda.
- Firma: es su compañero de turno.
- Firma, pero solo por la mitad del préstamo.

**Caso 2. La solicitud de Karla.** A Karla le piden firmar «como referencia» una hoja que dice «obligado solidario». **¿Qué hace?**

- ✔ No firma: la obligaría a pagar todo.
- Firma sin leer: dicen que es un trámite.
- Firma y pide que le den una copia después.

**Caso 3. La llamada a Don Chuy.** Un despacho llama a Don Chuy para cobrarle la deuda de un compañero del que solo fue referencia. **¿Qué hace?**

- ✔ No paga y se queja en el REDECO.
- Paga para que dejen de llamar.
- Da los datos de la familia de su compañero.

## M6 U01. Llamadas y mensajes falsos

**Caso 1. La llamada nocturna a Don Chuy.** «Del banco» le piden a Don Chuy el código que le llegó. **¿Qué hace?**

- ✔ No lo da, cuelga y llama a su banco.
- Da el código para cancelar el cargo.
- Da el código porque sabían su nombre completo y el banco.

**Caso 2. El paquete de Karla.** Le llega a Karla un mensaje para pagar 30 pesos por un paquete que no espera. **¿Qué hace?**

- ✔ Lo borra sin pagar.
- Paga los 30 pesos.
- Abre el enlace para ver qué paquete es y quién se lo envió.

**Caso 3. El primo de Beto.** Su «primo» le escribe a Beto desde un número nuevo pidiéndole dinero. **¿Qué hace?**

- ✔ Le llama a su número de siempre.
- Le manda el dinero; es su primo.
- Le pide una foto para confirmar.

## M6 U02. Apps «montadeudas»

**Caso 1. Los 4,500 de Beto.** La app le exige a Beto 4,500 por 2,000 y escribe a sus contactos. **¿Qué hace?**

- ✔ No paga la extorsión, avisa y denuncia.
- Paga los 4,500 para que lo dejen en paz.
- Pide otro préstamo en otra app para pagar.

**Caso 2. La app de Karla.** Karla quiere instalar una app de préstamos que pide acceso a sus contactos. **¿Qué hace?**

- ✔ No la instala y verifica en el SIPRES.
- La instala y quita el permiso después.
- La instala porque el préstamo es chico y lo pagará rápido.

**Caso 3. El compañero de Don Chuy.** Un compañero de Don Chuy está desesperado por las amenazas de una app. **¿Qué hace?**

- ✔ Le explica que no pague y lo acompaña a denunciar.
- Le dice que pague para que se calmen.
- Le presta dinero para que pague.

## M6 U03. Extorsión telefónica

**Caso 1. La llamada a Karla.** Le dicen a Karla que tienen a su hija y que no cuelgue. **¿Qué hace?**

- ✔ Cuelga y llama a la escuela.
- Paga para que no le pase nada.
- Negocia una cantidad menor sin colgar para ganar tiempo.

**Caso 2. La palabra de Ramiro.** Ramiro quiere proteger a su familia de estas llamadas. **¿Qué hace?**

- ✔ Acuerda una palabra clave con su familia.
- Le pide a su familia que no conteste.
- Cambia de número de celular toda la familia.

**Caso 3. Las fotos de Beto.** Beto publica en redes dónde trabaja y a qué hora sale. **¿Qué hace?**

- ✔ Deja de publicar horarios y ubicaciones.
- Sigue publicando; su perfil es privado.
- Publica solo en sus historias, que se borran en 24 horas.

## M6 U04. Si ya te pasó: qué hacer

**Caso 1. Los 3,000 de Don Chuy.** A Don Chuy le sacaron 3,000 después de dar su NIP. **¿Qué hace?**

- ✔ Bloquea, reclama con folio y denuncia.
- Espera a ver si le devuelven solos.
- Cambia de banco sin reclamar nada.

**Caso 2. La espera de Karla.** Karla vio un cargo raro y quiere esperar al estado de cuenta. **¿Qué hace?**

- ✔ Reclama de inmediato.
- Espera al estado de cuenta.
- Espera a ver si se repite antes de hacer algo.

**Caso 3. La vergüenza de Beto.** A Beto le da vergüenza contar que cayó en un fraude. **¿Qué hace?**

- ✔ Lo cuenta y sigue su plan.
- Lo calla por vergüenza.
- Se lo cuenta solo a quien lo engañó para que le devuelva el dinero.

## M6 U05. Tu identidad y que dejen de llamarte

**Caso 1. El crédito de Beto.** Beto recibe una llamada de cobranza por un crédito que no pidió. **¿Qué hace?**

- ✔ Pide su reporte, reclama, denuncia y bloquea.
- Paga el crédito para que ya no le llamen.
- Ignora las llamadas hasta que se cansen.

**Caso 2. Las llamadas de Karla.** A Karla le llaman diario de bancos y tiendas para ofrecerle créditos. **¿Qué hace?**

- ✔ Inscribe su celular en el REPEP y el REUS.
- Cambia de número cada vez que le llaman.
- Contesta y pide que la saquen de la lista.

**Caso 3. El reclutador de Don Chuy.** Un reclutador pide a Don Chuy foto de su INE por WhatsApp y 300 pesos para «apartar la vacante». **¿Qué hace?**

- ✔ No manda nada y verifica la empresa.
- Manda la foto porque la vacante es buena.
- Paga los 300 pesos y manda el INE después.

## M6 U06. Voces y videos falsos con inteligencia artificial

**Caso 1. El audio de Don Chuy.** Llega un audio con la voz del hijo de Don Chuy pidiendo 8,000 urgentes. **¿Qué hace?**

- ✔ Cuelga y llama al celular de su hijo.
- Deposita: es la voz de su hijo.
- Responde el audio pidiendo la cuenta.

**Caso 2. El video de Beto.** Beto ve un video de un futbolista famoso recomendando una inversión que «duplica» el dinero. **¿Qué hace?**

- ✔ No invierte: es un video falso.
- Invierte poco para probar.
- Comparte el video con su familia.

**Caso 3. El supervisor de Ramiro.** Una llamada con la voz del jefe de Ramiro le pide los códigos del sistema de acceso. **¿Qué hace?**

- ✔ No los da y confirma en persona.
- Los da porque es la voz del jefe.
- Da la mitad de los códigos.

## M7 U01. Tu fondo de emergencia, de poco a poco

**Caso 1. El refrigerador de Karla.** Karla no tenía ahorro y pidió en una app. **¿Qué hace ahora?**

- ✔ Aparta 100 por quincena para su fondo.
- Sigue pidiendo en apps cuando haga falta.
- Espera al aguinaldo para empezar.

**Caso 2. El préstamo del compañero de Ramiro.** Un compañero le pide a Ramiro prestado su fondo. **¿Qué hace?**

- ✔ No presta su fondo.
- Lo presta; es su compañero.
- Presta la mitad y confía en que le pague pronto.

**Caso 3. La tanda de Beto.** Beto quiere meter su fondo en una tanda. **¿Qué hace?**

- ✔ Lo deja en una cuenta aparte, disponible.
- Lo mete a la tanda para juntar más.
- Lo presta con intereses.

## M7 U02. Tu salud y la de tu familia: estar preparado

**Caso 1. La madrugada de Ramiro.** Ramiro no sabía a dónde llevar a su hija de madrugada. **¿Qué hace ahora?**

- ✔ Anota su clínica, el hospital cercano y los teléfonos.
- Espera a la próxima emergencia para buscar.
- Busca en internet cuando pase.

**Caso 2. La receta de Don Chuy.** Don Chuy gasta mucho en una medicina de marca. **¿Qué hace?**

- ✔ Pregunta por el genérico y compara.
- Sigue con la de marca aunque le cueste más de lo que puede.
- Deja de tomar la medicina.

**Caso 3. Los papeles de Karla.** Karla no encuentra el carnet de su hija cuando lo necesita. **¿Qué hace?**

- ✔ Guarda los documentos en una carpeta.
- Los busca cuando los necesite.
- Le pide a la escuela que los guarde.

## M7 U03. Seguro de vida, gastos funerarios y beneficiarios

**Caso 1. La preocupación de Don Chuy.** Don Chuy no sabe qué pasaría con su familia si falta. **¿Qué hace?**

- ✔ Pregunta por el seguro del trabajo y revisa beneficiarios.
- Supone que su familia se las arreglará.
- Espera a jubilarse para pensarlo.

**Caso 2. El plan de Karla.** A Karla le ofrecen un «plan funerario» sin contrato. **¿Qué hace?**

- ✔ Busca uno con póliza de una aseguradora autorizada.
- Contrata el plan porque es barato.
- Paga el primer mes para probar.

**Caso 3. Los papeles de Ramiro.** La familia de Ramiro no sabe dónde están sus pólizas. **¿Qué hace?**

- ✔ Las guarda en una carpeta y avisa dónde.
- Las deja en el casillero del trabajo.
- No dice nada para no preocupar a su familia con esos temas.

## M7 U04. Si llega un desastre: sismo, inundación o incendio

**Caso 1. La bolsa de Ramiro.** Ramiro guarda todos sus documentos originales en un cajón. **¿Qué hace?**

- ✔ Hace copias y fotos protegidas.
- Deja los originales en el cajón.
- Sube las fotos a su perfil público.

**Caso 2. El gestor de Karla.** Después de una inundación, alguien le cobra a Karla 500 pesos por anotarla en un apoyo. **¿Qué hace?**

- ✔ No paga y va al módulo oficial.
- Paga los 500 para asegurar el apoyo.
- Paga la mitad y el resto después.

**Caso 3. El préstamo de Don Chuy.** Tras el sismo, Don Chuy no puede pagar su crédito este mes. **¿Qué hace?**

- ✔ Pide aplazamiento por escrito.
- Deja de pagar sin avisar.
- Pide otro préstamo para cubrir el pago.

## M7 U05. Salud para tu familia: el seguro del IMSS que pagas tú

**Caso 1. La mamá de Don Chuy.** La mamá de Don Chuy no tiene seguridad social y él paga consultas privadas. **¿Qué hace?**

- ✔ Compara el seguro familiar con lo que gasta y pregunta qué cubre.
- Sigue pagando consultas privadas porque así ha sido siempre.
- Pide un préstamo cada vez que su mamá necesita ir al médico.

**Caso 2. La hija de Karla.** La hija de Karla no tiene seguro y se enferma seguido. **¿Qué hace?**

- ✔ La lleva al centro de salud con su CURP o revisa la cuota del seguro.
- Espera a que se ponga grave para llevarla a un hospital privado.
- Le da medicinas que le recomiendan en la farmacia de la esquina.

**Caso 3. El gestor de Beto.** Un gestor le ofrece a Beto «meter a su papá al IMSS» por 3,000. **¿Qué hace?**

- ✔ No paga: el trámite se hace directo en el IMSS.
- Paga los 3,000 para que su papá tenga IMSS más rápido.
- Paga la mitad ahora y la otra mitad cuando ya esté inscrito.

## M7 U06. Que tu familia no quede atorada: beneficiarios y testamento

**Caso 1. La cuenta de Don Chuy.** Don Chuy nunca nombró beneficiarios en su cuenta de nómina. **¿Qué hace?**

- ✔ Los nombra en su banco con nombres completos.
- Lo deja así porque cree que su familia recibirá todo sola.
- Le dice de palabra a su hijo mayor que la cuenta es para él.

**Caso 2. La pareja de Ramiro.** Ramiro vive en unión libre y no tiene testamento. **¿Qué hace?**

- ✔ Hace su testamento y nombra a su pareja como beneficiaria.
- Lo deja así porque viven juntos desde hace muchos años.
- Pone todo a nombre de su pareja desde ahora sin testamento.

**Caso 3. La hija de Karla.** Karla es mamá sola y le preocupa quién cuidaría a su hija. **¿Qué hace?**

- ✔ Nombra en su testamento a quien la cuidaría.
- Lo deja al azar porque no le gusta pensar en eso.
- Le dice de palabra a una vecina que cuide a su hija.

## M7 U07. Tu casa, tu tierra y lo que se hereda

**Caso 1. La casa de los papás de Don Chuy.** La casa sigue a nombre del papá de Don Chuy, que ya falleció. **¿Qué hace?**

- ✔ Pregunta en una notaría el trámite y cuánto cuesta escriturar.
- La deja a nombre de su papá porque ahí viven desde siempre.
- La vende sin papeles a un vecino para no hacer trámites.

**Caso 2. El 30% del hermano.** El hermano de Don Chuy cree que hay que pagar 30% de ISR por heredar. **¿Qué aprende?**

- ✔ Que heredar no paga ISR; solo cuestan los gastos de escriturar.
- Que de verdad hay que pagar 30% y mejor no escriturar.
- Que conviene no decirle nada al SAT para no pagar.

**Caso 3. La deuda del papá de Karla.** Un despacho le cobra a Karla la tarjeta de su papá, que falleció. **¿Qué hace?**

- ✔ Revisa si firmó como aval; si no, no paga con su dinero.
- Paga la tarjeta de su papá para que ya no le llamen.
- Paga la mitad para que el despacho la deje en paz.

## M8 U01. Ahorro para el retiro por tu cuenta

**Caso 1. El retiro de Ramiro.** Ramiro cree que el retiro está lejos y no ahorra. **¿Qué hace?**

- ✔ Empieza con aportaciones pequeñas cada quincena.
- Espera a ganar más para empezar.
- Espera a cumplir 50 años.

**Caso 2. La AFORE de Karla.** Karla no sabe en qué AFORE está. **¿Qué hace?**

- ✔ La localiza sin costo con su CURP.
- Paga a un gestor para encontrarla.
- Supone que no tiene AFORE y no busca.

**Caso 3. El regalo de Don Chuy.** Un agente le ofrece a Don Chuy una despensa si se cambia de AFORE. **¿Qué hace?**

- ✔ Compara rendimientos en la CONSAR.
- Se cambia por la despensa.
- Se cambia y luego regresa si no le gusta el rendimiento.

## M8 U02. Un ingreso extra en tus días de descanso

**Caso 1. Los autos de Ramiro.** Ramiro cree que ganará 2,000 a la semana lavando autos. **¿Qué hace?**

- ✔ Resta sus costos y calcula su ganancia por hora.
- Cuenta con los 2,000 completos.
- Deja su trabajo para lavar autos.

**Caso 2. El préstamo de Beto.** Beto quiere pedir un préstamo caro para empezar a vender comida. **¿Qué hace?**

- ✔ Empieza con poco, sin préstamos caros.
- Pide el préstamo para empezar en grande.
- Pide a varias apps para juntar el dinero.

**Caso 3. El cansancio de Karla.** Karla trabaja todos sus días de descanso y está agotada. **¿Qué hace?**

- ✔ Reduce los días extra para cuidar su salud.
- Trabaja también en sus horas de sueño.
- Toma bebidas energéticas para aguantar todos los días de descanso.

## M8 U03. Tu plan de una página

**Caso 1. Las notas de Karla.** Karla tiene todo en notas sueltas del celular. **¿Qué hace?**

- ✔ Llena su plan de una página.
- Deja las notas sueltas como están.
- Borra todas sus notas para empezar de cero algún día.

**Caso 2. La revisión de Don Chuy.** Don Chuy hizo su plan pero nunca lo vuelve a ver. **¿Qué hace?**

- ✔ Lo revisa cada día de pago.
- Lo guarda y lo revisa en diciembre.
- Lo tira porque ya lo hizo.

**Caso 3. El NIP de Beto.** Beto quiere anotar su NIP en su plan. **¿Qué hace?**

- ✔ No lo anota: no lleva datos sensibles.
- Lo anota para no olvidarlo.
- Anota solo la mitad del NIP.

# Parte 11. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Con qué cifra haces tu presupuesto?

- Con tu salario antes de descuentos, porque es lo que ganas
- ✔ Con lo que te llega
- Con lo que ganan tus compañeros

*¡Correcto! Es el dinero real.*

**M1 U01 P2.** Tu salario de quincena es 4,800 y te descuentan 600. ¿Cuánto te llega?

- 5,400
- 4,800
- ✔ 4,200

*¡Correcto! 4,800 menos 600.*

**M1 U01 P3.** ¿Dónde revisas tus descuentos?

- ✔ En tu recibo de pago
- Preguntando a un compañero del turno
- En tu celular

*¡Correcto! Ahí aparecen.*

**M1 U02 P1.** Gastas 100 por turno y haces 15 turnos. ¿Cuánto al mes?

- ✔ 1,500
- 100
- 3,000

*¡Correcto! 100 por 15.*

**M1 U02 P2.** Te falta dinero cada mes. ¿Qué haces primero?

- Pides un adelanto cada quincena
- ✔ Ajustas tus gastos del turno
- Dejas de pagar la luz un mes

*¡Correcto! Son los más fáciles de ajustar.*

**M1 U02 P3.** ¿Qué apartas primero?

- El dinero para salir el fin de semana
- Lo que sobre al final
- ✔ El ahorro, aunque sea poco

*¡Correcto! Si lo dejas al final, no ahorras.*

**M1 U03 P1.** Gastas 40 en refresco por turno, 15 turnos. ¿Cuánto al mes?

- 400
- ✔ 600
- 40

*¡Correcto! 40 por 15.*

**M1 U03 P2.** Perdiste en una app de apuestas. ¿Qué haces?

- Apuestas más para recuperar lo perdido pronto
- Pides prestado para seguir
- ✔ Dejas de apostar para recuperar

*¡Correcto! Perseguir pérdidas empeora.*

**M1 U03 P3.** ¿Qué haces con tus gastos hormiga?

- ✔ Los calculas y decides cuáles dejar
- Te prohíbes todo desde hoy
- Nada, son poquitos

*¡Correcto! Sabes y decides.*

**M1 U04 P1.** ¿Cuándo apartas tu ahorro?

- ✔ El día de pago
- Al final del mes, con lo que sobre
- Cuando haya una emergencia

*¡Correcto! Antes de gastar.*

**M1 U04 P2.** Ahorras 200 por quincena. ¿Cuánto juntas en un año?

- 2,400
- ✔ 4,800
- 200

*¡Correcto! 200 por 24.*

**M1 U04 P3.** Te gastas el ahorro porque está en tu cuenta de siempre. ¿Qué haces?

- Dejas de ahorrar
- Lo guardas debajo del colchón para no verlo
- ✔ Abres una cuenta aparte para ahorro

*¡Correcto! Separarlo ayuda.*

**M1 U05 P1.** ¿Cuándo conviene hablar de dinero en pareja?

- Al llegar del turno de 24 horas
- ✔ En un día fijo y con calma
- Solo cuando llega un cobro

*¡Correcto! Sin cansancio ni pleito.*

**M1 U05 P2.** ¿Con qué termina una buena plática de dinero?

- ✔ Con una acción acordada para la semana
- Con quién tiene la culpa
- Con la promesa de no volver a hablar del tema

*¡Correcto! Avanzar poco a poco.*

**M1 U05 P3.** Llevas semanas sin dormir por las deudas y sientes que no hay salida. ¿Qué haces?

- Aguantas solo
- Pides otro préstamo para calmarte
- ✔ Buscas ayuda, por ejemplo en la Línea de la Vida

*¡Correcto! Pedir ayuda es cuidarte.*

**M1 U06 P1.** Un producto cuesta 99 a la semana durante 52 semanas. ¿Cuánto pagas en total?

- 99
- 1,188, lo mismo que 12 pagos
- ✔ 5,148

*¡Correcto! 99 por 52.*

**M1 U06 P2.** ¿Cómo comparas dos tamaños de un producto?

- ✔ Por el precio por unidad
- Siempre el más grande
- Por el que tenga más publicidad

*¡Correcto! Así ves cuál rinde más.*

**M1 U06 P3.** Un anuncio dice «solo hoy». ¿Qué haces?

- Compras antes de que se acabe
- ✔ Esperas un día y revisas si lo necesitas
- Pides prestado para aprovechar

*¡Correcto! La prisa es una técnica de venta.*

## Módulo 2

**M2 U01 P1.** ¿Qué es la cuenta básica?

- Una cuenta con comisiones bajas pero con tarjeta de crédito
- ✔ Una cuenta sin comisiones de manejo
- Una cuenta solo para empresas

*¡Correcto! Es tu derecho.*

**M2 U01 P2.** Te cobran 35 por retiro en otro banco, 8 veces al mes. ¿Cuánto pagas?

- ✔ 280
- 35
- 350

*¡Correcto! 35 por 8.*

**M2 U01 P3.** No te gusta tu banco de nómina. ¿Qué puedes hacer?

- Nada, lo elige la empresa
- ✔ Pedir la portabilidad de nómina
- Cobrar en efectivo

*¡Correcto! Puedes cambiarla.*

**M2 U02 P1.** ¿Cuántos dígitos tiene la CLABE?

- 16
- ✔ 18
- 10

*¡Correcto! 18 dígitos.*

**M2 U02 P2.** Te avisan por mensaje que cambió la cuenta de tu casero. ¿Qué haces?

- ✔ Le llamas para confirmar
- Pagas a la cuenta nueva para no atrasarte
- Contestas el mensaje

*¡Correcto! Es un fraude común.*

**M2 U02 P3.** ¿Qué haces después de transferir?

- Nada
- Borras el mensaje del banco para tener espacio
- ✔ Guardas el comprobante

*¡Correcto! Es tu prueba.*

**M2 U03 P1.** ¿Qué hace la CONDUSEF?

- Presta dinero en emergencias a quien lo necesita
- ✔ Orienta y defiende sin costo
- Cobra deudas

*¡Correcto! No tiene costo.*

**M2 U03 P2.** ¿Dónde verificas que una financiera existe?

- En sus redes sociales
- ✔ En el SIPRES
- Preguntando a un conocido que ya le pidió prestado

*¡Correcto! El registro oficial.*

**M2 U03 P3.** ¿Qué pides al reclamar en el banco?

- ✔ Un folio
- Un descuento en tu próximo pago
- Nada

*¡Correcto! Es tu constancia.*

**M2 U04 P1.** Te llega una cadena que dice que el banco congelará cuentas. ¿Qué haces?

- ✔ Lo confirmas en la fuente oficial y no lo reenvías
- Sacas todo tu dinero hoy
- Lo reenvías para avisar a todos

*¡Correcto! Confirma antes.*

**M2 U04 P2.** ¿Quién orienta sin costo sobre créditos y seguros?

- Un gestor que cobra por adelantado
- ✔ CONDUSEF
- El vendedor del crédito

*¡Correcto! Sin costo y sin venderte nada.*

**M2 U04 P3.** Suben los precios del transporte. ¿Qué haces?

- Pides prestado para cubrir la diferencia
- Sigues igual
- ✔ Ajustas tu presupuesto

*¡Correcto! El plan se ajusta.*

**M2 U05 P1.** Tu ahorro paga 2% al año y la inflación es de 4%. ¿Qué pasa?

- Tu dinero crece 6%
- ✔ Pierdes poder de compra
- No pasa nada

*¡Correcto! 2 menos 4 es menos 2.*

**M2 U05 P2.** ¿Qué es el interés compuesto?

- Una comisión del banco por abrir tu cuenta
- Un impuesto
- ✔ Interés sobre el dinero y sobre los intereses ya ganados

*¡Correcto! Por eso crece cada vez más.*

**M2 U05 P3.** ¿Qué pasa con una deuda si solo pagas el mínimo?

- ✔ Crece con interés sobre interés
- Se paga sola
- Baja más rápido

*¡Correcto! El interés compuesto trabaja en tu contra.*

**M2 U06 P1.** ¿Qué haces antes de invertir?

- Pides un préstamo para empezar
- ✔ Juntas tu fondo de emergencia y pagas tus deudas caras
- Inviertes lo de la renta

*¡Correcto! Primero tu colchón.*

**M2 U06 P2.** Te ofrecen 10% al mes «sin riesgo». ¿Qué es?

- ✔ Casi seguro un fraude
- Una buena oportunidad
- Una inversión del gobierno

*¡Correcto! Nadie garantiza tanto.*

**M2 U06 P3.** ¿Qué es diversificar?

- Poner todo en lo que más sube
- Cambiar de inversión cada semana
- ✔ Repartir tu dinero en distintas inversiones

*¡Correcto! Así no dependes de una sola.*

## Módulo 3

**M3 U01 P1.** ¿Qué va en tu lista de deudas?

- ✔ Todas tus deudas, incluidas las de personas
- Solo las del banco
- Solo las grandes, las chicas no importan

*¡Correcto! Todas cuentan.*

**M3 U01 P2.** Ya cobraste tu tanda y debes pagos. ¿Qué es?

- Ahorro
- ✔ Una deuda
- Un regalo

*¡Correcto! Debes pagos.*

**M3 U01 P3.** Pagas 3,000 al mes en deudas y te llegan 8,000. ¿Qué parte se va en deudas?

- Menos de una cuarta parte
- Casi la mitad
- ✔ Más de un tercio

*¡Correcto! 3,000 de 8,000 es 37.5%.*

**M3 U02 P1.** 40 abonos semanales de 150. ¿Cuánto pagas?

- ✔ 6,000
- 150
- 4,000

*¡Correcto! 150 por 40.*

**M3 U02 P2.** ¿Qué indica un CAT más alto?

- Un crédito más barato y conveniente
- ✔ Un crédito más caro
- Más plazo para pagar

*¡Correcto! Mide el costo.*

**M3 U02 P3.** Algo cuesta 4,000 de contado y en abonos pagas 6,500. ¿Cuánto pagas de más?

- 6,500
- ✔ 2,500
- 4,000

*¡Correcto! 6,500 menos 4,000.*

**M3 U03 P1.** Te prestan 2,000 a pagar 100 diarios por 30 días. ¿Cuánto pagas?

- 2,000
- ✔ 3,000
- 2,100

*¡Correcto! 100 por 30.*

**M3 U03 P2.** Un prestamista te amenaza. ¿Qué haces?

- ✔ Guardas evidencia y denuncias
- Pides otro préstamo para pagarle rápido
- No dices nada a nadie

*¡Correcto! Las amenazas son delito.*

**M3 U03 P3.** ¿Qué es una señal de préstamo peligroso?

- Contrato por escrito
- Aparece en el SIPRES
- ✔ Pagos diarios sin contrato

*¡Correcto! Es la trampa típica.*

**M3 U04 P1.** Con la avalancha, ¿cuál pagas primero?

- ✔ La más cara
- La más chica
- La más reciente

*¡Correcto! Ahorras intereses.*

**M3 U04 P2.** No podrás pagar la próxima semana. ¿Qué haces?

- Esperas a que te llamen de cobranza
- ✔ Negocias antes y pides el acuerdo por escrito
- Pides otro préstamo

*¡Correcto! Evitas cargos.*

**M3 U04 P3.** ¿Qué haces con lo que pagabas a una deuda terminada?

- Te lo gastas en algo que te guste
- Lo guardas debajo del colchón
- ✔ Lo sumas a la siguiente deuda

*¡Correcto! Así aceleras.*

**M3 U05 P1.** Perdiste en las apuestas este mes. ¿Qué haces?

- Apuestas más para recuperarlo
- ✔ Paras y revisas tu presupuesto
- Pides un préstamo rápido

*¡Correcto! Recuperar es la trampa.*

**M3 U05 P2.** ¿Cuál es una señal de que el juego ya es un problema?

- Apostar una vez al año en la quiniela de la oficina
- Revisar los resultados del partido
- ✔ Apostar con préstamos o tarjeta

*¡Correcto! Deuda segura.*

**M3 U05 P3.** ¿Qué revisas antes de registrarte en una app de apuestas?

- ✔ Que tenga permiso de la Secretaría de Gobernación
- Que tenga muchos anuncios
- Que el bono sea grande

*¡Correcto! Sin permiso no hay a quién reclamar.*

## Módulo 4

**M4 U01 P1.** Tanda de 8 personas con 400 cada quincena. ¿Cuánto cobra cada una?

- ✔ 3,200
- 400
- 4,000

*¡Correcto! 400 por 8.*

**M4 U01 P2.** Cobraste primero. ¿Qué tienes?

- Una ganancia
- ✔ Una deuda con el grupo
- Un ahorro protegido por el banco

*¡Correcto! Debes los pagos.*

**M4 U01 P3.** ¿Cuál es el mayor riesgo de una tanda?

- Los intereses que cobra
- ✔ Que alguien deje de pagar
- Que el banco la cancele

*¡Correcto! Pierden los demás.*

**M4 U02 P1.** ¿Quién debe tener los primeros turnos?

- Quien los pida primero
- ✔ Personas de confianza
- Un desconocido que los necesite con urgencia

*¡Correcto! Menos riesgo.*

**M4 U02 P2.** ¿Cómo registras los pagos?

- ✔ Con transferencia o foto
- De memoria
- No hace falta

*¡Correcto! Queda prueba.*

**M4 U02 P3.** Puedes apartar 200 cada quincena sin problema. ¿Qué te conviene?

- Solo entrar a más tandas
- Esperar a que sobre
- ✔ Ahorrar también en una cuenta aparte

*¡Correcto! Protegido y tuyo.*

**M4 U03 P1.** ¿Dónde revisas tus puntos y tu ahorro de vivienda?

- Con un gestor
- En tu banco
- ✔ En Mi Cuenta Infonavit con tu NSS

*¡Correcto! Sitio oficial.*

**M4 U03 P2.** Alguien te cobra por «sacarte» tu crédito Infonavit. ¿Qué haces?

- ✔ No pagas: el trámite no tiene costo
- Pagas la mitad
- Le das tu contraseña para agilizar

*¡Correcto! Sin intermediarios.*

**M4 U03 P3.** ¿Qué revisas antes de firmar un crédito de vivienda?

- Solo el color de la casa
- ✔ Cuánto te descontarán de la quincena y si te alcanza
- Lo que opine el vendedor

*¡Correcto! Tu presupuesto manda.*

## Módulo 5

**M5 U01 P1.** ¿Qué es el Buró de Crédito?

- Una lista negra de personas que no pagan sus deudas
- ✔ Un historial de tus créditos y pagos
- Un banco

*¡Correcto! Guarda lo bueno y lo malo.*

**M5 U01 P2.** ¿Quién decide si te prestan?

- ✔ La institución que presta
- El Buró
- El gobierno

*¡Correcto! El Buró solo informa.*

**M5 U01 P3.** ¿Qué mejora tu historial?

- Pedir muchos créditos
- Cancelar todas tus tarjetas
- ✔ Pagar a tiempo

*¡Correcto! Los pagos puntuales cuentan.*

**M5 U02 P1.** ¿Cuántos reportes sin costo puedes pedir al año?

- Ninguno
- Uno en total, en cualquiera de las dos
- ✔ Uno en Buró y uno en Círculo

*¡Correcto! Uno en cada una.*

**M5 U02 P2.** Hay un crédito que no es tuyo. ¿Qué haces?

- ✔ Lo reclamas
- Lo pagas para que se borre
- Lo ignoras

*¡Correcto! Reclamar no tiene costo.*

**M5 U02 P3.** ¿Dónde pides tu reporte?

- En la página que te llegó por mensaje
- ✔ En los sitios oficiales
- Con un gestor

*¡Correcto! Evitas fraudes.*

**M5 U03 P1.** Te ofrecen «limpiar tu Buró» por dinero. ¿Qué es?

- Un servicio legítimo si tienen oficina
- ✔ Un engaño: nadie borra lo correcto
- Un trámite del gobierno

*¡Correcto! No pueden borrar lo correcto.*

**M5 U03 P2.** Tu tarjeta es de 9,000. ¿Cuánto conviene deber como máximo?

- ✔ 3,000
- 9,000
- 8,000

*¡Correcto! Un tercio.*

**M5 U03 P3.** ¿Qué te ayuda a pagar a tiempo?

- Esperar a que te llamen
- ✔ Recordatorios en tu celular
- Pedir otro crédito

*¡Correcto! No se te pasa la fecha.*

**M5 U04 P1.** Diste tu nombre y teléfono como referencia para la tarjeta de un amigo. ¿Te pueden cobrar?

- Sí, la mitad
- Sí, si él no paga
- ✔ No, solo diste tus datos

*¡Correcto! La referencia no se obliga.*

**M5 U04 P2.** ¿Quién responde por todo el contrato como si hubiera pedido el crédito?

- ✔ El obligado solidario
- La referencia personal
- El vendedor

*¡Correcto! Por eso le pueden cobrar directo.*

**M5 U04 P3.** Un despacho te presiona para pagar una deuda de la que solo eres referencia. ¿Qué haces?

- Pagas para que dejen de llamar
- ✔ No pagas y te quejas en el REDECO
- Das los datos de tu amigo y los de su familia

*¡Correcto! No pueden cobrar a referencias.*

## Módulo 6

**M6 U01 P1.** Te piden el código que te llegó «para cancelar un cargo». ¿Qué haces?

- Lo das si la persona sabe tu nombre completo
- ✔ Cuelgas y llamas a tu banco
- Das la mitad

*¡Correcto! El banco no pide códigos.*

**M6 U01 P2.** ¿Qué haces con un mensaje de paquetería que no esperas?

- ✔ Lo borras
- Pagas los 30 pesos
- Abres el enlace

*¡Correcto! Buscan tu tarjeta.*

**M6 U01 P3.** Un familiar con número nuevo te pide dinero. ¿Qué haces?

- Envías para ayudar
- Le preguntas por mensaje si es él
- ✔ Le llamas a su número de siempre

*¡Correcto! Confirma por un medio conocido.*

**M6 U02 P1.** Una app de préstamos pide acceso a tus contactos. ¿Qué haces?

- La instalas si el préstamo es chico
- ✔ No la instalas
- Le das acceso solo un día

*¡Correcto! Los contactos son para extorsionarte.*

**M6 U02 P2.** Te extorsionan por una app. ¿Qué recomienda la CONDUSEF?

- ✔ No pagar y denunciar
- Pagar para que se detengan
- Pedir otro préstamo

*¡Correcto! Pagar la alimenta.*

**M6 U02 P3.** ¿Dónde verificas a una financiera?

- En las reseñas de la tienda de apps
- ✔ En el SIPRES
- Con amigos

*¡Correcto! El registro oficial.*

**M6 U03 P1.** Te dicen que tienen a tu familiar y que no cuelgues. ¿Qué haces?

- ✔ Cuelgas y lo localizas
- Pagas rápido para que no le pase nada
- Negocias sin colgar

*¡Correcto! Localizar primero.*

**M6 U03 P2.** ¿Para qué sirve la palabra clave?

- Para tu banco
- ✔ Para confirmar que de verdad es tu familiar
- Para tu celular

*¡Correcto! Quien no la sabe, no es tu familiar.*

**M6 U03 P3.** ¿A dónde denuncias una extorsión?

- A la CONDUSEF
- A tu banco
- ✔ Al 089 o al 911

*¡Correcto! Son los números de denuncia y emergencia.*

**M6 U04 P1.** Ves un cargo que no hiciste. ¿Qué haces primero?

- ✔ Bloqueas la tarjeta
- Esperas al estado de cuenta
- Llamas al número del mensaje

*¡Correcto! Frena el daño.*

**M6 U04 P2.** ¿A dónde reportas delitos en línea?

- ✔ Al 088
- Al 070
- A tu jefe

*¡Correcto! Recibe delitos en línea.*

**M6 U04 P3.** ¿Qué guardas como evidencia?

- Solo tu estado de cuenta del mes
- ✔ Capturas, fechas, montos y folios
- Nada

*¡Correcto! Ayudan a reclamar.*

**M6 U05 P1.** ¿Cuánto cuesta inscribirte en el REPEP?

- ✔ Nada
- 150 pesos al año
- Lo que cobre tu compañía de celular

*¡Correcto! No tiene costo.*

**M6 U05 P2.** ¿Qué haces con la copia de tu INE que entregas?

- La entregas limpia para que no la rechacen
- ✔ Le escribes para qué es y la fecha
- Mandas mejor una foto por WhatsApp

*¡Correcto! Así no sirve para otra cosa.*

**M6 U05 P3.** Después de registrarte en el REUS, te llama alguien «del banco» pidiendo un código. ¿Qué es?

- Una llamada normal del banco
- Un error del registro
- ✔ Casi seguro un fraude: cuelga y llama tú

*¡Correcto! Los registros no frenan fraudes.*

**M6 U06 P1.** Te llega un audio con la voz de tu hija pidiendo dinero urgente. ¿Qué haces?

- Depositas: es su voz
- ✔ Cuelgas y la llamas tú al número guardado
- Respondes el audio pidiendo el número de cuenta

*¡Correcto! Confirma por otro medio.*

**M6 U06 P2.** ¿Para qué sirve una palabra clave familiar?

- ✔ Para confirmar que es tu familiar de verdad
- Para entrar al banco
- Para desbloquear el celular

*¡Correcto! Si no la dice, no es.*

**M6 U06 P3.** Un famoso recomienda en video una inversión que duplica tu dinero. ¿Qué es?

- Una oportunidad real
- Una inversión segura del gobierno
- ✔ Casi seguro un video falso y un fraude

*¡Correcto! Nadie duplica dinero.*

## Módulo 7

**M7 U01 P1.** ¿Dónde guardas tu fondo?

- En una tanda con tus compañeros
- ✔ En una cuenta aparte
- Prestado a un amigo

*¡Correcto! Seguro y disponible.*

**M7 U01 P2.** Apartas 150 por quincena. ¿En cuántas quincenas juntas 1,500?

- ✔ 10
- 15
- 5

*¡Correcto! 1,500 entre 150.*

**M7 U01 P3.** Usaste tu fondo. ¿Qué haces?

- Lo dejas así
- Pides prestado para llenarlo
- ✔ Lo repones antes de otros gastos

*¡Correcto! Es tu primera protección.*

**M7 U02 P1.** ¿Cuándo averiguas a dónde ir en una emergencia?

- ✔ Antes de que pase
- Cuando pase
- Nunca

*¡Correcto! No hay tiempo en la emergencia.*

**M7 U02 P2.** ¿Qué es un medicamento genérico?

- ✔ Uno con la misma sustancia que suele costar menos
- Uno de menor calidad y más barato
- Uno sin receta

*¡Correcto! Misma sustancia.*

**M7 U02 P3.** ¿Dónde guardas los documentos de tu familia?

- Sueltos en casa
- En la cartera del turno
- ✔ En una carpeta a la mano

*¡Correcto! Los encuentras rápido.*

**M7 U03 P1.** ¿Quién recibe el dinero de tu seguro si faltas?

- ✔ Tus beneficiarios
- La aseguradora
- Tu jefe

*¡Correcto! Por eso deben estar claros.*

**M7 U03 P2.** Te ofrecen un plan funerario sin contrato. ¿Qué haces?

- Lo contratas porque es barato
- Pagas solo el primer mes
- ✔ Buscas uno con póliza de una aseguradora autorizada

*¡Correcto! Evita fraudes.*

**M7 U03 P3.** ¿Dónde verificas una aseguradora?

- ✔ En la CNSF
- En sus anuncios de redes
- Con el vendedor

*¡Correcto! Es la autoridad de seguros.*

**M7 U04 P1.** ¿Dónde guardas tu fondo de emergencia?

- Todo en efectivo en la casa
- ✔ En una cuenta que puedas usar desde la app o el cajero
- Con un vecino de confianza

*¡Correcto! Disponible aunque pierdas la casa.*

**M7 U04 P2.** Alguien te cobra por anotarte en un apoyo del gobierno. ¿Qué es?

- ✔ Un fraude: los apoyos no tienen costo
- Un trámite normal
- Una comisión del banco

*¡Correcto! Nadie cobra.*

**M7 U04 P3.** ¿Qué te sirve para reclamar al seguro?

- Recordar lo que tenías
- El testimonio de un vecino
- ✔ Fotos de tus cosas y la póliza

*¡Correcto! Prueba de lo perdido.*

**M7 U05 P1.** ¿Cuánto cuesta en 2026 el seguro familiar del IMSS para una persona de 65 años?

- 9,300
- 13,800
- ✔ 19,800

*¡Correcto! De 60 a 69 años.*

**M7 U05 P2.** ¿Qué NO da el Seguro de Salud para la Familia?

- ✔ Pensión
- Consultas
- Medicinas

*¡Correcto! Solo es salud.*

**M7 U05 P3.** ¿Dónde se atiende sin costo quien no tiene seguridad social?

- En farmacias privadas
- ✔ En el centro de salud
- En cualquier hospital privado

*¡Correcto! O IMSS-Bienestar.*

**M7 U06 P1.** ¿Qué pasa si nombras beneficiarios en tu cuenta?

- ✔ Reciben el dinero sin juicio
- Pagan más impuestos cuando lo reciben
- No cambia nada

*¡Correcto! Es lo más rápido.*

**M7 U06 P2.** ¿Qué mes tiene descuentos para hacer testamento?

- Enero
- ✔ Septiembre
- Diciembre

*¡Correcto! Mes del Testamento.*

**M7 U06 P3.** ¿Qué puedes nombrar en tu testamento?

- Solo tu cuenta de banco y ninguna otra cosa más
- Tu número de NIP
- ✔ Quién cuidaría a tus hijos menores

*¡Correcto! Un tutor.*

**M7 U07 P1.** ¿Cuánto ISR pagas por recibir una herencia?

- 30%
- 10%
- ✔ Nada, está exenta

*¡Correcto! Artículo 93 de la Ley del ISR.*

**M7 U07 P2.** ¿Quién paga las deudas de alguien que falleció si no alcanza lo que dejó?

- ✔ Nadie de la familia, salvo el aval
- Sus hijos, con su propio dinero y sus ahorros
- Sus vecinos

*¡Correcto! Se paga con lo que dejó.*

**M7 U07 P3.** ¿Con qué se heredan los derechos de una parcela ejidal?

- Con un recibo de luz
- ✔ Con la lista de sucesión
- Con una carta escrita a mano por el ejidatario

*¡Correcto! Se registra en el RAN.*

## Módulo 8

**M8 U01 P1.** ¿Desde cuánto puedes aportar a tu AFORE en tiendas?

- ✔ 50 pesos
- 1,000 pesos
- 500 pesos

*¡Correcto! Desde 50.*

**M8 U01 P2.** ¿Cómo sabes en qué AFORE estás?

- Preguntas en tu trabajo o a un gestor que cobra poco
- ✔ Con tu CURP en e-SAR
- No se puede saber

*¡Correcto! No tiene costo.*

**M8 U01 P3.** Te ofrecen un regalo por cambiarte de AFORE. ¿Qué haces?

- Te cambias por el regalo
- Aceptas y regresas luego
- ✔ Comparas rendimientos primero

*¡Correcto! El regalo no mejora tu retiro.*

**M8 U02 P1.** Cobras 1,500 a la semana y gastas 500 en materiales. ¿Cuál es tu ganancia?

- ✔ 1,000
- 1,500
- 2,000

*¡Correcto! 1,500 menos 500.*

**M8 U02 P2.** ¿Cómo conviene empezar un ingreso extra?

- Con un préstamo grande para crecer rápido
- ✔ Con poco, sin deudas caras
- Con la tarjeta de un amigo

*¡Correcto! Menos riesgo.*

**M8 U02 P3.** Ganas 1,200 en 15 horas. ¿Cuánto por hora?

- 1,200
- 120
- ✔ 80

*¡Correcto! 1,200 entre 15.*

**M8 U03 P1.** ¿Cada cuándo revisas tu plan?

- Una vez al año, en diciembre
- ✔ Cada día de pago
- Nunca

*¡Correcto! Cinco minutos cada quincena.*

**M8 U03 P2.** ¿Qué va en tu plan?

- Tu NIP
- Tus contraseñas
- ✔ Tu presupuesto, deudas, ahorro, protección y AFORE

*¡Correcto! Son sus partes.*

**M8 U03 P3.** Terminaste una deuda. ¿Qué haces?

- ✔ Lo anotas y sumas ese pago a la siguiente
- Pides otro crédito para celebrar
- Nada

*¡Correcto! Así avanzas más rápido.*
