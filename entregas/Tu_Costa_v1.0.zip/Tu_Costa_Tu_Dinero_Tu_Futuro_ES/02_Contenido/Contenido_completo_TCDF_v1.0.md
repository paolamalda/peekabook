# Tu Costa, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Don Mel | 58 años. Pescador en Punta Maldonado, Guerrero. Tiene lancha propia y vende a un comprador del pueblo. |
| Doña Chepa | 50 años. Vende pescado y comida en Collantes, Oaxaca. Su hijo le manda dinero desde Carolina del Norte. |
| Yesenia | 29 años. Trabaja en un restaurante de playa en Marquelia; en temporada baja casi no hay trabajo. |
| Julián | 34 años. Siembra limón y ajonjolí en Cuajinicuilapa con su papá. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Tu plan de dinero ante huracanes | Tu plan de dinero para antes y después de un huracán. |  |
| Módulo 2. Tus documentos a salvo | Tus documentos importantes protegidos y respaldados. |  |
| Módulo 3. El ingreso de temporada, mes a mes | Tu calendario de ingresos del año y lo que apartas en temporada buena. | Año completo |
| Módulo 4. Fondo de emergencia y seguro de vivienda | Tu fondo de emergencia en marcha y tu decisión sobre el seguro de vivienda. | Casa protegida |
| Módulo 5. Crédito para tu actividad | Tu comparación del costo total de cualquier crédito o adelanto. | Crédito claro |
| Módulo 6. Tus derechos y cómo reclamar | Tu forma de pedir un trato digno y de reclamar con folio. | Trato digno |
| Módulo 7. Remesas que rinden | Tu forma de recibir remesas con menos comisión y con un plan. | Remesa que rinde |
| Módulo 8. Tu patrimonio y tu herencia | Tus papeles de casa y terreno en orden y tu decisión sobre la herencia. | Patrimonio en orden |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Plan ante huracanes, Ingreso de temporada, Crédito y costo total, Derechos y reclamos, Patrimonio.

## 3. Lecciones

# Parte 2. Módulo 1. Tu plan de dinero ante huracanes

## M1 U01. Antes de la temporada: tu plan de dinero

**Lo que lograrás:** Preparar un plan de dinero sencillo antes de que empiece la temporada de huracanes.

**Para empezar:** Cuando pasó el último huracán, Don Mel perdió su motor y tardó tres meses en volver a pescar. No tenía nada apartado y pidió prestado al comprador. En esta lección harás tu plan antes de que llegue el próximo.

### Lo esencial (5 minutos)

#### La temporada tiene fecha

En el Pacífico, la temporada de huracanes va del **15 de mayo al 30 de noviembre**, y lo más fuerte suele ser de agosto a octubre. Hay tiempo para prepararse.



#### Tu plan tiene cuatro partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Papeles | En bolsa cerrada y con copias. | Módulo 2. |
| Guardadito | Dinero apartado para la emergencia. | Módulo 4. |
| Contactos | Banco, aseguradora, familia, Protección Civil. | En papel. |
| Lo que te da de comer | Lancha, motor, herramientas, mercancía. | Cómo lo proteges. |

#### Un poco de efectivo

Después de un huracán puede no haber luz ni cajeros por días. Ten algo de efectivo para comida y agua en un lugar seguro.



#### Un caso en un minuto

Este año Don Mel apartó un poco de cada venta desde marzo. En mayo guardó sus papeles en una bolsa cerrada y anotó los teléfonos. Ya sabe dónde subirá su motor si hay aviso.

> **Idea clave:** antes del 15 de mayo, junta papeles, un guardadito, tus contactos y un plan para lo que te da de comer.



#### Comprueba lo que entendiste

1. ¿Cuándo empieza la temporada de huracanes en el Pacífico?
*Respuesta:* El 15 de mayo, y termina el 30 de noviembre.

2. ¿Por qué tener algo de efectivo?
*Respuesta:* Porque después del huracán puede no haber luz ni cajeros por días.


#### Para recordar

- Del 15 de mayo al 30 de noviembre.
- Papeles, guardadito, contactos.
- Algo de efectivo.



### Profundiza (5 minutos más)

#### Mi plan de temporada

| Parte | Qué hago | Listo |
|---|---|---|
| Papeles | | |
| Guardadito | | |
| Contactos en papel | | |
| Lo que me da de comer | | |
| Efectivo para tres días | | |



#### Escucha los avisos oficiales

Sigue los avisos del Servicio Meteorológico Nacional y de Protección Civil. Un aviso con tiempo te deja proteger tu lancha, tu mercancía o tu cosecha.



#### Casos


**Caso 1. Sin nada apartado**

Don Mel perdió su motor y no tenía ahorro.
- *¿Qué hace este año?* Aparta un poco de cada venta desde antes de mayo.


**Caso 2. Los papeles en el ropero**

Doña Chepa guarda sus escrituras en un cajón de madera.
- *¿Qué hace?* Los mete en una bolsa cerrada y saca copias.


**Caso 3. Todo en la tarjeta**

Yesenia tiene su dinero solo en la tarjeta.
- *¿Qué hace?* Guarda también un poco de efectivo para los primeros días.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar al aviso | No da tiempo | Prepárate antes de mayo |
| No apartar nada | Préstamos caros | Un poco de cada venta |
| Contactos solo en el celular | Sin batería, sin contactos | En papel |
| Todo en la tarjeta | Sin cajeros, sin dinero | Algo de efectivo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Mel, Doña Chepa y Yesenia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuándo termina la temporada de huracanes en el Pacífico? a) El 30 de noviembre · b) El 15 de mayo · c) En enero, con el año nuevo
2. ¿Cuándo preparas tu plan? a) Cuando ya está el aviso de huracán · b) Después del huracán · c) Antes del 15 de mayo
3. ¿Por qué guardar un poco de efectivo? a) Por si se va la luz y no hay cajeros · b) Porque el banco cierra en temporada · c) Para pagarle al comprador antes de que suba el precio
**Respuestas:** 1-a: 30 de noviembre. 2-c: antes de la temporada. 3-a: sin luz no hay cajeros.



#### Ponlo en práctica

Apartas 100 pesos de cada una de tus 3 ventas por semana desde marzo hasta mediados de mayo (10 semanas). ¿Cuánto juntas?
**Respuesta:** 3,000 pesos.



#### A tu plan

Llena tu plan de temporada y marca lo que ya tienes listo.



### Para saber más

- **Avisos de ciclones** (SMN · español): https://smn.conagua.gob.mx — **Qué buscar:** «ciclones tropicales».
- **Protección Civil** (Gobierno de México · español): https://www.gob.mx/cenapred — **Qué buscar:** «plan familiar de protección civil».

### Palabras clave

- *Temporada de huracanes:* meses en que se forman más huracanes.
- *Guardadito:* dinero apartado para una emergencia.
- *Aviso:* alerta oficial de que viene un fenómeno.

### Fuentes

SMN, temporada de ciclones tropicales 2026 en el Pacífico; CENAPRED; consultados el 5 de octubre de 2026.

---

## M1 U02. Después del huracán: sin prisas ni préstamos caros

**Lo que lograrás:** Tomar decisiones de dinero después de un desastre sin caer en préstamos caros ni fraudes.

**Para empezar:** Después del huracán, a Doña Chepa le ofrecieron «un préstamo de reconstrucción sin papeles». También le llegó un mensaje para «registrarse al apoyo» pagando 300 pesos. En esta lección verás qué hacer en los días difíciles.

### Lo esencial (5 minutos)

#### Los primeros días, en orden

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1. Tu familia | Salud, agua, comida. | Primero. |
| 2. Fotos de los daños | Casa, lancha, mercancía. | Para reclamar y para apoyos. |
| 3. Avisa | Aseguradora, banco si tienes crédito. | Pide folio. |
| 4. Apoyos oficiales | Pregunta en tu municipio. | Sin pagar a nadie. |

#### Los registros a apoyos no se cobran

Los censos y registros para apoyos después de un desastre los hace el gobierno sin costo. Si te piden dinero para registrarte, es fraude.



#### Habla con quien le debes

Si tienes un crédito, llama al banco o a la institución y explica lo que pasó. Pregunta si hay prórroga o un plan especial. Hazlo antes de atrasarte.



#### Un caso en un minuto

Doña Chepa tomó fotos de su puesto dañado, no pagó los 300 pesos y fue al módulo del municipio. Llamó a la tienda donde debía y le dieron un mes más.

> **Idea clave:** después del desastre, primero tu familia; toma fotos, avisa con folio y no pagues por apoyos ni tomes préstamos de prisa.



#### Comprueba lo que entendiste

1. ¿Te cobran por registrarte a un apoyo oficial?
*Respuesta:* No; si piden dinero, es fraude.

2. ¿Qué haces si tienes un crédito y el huracán te afectó?
*Respuesta:* Llamo antes de atrasarme y pregunto por prórroga o plan especial.


#### Para recordar

- Familia primero.
- Fotos y folios.
- Los apoyos no se cobran.



### Profundiza (5 minutos más)

#### Espera antes de decidir grande

Después de un desastre todo urge. Si no es comida, agua o salud, espera unos días antes de firmar préstamos o vender tus cosas.



#### Fotos con fecha

Las fotos del celular guardan la fecha. Mándalas por mensaje a un familiar para que queden respaldadas.



#### Casos


**Caso 1. El préstamo sin papeles**

Le ofrecen a Doña Chepa un préstamo de reconstrucción sin papeles.
- *¿Qué hace?* Espera, pregunta el costo total y busca primero los apoyos oficiales.


**Caso 2. El registro con cuota**

Le piden 300 pesos para registrarse a un apoyo.
- *¿Qué hace?* No paga y va al módulo oficial del municipio.


**Caso 3. El crédito de la lancha**

Don Mel no podrá pagar este mes el crédito de su lancha.
- *¿Qué hace?* Llama antes de atrasarse y pide una prórroga.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por registrarte | Fraude | Es sin costo |
| Firmar préstamos de prisa | Deuda cara | Espera unos días |
| No tomar fotos | Te cuesta reclamar | Fotos con fecha |
| Esperar a atrasarte | Cargos extra | Llama antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa y Don Mel. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te cobran por registrarte a un apoyo después del huracán. ¿Qué es? a) Normal · b) Fraude · c) Una cuota de recuperación oficial
2. ¿Qué haces primero después del huracán? a) Vendes tu lancha · b) Firmas un préstamo de reconstrucción ese mismo día · c) Cuidas a tu familia: salud, agua y comida
3. Tienes un crédito y no podrás pagar. ¿Cuándo llamas? a) Cuando te llamen a cobrar · b) Antes de atrasarte · c) Nunca
**Respuestas:** 1-b: los registros oficiales no se cobran. 2-c: familia primero. 3-b: antes.



#### Ponlo en práctica

Escribe los cuatro pasos de los primeros días en orden.
**Respuesta:** Familia, fotos de los daños, avisar con folio y preguntar por apoyos oficiales.



#### A tu plan

Anota en tu plan de temporada el teléfono de tu municipio y de tu banco o aseguradora.



### Para saber más

- **Fraudes después de desastres** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «desastres naturales».
- **Protección Civil** (CENAPRED · español): https://www.gob.mx/cenapred — **Qué buscar:** las alertas de tu zona y cómo armar tu plan familiar de emergencia.

### Palabras clave

- *Censo:* registro oficial de personas afectadas.
- *Prórroga:* más tiempo para pagar.
- *Folio:* número que comprueba tu reporte.

### Fuentes

CONDUSEF, recomendaciones ante desastres naturales; CENAPRED; consultados el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Tus documentos a salvo

## M2 U01. Tus papeles en una bolsa

**Lo que lograrás:** Proteger tus documentos importantes del agua y respaldarlos con copias.

**Para empezar:** El huracán metió agua a la casa de Julián. Las escrituras del terreno y las actas de nacimiento quedaron hechas pulpa. Reponerlas le costó viajes y dinero. En esta lección protegerás tus papeles.

### Lo esencial (5 minutos)

#### Los papeles que importan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Identidad | Actas, INE, CURP. | De toda la familia. |
| Casa y terreno | Escrituras, certificados ejidales, constancias. | Lo que comprueba que es tuyo. |
| Tu actividad | Permisos de pesca, facturas de lancha y motor. | Lo que te da de comer. |
| Dinero | Contratos de cuenta, pólizas de seguro. | Con teléfonos. |

#### Bolsa cerrada y en alto

Mete los originales en una bolsa de plástico que cierre bien, y esa bolsa en otra. Guárdala en alto y lista para llevártela si hay que salir.



#### Copias en otro lugar

Saca fotos de cada papel y mándalas a un familiar que viva en otro lugar, o guárdalas en tu correo. Una copia ayuda mucho a reponer el original.



#### Un caso en un minuto

Julián repuso sus papeles, los metió en doble bolsa y le mandó fotos a su hermana en Acapulco. La siguiente temporada, la bolsa salió con él cuando evacuaron.

> **Idea clave:** originales en doble bolsa cerrada y en alto, y fotos guardadas fuera de tu casa.



#### Comprueba lo que entendiste

1. ¿Cómo guardas los originales?
*Respuesta:* En doble bolsa cerrada, en alto y lista para llevártela.

2. ¿Dónde guardas las copias?
*Respuesta:* Fotos con un familiar en otro lugar o en mi correo.


#### Para recordar

- Doble bolsa.
- En alto.
- Fotos fuera de casa.



### Profundiza (5 minutos más)

#### Mi bolsa de papeles

| Papel | En la bolsa | Foto respaldada |
|---|---|---|
| Actas de nacimiento | | |
| INE y CURP | | |
| Escrituras o certificado ejidal | | |
| Permisos y facturas de trabajo | | |
| Contratos y pólizas | | |



#### Copias seguras

No publiques fotos de tus papeles en redes ni las mandes a desconocidos. Solo a familiares de confianza o a tu correo.



#### Casos


**Caso 1. Las escrituras mojadas**

Julián perdió sus escrituras en la inundación.
- *¿Qué hace para la próxima?* Guarda originales en doble bolsa y respalda fotos.


**Caso 2. Las fotos en grupo**

Yesenia quiere subir fotos de sus papeles al grupo de la colonia «por si acaso».
- *¿Qué hace?* Las manda solo a un familiar de confianza.


**Caso 3. La factura del motor**

Don Mel no tiene la factura de su motor en ningún lado.
- *¿Qué hace?* La pide al vendedor y la agrega a su bolsa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Papeles en cajones bajos | Se mojan | En alto |
| Sin copias | Reponer es difícil | Fotos respaldadas |
| Fotos en redes | Robo de identidad | Solo familia |
| Olvidar papeles de trabajo | No compruebas tu pérdida | Inclúyelos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Julián, Yesenia y Don Mel. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde guardas tus originales? a) En un cajón bajo de madera · b) En doble bolsa cerrada y en alto · c) En la lancha, que es donde pasas más tiempo
2. ¿A quién mandas las fotos de tus papeles? a) A quien te las pida · b) Al grupo de la colonia, por si alguien las necesita · c) A un familiar de confianza
3. ¿Qué papel sirve para comprobar que tu lancha es tuya? a) Tu credencial del INE con tu domicilio en la costa · b) La factura de la lancha · c) Un recibo de luz
**Respuestas:** 1-b: protegidos del agua. 2-c: solo confianza. 3-b: la factura.



#### Ponlo en práctica

Nombra tres papeles que van en tu bolsa.
**Respuesta:** Ejemplo: actas de nacimiento, INE y escrituras o certificado ejidal.



#### A tu plan

Arma tu bolsa de papeles esta semana y manda fotos a un familiar.



### Para saber más

- **Plan familiar** (CENAPRED · español): https://www.gob.mx/cenapred — **Qué buscar:** «documentos importantes».

### Palabras clave

- *Original:* el papel verdadero.
- *Respaldo:* copia guardada en otro lugar.
- *Certificado ejidal:* papel que acredita tus derechos en el ejido.

### Fuentes

CENAPRED, plan familiar de protección civil; consultado el 5 de octubre de 2026.

---

## M2 U02. Si perdiste tus papeles

**Lo que lograrás:** Identificar dónde reponer tus documentos más importantes después de perderlos.

**Para empezar:** Doña Chepa perdió su INE y las actas de sus hijos en el huracán. Le dicen que sin INE no puede cobrar en el banco ni pedir el apoyo. En esta lección verás por dónde empezar.

### Lo esencial (5 minutos)

#### Dónde se repone cada papel

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Acta de nacimiento | En gob.mx/actas con tu CURP. | O en el Registro Civil. |
| INE | En el módulo del INE. | El trámite es sin costo. |
| CURP | En gob.mx/curp. | Sin costo. |
| Escrituras | En la notaría o el Registro Público. | Pide copia certificada. |

#### Empieza por la CURP y el acta

Con la CURP sacas el acta en línea. Con el acta y un comprobante de domicilio repones la INE. Así, en orden, cada papel abre el siguiente.



#### Después de un desastre

A veces el INE y el Registro Civil abren módulos especiales en zonas afectadas. Pregunta en tu municipio.



#### Un caso en un minuto

Doña Chepa sacó su CURP y el acta en un ciber, pidió constancia de domicilio en la agencia municipal y fue al módulo del INE. En el banco le aceptaron su comprobante de trámite mientras tanto.

> **Idea clave:** repón en orden: CURP, acta e INE; pregunta por módulos especiales después del desastre.



#### Comprueba lo que entendiste

1. ¿Por qué papel empiezas?
*Respuesta:* Por la CURP y el acta.

2. ¿Cuánto cuesta reponer la INE?
*Respuesta:* Nada; el trámite es sin costo.


#### Para recordar

- CURP y acta primero.
- INE sin costo.
- Pregunta por módulos especiales.



### Profundiza (5 minutos más)

#### Guarda el comprobante de trámite

Mientras llega tu nueva INE, guarda el comprobante que te dan en el módulo. Pregunta en tu banco si lo aceptan para cobrar.



#### Papeles ejidales

Si perdiste tu certificado ejidal, pide una reposición en el Registro Agrario Nacional.



#### Casos


**Caso 1. Sin INE**

Doña Chepa perdió su INE.
- *¿Qué hace?* Saca su CURP y acta y va al módulo del INE.


**Caso 2. El gestor**

Le ofrecen a Yesenia reponer sus papeles por 800 pesos.
- *¿Qué hace?* Lo hace ella; la CURP y la INE son sin costo.


**Caso 3. El certificado ejidal**

El papá de Julián perdió su certificado ejidal.
- *¿Qué hace?* Pide la reposición en el Registro Agrario Nacional.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Empezar por la INE | Te falta el acta | CURP y acta primero |
| Pagar a gestores | Gasto de más | Hazlo tú |
| Tirar el comprobante | No cobras | Guárdalo |
| Olvidar el ejido | Pierdes el derecho | RAN |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa, Yesenia y Julián. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Por dónde empiezas a reponer papeles? a) Por las escrituras · b) Por la CURP y el acta · c) Por el pasaporte, que vale para todo
2. ¿Dónde repones un certificado ejidal? a) En el banco donde tienes tu cuenta · b) En la tienda · c) En el Registro Agrario Nacional
3. Te cobran 800 por reponer tu INE. ¿Qué haces? a) Pagas · b) Pagas la mitad ahora y la otra mitad al recibirla · c) Lo haces tú: es sin costo
**Respuestas:** 1-b: abren lo demás. 2-c: RAN. 3-c: sin costo.



#### Ponlo en práctica

Ordena los tres papeles: INE, CURP, acta.
**Respuesta:** CURP, acta, INE.



#### A tu plan

Revisa tu bolsa de papeles y anota cuáles tendrías que reponer y dónde.



### Para saber más

- **Acta en línea** (Gobierno de México · español): https://www.gob.mx/actas — **Qué buscar:** cómo obtener tu acta certificada con tu CURP y cuánto cuesta en tu estado.
- **CURP** (Gobierno de México · español): https://www.gob.mx/curp — **Qué buscar:** «Consulta tu CURP»: la consulta y la impresión no tienen costo.
- **Registro Agrario Nacional** (RAN · español): https://www.gob.mx/ran — **Qué buscar:** «reposición de certificado».

### Palabras clave

- *Reponer:* sacar de nuevo un papel perdido.
- *Copia certificada:* copia oficial que vale como el original.
- *Comprobante de trámite:* papel que muestra que pediste tu INE.

### Fuentes

INE; Gobierno de México, actas y CURP; Registro Agrario Nacional; consultados el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. El ingreso de temporada, mes a mes

## M3 U01. Tu calendario de ingresos

**Lo que lograrás:** Dibujar en un calendario los meses buenos y los meses bajos de tu ingreso.

**Para empezar:** Yesenia gana bien en Semana Santa, verano y diciembre. En septiembre y octubre casi no hay turistas y se endeuda cada año. Nunca ha visto su año completo. En esta lección lo harás.

### Lo esencial (5 minutos)

#### El año no es parejo

En la costa el ingreso sube y baja. La pesca depende de la temporada y del clima. La cosecha llega una o dos veces al año. Y el turismo tiene meses llenos y meses vacíos.



#### Marca tus meses

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Meses buenos | Entra más de lo que gastas. | Ahí se aparta. |
| Meses bajos | Entra menos de lo que gastas. | Ahí se usa lo apartado. |
| Meses de gasto fuerte | Escuela, fiestas, reparaciones. | Planéalos. |

#### Un calendario en una hoja

Dibuja los 12 meses. Pon en cada uno: alto, medio o bajo. Marca también los gastos fuertes, como el regreso a clases o el mantenimiento de la lancha.



#### Un caso en un minuto

Yesenia marcó en alto marzo-abril, julio-agosto y diciembre, y en bajo septiembre y octubre. Vio que necesita llegar a septiembre con dinero apartado.

> **Idea clave:** dibuja tu año: meses buenos, meses bajos y gastos fuertes; así sabes cuándo apartar y cuándo usar.



#### Comprueba lo que entendiste

1. ¿Qué haces en los meses buenos?
*Respuesta:* Aparto para los meses bajos.

2. ¿Qué marcas además de tus ingresos?
*Respuesta:* Los meses de gasto fuerte.


#### Para recordar

- Tu año no es parejo.
- Marca buenos y bajos.
- Planea los gastos fuertes.



### Profundiza (5 minutos más)

#### Mi calendario

| Mes | Ingreso (alto, medio, bajo) | Gasto fuerte |
|---|---|---|
| Enero | | |
| Febrero | | |
| Marzo | | |
| Abril | | |
| Mayo | | |
| Junio | | |
| Julio | | |
| Agosto | | |
| Septiembre | | |
| Octubre | | |
| Noviembre | | |
| Diciembre | | |



#### La temporada de huracanes cae en meses bajos

Para muchas familias de la costa, agosto a octubre junta menos ingreso y más riesgo. Por eso el guardadito del módulo 1 y el de los meses bajos pueden ser el mismo.



#### Casos


**Caso 1. Septiembre de cada año**

Yesenia se endeuda cada septiembre.
- *¿Qué hace?* Dibuja su año y aparta desde los meses buenos.


**Caso 2. La veda**

Don Mel no puede pescar ciertas especies en la veda.
- *¿Qué hace?* Marca la veda como mes bajo en su calendario.


**Caso 3. La cosecha de limón**

Julián cobra fuerte en la cosecha y se le va rápido.
- *¿Qué hace?* Marca los meses sin cosecha y reparte lo que cobra.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar que todos los meses son iguales | Te sorprenden los bajos | Dibuja el año |
| Olvidar gastos fuertes | Te endeudas | Márcalos |
| Gastar todo en los meses buenos | Nada para los bajos | Aparta |
| No contar la veda | Mes sin ingreso | Inclúyela |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Yesenia, Don Mel y Julián. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es un mes bajo? a) Un mes en que entra menos de lo que gastas · b) Un mes con muchas fiestas y compromisos en el pueblo · c) Un mes de vacaciones de la escuela
2. ¿Cuándo apartas dinero? a) En los meses bajos · b) Solo en diciembre, con el aguinaldo · c) En los meses buenos
3. ¿Qué marcas además del ingreso? a) Los gastos fuertes · b) Los cumpleaños de los vecinos · c) Nada más
**Respuestas:** 1-a: entra menos. 2-c: cuando sobra. 3-a: gastos fuertes.



#### Ponlo en práctica

Tienes 3 meses bajos y en cada uno te faltan 2,000. ¿Cuánto necesitas apartar en los meses buenos?
**Respuesta:** 6,000 pesos.



#### A tu plan

Llena tu calendario del año con tus meses altos, bajos y tus gastos fuertes.



### Para saber más

- **Presupuesto con ingreso variable** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ingresos variables».

### Palabras clave

- *Ingreso de temporada:* dinero que llega solo en ciertos meses.
- *Veda:* tiempo en que no se puede pescar una especie.
- *Gasto fuerte:* gasto grande que llega en un mes concreto.

### Fuentes

CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.

---

## M3 U02. Aparta en la temporada buena

**Lo que lograrás:** Separar una parte fija de lo que ganas en los meses buenos para cubrir los meses bajos.

**Para empezar:** En la cosecha, Julián cobró 30,000 pesos. En dos meses ya no tenía nada y faltaba medio año para la siguiente. En esta lección verás cómo repartir.

### Lo esencial (5 minutos)

#### Primero apartas, después gastas

Cuando cobras fuerte, separa de inmediato la parte para los meses bajos. Lo que queda es lo que puedes gastar ahora.



#### Tres formas de apartar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En tu cuenta | Una cuenta o un apartado aparte. | Que no uses la tarjeta de diario. |
| Sobres por mes | Un sobre por cada mes bajo. | En lugar seguro. |
| Ahorro en grupo con reglas | Una tanda bien organizada. | Con reglas claras. |

#### Divide entre los meses

Divide lo que cobraste entre los meses que tiene que durar. Ese es tu «sueldo» de cada mes, aunque el dinero haya llegado junto.



#### Un caso en un minuto

Julián dividió 30,000 entre 6 meses: 5,000 por mes. Apartó 25,000 en su cuenta y solo usa 5,000 cada mes. Por primera vez llegó a la siguiente cosecha sin deber.

> **Idea clave:** cuando cobras fuerte, divide entre los meses que debe durar y aparta antes de gastar.



#### Comprueba lo que entendiste

1. ¿Qué haces primero cuando cobras fuerte?
*Respuesta:* Aparto la parte de los meses bajos.

2. ¿Cómo sabes cuánto usar cada mes?
*Respuesta:* Divido lo que cobré entre los meses que debe durar.


#### Para recordar

- Primero apartas.
- Divide entre los meses.
- Un «sueldo» mensual.



### Profundiza (5 minutos más)

#### El sueldo de Julián

- Cosecha: **30,000**
- Meses hasta la siguiente: **6**
- Para cada mes: **5,000**


#### Si usas tanda

Una tanda puede servir para juntar en temporada buena. Que tenga reglas escritas, personas conocidas y un orden claro. Si alguien no paga, ¿qué pasa? Acuérdenlo antes.



#### Casos


**Caso 1. La cosecha que se fue**

Julián cobra 30,000 y en dos meses no tiene nada.
- *¿Qué hace?* Divide entre los meses y aparta antes de gastar.


**Caso 2. La tarjeta de diario**

Yesenia aparta en la misma tarjeta que usa diario y se lo gasta.
- *¿Qué hace?* Usa un apartado o cuenta distinta para su ahorro.


**Caso 3. La tanda sin reglas**

Doña Chepa quiere entrar a una tanda con gente que no conoce.
- *¿Qué hace?* Solo entra si hay reglas claras y conoce a las personas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar primero | No queda nada | Aparta primero |
| Apartar en la tarjeta de diario | Se gasta | Lugar distinto |
| Tanda sin reglas | Pierdes | Reglas escritas |
| No dividir | No sabes cuánto usar | Tu «sueldo» mensual |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Julián, Yesenia y Doña Chepa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Cobras 24,000 que deben durar 4 meses. ¿Cuánto usas por mes? a) 24,000 el primer mes · b) 6,000 · c) 4,000
2. ¿Qué haces primero al cobrar fuerte? a) Pagas la fiesta · b) Compras lo que te faltaba desde la temporada pasada · c) Apartas lo de los meses bajos
3. ¿Qué necesita una tanda para ser más segura? a) Mucha gente, aunque no la conozcas, para juntar más · b) Reglas claras y personas conocidas · c) Que nadie sepa el orden
**Respuestas:** 1-b: 24,000 entre 4. 2-c: primero apartas. 3-b: reglas y confianza.



#### Ponlo en práctica

Cobras 18,000 en la temporada de turismo y deben durar 3 meses. ¿Cuánto es tu sueldo mensual?
**Respuesta:** 6,000 pesos.



#### A tu plan

Para tu próximo cobro fuerte, escribe entre cuántos meses lo dividirás y dónde guardarás lo apartado.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ahorro» y «tandas».

### Palabras clave

- *Apartar:* separar dinero para después.
- *Tanda:* ahorro en grupo por turnos.
- *Sueldo mensual:* lo que te das para gastar cada mes.

### Fuentes

CONDUSEF, ahorro y tandas; consultado el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Fondo de emergencia y seguro de vivienda

## M4 U01. Tu fondo de emergencia

**Lo que lograrás:** Empezar un fondo de emergencia aunque sea poco, y usarlo solo para emergencias.

**Para empezar:** Doña Chepa tiene cuenta desde hace años porque ahí le llega el dinero de su hijo. Pero nunca deja nada: lo saca todo el mismo día. Cuando su refrigerador se descompuso, tuvo que empeñar su anillo. En esta lección empezarás tu fondo.

### Lo esencial (5 minutos)

#### Qué es un fondo de emergencia

Es dinero apartado solo para lo que no esperabas: una enfermedad, una reparación, un huracán. No es para fiestas ni compras. En México, solo 10.3% tiene ahorro para más de tres meses de su ingreso.



#### Cómo empezar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Una meta chica | Primero 1,000 pesos. | Luego un mes de gastos. |
| Poco y seguido | De cada venta o de cada envío. | Aunque sean 50. |
| Que no se mezcle | Un apartado o una cuenta aparte. | No la tarjeta de diario. |

#### Usa tu cuenta para guardar

Tener cuenta y no usarla para ahorrar es dejar una herramienta en el cajón. Deja una parte en la cuenta en lugar de sacarla toda.



#### Un caso en un minuto

Ahora Doña Chepa deja 300 pesos de cada envío de su hijo en la cuenta. En seis meses tiene 1,800. Cuando se descompuso la bomba de agua, no empeñó nada.

> **Idea clave:** empieza con una meta chica, aparta poco y seguido, y no lo mezcles con el dinero de diario.



#### Comprueba lo que entendiste

1. ¿Para qué es el fondo de emergencia?
*Respuesta:* Solo para lo que no esperabas, como una enfermedad, una reparación o un huracán.

2. ¿Cuál es una buena primera meta?
*Respuesta:* 1,000 pesos.


#### Para recordar

- Meta chica.
- Poco y seguido.
- Aparte del dinero diario.



### Profundiza (5 minutos más)

#### El fondo de Doña Chepa

- De cada envío: **300**
- Envíos: **6**
- En seis meses: **1,800**


#### Si lo usas, vuelve a llenarlo

Usar el fondo en una emergencia está bien: para eso es. Después, vuelve a apartar hasta llenarlo.



#### Casos


**Caso 1. Saca todo**

Doña Chepa saca todo el envío el mismo día.
- *¿Qué hace?* Deja una parte fija en la cuenta como fondo.


**Caso 2. Para la fiesta**

Yesenia quiere usar su fondo para la fiesta de su prima.
- *¿Qué hace?* Lo deja para emergencias y ahorra aparte para la fiesta.


**Caso 3. Usó el fondo**

Don Mel usó su fondo para arreglar el motor.
- *¿Qué hace?* Vuelve a apartar poco a poco para llenarlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No empezar porque es poco | Nunca empiezas | Meta chica |
| Mezclarlo | Se gasta | Aparte |
| Usarlo para gustos | No está cuando lo necesitas | Solo emergencias |
| No reponerlo | Te quedas sin fondo | Vuelve a llenarlo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa, Yesenia y Don Mel. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es un uso correcto del fondo? a) Una reparación urgente · b) Una fiesta · c) Un celular nuevo porque hay oferta
2. ¿Dónde guardas tu fondo? a) En la tarjeta de diario · b) Prestado a un vecino · c) En un apartado o cuenta aparte
3. Usaste tu fondo. ¿Qué haces después? a) Nada · b) Pides prestado para llenarlo de una vez · c) Vuelves a apartar poco a poco
**Respuestas:** 1-a: es emergencia. 2-c: aparte. 3-c: lo llenas.



#### Ponlo en práctica

Apartas 150 pesos por semana. ¿En cuántas semanas llegas a 1,500?
**Respuesta:** En 10 semanas.



#### A tu plan

Decide cuánto apartarás de cada venta o envío y dónde lo guardarás.



### Para saber más

- **Fondo de emergencia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Fondo de emergencia:* dinero solo para imprevistos.
- *Empeñar:* dejar algo a cambio de un préstamo.
- *Apartado:* espacio de tu cuenta para separar dinero.

### Fuentes

INEGI y CONDUSEF, ENSAFI 2023; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M4 U02. ¿Asegurar tu casa?

**Lo que lograrás:** Identificar qué preguntar sobre un seguro de vivienda y si cubre daños por huracán.

**Para empezar:** A Julián le ofrecieron un seguro de casa «contra todo». Después del huracán reclamó y le dijeron que no cubría inundación. En esta lección verás qué revisar antes de pagar.

### Lo esencial (5 minutos)

#### No todos cubren lo mismo

Un seguro de vivienda puede cubrir incendio, robo o daños por fenómenos como huracán e inundación. Pero no siempre: hay que preguntar qué cubre **por escrito**.



#### Antes de contratar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cubre huracán e inundación? | Fenómenos hidrometeorológicos. | Por escrito. |
| ¿Cuánto es el deducible? | Lo que pagas tú antes de que pague el seguro. | Pregunta el monto. |
| ¿Qué cubre: casa, cosas o ambas? | Construcción y contenido. | Revisa. |
| ¿Cuánto cuesta al año? | Y cómo se paga. | Compara. |

#### Verifica la aseguradora

Revisa que la aseguradora esté registrada en el SIPRES de CONDUSEF. No te recomendamos ninguna: compara al menos dos.



#### Un caso en un minuto

Julián volvió a cotizar. Pidió por escrito que cubriera huracán e inundación y preguntó el deducible. Comparó dos opciones y eligió la que cubría lo que más le preocupa.

> **Idea clave:** antes de pagar un seguro de casa, pide por escrito si cubre huracán e inundación y cuánto es el deducible.



#### Comprueba lo que entendiste

1. ¿Qué es el deducible?
*Respuesta:* Lo que pagas tú antes de que pague el seguro.

2. ¿Qué pides por escrito?
*Respuesta:* Qué cubre, sobre todo huracán e inundación.


#### Para recordar

- ¿Cubre huracán e inundación?
- ¿Cuánto es el deducible?
- Compara y verifica.



### Profundiza (5 minutos más)

#### El deducible

- Daño en la casa: **40,000**
- Deducible que pagas tú: **4,000**
- Lo que pagaría el seguro: **36,000**


#### Si reclamas

Toma fotos, avisa a la aseguradora lo antes posible y pide un número de reclamación. Si no te responden, acude a CONDUSEF.



#### Casos


**Caso 1. «Contra todo»**

A Julián le ofrecen un seguro «contra todo».
- *¿Qué hace?* Pide por escrito qué cubre y el deducible.


**Caso 2. Una sola opción**

Doña Chepa solo conoce un seguro.
- *¿Qué hace?* Compara al menos dos y verifica la aseguradora.


**Caso 3. Sin respuesta**

La aseguradora no le responde a Don Mel su reclamación.
- *¿Qué hace?* Acude a CONDUSEF con su número de reclamación.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer en «contra todo» | Te quedas sin cobertura | Por escrito |
| No preguntar el deducible | Sorpresa al reclamar | Pregunta |
| No comparar | Pagas de más | Dos opciones |
| Reclamar tarde | Te lo niegan | Avisa pronto |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Julián, Doña Chepa y Don Mel. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué preguntas primero a un seguro de casa en la costa? a) El color de la póliza · b) Si cubre huracán e inundación · c) Si regalan algo al contratar este mes
2. El daño es de 30,000 y el deducible de 3,000. ¿Cuánto pagaría el seguro? a) 3,000 · b) 30,000 · c) 27,000
3. La aseguradora no te responde. ¿A dónde vas? a) A otra aseguradora · b) A CONDUSEF · c) A ningún lado
**Respuestas:** 1-b: lo que más te importa. 2-c: 30,000 menos 3,000. 3-b: CONDUSEF.



#### Ponlo en práctica

Escribe las cuatro preguntas antes de contratar un seguro de casa.
**Respuesta:** ¿Cubre huracán e inundación?, ¿cuánto es el deducible?, ¿cubre casa, cosas o ambas?, ¿cuánto cuesta al año?



#### A tu plan

Si piensas asegurar tu casa, pide dos cotizaciones con las cuatro preguntas respondidas por escrito.



### Para saber más

- **Seguros de vivienda** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de casa habitación».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Deducible:* lo que pagas tú antes de que pague el seguro.
- *Póliza:* contrato del seguro.
- *Fenómeno hidrometeorológico:* huracán, tormenta o inundación.

### Fuentes

CONDUSEF, seguros de casa habitación; consultado el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Crédito para tu actividad

## M5 U01. El adelanto del comprador

**Lo que lograrás:** Calcular cuánto te cuesta de verdad un adelanto que se paga con tu producto.

**Para empezar:** Antes de la temporada, el comprador del pueblo le adelanta a Don Mel 8,000 pesos para gasolina y redes. A cambio, Don Mel le tiene que vender toda su pesca a 20 pesos menos el kilo que en el mercado. En esta lección verás cuánto le cuesta ese adelanto.

### Lo esencial (5 minutos)

#### Un préstamo disfrazado

Cuando te adelantan dinero a cambio de venderles tu producto más barato, es un préstamo. Su costo está escondido en el precio.



#### Haz la cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo que te adelantan | El préstamo. | Ejemplo: 8,000. |
| Lo que dejas de ganar | Diferencia de precio por kilo. | Por todos los kilos. |
| El costo real | Lo que dejas de ganar. | Compáralo con el adelanto. |

#### Compara con otras opciones

Con el costo real en la mano, compara con un crédito formal, con tu ahorro de temporada o con un grupo de ahorro. A veces el adelanto conviene; muchas veces no.



#### Un caso en un minuto

Don Mel vendió 600 kilos en la temporada. A 20 pesos menos, dejó de ganar 12,000 por un adelanto de 8,000. Este año juntó parte de la gasolina con su ahorro y pidió un adelanto más chico.

> **Idea clave:** un adelanto que pagas con tu producto es un préstamo; calcula cuánto dejas de ganar antes de aceptarlo.



#### Comprueba lo que entendiste

1. ¿Por qué un adelanto del comprador es un préstamo?
*Respuesta:* Porque lo pagas vendiendo tu producto más barato.

2. ¿Cómo calculas su costo?
*Respuesta:* Multiplico la diferencia de precio por los kilos que vendo.


#### Para recordar

- Es un préstamo.
- Calcula lo que dejas de ganar.
- Compara.



### Profundiza (5 minutos más)

#### El adelanto de Don Mel

- Pesos menos por kilo: **20**
- Kilos en la temporada: **600**
- Lo que dejó de ganar: **12,000**
- Lo que le adelantaron: **8,000**
- Lo que le costó de más: **4,000**


#### Juntarse con otros

Algunos pescadores y productores se organizan para vender juntos y negociar mejor precio. Pregunta en tu cooperativa o grupo.



#### Casos


**Caso 1. El adelanto de siempre**

Le ofrecen a Don Mel 8,000 a cambio de toda su pesca.
- *¿Qué hace?* Calcula cuánto dejaría de ganar antes de aceptar.


**Caso 2. Los insumos fiados**

La tienda le fía a Julián fertilizante y le cobra al doble en la cosecha.
- *¿Qué hace?* Compara ese costo con otras formas de pagarlo.


**Caso 3. Adelanto más chico**

Don Mel tiene la mitad de lo que necesita ahorrado.
- *¿Qué hace?* Usa su ahorro y pide solo lo que le falta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no cuesta | Pierdes ganancia | Haz la cuenta |
| Aceptar todo el adelanto | Mayor costo | Solo lo que falta |
| No comparar | Pagas de más | Revisa opciones |
| Fiar sin preguntar el precio | Sorpresa en la cosecha | Pregunta antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Mel y Julián. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te adelantan dinero si les vendes más barato. ¿Qué es? a) Un regalo · b) Un préstamo · c) Un apoyo de gobierno
2. Vendes 400 kilos a 15 pesos menos. ¿Cuánto dejas de ganar? a) 4,000 · b) 415 · c) 6,000
3. Tienes la mitad ahorrada. ¿Qué pides? a) Todo el adelanto por si acaso · b) Solo lo que te falta · c) El doble para guardar
**Respuestas:** 1-b: se paga con producto. 2-c: 15 por 400. 3-b: solo lo que falta.



#### Ponlo en práctica

Te adelantan 5,000 y vendes 300 kilos a 25 pesos menos. ¿Cuánto te cuesta de más el adelanto?
**Respuesta:** 2,500 pesos (dejas de ganar 7,500).



#### A tu plan

Si recibes adelantos, haz la cuenta con tus kilos y precios de la temporada pasada.



### Para saber más

- **Crédito para el campo y la pesca** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «crédito agropecuario».

### Palabras clave

- *Adelanto:* dinero que te dan antes y se paga después.
- *Costo escondido:* lo que pagas sin verlo, en el precio.
- *Fiado:* producto que te dan y pagas después.

### Fuentes

CONDUSEF; FIRA, Programa Institucional 2025-2030; consultados el 5 de octubre de 2026.

---

## M5 U02. Compara el costo total de un crédito

**Lo que lograrás:** Comparar créditos para tu lancha, tu parcela o tu negocio por lo que pagarás en total.

**Para empezar:** Yesenia quiere poner un puesto de comida en la playa. Le ofrecen dos créditos de 20,000: uno de 1,200 a la semana por 20 semanas y otro de 2,100 al mes por 12 meses. Se le hacen iguales. En esta lección los compararás.

### Lo esencial (5 minutos)

#### Multiplica y compara

Para comparar, multiplica el pago por el número de pagos. Así ves cuánto pagarás en total en cada uno.



#### Lo que comparas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Total a pagar | Pago por número de pagos. | Lo más claro. |
| CAT | Costo anual total. | En la carátula. |
| Plazo | ¿Te alcanza para cada pago? | Revisa tus meses bajos. |
| Institución registrada | SIPRES de CONDUSEF. | Siempre. |

#### Que los pagos caigan en tu año

Un crédito con pagos fijos cada semana puede ahogarte en los meses bajos. Revisa tu calendario (módulo 3) antes de firmar.



#### Un caso en un minuto

Yesenia hizo la cuenta: el primero suma 24,000 y el segundo 25,200. El primero es más barato, pero sus pagos caen en septiembre. Decidió esperar a abril y pedir menos.

> **Idea clave:** compara el total a pagar y el CAT, y revisa que los pagos caigan en meses en que sí tienes ingreso.



#### Comprueba lo que entendiste

1. ¿Cómo sabes cuánto pagarás en total?
*Respuesta:* Multiplico el pago por el número de pagos.

2. ¿Qué revisas además del total?
*Respuesta:* El CAT, el plazo frente a mis meses bajos y que la institución esté registrada.


#### Para recordar

- Total a pagar.
- CAT.
- Pagos en tus meses buenos.



### Profundiza (5 minutos más)

#### Los dos créditos de Yesenia

- Opción 1: 1,200 × 20 semanas: **24,000**
- Opción 2: 2,100 × 12 meses: **25,200**


#### Programas para el campo y la pesca

Algunos créditos para pesca y campo se dan con apoyo de programas públicos a través de bancos e intermediarios. Pregunta en la institución si tiene alguno y compara el total como cualquier otro crédito.



#### Casos


**Caso 1. Dos créditos «iguales»**

A Yesenia le parecen iguales dos créditos.
- *¿Qué hace?* Multiplica pago por número de pagos y compara.


**Caso 2. Pagos en la veda**

El crédito de Don Mel pide pagos fijos durante la veda.
- *¿Qué hace?* Pregunta por pagos que se ajusten a su temporada.


**Caso 3. La financiera del pueblo**

A Julián le prestan en una financiera que no conoce.
- *¿Qué hace?* La busca en el SIPRES antes de firmar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comparar solo el pago | Pagas más | Total a pagar |
| Ignorar tus meses bajos | Te atrasas | Revisa tu año |
| No ver el CAT | No comparas bien | Pídelo |
| Institución sin registro | Riesgo | SIPRES |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Yesenia, Don Mel y Julián. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Pagas 900 por semana durante 25 semanas. ¿Cuánto pagas en total? a) 22,500 · b) 900 · c) 25,900
2. ¿Qué indicador compara el costo de dos créditos? a) El nombre del asesor · b) El color del anuncio · c) El CAT
3. Tus pagos caerían en tus meses bajos. ¿Qué haces? a) Firmas igual · b) Pides pagos ajustados o esperas · c) Pides otro crédito para pagar este
**Respuestas:** 1-a: 900 por 25. 2-c: CAT. 3-b: ajusta o espera.



#### Ponlo en práctica

Un crédito de 15,000 se paga con 10 pagos de 1,800. ¿Cuánto pagas de más?
**Respuesta:** 3,000 pesos.



#### A tu plan

Si piensas pedir un crédito, compara dos opciones con el total, el CAT y tus meses bajos.



### Para saber más

- **Simuladores de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador de crédito».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Total a pagar:* todo lo que pagarás sumando los pagos.
- *Plazo:* tiempo para pagar.
- *Intermediario financiero:* institución que da el crédito.

### Fuentes

CONDUSEF, comparación de créditos y CAT; FIRA; consultados el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Tus derechos y cómo reclamar

## M6 U01. Tienes derecho a un trato digno

**Lo que lograrás:** Explicar que tienes derecho a ser atendido sin discriminación y qué hacer si no pasa.

**Para empezar:** Doña Chepa fue a abrir una cuenta en la cabecera municipal. La hicieron esperar, la mandaron a otra ventanilla y le dijeron que «mejor viniera con alguien que entendiera». Salió sin cuenta y con coraje. En esta lección verás tus derechos.

### Lo esencial (5 minutos)

#### Nadie puede negarte un servicio por quién eres

La ley prohíbe negar o condicionar un servicio por color de piel, origen, lengua, edad o forma de hablar. Eso es discriminación.



#### Lo que puedes pedir

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Información clara | Requisitos por escrito. | Para volver con todo. |
| Hablar con un responsable | Gerente o encargado. | Con calma. |
| Tu reclamación con folio | Que quede por escrito. | Para seguirla. |

#### Si te discriminan

Anota fecha, hora, sucursal y nombre de quien te atendió. Puedes presentar una queja ante el CONAPRED (800 543 0033). Si el problema es con un producto o un cobro, también puedes ir a CONDUSEF.



#### Un caso en un minuto

Doña Chepa volvió con su hija, pidió los requisitos por escrito y habló con el gerente. Abrió su cuenta. Anotó lo que pasó la primera vez y presentó su queja.

> **Idea clave:** tienes derecho a un trato digno; pide requisitos por escrito, habla con un responsable y, si te discriminan, presenta tu queja.



#### Comprueba lo que entendiste

1. ¿Pueden negarte un servicio por tu color de piel o tu forma de hablar?
*Respuesta:* No; eso es discriminación.

2. ¿Dónde presentas una queja por discriminación?
*Respuesta:* Ante el CONAPRED, 800 543 0033.


#### Para recordar

- Trato digno.
- Requisitos por escrito.
- CONAPRED si te discriminan.



### Profundiza (5 minutos más)

#### Si me trataron mal

| Dato | Lo anoté |
|---|---|
| Fecha y hora | |
| Sucursal u oficina | |
| Nombre de quien atendió | |
| Qué pasó | |



#### No vayas solo si no quieres

Ir acompañado ayuda a sentirte seguro y a tener un testigo. Pero el servicio es tuyo: no necesitas que alguien «hable por ti».



#### Casos


**Caso 1. «Venga con alguien que entienda»**

A Doña Chepa no la atienden bien en la sucursal.
- *¿Qué hace?* Pide los requisitos por escrito y habla con el encargado.


**Caso 2. Sin datos**

Yesenia quiere quejarse pero no anotó nada.
- *¿Qué hace?* La próxima vez anota fecha, hora, sucursal y nombre.


**Caso 3. El cobro injusto**

A Julián le cobraron una comisión que no le explicaron.
- *¿Qué hace?* Reclama en el banco y, si no le resuelven, va a CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Irte sin preguntar | Pierdes la vuelta | Pide requisitos |
| Quedarte callado | Se repite | Presenta tu queja |
| No anotar | Difícil probar | Anota datos |
| Pensar que no sirve | No cambia nada | Las quejas cuentan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa, Yesenia y Julián. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te niegan un servicio por tu forma de hablar. ¿Qué es? a) Discriminación · b) Una regla del banco · c) Un malentendido normal
2. ¿Qué número es del CONAPRED? a) 911 · b) El de la sucursal · c) 800 543 0033
3. ¿Qué anotas si te tratan mal? a) Solo tu nombre · b) Fecha, hora, lugar y quién te atendió · c) Nada, porque las quejas no sirven para nada
**Respuestas:** 1-a: es discriminación. 2-c: CONAPRED. 3-b: los datos.



#### Ponlo en práctica

Escribe la frase con la que pedirías los requisitos por escrito.
**Respuesta:** Ejemplo: «¿Me puede dar por escrito los requisitos para abrir la cuenta?».



#### A tu plan

Guarda el teléfono del CONAPRED y de CONDUSEF y la tabla «Si me trataron mal».



### Para saber más

- **Quejas por discriminación** (CONAPRED · español): https://www.conapred.org.mx — **Qué buscar:** cómo presentar una queja y qué datos del hecho anotar; teléfono 800 543 0033.
- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una queja contra un banco o financiera y qué papeles tener a la mano; teléfono 55 5340 0999.

### Palabras clave

- *Discriminación:* tratar peor a alguien por quién es.
- *Queja:* aviso formal de que algo estuvo mal.
- *Trato digno:* ser atendido con respeto.

### Fuentes

CONAPRED, presentación de quejas; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M6 U02. Reclama con folio

**Lo que lograrás:** Presentar una reclamación ante tu banco o aseguradora y llevarla a CONDUSEF si no te resuelven.

**Para empezar:** A Don Mel le descontaron dos veces el pago de su crédito. Fue a la sucursal y le dijeron «se va a regresar solo». Pasó un mes y nada. En esta lección verás cómo reclamar para que sí te respondan.

### Lo esencial (5 minutos)

#### Los pasos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1. Reclama en la institución | En sucursal o por teléfono. | Pide folio. |
| 2. Espera la respuesta | Pregunta en cuánto tiempo. | Anota la fecha. |
| 3. Si no resuelven, CONDUSEF | Con tu folio y papeles. | 55 5340 0999. |

#### Sin folio, no hay reclamación

Una queja de palabra se olvida. El folio es la prueba de que reclamaste y la fecha desde la que corre el tiempo.



#### Lleva tus pruebas

Estado de cuenta, comprobantes, contrato y fotos. Mientras más claro, más rápido.



#### Un caso en un minuto

Don Mel volvió, pidió su folio y anotó la fecha. Como no le resolvieron, fue a CONDUSEF con su estado de cuenta. Le regresaron el pago doble.

> **Idea clave:** reclama siempre con folio; si no te resuelven, lleva tu folio y tus pruebas a CONDUSEF.



#### Comprueba lo que entendiste

1. ¿Qué pides siempre al reclamar?
*Respuesta:* Un folio.

2. ¿A dónde vas si la institución no resuelve?
*Respuesta:* A CONDUSEF, con mi folio y mis pruebas.


#### Para recordar

- Folio siempre.
- Pruebas en mano.
- CONDUSEF si no resuelven.



### Profundiza (5 minutos más)

#### Mi reclamación

| Dato | Lo tengo |
|---|---|
| Folio | |
| Fecha | |
| Qué reclamé | |
| Respuesta | |



#### CONDUSEF también atiende en estados

CONDUSEF tiene oficinas en los estados y atiende por teléfono y en línea. No necesitas viajar a la Ciudad de México.



#### Casos


**Caso 1. «Se regresa solo»**

A Don Mel le cobraron doble y le dicen que se regresa solo.
- *¿Qué hace?* Pide folio y anota la fecha.


**Caso 2. Sin respuesta**

Pasó el plazo y no le resuelven.
- *¿Qué hace?* Va a CONDUSEF con su folio y pruebas.


**Caso 3. Sin papeles**

Yesenia quiere reclamar pero no tiene su estado de cuenta.
- *¿Qué hace?* Lo pide en el banco o en la app antes de reclamar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Reclamar de palabra | Se olvida | Folio |
| Sin pruebas | Tarda más | Lleva papeles |
| Esperar meses | Pierdes tiempo | Pregunta el plazo |
| Creer que CONDUSEF está lejos | No vas | Oficinas y teléfono |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Mel y Yesenia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es lo más importante al reclamar? a) Gritar fuerte · b) Pedir folio · c) Ir muchas veces sin anotar
2. No te resuelven. ¿A dónde vas? a) A tu casa · b) A otro banco · c) A CONDUSEF
3. ¿Qué llevas a tu reclamación? a) Nada · b) Estado de cuenta, comprobantes y contrato · c) Solo tu INE, porque ellos tienen todo lo demás
**Respuestas:** 1-b: el folio. 2-c: CONDUSEF. 3-b: tus pruebas.



#### Ponlo en práctica

Te cobraron dos veces un pago de 1,250. ¿Cuánto reclamas?
**Respuesta:** 1,250 pesos.



#### A tu plan

Si tienes algún cobro que no entiendes, haz tu reclamación con folio esta semana.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una queja contra un banco o financiera y qué papeles tener a la mano; teléfono 55 5340 0999.

### Palabras clave

- *Reclamación:* queja formal por un cobro o servicio.
- *Folio:* número que comprueba tu reclamación.
- *Estado de cuenta:* resumen de movimientos de tu cuenta o crédito.

### Fuentes

CONDUSEF, proceso de reclamación; consultado el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Remesas que rinden

## M7 U01. Compara cómo te mandan el dinero

**Lo que lograrás:** Comparar comisión y tipo de cambio para que llegue más dinero de cada envío.

**Para empezar:** El hijo de Doña Chepa le manda 300 dólares al mes desde Carolina del Norte. Siempre usa la misma empresa porque «ahí lo conocen». Nunca han comparado cuántos pesos llegan. En esta lección lo harán.

### Lo esencial (5 minutos)

#### Dos cosas cuestan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| La comisión | Lo que cobran por enviar. | Allá o aquí. |
| El tipo de cambio | Cuántos pesos dan por dólar. | Puede variar mucho. |

#### Lo que importa: los pesos que llegan

Compara cuántos pesos recibes en total por la misma cantidad de dólares. Un envío «sin comisión» puede pagar un tipo de cambio más bajo.



#### Usa el comparador oficial

PROFECO tiene el programa **Quién es Quién en el Envío de Dinero**, que compara empresas desde ciudades de EE. UU.: comisión, tipo de cambio y pesos que llegan. No te recomendamos una empresa: compara tú.



#### Un caso en un minuto

Doña Chepa y su hijo revisaron el comparador. Con otra opción le llegaban unos 300 pesos más al mes. En un año son 3,600 pesos.

> **Idea clave:** compara los pesos que llegan, no solo la comisión; usa el comparador de PROFECO.



#### Comprueba lo que entendiste

1. ¿Qué dos cosas cuestan en un envío?
*Respuesta:* La comisión y el tipo de cambio.

2. ¿Qué comparas al final?
*Respuesta:* Los pesos que llegan por la misma cantidad de dólares.


#### Para recordar

- Comisión y tipo de cambio.
- Compara pesos que llegan.
- Comparador de PROFECO.



### Profundiza (5 minutos más)

#### Lo que gana Doña Chepa al comparar

- Pesos más por envío: **300**
- Envíos al año: **12**
- Pesos más al año: **3,600**


#### Recibir en cuenta

Recibir el envío en una cuenta a tu nombre suele ser más seguro que cobrar en efectivo y te permite dejar una parte ahorrada (módulo 4).



#### Casos


**Caso 1. «Ahí lo conocen»**

El hijo de Doña Chepa siempre usa la misma empresa.
- *¿Qué hacen?* Comparan en el programa de PROFECO cuántos pesos llegan.


**Caso 2. «Sin comisión»**

A Yesenia le anuncian envío sin comisión.
- *¿Qué hace?* Revisa también el tipo de cambio y los pesos que llegan.


**Caso 3. Cobrar en efectivo**

Doña Chepa cobra siempre en ventanilla y gasta todo.
- *¿Qué hace?* Pide recibirlo en su cuenta y deja una parte.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No comparar nunca | Llegan menos pesos | Compara |
| Ver solo la comisión | Tipo de cambio bajo | Pesos que llegan |
| Cobrar todo en efectivo | Se gasta | Recibe en cuenta |
| Confiar en «sin comisión» | Costo escondido | Revisa todo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa, su hijo y Yesenia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué comparas entre empresas de envío? a) Los pesos que llegan · b) El color del logo · c) Qué tan cerca está la oficina
2. Un envío «sin comisión»… a) siempre es el mejor, porque no te cobran nada · b) es un fraude · c) puede pagar un tipo de cambio más bajo
3. ¿Qué programa compara envíos de dinero? a) El SIPRES · b) Quién es Quién en el Envío de Dinero, de PROFECO · c) El Buró de Crédito, que revisa a las empresas
**Respuestas:** 1-a: lo que llega. 2-c: revisa el cambio. 3-b: PROFECO.



#### Ponlo en práctica

Con una empresa llegan 5,400 pesos y con otra 5,650 por el mismo envío. ¿Cuánto más llega con la segunda?
**Respuesta:** 250 pesos.



#### A tu plan

Revisen juntos, tú y quien te manda dinero, el comparador de PROFECO con su ciudad.



### Para saber más

- **Quién es Quién en el Envío de Dinero** (PROFECO · español): https://qqed.profeco.gob.mx — **Qué buscar:** compara cuánto recibe tu familia con cada empresa, no solo la comisión.

### Palabras clave

- *Comisión:* cobro por enviar.
- *Tipo de cambio:* cuántos pesos dan por un dólar.
- *Remesa:* dinero que manda un familiar desde otro país.

### Fuentes

PROFECO, Quién es Quién en el Envío de Dinero; Banco de México, remesas; consultados el 5 de octubre de 2026.

---

## M7 U02. Un plan para la remesa

**Lo que lograrás:** Repartir la remesa con un plan acordado con quien la manda.

**Para empezar:** Cada mes, cuando llega el dinero de su hijo, a Doña Chepa le piden prestado vecinos y familiares. A fin de mes no queda nada y su hijo pregunta en qué se fue. En esta lección harán un plan juntos.

### Lo esencial (5 minutos)

#### Tres partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo básico | Comida, casa, salud, escuela. | Primero. |
| Ahorro | Fondo de emergencia. | Aunque sea poco. |
| Una meta | Arreglar la casa, una lancha, estudios. | Acordada con quien manda. |

#### Hablen con números

Quien manda la remesa trabaja duro allá. Quien la recibe administra aquí. Acuerden cuánto va a cada parte y revisen juntos cada cierto tiempo.



#### Los préstamos a otros

Si te piden prestado de la remesa, recuerda que no es solo tuya: tiene un plan. Una frase ayuda: «Ese dinero ya tiene destino».



#### Un caso en un minuto

Doña Chepa y su hijo acordaron: 70% para lo básico, 15% para el fondo y 15% para el techo de la casa. Ella ya no presta de la remesa. Él sabe en qué se usa.

> **Idea clave:** reparte la remesa en lo básico, ahorro y una meta, y acuerden el plan juntos.



#### Comprueba lo que entendiste

1. ¿Cuáles son las tres partes del plan?
*Respuesta:* Lo básico, ahorro y una meta.

2. ¿Qué frase ayuda cuando te piden prestado de la remesa?
*Respuesta:* «Ese dinero ya tiene destino».


#### Para recordar

- Básico, ahorro, meta.
- Acuerden juntos.
- Ya tiene destino.



### Profundiza (5 minutos más)

#### El plan de Doña Chepa (5,400 pesos)

- Lo básico (70%): **3,780**
- Ahorro (15%): **810**
- Techo de la casa (15%): **810**
- Total: **5,400**


#### Una meta que produce

Si la meta es una herramienta de trabajo (una lancha, un motor, un congelador para el puesto), puede generar ingreso para cuando las remesas bajen.



#### Casos


**Caso 1. Todos piden**

A Doña Chepa le piden prestado cada vez que llega la remesa.
- *¿Qué hace?* Dice «ese dinero ya tiene destino».


**Caso 2. Sin acuerdo**

El hijo de Doña Chepa no sabe en qué se usa el dinero.
- *¿Qué hacen?* Acuerdan juntos cuánto va a cada parte.


**Caso 3. La meta**

Don Mel recibe remesa de su hija y quiere un motor nuevo.
- *¿Qué hace?* Aparta cada mes una parte para esa meta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin plan | Se va en todo | Tres partes |
| Prestar de la remesa | No alcanza | Ya tiene destino |
| No hablar con quien manda | Desconfianza | Acuerden |
| Sin ahorro | Sin colchón | Aunque sea poco |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Chepa, su hijo y Don Mel. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuáles son las tres partes del plan? a) Fiestas, regalos y préstamos · b) Lo básico, ahorro y una meta · c) Todo para lo básico
2. Llegan 6,000 y apartas 10% para ahorro. ¿Cuánto es? a) 1,000 · b) 60 · c) 600
3. ¿Con quién acuerdas el plan? a) Con los vecinos que también reciben remesas · b) Con quien manda la remesa · c) Con nadie
**Respuestas:** 1-b: tres partes. 2-c: 10% de 6,000. 3-b: con quien la manda.



#### Ponlo en práctica

Recibes 4,000. Si 75% es para lo básico, ¿cuánto queda para ahorro y meta?
**Respuesta:** 1,000 pesos.



#### A tu plan

Hablen esta semana quien manda y quien recibe, y escriban su plan en tres partes.



### Para saber más

- **Remesas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «remesas».

### Palabras clave

- *Plan:* acuerdo de en qué se usa el dinero.
- *Meta:* algo que quieres lograr con el dinero.
- *Porcentaje:* parte de cada 100.

### Fuentes

CONDUSEF, uso de remesas; consultado el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Tu patrimonio y tu herencia

## M8 U01. Los papeles de tu casa y tu terreno

**Lo que lograrás:** Identificar qué papel comprueba que tu casa o tu terreno es tuyo y qué hacer si no lo tienes.

**Para empezar:** La familia de Julián vive desde hace 40 años en la misma casa, pero los papeles siguen a nombre del abuelo, que ya murió. Nadie sabe qué hacer. En esta lección verás por dónde empezar.

### Lo esencial (5 minutos)

#### Según tu tipo de propiedad

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Propiedad privada | Escritura en el Registro Público. | A tu nombre. |
| Ejido | Certificado parcelario o de derechos. | En el RAN. |
| Bienes comunales | Reconocimiento de la comunidad. | Asamblea y RAN. |
| Sin papeles | Constancia de posesión o regularización. | Pregunta en el municipio. |

#### Averigua a nombre de quién está

Pide en el Registro Público de la Propiedad o en el Registro Agrario Nacional a nombre de quién está tu casa o tu parcela. Es el primer paso.



#### Si está a nombre de alguien que murió

Hace falta un trámite de sucesión (con testamento o sin él) para pasarla a quien hereda. Mientras más tiempo pasa, más se complica. Pide orientación en una notaría, en la defensoría pública o en el RAN si es ejido.



#### Un caso en un minuto

Julián fue al RAN: la parcela está a nombre de su abuelo y había lista de sucesión con su papá. Su papá ya inició el trámite. Para la casa del pueblo pidieron orientación en la defensoría.

> **Idea clave:** averigua a nombre de quién están tu casa y tu terreno; si está a nombre de alguien que murió, inicia la sucesión pronto.



#### Comprueba lo que entendiste

1. ¿Dónde averiguas a nombre de quién está una parcela ejidal?
*Respuesta:* En el Registro Agrario Nacional.

2. ¿Qué pasa si la casa está a nombre de alguien que murió?
*Respuesta:* Hace falta un trámite de sucesión para pasarla a quien hereda.


#### Para recordar

- ¿A nombre de quién está?
- Registro Público o RAN.
- Sucesión pronto.



### Profundiza (5 minutos más)

#### Mis bienes

| Bien | Tipo (privado, ejido, comunal) | A nombre de | Papel |
|---|---|---|---|
| Casa | | | |
| Terreno o parcela | | | |
| Lancha o herramientas | | | |



#### Cuidado con quien «arregla papeles» rápido

Si alguien te ofrece escriturar sin trámites ni notario, desconfía. Una escritura falsa no protege tu casa.



#### Casos


**Caso 1. Papeles del abuelo**

La casa de Julián sigue a nombre del abuelo.
- *¿Qué hace?* Pide orientación para iniciar la sucesión.


**Caso 2. La parcela**

Don Mel no sabe si su parcela está registrada.
- *¿Qué hace?* Pregunta en el Registro Agrario Nacional.


**Caso 3. El arreglo rápido**

Le ofrecen a Yesenia escriturar su terreno en una semana sin notario.
- *¿Qué hace?* No paga y pregunta en el municipio o una notaría.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber a nombre de quién está | Problemas al heredar | Averigua |
| Dejar pasar años | Se complica | Inicia pronto |
| Pagar arreglos rápidos | Papeles falsos | Notaría o RAN |
| Olvidar la parcela | Pierdes derechos | RAN |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Julián, Don Mel y Yesenia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué papel comprueba una propiedad privada? a) La escritura registrada · b) El recibo de luz a tu nombre de los últimos años · c) Una foto de la casa
2. ¿Dónde se registran los derechos ejidales? a) En el banco donde tienes tu cuenta · b) En la tienda del pueblo · c) En el Registro Agrario Nacional
3. Te ofrecen escriturar en una semana sin notario. ¿Qué haces? a) Pagas · b) Desconfías y preguntas en una notaría o el municipio · c) Pagas la mitad
**Respuestas:** 1-a: la escritura. 2-c: RAN. 3-b: desconfía.



#### Ponlo en práctica

Escribe a nombre de quién está tu casa (o a quién tendrías que preguntar).
**Respuesta:** Respuesta personal: el nombre, o la oficina donde preguntarás (Registro Público o RAN).



#### A tu plan

Llena la tabla de tus bienes y averigua a nombre de quién está cada uno.



### Para saber más

- **Registro Agrario Nacional** (RAN · español): https://www.gob.mx/ran — **Qué buscar:** cómo consultar a nombre de quién está la parcela y los trámites del ejido.
- **Defensoría pública** (Instituto Federal de Defensoría Pública · español): https://www.ifdp.cjf.gob.mx — **Qué buscar:** la oficina más cercana y en qué casos te asesoran sin costo.

### Palabras clave

- *Escritura:* papel que comprueba que una propiedad es tuya.
- *Certificado parcelario:* papel de tu parcela en el ejido.
- *Sucesión:* trámite para pasar los bienes de quien murió.

### Fuentes

Registro Agrario Nacional; consultado el 5 de octubre de 2026.

---

## M8 U02. Que tu familia no pelee por lo tuyo

**Lo que lograrás:** Dejar decidido a quién le tocan tus bienes: testamento, lista de sucesión y beneficiarios.

**Para empezar:** Cuando murió el compadre de Don Mel, sus hijos pelearon por la lancha y la casa. Dos años después, la lancha sigue parada. Don Mel no quiere eso para los suyos. En esta lección dejarás todo decidido.

### Lo esencial (5 minutos)

#### Tres formas de decidir

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Testamento | Para casa, terreno privado, lancha y otros bienes. | En notaría. |
| Lista de sucesión | Para derechos ejidales. | En el RAN. |
| Beneficiarios | Para cuentas, Afore y seguros. | En cada institución. |

#### El testamento cuesta menos en septiembre

Cada septiembre las notarías ofrecen testamentos con costo reducido. Lleva tu lista de bienes y los nombres completos de a quién le dejas qué.



#### Habla con tu familia

Decirles qué decidiste evita sorpresas y peleas. No tienes que pedir permiso: es tu decisión.



#### Un caso en un minuto

Don Mel hizo testamento en septiembre: la lancha para su hijo que pesca, la casa para su esposa. Actualizó la lista de sucesión de su parcela y los beneficiarios de su cuenta. Se lo contó a la familia en una comida.

> **Idea clave:** testamento para tus bienes, lista de sucesión para el ejido y beneficiarios para tus cuentas; y cuéntaselo a tu familia.



#### Comprueba lo que entendiste

1. ¿Qué usas para heredar derechos ejidales?
*Respuesta:* La lista de sucesión, registrada en el RAN.

2. ¿Dónde se ponen beneficiarios de una cuenta?
*Respuesta:* En la institución de la cuenta.


#### Para recordar

- Testamento.
- Lista de sucesión.
- Beneficiarios.



### Profundiza (5 minutos más)

#### Mi herencia decidida

| Bien | Forma | A quién | Hecho |
|---|---|---|---|
| Casa | Testamento | | |
| Parcela ejidal | Lista de sucesión | | |
| Cuenta o Afore | Beneficiarios | | |
| Lancha o herramientas | Testamento | | |



#### Actualízalo

Si cambia tu familia (nace un nieto, muere alguien, te casas), revisa tu testamento, tu lista y tus beneficiarios.



#### Casos


**Caso 1. La lancha parada**

Don Mel no quiere que sus hijos peleen por la lancha.
- *¿Qué hace?* Hace testamento y dice a quién le deja la lancha.


**Caso 2. La parcela**

Julián quiere que la parcela pase a su hija.
- *¿Qué hace?* La pone en su lista de sucesión en el RAN.


**Caso 3. «No quiero hablar de eso»**

Doña Chepa no quiere hablar de herencias con su familia.
- *¿Qué hace?* Toma su decisión y se la cuenta con calma.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No decidir | Peleas y bienes parados | Testamento |
| Olvidar el ejido | Pierden el derecho | Lista de sucesión |
| Beneficiarios viejos | El dinero va a otro | Actualiza |
| No contarlo | Sorpresas | Habla con tu familia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Mel, Julián y Doña Chepa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Con qué dejas tu casa a tu familia? a) Con un testamento · b) Con un recibo · c) De palabra, frente a toda la familia reunida
2. ¿En qué mes el testamento cuesta menos en muchas notarías? a) Enero · b) Diciembre · c) Septiembre
3. ¿Dónde pones beneficiarios de tu Afore? a) En tu Afore · b) En el RAN · c) En la notaría
**Respuestas:** 1-a: testamento. 2-c: septiembre. 3-a: en tu Afore.



#### Ponlo en práctica

Escribe qué forma usas para cada bien: casa, parcela ejidal, cuenta del banco.
**Respuesta:** Casa: testamento. Parcela ejidal: lista de sucesión. Cuenta: beneficiarios.



#### A tu plan

Llena tu tabla de herencia y marca qué harás primero.



### Para saber más

- **Mes del testamento** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «mes del testamento».
- **Lista de sucesión** (RAN · español): https://www.gob.mx/ran — **Qué buscar:** cómo registrar o cambiar tu lista de sucesión de la parcela.

### Palabras clave

- *Testamento:* papel donde decides a quién dejas tus bienes.
- *Lista de sucesión:* lista de quién hereda tus derechos ejidales.
- *Beneficiario:* quien recibe tu dinero si faltas.

### Fuentes

Gobierno de México, Mes del Testamento; Registro Agrario Nacional; consultados el 5 de octubre de 2026.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Costa, Tu Dinero, Tu Futuro** — Programa de bienestar financiero para comunidades afromexicanas de la Costa Chica de Guerrero y Oaxaca: proteger lo que se tiene ante huracanes, ordenar el ingreso de temporada, usar crédito con cuidado, reclamar un trato injusto y cuidar el patrimonio. 8 módulos y 16 lecciones cortas para sesiones presenciales.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Tu plan de dinero ante huracanes:** Tu plan de dinero para antes y después de un huracán.
- **Tus documentos a salvo:** Tus documentos importantes protegidos y respaldados.
- **El ingreso de temporada, mes a mes:** Tu calendario de ingresos del año y lo que apartas en temporada buena.
- **Fondo de emergencia y seguro de vivienda:** Tu fondo de emergencia en marcha y tu decisión sobre el seguro de vivienda.
- **Crédito para tu actividad:** Tu comparación del costo total de cualquier crédito o adelanto.
- **Tus derechos y cómo reclamar:** Tu forma de pedir un trato digno y de reclamar con folio.
- **Remesas que rinden:** Tu forma de recibir remesas con menos comisión y con un plan.
- **Tu patrimonio y tu herencia:** Tus papeles de casa y terreno en orden y tu decisión sobre la herencia.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 16 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Don Mel:** 58 años. Pescador en Punta Maldonado, Guerrero. Tiene lancha propia y vende a un comprador del pueblo.
- **Doña Chepa:** 50 años. Vende pescado y comida en Collantes, Oaxaca. Su hijo le manda dinero desde Carolina del Norte.
- **Yesenia:** 29 años. Trabaja en un restaurante de playa en Marquelia; en temporada baja casi no hay trabajo.
- **Julián:** 34 años. Siembra limón y ajonjolí en Cuajinicuilapa con su papá.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **Ejemplos de la región:** pesca, limón, ajonjolí, coco, turismo de playa y comercio local de la Costa Chica.
5. **Facilitadores de la región** siempre que sea posible.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. Mayo en la casa de Doña Chepa (Módulos 1 y 2)

**Datos.** Es 2 de mayo. Doña Chepa quiere estar lista antes de la temporada de huracanes. Tiene sus actas, su INE y las escrituras en una caja de cartón en el piso. Puede apartar 150 a la semana durante 10 semanas.

**Tareas.**

1. ¿Antes de qué fecha conviene tener el plan listo?
2. ¿Cómo guarda sus originales?
3. ¿Dónde guarda las fotos de sus papeles?
4. ¿Cuánto junta de guardadito en 10 semanas?

**Clave.**

- Antes del 15 de mayo, cuando empieza la temporada en el Pacífico.
- En doble bolsa cerrada y en alto, no en el piso.
- Fuera de su casa: en su celular y con alguien de confianza en otro lugar.
- 150 por 10: 1,500.

### E2. El año de Yesenia (Módulos 3 y 4)

**Datos.** Yesenia gana 12,000 al mes en temporada alta (diciembre a abril, 5 meses) y 4,000 al mes en temporada baja (los otros 7 meses). Sus básicos son 6,500 al mes. Quiere un fondo de emergencia de 3,000 para empezar.

**Tareas.**

1. ¿Cuánto le falta cada mes de temporada baja?
2. ¿Cuánto le falta en los 7 meses bajos?
3. ¿Cuánto debe apartar en cada mes alto para cubrirlo?
4. ¿Cuándo y cómo arma su fondo de 3,000?

**Clave.**

- 6,500 menos 4,000: 2,500.
- 2,500 por 7: 17,500.
- 17,500 entre 5: 3,500 por mes alto (le quedan 12,000 menos 6,500 menos 3,500: 2,000).
- En la temporada alta, apartando poco y seguido (por ejemplo, 600 al mes en 5 meses) y sin mezclarlo con el dinero de diario.

### E3. El adelanto de Don Mel (Módulos 5 y 6)

**Datos.** El comprador le adelanta a Don Mel 5,000 para reparar el motor. A cambio, le paga su pescado a 60 el kilo en lugar de 75, hasta pagar. Don Mel le vende 400 kilos. En la financiera, le pidieron requisitos que no le dicen por escrito y lo trataron mal.

**Tareas.**

1. ¿Cuánto deja de ganar por kilo?
2. ¿Cuánto deja de ganar con los 400 kilos?
3. ¿Cuánto le costó el adelanto?
4. ¿Qué hace con el trato en la financiera?

**Clave.**

- 75 menos 60: 15 por kilo.
- 15 por 400: 6,000.
- Recibió 5,000 y dejó de ganar 6,000: le costó 1,000 más que lo prestado. Antes de aceptar, compara con el costo total de un crédito.
- Pide los requisitos por escrito, habla con un responsable y, si no le resuelven, reclama con folio; si lo discriminaron, presenta su queja.

### E4. La remesa y la parcela (Módulos 7 y 8)

**Datos.** El hijo de Doña Chepa le manda dinero cada mes. Con un servicio llegan 5,600 pesos y con otro 5,850 por el mismo envío. La casa está a nombre de su esposo, que murió hace tres años, y Julián siembra en una parcela ejidal de su papá.

**Tareas.**

1. ¿Cuántos pesos más llegan al mes con el segundo servicio? ¿Y al año?
2. ¿Cómo reparten la remesa?
3. ¿Qué hace con la casa a nombre del esposo?
4. ¿Qué documento protege la parcela ejidal?

**Clave.**

- 250 al mes; 3,000 al año.
- En lo básico, un ahorro y una meta, acordado en familia.
- Inicia pronto la sucesión para que la casa quede a su nombre o al de quien corresponda.
- La lista de sucesión, depositada en el RAN o ante notario.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Apartas 100 pesos de cada una de tus 3 ventas por semana desde marzo hasta mediados de mayo (10 semanas). ¿Cuánto juntas? |
| P02 | M1 U02 | Escribe los cuatro pasos de los primeros días en orden. |
| P03 | M2 U01 | Nombra tres papeles que van en tu bolsa. |
| P04 | M2 U02 | Ordena los tres papeles: INE, CURP, acta. |
| P05 | M3 U01 | Tienes 3 meses bajos y en cada uno te faltan 2,000. ¿Cuánto necesitas apartar en los meses buenos? |
| P06 | M3 U02 | Cobras 18,000 en la temporada de turismo y deben durar 3 meses. ¿Cuánto es tu sueldo mensual? |
| P07 | M4 U01 | Apartas 150 pesos por semana. ¿En cuántas semanas llegas a 1,500? |
| P08 | M4 U02 | Escribe las cuatro preguntas antes de contratar un seguro de casa. |
| P09 | M5 U01 | Te adelantan 5,000 y vendes 300 kilos a 25 pesos menos. ¿Cuánto te cuesta de más el adelanto? |
| P10 | M5 U02 | Un crédito de 15,000 se paga con 10 pagos de 1,800. ¿Cuánto pagas de más? |
| P11 | M6 U01 | Escribe la frase con la que pedirías los requisitos por escrito. |
| P12 | M6 U02 | Te cobraron dos veces un pago de 1,250. ¿Cuánto reclamas? |
| P13 | M7 U01 | Con una empresa llegan 5,400 pesos y con otra 5,650 por el mismo envío. ¿Cuánto más llega con la segunda? |
| P14 | M7 U02 | Recibes 4,000. Si 75% es para lo básico, ¿cuánto queda para ahorro y meta? |
| P15 | M8 U01 | Escribe a nombre de quién está tu casa (o a quién tendrías que preguntar). |
| P16 | M8 U02 | Escribe qué forma usas para cada bien: casa, parcela ejidal, cuenta del banco. |

### Respuestas

- **P01:** 3,000 pesos.
- **P02:** Familia, fotos de los daños, avisar con folio y preguntar por apoyos oficiales.
- **P03:** Ejemplo: actas de nacimiento, INE y escrituras o certificado ejidal.
- **P04:** CURP, acta, INE.
- **P05:** 6,000 pesos.
- **P06:** 6,000 pesos.
- **P07:** En 10 semanas.
- **P08:** ¿Cubre huracán e inundación?, ¿cuánto es el deducible?, ¿cubre casa, cosas o ambas?, ¿cuánto cuesta al año?
- **P09:** 2,500 pesos (dejas de ganar 7,500).
- **P10:** 3,000 pesos.
- **P11:** Ejemplo: «¿Me puede dar por escrito los requisitos para abrir la cuenta?».
- **P12:** 1,250 pesos.
- **P13:** 250 pesos.
- **P14:** 1,000 pesos.
- **P15:** Respuesta personal: el nombre, o la oficina donde preguntarás (Registro Público o RAN).
- **P16:** Casa: testamento. Parcela ejidal: lista de sucesión. Cuenta: beneficiarios.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu plan de dinero ante huracanes

- **Aviso:** alerta oficial de que viene un fenómeno.
- **Censo:** registro oficial de personas afectadas.
- **Folio:** número que comprueba tu reporte.
- **Guardadito:** dinero apartado para una emergencia.
- **Prórroga:** más tiempo para pagar.
- **Temporada de huracanes:** meses en que se forman más huracanes.

### Tus documentos a salvo

- **Certificado ejidal:** papel que acredita tus derechos en el ejido.
- **Comprobante de trámite:** papel que muestra que pediste tu INE.
- **Copia certificada:** copia oficial que vale como el original.
- **Original:** el papel verdadero.
- **Reponer:** sacar de nuevo un papel perdido.
- **Respaldo:** copia guardada en otro lugar.

### El ingreso de temporada, mes a mes

- **Apartar:** separar dinero para después.
- **Gasto fuerte:** gasto grande que llega en un mes concreto.
- **Ingreso de temporada:** dinero que llega solo en ciertos meses.
- **Sueldo mensual:** lo que te das para gastar cada mes.
- **Tanda:** ahorro en grupo por turnos.
- **Veda:** tiempo en que no se puede pescar una especie.

### Fondo de emergencia y seguro de vivienda

- **Apartado:** espacio de tu cuenta para separar dinero.
- **Deducible:** lo que pagas tú antes de que pague el seguro.
- **Empeñar:** dejar algo a cambio de un préstamo.
- **Fenómeno hidrometeorológico:** huracán, tormenta o inundación.
- **Fondo de emergencia:** dinero solo para imprevistos.
- **Póliza:** contrato del seguro.

### Crédito para tu actividad

- **Adelanto:** dinero que te dan antes y se paga después.
- **Costo escondido:** lo que pagas sin verlo, en el precio.
- **Fiado:** producto que te dan y pagas después.
- **Intermediario financiero:** institución que da el crédito.
- **Plazo:** tiempo para pagar.
- **Total a pagar:** todo lo que pagarás sumando los pagos.

### Tus derechos y cómo reclamar

- **Discriminación:** tratar peor a alguien por quién es.
- **Estado de cuenta:** resumen de movimientos de tu cuenta o crédito.
- **Queja:** aviso formal de que algo estuvo mal.
- **Reclamación:** queja formal por un cobro o servicio.
- **Trato digno:** ser atendido con respeto.

### Remesas que rinden

- **Comisión:** cobro por enviar.
- **Meta:** algo que quieres lograr con el dinero.
- **Plan:** acuerdo de en qué se usa el dinero.
- **Porcentaje:** parte de cada 100.
- **Remesa:** dinero que manda un familiar desde otro país.
- **Tipo de cambio:** cuántos pesos dan por un dólar.

### Tu patrimonio y tu herencia

- **Beneficiario:** quien recibe tu dinero si faltas.
- **Certificado parcelario:** papel de tu parcela en el ejido.
- **Escritura:** papel que comprueba que una propiedad es tuya.
- **Lista de sucesión:** lista de quién hereda tus derechos ejidales.
- **Sucesión:** trámite para pasar los bienes de quien murió.
- **Testamento:** papel donde decides a quién dejas tus bienes.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Avisos de ciclones | SMN: https://smn.conagua.gob.mx | «ciclones tropicales» | M1 U01 |
| Protección Civil | Gobierno de México: https://www.gob.mx/cenapred | «plan familiar de protección civil» | M1 U01 |
| Fraudes después de desastres | CONDUSEF: https://www.condusef.gob.mx | «desastres naturales» | M1 U02 |
| Protección Civil | CENAPRED: https://www.gob.mx/cenapred | — | M1 U02 |
| Plan familiar | CENAPRED: https://www.gob.mx/cenapred | «documentos importantes» | M2 U01 |
| Acta en línea | Gobierno de México: https://www.gob.mx/actas | — | M2 U02 |
| CURP | Gobierno de México: https://www.gob.mx/curp | — | M2 U02 |
| Registro Agrario Nacional | RAN: https://www.gob.mx/ran | «reposición de certificado» | M2 U02, M8 U01 |
| Presupuesto con ingreso variable | CONDUSEF: https://www.condusef.gob.mx | «ingresos variables» | M3 U01 |
| Ahorro | CONDUSEF: https://www.condusef.gob.mx | «ahorro» y «tandas» | M3 U02 |
| Fondo de emergencia | CONDUSEF: https://www.condusef.gob.mx | «fondo de emergencia» | M4 U01 |
| Seguros de vivienda | CONDUSEF: https://www.condusef.gob.mx | «seguro de casa habitación» | M4 U02 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M4 U02, M5 U02 |
| Crédito para el campo y la pesca | CONDUSEF: https://www.condusef.gob.mx | «crédito agropecuario» | M5 U01 |
| Simuladores de crédito | CONDUSEF: https://www.condusef.gob.mx | «simulador de crédito» | M5 U02 |
| Quejas por discriminación | CONAPRED: https://www.conapred.org.mx | 800 543 0033 | — | M6 U01 |
| Reclamaciones | CONDUSEF: https://www.condusef.gob.mx | 55 5340 0999 | — | M6 U01, M6 U02 |
| Quién es Quién en el Envío de Dinero | PROFECO: https://qqed.profeco.gob.mx | — | M7 U01 |
| Remesas | CONDUSEF: https://www.condusef.gob.mx | «remesas» | M7 U02 |
| Defensoría pública | Instituto Federal de Defensoría Pública: https://www.ifdp.cjf.gob.mx | — | M8 U01 |
| Mes del testamento | Gobierno de México: https://www.gob.mx | «mes del testamento» | M8 U02 |
| Lista de sucesión | RAN: https://www.gob.mx/ran | — | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Tu plan de dinero ante huracanes

- **M1 U01 · Antes de la temporada: tu plan de dinero.** SMN, temporada de ciclones tropicales 2026 en el Pacífico; CENAPRED; consultados el 5 de octubre de 2026.
- **M1 U02 · Después del huracán: sin prisas ni préstamos caros.** CONDUSEF, recomendaciones ante desastres naturales; CENAPRED; consultados el 5 de octubre de 2026.

### Tus documentos a salvo

- **M2 U01 · Tus papeles en una bolsa.** CENAPRED, plan familiar de protección civil; consultado el 5 de octubre de 2026.
- **M2 U02 · Si perdiste tus papeles.** INE; Gobierno de México, actas y CURP; Registro Agrario Nacional; consultados el 5 de octubre de 2026.

### El ingreso de temporada, mes a mes

- **M3 U01 · Tu calendario de ingresos.** CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.
- **M3 U02 · Aparta en la temporada buena.** CONDUSEF, ahorro y tandas; consultado el 5 de octubre de 2026.

### Fondo de emergencia y seguro de vivienda

- **M4 U01 · Tu fondo de emergencia.** INEGI y CONDUSEF, ENSAFI 2023; CONDUSEF; consultados el 5 de octubre de 2026.
- **M4 U02 · ¿Asegurar tu casa?.** CONDUSEF, seguros de casa habitación; consultado el 5 de octubre de 2026.

### Crédito para tu actividad

- **M5 U01 · El adelanto del comprador.** CONDUSEF; FIRA, Programa Institucional 2025-2030; consultados el 5 de octubre de 2026.
- **M5 U02 · Compara el costo total de un crédito.** CONDUSEF, comparación de créditos y CAT; FIRA; consultados el 5 de octubre de 2026.

### Tus derechos y cómo reclamar

- **M6 U01 · Tienes derecho a un trato digno.** CONAPRED, presentación de quejas; CONDUSEF; consultados el 5 de octubre de 2026.
- **M6 U02 · Reclama con folio.** CONDUSEF, proceso de reclamación; consultado el 5 de octubre de 2026.

### Remesas que rinden

- **M7 U01 · Compara cómo te mandan el dinero.** PROFECO, Quién es Quién en el Envío de Dinero; Banco de México, remesas; consultados el 5 de octubre de 2026.
- **M7 U02 · Un plan para la remesa.** CONDUSEF, uso de remesas; consultado el 5 de octubre de 2026.

### Tu patrimonio y tu herencia

- **M8 U01 · Los papeles de tu casa y tu terreno.** Registro Agrario Nacional; consultado el 5 de octubre de 2026.
- **M8 U02 · Que tu familia no pelee por lo tuyo.** Gobierno de México, Mes del Testamento; Registro Agrario Nacional; consultados el 5 de octubre de 2026.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Antes de la temporada: tu plan de dinero

**Caso 1. Sin nada apartado.** Don Mel perdió su motor y no tenía ahorro. **¿Qué hace este año?**

- ✔ Aparta de cada venta desde marzo.
- Espera al aviso de huracán para juntar dinero.
- Le pide al comprador un adelanto por si acaso.

**Caso 2. Los papeles en el ropero.** Doña Chepa guarda sus escrituras en un cajón de madera. **¿Qué hace?**

- ✔ Los mete en doble bolsa cerrada y saca copias.
- Los deja en el cajón, porque siempre han estado ahí.
- Se los da a guardar al comprador del pueblo.

**Caso 3. Todo en la tarjeta.** Yesenia tiene su dinero solo en la tarjeta. **¿Qué hace?**

- ✔ Guarda también algo de efectivo.
- Deja todo en la tarjeta, porque es más seguro que en casa.
- Saca todo su dinero y lo guarda en la casa.

## M1 U02. Después del huracán: sin prisas ni préstamos caros

**Caso 1. El préstamo sin papeles.** Le ofrecen a Doña Chepa un préstamo de reconstrucción sin papeles. **¿Qué hace?**

- ✔ Busca primero los apoyos oficiales.
- Firma el préstamo ese mismo día.
- Acepta y deja sus escrituras como garantía.

**Caso 2. El registro con cuota.** Le piden 300 pesos para registrarse a un apoyo. **¿Qué hace?**

- ✔ No paga y va al módulo del municipio.
- Paga los 300 para no quedarse fuera del apoyo.
- Paga y comparte el mensaje con sus vecinas.

**Caso 3. El crédito de la lancha.** Don Mel no podrá pagar este mes el crédito de su lancha. **¿Qué hace?**

- ✔ Llama antes y pide prórroga.
- Deja de pagar sin avisar.
- Espera a que le llamen para explicar.

## M2 U01. Tus papeles en una bolsa

**Caso 1. Las escrituras mojadas.** Julián perdió sus escrituras en la inundación. **¿Qué hace para la próxima?**

- ✔ Guarda los originales en doble bolsa y respalda fotos.
- Los deja en el mismo lugar y reza para que no vuelva a pasar.
- Los guarda en la lancha.

**Caso 2. Las fotos en grupo.** Yesenia quiere subir fotos de sus papeles al grupo de la colonia «por si acaso». **¿Qué hace?**

- ✔ Las manda solo a un familiar de confianza.
- Las sube al grupo de la colonia por si alguien las necesita.
- Las publica en su perfil.

**Caso 3. La factura del motor.** Don Mel no tiene la factura de su motor en ningún lado. **¿Qué hace?**

- ✔ La pide al vendedor.
- Supone que no la necesitará nunca.
- Hace una a mano y la firma.

## M2 U02. Si perdiste tus papeles

**Caso 1. Sin INE.** Doña Chepa perdió su INE. **¿Qué hace?**

- ✔ Saca su CURP y acta y va al módulo del INE.
- Espera a que alguien le traiga una INE nueva a su casa.
- Pide prestada la INE de su hermana.

**Caso 2. El gestor.** Le ofrecen a Yesenia reponer sus papeles por 800 pesos. **¿Qué hace?**

- ✔ Lo hace ella, sin costo.
- Paga los 800 para no batallar.
- Paga la mitad y lo demás al recibir.

**Caso 3. El certificado ejidal.** El papá de Julián perdió su certificado ejidal. **¿Qué hace?**

- ✔ Pide la reposición en el Registro Agrario Nacional.
- Le pide al comisariado un papel firmado a mano.
- Da la parcela por perdida.

## M3 U01. Tu calendario de ingresos

**Caso 1. Septiembre de cada año.** Yesenia se endeuda cada septiembre. **¿Qué hace?**

- ✔ Aparta en los meses buenos.
- Pide prestado cada septiembre, como siempre.
- Busca otro trabajo solo en septiembre.

**Caso 2. La veda.** Don Mel no puede pescar ciertas especies en la veda. **¿Qué hace?**

- ✔ Marca la veda como mes bajo en su calendario.
- Pesca de todos modos en la veda.
- Pide un adelanto para la veda.

**Caso 3. La cosecha de limón.** Julián cobra fuerte en la cosecha y se le va rápido. **¿Qué hace?**

- ✔ Reparte lo que cobra entre los meses.
- Gasta lo que cobra mientras dura.
- Presta lo que cobra para que le paguen después.

## M3 U02. Aparta en la temporada buena

**Caso 1. La cosecha que se fue.** Julián cobra 30,000 y en dos meses no tiene nada. **¿Qué hace?**

- ✔ Aparta antes de gastar.
- Se compra lo que le faltaba y después ve.
- Lo presta para que le regresen poco a poco.

**Caso 2. La tarjeta de diario.** Yesenia aparta en la misma tarjeta que usa diario y se lo gasta. **¿Qué hace?**

- ✔ Usa un apartado o una cuenta distinta para su ahorro.
- Sigue apartando en la misma tarjeta, pero con fuerza de voluntad.
- Guarda su ahorro con su prima.

**Caso 3. La tanda sin reglas.** Doña Chepa quiere entrar a una tanda con gente que no conoce. **¿Qué hace?**

- ✔ Solo entra si hay reglas claras y conoce a las personas.
- Entra porque le toca el primer turno.
- Entra con dos números para cobrar más.

## M4 U01. Tu fondo de emergencia

**Caso 1. Saca todo.** Doña Chepa saca todo el envío el mismo día. **¿Qué hace?**

- ✔ Deja una parte en la cuenta.
- Saca todo el mismo día, como siempre.
- Saca todo y lo esconde en la casa.

**Caso 2. Para la fiesta.** Yesenia quiere usar su fondo para la fiesta de su prima. **¿Qué hace?**

- ✔ Lo deja para emergencias y ahorra aparte para la fiesta.
- Usa el fondo para la fiesta y luego lo repone.
- Usa la mitad del fondo.

**Caso 3. Usó el fondo.** Don Mel usó su fondo para arreglar el motor. **¿Qué hace?**

- ✔ Lo vuelve a llenar poco a poco.
- Lo deja vacío hasta el siguiente huracán.
- Pide prestado para llenarlo de golpe.

## M4 U02. ¿Asegurar tu casa?

**Caso 1. «Contra todo».** A Julián le ofrecen un seguro «contra todo». **¿Qué hace?**

- ✔ Pide por escrito qué cubre y el deducible.
- Lo contrata porque dice «contra todo».
- Lo contrata y pregunta después de un huracán.

**Caso 2. Una sola opción.** Doña Chepa solo conoce un seguro. **¿Qué hace?**

- ✔ Compara dos y verifica.
- Contrata el único que conoce.
- No contrata ninguno porque no confía.

**Caso 3. Sin respuesta.** La aseguradora no le responde a Don Mel su reclamación. **¿Qué hace?**

- ✔ Acude a CONDUSEF con su número de reclamación.
- Espera otro año.
- Deja de pagar el seguro sin avisar.

## M5 U01. El adelanto del comprador

**Caso 1. El adelanto de siempre.** Le ofrecen a Don Mel 8,000 a cambio de toda su pesca. **¿Qué hace?**

- ✔ Calcula cuánto dejaría de ganar antes de aceptar.
- Acepta porque así lo ha hecho siempre.
- Acepta y vende la mitad a otro comprador a escondidas.

**Caso 2. Los insumos fiados.** La tienda le fía a Julián fertilizante y le cobra al doble en la cosecha. **¿Qué hace?**

- ✔ Compara ese costo con otras formas de pagarlo.
- Acepta el fertilizante fiado sin preguntar el precio.
- Deja de fertilizar este año.

**Caso 3. Adelanto más chico.** Don Mel tiene la mitad de lo que necesita ahorrado. **¿Qué hace?**

- ✔ Pide solo lo que le falta.
- Pide todo el adelanto y guarda su ahorro.
- Pide el doble para tener de sobra.

## M5 U02. Compara el costo total de un crédito

**Caso 1. Dos créditos «iguales».** A Yesenia le parecen iguales dos créditos. **¿Qué hace?**

- ✔ Compara el total a pagar.
- Elige el de pago más chico.
- Elige el que le ofrecieron primero.

**Caso 2. Pagos en la veda.** El crédito de Don Mel pide pagos fijos durante la veda. **¿Qué hace?**

- ✔ Pregunta por pagos que se ajusten a su temporada.
- Firma con pagos fijos aunque caigan en la veda.
- Firma y piensa en pedir otro préstamo para la veda.

**Caso 3. La financiera del pueblo.** A Julián le prestan en una financiera que no conoce. **¿Qué hace?**

- ✔ La busca en el SIPRES antes de firmar.
- Firma porque es del pueblo y todos la conocen.
- Firma si le dan tarjeta de presentación.

## M6 U01. Tienes derecho a un trato digno

**Caso 1. «Venga con alguien que entienda».** A Doña Chepa no la atienden bien en la sucursal. **¿Qué hace?**

- ✔ Pide los requisitos por escrito y habla con el encargado.
- Se va sin cuenta y no vuelve.
- Pide a su hija que abra la cuenta a nombre de ella.

**Caso 2. Sin datos.** Yesenia quiere quejarse pero no anotó nada. **¿Qué hace?**

- ✔ La próxima vez anota los datos.
- Deja de quejarse porque no anotó.
- Publica una queja sin datos en redes.

**Caso 3. El cobro injusto.** A Julián le cobraron una comisión que no le explicaron. **¿Qué hace?**

- ✔ Reclama en el banco y, si no resuelven, va a CONDUSEF.
- Paga la comisión para evitar problemas.
- Cierra la cuenta sin reclamar.

## M6 U02. Reclama con folio

**Caso 1. «Se regresa solo».** A Don Mel le cobraron doble y le dicen que se regresa solo. **¿Qué hace?**

- ✔ Pide folio y anota la fecha.
- Espera a que se regrese solo, como le dijeron.
- Deja de pagar el crédito para compensar.

**Caso 2. Sin respuesta.** Pasó el plazo y no le resuelven. **¿Qué hace?**

- ✔ Va a CONDUSEF con su folio y pruebas.
- Espera otro mes más.
- Vuelve a la sucursal a reclamar de palabra.

**Caso 3. Sin papeles.** Yesenia quiere reclamar pero no tiene su estado de cuenta. **¿Qué hace?**

- ✔ Primero lo pide en el banco.
- Reclama sin papeles y confía en su memoria.
- Desiste porque no tiene papeles.

## M7 U01. Compara cómo te mandan el dinero

**Caso 1. «Ahí lo conocen».** El hijo de Doña Chepa siempre usa la misma empresa. **¿Qué hacen?**

- ✔ Comparan en el programa de PROFECO cuántos pesos llegan.
- Siguen igual porque ahí lo conocen.
- Cambian a la empresa con el anuncio más grande.

**Caso 2. «Sin comisión».** A Yesenia le anuncian envío sin comisión. **¿Qué hace?**

- ✔ Revisa también el tipo de cambio y los pesos que llegan.
- La elige porque no cobra comisión.
- La elige porque está más cerca.

**Caso 3. Cobrar en efectivo.** Doña Chepa cobra siempre en ventanilla y gasta todo. **¿Qué hace?**

- ✔ Pide recibirlo en su cuenta y deja una parte.
- Sigue cobrando en ventanilla y gastando todo.
- Cobra en efectivo y lo guarda bajo el colchón.

## M7 U02. Un plan para la remesa

**Caso 1. Todos piden.** A Doña Chepa le piden prestado cada vez que llega la remesa. **¿Qué hace?**

- ✔ Dice «ese dinero ya tiene destino».
- Presta a todos para no quedar mal.
- Presta solo a los familiares que pidan primero.

**Caso 2. Sin acuerdo.** El hijo de Doña Chepa no sabe en qué se usa el dinero. **¿Qué hacen?**

- ✔ Acuerdan el plan juntos.
- Ella decide sola sin contarle.
- Él decide todo desde allá.

**Caso 3. La meta.** Don Mel recibe remesa de su hija y quiere un motor nuevo. **¿Qué hace?**

- ✔ Aparta cada mes para la meta.
- Pide un préstamo para el motor ya.
- Espera a que algún mes sobre.

## M8 U01. Los papeles de tu casa y tu terreno

**Caso 1. Papeles del abuelo.** La casa de Julián sigue a nombre del abuelo. **¿Qué hace?**

- ✔ Pide orientación para iniciar la sucesión.
- Lo deja así, porque todos saben que es de la familia.
- Paga para que le cambien el nombre sin trámite.

**Caso 2. La parcela.** Don Mel no sabe si su parcela está registrada. **¿Qué hace?**

- ✔ Pregunta en el Registro Agrario Nacional.
- Supone que sí está registrada.
- Le pregunta al comprador del pueblo.

**Caso 3. El arreglo rápido.** Le ofrecen a Yesenia escriturar su terreno en una semana sin notario. **¿Qué hace?**

- ✔ Pregunta en una notaría.
- Paga para tener su escritura en una semana.
- Paga la mitad y lo demás al recibir el papel.

## M8 U02. Que tu familia no pelee por lo tuyo

**Caso 1. La lancha parada.** Don Mel no quiere que sus hijos peleen por la lancha. **¿Qué hace?**

- ✔ Hace testamento y dice a quién le deja la lancha.
- Deja que sus hijos se pongan de acuerdo después.
- Vende la lancha para que no peleen.

**Caso 2. La parcela.** Julián quiere que la parcela pase a su hija. **¿Qué hace?**

- ✔ La pone en su lista de sucesión.
- Le dice de palabra a su hija que es suya.
- Escribe una carta y la guarda.

**Caso 3. «No quiero hablar de eso».** Doña Chepa no quiere hablar de herencias con su familia. **¿Qué hace?**

- ✔ Toma su decisión y se la cuenta con calma.
- No decide nada para no tener que hablar.
- Deja que su familia decida por ella.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Cuándo termina la temporada de huracanes en el Pacífico?

- ✔ El 30 de noviembre
- El 15 de mayo
- En enero, con el año nuevo

*¡Correcto! 30 de noviembre.*

**M1 U01 P2.** ¿Cuándo preparas tu plan?

- Cuando ya está el aviso de huracán
- Después del huracán
- ✔ Antes del 15 de mayo

*¡Correcto! Antes de la temporada.*

**M1 U01 P3.** ¿Por qué guardar un poco de efectivo?

- ✔ Por si se va la luz y no hay cajeros
- Porque el banco cierra en temporada
- Para pagarle al comprador antes de que suba el precio

*¡Correcto! Sin luz no hay cajeros.*

**M1 U02 P1.** Te cobran por registrarte a un apoyo después del huracán. ¿Qué es?

- Normal
- ✔ Fraude
- Una cuota de recuperación oficial

*¡Correcto! Los registros oficiales no se cobran.*

**M1 U02 P2.** ¿Qué haces primero después del huracán?

- Vendes tu lancha
- Firmas un préstamo de reconstrucción ese mismo día
- ✔ Cuidas a tu familia: salud, agua y comida

*¡Correcto! Familia primero.*

**M1 U02 P3.** Tienes un crédito y no podrás pagar. ¿Cuándo llamas?

- Cuando te llamen a cobrar
- ✔ Antes de atrasarte
- Nunca

*¡Correcto! Antes.*

## Módulo 2

**M2 U01 P1.** ¿Dónde guardas tus originales?

- En un cajón bajo de madera
- ✔ En doble bolsa cerrada y en alto
- En la lancha, que es donde pasas más tiempo

*¡Correcto! Protegidos del agua.*

**M2 U01 P2.** ¿A quién mandas las fotos de tus papeles?

- A quien te las pida
- Al grupo de la colonia, por si alguien las necesita
- ✔ A un familiar de confianza

*¡Correcto! Solo confianza.*

**M2 U01 P3.** ¿Qué papel sirve para comprobar que tu lancha es tuya?

- Tu credencial del INE con tu domicilio en la costa
- ✔ La factura de la lancha
- Un recibo de luz

*¡Correcto! La factura.*

**M2 U02 P1.** ¿Por dónde empiezas a reponer papeles?

- Por las escrituras
- ✔ Por la CURP y el acta
- Por el pasaporte, que vale para todo

*¡Correcto! Abren lo demás.*

**M2 U02 P2.** ¿Dónde repones un certificado ejidal?

- En el banco donde tienes tu cuenta
- En la tienda
- ✔ En el Registro Agrario Nacional

*¡Correcto! RAN.*

**M2 U02 P3.** Te cobran 800 por reponer tu INE. ¿Qué haces?

- Pagas
- Pagas la mitad ahora y la otra mitad al recibirla
- ✔ Lo haces tú: es sin costo

*¡Correcto! Sin costo.*

## Módulo 3

**M3 U01 P1.** ¿Qué es un mes bajo?

- ✔ Un mes en que entra menos de lo que gastas
- Un mes con muchas fiestas y compromisos en el pueblo
- Un mes de vacaciones de la escuela

*¡Correcto! Entra menos.*

**M3 U01 P2.** ¿Cuándo apartas dinero?

- En los meses bajos
- Solo en diciembre, con el aguinaldo
- ✔ En los meses buenos

*¡Correcto! Cuando sobra.*

**M3 U01 P3.** ¿Qué marcas además del ingreso?

- ✔ Los gastos fuertes
- Los cumpleaños de los vecinos
- Nada más

*¡Correcto! Gastos fuertes.*

**M3 U02 P1.** Cobras 24,000 que deben durar 4 meses. ¿Cuánto usas por mes?

- 24,000 el primer mes
- ✔ 6,000
- 4,000

*¡Correcto! 24,000 entre 4.*

**M3 U02 P2.** ¿Qué haces primero al cobrar fuerte?

- Pagas la fiesta
- Compras lo que te faltaba desde la temporada pasada
- ✔ Apartas lo de los meses bajos

*¡Correcto! Primero apartas.*

**M3 U02 P3.** ¿Qué necesita una tanda para ser más segura?

- Mucha gente, aunque no la conozcas, para juntar más
- ✔ Reglas claras y personas conocidas
- Que nadie sepa el orden

*¡Correcto! Reglas y confianza.*

## Módulo 4

**M4 U01 P1.** ¿Cuál es un uso correcto del fondo?

- ✔ Una reparación urgente
- Una fiesta
- Un celular nuevo porque hay oferta

*¡Correcto! Es emergencia.*

**M4 U01 P2.** ¿Dónde guardas tu fondo?

- En la tarjeta de diario
- Prestado a un vecino
- ✔ En un apartado o cuenta aparte

*¡Correcto! Aparte.*

**M4 U01 P3.** Usaste tu fondo. ¿Qué haces después?

- Nada
- Pides prestado para llenarlo de una vez
- ✔ Vuelves a apartar poco a poco

*¡Correcto! Lo llenas.*

**M4 U02 P1.** ¿Qué preguntas primero a un seguro de casa en la costa?

- El color de la póliza
- ✔ Si cubre huracán e inundación
- Si regalan algo al contratar este mes

*¡Correcto! Lo que más te importa.*

**M4 U02 P2.** El daño es de 30,000 y el deducible de 3,000. ¿Cuánto pagaría el seguro?

- 3,000
- 30,000
- ✔ 27,000

*¡Correcto! 30,000 menos 3,000.*

**M4 U02 P3.** La aseguradora no te responde. ¿A dónde vas?

- A otra aseguradora
- ✔ A CONDUSEF
- A ningún lado

*¡Correcto! CONDUSEF.*

## Módulo 5

**M5 U01 P1.** Te adelantan dinero si les vendes más barato. ¿Qué es?

- Un regalo
- ✔ Un préstamo
- Un apoyo de gobierno

*¡Correcto! Se paga con producto.*

**M5 U01 P2.** Vendes 400 kilos a 15 pesos menos. ¿Cuánto dejas de ganar?

- 4,000
- 415
- ✔ 6,000

*¡Correcto! 15 por 400.*

**M5 U01 P3.** Tienes la mitad ahorrada. ¿Qué pides?

- Todo el adelanto por si acaso
- ✔ Solo lo que te falta
- El doble para guardar

*¡Correcto! Solo lo que falta.*

**M5 U02 P1.** Pagas 900 por semana durante 25 semanas. ¿Cuánto pagas en total?

- ✔ 22,500
- 900
- 25,900

*¡Correcto! 900 por 25.*

**M5 U02 P2.** ¿Qué indicador compara el costo de dos créditos?

- El nombre del asesor
- El color del anuncio
- ✔ El CAT

*¡Correcto! CAT.*

**M5 U02 P3.** Tus pagos caerían en tus meses bajos. ¿Qué haces?

- Firmas igual
- ✔ Pides pagos ajustados o esperas
- Pides otro crédito para pagar este

*¡Correcto! Ajusta o espera.*

## Módulo 6

**M6 U01 P1.** Te niegan un servicio por tu forma de hablar. ¿Qué es?

- ✔ Discriminación
- Una regla del banco
- Un malentendido normal

*¡Correcto! Es discriminación.*

**M6 U01 P2.** ¿Qué número es del CONAPRED?

- 911
- El de la sucursal
- ✔ 800 543 0033

*¡Correcto! CONAPRED.*

**M6 U01 P3.** ¿Qué anotas si te tratan mal?

- Solo tu nombre
- ✔ Fecha, hora, lugar y quién te atendió
- Nada, porque las quejas no sirven para nada

*¡Correcto! Los datos.*

**M6 U02 P1.** ¿Qué es lo más importante al reclamar?

- Gritar fuerte
- ✔ Pedir folio
- Ir muchas veces sin anotar

*¡Correcto! El folio.*

**M6 U02 P2.** No te resuelven. ¿A dónde vas?

- A tu casa
- A otro banco
- ✔ A CONDUSEF

*¡Correcto! CONDUSEF.*

**M6 U02 P3.** ¿Qué llevas a tu reclamación?

- Nada
- ✔ Estado de cuenta, comprobantes y contrato
- Solo tu INE, porque ellos tienen todo lo demás

*¡Correcto! Tus pruebas.*

## Módulo 7

**M7 U01 P1.** ¿Qué comparas entre empresas de envío?

- ✔ Los pesos que llegan
- El color del logo
- Qué tan cerca está la oficina

*¡Correcto! Lo que llega.*

**M7 U01 P2.** Un envío «sin comisión»…

- siempre es el mejor, porque no te cobran nada
- es un fraude
- ✔ puede pagar un tipo de cambio más bajo

*¡Correcto! Revisa el cambio.*

**M7 U01 P3.** ¿Qué programa compara envíos de dinero?

- El SIPRES
- ✔ Quién es Quién en el Envío de Dinero, de PROFECO
- El Buró de Crédito, que revisa a las empresas

*¡Correcto! PROFECO.*

**M7 U02 P1.** ¿Cuáles son las tres partes del plan?

- Fiestas, regalos y préstamos
- ✔ Lo básico, ahorro y una meta
- Todo para lo básico

*¡Correcto! Tres partes.*

**M7 U02 P2.** Llegan 6,000 y apartas 10% para ahorro. ¿Cuánto es?

- 1,000
- 60
- ✔ 600

*¡Correcto! 10% de 6,000.*

**M7 U02 P3.** ¿Con quién acuerdas el plan?

- Con los vecinos que también reciben remesas
- ✔ Con quien manda la remesa
- Con nadie

*¡Correcto! Con quien la manda.*

## Módulo 8

**M8 U01 P1.** ¿Qué papel comprueba una propiedad privada?

- ✔ La escritura registrada
- El recibo de luz a tu nombre de los últimos años
- Una foto de la casa

*¡Correcto! La escritura.*

**M8 U01 P2.** ¿Dónde se registran los derechos ejidales?

- En el banco donde tienes tu cuenta
- En la tienda del pueblo
- ✔ En el Registro Agrario Nacional

*¡Correcto! RAN.*

**M8 U01 P3.** Te ofrecen escriturar en una semana sin notario. ¿Qué haces?

- Pagas
- ✔ Desconfías y preguntas en una notaría o el municipio
- Pagas la mitad

*¡Correcto! Desconfía.*

**M8 U02 P1.** ¿Con qué dejas tu casa a tu familia?

- ✔ Con un testamento
- Con un recibo
- De palabra, frente a toda la familia reunida

*¡Correcto! Testamento.*

**M8 U02 P2.** ¿En qué mes el testamento cuesta menos en muchas notarías?

- Enero
- Diciembre
- ✔ Septiembre

*¡Correcto! Septiembre.*

**M8 U02 P3.** ¿Dónde pones beneficiarios de tu Afore?

- ✔ En tu Afore
- En el RAN
- En la notaría

*¡Correcto! En tu Afore.*
