# Your Money, Your Family, Your Future: implementation guide

For the team that sets up and runs the course in Moodle 3.10.

# Part 1. Installation in Moodle, step by step

The same file is in `04_Moodle/README_INSTALL_YOUR_MONEY_EN_FOR_CLAUDE.md`.


You will create the course **Your Money, Your Family, Your Future** on academia.desarrollatalento.com. The site runs Moodle 3.10, the Boost theme, Level Up 3.15.2 and the **Custom certificate** plugin (mod_customcert).

If other courses exist on the site, **do not touch them.**

Work in the browser with the administrator session the person opened.

Rules:

- Use only the web interface.
- Do not use SSH.
- Do not install plugins.
- Do not change site settings.
- Do not touch other courses.
- If anything does not match these instructions, stop and ask.

### 0. Before you start

1. Confirm that no course with the short name `TDTF-CA-EN` exists. If it does, stop and ask.
2. Check in *Site administration > Plugins > Plugins overview* whether **Custom certificate** and **Level Up** exist. Note it for the report.
3. If the site has no H5P activities yet, the first one you upload installs its libraries: upload it with the administrator account. If a library error appears, stop and report the exact message.

### 1. Create the course

| Field | Value |
|---|---|
| Full name | Your Money, Your Family, Your Future |
| Short name | TDTF-CA-EN |
| Visibility | **Show** |
| Format | **Tiles** if installed; otherwise Topics. 7 sections |
| Completion tracking | Yes |
| Force language | English |

**Tiles format (if available):** in course settings, *Show progress on tiles*: **as a percentage**; one icon per module that fits its topic; the General section above the tiles. If Tiles doesn't exist, use Topics with "Show one section per page."

**Enrolment:** *Enrolment methods* > enable **Self enrolment** with the **enrolment key** the person gives you (if you don't have it, leave "[TBD]" and report it). Turn off guest access.

### 2. Sections

| Section | Name | Description |
|---|---|---|
| General | Welcome | Link to chapter 1 of the support book and the forum "Questions and comments" |
| 1 | Module 1. Understand your money and organize your finances | Content of `1_books/M1_resumen.html` |
| 2 | Module 2. Understand the financial system and plan your remittances | `M2_resumen.html` |
| 3 | Module 3. Build your credit and manage your debts | `M3_resumen.html` |
| 4 | Module 4. Protect your money, your identity and your family | `M4_resumen.html` |
| 5 | Module 5. Build wealth and prepare your future | `M5_resumen.html` |
| 6 | Support materials | "Cases, practice, glossary and where to get help." |
| 7 | Assessment and certificate | "Your certificate of completion." |

Description of the forum "Questions and comments": "Don't share account numbers, SSN, ITIN, passwords or your immigration status."

### 3. Lesson books

In each module section:

1. Create a book: name `Module N lessons`, chapter formatting "None", completion "View".
2. Book menu > **Import chapter** > `1_books/MN_libro_Moodle.zip`, type "Each HTML file represents one chapter".
3. Check that each lesson has its cover page first and 3 indented subchapters.

| Module | Chapters | Pages |
|---|---|---|
| M1 | 14 | 56 |
| M2 | 13 | 52 |
| M3 | 10 | 40 |
| M4 | 11 | 44 |
| M5 | 11 | 44 |

### 4. Support book

In section 6, create the book `Support materials` with the same settings and import `1_books/Apoyo_libro_Moodle.zip` (6 chapters). In the General section, add a **URL** or label to chapter 1 ("Welcome").

In the same section 6, add a **File** resource named `Tools for your numbers (Excel)` with the file in `10_tools/`. Display: "Force download". Description: "Budget, debt list, emergency fund and compound-interest goal. Type only in the pink cells; the file is yours and isn't shared." Completion: "View".

### 5. Glossary

In section 6, create the glossary `Course key words` and import `3_glossary/Glosario_curso_Moodle.xml`, destination "current glossary".

### 6. Question bank and self-assessments

1. *Question bank > Import*: GIFT format, `4_questions/banco_preguntas_v3_en.gift.txt`. Categories *Your Money v3.3/M1* to *M5* are created, with 177 questions.
2. In each module section, create the quiz `Module N self-assessment`: grade to pass 70, unlimited attempts, highest grade, shuffle answers, review with correct answer and feedback, completion "Require passing grade".
3. Add **all** questions from *Your Money v3.3/MN*, 10 per page:

| M1 | M2 | M3 | M4 | M5 |
|---|---|---|---|---|
| 42 | 39 | 30 | 33 | 33 |

### 7. H5P activities (59)

Files in `2_h5p/MN/`, in order. In each section, **after the book** and in lesson order:

1. *Add an activity > H5P*.
2. Name: `MN UYY · What would you do?`.
3. Upload `MN_UYY_what_would_you_do.h5p`.
4. Options: download no, embed no, copyright yes.
5. Grade: tracking yes, "highest grade". Completion: "Student must receive a grade".

**Final order of each section:** book, H5P in order, self-assessment.

**Check:** open 3 random activities with *Switch role to > Student*. You should see 3 cases, 3 options per case and the grade at the end.

### 8. Program surveys

`8_surveys/` has the surveys and their document `surveys.md`. Use the **Feedback** module in **anonymous** mode and, in each one, *Templates > Import questions* with its XML (if the import fails, build them by hand from `surveys.md`):

| Activity | Section | File | Completion |
|---|---|---|---|
| `Start survey` | General | `survey_start.xml` | Submit |
| `Final survey` | 7 | `survey_final.xml` | Submit; required for the certificate |
| `30-day follow-up` | 7 | `survey_follow_up.xml` | Submit |
| `90-day follow-up` | 7 | `survey_follow_up.xml` | Submit |

Restrict the follow-ups by date: 30 and 90 days after the cohort's end date ("[TBD]"). The final survey is the program's evidence of results: don't skip it.

### 9. Level Up, badges, completion and certificate

Follow `7_guides/gamification_guide.md`: sections 2 (Level Up), 3 (8 badges with `5_badges/`; each name includes the course so it's unique on the platform), 4 (completion with the 5 self-assessments) and 5 (certificate with the standard template and the data in `6_certificate/certificate.md`). If Level Up or Custom certificate does not exist, do not install it: skip that step and report it.

### 10. Final review (as a student)

- M1 U01: cover page first, two path buttons, colored terms with their meaning and "Current fact" or "Before you act, check" boxes.
- One H5P per module opens, shows 3 cases and records a grade.
- One self-assessment shows 3 options per question.
- The support book shows "See the key" in the case studies and collapsible frequently asked questions.

### 11. Report for the person

Course link; pages per book; H5P per module; questions per self-assessment; surveys created; active badges; Level Up settings; certificate status; what you could not do and why; screenshots of the tiles home page, an H5P, a self-assessment and the certificate preview.

The course stays **visible**, with enrolment by key. For the catalog listing, use `catalog_card.md`.


# Part 2. Activities, points, badges and certificate


This guide is for Moodle 3.10 with Level Up (block_xp) 3.15.2 and the Custom certificate plugin (mod_customcert).

The goal is to motivate without competing. Points reward progress, not perfect scores. Nobody's name is ever shown in a table.

### 1. What each module has

| Activity | How many | Completion |
|---|---|---|
| Book "Module N lessons" | 1 per module (5) | View |
| H5P activity "MN UYY · What would you do?" | 1 per lesson (59) | Receive a grade |
| Quiz "Module N self-assessment" | 1 per module (5) | Passing grade of 70% |

**Each H5P activity:** no download button, copyright button on, embed off; attempt tracking with "Highest grade"; completion "Student must receive a grade".

**Self-assessments:** use the bank of 177 three-option questions with feedback, in categories *Your Money v3.3/M1* to *M5*. Passing grade 70%, unlimited attempts, shuffled answers and review with the correct answer and feedback at the end.

### 2. Level Up: levels and points

**Rules** (*Level Up > Rules*):

1. Remove the default rules or set them to 0.
2. **For completing any activity:** 25 points, event "Course module completion updated" (`\core\event\course_module_completion_updated`).
3. **For posting in the forum:** 5 points, event "Post created" (`\mod_forum\event\post_created`).
4. Keep cheat guard on.

Completing the whole course gives about 1,725 points:

| Activities | How many | Points |
|---|---|---|
| H5P activities | 59 | 1,475 |
| Books | 5 | 125 |
| Self-assessments | 5 | 125 |
| **Total** | 69 | **1,725** |

**Levels** (6 levels, no automatic algorithm):

| Level | Name | Points | Reached around |
|---|---|---|---|
| 1 | Getting started | 0 | On entry |
| 2 | Getting organized | 150 | Halfway through Module 1 |
| 3 | Using my account | 450 | During Module 2 |
| 4 | Caring for my credit | 800 | During Module 3 |
| 5 | Protecting my family | 1,150 | During Module 4 |
| 6 | Building my future | 1,500 | During Module 5 |

**Ladder:** anonymity on; show only nearby neighbors or turn it off.

### 3. Badges

*Course administration > Badges > Add a new badge*. Images in `5_badges/`. Issuer: Desarrolla Talento. Expiry: never. Names include the course so they're unique on the platform: use them exactly.

| Image | Badge | Criterion (activity completion, with passing grade) | Description |
|---|---|---|---|
| 01_M1_my_money_in_order.png | My money in order · Your Money | Module 1 Self-assessment completed (passed) | You organized your cash flow, your budget and your taxes. 14 lessons, about 3 hours. |
| 02_M2_smart_sending.png | Smart sending · Your Money | Module 2 Self-assessment | You know how to choose an account, compare remittances and protect your family from fraud. 13 lessons. |
| 03_M3_credit_on_track.png | Credit on track · Your Money | Module 3 Self-assessment | You understand your report, compare loans and have a debt plan. 10 lessons. |
| 04_M4_protected_family.png | Protected family · Your Money | Module 4 Self-assessment | You have a plan for protection, insurance and family preparedness. 11 lessons. |
| 05_M5_future_in_motion.png | Future in motion · Your Money | Module 5 Self-assessment | Your goals, your retirement and your one-page plan are in writing. 11 lessons. |
| 06_scam_detective.png | Scam detective · Your Money | H5P for M2 U11, M4 U01 and M4 U02 completed | You recognize the signs of fraud and verify before you act. |
| 07_expert_comparer.png | Expert comparer · Your Money | H5P for M2 U08, M3 U05 and M5 U05 completed | You compare by total cost, not just the advertised price. |
| 08_complete_plan.png | Complete plan · Your Money | Course completion | You completed the program's five modules. |

When done, **enable** each badge.

### 4. Course completion

*Course administration > Course completion*: activity completion condition with **all** 5 self-assessments. Optional: the 5 books.

### 5. Certificate of completion (Custom certificate)

1. In the section "Assessment and certificate", add **Custom certificate** using the **platform's standard template** (no background image): name "Certificate of completion".
2. **Restrict access:** one "Activity completion" condition for each of the 5 self-assessments, "must be marked complete and pass", and the **Final survey** submitted.
3. In the template change only these data (also in `6_certificate/certificate.md`):

   | Field | Text |
   |---|---|
   | Course title | Your Money, Your Family, Your Future |
   | Line | for completing the financial well-being program Your Money, Your Family, Your Future |
   | Topic 1 | My money |
   | Topic 2 | Financial system |
   | Topic 3 | Credit and debt |
   | Topic 4 | Protection |
   | Topic 5 | Future and wealth |

4. Check the **PDF preview** and turn on "Verify certificate".

If Custom certificate is not installed, the **Complete plan · Your Money** badge works as a digital certificate.

### 6. What not to do

- Do not give points for viewing pages.
- Do not post names in rankings.
- Do not ask for real data to pass.
- Do not tie badges or the certificate to buying services or products.

