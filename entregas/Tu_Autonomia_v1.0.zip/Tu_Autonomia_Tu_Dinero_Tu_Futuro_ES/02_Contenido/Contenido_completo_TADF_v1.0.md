# Tu Autonomía, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Leticia | 45 años. Ama de casa en Querétaro; su esposo maneja todo el dinero de la casa. |
| Lucía | 38 años. Separada, con dos hijos. Trabaja en una tienda y recibe pensión alimenticia que a veces no llega. |
| Doña Rosario | 61 años. Dejó de trabajar para cuidar a sus papás. Tiene ocho años cotizados en el IMSS. |
| Andrea | 29 años. Trabaja en una oficina y quiere tener su propio ahorro y su retiro en orden. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Mi dinero, mi nombre | Una cuenta, tus documentos y un ingreso propio a tu nombre. | A mi nombre |
| Módulo 2. Un presupuesto que cuenta los cuidados | Tu presupuesto del hogar con tu trabajo de cuidados contado y acuerdos de dinero claros. | Mi trabajo cuenta |
| Módulo 3. Afore, semanas y aportaciones voluntarias | Tu Afore localizada, tus semanas revisadas y tu primera aportación voluntaria. |  |
| Módulo 4. Pensión Mujeres Bienestar | Tu registro o el de una mujer cercana a la Pensión Mujeres Bienestar, y un plan para usarla. |  |
| Módulo 5. Seguros para mí | Tus seguros revisados y tu decisión sobre un seguro para ti. | Protegida |
| Módulo 6. Violencia económica: señales y salida | Las señales de violencia económica y tu plan de seguridad económica. | Mi dinero es mío |
| Módulo 7. Pensión alimenticia | Tus pasos para pedir, cobrar y administrar la pensión alimenticia. | Derechos de mis hijos |
| Módulo 8. Estrés financiero y salud | Tus tres pasos pequeños para bajar el estrés por dinero y tu plan de autonomía. | En calma |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Dinero a mi nombre, Trabajo de cuidados, Afore y pensión, Violencia económica, Estrés y salud.

## 3. Lecciones

# Parte 2. Módulo 1. Mi dinero, mi nombre

## M1 U01. Una cuenta a tu nombre

**Lo que lograrás:** Abrir o usar una cuenta a tu nombre para tener dinero que solo tú controlas.

**Para empezar:** Leticia lleva 20 años casada. Todo el dinero entra a la cuenta de su esposo y él le da «para el gasto». Cuando quiere comprar algo para ella, tiene que pedir. En esta lección verás por qué una cuenta propia cambia eso.

### Lo esencial (5 minutos)

#### Tu cuenta, tu decisión

Una cuenta a tu nombre es dinero que solo tú puedes mover con tu tarjeta y tu NIP. En México, 58.6% de las mujeres tiene cuenta, contra 68.0% de los hombres.



#### Lo que te da

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguridad | Tu dinero no depende de nadie. | Ni de una casa. |
| Decisión | Usas lo tuyo sin pedir. | Autonomía. |
| Ahorro | Puedes guardar para ti. | Aunque sea poco. |
| Historial | Empiezas tu propia historia financiera. | Para el futuro. |

#### Cuál abrir

Pide una **cuenta básica**: sin comisión por manejo ni saldo mínimo, con tu INE. Revisa que la institución esté en el SIPRES de CONDUSEF. No te recomendamos un banco: tú eliges.



#### Un caso en un minuto

Leticia abrió una cuenta básica. Le pidió a su esposo que el gasto de la casa se lo deposite ahí. Ahora ve lo que entra y puede apartar un poco para ella.

> **Idea clave:** una cuenta a tu nombre es dinero que decides tú; pide la cuenta básica.



#### Comprueba lo que entendiste

1. ¿Quién mueve el dinero de tu cuenta?
*Respuesta:* Solo yo, con mi tarjeta y mi NIP.

2. ¿Qué cuenta pides para no pagar comisiones?
*Respuesta:* La cuenta básica.


#### Para recordar

- A tu nombre.
- Cuenta básica.
- Tú decides.



### Profundiza (5 minutos más)

#### Cuentas compartidas

Una cuenta mancomunada es de dos personas. Puede servir para gastos de la casa, pero no sustituye una cuenta tuya.



#### Tu NIP es tuyo

Aunque confíes en tu pareja, tu NIP no se comparte. Es como la llave de tu casa.



#### Casos


**Caso 1. «Para el gasto»**

El esposo de Leticia le da efectivo cada semana.
- *¿Qué hace?* Abre una cuenta básica y pide que se lo deposite ahí.


**Caso 2. La cuenta de los dos**

Andrea y su novio quieren una sola cuenta para todo.
- *¿Qué hace?* Abre una compartida para la casa y mantiene la suya.


**Caso 3. El NIP**

La pareja de Lucía le pide su NIP «por si acaso».
- *¿Qué hace?* No se lo da; el NIP es solo suyo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener cuenta propia | Dependes | Ábrela |
| Solo cuenta compartida | Sin espacio tuyo | Ten la tuya |
| Compartir el NIP | Pierdes el control | Es tuyo |
| Pagar comisiones | Gasto inútil | Cuenta básica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Andrea y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué te da una cuenta a tu nombre? a) Que tu pareja vea tus gastos · b) Más deudas · c) Dinero que decides tú
2. ¿Qué porcentaje de mujeres tiene cuenta en México? a) 90%, casi todas · b) 58.6% · c) 20%, una de cada cinco
3. Tu pareja te pide tu NIP. ¿Qué haces? a) Le das la mitad · b) No se lo das · c) Se lo das
**Respuestas:** 1-c: tú decides. 2-b: 58.6%. 3-b: es tuyo.



#### Ponlo en práctica

Apartas 100 pesos de cada gasto semanal en tu cuenta. ¿Cuánto en un año?
**Respuesta:** 5,200 pesos.



#### A tu plan

Si no tienes cuenta a tu nombre, elige dónde abrirás una cuenta básica esta semana.



### Para saber más

- **Cuentas básicas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Cuenta básica:* cuenta sin comisión por manejo.
- *Cuenta mancomunada:* cuenta de dos personas.
- *Autonomía:* poder decidir por ti misma.

### Fuentes

INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M1 U02. Tus documentos y tus bienes a tu nombre

**Lo que lograrás:** Identificar qué documentos deben estar a tu nombre y guardar copias.

**Para empezar:** Leticia y su esposo compraron una casa hace 15 años. Ella aportó la mitad del enganche con lo que vendió de comida. La escritura está solo a nombre de él. En esta lección verás por qué importa.

### Lo esencial (5 minutos)

#### Lo que no está a tu nombre, no lo puedes probar

Quizá aportaste a una casa, un terreno, un auto o un negocio y no estás en los papeles. Así te cuesta mucho demostrar que también es tuyo.



#### Revisa a nombre de quién está

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Casa o terreno | Escritura en el Registro Público. | ¿Apareces? |
| Auto | Factura y tarjeta de circulación. | ¿A tu nombre? |
| Negocio | Registro en el SAT, permisos. | ¿Tuyo? |
| Régimen matrimonial | Sociedad conyugal o separación de bienes. | En tu acta de matrimonio. |

#### Ten copias tuyas

Guarda copia de tu acta de matrimonio, escrituras, facturas y contratos en un lugar que solo tú conozcas o en tu correo.



#### Un caso en un minuto

Leticia revisó su acta de matrimonio: están casados por sociedad conyugal, así que la casa también es suya aunque no aparezca. Pidió copia de la escritura y la guardó con sus papeles.

> **Idea clave:** revisa a nombre de quién están tus bienes y tu régimen matrimonial, y guarda copias tuyas.



#### Comprueba lo que entendiste

1. ¿Dónde ves tu régimen matrimonial?
*Respuesta:* En mi acta de matrimonio.

2. ¿Por qué guardar copias propias?
*Respuesta:* Para poder demostrar lo que es mío si hace falta.


#### Para recordar

- Revisa a nombre de quién.
- Régimen matrimonial.
- Copias tuyas.



### Profundiza (5 minutos más)

#### Mis bienes

| Bien | A nombre de | Copia guardada |
|---|---|---|
| Casa o terreno | | |
| Auto | | |
| Negocio | | |
| Acta de matrimonio | | |



#### En unión libre

Si vives en unión libre, protegerte depende más de los papeles. Pregunta en una notaría o en la defensoría pública cómo quedar en las escrituras de lo que compran juntos.



#### Casos


**Caso 1. La escritura**

La casa de Leticia está solo a nombre de su esposo.
- *¿Qué hace?* Revisa su régimen matrimonial y guarda copia de la escritura.


**Caso 2. El auto de Lucía**

Lucía pagó el auto, pero la factura está a nombre de su expareja.
- *¿Qué hace?* Junta sus comprobantes de pago y pide orientación legal.


**Caso 3. La compra nueva**

Andrea y su pareja van a comprar un terreno.
- *¿Qué hace?* Pide que la escritura quede a nombre de los dos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar papeles | No sabes qué es tuyo | Revisa |
| Sin copias propias | No puedes probar | Guárdalas |
| Comprar solo a nombre del otro | Te quedas fuera | A nombre de los dos |
| No saber tu régimen | Sorpresas | Revisa tu acta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Lucía y Andrea. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde ves si estás casada por sociedad conyugal? a) En tu recibo de luz · b) En tu INE, atrás de la foto · c) En tu acta de matrimonio
2. Van a comprar un terreno juntos. ¿Cómo debe quedar la escritura? a) Solo a nombre de él · b) A nombre de los dos · c) Sin nombre
3. ¿Dónde guardas copias de tus papeles? a) Se las das a tu suegra para que las cuide · b) En un lugar que solo tú conozcas o en tu correo · c) Donde todos las vean
**Respuestas:** 1-c: el acta. 2-b: los dos. 3-b: lugar tuyo.



#### Ponlo en práctica

Escribe dos bienes de tu hogar y a nombre de quién están.
**Respuesta:** Respuesta personal, por ejemplo: «La casa, a nombre de los dos; el auto, a nombre de mi pareja».



#### A tu plan

Llena la tabla «Mis bienes» y guarda copias en tu correo.



### Para saber más

- **Registro Público de la Propiedad** de tu estado — **Qué buscar:** «certificado de libertad de gravamen» o «copia de escritura».
- **Defensoría pública** (Poder Judicial de tu estado) — **Qué buscar:** «defensoría pública familiar».

### Palabras clave

- *Escritura:* papel que dice de quién es una casa o terreno.
- *Sociedad conyugal:* lo que compran durante el matrimonio es de los dos.
- *Separación de bienes:* cada quien es dueño de lo suyo.

### Fuentes

Códigos civiles estatales, regímenes matrimoniales; consultado el 5 de octubre de 2026.

---

## M1 U03. Un dinero propio, aunque no tengas sueldo

**Lo que lograrás:** Tener una parte del dinero del hogar para ti y tomar decisiones de dinero en pareja.

**Para empezar:** Leticia no tiene sueldo porque cuida la casa y a sus hijos. Piensa que «no tiene derecho» a gastar en ella. Su esposo cree que el dinero es de él porque él lo gana. En esta lección verás otra manera de verlo.

### Lo esencial (5 minutos)

#### El dinero del hogar es de quienes lo sostienen

Si tú cuidas la casa y los hijos, haces posible que tu pareja trabaje. El dinero del hogar es de los dos, aunque solo uno reciba el sueldo.



#### Un acuerdo justo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gastos de la casa | Lo de todos. | Primero. |
| Dinero para cada quien | Una cantidad igual para los dos. | Sin dar explicaciones. |
| Ahorro en común | Para metas de la familia. | Acordado. |

#### Hablarlo con números

Propón una plática con el presupuesto en la mano: cuánto entra, cuánto se va en la casa y cuánto queda. Pide una cantidad igual para cada uno.



#### Un caso en un minuto

Leticia propuso que, después de los gastos, cada uno tenga 600 pesos al mes para sí. Su esposo aceptó. Ella los deposita en su cuenta y decide en qué usarlos.

> **Idea clave:** el dinero del hogar es de quienes lo sostienen; acuerden una cantidad igual para cada quien.



#### Comprueba lo que entendiste

1. ¿De quién es el dinero del hogar si tú cuidas la casa?
*Respuesta:* De los dos, aunque solo uno reciba sueldo.

2. ¿Qué propones en el acuerdo?
*Respuesta:* Una cantidad igual para cada uno, sin dar explicaciones.


#### Para recordar

- El dinero es de los dos.
- Cantidad igual para cada quien.
- Háblenlo con números.



### Profundiza (5 minutos más)

#### El acuerdo de Leticia

- Entra al mes: **16,000**
- Gastos de la casa y ahorro: **14,000**
- Queda: **2,000**
- 600 para cada quien: **1,200**
- Para ahorro en común: **800**


#### Un ingreso propio también ayuda

Si puedes y quieres, un ingreso propio (por pocas horas o por tu cuenta) te da más margen. Pero no es requisito para que tengas derecho al dinero del hogar.



#### Casos


**Caso 1. «No tengo derecho»**

Leticia cree que no puede gastar en ella porque no gana sueldo.
- *¿Qué hace?* Propone un acuerdo con una cantidad igual para cada uno.


**Caso 2. «Es mi dinero»**

El esposo de Leticia dice que el dinero es de él.
- *¿Qué hace Leticia?* Le muestra con números cómo sostienen juntos el hogar.


**Caso 3. Pareja nueva**

Andrea empieza a vivir con su pareja.
- *¿Qué hace?* Acuerdan desde el inicio gastos comunes y dinero de cada quien.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no tienes derecho | Te quedas sin nada | Es de los dos |
| No hablarlo | Resentimiento | Con números |
| Montos desiguales | Injusto | Igual para los dos |
| Esperar a tener sueldo | Pierdes años | Acuerdo ahora |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, su esposo y Andrea. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Cuidas la casa y tu pareja gana el sueldo. ¿De quién es el dinero del hogar? a) De nadie · b) Solo de él · c) De los dos
2. Quedan 1,000 pesos después de gastos. ¿Cuánto para cada uno por igual? a) 1,000 para él · b) 500 · c) 200
3. ¿Cómo conviene hablar de dinero en pareja? a) Nunca · b) Con el presupuesto y los números · c) A gritos, cuando ya no aguantas
**Respuestas:** 1-c: de los dos. 2-b: mitad. 3-b: con números.



#### Ponlo en práctica

Entran 12,000 y los gastos de la casa son 10,400. Si cada uno toma 500, ¿cuánto queda para ahorro en común?
**Respuesta:** 600 pesos.



#### A tu plan

Escribe tu propuesta de acuerdo: gastos de la casa, dinero para cada quien y ahorro en común.



### Para saber más

- **Finanzas en pareja** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «finanzas en pareja».

### Palabras clave

- *Ingreso propio:* dinero que ganas tú.
- *Acuerdo:* lo que deciden juntos.
- *Ahorro en común:* dinero que juntan para metas de la familia.

### Fuentes

CONDUSEF, finanzas en pareja; consultado el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Un presupuesto que cuenta los cuidados

## M2 U01. Tu trabajo de cuidados vale

**Lo que lograrás:** Reconocer el valor del trabajo de cuidados y del hogar que haces sin pago.

**Para empezar:** Doña Rosario cuidó a su papá y a su mamá durante diez años. Cuando le preguntan en qué trabaja, dice «en nada». En esta lección verás cuánto vale ese trabajo.

### Lo esencial (5 minutos)

#### Casi 40 horas a la semana

En México, las mujeres hacen en promedio 39.7 horas a la semana de trabajo sin pago (casa, cuidados, comunidad); los hombres, 18.2. Es casi una jornada completa más.



#### Lo que cuenta como trabajo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Casa | Cocinar, limpiar, lavar. | Todos los días. |
| Cuidados | Hijos, personas mayores o enfermas. | Muchas horas. |
| Gestión | Compras, trámites, pagos. | También es trabajo. |
| Comunidad | Escuela, iglesia, vecinos. | Sin pago. |

#### Ponle precio

Si tuvieras que pagar a alguien para hacer lo que haces, ¿cuánto costaría? Esa cifra es lo que aportas al hogar, aunque no entre como dinero.



#### Un caso en un minuto

Doña Rosario calculó cuánto costaba una cuidadora en su ciudad: unos 8,000 pesos al mes. Durante diez años aportó eso a su familia. Ahora dice: «Trabajé cuidando a mis papás».

> **Idea clave:** el trabajo de cuidados es trabajo; cuenta lo que aportas aunque no te paguen.



#### Comprueba lo que entendiste

1. ¿Cuántas horas a la semana de trabajo sin pago hacen en promedio las mujeres?
*Respuesta:* 39.7 horas.

2. ¿Cómo calculas lo que aportas?
*Respuesta:* Pensando cuánto costaría pagar a alguien para hacerlo.


#### Para recordar

- Cuidar es trabajo.
- 39.7 horas a la semana.
- Ponle precio.



### Profundiza (5 minutos más)

#### Mis horas

| Actividad | Horas a la semana |
|---|---|
| Casa | |
| Cuidados | |
| Gestión y trámites | |
| Comunidad | |
| **Total** | |



#### No es solo tuyo

Este trabajo se puede repartir mejor en la familia. Hacer visibles las horas ayuda a pedirlo.



#### Casos


**Caso 1. «En nada»**

Doña Rosario dice que no trabaja.
- *¿Qué hace?* Reconoce que cuidó y calcula cuánto aportó.


**Caso 2. Las horas de Leticia**

Leticia no sabe cuántas horas trabaja en casa.
- *¿Qué hace?* Llena su tabla de horas de una semana.


**Caso 3. Repartir**

Lucía hace todo en casa además de su trabajo.
- *¿Qué hace?* Muestra sus horas y reparte tareas con sus hijos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decir que no trabajas | Te desvaloras | Cuidar es trabajo |
| No contar las horas | No se ve | Anótalas |
| Hacerlo todo sola | Agotamiento | Reparte |
| No ponerle precio | No ves tu aporte | Calcúlalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario, Leticia y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuidar a tus papás es trabajo? a) Solo si te pagan por hacerlo · b) No · c) Sí, aunque no tenga pago
2. ¿Cuántas horas sin pago hacen los hombres en promedio? a) 39.7 · b) 18.2 · c) 0
3. ¿Para qué sirve contar tus horas? a) Para ver tu aporte y repartir mejor · b) Para nada · c) Para pedir un préstamo con tus horas
**Respuestas:** 1-c: es trabajo. 2-b: 18.2. 3-a: ver y repartir.



#### Ponlo en práctica

Una cuidadora cuesta 8,000 al mes. ¿Cuánto vale ese trabajo en un año?
**Respuesta:** 96,000 pesos.



#### A tu plan

Llena tu tabla de horas de una semana.



### Para saber más

- **Encuesta Nacional sobre Uso del Tiempo** (INEGI · español): https://www.inegi.org.mx — **Qué buscar:** «ENUT 2024».

### Palabras clave

- *Trabajo de cuidados:* cuidar a otras personas.
- *Trabajo no remunerado:* trabajo sin pago.
- *Aporte:* lo que das al hogar.

### Fuentes

INEGI, Encuesta Nacional sobre Uso del Tiempo 2024; consultado el 5 de octubre de 2026.

---

## M2 U02. El presupuesto del hogar, con tu parte

**Lo que lograrás:** Hacer el presupuesto del hogar incluyendo tus necesidades, no solo las de los demás.

**Para empezar:** Lucía hace un presupuesto cada quincena. Pone la renta, la comida, la escuela, el celular de su hijo. Ella no aparece en ningún renglón. En esta lección te pondrás en tu presupuesto.

### Lo esencial (5 minutos)

#### Los renglones de tu presupuesto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Casa y comida | Lo básico. | Primero. |
| Hijos | Escuela, ropa, salud. | Importante. |
| Tú | Tu salud, tu ropa, tu descanso. | También va. |
| Ahorro | Emergencias y retiro. | Aunque sea poco. |

#### Tú también eres un gasto necesario

Tus consultas médicas, tus lentes, tu transporte y un poco de descanso no son lujos. Si tú te enfermas, todo el hogar se detiene.



#### Empieza con un renglón

Agrega un renglón con tu nombre. Aunque sea una cantidad chica, que esté.



#### Un caso en un minuto

Lucía agregó «Lucía: 300» a su presupuesto. Con eso pagó sus lentes en tres quincenas. Dice que ver su nombre escrito le cambió la forma de pensar.

> **Idea clave:** ponte en el presupuesto del hogar: tu salud y tus necesidades también son gasto necesario.



#### Comprueba lo que entendiste

1. ¿Tus consultas médicas son un lujo?
*Respuesta:* No; son gasto necesario.

2. ¿Cómo empiezas?
*Respuesta:* Agregando un renglón con mi nombre.


#### Para recordar

- Un renglón con tu nombre.
- Tu salud no es lujo.
- Aunque sea poco.



### Profundiza (5 minutos más)

#### Mi presupuesto de quincena

| Renglón | Monto |
|---|---|
| Casa y comida | |
| Hijos | |
| Yo | |
| Ahorro | |
| **Total** | |



#### Una guía sencilla

Si no sabes por dónde empezar, prueba: lo básico primero, después ahorro y un monto para ti, aunque sea 5% de lo que entra.



#### Casos


**Caso 1. No aparece**

Lucía no aparece en su presupuesto.
- *¿Qué hace?* Agrega un renglón con su nombre.


**Caso 2. Los lentes**

Doña Rosario lleva un año sin cambiar sus lentes.
- *¿Qué hace?* Los incluye como gasto necesario y aparta para ellos.


**Caso 3. Todo para los hijos**

Leticia gasta todo lo que sobra en los hijos.
- *¿Qué hace?* Aparta también un monto para ella.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No aparecer | Te descuidas | Un renglón tuyo |
| Ver tu salud como lujo | Te enfermas | Es necesaria |
| Todo para los demás | Agotamiento | Tú también |
| Sin ahorro | Sin colchón | Aunque sea poco |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Doña Rosario y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Tus lentes son un lujo o un gasto necesario? a) Depende de tu pareja · b) Lujo · c) Necesario
2. Te entran 8,000 por quincena. ¿Cuánto es 5% para ti? a) 80 · b) 400 · c) 800
3. ¿Qué renglón suele faltar en el presupuesto de muchas mujeres? a) El de ellas mismas · b) La comida de toda la semana · c) La renta
**Respuestas:** 1-c: necesario. 2-b: 5% de 8,000. 3-a: ellas mismas.



#### Ponlo en práctica

Apartas 300 por quincena para unos lentes de 900. ¿En cuántas quincenas los juntas?
**Respuesta:** En 3 quincenas.



#### A tu plan

Haz tu presupuesto de quincena con un renglón con tu nombre.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto familiar».

### Palabras clave

- *Presupuesto:* plan de lo que entra y sale.
- *Renglón:* cada gasto de la lista.
- *Gasto necesario:* lo que necesitas para estar bien.

### Fuentes

CONDUSEF, presupuesto familiar; consultado el 5 de octubre de 2026.

---

## M2 U03. Acuerdos de dinero que se cumplen

**Lo que lograrás:** Hacer acuerdos de dinero claros con tu pareja o tu familia y revisarlos.

**Para empezar:** Andrea y su pareja dividen los gastos «más o menos». Ella paga la comida y él la renta, pero la comida subió y ella termina pagando más. Nadie lo ha hablado. En esta lección harán un acuerdo claro.

### Lo esencial (5 minutos)

#### Un buen acuerdo dice

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Qué gastos son comunes | Renta, comida, servicios. | La lista. |
| Cuánto pone cada quien | Mitad o proporción al ingreso. | Justo. |
| Cuándo se revisa | Cada mes o cada tres meses. | Fecha fija. |

#### Proporción al ingreso

Si uno gana más, puede poner más. Por ejemplo, si él gana 60% del total y ella 40%, cada uno pone esa proporción de los gastos comunes.



#### Escríbanlo

Un acuerdo escrito, aunque sea en una hoja, evita malentendidos y facilita revisarlo cuando cambian los precios o los ingresos.



#### Un caso en un minuto

Andrea y su pareja sumaron sus ingresos: él gana 60% y ella 40%. Ahora cada uno pone esa parte de los gastos comunes y lo revisan cada tres meses.

> **Idea clave:** acuerden qué es común, cuánto pone cada quien y cuándo lo revisan, y escríbanlo.



#### Comprueba lo que entendiste

1. ¿Qué dice un buen acuerdo?
*Respuesta:* Qué gastos son comunes, cuánto pone cada quien y cuándo se revisa.

2. ¿Qué es poner en proporción al ingreso?
*Respuesta:* Que cada quien ponga según la parte del ingreso total que gana.


#### Para recordar

- Lista de gastos comunes.
- Cuánto pone cada quien.
- Fecha para revisar.



### Profundiza (5 minutos más)

#### El acuerdo de Andrea

- Gastos comunes al mes: **20,000**
- Parte de Andrea: **40%**
- Lo que pone Andrea: **8,000**
- Lo que pone su pareja (60%): **12,000**


#### Cuando cambia algo

Si alguien pierde el trabajo, nace un hijo o suben los precios, revisen el acuerdo antes de la fecha.



#### Casos


**Caso 1. «Más o menos»**

Andrea termina pagando más sin que lo hablen.
- *¿Qué hace?* Propone un acuerdo escrito con proporciones.


**Caso 2. Ganan distinto**

Leticia no gana sueldo y su esposo sí.
- *¿Qué hacen?* Acuerdan los gastos comunes y una cantidad para cada quien (M1 U03).


**Caso 3. Subió la renta**

A Lucía y su hermana, que viven juntas, les subieron la renta.
- *¿Qué hacen?* Revisan su acuerdo antes de la fecha.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| «Más o menos» | Alguien paga de más | Acuerdo claro |
| No escribirlo | Malentendidos | En una hoja |
| No revisarlo | Queda viejo | Fecha fija |
| Ignorar cambios | Injusto | Revísenlo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Andrea, Leticia y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Él gana 70% del total y ella 30%. Los gastos comunes son 10,000. ¿Cuánto pone ella? a) 7,000 · b) 5,000 · c) 3,000
2. ¿Cada cuándo revisan el acuerdo? a) En una fecha fija o cuando algo cambia · b) Nunca · c) Solo si hay pleito entre los dos
3. ¿Qué ayuda a evitar malentendidos? a) Escribir el acuerdo · b) No hablar · c) Que decida uno solo
**Respuestas:** 1-c: 30% de 10,000. 2-a: fecha fija o cambios. 3-a: por escrito.



#### Ponlo en práctica

Los gastos comunes son 15,000 y tú pones 40%. ¿Cuánto pones?
**Respuesta:** 6,000 pesos.



#### A tu plan

Escriban su acuerdo con la lista de gastos comunes, la parte de cada quien y la fecha de revisión.



### Para saber más

- **Finanzas en pareja** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «finanzas en pareja».

### Palabras clave

- *Gastos comunes:* los que se comparten.
- *Proporción:* parte según lo que gana cada quien.
- *Revisión:* volver a ver el acuerdo.

### Fuentes

CONDUSEF, finanzas en pareja; consultado el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Afore, semanas y aportaciones voluntarias

## M3 U01. La brecha de la Afore

**Lo que lograrás:** Explicar por qué las mujeres tienen menos Afore y localizar la tuya.

**Para empezar:** Andrea cree que «la Afore es cosa de cuando seas viejita». No sabe si tiene una ni en qué Afore está. En esta lección verás por qué importa desde hoy.

### Lo esencial (5 minutos)

#### La brecha más grande

Solo 34.2% de las mujeres tiene Afore, contra 51.4% de los hombres: 17 puntos de diferencia. Es la brecha financiera más grande entre mujeres y hombres en México.



#### Por qué pasa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuidados | Dejan el empleo para cuidar. | Se detiene la Afore. |
| Empleo informal | Sin IMSS ni Afore. | Más común en mujeres. |
| Sueldos más bajos | Menos aportaciones. | Menos ahorro. |

#### Localiza la tuya

Con tu CURP, en la app AforeMóvil o en la página de la CONSAR, puedes saber en qué Afore estás. Si nunca tuviste, puedes abrir una con tu CURP aunque trabajes por tu cuenta o no tengas sueldo.



#### Un caso en un minuto

Andrea descargó AforeMóvil y encontró su cuenta de su primer trabajo. Actualizó su teléfono y revisó sus beneficiarios.

> **Idea clave:** la Afore es tu ahorro para el retiro; localízala con tu CURP o abre una, aunque no tengas patrón.



#### Comprueba lo que entendiste

1. ¿Qué porcentaje de mujeres tiene Afore?
*Respuesta:* 34.2%, contra 51.4% de los hombres.

2. ¿Puedes abrir una Afore sin patrón?
*Respuesta:* Sí, con tu CURP en la app AforeMóvil.


#### Para recordar

- Brecha de 17 puntos.
- Localízala con tu CURP.
- Ábrela aunque no tengas patrón.



### Profundiza (5 minutos más)

#### Mi Afore

| Dato | Lo tengo |
|---|---|
| Afore donde estoy | |
| Saldo aproximado | |
| Beneficiarios | |
| Datos de contacto al día | |



#### También para quien cuida en casa

Las personas que no tienen sueldo también pueden ahorrar en su Afore con aportaciones voluntarias (U03).



#### Casos


**Caso 1. «Cosa de viejitas»**

Andrea cree que la Afore no le importa todavía.
- *¿Qué hace?* La localiza con su CURP y revisa sus datos.


**Caso 2. Sin patrón**

Leticia nunca tuvo empleo formal.
- *¿Qué hace?* Abre su Afore con su CURP en la app.


**Caso 3. Beneficiarios viejos**

Lucía tiene a su expareja como beneficiaria.
- *¿Qué hace?* Cambia a sus beneficiarios por sus hijos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejarlo para después | Pierdes años | Revisa hoy |
| Creer que sin patrón no se puede | No ahorras | Ábrela |
| Beneficiarios viejos | Va a quien no quieres | Actualiza |
| No actualizar contacto | No te localizan | Actualiza |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Andrea, Leticia y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es la brecha de Afore entre hombres y mujeres? a) 2 puntos, casi nada · b) Ninguna · c) 17.2 puntos
2. ¿Con qué localizas tu Afore? a) Con tu acta de matrimonio · b) Con tu CURP · c) Con tu recibo de luz
3. Nunca tuviste empleo formal. ¿Puedes tener Afore? a) Solo si te casas y tu esposo tiene una · b) Sí, la abres con tu CURP · c) No
**Respuestas:** 1-c: 51.4 menos 34.2. 2-b: CURP. 3-b: se puede abrir.



#### Ponlo en práctica

Si 34 de cada 100 mujeres tienen Afore, ¿cuántas no tienen?
**Respuesta:** 66 de cada 100.



#### A tu plan

Localiza o abre tu Afore y llena tu tabla.



### Para saber más

- **AforeMóvil y localización** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «localiza tu Afore». SARTEL 55 1328 5000.

### Palabras clave

- *Afore:* administradora de tu ahorro para el retiro.
- *Brecha:* diferencia entre dos grupos.
- *Beneficiario:* quien recibe tu ahorro si faltas.

### Fuentes

INEGI y CNBV, ENIF 2024; CONSAR; consultados el 5 de octubre de 2026.

---

## M3 U02. Las semanas que se pierden por cuidar

**Lo que lograrás:** Revisar tus semanas cotizadas y entender cómo los años de cuidado afectan tu pensión.

**Para empezar:** Doña Rosario trabajó ocho años en una fábrica y después se dedicó a cuidar a sus papás. Ahora tiene 61 años y quiere saber si puede pensionarse. En esta lección revisará sus semanas.

### Lo esencial (5 minutos)

#### Las semanas son la llave

Para una pensión del IMSS necesitas un número mínimo de semanas cotizadas. Si empezaste a cotizar antes de julio de 1997 (Ley 73), son 500. Si empezaste después (Ley 97), en 2026 son 875 y suben 25 cada año hasta 1,000 en 2031.



#### Revisa tres cosas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuántas tienes | Constancia de semanas del IMSS. | Con tu CURP. |
| Qué ley te toca | Según cuándo empezaste. | 73 o 97. |
| Cuántas te faltan | Requisito menos las que tienes. | La cuenta. |

#### Si no alcanzas

Si no juntas las semanas, con Ley 97 puedes retirar tu ahorro de la Afore al llegar a la edad, en lugar de una pensión mensual. Y existe la Pensión Bienestar a partir de los 65 años (módulo 4).



#### Un caso en un minuto

Doña Rosario consultó: tiene 416 semanas y empezó en 1988, así que es Ley 73. Le faltan 84 semanas para las 500. Está revisando con el IMSS cómo completarlas.

> **Idea clave:** revisa tus semanas, qué ley te toca y cuántas te faltan; los años de cuidado no suman, por eso conviene planear.



#### Comprueba lo que entendiste

1. ¿Cuántas semanas pide la Ley 73?
*Respuesta:* 500.

2. ¿Y la Ley 97 en 2026?
*Respuesta:* 875.


#### Para recordar

- Ley 73: 500.
- Ley 97: 875 en 2026.
- Calcula cuántas faltan.



### Profundiza (5 minutos más)

#### Las semanas de Doña Rosario

- Requisito Ley 73: **500**
- Semanas que tiene: **416**
- Semanas que le faltan: **84**


#### Continuar cotizando

El IMSS tiene esquemas para seguir cotizando de forma voluntaria en ciertos casos. Pregunta en tu subdelegación qué opción aplica para ti antes de pagar nada.



#### Casos


**Caso 1. ¿Puede pensionarse?**

Doña Rosario no sabe cuántas semanas tiene.
- *¿Qué hace?* Pide su constancia de semanas en el IMSS.


**Caso 2. ¿Qué ley?**

Andrea empezó a trabajar en 2018.
- *¿Qué hace?* Sabe que es Ley 97 y calcula cuántas semanas le faltan.


**Caso 3. El gestor**

Le ofrecen a Doña Rosario «completar sus semanas» pagando 15,000 a un gestor.
- *¿Qué hace?* No paga y pregunta directo en el IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar | Sorpresa al jubilarte | Consulta |
| Confundir la ley | Cuentas mal | Revisa cuándo empezaste |
| Pagar a gestores | Fraude | Pregunta en el IMSS |
| Creer que no hay nada que hacer | Te rindes | Revisa opciones |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario y Andrea. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Empezaste a cotizar en 1995. ¿Qué ley te toca? a) Ley 97 · b) Ninguna · c) Ley 73
2. Eres Ley 97 y tienes 600 semanas. ¿Cuántas te faltan en 2026? a) 275 · b) 400 · c) 0
3. Un gestor te ofrece completar semanas por 15,000. ¿Qué haces? a) Pagas la mitad ahora y la otra al terminar · b) Preguntas directo en el IMSS · c) Pagas
**Respuestas:** 1-c: antes de 1997. 2-a: 875 menos 600. 3-b: directo.



#### Ponlo en práctica

Eres Ley 73 y tienes 380 semanas. ¿Cuántas te faltan?
**Respuesta:** 120.



#### A tu plan

Pide tu constancia de semanas cotizadas y calcula cuántas te faltan.



### Para saber más

- **Semanas cotizadas** (IMSS · español): https://serviciosdigitales.imss.gob.mx — **Qué buscar:** «constancia de semanas cotizadas».

### Palabras clave

- *Semanas cotizadas:* semanas trabajadas con IMSS.
- *Ley 73 y Ley 97:* reglas según cuándo empezaste a cotizar.
- *Laguna:* tiempo en que no cotizaste.

### Fuentes

IMSS, requisitos de pensión Ley 73 y Ley 97; consultado el 5 de octubre de 2026.

---

## M3 U03. Aportaciones voluntarias: tu retiro, tu decisión

**Lo que lograrás:** Hacer aportaciones voluntarias a tu Afore, aunque sean pequeñas.

**Para empezar:** Leticia cree que con 100 pesos al mes «no hace nada». Andrea piensa lo mismo. En esta lección verás cuánto suman.

### Lo esencial (5 minutos)

#### Lo que tú agregas

Puedes depositar a tu Afore desde 50 pesos en tiendas de conveniencia, en la app AforeMóvil o por domiciliación. Ese dinero es tuyo y crece con el tiempo.



#### Formas de aportar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En tienda | Desde 50 pesos. | Con tu CURP. |
| En la app | AforeMóvil. | Cuando quieras. |
| Domiciliado | Monto fijo cada mes. | Automático. |

#### El tiempo hace la diferencia

Mientras antes empieces, más tiempo tiene tu ahorro para crecer. Una cantidad chica durante muchos años suma más que una grande al final.



#### Un caso en un minuto

Andrea domicilió 300 pesos al mes. En 30 años habrá aportado 108,000 pesos, más lo que generen. Leticia empezó con 100 en la tienda, cada mes.

> **Idea clave:** aporta a tu Afore aunque sea poco y empieza pronto; el tiempo hace crecer tu ahorro.



#### Comprueba lo que entendiste

1. ¿Desde cuánto puedes aportar en una tienda?
*Respuesta:* Desde 50 pesos.

2. ¿Por qué empezar pronto?
*Respuesta:* Porque el ahorro tiene más tiempo para crecer.


#### Para recordar

- Desde 50 pesos.
- Tienda, app o domiciliado.
- Empieza pronto.



### Profundiza (5 minutos más)

#### Lo que aporta Andrea

- Al mes: **300**
- Meses: **12**
- Al año: **3,600**
- Años: **30**
- Aportado, sin contar lo que genere: **108,000**


#### Beneficios de largo plazo

Algunas aportaciones voluntarias de largo plazo tienen beneficios fiscales. Pregunta en tu Afore qué tipo te conviene.



#### Casos


**Caso 1. «100 pesos no hacen nada»**

Leticia cree que su aportación no sirve.
- *¿Qué hace?* Aporta 100 cada mes en la tienda.


**Caso 2. Se le olvida**

Andrea aporta cuando se acuerda.
- *¿Qué hace?* Domicilia un monto fijo cada mes.


**Caso 3. Dinero extra**

Lucía recibió 1,000 pesos de un trabajo extra.
- *¿Qué hace?* Aporta una parte a su Afore.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es poco | No empiezas | Desde 50 |
| Aportar cuando te acuerdas | Irregular | Domicilia |
| Esperar a ganar más | Pierdes años | Empieza ya |
| No revisar tu Afore | No ves el avance | Revisa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Andrea y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde puedes aportar a tu Afore? a) Solo por medio de tu patrón · b) Solo en las oficinas del IMSS, con cita · c) En tienda, app o domiciliado
2. Aportas 200 al mes. ¿Cuánto en 10 años, sin rendimientos? a) 2,400 · b) 24,000 · c) 240,000
3. ¿Qué conviene más? a) Esperar a ganar más para aportar en grande · b) Empezar pronto con poco · c) Aportar solo al final
**Respuestas:** 1-c: tres formas. 2-b: 200 por 120 meses. 3-b: el tiempo ayuda.



#### Ponlo en práctica

Aportas 150 al mes. ¿Cuánto en 5 años, sin rendimientos?
**Respuesta:** 9,000 pesos.



#### A tu plan

Decide cuánto aportarás al mes y haz la primera aportación.



### Para saber más

- **Ahorro voluntario** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «ahorro voluntario».

### Palabras clave

- *Aportación voluntaria:* lo que tú agregas a tu Afore.
- *Domiciliar:* cargo automático cada mes.
- *Rendimiento:* lo que genera tu ahorro.

### Fuentes

CONSAR, ahorro voluntario; consultado el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Pensión Mujeres Bienestar

## M4 U01. Qué es la Pensión Mujeres Bienestar

**Lo que lograrás:** Identificar la Pensión Mujeres Bienestar, quién puede recibirla y cómo registrarse.

**Para empezar:** Doña Rosario tiene 61 años y escuchó que hay «un apoyo para mujeres», pero cree que es solo para las que nunca trabajaron. En esta lección verás de qué se trata.

### Lo esencial (5 minutos)

#### Para mujeres de 60 a 64 años

La Pensión Mujeres Bienestar es para mujeres mexicanas de 60 a 64 años. En 2026 son 3,100 pesos cada dos meses, depositados en la tarjeta del Banco del Bienestar.



#### Lo que llevas al registro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Identificación | INE vigente. | Original. |
| CURP | Impresa. | Reciente. |
| Acta de nacimiento | Legible. | Copia. |
| Comprobante de domicilio | Reciente. | Copia. |

#### Registro en las fechas oficiales

El registro se hace en los módulos del Bienestar en las fechas que anuncia la Secretaría. Es sin costo y sin intermediarios. Puedes registrar a una persona auxiliar de tu confianza.



#### Un caso en un minuto

Doña Rosario preguntó en el módulo: no importa si trabajó o no. Llevó sus papeles en las fechas de registro y ya recibe su pensión.

> **Idea clave:** si tienes de 60 a 64 años, puedes registrarte a la Pensión Mujeres Bienestar sin costo, en las fechas oficiales.



#### Comprueba lo que entendiste

1. ¿Para qué edades es la Pensión Mujeres Bienestar?
*Respuesta:* De 60 a 64 años.

2. ¿Cuánto es en 2026?
*Respuesta:* 3,100 pesos cada dos meses.


#### Para recordar

- 60 a 64 años.
- 3,100 por bimestre.
- Registro sin costo.



### Profundiza (5 minutos más)

#### Mi lista para el registro

| Papel | Lo tengo |
|---|---|
| INE | |
| CURP | |
| Acta de nacimiento | |
| Comprobante de domicilio | |
| Datos de mi persona auxiliar | |



#### Nadie cobra por registrarte

Si alguien te pide dinero por registrarte o por «asegurar tu lugar», es fraude. Repórtalo a la Línea de Bienestar, 800 639 4264.



#### Casos


**Caso 1. «Solo para las que no trabajaron»**

Doña Rosario cree que no le toca.
- *¿Qué hace?* Pregunta en el módulo y se registra.


**Caso 2. La mamá de Lucía**

La mamá de Lucía tiene 62 años y no sabe del programa.
- *¿Qué hace Lucía?* Le ayuda a juntar sus papeles para el registro.


**Caso 3. El lugar asegurado**

Le piden a Leticia 300 pesos para registrar a su mamá.
- *¿Qué hace?* No paga y reporta a la Línea de Bienestar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no te toca | No te registras | Pregunta |
| Ir sin papeles | Pierdes la vuelta | Lleva la lista |
| Pagar por registrarte | Fraude | Sin costo |
| Perder las fechas | Esperas otro periodo | Revisa los avisos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario, Lucía y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Quién puede recibir la Pensión Mujeres Bienestar? a) Solo mujeres que nunca trabajaron · b) Mujeres de 18 a 30 · c) Mujeres de 60 a 64 años
2. ¿Cuánto es al bimestre en 2026? a) 6,400 · b) 3,100 · c) 1,000
3. Te piden dinero para registrarte. ¿Qué es? a) Fraude · b) Una cuota oficial · c) Algo normal entre parejas
**Respuestas:** 1-c: 60 a 64. 2-b: 3,100. 3-a: es sin costo.



#### Ponlo en práctica

Recibes 3,100 por bimestre. ¿Cuánto al año?
**Respuesta:** 18,600 pesos.



#### A tu plan

Si tú o una mujer cercana tiene de 60 a 64 años, revisen juntas la lista de papeles.



### Para saber más

- **Pensión Mujeres Bienestar** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «Mujeres Bienestar».
- **Línea de Bienestar:** 800 639 4264.

### Palabras clave

- *Bimestre:* dos meses.
- *Módulo:* oficina donde te registras.
- *Persona auxiliar:* alguien registrado para ayudarte.

### Fuentes

Secretaría de Bienestar, Pensión Mujeres Bienestar 2026; consultado el 5 de octubre de 2026.

---

## M4 U02. Que tu pensión sea para ti

**Lo que lograrás:** Usar la pensión para tus necesidades y no dejar que otros la tomen.

**Para empezar:** Doña Rosario empezó a cobrar su pensión. Su hijo le pidió la tarjeta «para administrarla». Desde entonces, ella no sabe cuánto le queda. En esta lección verás cómo mantener el control.

### Lo esencial (5 minutos)

#### Tu pensión es tuya

La pensión está a tu nombre para tus necesidades. Puedes ayudar a tu familia si quieres, pero la decisión es tuya y la tarjeta y el NIP se quedan contigo.



#### Un plan para tu pensión

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Salud | Consultas, medicinas, lentes. | Primero. |
| Tus gastos | Comida, transporte, ropa. | Lo tuyo. |
| Ahorro | Un guardadito. | Para imprevistos. |
| Ayuda a la familia | Si quieres y puedes. | Tú decides cuánto. |

#### Dos meses, dos mitades

Llega cada dos meses: divide en dos para que alcance (1,550 por mes).



#### Un caso en un minuto

Doña Rosario recuperó su tarjeta y cambió su NIP. Ahora aparta para sus medicinas y le da a su hijo 300 pesos cuando ella puede.

> **Idea clave:** tu pensión es para ti; tú decides, y la tarjeta y el NIP se quedan contigo.



#### Comprueba lo que entendiste

1. ¿Quién decide cómo se usa tu pensión?
*Respuesta:* Yo.

2. ¿Cuánto es para cada mes si cobras 3,100 por bimestre?
*Respuesta:* 1,550 pesos.


#### Para recordar

- Tu pensión es tuya.
- Tarjeta y NIP contigo.
- Divide en dos meses.



### Profundiza (5 minutos más)

#### La pensión de Doña Rosario

- Por bimestre: **3,100**
- Meses: **2**
- Para cada mes: **1,550**


#### Si alguien la toma sin permiso

Usar tu pensión sin tu permiso es violencia económica (módulo 6). Puedes orientarte en el 079, opción 1.



#### Casos


**Caso 1. «Para administrarla»**

El hijo de Doña Rosario se quedó con su tarjeta.
- *¿Qué hace?* Recupera su tarjeta y cambia su NIP.


**Caso 2. Todo para los nietos**

La mamá de Lucía gasta toda su pensión en los nietos.
- *¿Qué hace?* Aparta primero para su salud y sus gastos.


**Caso 3. Todo el primer mes**

Doña Rosario gasta toda la pensión el primer mes.
- *¿Qué hace?* La divide en dos mitades.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar la tarjeta | Pierdes el control | Contigo |
| Todo para otros | Te descuidas | Tú primero |
| Gastar todo el primer mes | No alcanza | Divide |
| Callar el abuso | Sigue | 079 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario y la mamá de Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Quién guarda tu tarjeta de pensión? a) Tu nuera · b) Tu hijo · c) Tú
2. Cobras 3,100 por bimestre. ¿Cuánto por mes? a) 3,100 · b) 1,550 · c) 1,000
3. Alguien usa tu pensión sin permiso. ¿Qué es? a) Violencia económica · b) Algo normal en las familias · c) Ayuda
**Respuestas:** 1-c: tú. 2-b: la mitad. 3-a: violencia económica.



#### Ponlo en práctica

De 1,550 al mes, apartas 300 para medicinas. ¿Cuánto queda para lo demás?
**Respuesta:** 1,250 pesos.



#### A tu plan

Escribe tu plan para la pensión: salud, gastos, ahorro y ayuda (si quieres).



### Para saber más

- **Línea de las Mujeres** (Secretaría de las Mujeres · español): 079, opción 1.

### Palabras clave

- *Control:* poder decidir sobre tu dinero.
- *Plan:* cómo vas a usar tu dinero.
- *Violencia económica:* cuando alguien controla o toma tu dinero.

### Fuentes

Secretaría de Bienestar; Secretaría de las Mujeres, Línea 079; consultados el 5 de octubre de 2026.

---

## M4 U03. A los 65, el paso a la Pensión Adultos Mayores

**Lo que lograrás:** Identificar qué pasa con tu pensión al cumplir 65 años y planear con el nuevo monto.

**Para empezar:** Doña Rosario cumplirá 65 el próximo año. Su comadre le dijo que «tiene que registrarse otra vez desde cero». Está preocupada. En esta lección verás qué pasa.

### Lo esencial (5 minutos)

#### El cambio es automático

Al cumplir 65 años, las beneficiarias de Mujeres Bienestar pasan **en automático** a la Pensión para el Bienestar de las Personas Adultas Mayores. Siguen con la misma tarjeta. No hay que registrarse desde cero.



#### Lo que cambia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| El monto | De 3,100 a 6,400 por bimestre. | En 2026. |
| La tarjeta | Es la misma. | Banco del Bienestar. |
| Los avisos | Mantén tus datos al día. | Por si te piden actualizar. |

#### Planea el nuevo monto

Con 6,400 por bimestre tienes 3,200 al mes. Decide antes cómo lo repartirás: salud, gastos, ahorro, ayuda a la familia.



#### Un caso en un minuto

Doña Rosario se tranquilizó: no tiene que hacer trámite. Ya decidió que la diferencia irá a su guardadito de salud y a sus lentes.

> **Idea clave:** a los 65 pasas en automático a la Pensión Adultos Mayores, con más monto; planea desde antes cómo usarlo.



#### Comprueba lo que entendiste

1. ¿Tienes que registrarte desde cero a los 65?
*Respuesta:* No; el paso es automático.

2. ¿Cuánto es la Pensión Adultos Mayores en 2026?
*Respuesta:* 6,400 pesos por bimestre.


#### Para recordar

- Paso automático.
- 6,400 por bimestre.
- Misma tarjeta.



### Profundiza (5 minutos más)

#### El aumento de Doña Rosario

- Pensión Adultos Mayores: **6,400**
- Mujeres Bienestar: **3,100**
- Más por bimestre: **3,300**


#### Cuidado con «trámites» falsos

Si alguien te ofrece «hacer tu cambio a los 65» por dinero, es fraude. Repórtalo a la Línea de Bienestar, 800 639 4264.



#### Casos


**Caso 1. «Regístrate otra vez»**

La comadre le dice a Doña Rosario que se registre desde cero.
- *¿Qué hace?* Sabe que el paso es automático y mantiene sus datos al día.


**Caso 2. El gestor del cambio**

Le ofrecen hacer «el cambio» por 500 pesos.
- *¿Qué hace?* No paga y reporta a la Línea de Bienestar.


**Caso 3. El nuevo monto**

Doña Rosario recibirá más dinero.
- *¿Qué hace?* Decide antes cómo repartirlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que hay que empezar de cero | Te angustias | Es automático |
| Pagar por el cambio | Fraude | Sin costo |
| No actualizar datos | Problemas | Mantén tus datos |
| No planear | Se va en otras cosas | Decide antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario y su comadre. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué pasa a los 65 si recibes Mujeres Bienestar? a) Te registras desde cero en un módulo · b) Pierdes la pensión · c) Pasas en automático a la Pensión Adultos Mayores
2. ¿Cuánto más recibes por bimestre al cambiar? a) 3,300 · b) 100 · c) Nada, se queda igual
3. Te cobran por hacer el cambio. ¿Qué haces? a) No pagas y reportas · b) Pagas la mitad ahora y la otra al terminar · c) Pagas
**Respuestas:** 1-c: automático. 2-a: 6,400 menos 3,100. 3-a: es sin costo.



#### Ponlo en práctica

Con 6,400 por bimestre, ¿cuánto tienes al mes?
**Respuesta:** 3,200 pesos.



#### A tu plan

Si te faltan pocos años para los 65, escribe cómo usarás el nuevo monto.



### Para saber más

- **Pensión para el Bienestar de las Personas Adultas Mayores** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** los requisitos, el monto vigente y dónde registrarte según tu edad.

### Palabras clave

- *Automático:* sin hacer trámite.
- *Monto:* cantidad de dinero.
- *Actualizar datos:* corregir tu teléfono o domicilio.

### Fuentes

Secretaría de Bienestar, Pensión Mujeres Bienestar y Pensión Adultos Mayores 2026; consultado el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Seguros para mí

## M5 U01. Un seguro de vida también para ti

**Lo que lograrás:** Comprobar si te conviene un seguro de vida a tu nombre y qué preguntar.

**Para empezar:** Lucía tiene un seguro de vida… a nombre de su expareja, que era el titular. Ella mantiene sola a sus dos hijos y no tiene ninguno propio. En esta lección verás por qué importa.

### Lo esencial (5 minutos)

#### Las mujeres tienen menos seguros

Solo 18.3% de las mujeres tiene algún seguro, contra 28.2% de los hombres. Si alguien depende de tu ingreso o de tus cuidados, un seguro de vida protege a esas personas si tú faltas.



#### Antes de contratar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cuánto paga? | La suma asegurada. | Que alcance. |
| ¿Cuánto cuesta y hasta cuándo? | Prima y plazo. | Por escrito. |
| ¿Quién cobra? | Tus beneficiarios. | Tus hijos, con tutor. |
| ¿Está autorizada? | La aseguradora. | SIPRES de CONDUSEF. |

#### Revisa lo que ya tienes

Muchos empleos dan seguro de vida como prestación. Pregunta en tu trabajo si tienes uno y a quién pusiste de beneficiario.



#### Un caso en un minuto

Lucía preguntó en su trabajo: tenía un seguro de vida de prestación con su mamá como beneficiaria. Lo actualizó a nombre de sus hijos, con su hermana como tutora.

> **Idea clave:** si alguien depende de ti, revisa si tienes seguro de vida, quién cobra y si alcanza.



#### Comprueba lo que entendiste

1. ¿Qué porcentaje de mujeres tiene algún seguro?
*Respuesta:* 18.3%.

2. ¿Dónde puede haber un seguro que ya tienes?
*Respuesta:* En las prestaciones de tu trabajo.


#### Para recordar

- ¿Alguien depende de ti?
- Revisa lo que tienes.
- Beneficiarios al día.



### Profundiza (5 minutos más)

#### Si tus hijos son menores

Si tus beneficiarios son menores de edad, conviene nombrar un tutor o una persona que administre el dinero. Pregunta a la aseguradora cómo hacerlo.



#### ¿Cuánto alcanza?

Una forma sencilla: cuánto necesitaría tu familia al año por cuántos años, hasta que tus hijos sean mayores.



#### Casos


**Caso 1. Sin seguro propio**

Lucía no tiene seguro a su nombre.
- *¿Qué hace?* Pregunta en su trabajo y revisa beneficiarios.


**Caso 2. Hijos menores**

Los beneficiarios de Andrea serían sus sobrinos menores.
- *¿Qué hace?* Pregunta cómo nombrar a un tutor.


**Caso 3. Seguro por teléfono**

Le ofrecen a Leticia un seguro de vida por teléfono.
- *¿Qué hace?* Pide la información por escrito y verifica la aseguradora.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar las prestaciones | Pagas doble | Pregunta en tu trabajo |
| Beneficiarios viejos | Cobra quien no quieres | Actualiza |
| Menores sin tutor | Trámite largo | Nombra a alguien |
| Contratar por teléfono | No sabes qué compras | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Andrea y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué porcentaje de mujeres tiene algún seguro? a) 50% · b) 80%, la mayoría · c) 18.3%
2. ¿Dónde puede haber un seguro que ya tienes? a) En las prestaciones de tu trabajo · b) En tu INE, atrás de la foto · c) En tu recibo de luz
3. Tus beneficiarios son menores. ¿Qué haces? a) Pones a tu expareja para que los cuide · b) Preguntas cómo nombrar un tutor · c) Nada, se queda igual
**Respuestas:** 1-c: 18.3%. 2-a: prestaciones. 3-b: un tutor.



#### Ponlo en práctica

Tu familia necesitaría 60,000 al año durante 8 años. ¿Cuánto debería pagar el seguro?
**Respuesta:** 480,000 pesos.



#### A tu plan

Pregunta en tu trabajo si tienes seguro de vida y revisa tus beneficiarios.



### Para saber más

- **Seguros de vida** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de vida».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Suma asegurada:* lo que paga el seguro.
- *Prima:* lo que pagas por el seguro.
- *Tutor:* quien cuida el dinero de un menor.

### Fuentes

INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M5 U02. Tu salud, protegida

**Lo que lograrás:** Identificar qué servicio de salud te corresponde y prepararte para gastos médicos.

**Para empezar:** Leticia tenía IMSS como beneficiaria de su esposo. Cuando se separaron, ya no sabía si seguía teniendo servicio médico. En esta lección verás tus opciones.

### Lo esencial (5 minutos)

#### Tus opciones de salud

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IMSS o ISSSTE | Si trabajas formal o eres beneficiaria. | Revisa tu vigencia. |
| IMSS-Bienestar | Para quien no tiene seguridad social. | En tu centro de salud. |
| IMSS voluntario | Si trabajas por tu cuenta. | Pagas una cuota. |
| Guardadito de salud | Para lo que no cubren. | Siempre ayuda. |

#### Revisa tu vigencia

Puedes consultar en la página del IMSS si tienes derechos vigentes y como qué (trabajadora o beneficiaria). Si cambió tu situación familiar, revísalo.



#### Lo que te toca revisar cada año

Muchos estudios preventivos (mamografía, papanicolaou, glucosa, presión) se hacen en instituciones públicas sin costo. Pregunta en tu clínica.



#### Un caso en un minuto

Leticia consultó su vigencia: ya no era beneficiaria. Se registró en su centro de salud y empezó un guardadito de 200 pesos al mes para gastos médicos.

> **Idea clave:** revisa qué servicio de salud te corresponde y ten un guardadito para lo que no cubre.



#### Comprueba lo que entendiste

1. ¿Qué opción tienes si no tienes seguridad social?
*Respuesta:* IMSS-Bienestar, en tu centro de salud.

2. ¿Qué haces si cambió tu situación familiar?
*Respuesta:* Reviso mi vigencia en el IMSS.


#### Para recordar

- Revisa tu vigencia.
- IMSS-Bienestar si no tienes.
- Guardadito de salud.



### Profundiza (5 minutos más)

#### El guardadito de Leticia

- Al mes: **200**
- Meses: **12**
- En un año para salud: **2,400**


#### Tus chequeos

Anota en tu calendario tus estudios preventivos. Detectar a tiempo cuesta menos en salud y en dinero.



#### Casos


**Caso 1. ¿Sigo teniendo IMSS?**

Leticia se separó y no sabe si sigue como beneficiaria.
- *¿Qué hace?* Consulta su vigencia en el IMSS.


**Caso 2. Trabaja por su cuenta**

Lucía hace trabajos extra por su cuenta y quiere IMSS.
- *¿Qué hace?* Revisa los requisitos del IMSS para independientes.


**Caso 3. La mamografía**

Doña Rosario no se ha hecho una mamografía.
- *¿Qué hace?* Pregunta en su clínica pública.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar tu vigencia | Sorpresa en una emergencia | Consulta |
| Sin guardadito | Préstamos caros | Aparta |
| Dejar los chequeos | Gastos mayores | Anótalos |
| Pagar lo que hay sin costo | Gasto de más | Pregunta primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Lucía y Doña Rosario. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. No tienes seguridad social. ¿A dónde vas? a) Solo a hospitales privados · b) A ningún lado, porque no tienes derecho · c) A tu centro de salud del IMSS-Bienestar
2. Te separaste y eras beneficiaria del IMSS de tu pareja. ¿Qué haces? a) Nada, se queda igual · b) Revisas tu vigencia · c) Usas su credencial mientras se arregla
3. Apartas 150 al mes para salud. ¿Cuánto en un año? a) 150 · b) 1,800 · c) 15,000
**Respuestas:** 1-c: IMSS-Bienestar. 2-b: revisa. 3-b: 150 por 12.



#### Ponlo en práctica

Una consulta privada cuesta 600 y la necesitas 4 veces al año. ¿Cuánto apartas al mes?
**Respuesta:** 200 pesos.



#### A tu plan

Revisa qué servicio de salud te corresponde y anota tus chequeos del año.



### Para saber más

- **Vigencia de derechos** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «vigencia de derechos».
- **IMSS-Bienestar** (Gobierno de México · español): https://www.gob.mx/imss-bienestar — **Qué buscar:** tu unidad médica más cercana y qué servicios dan sin costo.

### Palabras clave

- *Vigencia:* que tu derecho está activo.
- *Beneficiaria:* quien tiene servicio por un familiar.
- *Preventivo:* estudio para detectar a tiempo.

### Fuentes

IMSS, vigencia de derechos; IMSS-Bienestar; consultados el 5 de octubre de 2026.

---

## M5 U03. Revisa los seguros que ya pagas

**Lo que lograrás:** Encontrar los seguros que te cobran y decidir si te sirven.

**Para empezar:** Andrea revisó su estado de cuenta y encontró tres seguros: uno de la tarjeta, uno del celular y uno de «protección de saldo». Suman 380 pesos al mes. No sabía que los tenía. En esta lección revisarás los tuyos.

### Lo esencial (5 minutos)

#### Busca en tus estados de cuenta

Revisa tu cuenta, tu tarjeta de crédito, tu recibo del celular y tus créditos. Algunos seguros se agregan al contratar algo y siguen cobrándose cada mes.



#### Por cada seguro, pregúntate

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Qué cubre? | Pide la póliza. | Por escrito. |
| ¿Cuánto me cuesta al año? | Multiplica por 12. | Ve el total. |
| ¿Lo necesito? | ¿Me protege de algo que me preocupa? | Decide. |

#### Cancela lo que no pediste o no te sirve

Si te cobran un seguro que no pediste, pide que lo cancelen y te devuelvan lo cobrado. Si no te resuelven, ve a CONDUSEF.



#### Un caso en un minuto

Andrea canceló el seguro de «protección de saldo», que no le servía, y se quedó con el del celular. Ahorra 2,400 pesos al año.

> **Idea clave:** revisa tus estados de cuenta, pregunta qué cubre cada seguro y cancela los que no pediste o no te sirven.



#### Comprueba lo que entendiste

1. ¿Dónde buscas seguros que pagas?
*Respuesta:* En mis estados de cuenta, tarjeta, recibo del celular y créditos.

2. ¿Qué haces con un seguro que no pediste?
*Respuesta:* Pido cancelarlo y que me devuelvan lo cobrado.


#### Para recordar

- Revisa tus estados de cuenta.
- ¿Qué cubre?
- Cancela lo que no pediste.



### Profundiza (5 minutos más)

#### Los seguros de Andrea

- Al mes: **380**
- Meses: **12**
- Al año: **4,560**


#### Pide la póliza

Si decides quedarte con un seguro, pide la póliza y guárdala con tus papeles. Pon a tus beneficiarios al día.



#### Casos


**Caso 1. Tres seguros sorpresa**

Andrea encuentra tres seguros que no recordaba.
- *¿Qué hace?* Pregunta qué cubre cada uno y cancela el que no le sirve.


**Caso 2. El seguro que no pidió**

A Lucía le cobran un seguro que nunca aceptó.
- *¿Qué hace?* Pide cancelarlo y la devolución de lo cobrado.


**Caso 3. Sin póliza**

Leticia paga un seguro, pero no tiene la póliza.
- *¿Qué hace?* La pide a la aseguradora y la guarda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar | Pagas por años | Revisa |
| Cancelar sin saber | Te quedas sin algo útil | Pregunta antes |
| Aceptar cobros no pedidos | Pierdes dinero | Reclama |
| Sin póliza | No sabes qué tienes | Pídela |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Andrea, Lucía y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te cobran un seguro que no pediste. ¿Qué haces? a) Cierras tu cuenta sin decir nada · b) Lo sigues pagando · c) Pides cancelarlo y la devolución
2. Un seguro cuesta 95 al mes. ¿Cuánto al año? a) 95 · b) 1,140 · c) 950, como en diez meses
3. ¿Qué preguntas de cada seguro? a) Su color y el diseño de la póliza · b) Qué cubre, cuánto cuesta y si lo necesitas · c) Nada, se queda igual
**Respuestas:** 1-c: cancela y reclama. 2-b: 95 por 12. 3-b: las tres preguntas.



#### Ponlo en práctica

Cancelas un seguro de 120 al mes. ¿Cuánto ahorras en un año?
**Respuesta:** 1,440 pesos.



#### A tu plan

Revisa tus últimos tres estados de cuenta y anota cada seguro que pagas.



### Para saber más

- **Cargos no reconocidos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguros no solicitados». 55 5340 0999.

### Palabras clave

- *Póliza:* contrato del seguro.
- *Cargo no reconocido:* cobro que no aceptaste.
- *Estado de cuenta:* resumen de movimientos.

### Fuentes

CONDUSEF, cargos no reconocidos y seguros; consultado el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Violencia económica: señales y salida

## M6 U01. Señales de violencia económica

**Lo que lograrás:** Reconocer la violencia económica y patrimonial, aunque no haya golpes.

**Para empezar:** El esposo de Leticia revisa cada ticket, le pide cuentas de cada peso y le dice que «no sabe administrar». Un día vendió el auto que estaba a nombre de los dos sin decirle. Ella no sabía que eso tiene nombre. En esta lección lo verás.

### Lo esencial (5 minutos)

#### Tiene nombre y está en la ley

La violencia económica es controlar o limitar el dinero de una persona. La patrimonial es dañar, quitar o retener sus bienes o documentos. La ley las reconoce. En México, 27.4% de las mujeres ha vivido violencia económica, patrimonial o discriminación.



#### Señales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te prohíbe trabajar o estudiar | Para que dependas. | Control. |
| Te pide cuentas de todo | Y te da lo mínimo. | Control. |
| Usa o esconde tus papeles | Actas, escrituras, tarjetas. | Patrimonial. |
| Saca créditos a tu nombre | O usa tu tarjeta sin permiso. | Económica. |

#### No es tu culpa

No es «falta de administración» ni «así son las parejas». Reconocerlo es el primer paso.



#### Un caso en un minuto

Leticia leyó las señales y se reconoció en varias. Llamó al 079, opción 1, para orientarse. Le explicaron sus derechos sobre el auto y la casa.

> **Idea clave:** controlar tu dinero, quitarte tus bienes o usar tu nombre sin permiso es violencia; no es tu culpa y hay a dónde llamar.



#### Comprueba lo que entendiste

1. ¿Qué es violencia económica?
*Respuesta:* Controlar o limitar el dinero de una persona.

2. ¿A dónde llamas para orientarte?
*Respuesta:* Al 079, opción 1, las 24 horas.


#### Para recordar

- Tiene nombre.
- No es tu culpa.
- 079, opción 1.



### Profundiza (5 minutos más)

#### ¿Te pasa?

| Señal | Sí | No |
|---|---|---|
| Me prohíbe trabajar o estudiar | | |
| Me pide cuentas de cada peso | | |
| Usa o esconde mis papeles | | |
| Sacó créditos a mi nombre | | |
| Vendió bienes sin decirme | | |



#### Cuida tu privacidad

Si alguien revisa tu celular o tu computadora, borra el historial después de ver esta lección y guarda el 079 con otro nombre.



#### Casos


**Caso 1. El auto vendido**

El esposo de Leticia vendió el auto de los dos sin decirle.
- *¿Qué hace?* Se orienta en el 079 sobre sus derechos.


**Caso 2. El crédito a su nombre**

La expareja de Lucía sacó un crédito a nombre de ella.
- *¿Qué hace?* Revisa su reporte de crédito y presenta una reclamación.


**Caso 3. «No sabes administrar»**

A Andrea su novio le dice que no sabe administrar y le pide su sueldo.
- *¿Qué hace?* Reconoce la señal y conserva el control de su dinero.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar que es normal | Sigue pasando | Tiene nombre |
| Culparte | Te callas | No es tu culpa |
| No revisar tu crédito | Deudas ajenas | Revísalo |
| Dejar rastro | Riesgo | Cuida tu privacidad |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Lucía y Andrea. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Tu pareja vende un bien de los dos sin decirte. ¿Qué es? a) Un regalo de vez en cuando · b) Algo normal entre parejas · c) Violencia patrimonial
2. ¿A dónde llamas para orientarte las 24 horas? a) Al 079, opción 1 · b) A tu suegra, para que hable con él · c) A nadie
3. ¿Qué porcentaje de mujeres ha vivido violencia económica, patrimonial o discriminación? a) 27.4% · b) 2% · c) 90%, casi todas
**Respuestas:** 1-c: es patrimonial. 2-a: 079. 3-a: 27.4%.



#### Ponlo en práctica

Escribe una señal de violencia económica que conozcas.
**Respuesta:** Ejemplo: «Que te prohíban trabajar para que dependas».



#### A tu plan

Guarda el 079 en tu teléfono (con otro nombre si hace falta) y llena la tabla en privado.



### Para saber más

- **Línea de las Mujeres** (Secretaría de las Mujeres · español): 079, opción 1. En emergencia, 911.
- **Ley General de Acceso de las Mujeres a una Vida Libre de Violencia** (Cámara de Diputados · español): https://www.diputados.gob.mx/LeyesBiblio — **Qué buscar:** «artículo 6».

### Palabras clave

- *Violencia económica:* controlar o limitar tu dinero.
- *Violencia patrimonial:* dañar, quitar o retener tus bienes o papeles.
- *Orientación:* ayuda para saber qué hacer.

### Fuentes

Ley General de Acceso de las Mujeres a una Vida Libre de Violencia, artículo 6; INEGI, ENDIREH 2021; Secretaría de las Mujeres, Línea 079; consultados el 5 de octubre de 2026.

---

## M6 U02. Tu plan de seguridad económica

**Lo que lograrás:** Preparar un plan con dinero, documentos y contactos por si necesitas salir de una situación de violencia.

**Para empezar:** Lucía tardó mucho en separarse porque no tenía dinero propio ni sabía dónde estaban sus papeles. Hoy ayuda a su hermana, que está pasando por lo mismo. En esta lección verás qué preparar.

### Lo esencial (5 minutos)

#### Tu plan tiene cuatro partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Un poco de dinero propio | En una cuenta a tu nombre o con alguien de confianza. | Poco a poco. |
| Tus documentos | Actas, INE, CURP, escrituras, de tus hijos. | Copias fuera de casa. |
| Contactos | 079, 911, alguien de confianza. | Memorizados o escondidos. |
| Un lugar | Casa de alguien o refugio. | Pensado antes. |

#### Discreción

Haz tu plan sin llamar la atención. Las copias pueden estar con alguien de confianza o en un correo que solo tú abras.



#### No estás sola

En el 079, opción 1, te orientan para armar tu plan y te dicen a dónde acudir en tu estado. Si hay peligro inmediato, llama al 911.



#### Un caso en un minuto

La hermana de Lucía abrió una cuenta a su nombre, le dio a Lucía copias de sus papeles y guardó el 079 con otro nombre. Cuando decidió salir, tenía con qué empezar.

> **Idea clave:** un poco de dinero propio, copias de tus papeles fuera de casa, contactos y un lugar; arma tu plan con discreción.



#### Comprueba lo que entendiste

1. ¿Cuáles son las cuatro partes del plan?
*Respuesta:* Dinero propio, documentos, contactos y un lugar.

2. ¿Dónde guardas copias de tus papeles?
*Respuesta:* Con alguien de confianza o en un correo que solo yo abra.


#### Para recordar

- Dinero propio.
- Copias fuera de casa.
- 079 y 911.



### Profundiza (5 minutos más)

#### Mi plan (llénalo en privado)

| Parte | Listo |
|---|---|
| Cuenta o ahorro a mi nombre | |
| Copias de mis papeles y los de mis hijos | |
| Contactos guardados | |
| Lugar a dónde ir | |



#### Tus derechos

Al separarte puedes tener derecho a una parte de los bienes y a pensión alimenticia para tus hijos (módulo 7). La defensoría pública te orienta sin costo.



#### Casos


**Caso 1. Sin dinero propio**

La hermana de Lucía no tiene dinero a su nombre.
- *¿Qué hace?* Abre una cuenta y aparta poco a poco.


**Caso 2. Los papeles**

No sabe dónde están las actas de sus hijos.
- *¿Qué hace?* Saca copias en línea y las deja con alguien de confianza.


**Caso 3. Peligro inmediato**

Su pareja la amenaza esa noche.
- *¿Qué hace?* Llama al 911.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener plan | Más difícil salir | Prepáralo |
| Papeles solo en casa | Te los esconden | Copias fuera |
| Contarlo a quien no debes | Riesgo | Discreción |
| Esperar en peligro | Riesgo | 911 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con la hermana de Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde guardas copias de tus papeles? a) En el auto de tu pareja · b) Solo en la casa, en un cajón · c) Con alguien de confianza o en tu correo
2. Hay peligro inmediato. ¿A dónde llamas? a) Al 911 · b) A la tienda · c) A nadie
3. ¿Quién te orienta sin costo sobre bienes y pensión? a) La defensoría pública · b) Un vecino que sabe de leyes · c) El banco
**Respuestas:** 1-c: fuera de casa. 2-a: 911. 3-a: defensoría.



#### Ponlo en práctica

Apartas 50 pesos al día. ¿Cuánto en 30 días?
**Respuesta:** 1,500 pesos.



#### A tu plan

Si lo necesitas, llena tu plan en privado. Si no, compártelo con alguien que pueda necesitarlo.



### Para saber más

- **Línea de las Mujeres:** 079, opción 1. Emergencias: 911.
- **Defensoría pública** (Poder Judicial de tu estado) — **Qué buscar:** «defensoría pública familiar».

### Palabras clave

- *Plan de seguridad:* lo que preparas para salir de un peligro.
- *Discreción:* hacerlo sin que se note.
- *Refugio:* lugar seguro para mujeres y sus hijos.

### Fuentes

Secretaría de las Mujeres, Línea 079; consultado el 5 de octubre de 2026.

---

## M6 U03. Recuperar el control de tu dinero

**Lo que lograrás:** Dar los primeros pasos para recuperar tu dinero, tu crédito y tus papeles después de la violencia económica.

**Para empezar:** Lucía ya se separó. Pero tiene deudas que sacó su expareja a su nombre, su crédito está manchado y no tiene sus escrituras. En esta lección verás por dónde empezar.

### Lo esencial (5 minutos)

#### Tres pasos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Revisa tu crédito | Reporte especial sin costo una vez al año. | Buró y Círculo. |
| Reclama lo que no es tuyo | Créditos que no pediste. | Con folio. |
| Cambia accesos | NIP, contraseñas, correo. | Que solo tú sepas. |

#### Recupera tus papeles

Saca copias de actas en línea, pide copias de escrituras en el Registro Público y repón tu INE si te la quitaron.



#### Paso a paso

No tienes que resolver todo en un día. Elige un paso por semana y anótalo.



#### Un caso en un minuto

Lucía pidió su reporte: había dos créditos que no pidió. Presentó reclamaciones con la ayuda de la defensoría. Cambió su NIP y sus contraseñas. En tres meses su reporte estaba limpio.

> **Idea clave:** revisa tu crédito, reclama lo que no es tuyo y cambia tus accesos; un paso por semana.



#### Comprueba lo que entendiste

1. ¿Cada cuándo puedes pedir tu reporte de crédito sin costo?
*Respuesta:* Una vez cada 12 meses en cada sociedad.

2. ¿Qué accesos cambias?
*Respuesta:* NIP, contraseñas y correo.


#### Para recordar

- Revisa tu crédito.
- Reclama con folio.
- Cambia tus accesos.



### Profundiza (5 minutos más)

#### Mis pasos

| Semana | Paso | Hecho |
|---|---|---|
| 1 | Pedir reporte de crédito | |
| 2 | Cambiar NIP y contraseñas | |
| 3 | Reclamar créditos ajenos | |
| 4 | Recuperar copias de papeles | |



#### Si te siguen molestando

Si tu expareja sigue usando tus datos o te amenaza, guarda pruebas y denuncia. El 079 te orienta sobre medidas de protección.



#### Casos


**Caso 1. Créditos ajenos**

Lucía tiene dos créditos que no pidió.
- *¿Qué hace?* Presenta reclamaciones con folio.


**Caso 2. Las contraseñas**

Su expareja conoce la contraseña de su correo.
- *¿Qué hace?* La cambia junto con su NIP.


**Caso 3. Todo a la vez**

Lucía se siente abrumada.
- *¿Qué hace?* Elige un paso por semana.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar el crédito | Deudas ajenas | Reporte |
| Mismas contraseñas | Sigue el acceso | Cámbialas |
| Querer todo hoy | Te abrumas | Paso a paso |
| No guardar pruebas | Difícil denunciar | Guárdalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde ves si hay créditos a tu nombre que no pediste? a) En tu INE, atrás de la foto · b) En tu acta de nacimiento · c) En tu reporte de crédito
2. Tu expareja conoce tus contraseñas. ¿Qué haces? a) Las cambias · b) Nada, se queda igual · c) Le pides que las olvide
3. Te sientes abrumada. ¿Qué haces? a) Un paso por semana · b) Nada, se queda igual · c) Todo en un día, para quitártelo de encima
**Respuestas:** 1-c: reporte. 2-a: cámbialas. 3-a: paso a paso.



#### Ponlo en práctica

Tienes 4 pasos y haces uno por semana. ¿En cuántas semanas terminas?
**Respuesta:** En 4 semanas.



#### A tu plan

Llena tu tabla de pasos y haz el primero esta semana.



### Para saber más

- **Reporte de crédito especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.
- **Reporte de crédito especial** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.
- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una queja contra un banco o financiera y qué papeles tener a la mano; teléfono 55 5340 0999.
- **Línea de las Mujeres:** 079, opción 1.

### Palabras clave

- *Reporte de crédito:* tu historial de deudas.
- *Reclamación:* queja formal con folio.
- *Medidas de protección:* órdenes para que no te molesten.

### Fuentes

Buró de Crédito y Círculo de Crédito; CONDUSEF; Secretaría de las Mujeres; consultados el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Pensión alimenticia

## M7 U01. Qué cubre la pensión alimenticia

**Lo que lograrás:** Identificar qué cubre la pensión alimenticia y que es un derecho de tus hijos.

**Para empezar:** La expareja de Lucía le da 1,500 al mes «para la comida». Ella cree que eso es todo lo que le toca a sus hijos. En esta lección verás qué cubre de verdad.

### Lo esencial (5 minutos)

#### Es un derecho de tus hijos

La pensión alimenticia es el dinero que el padre o la madre que no vive con los hijos debe aportar para su desarrollo. Es un derecho de las niñas y los niños, no un favor.



#### Qué cubren los alimentos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comida | Lo de todos los días. | Básico. |
| Casa | Una parte de renta y servicios. | Donde viven. |
| Salud | Consultas y medicinas. | Atención. |
| Escuela | Útiles, uniformes, cuotas. | Educación. |

#### Según necesidades y posibilidades

El monto se fija según lo que necesitan los hijos y lo que puede pagar quien la da. Se puede acordar o lo fija un juez.



#### Un caso en un minuto

Lucía hizo la cuenta de lo que cuestan sus hijos: comida, escuela, salud y parte de la renta. Eran 6,000 al mes. Con eso fue a la defensoría para revisar el monto.

> **Idea clave:** la pensión alimenticia es un derecho de tus hijos y cubre comida, casa, salud y escuela.



#### Comprueba lo que entendiste

1. ¿De quién es el derecho a la pensión alimenticia?
*Respuesta:* De las niñas y los niños.

2. ¿Qué cubre?
*Respuesta:* Comida, casa, salud y escuela.


#### Para recordar

- Es derecho de tus hijos.
- No solo comida.
- Según necesidades y posibilidades.



### Profundiza (5 minutos más)

#### Lo que cuestan mis hijos al mes

| Concepto | Monto |
|---|---|
| Comida | |
| Parte de la casa | |
| Salud | |
| Escuela | |
| Ropa y otros | |
| **Total** | |



#### También puede pedirla la mamá que no vive con ellos

La obligación es de quien no vive con los hijos, sea mamá o papá.



#### Casos


**Caso 1. «Para la comida»**

La expareja de Lucía da 1,500 solo para comida.
- *¿Qué hace?* Calcula lo que cuestan sus hijos y pide orientación.


**Caso 2. «Es un favor»**

A una amiga de Andrea le dicen que la pensión es un favor.
- *¿Qué le dice Andrea?* Que es un derecho de los hijos.


**Caso 3. Sin acuerdo**

Leticia se está separando y no hay acuerdo de pensión.
- *¿Qué hace?* Pide orientación en la defensoría pública.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es un favor | No la exiges | Es un derecho |
| Solo contar comida | Monto bajo | Todo lo que cubre |
| No calcular | No sabes cuánto pedir | Haz la tabla |
| Esperar sin acuerdo | Pierdes tiempo | Pide orientación |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Andrea y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué cubre la pensión alimenticia? a) Solo ropa · b) Solo comida, lo demás es aparte · c) Comida, casa, salud y escuela
2. ¿De quién es el derecho? a) De los hijos · b) De la mamá que cuida a los hijos · c) Del papá
3. ¿Cómo se fija el monto? a) Lo que quiera quien paga · b) Según necesidades y posibilidades · c) Siempre 1,000 pesos
**Respuestas:** 1-c: todo eso. 2-a: de los hijos. 3-b: necesidades y posibilidades.



#### Ponlo en práctica

Comida 3,000, escuela 1,200, salud 600 y parte de la casa 1,200. ¿Total?
**Respuesta:** 6,000 pesos.



#### A tu plan

Llena la tabla de lo que cuestan tus hijos al mes.



### Para saber más

- **Defensoría pública** (Poder Judicial de tu estado) — **Qué buscar:** «defensoría pública familiar».
- **Procuraduría de Protección de Niñas, Niños y Adolescentes** (DIF · español): https://www.gob.mx/difnacional — **Qué buscar:** la procuraduría de tu estado y cómo pedir orientación.

### Palabras clave

- *Alimentos:* lo que necesitan los hijos para vivir y crecer.
- *Pensión alimenticia:* dinero para los alimentos de los hijos.
- *Defensoría pública:* abogados del Estado sin costo.

### Fuentes

Ley General de los Derechos de Niñas, Niños y Adolescentes; códigos civiles estatales; consultados el 5 de octubre de 2026.

---

## M7 U02. Si la pensión no llega

**Lo que lograrás:** Decidir qué hacer cuando la pensión alimenticia se atrasa o deja de pagarse.

**Para empezar:** Desde hace cuatro meses, la expareja de Lucía no paga. Le dice que «no tiene». Lucía no quiere pelear, pero los niños necesitan útiles. En esta lección verás los pasos.

### Lo esencial (5 minutos)

#### Los pasos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Junta pruebas | Comprobantes de lo que sí pagó y de lo que no. | Fechas. |
| Ve a la defensoría | Te orientan sin costo. | Familiar. |
| Pide descuento por nómina | Si tiene trabajo formal. | Directo. |
| Registro de deudores | Existe un registro nacional. | Para quien no paga. |

#### Lo atrasado se puede reclamar

Los pagos que no se hicieron se pueden reclamar. Lleva la cuenta de cada mes que no llegó.



#### Si hay violencia

Si pedir la pensión te pone en riesgo, oriéntate en el 079, opción 1. Hay formas de hacerlo con medidas de protección.



#### Un caso en un minuto

Lucía juntó sus comprobantes y fue a la defensoría. Le explicaron que puede pedir lo atrasado y el descuento por nómina, porque su expareja trabaja en una empresa.

> **Idea clave:** junta tus pruebas, ve a la defensoría y pide lo atrasado; si trabaja formal, el descuento puede ser por nómina.



#### Comprueba lo que entendiste

1. ¿Qué juntas antes de ir a la defensoría?
*Respuesta:* Comprobantes de lo que pagó y de lo que no, con fechas.

2. ¿Se puede reclamar lo atrasado?
*Respuesta:* Sí.


#### Para recordar

- Pruebas con fechas.
- Defensoría sin costo.
- Descuento por nómina.



### Profundiza (5 minutos más)

#### Lo atrasado de Lucía

- Pensión mensual acordada: **1,500**
- Meses sin pago: **4**
- Atrasado: **6,000**


#### Registro Nacional de Obligaciones Alimentarias

Es un registro de personas que deben pensión alimenticia. Pregunta en la defensoría cómo se usa en tu caso.



#### Casos


**Caso 1. «No tengo»**

La expareja de Lucía dice que no tiene para pagar.
- *¿Qué hace?* Junta pruebas y va a la defensoría.


**Caso 2. Trabajo formal**

La expareja trabaja en una empresa.
- *¿Qué pide Lucía?* El descuento por nómina.


**Caso 3. Miedo**

A una conocida de Andrea le da miedo pedir la pensión.
- *¿Qué le sugiere?* Orientarse en el 079 sobre medidas de protección.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No guardar comprobantes | Difícil probar | Guárdalos |
| Dejar pasar los meses | Crece la deuda | Actúa |
| Ir sola sin orientación | Te pierdes | Defensoría |
| Arriesgarte | Peligro | 079 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía y una conocida de Andrea. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. La pensión no llega desde hace meses. ¿Qué haces primero? a) Le quitas a los niños · b) Nada, se queda igual · c) Juntas pruebas con fechas
2. Quien paga trabaja en una empresa. ¿Qué puedes pedir? a) Un regalo de vez en cuando · b) Descuento por nómina · c) Nada, se queda igual
3. Te da miedo pedirla. ¿Dónde te orientas? a) En el banco donde cobras · b) En el 079, opción 1 · c) En la tienda
**Respuestas:** 1-c: pruebas. 2-b: nómina. 3-b: 079.



#### Ponlo en práctica

La pensión es de 2,000 y no llegó en 3 meses. ¿Cuánto está atrasado?
**Respuesta:** 6,000 pesos.



#### A tu plan

Junta tus comprobantes y anota los meses que no llegó la pensión.



### Para saber más

- **Defensoría pública** (Poder Judicial de tu estado) — **Qué buscar:** «pensión alimenticia».
- **Línea de las Mujeres:** 079, opción 1.

### Palabras clave

- *Atrasado:* lo que debió pagarse y no se pagó.
- *Descuento por nómina:* que la empresa descuente la pensión del sueldo.
- *Deudor alimentario:* quien no paga la pensión.

### Fuentes

Registro Nacional de Obligaciones Alimentarias; DIF; consultados el 5 de octubre de 2026.

---

## M7 U03. Que la pensión rinda para tus hijos

**Lo que lograrás:** Administrar la pensión alimenticia para los gastos de tus hijos y dejar registro.

**Para empezar:** Cuando llega la pensión, Lucía la mezcla con su sueldo y se va en todo. Su expareja le reclama que «no sabe en qué se gasta». En esta lección verás cómo ordenarla.

### Lo esencial (5 minutos)

#### Sepárala

Ten la pensión en un apartado o una cuenta distinta. Así sabes cuánto llega y en qué se usa.



#### Un plan sencillo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lista de gastos de los hijos | La tabla de M7 U01. | Base. |
| Gastos de temporada | Inicio de clases, uniformes. | Aparta cada mes. |
| Comprobantes | Recibos de escuela, médico. | Guárdalos. |

#### No tienes que rendir cuentas por cada peso

No tienes obligación de justificar cada gasto ante tu expareja, pero tener tus cuentas en orden te protege si hay un juicio o una revisión.



#### Un caso en un minuto

Lucía abrió un apartado para la pensión. Cada mes reserva 300 para el regreso a clases. Guarda los recibos en una carpeta.

> **Idea clave:** separa la pensión, planea los gastos de temporada y guarda comprobantes.



#### Comprueba lo que entendiste

1. ¿Por qué separar la pensión?
*Respuesta:* Para saber cuánto llega y en qué se usa.

2. ¿Qué gastos planeas con tiempo?
*Respuesta:* Los de temporada, como el regreso a clases.


#### Para recordar

- Sepárala.
- Aparta para la temporada.
- Guarda comprobantes.



### Profundiza (5 minutos más)

#### El regreso a clases de Lucía

- Al mes: **300**
- Meses: **10**
- Para útiles y uniformes: **3,000**


#### Tus hijos también aprenden

Platicar con tus hijos, según su edad, sobre cómo se usa el dinero de la casa les enseña a planear.



#### Casos


**Caso 1. Mezclado**

Lucía mezcla la pensión con su sueldo.
- *¿Qué hace?* La separa en un apartado.


**Caso 2. El regreso a clases**

Cada agosto, a Lucía no le alcanza.
- *¿Qué hace?* Aparta cada mes para el regreso a clases.


**Caso 3. El reclamo**

La expareja dice que no sabe en qué se gasta.
- *¿Qué hace?* Guarda sus comprobantes en una carpeta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mezclar | No sabes en qué se va | Sepárala |
| No planear la temporada | Te quedas corta | Aparta |
| No guardar recibos | Sin pruebas | Carpeta |
| Justificar cada peso | Te desgastas | Solo cuentas en orden |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde conviene guardar la pensión? a) Con tu expareja · b) Mezclada con tu sueldo para que alcance · c) En un apartado o cuenta distinta
2. Apartas 250 al mes para el regreso a clases. ¿Cuánto en 10 meses? a) 2,500 · b) 250 · c) 25,000
3. ¿Qué guardas? a) Nada, se queda igual · b) Recibos de escuela y médico · c) Solo los tickets del súper de cada semana
**Respuestas:** 1-c: separada. 2-a: 250 por 10. 3-b: comprobantes.



#### Ponlo en práctica

El uniforme y los útiles cuestan 3,600. ¿Cuánto apartas al mes durante 12 meses?
**Respuesta:** 300 pesos.



#### A tu plan

Abre un apartado para la pensión y decide cuánto reservarás para el regreso a clases.



### Para saber más

- **Presupuesto familiar** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «regreso a clases».

### Palabras clave

- *Apartado:* espacio de tu cuenta para separar dinero.
- *Gasto de temporada:* gasto que llega en ciertos meses.
- *Comprobante:* papel que muestra un pago.

### Fuentes

CONDUSEF, presupuesto familiar y regreso a clases; consultado el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Estrés financiero y salud

## M8 U01. El estrés por dinero también es salud

**Lo que lograrás:** Reconocer cómo el estrés por dinero afecta tu cuerpo y tu ánimo.

**Para empezar:** Andrea tiene gastritis y no duerme bien. Su doctora le preguntó si estaba preocupada por algo. Ella dijo «solo por dinero», como si no contara. En esta lección verás que sí cuenta.

### Lo esencial (5 minutos)

#### El dinero se siente en el cuerpo

En México, 42.2% de las mujeres vive con estrés financiero alto, contra 30.7% de los hombres. Uno de cada tres adultos reporta malestar físico por preocupaciones de dinero: gastritis, colitis, dolor de cabeza, presión.



#### Señales en ti

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sueño | No duermes o despiertas pensando en pagos. | Cansancio. |
| Cuerpo | Gastritis, dolor de cabeza, presión. | Malestar. |
| Ánimo | Tristeza, enojo, culpa. | Sin ganas. |
| Evitar | No abrir estados de cuenta ni contestar. | Esconderse. |

#### Nombrarlo ayuda

Decir «estoy estresada por dinero» no es exagerar. Es el primer paso para hacer algo.



#### Un caso en un minuto

Andrea le contó a su doctora. Le recomendó atención para el estrés y ordenar sus deudas. Empezó por hacer su lista. Dice que ver los números le dio menos miedo que imaginarlos.

> **Idea clave:** el estrés por dinero afecta tu salud; reconocerlo es el primer paso.



#### Comprueba lo que entendiste

1. ¿Qué porcentaje de mujeres vive con estrés financiero alto?
*Respuesta:* 42.2%.

2. ¿Cuál es una señal de estrés por dinero?
*Respuesta:* No dormir, gastritis, dolor de cabeza, tristeza o evitar ver los números.


#### Para recordar

- El estrés es salud.
- Reconócelo.
- Habla de ello.



### Profundiza (5 minutos más)

#### Mis señales

| Señal | Me pasa |
|---|---|
| No duermo bien | |
| Dolor de estómago o cabeza | |
| Tristeza o enojo | |
| Evito ver mis cuentas | |



#### Si te sientes muy mal

Si el estrés te quita las ganas de vivir, busca ayuda de inmediato: Línea de la Vida, 800 911 2000, las 24 horas.



#### Casos


**Caso 1. «Solo por dinero»**

Andrea minimiza su preocupación.
- *¿Qué hace?* La reconoce y lo platica con su doctora.


**Caso 2. Los sobres sin abrir**

Leticia no abre sus estados de cuenta.
- *¿Qué hace?* Los abre con alguien de confianza y hace su lista.


**Caso 3. Sin dormir**

Lucía no duerme pensando en la renta.
- *¿Qué hace?* Escribe su presupuesto y lo que hará mañana.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Minimizarlo | Empeora | Reconócelo |
| Evitar los números | Crecen los problemas | Míralos |
| Callarlo | Te aíslas | Platícalo |
| No pedir ayuda | Te enfermas | Busca atención |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Andrea, Leticia y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿El estrés por dinero afecta la salud? a) Solo a los hombres · b) No · c) Sí
2. ¿Qué porcentaje de mujeres vive con estrés financiero alto? a) 10%, muy pocas · b) 42.2% · c) 90%, casi todas
3. Evitas abrir tus estados de cuenta. ¿Qué haces? a) Los abres con alguien de confianza · b) Los tiras · c) Los escondes hasta que tengas dinero
**Respuestas:** 1-c: sí. 2-b: 42.2%. 3-a: con apoyo.



#### Ponlo en práctica

Escribe una señal de estrés por dinero que hayas sentido.
**Respuesta:** Respuesta personal, por ejemplo: «No duermo bien la noche antes de pagar la renta».



#### A tu plan

Llena tu tabla de señales y platícala con alguien de confianza.



### Para saber más

- **Línea de la Vida** (Gobierno de México · español): 800 911 2000, las 24 horas.
- **ENSAFI** (INEGI · español): https://www.inegi.org.mx — **Qué buscar:** «ENSAFI 2023».

### Palabras clave

- *Estrés financiero:* preocupación por el dinero.
- *Malestar:* sentirse mal del cuerpo.
- *Señal:* algo que te avisa.

### Fuentes

INEGI y CONDUSEF, ENSAFI 2023; consultado el 5 de octubre de 2026.

---

## M8 U02. Tres pasos pequeños

**Lo que lograrás:** Bajar el estrés por dinero con tres acciones pequeñas que sí puedes hacer.

**Para empezar:** Leticia siente que tiene que resolver todo: deudas, ahorro, retiro, casa. Como es mucho, no hace nada. En esta lección elegirás solo tres pasos.

### Lo esencial (5 minutos)

#### Tres pasos que bajan el estrés

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1. Ver los números | Una lista de lo que entra, sale y debes. | Una vez. |
| 2. Un colchón chico | Aunque sean 500 pesos. | Para imprevistos. |
| 3. Una fecha fija | Un día al mes para revisar. | 20 minutos. |

#### Chico es mejor que nada

Un paso pequeño que haces es mejor que un plan grande que no empiezas. Cuando terminas uno, el siguiente pesa menos.



#### No lo hagas sola

Un círculo de mujeres, una amiga o tu familia pueden acompañarte. Los círculos de este programa sirven para eso.



#### Un caso en un minuto

Leticia hizo su lista un domingo, apartó 500 pesos en su cuenta y puso el día 5 de cada mes para revisar. Dice que duerme mejor.

> **Idea clave:** ve tus números, junta un colchón chico y revisa en una fecha fija; tres pasos pequeños bajan el estrés.



#### Comprueba lo que entendiste

1. ¿Cuáles son los tres pasos?
*Respuesta:* Ver los números, juntar un colchón chico y revisar en una fecha fija.

2. ¿Por qué empezar chico?
*Respuesta:* Porque un paso que haces vale más que un plan que no empiezas.


#### Para recordar

- Ve tus números.
- Colchón chico.
- Fecha fija.



### Profundiza (5 minutos más)

#### El colchón de Leticia

- Por semana: **125**
- Semanas: **4**
- En un mes: **500**


#### Cuídate también

Dormir, moverte y hablar con alguien también bajan el estrés. El dinero importa, y tú también.



#### Casos


**Caso 1. Todo a la vez**

Leticia quiere resolver todo y no hace nada.
- *¿Qué hace?* Elige tres pasos pequeños.


**Caso 2. El colchón**

Andrea no tiene nada para imprevistos.
- *¿Qué hace?* Aparta poco cada semana hasta llegar a 500.


**Caso 3. Se le olvida revisar**

Lucía revisa sus cuentas solo cuando hay problema.
- *¿Qué hace?* Pone una fecha fija al mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Querer todo | No empiezas | Tres pasos |
| Esperar a tener mucho | Sin colchón | Poco a poco |
| Revisar solo en crisis | Sorpresas | Fecha fija |
| Hacerlo sola | Te desanimas | Acompáñate |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Leticia, Andrea y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué baja el estrés por dinero? a) Pedir otro préstamo · b) No pensar en eso · c) Tres pasos pequeños
2. Apartas 100 por semana. ¿En cuántas semanas llegas a 500? a) 5 · b) 50 · c) 1
3. ¿Cada cuándo revisas tus cuentas? a) En una fecha fija al mes · b) Solo en crisis, cuando ya no alcanza · c) Nunca
**Respuestas:** 1-c: pasos pequeños. 2-a: 5 semanas. 3-a: fecha fija.



#### Ponlo en práctica

Apartas 75 por semana. ¿Cuánto tienes en 8 semanas?
**Respuesta:** 600 pesos.



#### A tu plan

Escribe tus tres pasos y la fecha de tu revisión mensual.



### Para saber más

- **Fondo de emergencia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Colchón:* dinero para imprevistos.
- *Revisión:* ver cómo vas.
- *Círculo:* grupo de mujeres que se acompañan.

### Fuentes

CONDUSEF, recomendaciones de ahorro; consultado el 5 de octubre de 2026.

---

## M8 U03. Mi plan de autonomía

**Lo que lograrás:** Reunir en una página tus decisiones sobre dinero, retiro, protección y salud.

**Para empezar:** Doña Rosario terminó el curso con muchas hojas llenas. Quiere tener todo en un solo lugar para revisarlo y enseñárselo a su hija. En esta lección harás tu plan de autonomía.

### Lo esencial (5 minutos)

#### Tu plan tiene seis partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| A mi nombre | Cuenta, papeles, ingreso propio. | M1. |
| Mi trabajo cuenta | Presupuesto y acuerdos. | M2. |
| Mi retiro | Afore, semanas, pensión. | M3 y M4. |
| Protegida | Seguros y salud. | M5. |
| Segura | Señales y plan de seguridad. | M6. |
| En calma | Tres pasos. | M7 y M8. |

#### Una acción y una fecha

Para cada parte escribe la siguiente acción y cuándo la harás. No tienes que hacerlo todo hoy.



#### Compártelo si quieres

Puedes compartir tu plan con una persona de confianza o en tu círculo. Si tu plan de seguridad es privado, no lo pongas aquí.



#### Un caso en un minuto

Doña Rosario hizo su plan: registrarse a Mujeres Bienestar (esta semana), preguntar por sus semanas (el lunes), aportar 100 a su Afore (cada mes). Se lo enseñó a su hija.

> **Idea clave:** junta tus decisiones en una página con una acción y una fecha para cada parte.



#### Comprueba lo que entendiste

1. ¿Cuántas partes tiene tu plan?
*Respuesta:* Seis.

2. ¿Qué escribes en cada una?
*Respuesta:* La siguiente acción y una fecha.


#### Para recordar

- Seis partes.
- Una acción por parte.
- Con fecha.



### Profundiza (5 minutos más)

#### Mi plan de autonomía

| Parte | Siguiente acción | Fecha |
|---|---|---|
| A mi nombre | | |
| Mi trabajo cuenta | | |
| Mi retiro | | |
| Protegida | | |
| Segura | | |
| En calma | | |



#### Revísalo cada tres meses

Tu vida cambia; tu plan también. Revísalo cada tres meses o cuando algo importante pase.



#### Casos


**Caso 1. Muchas hojas**

Doña Rosario tiene todo disperso.
- *¿Qué hace?* Junta todo en su plan de una página.


**Caso 2. Todo hoy**

Andrea quiere hacer las seis partes hoy.
- *¿Qué hace?* Escribe una acción con fecha para cada parte.


**Caso 3. El plan privado**

Leticia tiene un plan de seguridad que no quiere que vean.
- *¿Qué hace?* Lo guarda aparte y no lo pone en su plan general.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Hojas dispersas | No ves el avance | Una página |
| Todo hoy | Te abrumas | Una acción por parte |
| Sin fechas | No pasa | Pon fecha |
| Exponer tu plan de seguridad | Riesgo | Guárdalo aparte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Rosario, Andrea y Leticia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué lleva cada parte de tu plan? a) Un dibujo · b) Solo lo que ya hiciste en el curso · c) La siguiente acción y una fecha
2. ¿Cada cuándo revisas tu plan? a) Nunca · b) Cada tres meses o si algo cambia · c) Cada diez años, cuando cambia todo
3. Tienes un plan de seguridad privado. ¿Dónde lo guardas? a) Aparte, en privado · b) En el plan que compartes · c) En la puerta del refrigerador
**Respuestas:** 1-c: acción y fecha. 2-b: cada tres meses. 3-a: aparte.



#### Ponlo en práctica

Escribe la siguiente acción de la parte «Mi retiro» con una fecha.
**Respuesta:** Ejemplo: «Localizar mi Afore con mi CURP el sábado 10».



#### A tu plan

Llena tu plan de autonomía y ponle fecha a cada acción.



### Para saber más

- **Todo lo del curso** (Desarrolla Talento · español): repasa las tablas de los módulos 1 a 8.

### Palabras clave

- *Autonomía:* poder decidir por ti misma.
- *Plan:* lista de lo que harás y cuándo.
- *Revisión:* volver a ver cómo vas.

### Fuentes

Elaboración propia con base en los módulos 1 a 8 del programa.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Autonomía, Tu Dinero, Tu Futuro** — Programa de bienestar financiero para mujeres adultas: dinero y documentos a su nombre, un presupuesto que cuenta el trabajo de cuidados, Afore y retiro, Pensión Mujeres Bienestar, seguros, violencia económica, pensión alimenticia y estrés financiero. 8 módulos y 24 lecciones cortas en línea, con dos círculos presenciales. No es un curso de emprendimiento.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Mi dinero, mi nombre:** Una cuenta, tus documentos y un ingreso propio a tu nombre.
- **Un presupuesto que cuenta los cuidados:** Tu presupuesto del hogar con tu trabajo de cuidados contado y acuerdos de dinero claros.
- **Afore, semanas y aportaciones voluntarias:** Tu Afore localizada, tus semanas revisadas y tu primera aportación voluntaria.
- **Pensión Mujeres Bienestar:** Tu registro o el de una mujer cercana a la Pensión Mujeres Bienestar, y un plan para usarla.
- **Seguros para mí:** Tus seguros revisados y tu decisión sobre un seguro para ti.
- **Violencia económica: señales y salida:** Las señales de violencia económica y tu plan de seguridad económica.
- **Pensión alimenticia:** Tus pasos para pedir, cobrar y administrar la pensión alimenticia.
- **Estrés financiero y salud:** Tus tres pasos pequeños para bajar el estrés por dinero y tu plan de autonomía.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 24 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Leticia:** 45 años. Ama de casa en Querétaro; su esposo maneja todo el dinero de la casa.
- **Lucía:** 38 años. Separada, con dos hijos. Trabaja en una tienda y recibe pensión alimenticia que a veces no llega.
- **Doña Rosario:** 61 años. Dejó de trabajar para cuidar a sus papás. Tiene ocho años cotizados en el IMSS.
- **Andrea:** 29 años. Trabaja en una oficina y quiere tener su propio ahorro y su retiro en orden.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **No es un curso de emprendimiento:** se enfoca en autonomía, retiro y protección.
5. **Sin culpas:** se separan los hábitos personales de las desigualdades que no dependen de ellas.
6. **Seguridad primero:** las lecciones de violencia económica recuerdan borrar el historial si alguien revisa el dispositivo y dan el 079 y el 911.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. El dinero de la casa de Leticia (Módulos 1 y 2)

**Datos.** El esposo de Leticia gana 18,000 al mes y maneja todo. Leticia cuida a sus dos hijos y a su suegra unas 40 horas a la semana. No tiene cuenta a su nombre. Acuerdan que cada uno tenga un dinero propio de 600 al mes, además del gasto de la casa.

**Tareas.**

1. ¿Qué cuenta pide Leticia y a nombre de quién?
2. ¿Qué revisa sobre los bienes de la familia?
3. ¿Por qué su trabajo de cuidados cuenta en el presupuesto?
4. ¿Cuánto junta en un año con su dinero propio si aparta la mitad?

**Clave.**

- Una cuenta básica, a su nombre.
- A nombre de quién están la casa y el auto, su régimen matrimonial, y guarda copias suyas.
- Porque es trabajo: sostiene el hogar aunque no se pague; el dinero del hogar es de quienes lo sostienen.
- 300 por 12: 3,600.

### E2. El retiro de Doña Rosario (Módulos 3 y 4)

**Datos.** Doña Rosario tiene 61 años y ocho años cotizados en el IMSS (unas 416 semanas). Dejó de trabajar para cuidar a sus papás. Puede aportar 200 al mes a su Afore. Una vecina le dice que para la Pensión Mujeres Bienestar «hay que pagar el registro».

**Tareas.**

1. ¿Cómo localiza su Afore?
2. ¿Cuánto aporta en un año?
3. ¿Tiene que pagar el registro a la Pensión Mujeres Bienestar?
4. ¿Qué pasa cuando cumpla 65?

**Clave.**

- Con su CURP, en AforeMóvil o en e-SAR.
- 200 por 12: 2,400.
- No: el registro es sin costo, en las fechas oficiales, para mujeres de 60 a 64 años.
- Pasa en automático a la Pensión Adultos Mayores, con más monto; la tarjeta y el NIP se quedan con ella.

### E3. Los seguros y la violencia económica (Módulos 5 y 6)

**Datos.** Andrea revisa su estado de cuenta y ve un seguro de 150 al mes que no pidió. Su amiga Lucía le cuenta que su exesposo sacó una tarjeta a nombre de ella y no la deja ver sus estados de cuenta.

**Tareas.**

1. ¿Cuánto ahorra Andrea al año si cancela el seguro que no pidió?
2. ¿Qué es lo que vive Lucía?
3. ¿Qué tres cosas guarda Lucía en su plan de seguridad económica?
4. ¿Qué hace con la tarjeta que no sacó?

**Clave.**

- 150 por 12: 1,800.
- Violencia económica: usar su nombre sin permiso y quitarle el control de su dinero. No es su culpa y hay a dónde llamar.
- Un poco de dinero propio, copias de sus papeles fuera de casa y sus contactos (y un lugar a dónde ir).
- Revisa su reporte de crédito, reclama lo que no es suyo y cambia sus accesos, un paso por semana.

### E4. La pensión de los hijos de Lucía (Módulos 7 y 8)

**Datos.** Lucía debe recibir 3,000 al mes de pensión alimenticia; en los últimos cuatro meses solo llegaron dos pagos. El papá trabaja con nómina. En agosto gastará 2,400 en útiles y uniformes. Dice que el dinero no la deja dormir.

**Tareas.**

1. ¿Cuánto le deben?
2. ¿Qué hace para cobrar lo atrasado?
3. ¿Cuánto aparta al mes desde enero para pagar agosto?
4. ¿Cuáles son sus tres pasos pequeños contra el estrés?

**Clave.**

- Dos pagos de 3,000: 6,000.
- Junta sus pruebas, va a la defensoría y pide lo atrasado; como él trabaja con nómina, el descuento puede ser por nómina.
- 2,400 entre 8 meses (enero a agosto): 300.
- Ver sus números, juntar un colchón chico y revisar en una fecha fija.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Apartas 100 pesos de cada gasto semanal en tu cuenta. ¿Cuánto en un año? |
| P02 | M1 U02 | Escribe dos bienes de tu hogar y a nombre de quién están. |
| P03 | M1 U03 | Entran 12,000 y los gastos de la casa son 10,400. Si cada uno toma 500, ¿cuánto queda para ahorro en común? |
| P04 | M2 U01 | Una cuidadora cuesta 8,000 al mes. ¿Cuánto vale ese trabajo en un año? |
| P05 | M2 U02 | Apartas 300 por quincena para unos lentes de 900. ¿En cuántas quincenas los juntas? |
| P06 | M2 U03 | Los gastos comunes son 15,000 y tú pones 40%. ¿Cuánto pones? |
| P07 | M3 U01 | Si 34 de cada 100 mujeres tienen Afore, ¿cuántas no tienen? |
| P08 | M3 U02 | Eres Ley 73 y tienes 380 semanas. ¿Cuántas te faltan? |
| P09 | M3 U03 | Aportas 150 al mes. ¿Cuánto en 5 años, sin rendimientos? |
| P10 | M4 U01 | Recibes 3,100 por bimestre. ¿Cuánto al año? |
| P11 | M4 U02 | De 1,550 al mes, apartas 300 para medicinas. ¿Cuánto queda para lo demás? |
| P12 | M4 U03 | Con 6,400 por bimestre, ¿cuánto tienes al mes? |
| P13 | M5 U01 | Tu familia necesitaría 60,000 al año durante 8 años. ¿Cuánto debería pagar el seguro? |
| P14 | M5 U02 | Una consulta privada cuesta 600 y la necesitas 4 veces al año. ¿Cuánto apartas al mes? |
| P15 | M5 U03 | Cancelas un seguro de 120 al mes. ¿Cuánto ahorras en un año? |
| P16 | M6 U01 | Escribe una señal de violencia económica que conozcas. |
| P17 | M6 U02 | Apartas 50 pesos al día. ¿Cuánto en 30 días? |
| P18 | M6 U03 | Tienes 4 pasos y haces uno por semana. ¿En cuántas semanas terminas? |
| P19 | M7 U01 | Comida 3,000, escuela 1,200, salud 600 y parte de la casa 1,200. ¿Total? |
| P20 | M7 U02 | La pensión es de 2,000 y no llegó en 3 meses. ¿Cuánto está atrasado? |
| P21 | M7 U03 | El uniforme y los útiles cuestan 3,600. ¿Cuánto apartas al mes durante 12 meses? |
| P22 | M8 U01 | Escribe una señal de estrés por dinero que hayas sentido. |
| P23 | M8 U02 | Apartas 75 por semana. ¿Cuánto tienes en 8 semanas? |
| P24 | M8 U03 | Escribe la siguiente acción de la parte «Mi retiro» con una fecha. |

### Respuestas

- **P01:** 5,200 pesos.
- **P02:** Respuesta personal, por ejemplo: «La casa, a nombre de los dos; el auto, a nombre de mi pareja».
- **P03:** 600 pesos.
- **P04:** 96,000 pesos.
- **P05:** En 3 quincenas.
- **P06:** 6,000 pesos.
- **P07:** 66 de cada 100.
- **P08:** 120.
- **P09:** 9,000 pesos.
- **P10:** 18,600 pesos.
- **P11:** 1,250 pesos.
- **P12:** 3,200 pesos.
- **P13:** 480,000 pesos.
- **P14:** 200 pesos.
- **P15:** 1,440 pesos.
- **P16:** Ejemplo: «Que te prohíban trabajar para que dependas».
- **P17:** 1,500 pesos.
- **P18:** En 4 semanas.
- **P19:** 6,000 pesos.
- **P20:** 6,000 pesos.
- **P21:** 300 pesos.
- **P22:** Respuesta personal, por ejemplo: «No duermo bien la noche antes de pagar la renta».
- **P23:** 600 pesos.
- **P24:** Ejemplo: «Localizar mi Afore con mi CURP el sábado 10».


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Mi dinero, mi nombre

- **Acuerdo:** lo que deciden juntos.
- **Ahorro en común:** dinero que juntan para metas de la familia.
- **Autonomía:** poder decidir por ti misma.
- **Cuenta básica:** cuenta sin comisión por manejo.
- **Cuenta mancomunada:** cuenta de dos personas.
- **Escritura:** papel que dice de quién es una casa o terreno.
- **Ingreso propio:** dinero que ganas tú.
- **Separación de bienes:** cada quien es dueño de lo suyo.
- **Sociedad conyugal:** lo que compran durante el matrimonio es de los dos.

### Un presupuesto que cuenta los cuidados

- **Aporte:** lo que das al hogar.
- **Gasto necesario:** lo que necesitas para estar bien.
- **Gastos comunes:** los que se comparten.
- **Presupuesto:** plan de lo que entra y sale.
- **Proporción:** parte según lo que gana cada quien.
- **Renglón:** cada gasto de la lista.
- **Revisión:** volver a ver el acuerdo.
- **Trabajo de cuidados:** cuidar a otras personas.
- **Trabajo no remunerado:** trabajo sin pago.

### Afore, semanas y aportaciones voluntarias

- **Afore:** administradora de tu ahorro para el retiro.
- **Aportación voluntaria:** lo que tú agregas a tu Afore.
- **Beneficiario:** quien recibe tu ahorro si faltas.
- **Brecha:** diferencia entre dos grupos.
- **Domiciliar:** cargo automático cada mes.
- **Laguna:** tiempo en que no cotizaste.
- **Ley 73 y Ley 97:** reglas según cuándo empezaste a cotizar.
- **Rendimiento:** lo que genera tu ahorro.
- **Semanas cotizadas:** semanas trabajadas con IMSS.

### Pensión Mujeres Bienestar

- **Actualizar datos:** corregir tu teléfono o domicilio.
- **Automático:** sin hacer trámite.
- **Bimestre:** dos meses.
- **Control:** poder decidir sobre tu dinero.
- **Monto:** cantidad de dinero.
- **Módulo:** oficina donde te registras.
- **Persona auxiliar:** alguien registrado para ayudarte.
- **Plan:** cómo vas a usar tu dinero.
- **Violencia económica:** cuando alguien controla o toma tu dinero.

### Seguros para mí

- **Beneficiaria:** quien tiene servicio por un familiar.
- **Cargo no reconocido:** cobro que no aceptaste.
- **Estado de cuenta:** resumen de movimientos.
- **Preventivo:** estudio para detectar a tiempo.
- **Prima:** lo que pagas por el seguro.
- **Póliza:** contrato del seguro.
- **Suma asegurada:** lo que paga el seguro.
- **Tutor:** quien cuida el dinero de un menor.
- **Vigencia:** que tu derecho está activo.

### Violencia económica: señales y salida

- **Discreción:** hacerlo sin que se note.
- **Medidas de protección:** órdenes para que no te molesten.
- **Orientación:** ayuda para saber qué hacer.
- **Plan de seguridad:** lo que preparas para salir de un peligro.
- **Reclamación:** queja formal con folio.
- **Refugio:** lugar seguro para mujeres y sus hijos.
- **Reporte de crédito:** tu historial de deudas.
- **Violencia patrimonial:** dañar, quitar o retener tus bienes o papeles.

### Pensión alimenticia

- **Alimentos:** lo que necesitan los hijos para vivir y crecer.
- **Apartado:** espacio de tu cuenta para separar dinero.
- **Atrasado:** lo que debió pagarse y no se pagó.
- **Comprobante:** papel que muestra un pago.
- **Defensoría pública:** abogados del Estado sin costo.
- **Descuento por nómina:** que la empresa descuente la pensión del sueldo.
- **Deudor alimentario:** quien no paga la pensión.
- **Gasto de temporada:** gasto que llega en ciertos meses.
- **Pensión alimenticia:** dinero para los alimentos de los hijos.

### Estrés financiero y salud

- **Colchón:** dinero para imprevistos.
- **Círculo:** grupo de mujeres que se acompañan.
- **Estrés financiero:** preocupación por el dinero.
- **Malestar:** sentirse mal del cuerpo.
- **Señal:** algo que te avisa.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Cuentas básicas | CONDUSEF: https://www.condusef.gob.mx | «cuenta básica» | M1 U01 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M1 U01, M5 U01 |
| Defensoría pública | Poder Judicial de tu estado:  | «defensoría pública familiar» | M1 U02, M6 U02, M7 U01, M7 U02 |
| Finanzas en pareja | CONDUSEF: https://www.condusef.gob.mx | «finanzas en pareja» | M1 U03, M2 U03 |
| Encuesta Nacional sobre Uso del Tiempo | INEGI: https://www.inegi.org.mx | «ENUT 2024» | M2 U01 |
| Presupuesto | CONDUSEF: https://www.condusef.gob.mx | «presupuesto familiar» | M2 U02 |
| AforeMóvil y localización | CONSAR: https://www.gob.mx/consar | «localiza tu Afore». SARTEL 55 1328 5000 | M3 U01 |
| Semanas cotizadas | IMSS: https://serviciosdigitales.imss.gob.mx | «constancia de semanas cotizadas» | M3 U02 |
| Ahorro voluntario | CONSAR: https://www.gob.mx/consar | «ahorro voluntario» | M3 U03 |
| Pensión Mujeres Bienestar | Secretaría de Bienestar: https://programasparaelbienestar.gob.mx | «Mujeres Bienestar» | M4 U01 |
| Línea de las Mujeres | Secretaría de las Mujeres: 079, opción 1 | — | M4 U02, M6 U01 |
| Pensión para el Bienestar de las Personas Adultas Mayores | Secretaría de Bienestar: https://programasparaelbienestar.gob.mx | — | M4 U03 |
| Seguros de vida | CONDUSEF: https://www.condusef.gob.mx | «seguro de vida» | M5 U01 |
| Vigencia de derechos | IMSS: https://www.imss.gob.mx | «vigencia de derechos» | M5 U02 |
| IMSS-Bienestar | Gobierno de México: https://www.gob.mx/imss-bienestar | — | M5 U02 |
| Cargos no reconocidos | CONDUSEF: https://www.condusef.gob.mx | «seguros no solicitados». 55 5340 0999 | M5 U03 |
| Ley General de Acceso de las Mujeres a una Vida Libre de Violencia | Cámara de Diputados: https://www.diputados.gob.mx/LeyesBiblio | «artículo 6» | M6 U01 |
| Reclamaciones | CONDUSEF: https://www.condusef.gob.mx | 55 5340 0999 | — | M6 U03 |
| Procuraduría de Protección de Niñas, Niños y Adolescentes | DIF: https://www.gob.mx/difnacional | — | M7 U01 |
| Presupuesto familiar | CONDUSEF: https://www.condusef.gob.mx | «regreso a clases» | M7 U03 |
| Línea de la Vida | Gobierno de México: 800 911 2000, las 24 horas | — | M8 U01 |
| ENSAFI | INEGI: https://www.inegi.org.mx | «ENSAFI 2023» | M8 U01 |
| Fondo de emergencia | CONDUSEF: https://www.condusef.gob.mx | «fondo de emergencia» | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Mi dinero, mi nombre

- **M1 U01 · Una cuenta a tu nombre.** INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.
- **M1 U02 · Tus documentos y tus bienes a tu nombre.** Códigos civiles estatales, regímenes matrimoniales; consultado el 5 de octubre de 2026.
- **M1 U03 · Un dinero propio, aunque no tengas sueldo.** CONDUSEF, finanzas en pareja; consultado el 5 de octubre de 2026.

### Un presupuesto que cuenta los cuidados

- **M2 U01 · Tu trabajo de cuidados vale.** INEGI, Encuesta Nacional sobre Uso del Tiempo 2024; consultado el 5 de octubre de 2026.
- **M2 U02 · El presupuesto del hogar, con tu parte.** CONDUSEF, presupuesto familiar; consultado el 5 de octubre de 2026.
- **M2 U03 · Acuerdos de dinero que se cumplen.** CONDUSEF, finanzas en pareja; consultado el 5 de octubre de 2026.

### Afore, semanas y aportaciones voluntarias

- **M3 U01 · La brecha de la Afore.** INEGI y CNBV, ENIF 2024; CONSAR; consultados el 5 de octubre de 2026.
- **M3 U02 · Las semanas que se pierden por cuidar.** IMSS, requisitos de pensión Ley 73 y Ley 97; consultado el 5 de octubre de 2026.
- **M3 U03 · Aportaciones voluntarias: tu retiro, tu decisión.** CONSAR, ahorro voluntario; consultado el 5 de octubre de 2026.

### Pensión Mujeres Bienestar

- **M4 U01 · Qué es la Pensión Mujeres Bienestar.** Secretaría de Bienestar, Pensión Mujeres Bienestar 2026; consultado el 5 de octubre de 2026.
- **M4 U02 · Que tu pensión sea para ti.** Secretaría de Bienestar; Secretaría de las Mujeres, Línea 079; consultados el 5 de octubre de 2026.
- **M4 U03 · A los 65, el paso a la Pensión Adultos Mayores.** Secretaría de Bienestar, Pensión Mujeres Bienestar y Pensión Adultos Mayores 2026; consultado el 5 de octubre de 2026.

### Seguros para mí

- **M5 U01 · Un seguro de vida también para ti.** INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.
- **M5 U02 · Tu salud, protegida.** IMSS, vigencia de derechos; IMSS-Bienestar; consultados el 5 de octubre de 2026.
- **M5 U03 · Revisa los seguros que ya pagas.** CONDUSEF, cargos no reconocidos y seguros; consultado el 5 de octubre de 2026.

### Violencia económica: señales y salida

- **M6 U01 · Señales de violencia económica.** Ley General de Acceso de las Mujeres a una Vida Libre de Violencia, artículo 6; INEGI, ENDIREH 2021; Secretaría de las Mujeres, Línea 079; consultados el 5 de octubre de 2026.
- **M6 U02 · Tu plan de seguridad económica.** Secretaría de las Mujeres, Línea 079; consultado el 5 de octubre de 2026.
- **M6 U03 · Recuperar el control de tu dinero.** Buró de Crédito y Círculo de Crédito; CONDUSEF; Secretaría de las Mujeres; consultados el 5 de octubre de 2026.

### Pensión alimenticia

- **M7 U01 · Qué cubre la pensión alimenticia.** Ley General de los Derechos de Niñas, Niños y Adolescentes; códigos civiles estatales; consultados el 5 de octubre de 2026.
- **M7 U02 · Si la pensión no llega.** Registro Nacional de Obligaciones Alimentarias; DIF; consultados el 5 de octubre de 2026.
- **M7 U03 · Que la pensión rinda para tus hijos.** CONDUSEF, presupuesto familiar y regreso a clases; consultado el 5 de octubre de 2026.

### Estrés financiero y salud

- **M8 U01 · El estrés por dinero también es salud.** INEGI y CONDUSEF, ENSAFI 2023; consultado el 5 de octubre de 2026.
- **M8 U02 · Tres pasos pequeños.** CONDUSEF, recomendaciones de ahorro; consultado el 5 de octubre de 2026.
- **M8 U03 · Mi plan de autonomía.** Elaboración propia con base en los módulos 1 a 8 del programa.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Una cuenta a tu nombre

**Caso 1. «Para el gasto».** El esposo de Leticia le da efectivo cada semana. **¿Qué hace?**

- ✔ Abre una cuenta básica y pide que le depositen ahí.
- Sigue recibiendo efectivo, porque así lo han hecho siempre.
- Le pide a su esposo que le dé su tarjeta.

**Caso 2. La cuenta de los dos.** Andrea y su novio quieren una sola cuenta para todo. **¿Qué hace?**

- ✔ Mantiene la suya además de la compartida.
- Cierra su cuenta y usan solo la de los dos.
- Le da su NIP a su novio para la cuenta común.

**Caso 3. El NIP.** La pareja de Lucía le pide su NIP «por si acaso». **¿Qué hace?**

- ✔ No se lo da.
- Se lo da, porque si no, él va a pensar que le esconde algo.
- Le da los primeros dos números.

## M1 U02. Tus documentos y tus bienes a tu nombre

**Caso 1. La escritura.** La casa de Leticia está solo a nombre de su esposo. **¿Qué hace?**

- ✔ Revisa su régimen y guarda copia de la escritura.
- No revisa nada, porque confía en que su esposo nunca la dejaría sin casa.
- Le pide a su suegra que guarde los papeles.

**Caso 2. El auto de Lucía.** Lucía pagó el auto, pero la factura está a nombre de su expareja. **¿Qué hace?**

- ✔ Junta sus comprobantes y pide orientación legal.
- Da el auto por perdido.
- Toma el auto sin decir nada.

**Caso 3. La compra nueva.** Andrea y su pareja van a comprar un terreno. **¿Qué hace?**

- ✔ Pide que la escritura quede a nombre de los dos.
- Deja que quede solo a nombre de su pareja, porque él puso más.
- No firma nada para no complicarse.

## M1 U03. Un dinero propio, aunque no tengas sueldo

**Caso 1. «No tengo derecho».** Leticia cree que no puede gastar en ella porque no gana sueldo. **¿Qué hace?**

- ✔ Propone una cantidad igual para cada uno.
- Sigue sin gastar en ella, porque piensa que no le corresponde.
- Toma dinero sin decirle a nadie.

**Caso 2. «Es mi dinero».** El esposo de Leticia dice que el dinero es de él. **¿Qué hace Leticia?**

- ✔ Le muestra con números cómo sostienen el hogar.
- Le da la razón para no pelear.
- Deja de hacer el trabajo de la casa en protesta.

**Caso 3. Pareja nueva.** Andrea empieza a vivir con su pareja. **¿Qué hace?**

- ✔ Acuerdan desde el inicio gastos y dinero de cada quien.
- Lo dejan para después, cuando ya estén instalados y vean cómo les va.
- Ella paga todo para no pelear.

## M2 U01. Tu trabajo de cuidados vale

**Caso 1. «En nada».** Doña Rosario dice que no trabaja. **¿Qué hace?**

- ✔ Reconoce que cuidó y calcula cuánto aportó.
- Sigue diciendo que no trabaja, porque nunca le pagaron.
- Se siente culpable por no haber tenido empleo.

**Caso 2. Las horas de Leticia.** Leticia no sabe cuántas horas trabaja en casa. **¿Qué hace?**

- ✔ Llena su tabla de horas de una semana.
- Calcula a ojo.
- Piensa que no vale la pena contarlas.

**Caso 3. Repartir.** Lucía hace todo en casa además de su trabajo. **¿Qué hace?**

- ✔ Muestra sus horas y reparte tareas.
- Sigue haciendo todo sola para que no haya pleitos en la casa.
- Deja de hacer todo de golpe.

## M2 U02. El presupuesto del hogar, con tu parte

**Caso 1. No aparece.** Lucía no aparece en su presupuesto. **¿Qué hace?**

- ✔ Agrega un renglón con su nombre.
- Sigue sin aparecer, porque los niños son primero.
- Se pone al final, si sobra.

**Caso 2. Los lentes.** Doña Rosario lleva un año sin cambiar sus lentes. **¿Qué hace?**

- ✔ Los incluye como gasto necesario y aparta.
- Espera a que le alcance algún día para cambiar sus lentes.
- Compra unos lentes de farmacia sin consulta.

**Caso 3. Todo para los hijos.** Leticia gasta todo lo que sobra en los hijos. **¿Qué hace?**

- ✔ Aparta también un monto para ella.
- Gasta todo lo que sobra en los hijos.
- Ahorra todo para los hijos.

## M2 U03. Acuerdos de dinero que se cumplen

**Caso 1. «Más o menos».** Andrea termina pagando más sin que lo hablen. **¿Qué hace?**

- ✔ Propone un acuerdo escrito con proporciones.
- Sigue pagando más sin decir nada para evitar una discusión.
- Deja de pagar la comida sin avisar.

**Caso 2. Ganan distinto.** Leticia no gana sueldo y su esposo sí. **¿Qué hacen?**

- ✔ Acuerdan gastos comunes y dinero de cada quien.
- Él decide todo porque gana el sueldo.
- Ella pide prestado para su parte.

**Caso 3. Subió la renta.** A Lucía y su hermana, que viven juntas, les subieron la renta. **¿Qué hacen?**

- ✔ Revisan su acuerdo antes de la fecha.
- Esperan a la fecha aunque ya no les alcance.
- Cada una paga lo que pueda ese mes.

## M3 U01. La brecha de la Afore

**Caso 1. «Cosa de viejitas».** Andrea cree que la Afore no le importa todavía. **¿Qué hace?**

- ✔ La localiza con su CURP.
- Lo deja para cuando tenga 50 años y le preocupe el retiro.
- Le pide a su mamá que la busque.

**Caso 2. Sin patrón.** Leticia nunca tuvo empleo formal. **¿Qué hace?**

- ✔ Abre su Afore con su CURP en la app.
- Piensa que sin patrón no puede tener Afore.
- Espera a casarse para tener la Afore del esposo.

**Caso 3. Beneficiarios viejos.** Lucía tiene a su expareja como beneficiaria. **¿Qué hace?**

- ✔ Cambia a sus beneficiarios por sus hijos.
- Deja a su expareja, porque cambiarlo es mucho trámite.
- Pone a su mamá para no pensar.

## M3 U02. Las semanas que se pierden por cuidar

**Caso 1. ¿Puede pensionarse?.** Doña Rosario no sabe cuántas semanas tiene. **¿Qué hace?**

- ✔ Pide su constancia de semanas en el IMSS.
- Supone que ya no tiene derecho a nada porque dejó de trabajar hace mucho.
- Le pregunta a una vecina.

**Caso 2. ¿Qué ley?.** Andrea empezó a trabajar en 2018. **¿Qué hace?**

- ✔ Calcula con la Ley 97 cuántas le faltan.
- Supone que es Ley 73 porque le piden menos semanas.
- Piensa que falta mucho y no revisa.

**Caso 3. El gestor.** Le ofrecen a Doña Rosario «completar sus semanas» pagando 15,000 a un gestor. **¿Qué hace?**

- ✔ Pregunta directo en el IMSS.
- Le paga los 15,000 al gestor para no perder tiempo.
- Le paga la mitad y lo demás al ver las semanas.

## M3 U03. Aportaciones voluntarias: tu retiro, tu decisión

**Caso 1. «100 pesos no hacen nada».** Leticia cree que su aportación no sirve. **¿Qué hace?**

- ✔ Aporta 100 cada mes en la tienda.
- No aporta, porque cree que 100 pesos no hacen ninguna diferencia.
- Espera a tener 1,000 juntos.

**Caso 2. Se le olvida.** Andrea aporta cuando se acuerda. **¿Qué hace?**

- ✔ Domicilia un monto fijo.
- Sigue aportando cuando se acuerda, aunque pasen meses.
- Deja de aportar.

**Caso 3. Dinero extra.** Lucía recibió 1,000 pesos de un trabajo extra. **¿Qué hace?**

- ✔ Aporta una parte a su Afore.
- Lo gasta todo en algo que quería.
- Lo guarda en casa por si acaso.

## M4 U01. Qué es la Pensión Mujeres Bienestar

**Caso 1. «Solo para las que no trabajaron».** Doña Rosario cree que no le toca. **¿Qué hace?**

- ✔ Pregunta en el módulo y se registra.
- No va, porque cree que el apoyo es solo para quienes nunca trabajaron.
- Le pide a un gestor que la registre.

**Caso 2. La mamá de Lucía.** La mamá de Lucía tiene 62 años y no sabe del programa. **¿Qué hace Lucía?**

- ✔ Le ayuda a juntar sus papeles.
- Espera a que su mamá se entere sola.
- La registra con sus propios datos.

**Caso 3. El lugar asegurado.** Le piden a Leticia 300 pesos para registrar a su mamá. **¿Qué hace?**

- ✔ No paga y reporta a la Línea de Bienestar.
- Paga los 300 para que su mamá no se quede fuera.
- Paga y no dice nada.

## M4 U02. Que tu pensión sea para ti

**Caso 1. «Para administrarla».** El hijo de Doña Rosario se quedó con su tarjeta. **¿Qué hace?**

- ✔ Recupera su tarjeta y cambia su NIP.
- Deja la tarjeta con su hijo, porque él sabe administrar mejor.
- Le pide que le dé algo cada mes.

**Caso 2. Todo para los nietos.** La mamá de Lucía gasta toda su pensión en los nietos. **¿Qué hace?**

- ✔ Aparta primero para su salud y sus gastos.
- Sigue gastando toda la pensión en sus nietos.
- Deja de ver a sus nietos.

**Caso 3. Todo el primer mes.** Doña Rosario gasta toda la pensión el primer mes. **¿Qué hace?**

- ✔ La divide en dos mitades.
- La gasta toda el primer mes y espera el siguiente depósito.
- Pide prestado el segundo mes.

## M4 U03. A los 65, el paso a la Pensión Adultos Mayores

**Caso 1. «Regístrate otra vez».** La comadre le dice a Doña Rosario que se registre desde cero. **¿Qué hace?**

- ✔ Mantiene sus datos al día; el paso es automático.
- Se registra desde cero para no perder nada.
- Deja de cobrar mientras se aclara.

**Caso 2. El gestor del cambio.** Le ofrecen hacer «el cambio» por 500 pesos. **¿Qué hace?**

- ✔ No paga y reporta.
- Paga los 500 para que el cambio salga a tiempo y sin errores.
- Paga la mitad.

**Caso 3. El nuevo monto.** Doña Rosario recibirá más dinero. **¿Qué hace?**

- ✔ Decide antes cómo repartirlo.
- Espera a ver en qué se va.
- Se lo da todo a su hijo.

## M5 U01. Un seguro de vida también para ti

**Caso 1. Sin seguro propio.** Lucía no tiene seguro a su nombre. **¿Qué hace?**

- ✔ Pregunta en su trabajo y revisa beneficiarios.
- Contrata el primer seguro que le ofrezcan por teléfono, por si acaso.
- Lo deja para cuando sus hijos sean mayores.

**Caso 2. Hijos menores.** Los beneficiarios de Andrea serían sus sobrinos menores. **¿Qué hace?**

- ✔ Pregunta cómo nombrar a un tutor.
- Pone a los sobrinos sin más.
- No pone a nadie.

**Caso 3. Seguro por teléfono.** Le ofrecen a Leticia un seguro de vida por teléfono. **¿Qué hace?**

- ✔ Pide la información por escrito y verifica.
- Contrata en la llamada porque la oferta es solo por hoy.
- Da su tarjeta para que le manden información.

## M5 U02. Tu salud, protegida

**Caso 1. ¿Sigo teniendo IMSS?.** Leticia se separó y no sabe si sigue como beneficiaria. **¿Qué hace?**

- ✔ Consulta su vigencia en el IMSS.
- Supone que sigue teniendo IMSS como antes, porque nadie le avisó nada.
- Usa la credencial de su expareja.

**Caso 2. Trabaja por su cuenta.** Lucía hace trabajos extra por su cuenta y quiere IMSS. **¿Qué hace?**

- ✔ Revisa los requisitos para independientes.
- Se queda sin servicio médico.
- Usa la credencial de su hermana.

**Caso 3. La mamografía.** Doña Rosario no se ha hecho una mamografía. **¿Qué hace?**

- ✔ Pregunta en su clínica pública.
- Lo deja para cuando tenga síntomas.
- Paga uno privado sin preguntar antes.

## M5 U03. Revisa los seguros que ya pagas

**Caso 1. Tres seguros sorpresa.** Andrea encuentra tres seguros que no recordaba. **¿Qué hace?**

- ✔ Pregunta qué cubre cada uno y cancela el que no le sirve.
- Cancela los tres sin preguntar qué cubren.
- Sigue pagando todo.

**Caso 2. El seguro que no pidió.** A Lucía le cobran un seguro que nunca aceptó. **¿Qué hace?**

- ✔ Pide cancelarlo y la devolución.
- Lo sigue pagando, porque cancelar es mucho trámite y no quiere problemas.
- Cierra su cuenta sin reclamar.

**Caso 3. Sin póliza.** Leticia paga un seguro, pero no tiene la póliza. **¿Qué hace?**

- ✔ La pide y la guarda.
- Sigue pagando sin saber qué cubre.
- Cancela sin revisar.

## M6 U01. Señales de violencia económica

**Caso 1. El auto vendido.** El esposo de Leticia vendió el auto de los dos sin decirle. **¿Qué hace?**

- ✔ Se orienta en el 079 sobre sus derechos.
- No hace nada, porque piensa que así son las parejas.
- Le reclama a gritos sin saber sus derechos.

**Caso 2. El crédito a su nombre.** La expareja de Lucía sacó un crédito a nombre de ella. **¿Qué hace?**

- ✔ Revisa su reporte y reclama.
- Paga los créditos para no tener problemas.
- Los ignora porque no son suyos.

**Caso 3. «No sabes administrar».** A Andrea su novio le dice que no sabe administrar y le pide su sueldo. **¿Qué hace?**

- ✔ Reconoce la señal y conserva su dinero.
- Le da su sueldo, porque él dice que sabe administrar mejor y ella le cree.
- Le da la mitad.

## M6 U02. Tu plan de seguridad económica

**Caso 1. Sin dinero propio.** La hermana de Lucía no tiene dinero a su nombre. **¿Qué hace?**

- ✔ Abre una cuenta y aparta poco a poco.
- Espera a que su pareja le dé dinero para irse.
- Pide un préstamo caro.

**Caso 2. Los papeles.** No sabe dónde están las actas de sus hijos. **¿Qué hace?**

- ✔ Saca copias y las deja con alguien de confianza.
- Deja los papeles en casa, donde siempre han estado guardados.
- Les pide los papeles a su pareja.

**Caso 3. Peligro inmediato.** Su pareja la amenaza esa noche. **¿Qué hace?**

- ✔ Llama al 911.
- Espera a que se calme.
- Lo platica al día siguiente.

## M6 U03. Recuperar el control de tu dinero

**Caso 1. Créditos ajenos.** Lucía tiene dos créditos que no pidió. **¿Qué hace?**

- ✔ Presenta reclamaciones con folio.
- Paga los créditos para limpiar su historial rápido.
- Los deja así.

**Caso 2. Las contraseñas.** Su expareja conoce la contraseña de su correo. **¿Qué hace?**

- ✔ La cambia junto con su NIP.
- Deja la misma contraseña porque ya está separada.
- Le pide que no entre.

**Caso 3. Todo a la vez.** Lucía se siente abrumada. **¿Qué hace?**

- ✔ Elige un paso por semana.
- Intenta resolverlo todo el mismo día, aunque termine agotada.
- Lo deja todo para después.

## M7 U01. Qué cubre la pensión alimenticia

**Caso 1. «Para la comida».** La expareja de Lucía da 1,500 solo para comida. **¿Qué hace?**

- ✔ Calcula el costo de sus hijos y pide orientación.
- Acepta los 1,500, porque piensa que eso es todo lo que le toca.
- Deja de pedir para no pelear.

**Caso 2. «Es un favor».** A una amiga de Andrea le dicen que la pensión es un favor. **¿Qué le dice Andrea?**

- ✔ Que es un derecho de los hijos.
- Que tiene razón y es un favor.
- Que no se meta.

**Caso 3. Sin acuerdo.** Leticia se está separando y no hay acuerdo de pensión. **¿Qué hace?**

- ✔ Pide orientación en la defensoría.
- Espera a que él ofrezca algo.
- Decide no pedir nada.

## M7 U02. Si la pensión no llega

**Caso 1. «No tengo».** La expareja de Lucía dice que no tiene para pagar. **¿Qué hace?**

- ✔ Junta pruebas y va a la defensoría.
- Acepta que no tiene y deja de pedir, aunque los niños necesiten útiles.
- Le pide a su familia que pague.

**Caso 2. Trabajo formal.** La expareja trabaja en una empresa. **¿Qué pide Lucía?**

- ✔ El descuento por nómina.
- Que le pague cuando pueda.
- Nada, porque es difícil.

**Caso 3. Miedo.** A una conocida de Andrea le da miedo pedir la pensión. **¿Qué le sugiere?**

- ✔ Orientarse en el 079.
- No pedir nada.
- Pedirla a gritos.

## M7 U03. Que la pensión rinda para tus hijos

**Caso 1. Mezclado.** Lucía mezcla la pensión con su sueldo. **¿Qué hace?**

- ✔ La separa en un apartado.
- La sigue mezclando con su sueldo, porque al final todo es para la casa.
- La gasta el día que llega.

**Caso 2. El regreso a clases.** Cada agosto, a Lucía no le alcanza. **¿Qué hace?**

- ✔ Aparta cada mes para el regreso a clases.
- Pide prestado cada agosto.
- Espera a ver si le alcanza.

**Caso 3. El reclamo.** La expareja dice que no sabe en qué se gasta. **¿Qué hace?**

- ✔ Guarda comprobantes en una carpeta.
- Le da explicaciones de cada peso por mensaje.
- Deja de comprar cosas para no discutir.

## M8 U01. El estrés por dinero también es salud

**Caso 1. «Solo por dinero».** Andrea minimiza su preocupación. **¿Qué hace?**

- ✔ La reconoce y lo platica con su doctora.
- Sigue diciendo que es solo dinero y que ya se le pasará.
- Se toma algo para la gastritis y ya.

**Caso 2. Los sobres sin abrir.** Leticia no abre sus estados de cuenta. **¿Qué hace?**

- ✔ Los abre con alguien de confianza.
- Los guarda sin abrir.
- Los tira.

**Caso 3. Sin dormir.** Lucía no duerme pensando en la renta. **¿Qué hace?**

- ✔ Escribe su presupuesto y lo que hará mañana.
- Se queda despierta dándole vueltas toda la noche.
- Pide un préstamo para la renta.

## M8 U02. Tres pasos pequeños

**Caso 1. Todo a la vez.** Leticia quiere resolver todo y no hace nada. **¿Qué hace?**

- ✔ Elige tres pasos pequeños.
- Sigue sin hacer nada, porque siente que es demasiado para ella sola.
- Intenta todo en una semana.

**Caso 2. El colchón.** Andrea no tiene nada para imprevistos. **¿Qué hace?**

- ✔ Aparta poco cada semana.
- Espera a tener mucho para empezar.
- Pide prestado para tener colchón.

**Caso 3. Se le olvida revisar.** Lucía revisa sus cuentas solo cuando hay problema. **¿Qué hace?**

- ✔ Pone una fecha fija al mes.
- Revisa solo cuando hay problema.
- Deja de revisar.

## M8 U03. Mi plan de autonomía

**Caso 1. Muchas hojas.** Doña Rosario tiene todo disperso. **¿Qué hace?**

- ✔ Junta todo en una página.
- Sigue con sus hojas sueltas, porque ahí ya está todo lo que aprendió.
- Lo deja en la memoria.

**Caso 2. Todo hoy.** Andrea quiere hacer las seis partes hoy. **¿Qué hace?**

- ✔ Escribe una acción con fecha para cada parte.
- Intenta hacer todo hoy.
- Lo deja para el próximo mes.

**Caso 3. El plan privado.** Leticia tiene un plan de seguridad que no quiere que vean. **¿Qué hace?**

- ✔ Lo guarda aparte.
- Lo incluye en el plan que comparte con la familia.
- Lo tira.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Qué te da una cuenta a tu nombre?

- Que tu pareja vea tus gastos
- Más deudas
- ✔ Dinero que decides tú

*¡Correcto! Tú decides.*

**M1 U01 P2.** ¿Qué porcentaje de mujeres tiene cuenta en México?

- 90%, casi todas
- ✔ 58.6%
- 20%, una de cada cinco

*¡Correcto! 58.6%.*

**M1 U01 P3.** Tu pareja te pide tu NIP. ¿Qué haces?

- Le das la mitad
- ✔ No se lo das
- Se lo das

*¡Correcto! Es tuyo.*

**M1 U02 P1.** ¿Dónde ves si estás casada por sociedad conyugal?

- En tu recibo de luz
- En tu INE, atrás de la foto
- ✔ En tu acta de matrimonio

*¡Correcto! El acta.*

**M1 U02 P2.** Van a comprar un terreno juntos. ¿Cómo debe quedar la escritura?

- Solo a nombre de él
- ✔ A nombre de los dos
- Sin nombre

*¡Correcto! Los dos.*

**M1 U02 P3.** ¿Dónde guardas copias de tus papeles?

- Se las das a tu suegra para que las cuide
- ✔ En un lugar que solo tú conozcas o en tu correo
- Donde todos las vean

*¡Correcto! Lugar tuyo.*

**M1 U03 P1.** Cuidas la casa y tu pareja gana el sueldo. ¿De quién es el dinero del hogar?

- De nadie
- Solo de él
- ✔ De los dos

*¡Correcto! De los dos.*

**M1 U03 P2.** Quedan 1,000 pesos después de gastos. ¿Cuánto para cada uno por igual?

- 1,000 para él
- ✔ 500
- 200

*¡Correcto! Mitad.*

**M1 U03 P3.** ¿Cómo conviene hablar de dinero en pareja?

- Nunca
- ✔ Con el presupuesto y los números
- A gritos, cuando ya no aguantas

*¡Correcto! Con números.*

## Módulo 2

**M2 U01 P1.** ¿Cuidar a tus papás es trabajo?

- Solo si te pagan por hacerlo
- No
- ✔ Sí, aunque no tenga pago

*¡Correcto! Es trabajo.*

**M2 U01 P2.** ¿Cuántas horas sin pago hacen los hombres en promedio?

- 39.7
- ✔ 18.2
- 0

*¡Correcto! 18.2.*

**M2 U01 P3.** ¿Para qué sirve contar tus horas?

- ✔ Para ver tu aporte y repartir mejor
- Para nada
- Para pedir un préstamo con tus horas

*¡Correcto! Ver y repartir.*

**M2 U02 P1.** ¿Tus lentes son un lujo o un gasto necesario?

- Depende de tu pareja
- Lujo
- ✔ Necesario

*¡Correcto! Necesario.*

**M2 U02 P2.** Te entran 8,000 por quincena. ¿Cuánto es 5% para ti?

- 80
- ✔ 400
- 800

*¡Correcto! 5% de 8,000.*

**M2 U02 P3.** ¿Qué renglón suele faltar en el presupuesto de muchas mujeres?

- ✔ El de ellas mismas
- La comida de toda la semana
- La renta

*¡Correcto! Ellas mismas.*

**M2 U03 P1.** Él gana 70% del total y ella 30%. Los gastos comunes son 10,000. ¿Cuánto pone ella?

- 7,000
- 5,000
- ✔ 3,000

*¡Correcto! 30% de 10,000.*

**M2 U03 P2.** ¿Cada cuándo revisan el acuerdo?

- ✔ En una fecha fija o cuando algo cambia
- Nunca
- Solo si hay pleito entre los dos

*¡Correcto! Fecha fija o cambios.*

**M2 U03 P3.** ¿Qué ayuda a evitar malentendidos?

- ✔ Escribir el acuerdo
- No hablar
- Que decida uno solo

*¡Correcto! Por escrito.*

## Módulo 3

**M3 U01 P1.** ¿Cuál es la brecha de Afore entre hombres y mujeres?

- 2 puntos, casi nada
- Ninguna
- ✔ 17.2 puntos

*¡Correcto! 51.4 menos 34.2.*

**M3 U01 P2.** ¿Con qué localizas tu Afore?

- Con tu acta de matrimonio
- ✔ Con tu CURP
- Con tu recibo de luz

*¡Correcto! CURP.*

**M3 U01 P3.** Nunca tuviste empleo formal. ¿Puedes tener Afore?

- Solo si te casas y tu esposo tiene una
- ✔ Sí, la abres con tu CURP
- No

*¡Correcto! Se puede abrir.*

**M3 U02 P1.** Empezaste a cotizar en 1995. ¿Qué ley te toca?

- Ley 97
- Ninguna
- ✔ Ley 73

*¡Correcto! Antes de 1997.*

**M3 U02 P2.** Eres Ley 97 y tienes 600 semanas. ¿Cuántas te faltan en 2026?

- ✔ 275
- 400
- 0

*¡Correcto! 875 menos 600.*

**M3 U02 P3.** Un gestor te ofrece completar semanas por 15,000. ¿Qué haces?

- Pagas la mitad ahora y la otra al terminar
- ✔ Preguntas directo en el IMSS
- Pagas

*¡Correcto! Directo.*

**M3 U03 P1.** ¿Dónde puedes aportar a tu Afore?

- Solo por medio de tu patrón
- Solo en las oficinas del IMSS, con cita
- ✔ En tienda, app o domiciliado

*¡Correcto! Tres formas.*

**M3 U03 P2.** Aportas 200 al mes. ¿Cuánto en 10 años, sin rendimientos?

- 2,400
- ✔ 24,000
- 240,000

*¡Correcto! 200 por 120 meses.*

**M3 U03 P3.** ¿Qué conviene más?

- Esperar a ganar más para aportar en grande
- ✔ Empezar pronto con poco
- Aportar solo al final

*¡Correcto! El tiempo ayuda.*

## Módulo 4

**M4 U01 P1.** ¿Quién puede recibir la Pensión Mujeres Bienestar?

- Solo mujeres que nunca trabajaron
- Mujeres de 18 a 30
- ✔ Mujeres de 60 a 64 años

*¡Correcto! 60 a 64.*

**M4 U01 P2.** ¿Cuánto es al bimestre en 2026?

- 6,400
- ✔ 3,100
- 1,000

*¡Correcto! 3,100.*

**M4 U01 P3.** Te piden dinero para registrarte. ¿Qué es?

- ✔ Fraude
- Una cuota oficial
- Algo normal entre parejas

*¡Correcto! Es sin costo.*

**M4 U02 P1.** ¿Quién guarda tu tarjeta de pensión?

- Tu nuera
- Tu hijo
- ✔ Tú

*¡Correcto! Tú.*

**M4 U02 P2.** Cobras 3,100 por bimestre. ¿Cuánto por mes?

- 3,100
- ✔ 1,550
- 1,000

*¡Correcto! La mitad.*

**M4 U02 P3.** Alguien usa tu pensión sin permiso. ¿Qué es?

- ✔ Violencia económica
- Algo normal en las familias
- Ayuda

*¡Correcto! Violencia económica.*

**M4 U03 P1.** ¿Qué pasa a los 65 si recibes Mujeres Bienestar?

- Te registras desde cero en un módulo
- Pierdes la pensión
- ✔ Pasas en automático a la Pensión Adultos Mayores

*¡Correcto! Automático.*

**M4 U03 P2.** ¿Cuánto más recibes por bimestre al cambiar?

- ✔ 3,300
- 100
- Nada, se queda igual

*¡Correcto! 6,400 menos 3,100.*

**M4 U03 P3.** Te cobran por hacer el cambio. ¿Qué haces?

- ✔ No pagas y reportas
- Pagas la mitad ahora y la otra al terminar
- Pagas

*¡Correcto! Es sin costo.*

## Módulo 5

**M5 U01 P1.** ¿Qué porcentaje de mujeres tiene algún seguro?

- 50%
- 80%, la mayoría
- ✔ 18.3%

*¡Correcto! 18.3%.*

**M5 U01 P2.** ¿Dónde puede haber un seguro que ya tienes?

- ✔ En las prestaciones de tu trabajo
- En tu INE, atrás de la foto
- En tu recibo de luz

*¡Correcto! Prestaciones.*

**M5 U01 P3.** Tus beneficiarios son menores. ¿Qué haces?

- Pones a tu expareja para que los cuide
- ✔ Preguntas cómo nombrar un tutor
- Nada, se queda igual

*¡Correcto! Un tutor.*

**M5 U02 P1.** No tienes seguridad social. ¿A dónde vas?

- Solo a hospitales privados
- A ningún lado, porque no tienes derecho
- ✔ A tu centro de salud del IMSS-Bienestar

*¡Correcto! IMSS-Bienestar.*

**M5 U02 P2.** Te separaste y eras beneficiaria del IMSS de tu pareja. ¿Qué haces?

- Nada, se queda igual
- ✔ Revisas tu vigencia
- Usas su credencial mientras se arregla

*¡Correcto! Revisa.*

**M5 U02 P3.** Apartas 150 al mes para salud. ¿Cuánto en un año?

- 150
- ✔ 1,800
- 15,000

*¡Correcto! 150 por 12.*

**M5 U03 P1.** Te cobran un seguro que no pediste. ¿Qué haces?

- Cierras tu cuenta sin decir nada
- Lo sigues pagando
- ✔ Pides cancelarlo y la devolución

*¡Correcto! Cancela y reclama.*

**M5 U03 P2.** Un seguro cuesta 95 al mes. ¿Cuánto al año?

- 95
- ✔ 1,140
- 950, como en diez meses

*¡Correcto! 95 por 12.*

**M5 U03 P3.** ¿Qué preguntas de cada seguro?

- Su color y el diseño de la póliza
- ✔ Qué cubre, cuánto cuesta y si lo necesitas
- Nada, se queda igual

*¡Correcto! Las tres preguntas.*

## Módulo 6

**M6 U01 P1.** Tu pareja vende un bien de los dos sin decirte. ¿Qué es?

- Un regalo de vez en cuando
- Algo normal entre parejas
- ✔ Violencia patrimonial

*¡Correcto! Es patrimonial.*

**M6 U01 P2.** ¿A dónde llamas para orientarte las 24 horas?

- ✔ Al 079, opción 1
- A tu suegra, para que hable con él
- A nadie

*¡Correcto! 079.*

**M6 U01 P3.** ¿Qué porcentaje de mujeres ha vivido violencia económica, patrimonial o discriminación?

- ✔ 27.4%
- 2%
- 90%, casi todas

*¡Correcto! 27.4%.*

**M6 U02 P1.** ¿Dónde guardas copias de tus papeles?

- En el auto de tu pareja
- Solo en la casa, en un cajón
- ✔ Con alguien de confianza o en tu correo

*¡Correcto! Fuera de casa.*

**M6 U02 P2.** Hay peligro inmediato. ¿A dónde llamas?

- ✔ Al 911
- A la tienda
- A nadie

*¡Correcto! 911.*

**M6 U02 P3.** ¿Quién te orienta sin costo sobre bienes y pensión?

- ✔ La defensoría pública
- Un vecino que sabe de leyes
- El banco

*¡Correcto! Defensoría.*

**M6 U03 P1.** ¿Dónde ves si hay créditos a tu nombre que no pediste?

- En tu INE, atrás de la foto
- En tu acta de nacimiento
- ✔ En tu reporte de crédito

*¡Correcto! Reporte.*

**M6 U03 P2.** Tu expareja conoce tus contraseñas. ¿Qué haces?

- ✔ Las cambias
- Nada, se queda igual
- Le pides que las olvide

*¡Correcto! Cámbialas.*

**M6 U03 P3.** Te sientes abrumada. ¿Qué haces?

- ✔ Un paso por semana
- Nada, se queda igual
- Todo en un día, para quitártelo de encima

*¡Correcto! Paso a paso.*

## Módulo 7

**M7 U01 P1.** ¿Qué cubre la pensión alimenticia?

- Solo ropa
- Solo comida, lo demás es aparte
- ✔ Comida, casa, salud y escuela

*¡Correcto! Todo eso.*

**M7 U01 P2.** ¿De quién es el derecho?

- ✔ De los hijos
- De la mamá que cuida a los hijos
- Del papá

*¡Correcto! De los hijos.*

**M7 U01 P3.** ¿Cómo se fija el monto?

- Lo que quiera quien paga
- ✔ Según necesidades y posibilidades
- Siempre 1,000 pesos

*¡Correcto! Necesidades y posibilidades.*

**M7 U02 P1.** La pensión no llega desde hace meses. ¿Qué haces primero?

- Le quitas a los niños
- Nada, se queda igual
- ✔ Juntas pruebas con fechas

*¡Correcto! Pruebas.*

**M7 U02 P2.** Quien paga trabaja en una empresa. ¿Qué puedes pedir?

- Un regalo de vez en cuando
- ✔ Descuento por nómina
- Nada, se queda igual

*¡Correcto! Nómina.*

**M7 U02 P3.** Te da miedo pedirla. ¿Dónde te orientas?

- En el banco donde cobras
- ✔ En el 079, opción 1
- En la tienda

*¡Correcto! 079.*

**M7 U03 P1.** ¿Dónde conviene guardar la pensión?

- Con tu expareja
- Mezclada con tu sueldo para que alcance
- ✔ En un apartado o cuenta distinta

*¡Correcto! Separada.*

**M7 U03 P2.** Apartas 250 al mes para el regreso a clases. ¿Cuánto en 10 meses?

- ✔ 2,500
- 250
- 25,000

*¡Correcto! 250 por 10.*

**M7 U03 P3.** ¿Qué guardas?

- Nada, se queda igual
- ✔ Recibos de escuela y médico
- Solo los tickets del súper de cada semana

*¡Correcto! Comprobantes.*

## Módulo 8

**M8 U01 P1.** ¿El estrés por dinero afecta la salud?

- Solo a los hombres
- No
- ✔ Sí

*¡Correcto! Sí.*

**M8 U01 P2.** ¿Qué porcentaje de mujeres vive con estrés financiero alto?

- 10%, muy pocas
- ✔ 42.2%
- 90%, casi todas

*¡Correcto! 42.2%.*

**M8 U01 P3.** Evitas abrir tus estados de cuenta. ¿Qué haces?

- ✔ Los abres con alguien de confianza
- Los tiras
- Los escondes hasta que tengas dinero

*¡Correcto! Con apoyo.*

**M8 U02 P1.** ¿Qué baja el estrés por dinero?

- Pedir otro préstamo
- No pensar en eso
- ✔ Tres pasos pequeños

*¡Correcto! Pasos pequeños.*

**M8 U02 P2.** Apartas 100 por semana. ¿En cuántas semanas llegas a 500?

- ✔ 5
- 50
- 1

*¡Correcto! 5 semanas.*

**M8 U02 P3.** ¿Cada cuándo revisas tus cuentas?

- ✔ En una fecha fija al mes
- Solo en crisis, cuando ya no alcanza
- Nunca

*¡Correcto! Fecha fija.*

**M8 U03 P1.** ¿Qué lleva cada parte de tu plan?

- Un dibujo
- Solo lo que ya hiciste en el curso
- ✔ La siguiente acción y una fecha

*¡Correcto! Acción y fecha.*

**M8 U03 P2.** ¿Cada cuándo revisas tu plan?

- Nunca
- ✔ Cada tres meses o si algo cambia
- Cada diez años, cuando cambia todo

*¡Correcto! Cada tres meses.*

**M8 U03 P3.** Tienes un plan de seguridad privado. ¿Dónde lo guardas?

- ✔ Aparte, en privado
- En el plan que compartes
- En la puerta del refrigerador

*¡Correcto! Aparte.*
