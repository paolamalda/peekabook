YOUR BUSINESS, YOUR MONEY, YOUR FUTURE · U.S.
Version 1.3 · United States (federal and California) · English · Desarrolla Talento · September 2026

Money course for Latino entrepreneurs and self-employed people in the United States: 9 modules, 43 lessons, with federal rules and California examples.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt   This file.
01_Manual/      Program manual: audience, rules, modules and lessons, characters and verified facts.
02_Content/     Full content: characters, lessons, support book, H5P and question bank (.docx and .md).
03_Guide/       Implementation guide: Moodle installation, gamification, community and channels, and maintenance (.docx and .md).
04_Moodle/      Package to install: books, H5P, glossary, question bank, badges, certificate, guides, preview and the README for Claude.

HOW IT FITS TOGETHER
--------------------
The folder comes in 3 zips because of size. Unzip them all in the same place: they merge into this folder.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Coordination read the program manual
[ ] Tax content reviewed by a tax preparer or CPA
[ ] Current facts confirmed on official sites (manual, verified facts section)
[ ] Course installed with 04_Moodle/README_INSTALL_YOUR_BUSINESS_US_EN_FOR_CLAUDE.md
[ ] Level Up, badges and certificate set up
[ ] Community created (Your Business Community folder)
[ ] Review with the student role
[ ] Maintenance calendar assigned

KEEP IN MIND
------------
- Lessons do not recommend specific banks, processors, platforms or loans; they teach how to compare.
- Federal rules with California examples; in other states, local rules are checked.
- The course gives tax orientation, but each case is reviewed with a tax preparer or CPA. It does not give immigration advice.
