# Your Business Community · U.S.: content

## Welcome to the community

**Your Business Community · U.S.** is the space for people taking *Your Business, Your Money, Your Future* in the United States. It complements the course: here you ask questions, share progress, meet other businesses, learn about tax dates and warn each other about scams.

### What you'll find

| Space | What it's for |
|---|---|
| **Announcements** | Tax dates, reminders, the monthly session and alerts. Only the team posts. |
| **Introduce yourself** | Tell us who you are, what business you have and what you want to achieve. |
| **Question forums** | Three forums by topic: money, price and cash flow; taxes and formality; credit, protection and future. |
| **Introduce your business** | One post a month to tell people what you do. No financial offers. |
| **Scam alerts** | Warn about "IRS" calls, government-imitation letters, overpayment checks or fake suppliers. |
| **Wins** | Celebrate progress: you paid yourself a salary, calculated your price, got your EIN. |
| **Monthly live session** | One topic a month and questions. |
| **Commercial referrals** | Services with a commercial agreement, separate and labeled. Optional. |

### What it is and isn't

- **It is** a place to learn, ask and support each other as entrepreneurs.
- **It isn't** personalized tax, legal or accounting advice. For your specific case, we point you to the IRS, VITA, an SBDC or a professional. We don't give immigration advice.
- **It isn't** a place to offer loans, investments or schemes to "pay less tax."

### How to recognize the team

The team **never** asks for your SSN, ITIN, EIN, passwords, account numbers, your business's real amounts or your immigration status. If someone does in the community's name, it's a scam: report it in **Scam alerts**.

### How to start

1. Read the rules (chapter 2).
2. Introduce yourself in **Introduce yourself**.
3. Note the date of the monthly session (chapter 5).
4. When you have a question, use the template in chapter 3.


## Rules and privacy

These rules protect your information and everyone else's.

### Your data

- **Never post** SSN, ITIN, EIN, passwords, account or card numbers, codes, real sales amounts, screenshots of your bank or IRS account, or your or anyone else's immigration status.
- If you want to give an example, use **made-up or rounded numbers**: "I sell about 3 thousand a month."
- Forums don't allow attachments, to avoid sharing documents by mistake.

### Respect

- No mocking or judging: everyone starts somewhere, formal or not.
- No personal arguments or posts about customers, suppliers or others by full name.

### Not allowed

1. Offering loans, investments, referral "businesses" or financial products.
2. Offering schemes to "pay less tax" or lending your tax number.
3. Recommending "notarios" or fixers who "take care of" taxes, papers or credit.
4. Posting shortened links or unofficial sites for official procedures.
5. Promoting your business outside the **Introduce your business** forum.
6. Impersonating the team, an authority or another person.

### Introduce your business

One post a month per person: what you do, where and how to reach you through your public channels. No misleading prices, no financial offers and no one's personal data.

### If something looks like a scam

Post it in **Scam alerts** without personal data, or message the team privately. If it already affected you: keep evidence, tell your bank or payment processor and report it at ReportFraud.ftc.gov (M4 U03 and M7 U03).

### What the team does

- Removes posts with personal or tax data and lets you know privately.
- Removes posts selling financial products or inviting people to invest.
- Answers general questions and refers personal cases.


## How to ask and introduce your business

A clear question gets a useful answer faster.

### Question template

**Module or topic:** (for example, M5 estimated payments)
**My business, without personal data:** (for example, "I sell food, about 3 thousand a month, mostly cash")
**What I already checked:** (for example, "I read lesson M5 U04")
**My specific question:** (one question, not five)

### What the community can and can't solve

| Can | Can't |
|---|---|
| Questions about what the course explains | Review your actual returns or invoices |
| How to calculate price, cash flow or break-even | Tell you which bank, processor or platform to use |
| Which institution to go to | Do IRS or state paperwork for you |
| How to recognize a scam | Log into your IRS account or your bank |

### "Introduce your business" template

**What you do:** (one or two lines)
**Where:** (city or "online")
**Something from the course you already apply:** (one line)
**Where to find you:** (your public social media or business page)

### Answering others

You can share your experience: say it's your experience, not a rule; don't recommend brands, preparers or suppliers by name; if you're not sure, point to the lesson or the official institution. Remember that taxes depend on each case.


## Your calendar for the year

Dates that matter to entrepreneurs in the United States. We remind you of each one in **Announcements** and on the channel.

| Month | Reminder | Lesson |
|---|---|---|
| January 15 | Fourth estimated payment for the previous year | M5 U04 |
| January | Check the new retirement limits, mileage rate and minimum wage | M1 U04, M8 U01, M9 U01 |
| January and February | Your 1099s arrive; send any 1099-NECs you owe | M5 U04 |
| April 15 | Annual return and first estimated payment | M5 U03, M5 U04 |
| April | In California, your LLC's minimum tax, if you have one | M5 U01 |
| May | Check your retirement estimate at ssa.gov | M9 U01 |
| June 15 | Second estimated payment | M5 U04 |
| July | Mid-year dashboard: sales, margin, profit | M8 U03 |
| August | Review your business insurance | M7 U02 |
| September 15 | Third estimated payment | M5 U04 |
| October | Set money aside for the slow season and year-end expenses | M3 U03 |
| November to January | Health insurance open enrollment | M7 U01 |
| December | Contribute to your retirement account and fill in your one-page plan | M9 U01, M9 U03 |

Your sales tax filing dates depend on the frequency the CDTFA or your state assigns you. Official dates can change; confirm them with the IRS and your state.


## Monthly session and challenges

### Monthly live session

One video session a month. The date and link are posted in **Announcements** and on the channel.

- Length: 60 minutes.
- One topic of the month, an exercise with made-up numbers and questions.
- We never open your IRS account, bank or platform in front of the group.
- If there's a guest (tax preparer, SBDC adviser), it's general orientation.

### Monthly challenges

Each month we post a short challenge in **Announcements**. When you complete it, share it in **Wins**, without personal data or real amounts.

| Month | Challenge |
|---|---|
| 1 | Log sales, expenses and miles 7 days in a row (M1 U04) |
| 2 | Open your business account and your tax account (M1 U02 and U03) |
| 3 | Set your salary and your tax percentage (M1 U03) |
| 4 | Figure the real cost of your main product (M2 U01) |
| 5 | Figure your break-even point and daily target (M2 U03) |
| 6 | Build your cash-flow calendar with your estimated payments (M3 U01) |
| 7 | Turn on alerts and two-step verification (M4 U02) |
| 8 | Check in CalGold or with your city which permits your business needs (M5 U02) |
| 9 | Request your IRS IP PIN (M5 U04) |
| 10 | Get a quote for business insurance (M7 U02) |
| 11 | Review your health insurance options before open enrollment (M7 U01) |
| 12 | Check your estimate at ssa.gov and fill in your one-page plan (M9) |

### Community survey

Twice a year we ask for your opinion in the **Community survey** activity. It's anonymous.


## How commercial referrals work

We want you to know exactly what is program content and what is a commercial offer.

### Where they appear

- **Only** in the **Commercial referrals** forum and the WhatsApp channel.
- **Never** in lessons, activities, self-assessments, badges, the certificate or the monthly session.

### What they always say

> **Commercial referral:** Desarrolla Talento may receive a commission if you use this service. Compare with at least one other option. Using it is voluntary and doesn't affect your access, points or certificate.

### Before using any service

- Check the institution's license with your state regulator (M6 U02).
- Compare the total cost with your real numbers (M4 U01 and M6 U03).
- Ask for the proposal in writing and compare with at least one other option.

### What you'll never see

- Merchant cash advances or payday loans.
- "No credit check" loans with an up-front fee.
- Schemes to "pay less tax."
- Pressure to decide.

