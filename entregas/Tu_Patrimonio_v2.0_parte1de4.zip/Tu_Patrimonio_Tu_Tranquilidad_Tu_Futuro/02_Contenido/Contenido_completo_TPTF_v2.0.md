# Tu Patrimonio, Tu Tranquilidad, Tu Futuro: contenido completo

Versión 2.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Perfil | Reto principal |
|---|---|---|
| **Carmen** (58) | Casada con Arturo, vive en la Ciudad de México. Su esposo siempre manejó las cuentas y las inversiones; ella lleva el gasto de la casa y una cuenta propia con ahorros | No sabe qué tienen, dónde está ni qué pasaría si Arturo faltara |
| **Lucía** (64) | Viuda desde hace un año, vive en Guadalajara. Recibe pensión de viudez del IMSS; heredó inversiones que no entiende. Sus hijos le «ayudan» con el celular | Le da miedo la tecnología y ya recibió dos llamadas «del banco» |
| **Maru** (52) | Vive en Puebla. Trabajó 12 años en una empresa antes de casarse (cotizó desde 1990) y vende por catálogo. Piensa en la Modalidad 40. Su esposo, Raúl, es maestro en escuelas públicas federales (ISSSTE) | Saber si todavía puede y si le conviene |
| **Elena** (47) | Divorciada, vive en Monterrey con dos hijos adolescentes. Trabaja en una inmobiliaria y ayuda con las cuentas de su mamá | Su seguro de gastos médicos subió 30% y no sabe si cancelarlo |

Son personajes inventados; cualquier parecido con personas reales es coincidencia.

---

## 2. Mapa de módulos

| Módulo | Lecciones | Resultado |
|---|---|---|
| M1 Tu dinero hoy: mapa y orden | 5 | Inventario de cuentas, inversiones, seguros y documentos; gasto real al mes y al año; compras inteligentes |
| M2 Conoce el sistema financiero | 4 | Mapa de instituciones y cómo verificarlas |
| M3 El celular sin miedo | 5 | Banca en el celular con candados y una persona de confianza |
| M4 Fraudes: que no te pase | 8 | Protocolo contra fraudes y plan de respuesta |
| M5 Tus cuentas y tu ahorro protegido | 7 | Cuentas revisadas, ahorro dentro del IPAB, fondo de emergencia, tarjeta de crédito bien usada, historial revisado y qué firmas por otras personas |
| M6 Tus inversiones | 6 | Qué tienes, cuánto rinde, cuánto cuesta, quién te asesora y cómo decidir sin pánico ante noticias y cambios |
| M7 Pensión y retiro | 6 | Mapa de pensiones (IMSS e ISSSTE) y cálculo de retiro |
| M8 Salud y seguros | 6 | Seguro de gastos médicos entendido y comparado; patrimonio preparado para un desastre |
| M9 Impuestos sin miedo | 3 | Saber si declaras, qué te retienen y qué deduces |
| M10 Patrimonio y familia | 6 | Testamento, beneficiarios, documentos y casa en orden |
| M11 Decidir con calma y tu plan | 3 | Reglas para decidir sin presión y plan de una página con tu compromiso |

**Insignias:** Mi mapa en orden (M1 y M2), Celular con candado (M3), Nadie me engaña (M4), Ahorro protegido (M5 y M6), Retiro claro (M7), Salud asegurada (M8 y M9), Familia en orden (M10) y Plan completo (curso).

---

## 3. Lecciones

# Parte 2. Módulo 1. Tu dinero hoy: mapa y orden

## M1 U01. ¿Qué tengo y dónde está?

**Lo que lograrás:** Hacer el inventario de tu patrimonio: cuentas, inversiones, seguros, inmuebles, pensiones y deudas, sin anotar números completos ni contraseñas.

**Para empezar:** Carmen sabe que tienen «algo invertido» y un departamento que rentan, pero todo lo maneja Arturo. Una tarde se pregunta qué haría si él se enfermara mañana. No sabe en qué banco está cada cosa ni a quién llamar. En esta lección harás el mapa que a Carmen le falta.

### Lo esencial (5 minutos)

#### Primero, el mapa

No puedes cuidar lo que no conoces. El primer paso no es invertir ni cambiar de banco: es saber qué hay y dónde está.

Tu inventario es una lista sencilla. No necesitas saldos exactos: basta con saber qué es, en qué institución está y a nombre de quién.



#### Lo que va en tu inventario

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuentas | Débito, ahorro, nómina, cuentas en dólares. | Banco y a nombre de quién. |
| Inversiones | Pagarés, Cetes, fondos, casa de bolsa. | Institución y contacto. |
| Seguros | Gastos médicos, vida, casa, auto. | Aseguradora y renovación. |
| Inmuebles y deudas | Casa, departamento, créditos, tarjetas. | Escrituras y saldos aproximados. |

#### Lo que nunca anotas

En tu inventario **no** van números completos de tarjeta, NIP, contraseñas ni códigos. Anota solo los últimos cuatro dígitos de cada cuenta. Así, si alguien encuentra la lista, no puede usarla.



#### Un caso en un minuto

Carmen se sentó con Arturo un domingo, con los estados de cuenta a la mano. Llenaron una tabla con todo: dos cuentas de banco, un fondo en una casa de bolsa, el seguro de gastos médicos y el departamento.

Descubrieron una cuenta vieja que nadie usaba y que cobraba comisión cada mes.

> **Idea clave:** un inventario sencillo te da tranquilidad y es el punto de partida de todo el curso.



#### Comprueba lo que entendiste

1. ¿Necesitas los saldos exactos para tu inventario?
*Respuesta:* No. Basta con qué es, dónde está y a nombre de quién; los saldos pueden ser aproximados.

2. ¿Anotas tu NIP o contraseñas en el inventario?
*Respuesta:* No. Solo los últimos cuatro dígitos; así la lista no sirve para robarte.


#### Para recordar

- Qué tienes, dónde está y a nombre de quién.
- Sin números completos, NIP ni contraseñas.
- Revísalo cada año.



### Profundiza (5 minutos más)

#### Tu inventario en una hoja

Llena una fila por cada cosa. Usa números redondeados.
| Tipo | Institución | A nombre de | Últimos 4 dígitos | Saldo aproximado | Contacto |
|---|---|---|---|---|---|
| Cuenta de débito | Banco A | Carmen | 1234 | 80,000 | Sucursal Del Valle |
| Fondo de inversión | Casa de bolsa B | Arturo | 5678 | 900,000 | Asesor, teléfono oficial |
| Seguro de gastos médicos | Aseguradora C | Arturo y Carmen | — | Renueva en marzo | Agente |
| Departamento | — | Ambos | — | Valor aproximado | Escrituras en la carpeta |



#### ¿A nombre de quién?

Anota el titular de cada cosa. Importa porque, si el titular falta, lo que sigue depende de los **beneficiarios** y del **testamento** (módulo 10). Una cuenta a nombre de tu pareja no es tuya, aunque el dinero sea de la familia.



#### Dónde encontrar lo que no sabes

- Estados de cuenta en papel o en el correo.
- Constancias de retenciones que llegan cada año (módulo 9).
- Pólizas y recibos de seguros.
- El reporte de crédito, que muestra créditos y tarjetas a tu nombre.

> **Antes de actuar, verifica:** si encuentras una cuenta o inversión que no reconoces, llama al número oficial de la institución. No uses el que venga en un papel viejo o en un mensaje.



#### Casos


**Caso 1. La lista de Carmen**

Carmen quiere hacer su inventario y piensa anotar el NIP de cada tarjeta «para no olvidarlo».
- *¿Qué hace?* Anota solo los últimos cuatro dígitos y guarda los NIP en su memoria, nunca en la lista.


**Caso 2. La herencia de Lucía**

Lucía heredó inversiones de su esposo y no sabe dónde están todas.
- *¿Qué hace?* Revisa estados de cuenta y constancias de retenciones del último año para identificar cada institución.


**Caso 3. La cuenta olvidada de Elena**

Elena encuentra en su inventario una cuenta que no usa desde hace años y que cobra comisión.
- *¿Qué hace?* Confirma el saldo con el banco y decide si la cancela por escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber qué hay | Dependes de otra persona | Haz tu inventario |
| Anotar NIP y contraseñas | La lista sirve para robarte | Solo últimos 4 dígitos |
| Confundir titular y familia | Sorpresas si alguien falta | Anota a nombre de quién |
| Hacerlo una vez y olvidarlo | Se queda viejo | Revísalo cada año |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué va en tu inventario? a) Tus contraseñas, para tenerlas juntas · b) Qué tienes, dónde está y a nombre de quién · c) Solo las cuentas con más dinero, porque las demás no importan
2. ¿Qué datos de una cuenta anotas? a) Los últimos cuatro dígitos · b) El número completo y el NIP · c) Ninguno, solo el banco sin detalles
3. Encuentras una inversión que no reconoces. ¿Qué haces? a) Llamas al número que viene en un papel viejo · b) Esperas a que te llamen · c) Llamas al número oficial de la institución
**Respuestas:** 1-b: es el mapa básico. 2-a: así la lista no sirve para robarte. 3-c: solo el número oficial es seguro.



#### Ponlo en práctica

Carmen tiene 80,000 en su cuenta, 900,000 en un fondo a nombre de Arturo y 250,000 en una cuenta de ambos. ¿Cuánto está a nombre de Carmen, sola o compartido?
**Respuesta:** 80,000 más 250,000: 330,000. Los 900,000 del fondo están a nombre de Arturo.



#### A tu plan

Llena la tabla de inventario con lo que sepas hoy y marca lo que te falta averiguar.



### Para saber más

- **Buró de Entidades Financieras** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** la institución de cada cuenta, para saber cómo atiende a sus clientes.
- **Reporte de Crédito Especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** el reporte sin costo una vez al año, para ver créditos y tarjetas a tu nombre.

### Palabras clave

- *Inventario:* lista de todo lo que tienes y lo que debes, con dónde está cada cosa.
- *Titular:* la persona a cuyo nombre está una cuenta o un bien.
- *Patrimonio:* lo que tienes menos lo que debes.

### Fuentes

CONDUSEF · Buró de Crédito, consultados el 29 de septiembre de 2026.

---

## M1 U02. ¿Cuánto cuesta vivir en mi casa, al mes y al año?

**Lo que lograrás:** Calcular el gasto real de tu casa, incluidos los gastos que llegan una o dos veces al año, y convertirlo en un «mes promedio».

**Para empezar:** Cada enero, Elena se sorprende: predial, seguro del auto, inscripciones y la renovación del seguro médico llegan casi juntos. Siente que el dinero «desaparece». En realidad, son gastos que ya sabía que venían. En esta lección aprenderás a verlos venir.

### Lo esencial (5 minutos)

#### Tres tipos de gasto

Los **fijos** son iguales cada mes (colegiaturas, servicio de limpieza). Los **variables** cambian (súper, gasolina). Los gastos anuales son los que más sorprenden.



#### Tu mes promedio

Elena suma lo que gasta cada mes y le agrega la parte mensual de sus gastos anuales.
- Gasto de cada mes: **45,000**
- Gastos anuales divididos entre 12: **7,000**
- Tu mes promedio: **52,000**
Si apartas 7,000 cada mes, enero deja de ser una sorpresa.


#### Tu lista de gastos anuales

Predial, agua, seguros de gastos médicos, casa y auto, tenencia o refrendo, inscripciones, mantenimiento de la casa, regalos de diciembre y vacaciones.



#### Un caso en un minuto

Elena sumó sus gastos anuales: 84,000. Entre 12, son 7,000 al mes. Abrió una cuenta aparte para eso y aparta la cantidad cada quincena.

Este enero pagó todo sin tocar su ahorro de emergencia.

> **Idea clave:** el gasto real de tu casa incluye lo que pagas una vez al año; divídelo entre 12 y apártalo cada mes.



#### Comprueba lo que entendiste

1. ¿Qué es un gasto anual?
*Respuesta:* Un pago que llega una o pocas veces al año, como el predial o un seguro.

2. ¿Cómo calculas tu mes promedio?
*Respuesta:* Sumas el gasto de cada mes más los gastos anuales divididos entre 12.


#### Para recordar

- Fijos, variables y anuales.
- Anuales entre 12, cada mes.
- Una cuenta aparte para lo anual.



### Profundiza (5 minutos más)

#### Ejemplo de gastos anuales

| Gasto | Monto al año | Al mes |
|---|---|---|
| Seguro de gastos médicos | 48,000 | 4,000 |
| Predial y agua | 9,600 | 800 |
| Seguro del auto y refrendo | 14,400 | 1,200 |
| Inscripciones y útiles | 12,000 | 1,000 |
| **Total** | **84,000** | **7,000** |



#### Cómo saber cuánto gastas

Revisa tres meses de estados de cuenta de tus tarjetas y cuentas, y agrupa los gastos. Si pagas mucho en efectivo, anota durante un mes lo que sale de tu cartera. No se trata de juzgar cada compra, sino de saber a dónde va el dinero.



#### Si el gasto es mayor que el ingreso

Si tu mes promedio es mayor que lo que entra, empieza por los gastos anuales y por los servicios que ya no usas. Evita cubrir la diferencia con tarjeta de crédito: es una deuda que crece.

> **Antes de actuar, verifica:** antes de cancelar un seguro para ahorrar, revisa el módulo 8; algunos seguros no se pueden recuperar en las mismas condiciones.



#### Casos


**Caso 1. El enero de Elena**

Elena paga en enero el seguro del auto, el predial y las inscripciones, y siempre usa su ahorro.
- *¿Qué hace?* Suma sus gastos anuales, los divide entre 12 y aparta esa cantidad cada mes en una cuenta aparte.


**Caso 2. El gasto de Carmen**

Carmen no sabe cuánto gasta la casa; Arturo dice que «unos 40 mil».
- *¿Qué hace?* Revisa tres meses de estados de cuenta y agrupa los gastos para saber la cifra real.


**Caso 3. La diferencia de Maru**

El mes promedio de Maru es 3,000 mayor que su ingreso y lo cubre con la tarjeta.
- *¿Qué hace?* Revisa sus gastos anuales y los servicios que no usa, y deja de cubrir la diferencia con crédito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Olvidar los gastos anuales | Enero te sorprende | Divídelos entre 12 |
| Calcular «de memoria» | La cifra no es real | Usa estados de cuenta |
| Cubrir la diferencia con tarjeta | La deuda crece | Ajusta gastos |
| Mezclar lo anual con el gasto diario | Te lo gastas | Cuenta aparte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es un gasto anual? a) El súper de cada semana · b) La luz de cada bimestre, que casi no cambia · c) El seguro de gastos médicos
2. Tus gastos anuales suman 60,000. ¿Cuánto apartas al mes? a) 5,000 · b) 6,000 · c) 60,000, todo en enero
3. Tu mes promedio es mayor que tu ingreso. ¿Qué haces primero? a) Lo cubres con la tarjeta de crédito · b) Revisas gastos anuales y servicios que no usas · c) Cancelas tu seguro médico para ajustar el gasto de inmediato
**Respuestas:** 1-c: llega una vez al año. 2-a: 60,000 entre 12 son 5,000. 3-b: ajustar es mejor que endeudarte.



#### Ponlo en práctica

Tus gastos de cada mes son 38,000 y tus gastos anuales suman 54,000. ¿Cuál es tu mes promedio?
**Respuesta:** 54,000 entre 12 son 4,500. Tu mes promedio es 38,000 más 4,500: 42,500.



#### A tu plan

Haz tu lista de gastos anuales, súmalos y divídelos entre 12. Esa es la cantidad que apartarás cada mes.



### Para saber más

- **Presupuesto personal** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto» y sus calculadoras, para ordenar tus gastos.

### Palabras clave

- *Gastos anuales:* pagos que llegan una o pocas veces al año, como predial, seguros o tenencia.
- *Mes promedio:* lo que gasta tu casa cada mes más la parte mensual de los gastos anuales.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U03. Mi dinero, nuestro dinero

**Lo que lograrás:** Hablar de dinero en pareja y en familia, conocer el régimen de tu matrimonio y tener una cuenta propia para tu tranquilidad.

**Para empezar:** Carmen nunca ha preguntado cuánto ganan ni cuánto tienen: «eso lo ve Arturo». No es desconfianza; así se acostumbraron. Pero si algo cambiara, ella tendría que empezar de cero. En esta lección verás cómo abrir la conversación sin pelear.

### Lo esencial (5 minutos)

#### Hablar de dinero es cuidarse

Conocer el dinero de la familia no es desconfiar: es cuidarse. Si solo una persona sabe dónde está todo, la familia depende de ella. Si falta, se enferma o se separan, la otra persona queda sin información.



#### Tres acuerdos básicos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transparencia | Las dos personas saben qué hay y dónde. | Sin sorpresas. |
| Cuenta propia | Cada quien tiene una cuenta a su nombre. | Tu respaldo. |
| Cita mensual | Revisan juntos gastos y metas. | Menos discusiones. |

#### El régimen de tu matrimonio

Si estás casada por lo civil, tu matrimonio tiene un régimen patrimonial. En la **sociedad conyugal**, lo adquirido durante el matrimonio es de las dos personas. En la **separación de bienes**, cada quien es dueño de lo suyo. Lo dice tu acta de matrimonio.



#### Un caso en un minuto

Carmen le propuso a Arturo una «cita de dinero» al mes. Empezaron con el inventario del módulo 1. Arturo le mostró sus cuentas y ella abrió una cuenta propia para su ahorro.

> **Idea clave:** hablar de dinero en familia no es desconfianza; es tranquilidad para las dos personas.



#### Comprueba lo que entendiste

1. ¿Dónde dice cuál es el régimen de tu matrimonio?
*Respuesta:* En tu acta de matrimonio.

2. ¿Para qué sirve una cuenta propia?
*Respuesta:* Es tu respaldo: tienes acceso a dinero a tu nombre si algo cambia.


#### Para recordar

- Las dos personas saben qué hay.
- Cuenta propia a tu nombre.
- Revisa tu acta de matrimonio.



### Profundiza (5 minutos más)

#### Cómo empezar la conversación

- Elige un momento tranquilo, no en medio de un problema.
- Empieza por una meta común: «quiero que estemos preparados si alguno falta».
- Propón hacer juntos el inventario.
- Acuerden una cita mensual de 30 minutos.



#### Los dos regímenes

| | Sociedad conyugal | Separación de bienes |
|---|---|---|
| Lo que compran durante el matrimonio | Es de las dos personas | Es de quien lo compró |
| Si se separan | Se reparte | Cada quien conserva lo suyo |
| Qué revisar | Acta de matrimonio y capitulaciones | Acta de matrimonio y capitulaciones |

> **Antes de actuar, verifica:** las reglas cambian según el estado y según lo que firmaron al casarse. Para tu caso, consulta a una notaría o a un abogado.



#### Si la conversación no es posible

Puede ser control económico. Por ejemplo, si tu pareja se niega siempre a hablar de dinero, te quita el acceso a tus cuentas o controla lo que gastas. En el módulo 11 verás cómo reconocerlo y dónde pedir apoyo.



#### Casos


**Caso 1. La cita de Carmen**

Carmen quiere saber qué tienen, pero teme que Arturo se moleste.
- *¿Qué hace?* Propone una cita tranquila con una meta común: estar preparados si alguno falta.


**Caso 2. La cuenta de Maru**

Maru deposita lo que gana por catálogo en la cuenta de su esposo.
- *¿Qué hace?* Abre una cuenta a su nombre para tener su propio respaldo.


**Caso 3. El acta de Elena**

Elena no sabe qué régimen tuvo su matrimonio al divorciarse.
- *¿Qué hace?* Revisa su acta de matrimonio y, si hay dudas, consulta a una notaría o a un abogado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar todo en una sola persona | Dependencia total | Transparencia |
| No tener nada a tu nombre | Sin respaldo | Cuenta propia |
| Hablar solo en crisis | Discusiones | Cita mensual |
| Suponer el régimen | Sorpresas | Revisa tu acta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Maru y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde consultas el régimen de tu matrimonio? a) En tu estado de cuenta · b) En la escritura de la casa · c) En tu acta de matrimonio
2. ¿Qué es la sociedad conyugal? a) Lo adquirido en el matrimonio es de las dos personas · b) Cada quien conserva lo que compró, aunque sea durante el matrimonio · c) Una cuenta de banco compartida por la pareja
3. ¿Cuál es un buen primer paso para hablar de dinero? a) Hacer juntos el inventario · b) Pedir todas las contraseñas de golpe · c) Esperar a que haya un problema
**Respuestas:** 1-c: el acta lo indica. 2-a: se comparte lo adquirido. 3-a: es concreto y sin juicios.



#### Ponlo en práctica

Durante su matrimonio en sociedad conyugal, Carmen y Arturo compraron un departamento de 2,400,000. ¿Qué parte corresponde a cada quien?
**Respuesta:** En sociedad conyugal, lo adquirido es de las dos personas: 1,200,000 cada quien, salvo acuerdos distintos en sus capitulaciones.



#### A tu plan

Busca tu acta de matrimonio, anota tu régimen y propón a tu familia una cita mensual de dinero.



### Para saber más

- **Mes del Testamento y trámites notariales** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «notarías» de tu estado, para consultar dudas sobre tu régimen.
- **Guías y herramientas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «finanzas en pareja», con ideas para la conversación.

### Palabras clave

- *Régimen patrimonial:* la regla que define de quién son los bienes en el matrimonio: sociedad conyugal o separación de bienes.
- *Capitulaciones:* el acuerdo que la pareja firma al casarse sobre sus bienes.

### Fuentes

CONDUSEF · Código Civil Federal, consultados el 29 de septiembre de 2026.

---

## M1 U04. Tu carpeta de documentos

**Lo que lograrás:** Reunir en una carpeta los documentos que tu familia necesitaría en una emergencia, guardarlos seguros y decir a una persona de confianza dónde están.

**Para empezar:** Cuando murió su esposo, Lucía pasó semanas buscando pólizas, escrituras y contratos. Algunos aparecieron en cajones, otros nunca. Hoy quiere evitarles eso a sus hijos. En esta lección armarás tu carpeta.

### Lo esencial (5 minutos)

#### Una carpeta, un lugar

Tu carpeta de documentos reúne lo que tu familia necesitaría si tú no pudieras decidir. Debe estar en un solo lugar y alguien de confianza debe saber dónde.



#### Qué va en tu carpeta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Identidad | Copia de INE, CURP, actas de nacimiento y de matrimonio. | Para cualquier trámite. |
| Bienes | Escrituras, facturas del auto. | Prueban que es tuyo. |
| Seguros y pensión | Pólizas, AFORE, resoluciones de pensión. | Para cobrar. |
| Testamento y beneficiarios | Copia del testamento y designaciones. | Para que se cumpla tu voluntad. |

#### Protegida, no escondida

Guarda los originales en un lugar seguro de tu casa o en una caja de seguridad. Si haces copias digitales, guárdalas con contraseña. Nunca guardes en la carpeta tu NIP ni tus contraseñas.



#### Un caso en un minuto

Lucía compró una carpeta con separadores: identidad, casa, seguros, pensión y testamento. Le dijo a su hija mayor dónde está. En una hoja al frente anotó a quién llamar en cada caso: notaría, aseguradora y banco.

> **Idea clave:** una carpeta ordenada y una persona que sabe dónde está ahorran semanas de angustia a tu familia.



#### Comprueba lo que entendiste

1. ¿Guardas tus contraseñas en la carpeta?
*Respuesta:* No. La carpeta tiene documentos; las contraseñas no se escriben.

2. ¿Quién debe saber dónde está la carpeta?
*Respuesta:* Al menos una persona de confianza.


#### Para recordar

- Un solo lugar.
- Una persona de confianza sabe dónde.
- Sin contraseñas ni NIP.



### Profundiza (5 minutos más)

#### Lista de revisión

| Documento | Lo tengo | Dónde está el original |
|---|---|---|
| Actas de nacimiento y matrimonio | | |
| INE y CURP (copia) | | |
| Escrituras | | |
| Pólizas de seguro | | |
| Estado de cuenta de la AFORE y resolución de pensión | | |
| Testamento (copia) | | |
| Contactos: notaría, agente, banco | | |



#### Copias digitales

Si escaneas tus documentos, guárdalos en una carpeta protegida con contraseña o en la nube con verificación en dos pasos. No mandes copias de tu INE por WhatsApp a quien no conoces: es la materia prima del robo de identidad (módulo 4).



#### Mantenla al día

Revisa la carpeta una vez al año, por ejemplo en septiembre, el Mes del Testamento. Cambia las pólizas vencidas y actualiza contactos.

> **Antes de actuar, verifica:** si vas a entregar copias de tu INE para un trámite, escribe sobre la copia para qué es y la fecha. Así es más difícil que la usen para otra cosa.



#### Casos


**Caso 1. La carpeta de Lucía**

Lucía tiene sus documentos en tres cajones distintos y nadie sabe dónde.
- *¿Qué hace?* Los reúne en una carpeta con separadores y le dice a su hija dónde está.


**Caso 2. El escaneo de Carmen**

Carmen quiere escanear su carpeta y mandarla por WhatsApp a sus hijos «por si acaso».
- *¿Qué hace?* Guarda las copias en una carpeta protegida con contraseña y solo comparte dónde está.


**Caso 3. La copia de Maru**

Le piden a Maru una copia de su INE para registrarse como vendedora por catálogo.
- *¿Qué hace?* Escribe sobre la copia para qué es y la fecha antes de entregarla.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Documentos dispersos | Tu familia no los encuentra | Una carpeta |
| Contraseñas en la carpeta | Riesgo de robo | Nunca las escribas |
| Copias de INE por chat | Robo de identidad | Comparte con cuidado |
| No actualizarla | Pólizas vencidas | Revisión anual |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué NO va en tu carpeta? a) Tu NIP y tus contraseñas · b) La copia de tu testamento · c) Las pólizas de seguro vigentes
2. ¿Cuándo conviene revisar la carpeta? a) Solo cuando hay una emergencia · b) Una vez al año · c) Nunca, si ya está hecha
3. ¿Cómo entregas una copia de tu INE para un trámite? a) Sin anotar nada, como te la pidan · b) Por WhatsApp a quien la pida, para que el trámite sea rápido · c) Con una nota de para qué es y la fecha
**Respuestas:** 1-a: nunca se escriben. 2-b: así se mantiene al día. 3-c: dificulta que la usen para otra cosa.



#### Ponlo en práctica

Llena la lista de revisión. Si te faltan tres documentos, ¿cuál buscas primero?
**Respuesta:** Por ejemplo: primero las pólizas y la resolución de pensión, porque tu familia las necesita para cobrar; después las escrituras y el testamento.



#### A tu plan

Arma tu carpeta con los separadores de la lista y dile a una persona de confianza dónde está.



### Para saber más

- **Mes del Testamento** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento», para revisar tu carpeta cada septiembre.
- **Robo de identidad** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «robo de identidad», para cuidar tus copias.

### Palabras clave

- *Carpeta de documentos:* el lugar donde guardas los papeles importantes de tu patrimonio y tu familia.
- *Caja de seguridad:* espacio que renta un banco para guardar objetos y documentos.

### Fuentes

CONDUSEF · Gobierno de México, consultados el 29 de septiembre de 2026.

---

## M1 U05. Compra inteligente: el súper, las ofertas y los pagos a plazos

**Lo que lograrás:** Comparar por precio por unidad, reconocer las técnicas de venta y calcular el costo total de compras a plazos y suscripciones antes de decidir.

**Para empezar:** Elena compró una lavadora «a 18 meses sin intereses» porque la oferta terminaba ese día. Ahora suma ese pago a otros tres de la tienda departamental y a las plataformas de sus hijos. En esta lección aprenderás a ver el precio completo.

### Lo esencial (5 minutos)

#### Compara por unidad

En el súper, divide el precio entre los gramos, litros o piezas. El paquete grande o «2 por 1» no siempre sale más barato.



#### Técnicas que te hacen gastar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Solo hoy» | Te quitan tiempo para pensar. | Espera un día. |
| Pagos chiquitos | Parecen poco; suman mucho. | Suma el total. |
| Suscripciones | Se cobran solas cada mes. | Revísalas. |
| Lista y presupuesto | Compras lo que planeaste. | Control. |

#### Pagos a plazos

Antes de comprar a plazos, suma todos tus pagos que ya corren. Un pago nuevo es dinero comprometido por muchos meses, aunque sea «sin intereses».



#### Un caso en un minuto

Elena hizo una lista de todos sus pagos a plazos: 4,300 al mes. Decidió no comprar nada nuevo a plazos hasta terminar dos. Canceló una plataforma que nadie veía y compra el súper con lista.

> **Idea clave:** compra con lista y compara por unidad. Antes de un pago a plazos nuevo, suma todos los que ya tienes. Ante el «solo hoy», espera un día.



#### Comprueba lo que entendiste

1. ¿Cómo comparas dos presentaciones?
*Respuesta:* Por el precio por unidad.

2. ¿Qué revisas antes de comprar a plazos?
*Respuesta:* Todos los pagos que ya tienes cada mes.


#### Para recordar

- Lista y precio por unidad.
- Suma tus pagos a plazos.
- Espera un día.



### Profundiza (5 minutos más)

#### Lo que ya pagaste no decide por ti

Si ya pagaste la inscripción de un gimnasio que no usas, seguir pagando no recupera ese dinero. Decide por lo que te conviene de hoy en adelante.



#### Lo que cuesta después

Un auto, una mascota o un aparato traen gastos después: mantenimiento, seguro, refacciones. Súmalos antes de comprar.



#### Tus pagos que se repiten

| Pago | Al mes | Meses que faltan | Total que falta |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

> **Antes de actuar, verifica:** el precio de contado, el número de pagos y el total. Puedes comparar en «Quién es quién en los precios» de Profeco.



#### Casos


**Caso 1. La lavadora de Elena**

Elena ve una lavadora a 18 meses sin intereses «solo hoy».
- *¿Qué hace?* Suma sus pagos a plazos, espera un día y decide con su presupuesto.


**Caso 2. El súper de Lucía**

Lucía cree que el «2 por 1» siempre conviene.
- *¿Qué hace?* Calcula el precio por unidad y compra solo si lo usará.


**Caso 3. El gimnasio de Carmen**

Carmen pagó un año de gimnasio y no va, pero quiere renovar «para no perder lo pagado».
- *¿Qué hace?* No renueva: lo ya pagado no se recupera.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comprar sin lista | Gastas de más | Lista |
| Ver solo el pago mensual | Te comprometes meses | Suma el total |
| Seguir por lo ya pagado | Más gasto | Decide desde hoy |
| Suscripciones olvidadas | Fugas | Revisa cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Lucía y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un aceite de 1 litro cuesta 48 y uno de 3 litros cuesta 150. ¿Cuál sale más barato por litro? a) El de 3 litros · b) El de 1 litro · c) Cuestan igual
2. ¿Qué haces antes de una compra nueva a plazos? a) Sumas los pagos que ya tienes · b) Compras si es sin intereses · c) Pides otra tarjeta
3. Ya pagaste algo que no usas. ¿Qué haces? a) Sigues pagando para no perder lo pagado · b) Pagas otro año más · c) Decides por lo que te conviene de hoy en adelante
**Respuestas:** 1-b: 48 contra 50 por litro. 2-a: tu presupuesto tiene límite. 3-c: lo pagado no se recupera.



#### Ponlo en práctica

Tienes tres pagos de 900, 1,200 y 650 al mes. ¿Cuánto tienes comprometido?
**Respuesta:** 2,750 pesos al mes.



#### A tu plan

Haz tu tabla de pagos que se repiten y no agregues uno nuevo hasta terminar uno.



### Para saber más

- **Quién es quién en los precios** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** compara precios de productos básicos en tu ciudad.
- **Meses sin intereses** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «meses sin intereses».

### Palabras clave

- *Precio por unidad:* precio dividido entre la cantidad.
- *Suscripción:* pago que se cobra solo cada mes hasta que lo cancelas.

### Fuentes

Profeco · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 3. Módulo 2. Conoce el sistema financiero

## M2 U01. ¿Quién es quién en el sistema financiero?

**Lo que lograrás:** Distinguir a las autoridades que ponen las reglas y vigilan, de las instituciones que te dan servicios, y saber a cuál acudir en cada caso.

**Para empezar:** A Lucía le llamaron «de la CONDUSEF» para ofrecerle recuperar un dinero perdido a cambio de un depósito. Ella no sabía qué hace la CONDUSEF ni si llama a la gente. En esta lección conocerás quién es quién para que nadie te confunda.

### Lo esencial (5 minutos)

#### Dos grupos

En el sistema financiero hay dos grupos. Las **autoridades** ponen reglas, vigilan y defienden a los usuarios. Las **instituciones** te dan servicios: cuentas, créditos, seguros, inversiones.



#### Las autoridades que más te importan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Banxico | Cuida el valor del peso y los pagos (SPEI). | No te abre cuentas. |
| CNBV | Autoriza y vigila bancos y casas de bolsa. | Tiene el padrón de entidades. |
| CONDUSEF | Defiende a los usuarios y recibe quejas. | No vende nada ni pide depósitos. |
| CNSF y CONSAR | Vigilan aseguradoras y AFORE. | Revisa que estén autorizadas. |

#### Las autoridades no te venden

Ninguna autoridad te llama para venderte algo, pedirte un depósito o «liberar» un dinero. Si alguien dice ser de la CONDUSEF, la CNBV o el SAT y te pide dinero o datos, es fraude.



#### Un caso en un minuto

Lucía colgó y buscó el teléfono de la CONDUSEF en su sitio oficial. Le confirmaron que no hacen esas llamadas y que era un intento de fraude.

> **Idea clave:** las autoridades vigilan y defienden; nunca te piden dinero para ayudarte.



#### Comprueba lo que entendiste

1. ¿La CONDUSEF te pide depósitos para recuperar dinero?
*Respuesta:* No. Es sin costo y nunca pide depósitos; si alguien lo hace en su nombre, es fraude.

2. ¿Quién tiene el padrón de bancos y casas de bolsa autorizados?
*Respuesta:* La CNBV.


#### Para recordar

- Autoridades: reglas, vigilancia y defensa.
- Instituciones: servicios.
- Una autoridad nunca te pide dinero.



### Profundiza (5 minutos más)

#### Autoridades y lo que hacen por ti

| Autoridad | Qué hace | Cuándo acudes |
|---|---|---|
| Banxico | Política monetaria, sistema de pagos SPEI | Consultar el comprobante de una transferencia (CEP) |
| SHCP y SAT | Hacienda e impuestos | Declaraciones y constancias |
| CNBV | Autoriza y supervisa bancos, casas de bolsa y asesores | Verificar si una institución está autorizada |
| CNSF | Supervisa aseguradoras | Verificar una aseguradora |
| CONSAR | Supervisa AFORE | Dudas sobre tu AFORE |
| CONDUSEF | Orienta y defiende; recibe quejas | Reclamar a una institución |
| IPAB | Protege depósitos bancarios | Saber hasta cuánto está protegido tu ahorro |



#### Las instituciones

Bancos, casas de bolsa, operadoras de fondos, aseguradoras y AFORE son las más comunes para ti. En el módulo 2 U02 verás qué hace cada una. En el curso no se recomiendan SOFIPO, SOCAP ni SOFOM.



#### Cómo comunicarte con una autoridad

Siempre por el teléfono o el sitio que tú buscas, nunca por un número que te den en una llamada o un mensaje. Los sitios oficiales del gobierno terminan en **gob.mx**.

> **Antes de actuar, verifica:** si una llamada o mensaje usa el nombre de una autoridad, cuelga y comunícate tú por el canal oficial.



#### Casos


**Caso 1. La llamada de Lucía**

A Lucía le llama alguien «de la CONDUSEF» para recuperar dinero a cambio de un depósito.
- *¿Qué hace?* Cuelga y llama ella al número oficial de la CONDUSEF para confirmar.


**Caso 2. El fondo de Carmen**

Carmen quiere saber si la casa de bolsa donde está su fondo está autorizada.
- *¿Qué hace?* Busca la institución en el padrón de entidades supervisadas de la CNBV.


**Caso 3. La queja de Elena**

El banco le cobró a Elena una comisión que no reconoce y no le resuelven.
- *¿Qué hace?* Reclama por escrito en el banco y, si no le resuelven, acude a la CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer a quien dice ser autoridad | Fraude | Cuelga y verifica |
| Pagar por «recuperar» dinero | Pierdes más | Las autoridades no cobran |
| Buscar el teléfono en el mensaje | Te lleva al fraude | Usa gob.mx |
| No saber a quién acudir | Te rindes | Usa la tabla |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué hace la CONDUSEF? a) Vende seguros y créditos a mejor precio que los bancos · b) Orienta y defiende a los usuarios · c) Presta dinero en emergencias
2. ¿Dónde verificas si un banco está autorizado? a) En el padrón de la CNBV · b) En su página de redes sociales · c) Preguntando al asesor que te llamó
3. Alguien «del SAT» te pide un depósito para evitar una multa. ¿Qué es? a) Un trámite normal si es urgente · b) Una promoción del gobierno · c) Un fraude: las autoridades no piden depósitos así
**Respuestas:** 1-b: no tiene costo y defiende a los usuarios. 2-a: la CNBV tiene el padrón. 3-c: cuelga y verifica en el canal oficial.



#### Ponlo en práctica

Relaciona: a) quiero saber si mi aseguradora está autorizada; b) quiero reclamar un cargo; c) quiero saber cuánto protege mi ahorro.
**Respuesta:** a) CNSF; b) primero el banco y después la CONDUSEF; c) IPAB.



#### A tu plan

Guarda en tu carpeta los sitios oficiales de CONDUSEF, CNBV e IPAB para buscar ahí los teléfonos cuando los necesites.



### Para saber más

- **Padrón de Entidades Supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «padrón de entidades supervisadas», para verificar bancos y casas de bolsa.
- **CONDUSEF** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** teléfonos oficiales y «fraudes», para saber cómo te contactan de verdad.

### Palabras clave

- *Sistema financiero:* el conjunto de autoridades e instituciones que manejan el ahorro, el crédito, los seguros, las inversiones y los pagos.
- *Autoridad financiera:* organismo del gobierno que pone reglas, vigila o defiende a los usuarios.

### Fuentes

CNBV · CONDUSEF · Banxico, consultados el 29 de septiembre de 2026.

---

## M2 U02. Bancos, casas de bolsa, aseguradoras y AFORE: ¿qué hace cada una?

**Lo que lograrás:** Identificar qué hace cada tipo de institución, qué cuida de tu dinero y quién la vigila, para no confundir un depósito con una inversión.

**Para empezar:** Carmen cree que su fondo en la casa de bolsa «es como una cuenta de banco» y que está protegido igual. No lo está. En esta lección verás por qué importa saber qué tipo de institución tiene tu dinero.

### Lo esencial (5 minutos)

#### Cada institución hace algo distinto

El nombre del lugar donde está tu dinero dice mucho de lo que puedes esperar. Te dice si está protegido, si puede subir o bajar y cuándo lo puedes sacar.



#### Las cuatro que más usarás

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Banco | Cuentas, pagarés, tarjetas, créditos. | Depósitos protegidos por el IPAB. |
| Casa de bolsa y operadora de fondos | Inversiones en bonos, fondos y acciones. | No las protege el IPAB; pueden subir o bajar. |
| Aseguradora | Seguros de gastos médicos, vida, casa y auto. | Te protege de un riesgo. |
| AFORE | Tu ahorro para el retiro. | Lo vigila la CONSAR. |

#### Depósito no es inversión

Un depósito en un banco está protegido hasta cierto límite (módulo 5). Una inversión en un fondo o en acciones puede subir o bajar de valor.



#### Un caso en un minuto

Carmen revisó su estado de cuenta: su dinero está en un fondo de deuda en una casa de bolsa. Entendió que su valor cambia día a día y que no lo cubre el IPAB, aunque la institución esté autorizada y vigilada.

> **Idea clave:** saber qué tipo de institución tiene tu dinero te dice qué protección tiene y qué riesgos corre.



#### Comprueba lo que entendiste

1. ¿El IPAB protege un fondo de inversión en una casa de bolsa?
*Respuesta:* No. Protege depósitos bancarios; un fondo puede subir o bajar.

2. ¿Quién vigila a las AFORE?
*Respuesta:* La CONSAR.


#### Para recordar

- Banco: depósitos protegidos.
- Casa de bolsa: inversiones que suben y bajan.
- Aseguradora y AFORE: protección y retiro.



### Profundiza (5 minutos más)

#### Cada institución en una tabla

| Institución | Qué te ofrece | Quién la vigila | ¿La protege el IPAB? |
|---|---|---|---|
| Banco | Cuentas, pagarés, tarjetas | CNBV | Sí, los depósitos |
| Casa de bolsa | Bonos, acciones, fondos | CNBV | No |
| Operadora de fondos | Fondos de inversión | CNBV | No |
| Aseguradora | Seguros | CNSF | No aplica |
| AFORE | Ahorro para el retiro | CONSAR | No aplica |



#### Bancos digitales y apps

Hay bancos que solo operan por app. Si tienen licencia de banco, sus depósitos están protegidos por el IPAB como los de cualquier banco. Una app que no es banco puede ofrecer algo que parece una cuenta, pero no tiene esa protección. Verifica el tipo de entidad en el padrón de la CNBV (M2 U03).



#### «Me lo ofreció mi banco»

En la sucursal te pueden ofrecer productos de otras empresas del mismo grupo: un fondo de la operadora o un seguro de la aseguradora. Pregunta siempre **quién** es la institución que te da el producto; la protección depende de eso.

> **Antes de actuar, verifica:** en el contrato y en el estado de cuenta, el nombre legal de la institución que tiene tu dinero.



#### Casos


**Caso 1. El fondo de Carmen**

Carmen cree que su fondo en la casa de bolsa está protegido por el IPAB.
- *¿Qué hace?* Revisa su estado de cuenta y entiende que es una inversión que puede subir o bajar, sin protección del IPAB.


**Caso 2. El ofrecimiento a Lucía**

En la sucursal le ofrecen a Lucía «una cuenta que da más» y resulta ser un fondo de inversión.
- *¿Qué hace?* Pregunta quién es la institución, cómo funciona y qué riesgo tiene antes de firmar.


**Caso 3. La app de Elena**

Elena usa una app que promete «rendimientos diarios» y no sabe si es banco.
- *¿Qué hace?* Busca el nombre legal en el padrón de la CNBV para saber qué tipo de entidad es.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que todo es una cuenta | Riesgos que no ves | Pregunta el tipo de institución |
| Confundir el grupo con la institución | Protección distinta | Revisa el nombre legal |
| Suponer que una app es banco | Sin protección | Verifica en la CNBV |
| Firmar sin preguntar el riesgo | Sorpresas | Pregunta si puede bajar |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué protege el IPAB? a) Los fondos de inversión de una casa de bolsa · b) Los depósitos en bancos · c) Todas las inversiones del país
2. ¿Qué es una inversión? a) Dinero que puede subir o bajar de valor · b) Dinero que siempre te devuelven igual · c) Un seguro de vida con ahorro garantizado
3. En la sucursal te ofrecen un producto. ¿Qué preguntas primero? a) Si hay regalo por contratar · b) Quién es la institución que lo da · c) Cuántas personas ya lo compraron
**Respuestas:** 1-b: protege depósitos bancarios. 2-a: puede ganar o perder. 3-b: la protección depende de la institución.



#### Ponlo en práctica

Clasifica: pagaré bancario, fondo de deuda, seguro de gastos médicos, cuenta de ahorro. ¿Cuáles protege el IPAB?
**Respuesta:** El pagaré bancario y la cuenta de ahorro, porque son depósitos en un banco. El fondo no lo protege; el seguro es otro tipo de producto.



#### A tu plan

En tu inventario, agrega una columna con el tipo de institución de cada cosa: banco, casa de bolsa, aseguradora o AFORE.



### Para saber más

- **Padrón de Entidades Supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** el tipo de entidad de cada institución.
- **Seguro de depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** qué productos protege.

### Palabras clave

- *Depósito:* dinero que guardas en un banco y que te devuelven completo, con o sin intereses.
- *Inversión:* dinero que pones a trabajar para que crezca, con la posibilidad de ganar o perder.
- *Nombre legal:* el nombre oficial de la institución, que aparece en el contrato.

### Fuentes

CNBV · IPAB · CONSAR · CNSF, consultados el 29 de septiembre de 2026.

---

## M2 U03. Verifica antes de confiar

**Lo que lograrás:** Verificar cualquier institución o asesor antes de darle tu dinero o tus datos, usando el SIPRES, el padrón de la CNBV y el Buró de Entidades Financieras.

**Para empezar:** A Maru le ofrecen invertir sus ahorros en «una financiera nueva que paga el 2% mensual». Tiene página web, oficinas y folletos bonitos. ¿Cómo sabe si existe de verdad y si está autorizada? En esta lección aprenderás a verificar en cinco minutos.

### Lo esencial (5 minutos)

#### Tres consultas sin costo

Antes de confiar tu dinero, verifica tres cosas. Que la institución **existe**. Que está **autorizada** para lo que te ofrece. Y **cómo trata** a sus clientes.



#### Dónde verificar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| SIPRES (CONDUSEF) | Si está registrada como entidad financiera. | Nombre legal y tipo. |
| Padrón de la CNBV | Si está autorizada y supervisada. | Advertencias de entidades irregulares. |
| Buró de Entidades Financieras | Quejas, multas y cómo resuelve. | Compara instituciones. |

#### Señales de alerta

Rendimientos altos y «garantizados», prisa por firmar, pagos a cuentas personales y nombres parecidos a los de instituciones conocidas. Un folleto bonito no prueba nada.



#### Un caso en un minuto

Maru buscó el nombre en el SIPRES: no aparecía. En la CNBV encontró una advertencia sobre una empresa con un nombre casi igual. No invirtió.

> **Idea clave:** cinco minutos de verificación te pueden ahorrar años de ahorro.



#### Comprueba lo que entendiste

1. ¿Qué revisas en el Buró de Entidades Financieras?
*Respuesta:* Quejas, multas y cómo resuelve la institución.

2. ¿Un rendimiento «garantizado» del 2% mensual es buena señal?
*Respuesta:* No. Es una señal de alerta de fraude.


#### Para recordar

- Existe, está autorizada y trata bien.
- SIPRES, CNBV y Buró de Entidades.
- Rendimiento garantizado alto = alerta.



### Profundiza (5 minutos más)

#### Tu verificación en cinco pasos

| Paso | Qué haces | Qué buscas |
|---|---|---|
| 1 | Pide el nombre legal completo | El que viene en el contrato |
| 2 | Búscalo en el SIPRES | Que exista y su tipo de entidad |
| 3 | Búscalo en el padrón de la CNBV o la CNSF | Que esté autorizada para ese producto |
| 4 | Revisa las advertencias de la CNBV | Que no haya alertas |
| 5 | Consulta el Buró de Entidades Financieras | Quejas y sanciones |



#### Nombres parecidos

Los fraudes usan nombres casi iguales a los de instituciones reales, con una letra de más o un «Financiera» agregado. Compara el nombre letra por letra y el sitio web: el oficial es el que aparece en el padrón, no el del folleto.



#### Personas, no solo empresas

Si te ofrece la inversión una persona, pregunta para qué institución trabaja y confirma con la institución, por su teléfono oficial, que esa persona existe. Los asesores en inversiones deben estar en el registro de la CNBV (módulo 6).

> **Antes de actuar, verifica:** nunca deposites a la cuenta personal de un asesor o promotor. El dinero va a una cuenta a nombre de la institución.



#### Casos


**Caso 1. La financiera de Maru**

A Maru le ofrecen 2% mensual «garantizado» en una financiera nueva con oficinas elegantes.
- *¿Qué hace?* Busca el nombre legal en el SIPRES y en el padrón de la CNBV, y revisa las advertencias.


**Caso 2. El promotor de Lucía**

Un promotor le pide a Lucía depositar a su cuenta personal «para agilizar».
- *¿Qué hace?* No deposita; el dinero solo va a una cuenta a nombre de la institución.


**Caso 3. El nombre de Carmen**

Carmen recibe un folleto de «Banco Nacional Mexicano Plus».
- *¿Qué hace?* Compara el nombre y el sitio con el padrón oficial antes de creer que es su banco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confiar en la apariencia | Folletos y oficinas no prueban nada | Verifica en registros |
| Depositar a personas | Tu dinero desaparece | Solo a la institución |
| No revisar advertencias | Entidades irregulares | CNBV |
| Creer en rendimientos garantizados | Señal de fraude | Desconfía |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Lucía y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué revisas primero de una institución? a) Si tiene oficinas bonitas · b) Si alguien conocido ya invirtió · c) Si existe y está autorizada
2. Un promotor te pide depositar a su cuenta personal. ¿Qué haces? a) No depositas: solo a cuenta de la institución · b) Depositas si te da un recibo firmado con el logotipo de la institución · c) Depositas la mitad para probar
3. ¿Dónde ves quejas y multas de una institución? a) En sus redes sociales · b) En el Buró de Entidades Financieras · c) En los comentarios de su página
**Respuestas:** 1-c: primero que exista y esté autorizada. 2-a: nunca a personas. 3-b: es la herramienta oficial de CONDUSEF.



#### Ponlo en práctica

Te ofrecen 2% mensual. ¿Cuánto sería al año, sin contar interés sobre interés, y por qué es una alerta?
**Respuesta:** 2% por 12 meses es 24% al año. Es mucho más de lo que pagan inversiones seguras como Cetes; un rendimiento así, garantizado, es señal de fraude.



#### A tu plan

Elige una institución donde tengas dinero y verifícala hoy en el SIPRES y en el Buró de Entidades Financieras.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES», para confirmar el registro de una entidad.
- **Buró de Entidades Financieras** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** quejas y sanciones de cada institución.
- **Advertencias** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «entidades no autorizadas» o advertencias al público.

### Palabras clave

- *SIPRES:* registro de prestadores de servicios financieros de CONDUSEF.
- *Buró de Entidades Financieras:* herramienta de CONDUSEF que muestra quejas, sanciones y cómo resuelve cada institución.
- *Advertencia:* aviso de la autoridad sobre empresas que operan sin autorización.

### Fuentes

CONDUSEF · CNBV, consultados el 29 de septiembre de 2026.

---

## M2 U04. Tus derechos y dónde reclamar

**Lo que lograrás:** Identificar tus derechos como usuaria de servicios financieros y reclamar paso a paso, primero en la institución y después en la CONDUSEF.

**Para empezar:** Elena vio en su estado de cuenta un seguro que nunca contrató: 350 pesos al mes desde hace un año. Llamó al banco y le dijeron que «así venía la tarjeta». No es así. En esta lección aprenderás a reclamar para que te devuelvan lo que es tuyo.

### Lo esencial (5 minutos)

#### Tienes derechos

Tienes derecho a información clara, a que no te cobren productos que no pediste, a recibir tus estados de cuenta y a presentar una reclamación. Reclamar no tiene costo.



#### Dos niveles para reclamar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| UNE de la institución | Cada institución tiene una Unidad Especializada. | Primer paso, por escrito. |
| CONDUSEF | Si no te resuelven o no estás de acuerdo. | Sin costo. |
| Folio | Número de tu reclamación. | Guárdalo siempre. |
| REUS | Registro para no recibir publicidad financiera. | Módulo 4. |

#### Por escrito y con folio

Presenta tu reclamación en la UNE por escrito o por el canal oficial, y pide siempre un **folio**. Sin folio, es como si no hubieras reclamado.



#### Un caso en un minuto

Elena presentó su reclamación en la UNE del banco con su estado de cuenta. Le dieron folio. Como no le respondieron a tiempo, acudió a la CONDUSEF. Le devolvieron los cargos del seguro que no contrató.

> **Idea clave:** reclama por escrito, guarda el folio y, si no te resuelven, ve a la CONDUSEF.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta presentar una reclamación?
*Respuesta:* Nada. Reclamar no tiene costo.

2. ¿Qué pides siempre al reclamar?
*Respuesta:* Un folio.


#### Para recordar

- Primero la UNE, por escrito.
- Guarda el folio.
- Después, CONDUSEF.



### Profundiza (5 minutos más)

#### Tu reclamación paso a paso

| Paso | Qué haces |
|---|---|
| 1 | Reúne pruebas: estado de cuenta, contrato, capturas |
| 2 | Presenta la reclamación en la UNE, por escrito o canal oficial |
| 3 | Pide y guarda el folio |
| 4 | Espera la respuesta en el plazo que te indiquen |
| 5 | Si no te resuelven, acude a la CONDUSEF con tu folio |



#### Productos que no pediste

Seguros, membresías o asistencias agregados a tu tarjeta o cuenta sin tu autorización se pueden reclamar. Revisa tu estado de cuenta cada mes: los cargos pequeños son los que más pasan desapercibidos.



#### Lo que hace la CONDUSEF

Te orienta, recibe tu queja, puede citar a la institución a una conciliación y, en algunos casos, te apoya con asesoría jurídica. Nada tiene costo.

> **Antes de actuar, verifica:** el plazo para reclamar un cargo no reconocido puede ser corto; reclama en cuanto lo detectes.



#### Casos


**Caso 1. El seguro de Elena**

Elena descubre un seguro de 350 pesos al mes que nunca contrató.
- *¿Qué hace?* Reclama por escrito en la UNE del banco con su estado de cuenta y guarda el folio.


**Caso 2. La respuesta a Lucía**

El banco no respondió la reclamación de Lucía en el plazo.
- *¿Qué hace?* Acude a la CONDUSEF con su folio y sus pruebas.


**Caso 3. La llamada de Carmen**

Carmen reclama por teléfono y no le dan número de folio.
- *¿Qué hace?* Pide el folio o presenta la reclamación por escrito para tener constancia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Reclamar sin folio | No hay constancia | Pide el folio |
| Aceptar «así viene» | Pagas lo que no pediste | Reclama |
| Esperar meses | Pierdes plazos | Reclama pronto |
| Pagar a un gestor | Es sin costo | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Lucía y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde reclamas primero? a) En redes sociales del banco · b) En la UNE de la institución · c) Con un gestor que cobra
2. ¿Qué haces si no te resuelven? a) Te olvidas del cargo · b) Pagas para que un despacho reclame · c) Acudes a la CONDUSEF con tu folio
3. Un seguro de 350 al mes que no pediste, durante un año. ¿Cuánto reclamas? a) 4,200 · b) 350 · c) 3,500
**Respuestas:** 1-b: la UNE es el primer paso. 2-c: la CONDUSEF no tiene costo. 3-a: 350 por 12 meses son 4,200.



#### Ponlo en práctica

Elena pagó 350 al mes durante 14 meses por un seguro que no contrató. ¿Cuánto reclama?
**Respuesta:** 350 por 14: 4,900.



#### A tu plan

Revisa tu último estado de cuenta y marca cualquier cargo que no reconozcas. Si hay alguno, reclama esta semana.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «UNE» de tu institución y «asesoría», para reclamar.
- **REUS** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REUS», para no recibir publicidad financiera.

### Palabras clave

- *UNE:* la Unidad Especializada de Atención a Usuarios de cada institución, que recibe reclamaciones.
- *Folio:* el número que identifica tu reclamación.
- *Conciliación:* reunión que organiza la CONDUSEF entre tú y la institución para resolver una queja.

### Fuentes

CONDUSEF · Ley de Protección y Defensa al Usuario de Servicios Financieros, consultadas el 29 de septiembre de 2026.

---


# Parte 4. Módulo 3. El celular sin miedo

## M3 U01. Tu banco en el celular: lo que sí y lo que nunca

**Lo que lograrás:** Identificar lo que puedes hacer con la app de tu banco y lo que tu banco nunca te pedirá, para usarla con tranquilidad.

**Para empezar:** Lucía no usa la app de su banco: «me da miedo picarle a algo y que se vaya el dinero». Cada vez que necesita algo, le pide ayuda a su nieto o hace fila en la sucursal. En esta lección verás que la app, bien configurada, puede ser más segura que la fila.

### Lo esencial (5 minutos)

#### Qué puedes hacer

Con la app de tu banco puedes ver tu saldo y movimientos, pagar servicios y transferir. También puedes apagar tu tarjeta si la pierdes y recibir avisos de cada cargo. Verlo todo al momento te ayuda a detectar fraudes rápido.



#### Lo que tu banco nunca te pide

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Códigos | El código que te llega por mensaje o el del token. | Es solo tuyo. |
| Contraseñas y NIP | Por teléfono, mensaje o correo. | Nunca los dictes. |
| Mover tu dinero | A una «cuenta segura». | No existe. |
| Instalar apps | Para «ayudarte» a distancia. | Te roban el control. |

#### Más segura que la fila

La app te avisa de inmediato de cualquier movimiento. En la fila del cajero o de la sucursal, en cambio, hay desconocidos que pueden ver tu NIP u ofrecerte «ayuda». Bien configurada, la app te protege.



#### Un caso en un minuto

Lucía pidió en la sucursal que le activaran la app. La ejecutiva le mostró cómo ver su saldo y cómo apagar la tarjeta. Esa semana, sola, pagó la luz desde su casa.

> **Idea clave:** tu banco nunca te pedirá códigos, contraseñas ni mover tu dinero; quien lo pida es un estafador.



#### Comprueba lo que entendiste

1. ¿Tu banco te puede pedir por teléfono el código que te llegó por mensaje?
*Respuesta:* No. Nunca. Quien lo pida es un estafador.

2. ¿Qué ventaja tiene recibir avisos de cada cargo?
*Respuesta:* Detectas un fraude de inmediato y puedes actuar rápido.


#### Para recordar

- Ver, pagar, transferir y apagar tu tarjeta.
- Nunca códigos, contraseñas ni «cuentas seguras».
- Los avisos te protegen.



### Profundiza (5 minutos más)

#### ¿Quién te está hablando?

| Si te piden… | Es… | Qué haces |
|---|---|---|
| El código de un mensaje | Fraude | Cuelga |
| Mover tu dinero a una «cuenta segura» | Fraude | Cuelga y llama tú al banco |
| Instalar una app para «ayudarte» | Fraude | No instales nada |
| Confirmar un cargo con «sí» o «no» por mensaje del banco | Puede ser real | Verifica en tu app, no en el enlace |



#### Solo la app oficial

Descárgala desde la tienda de tu celular, buscando el nombre exacto de tu banco y revisando que el desarrollador sea el banco. Nunca desde un enlace que te llegue por mensaje. En el M3 U02 lo harás paso a paso.



#### La sucursal, tu aliada

Si tienes dudas, la sucursal de tu banco puede ayudarte a activar la app y a configurar avisos. Ahí la ayuda es de personal identificado del banco, no de desconocidos.

> **Antes de actuar, verifica:** el teléfono oficial de tu banco está atrás de tu tarjeta. Anótalo en tu carpeta; es el único que usas.



#### Casos


**Caso 1. El miedo de Lucía**

Lucía no usa la app por miedo y siempre hace fila con desconocidos alrededor.
- *¿Qué hace?* Pide en la sucursal que le activen la app y le enseñen lo básico.


**Caso 2. La llamada a Carmen**

Alguien «del banco» le pide a Carmen el código que le acaba de llegar.
- *¿Qué hace?* No lo da, cuelga y llama al número de atrás de su tarjeta.


**Caso 3. La app de Maru**

A Maru le llega un mensaje con un enlace para «descargar la nueva app de tu banco».
- *¿Qué hace?* No abre el enlace y busca la app oficial en la tienda de su celular.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar códigos por teléfono | Vacían tu cuenta | Nunca los des |
| Descargar apps por enlaces | App falsa | Solo tienda oficial |
| No activar avisos | Te enteras tarde | Actívalos |
| Pedir ayuda a desconocidos | Te roban | Sucursal o persona de confianza |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué nunca te pide tu banco? a) Que revises tus movimientos · b) El código de un mensaje · c) Que actives los avisos
2. ¿De dónde descargas la app de tu banco? a) De la tienda oficial del celular · b) De un enlace que te llegó · c) De la página que te recomendó un conocido
3. ¿Cuál es el teléfono seguro de tu banco? a) El que viene en un mensaje · b) El que te da quien te llamó · c) El de atrás de tu tarjeta
**Respuestas:** 1-b: los códigos son solo tuyos. 2-a: evita apps falsas. 3-c: es el oficial.



#### Ponlo en práctica

Escribe tres cosas que harás con la app y tres que nunca harás.
**Respuesta:** Por ejemplo: sí ver movimientos, pagar servicios y apagar la tarjeta; nunca dar códigos, mover dinero a una «cuenta segura» ni instalar apps para que me «ayuden».



#### A tu plan

Anota en tu carpeta el teléfono de atrás de tu tarjeta y pide en tu sucursal que te activen la app si aún no la tienes.



### Para saber más

- **Fraudes financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes», con las formas más comunes de engaño.

### Palabras clave

- *Banca móvil:* la app de tu banco en el celular.
- *Código de verificación:* número que te llega por mensaje o genera tu token para confirmar una operación.
- *Token:* generador de códigos, en tu app o en un aparato, para autorizar operaciones.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U02. Primeros pasos seguros en la app

**Lo que lograrás:** Instalar y configurar la app de tu banco de forma segura: app oficial, contraseña fuerte, huella o rostro, token y bloqueo de pantalla.

**Para empezar:** El nieto de Lucía le configuró la app «rapidito» y le puso de contraseña su fecha de nacimiento. También la tiene anotada en un papel dentro de la funda del celular. En esta lección verás cómo hacerlo bien, una sola vez.

### Lo esencial (5 minutos)

#### 1. La app oficial

En la tienda de tu celular, busca el nombre exacto de tu banco. Revisa que quien la publica sea el banco. Si tienes duda, pídela en la sucursal.



#### 2. Contraseña que solo tú sabes

Usa una contraseña que no sea tu fecha de nacimiento, tu teléfono ni «123456». Una frase corta que recuerdes, con números, funciona bien. No la escribas en el celular ni en la funda.



#### Tres candados del celular

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Huella o rostro | Para entrar a la app. | Más fácil y seguro. |
| Bloqueo de pantalla | Código para abrir el celular. | Si lo pierdes, nadie entra. |
| Token | Genera códigos para autorizar. | Actívalo en la app. |

#### Un caso en un minuto

Lucía volvió a la sucursal. Cambió su contraseña por una frase que solo ella sabe, activó la huella y puso bloqueo de pantalla. Tiró el papel de la funda.

> **Idea clave:** configura bien una vez: app oficial, contraseña propia, huella y bloqueo de pantalla.



#### Comprueba lo que entendiste

1. ¿Tu fecha de nacimiento es buena contraseña?
*Respuesta:* No. Es fácil de adivinar.

2. ¿Para qué sirve el bloqueo de pantalla?
*Respuesta:* Si pierdes el celular, nadie puede entrar a tus apps.


#### Para recordar

- App oficial.
- Contraseña que solo tú sabes.
- Huella, token y bloqueo de pantalla.



### Profundiza (5 minutos más)

#### Lista de configuración

| Paso | Hecho |
|---|---|
| App descargada de la tienda oficial | |
| Contraseña nueva, que solo yo sé | |
| Huella o rostro activado | |
| Token activado | |
| Bloqueo de pantalla del celular | |
| Teléfono del banco anotado en mi carpeta | |



#### ¿Y si alguien me ayuda?

Si una persona de confianza te ayuda a instalarla, que sea contigo al lado y que **tú** escribas la contraseña. Al terminar, cámbiala si la vio. Nadie más debe conocerla, ni tus hijos.



#### Si cambias de celular

Antes de vender o regalar tu celular viejo, cierra la sesión del banco, desactiva el token en ese equipo y borra el celular. En el nuevo, repite los pasos.

> **Antes de actuar, verifica:** cada banco tiene pasos distintos para activar el token; pídelos en la sucursal o en el número oficial.



#### Casos


**Caso 1. La contraseña de Lucía**

La contraseña de Lucía es su fecha de nacimiento y está anotada en la funda.
- *¿Qué hace?* La cambia por una frase que solo ella sabe y tira el papel.


**Caso 2. La ayuda de Carmen**

Su hija le ayuda a Carmen a instalar la app y ve la contraseña.
- *¿Qué hace?* Al terminar, Carmen cambia la contraseña por una que solo ella conozca.


**Caso 3. El celular viejo de Elena**

Elena va a regalar su celular viejo a su hijo.
- *¿Qué hace?* Cierra la sesión del banco, desactiva el token y borra el celular antes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contraseñas fáciles | Las adivinan | Frase propia |
| Contraseña anotada en la funda | Te la roban con el celular | En tu memoria |
| Sin bloqueo de pantalla | Cualquiera entra | Actívalo |
| Regalar el celular sin borrarlo | Acceso a tu banco | Cierra y borra |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es mejor contraseña? a) Una frase propia con números · b) Tu fecha de nacimiento, que nunca se te olvida · c) 123456, fácil de recordar
2. Tu hija vio tu contraseña al ayudarte. ¿Qué haces? a) Nada, es de confianza · b) La cambias por una que solo tú sepas · c) Se la das también a tu otro hijo
3. ¿Qué haces antes de regalar tu celular? a) Solo quitas las fotos · b) Nada, ya es de tu familia · c) Cierras el banco, quitas el token y lo borras
**Respuestas:** 1-a: difícil de adivinar. 2-b: solo tú debes saberla. 3-c: así nadie entra a tu banco.



#### Ponlo en práctica

Llena la lista de configuración y marca lo que te falta.
**Respuesta:** Por ejemplo: tengo la app oficial y bloqueo de pantalla; me falta cambiar la contraseña, activar la huella y el token.



#### A tu plan

Completa hoy los pasos que te falten de la lista de configuración, en tu sucursal si lo prefieres.



### Para saber más

- **Seguridad en la banca móvil** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «banca móvil» y «recomendaciones de seguridad».

### Palabras clave

- *Contraseña:* clave secreta para entrar a tu app; solo tú la conoces.
- *Bloqueo de pantalla:* código, huella o rostro para abrir el celular.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U03. Pon candados: alertas, límites y tarjeta apagada

**Lo que lograrás:** Activar las alertas de cada movimiento, fijar el límite de tus transferencias (MTU), usar la tarjeta digital y apagar tu tarjeta cuando no la usas.

**Para empezar:** A Carmen le robaron la cartera en el mercado. Cuando llegó a casa y llamó al banco, ya había tres cargos. Si hubiera tenido las alertas y la tarjeta apagada desde la app, lo habría frenado en segundos. En esta lección pondrás tus candados.

### Lo esencial (5 minutos)

#### Alertas de cada movimiento

Activa en tu app los avisos de cada cargo, retiro y transferencia. Si ves uno que no hiciste, actúas de inmediato.



#### Tu límite de transferencias

Desde enero de 2026, cada persona puede fijar el Monto Transaccional del Usuario (MTU). Si no lo fijas, el banco aplica uno de 1,500 UDIS, unos 12,800 pesos. Pon el que de verdad usas: si nunca transfieres más de 5,000, fija 5,000.

> **Dato vigente:** el MTU es obligatorio desde el 1 de enero de 2026. Si no lo configuras, el banco aplica un límite de 1,500 UDIS (unos 12,800 pesos). Puedes cambiarlo en cualquier momento. Consultado el 29 de septiembre de 2026 a través de la CNBV y medios nacionales.



#### Más candados

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tarjeta apagada | La prendes solo cuando la usas. | Si la roban, no sirve. |
| Tarjeta digital | Para compras en internet, con datos que cambian. | Tu tarjeta física no se expone. |
| Compras en el extranjero | Desactívalas si no viajas. | Menos riesgo. |

#### Un caso en un minuto

Carmen activó las alertas, fijó su límite en 5,000 y apaga su tarjeta de crédito cuando no la usa. Semanas después le llegó un aviso de un cargo que no hizo; apagó la tarjeta desde la app y reclamó el mismo día.

> **Idea clave:** con alertas, límite y tarjeta apagada, un robo se frena en segundos.



#### Comprueba lo que entendiste

1. ¿Qué es el MTU?
*Respuesta:* El límite de transferencias que tú fijas en tu app.

2. ¿Para qué sirve la tarjeta digital?
*Respuesta:* Para comprar en internet sin exponer los datos de tu tarjeta física.


#### Para recordar

- Alertas de todo.
- Límite de transferencias a tu medida.
- Tarjeta apagada si no la usas.



### Profundiza (5 minutos más)

#### Tu configuración de candados

| Candado | Dónde está en la app | Hecho |
|---|---|---|
| Alertas de cargos y transferencias | Configuración o notificaciones | |
| Límite de transferencias (MTU) | Seguridad o límites | |
| Apagar y encender tarjeta | Tarjetas | |
| Tarjeta digital | Tarjetas | |
| Compras en el extranjero | Tarjetas | |



#### Si necesitas mandar más

Si un día necesitas transferir más de tu límite, lo subes tú desde la app, haces la operación y lo vuelves a bajar. Si alguien te presiona para subirlo «ya», es señal de fraude.



#### Compras en internet

Usa la tarjeta digital o una tarjeta con límite bajo. Compra solo en sitios que conoces, escribiendo tú la dirección, no desde enlaces de mensajes.

> **Antes de actuar, verifica:** los nombres de las opciones cambian en cada app. Si no las encuentras, pide ayuda en la sucursal o en el número oficial.



#### Casos


**Caso 1. La cartera de Carmen**

A Carmen le roban la cartera y no tenía alertas ni forma de apagar la tarjeta.
- *¿Qué hace?* Activa alertas y la opción de apagar la tarjeta desde la app para frenar cargos al momento.


**Caso 2. El límite de Lucía**

Lucía nunca transfiere más de 3,000, pero su límite es el de 12,800 que puso el banco.
- *¿Qué hace?* Baja su límite de transferencias a 3,000 desde la app.


**Caso 3. La prisa de Maru**

Alguien le pide a Maru que suba su límite «ya» para recibir un reembolso.
- *¿Qué hace?* No lo sube y cuelga: recibir dinero no requiere subir tu límite.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin alertas | Te enteras tarde | Actívalas |
| Límite más alto del necesario | Pierdes más en un fraude | Ajústalo |
| Tarjeta física en internet | Clonación | Tarjeta digital |
| Subir el límite por presión | Fraude | Nunca por prisa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Nunca transfieres más de 4,000. ¿Qué límite fijas? a) El más alto posible · b) 4,000 · c) El que ponga el banco
2. ¿Qué usas para comprar en internet? a) La tarjeta digital · b) La tarjeta física de débito · c) La tarjeta de otra persona
3. ¿Recibir un reembolso requiere subir tu límite? a) Sí, siempre que el reembolso sea mayor que tu límite actual · b) Solo si es urgente · c) No: el límite es para lo que tú envías
**Respuestas:** 1-b: el límite a tu medida. 2-a: protege tu tarjeta física. 3-c: quien lo pida busca robarte.



#### Ponlo en práctica

Te roban 12,800 en transferencias con el límite del banco. Con un límite de 3,000, ¿cuánto sería lo máximo por día?
**Respuesta:** 3,000, porque el límite frena lo que pueden transferir desde tu app.



#### A tu plan

Activa hoy tus alertas, fija tu límite de transferencias y aprende a apagar tu tarjeta en la app.



### Para saber más

- **Monto Transaccional del Usuario** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «MTU», para conocer la regla.
- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «tarjeta digital» y recomendaciones de compras en línea.

### Palabras clave

- *Monto Transaccional del Usuario:* el límite de dinero que puedes transferir desde tu app, que tú misma fijas.
- *Tarjeta digital:* tarjeta virtual para compras en internet, con datos que cambian.
- *UDI:* unidad cuyo valor en pesos cambia con la inflación.

### Fuentes

CNBV · CONDUSEF · medios nacionales, consultados el 29 de septiembre de 2026.

---

## M3 U04. Transferir sin errores

**Lo que lograrás:** Enviar dinero por transferencia sin equivocarte: CLABE, registro de destinatarios, revisión del nombre, comprobante (CEP) y qué hacer si te equivocas.

**Para empezar:** Maru le transfirió a su proveedora de catálogo, pero se equivocó en un número de la CLABE. El dinero llegó a otra persona. No sabía que podía revisar el nombre antes de enviar. En esta lección aprenderás a transferir con calma.

### Lo esencial (5 minutos)

#### La CLABE

La CLABE tiene 18 dígitos. Pídela por escrito a quien le vas a pagar y cópiala con cuidado.



#### Antes de enviar

1. Registra a la persona como destinataria en tu app.
2. Revisa el nombre del titular que muestra tu app antes de confirmar.
3. Revisa el monto dos veces.
4. Guarda el comprobante.



#### El comprobante oficial

Cada transferencia SPEI tiene un CEP, que puedes descargar en el sitio de Banxico con los datos de la operación. Es la prueba de que el dinero llegó.



#### Un caso en un minuto

Ahora Maru registra a cada proveedora en su app. Antes de enviar, revisa que el nombre que aparece sea el correcto. Si no coincide, no envía y pregunta.

> **Idea clave:** registra, revisa el nombre y el monto, y guarda el comprobante.



#### Comprueba lo que entendiste

1. ¿Cuántos dígitos tiene la CLABE?
*Respuesta:* 18.

2. ¿Qué revisas antes de confirmar?
*Respuesta:* El nombre del titular que muestra tu app y el monto.


#### Para recordar

- CLABE por escrito.
- Revisa nombre y monto.
- Guarda el comprobante (CEP).



### Profundiza (5 minutos más)

#### Si te equivocaste

Llama de inmediato al número oficial de tu banco y presenta una reclamación. El banco puede pedir al otro banco la devolución, pero depende de que el titular acepte. Por eso es tan importante revisar antes.



#### Cambios de cuenta por mensaje

¿Una persona o empresa te avisa por mensaje o correo que «cambió su cuenta»? Antes de pagar, confirma por teléfono, con un número que ya tenías. Es un fraude común.



#### Transferencia segura

| Paso | Por qué |
|---|---|
| Pide la CLABE por escrito | Evitas errores al dictar |
| Registra a la persona | La app muestra su nombre |
| Revisa nombre y monto | Detectas errores y fraudes |
| Guarda el CEP | Pruebas el pago |

> **Antes de actuar, verifica:** algunas apps retrasan unos minutos las transferencias a destinatarios nuevos; es una protección, no un error.



#### Casos


**Caso 1. El error de Maru**

Maru se equivocó en un número de la CLABE y el dinero llegó a otra persona.
- *¿Qué hace?* Llama al número oficial del banco y reclama de inmediato.


**Caso 2. El aviso a Carmen**

Carmen recibe un correo de su jardinero: «cambié de cuenta, deposita a esta nueva».
- *¿Qué hace?* Le llama a un número que ya tenía para confirmar antes de pagar.


**Caso 3. La prueba de Elena**

El casero dice que no le llegó la renta que Elena transfirió.
- *¿Qué hace?* Descarga el CEP en el sitio de Banxico para probar el pago.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dictar la CLABE | Errores | Por escrito |
| No revisar el nombre | Llega a otra persona | Revísalo |
| Creer cambios de cuenta por correo | Fraude | Confirma por teléfono |
| No guardar comprobante | Sin prueba | Descarga el CEP |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el CEP? a) El comprobante oficial de una transferencia SPEI · b) Una clave para entrar a tu app · c) Un cobro por transferir
2. Te llega un correo: «cambié mi cuenta». ¿Qué haces? a) Pagas a la cuenta nueva · b) Confirmas por teléfono con un número que ya tenías · c) Contestas el correo para confirmar
3. ¿Qué revisas antes de enviar? a) Solo la CLABE, porque el nombre lo pone el banco · b) Solo el monto · c) El nombre del titular y el monto
**Respuestas:** 1-a: lo emite Banxico. 2-b: es un fraude común. 3-c: ambos evitan errores.



#### Ponlo en práctica

Escribe los cuatro pasos de una transferencia segura.
**Respuesta:** Pedir la CLABE por escrito, registrar a la persona, revisar nombre y monto, y guardar el comprobante.



#### A tu plan

Registra en tu app a las personas a quienes pagas cada mes y revisa que el nombre sea correcto.



### Para saber más

- **CEP** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «CEP», para descargar el comprobante de tus transferencias.

### Palabras clave

- *CLABE:* número de 18 dígitos que identifica una cuenta para recibir transferencias.
- *CEP:* Comprobante Electrónico de Pago que emite Banxico para las transferencias SPEI.
- *SPEI:* el sistema de transferencias entre bancos de Banxico.

### Fuentes

Banco de México · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M3 U05. Tu persona de confianza

**Lo que lograrás:** Elegir a una persona de confianza para dudas con tu banca, saber qué le compartes y qué no, y nunca pedir ayuda a desconocidos.

**Para empezar:** Lucía no sabía cómo pagar el predial en la app. Un joven amable en la sucursal se ofreció a ayudarla con su celular. Días después vio retiros que no hizo. En esta lección aprenderás a pedir ayuda de forma segura.

### Lo esencial (5 minutos)

#### Una persona elegida con calma

Tu persona de confianza es alguien cercano que conoces bien, que ya maneja su banca y que te explica sin prisa. Puede ser una hija, una amiga o un sobrino. La eliges tú, antes de necesitarla.



#### Qué sí y qué no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te explica | Te muestra dónde está cada opción. | Tú haces los pasos. |
| Te acompaña | A la sucursal o al teléfono del banco. | Tú hablas. |
| Tu contraseña | Nunca la conoce. | Ni tus hijos. |
| Tu celular sola | No opera tu banca sin ti. | Tú confirmas todo. |

#### Desconocidos, nunca

Nunca pidas ni aceptes ayuda de desconocidos en el cajero, en la sucursal o por teléfono. Para dudas, usa a tu persona de confianza, al personal identificado del banco o el número oficial.



#### Un caso en un minuto

Lucía eligió a su hija Clara como persona de confianza. Los domingos, Clara le explica con paciencia y Lucía hace los pasos. Si Clara no está, Lucía llama al número de atrás de su tarjeta.

> **Idea clave:** elige tu persona de confianza antes de necesitarla, y nunca aceptes ayuda de desconocidos.



#### Comprueba lo que entendiste

1. ¿Tu persona de confianza debe saber tu contraseña?
*Respuesta:* No. Te explica, pero tú haces los pasos.

2. ¿A quién pides ayuda si no está?
*Respuesta:* Al personal identificado del banco o al número oficial.


#### Para recordar

- Elígela antes de necesitarla.
- Te explica; tú haces los pasos.
- Desconocidos, nunca.



### Profundiza (5 minutos más)

#### Cómo elegirla

| Pregunta | Sí | No |
|---|---|---|
| ¿La conozco bien desde hace tiempo? | | |
| ¿Maneja con cuidado su propia banca? | | |
| ¿Me explica sin prisa ni presión? | | |
| ¿Respeta que yo decida? | | |
| ¿Ha pedido dinero prestado de forma insistente? | | |



#### Cuando la ayuda se vuelve control

Pedir ayuda no significa entregar el control. Si alguien, aunque sea de tu familia, quiere tus contraseñas, opera tu banca sin ti o te presiona para transferirle, pon un límite. En el módulo 11 verás cómo.



#### En la sucursal

Pide ayuda solo al personal con gafete del banco, en ventanilla o módulos de atención. El personal del banco no te pide tu NIP ni que le prestes el celular desbloqueado para irse con él.

> **Antes de actuar, verifica:** si alguien «del banco» se ofrece a ayudarte fuera de la sucursal o en el cajero, no es del banco.



#### Casos


**Caso 1. El joven amable de Lucía**

Un desconocido amable se ofrece a ayudar a Lucía con la app en la sucursal.
- *¿Qué hace?* No acepta y pide ayuda al personal con gafete del banco.


**Caso 2. La elección de Carmen**

Carmen piensa pedir ayuda al sobrino que siempre le pide dinero prestado.
- *¿Qué hace?* Elige a otra persona que la respete y no la presione.


**Caso 3. La hija de Elena**

La hija de Elena le pide su contraseña «para ayudarla más rápido».
- *¿Qué hace?* No se la da; su hija le explica y Elena hace los pasos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar ayuda de desconocidos | Robo | Solo personal identificado |
| Dar tu contraseña a la familia | Pierdes control | Tú haces los pasos |
| Elegir a quien presiona | Riesgo de abuso | Elige con calma |
| No tener a nadie | Dependes de extraños | Elige hoy |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién puede ayudarte en el cajero? a) Nadie desconocido · b) Quien se ofrezca amablemente · c) Cualquier persona formada detrás
2. ¿Qué hace tu persona de confianza? a) Te explica y tú haces los pasos · b) Opera tu banca con tu contraseña · c) Guarda tu celular por ti
3. Tu hija te pide la contraseña para ayudarte. ¿Qué haces? a) Se la das: es tu hija y así te ayuda más rápido cuando no estás · b) Le pides que te explique y tú la escribes · c) Le das la mitad de la contraseña
**Respuestas:** 1-a: ayuda de desconocidos es un riesgo. 2-a: tú mantienes el control. 3-b: nadie más debe saberla.



#### Ponlo en práctica

Usa la tabla para evaluar a dos posibles personas de confianza. ¿Qué respuesta descarta a alguien?
**Respuesta:** Que presione, no respete tus decisiones o pida dinero prestado de forma insistente.



#### A tu plan

Elige a tu persona de confianza, platica con ella sobre qué sí y qué no, y anota su nombre en tu carpeta.



### Para saber más

- **Adultos mayores y finanzas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «adultos mayores», con recomendaciones de seguridad.

### Palabras clave

- *Persona de confianza:* alguien que eliges con calma para ayudarte con dudas, sin darle tus contraseñas.
- *Gafete:* identificación visible del personal del banco.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 5. Módulo 4. Fraudes: que no te pase

## M4 U01. Cómo piensa quien te quiere estafar

**Lo que lograrás:** Reconocer los cuatro ganchos que usan casi todos los fraudes (urgencia, autoridad, miedo y premio) y aplicar la regla de oro: cuelga y verifica tú.

**Para empezar:** En un mes, Lucía recibió una llamada «del banco», un mensaje de «paquetería» y una llamada de un «sobrino» en problemas. Parecían distintas, pero todas usaban los mismos trucos. En esta lección aprenderás a reconocerlos, sin importar el disfraz.

### Lo esencial (5 minutos)

#### Cambian el disfraz, no el truco

Quien estafa no necesita hackear tu celular: necesita que **tú** hagas algo con prisa. Por eso usa la ingeniería social: te pone nerviosa para que no pienses.



#### Los cuatro ganchos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Urgencia | «Tiene que ser ahora o pierde su dinero». | La prisa es la señal. |
| Autoridad | «Le hablo del banco, del SAT, de la policía». | Cualquiera puede decirlo. |
| Miedo | «Su hijo tuvo un accidente». | Te bloquea para pensar. |
| Premio | «Ganó un premio, solo pague el envío». | Nadie regala así. |

#### La regla de oro

Ante cualquier llamada, mensaje o visita que te pida dinero, datos o códigos: **cuelga y verifica tú**, por un número o canal que ya conoces. Ninguna institución seria se molesta porque verifiques.



#### Un caso en un minuto

Lucía pegó en su refrigerador una hoja: «Prisa, autoridad, miedo o premio = cuelgo y verifico». La siguiente llamada «del banco» la cortó en diez segundos y llamó al número de atrás de su tarjeta. No había ningún problema con su cuenta.

> **Idea clave:** la prisa es la señal; cuelga y verifica tú por un canal que ya conoces.



#### Comprueba lo que entendiste

1. ¿Cuáles son los cuatro ganchos?
*Respuesta:* Urgencia, autoridad, miedo y premio.

2. ¿Qué haces ante una llamada que te pide dinero con prisa?
*Respuesta:* Cuelgo y verifico por un número que ya conozco.


#### Para recordar

- Urgencia, autoridad, miedo y premio.
- Cuelga y verifica tú.
- Nadie serio se molesta porque verifiques.



### Profundiza (5 minutos más)

#### Frases que delatan un fraude

| Frase | Gancho |
|---|---|
| «No cuelgue, es urgente» | Urgencia |
| «Soy el licenciado del área de seguridad» | Autoridad |
| «No le diga a nadie, es confidencial» | Miedo y aislamiento |
| «Solo pague el envío de su premio» | Premio |
| «Deme el código para cancelar el cargo» | Autoridad y urgencia |



#### El secreto también es una señal

Muchos fraudes piden que no le cuentes a nadie. Es para que nadie te diga «eso es un fraude». Si te piden secreto, cuéntaselo a tu persona de confianza antes de hacer nada.



#### No es cuestión de ser ingenua

Los fraudes funcionan con personas preparadas porque juegan con emociones, no con conocimientos. Reconocer el truco no depende de saber de finanzas, sino de parar y verificar.

> **Dato vigente:** durante 2025, la CONDUSEF registró 72,873 asuntos relacionados con un posible fraude. De enero a marzo de 2026, el 37.4% de las reclamaciones que recibió se relacionaron con un posible fraude. Consultado el 29 de septiembre de 2026 a través de la CONDUSEF.



#### Casos


**Caso 1. La prisa de Lucía**

Una voz «del área de seguridad» le dice a Lucía que no cuelgue porque su cuenta será bloqueada en cinco minutos.
- *¿Qué hace?* Cuelga y llama ella al número de atrás de su tarjeta.


**Caso 2. El premio de Carmen**

A Carmen le avisan que ganó una camioneta y solo debe pagar 3,500 de «trámites».
- *¿Qué hace?* No paga nada: un premio real no cobra por entregarse.


**Caso 3. El secreto de Maru**

Le piden a Maru que no le cuente a nadie de una «inversión exclusiva».
- *¿Qué hace?* Se lo cuenta a su persona de confianza y verifica antes de decidir.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Actuar con prisa | Caes en el truco | Para y verifica |
| Creer por el cargo | Cualquiera dice ser autoridad | Llama tú |
| Guardar el secreto | Nadie te advierte | Cuéntalo |
| Pensar «a mí no me pasa» | Bajas la guardia | Reconoce los ganchos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué gancho usa «tiene cinco minutos o pierde su dinero»? a) Premio · b) Urgencia · c) Ninguno, es un aviso normal
2. Te piden guardar el secreto. ¿Qué haces? a) Lo cuentas a tu persona de confianza · b) Lo guardas para no meterte en problemas · c) Pides más detalles a quien llama
3. ¿Cuál es la regla de oro? a) Dar solo los datos que ya tienen, para confirmar que son del banco · b) Pedir el nombre completo de quien llama · c) Colgar y verificar tú por un canal conocido
**Respuestas:** 1-b: la prisa es el gancho. 2-a: el secreto es una señal de fraude. 3-c: siempre verifica tú.



#### Ponlo en práctica

Clasifica estas frases según su gancho: «su nieto está detenido», «ganó un viaje», «le hablo del SAT», «tiene diez minutos».
**Respuesta:** Miedo, premio, autoridad y urgencia.



#### A tu plan

Escribe en una hoja la regla «prisa, autoridad, miedo o premio = cuelgo y verifico» y ponla junto a tu teléfono.



### Para saber más

- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «Portal de Fraudes Financieros», con las formas más comunes de engaño.

### Palabras clave

- *Ingeniería social:* engaño que usa emociones como la prisa o el miedo para que hagas algo que te perjudica.
- *Fraude:* engaño para quitarte dinero o datos.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M4 U02. La llamada «del banco»

**Lo que lograrás:** Reconocer la llamada falsa del banco, saber que el código nunca se da y responder colgando y llamando tú al número oficial.

**Para empezar:** A Carmen le llamaron para «cancelar un cargo de 18,000 pesos en una tienda en línea». El hombre sabía su nombre y los últimos dígitos de su tarjeta. Le pidió el código que le acababa de llegar «para bloquear la compra». Casi se lo da. En esta lección verás por qué nunca debes darlo.

### Lo esencial (5 minutos)

#### El guion de siempre

Te llaman «del área de seguridad» por un cargo que no hiciste. Suenan profesionales, saben tu nombre y a veces parte de tu tarjeta. Luego te piden un código, tu NIP o que muevas tu dinero a una «cuenta segura».



#### Lo que te piden y lo que es

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Dígame el código que le llegó» | En realidad autoriza una operación a su favor. | Nunca lo des. |
| «Pase su dinero a una cuenta segura» | No existe; es la cuenta del estafador. | Cuelga. |
| «Instale esta app para ayudarle» | Les da control de tu celular. | No instales nada. |
| «Le mandamos a alguien por su tarjeta» | Se la llevan y la usan. | Nadie recoge tarjetas. |

#### Por qué saben tus datos

Tu nombre y los últimos dígitos de tu tarjeta pueden venir de filtraciones o de un mensaje falso que abriste. Que los sepan **no** prueba que sean del banco.



#### Un caso en un minuto

Carmen dudó, colgó y llamó al número de atrás de su tarjeta. No había ningún cargo de 18,000. El código que le pedían era para autorizar una transferencia desde su cuenta.

> **Idea clave:** el código es como tu firma: nunca lo das por teléfono, aunque parezca tu banco.



#### Comprueba lo que entendiste

1. ¿Existe la «cuenta segura» a la que te piden mover tu dinero?
*Respuesta:* No. Es la cuenta del estafador.

2. ¿Que sepan tu nombre prueba que es el banco?
*Respuesta:* No. Pueden tenerlo de filtraciones o mensajes falsos.


#### Para recordar

- El código es tu firma: nunca lo das.
- No hay «cuentas seguras».
- Cuelga y llama al número de tu tarjeta.



### Profundiza (5 minutos más)

#### Banco real contra banco falso

| El banco real… | El falso… |
|---|---|
| Te pide que confirmes en tu app | Te pide el código por teléfono |
| Te invita a llamar al número de tu tarjeta | Te pide no colgar |
| Nunca mueve tu dinero por «seguridad» | Te pide pasarlo a otra cuenta |
| No manda a nadie por tu tarjeta | Manda a un «mensajero» |



#### Cuelga bien

Algunos estafadores se quedan en la línea y fingen ser el banco cuando vuelves a marcar. Cuelga, espera un minuto o llama desde otro teléfono.



#### Si ya diste el código

Llama de inmediato al número oficial, pide bloquear tus cuentas y tarjetas, cambia tu contraseña y presenta una reclamación por escrito. Sigue tu plan de respuesta (M4 U08).

> **Antes de actuar, verifica:** el número de atrás de tu tarjeta y el de tu app son los únicos que usas; anótalos en tu carpeta.



#### Casos


**Caso 1. El cargo de Carmen**

Le piden a Carmen el código que le llegó para «cancelar un cargo de 18,000».
- *¿Qué hace?* No lo da, cuelga y llama al número de atrás de su tarjeta.


**Caso 2. La cuenta segura de Lucía**

Le dicen a Lucía que su dinero está en riesgo y que lo pase a una «cuenta segura».
- *¿Qué hace?* Cuelga: el banco nunca pide mover tu dinero; llama al número oficial.


**Caso 3. El mensajero de Elena**

«Del banco» le dicen a Elena que pasarán por su tarjeta para cambiarla.
- *¿Qué hace?* No entrega la tarjeta y llama al banco para confirmar que es un fraude.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar el código | Autorizas el robo | Nunca lo des |
| No colgar | Te siguen presionando | Cuelga |
| Volver a marcar de inmediato | Siguen en la línea | Espera o usa otro teléfono |
| Entregar la tarjeta | La usan | Nadie la recoge |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Para qué sirve en realidad el código que te piden? a) Para cancelar el cargo · b) Para autorizar una operación a favor del estafador · c) Para verificar tu identidad ante el banco
2. ¿Qué haces si te piden mover tu dinero a una cuenta segura? a) Cuelgas y llamas al número oficial · b) Lo mueves solo una parte · c) Pides el nombre de la cuenta
3. Ya diste el código. ¿Qué haces primero? a) Esperas a ver si pasa algo · b) Le reclamas a quien llamó y le pides que devuelva lo que tomó · c) Llamas al banco y pides bloquear todo
**Respuestas:** 1-b: el código autoriza operaciones. 2-a: la cuenta segura no existe. 3-c: cada minuto cuenta.



#### Ponlo en práctica

Escribe lo que dirás si te llaman «del banco»: una frase para colgar.
**Respuesta:** Por ejemplo: «Gracias, voy a llamar yo al número de mi tarjeta». Y cuelgas.



#### A tu plan

Anota el número de atrás de tu tarjeta en tu carpeta y practica la frase para colgar.



### Para saber más

- **Fraudes telefónicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «vishing» o fraudes telefónicos.

### Palabras clave

- *Vishing:* fraude por llamada telefónica que se hace pasar por una institución.
- *Cuenta segura:* engaño en el que te piden mover tu dinero a una cuenta del estafador.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M4 U03. Mensajes y correos falsos

**Lo que lograrás:** Reconocer mensajes de texto, WhatsApp y correos falsos que imitan bancos, paqueterías y el SAT, y no abrir sus enlaces.

**Para empezar:** A Lucía le llegó un mensaje: «BANCO: su tarjeta fue bloqueada. Ingrese aquí para reactivarla». El enlace llevaba a una página idéntica a la de su banco. Escribió su usuario y contraseña. En esta lección aprenderás a reconocer estos mensajes antes de tocar el enlace.

### Lo esencial (5 minutos)

#### Qué es el phishing

El phishing son mensajes que imitan a tu banco, una paquetería, el SAT o una tienda. Te piden entrar a un enlace y escribir tus datos. La página se ve idéntica, pero es falsa.



#### Señales de un mensaje falso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Prisa | «Su cuenta será cancelada hoy». | Urgencia. |
| Enlace | Te pide entrar a una liga. | Tu banco no te manda a escribir datos. |
| Paquete que no esperas | «Pague 30 pesos para recibirlo». | Te roban la tarjeta. |
| Errores y remitentes raros | Faltas de ortografía, números desconocidos. | Otra señal. |

#### No toques el enlace

Si un mensaje te preocupa, no uses su enlace ni su teléfono. Abre tú la app de tu banco o llama al número de tu tarjeta. Si todo está bien ahí, el mensaje era falso.



#### Un caso en un minuto

Lucía llamó al banco en cuanto se dio cuenta. Bloquearon su acceso y cambió su contraseña. Ahora, cuando le llega un mensaje «del banco», abre ella su app. Nunca ha habido un problema real.

> **Idea clave:** no uses los enlaces de mensajes; abre tú la app o llama al número de tu tarjeta.



#### Comprueba lo que entendiste

1. ¿Qué es el phishing?
*Respuesta:* Mensajes o páginas falsas que imitan a una empresa para robar tus datos.

2. ¿Qué haces si un mensaje dice que tu tarjeta fue bloqueada?
*Respuesta:* Abro yo mi app o llamo al número de mi tarjeta, sin usar el enlace.


#### Para recordar

- No toques el enlace.
- Abre tú la app o llama al número de tu tarjeta.
- Paquete que no esperas = alerta.



### Profundiza (5 minutos más)

#### Mensajes falsos comunes

| Mensaje | Qué buscan |
|---|---|
| «Su tarjeta fue bloqueada, ingrese aquí» | Tu usuario y contraseña |
| «Su paquete no pudo entregarse, pague 30 pesos» | Los datos de tu tarjeta |
| «El SAT le devuelve dinero, registre su cuenta» | Tus datos y tu cuenta |
| «Mamá, cambié de número, guárdalo» | Iniciar una extorsión o pedir dinero |



#### WhatsApp y redes

En WhatsApp también llegan mensajes falsos, incluso desde cuentas con la foto de un familiar. Si alguien cercano te pide dinero por mensaje, llámale a su número de siempre antes de hacer nada.



#### Reporta y borra

Borra el mensaje sin contestar. Puedes reportarlo a tu banco y bloquear el número. Si abriste el enlace y escribiste datos, sigue tu plan de respuesta (M4 U08).

> **Antes de actuar, verifica:** el SAT no te pide datos bancarios por mensaje ni te manda enlaces para devoluciones. Todo se consulta en su sitio oficial.



#### Casos


**Caso 1. La tarjeta de Lucía**

A Lucía le llega un mensaje: «su tarjeta fue bloqueada, ingrese aquí».
- *¿Qué hace?* No abre el enlace; revisa en su app o llama al número de su tarjeta.


**Caso 2. El paquete de Carmen**

Carmen recibe un mensaje de una paquetería para pagar 30 pesos por un envío que no espera.
- *¿Qué hace?* Lo borra sin pagar: es para robar los datos de su tarjeta.


**Caso 3. El número nuevo de Elena**

A Elena le escribe «su hijo» desde un número nuevo pidiéndole dinero urgente.
- *¿Qué hace?* Le llama a su hijo a su número de siempre antes de enviar nada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Abrir enlaces de mensajes | Página falsa | Usa tu app |
| Pagar envíos que no esperas | Roban tu tarjeta | Borra |
| Creer por la foto de perfil | Suplantación | Llama al número de siempre |
| Contestar al mensaje | Confirmas que estás activa | Borra y bloquea |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces con un mensaje que dice que tu cuenta será cancelada? a) Abres tu app sin usar el enlace · b) Entras al enlace para revisar · c) Respondes el mensaje con tus datos
2. Te llega un cobro de paquetería que no esperas. ¿Qué es? a) Un envío olvidado que debes pagar · b) Un intento de robar tu tarjeta · c) Un regalo de un familiar
3. «Tu hijo» te escribe desde un número nuevo pidiéndote dinero. ¿Qué haces? a) Envías poco para ayudar · b) Le pides una foto para confirmar · c) Le llamas a su número de siempre
**Respuestas:** 1-a: nunca uses el enlace. 2-b: buscan tus datos. 3-c: confirma por un canal conocido.



#### Ponlo en práctica

Revisa tus mensajes de la última semana y cuenta cuántos tienen alguna de las señales.
**Respuesta:** Por ejemplo: dos mensajes con enlaces «del banco» y uno de paquetería; los tres eran falsos y se borran.



#### A tu plan

Acuerda con tu familia que nadie pide dinero por mensaje sin llamar antes.



### Para saber más

- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «phishing» y «smishing».
- **SAT** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** avisos sobre correos y mensajes falsos.

### Palabras clave

- *Phishing:* engaño con mensajes o páginas falsas que imitan a una empresa para robar tus datos.
- *Smishing:* phishing por mensaje de texto.
- *Enlace:* dirección que te lleva a una página.

### Fuentes

CONDUSEF · SAT, consultados el 29 de septiembre de 2026.

---

## M4 U04. «Mamá, estoy en problemas»: extorsión y voces falsas

**Lo que lograrás:** Reconocer la extorsión telefónica y el secuestro virtual, saber que hoy se pueden imitar voces, y acordar una palabra clave familiar.

**Para empezar:** Elena recibió una llamada: una voz llorando, igualita a la de su hijo, decía «mamá, ayúdame». Luego un hombre exigió 50,000 pesos y que no colgara. Su hijo estaba en la escuela, tranquilo. En esta lección aprenderás qué hacer en esos minutos de miedo.

### Lo esencial (5 minutos)

#### El secuestro virtual

En el secuestro virtual nadie está secuestrado. Te hacen creer que sí con gritos, llanto o una voz parecida, y te exigen que no cuelgues para que no verifiques.



#### Nuevos trucos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Voz imitada | Con pocos audios de redes, se puede imitar una voz. | No confíes solo en la voz. |
| «No cuelgue» | Te mantienen en la línea. | Para que no llames a tu familiar. |
| Datos de redes | Saben nombres y lugares. | Los tomaron de publicaciones. |
| Palabra clave | Una palabra que solo tu familia conoce. | Tu mejor defensa. |

#### Qué hacer

Cuelga. Llama o escribe a tu familiar a su número de siempre, o pide a alguien a tu lado que lo haga. Si no contesta, llama a su escuela, trabajo o a alguien que esté con él. Y reporta al 089 o al 911.



#### Un caso en un minuto

Elena colgó, a pesar del miedo, y llamó a la escuela. Su hijo estaba en clase. Después acordó con sus hijos una palabra clave: si alguien llama «en su nombre» y no la dice, es falso.

> **Idea clave:** cuelga y localiza a tu familiar por otro medio; acuerden una palabra clave.



#### Comprueba lo que entendiste

1. ¿Por qué te piden que no cuelgues?
*Respuesta:* Para que no puedas llamar a tu familiar y descubrir que está bien.

2. ¿Puedes confiar solo en la voz?
*Respuesta:* No. Hoy se pueden imitar voces con pocos audios.


#### Para recordar

- Cuelga.
- Localiza a tu familiar por otro medio.
- Palabra clave familiar.



### Profundiza (5 minutos más)

#### Tu plan en tres minutos

| Minuto | Qué haces |
|---|---|
| 1 | Cuelgas, aunque te digan que no |
| 2 | Llamas a tu familiar o a quien esté con él; pides a alguien que te ayude a localizarlo |
| 3 | Si está bien, reportas al 089 (denuncia anónima) o al 911 |



#### Cuida lo que publicas

Evita publicar en redes horarios, escuelas, viajes en curso y audios largos de tus hijos. Configura tus redes como privadas. Menos información, menos material para un engaño.



#### Después del susto

Es normal quedar alterada. Habla con tu familia y, si ya pagaste, denuncia: sigue tu plan de respuesta (M4 U08). No es tu culpa; estos engaños están diseñados para asustar.

> **Antes de actuar, verifica:** los números de emergencia de tu estado (911 y 089) y guárdalos en tu teléfono.



#### Casos


**Caso 1. La voz de Elena**

Elena oye la voz de su hijo llorando y un hombre le exige 50,000 sin colgar.
- *¿Qué hace?* Cuelga y localiza a su hijo en la escuela antes de hacer nada.


**Caso 2. La palabra de Carmen**

Carmen quiere prepararse por si le llaman fingiendo ser su nieto.
- *¿Qué hace?* Acuerda con su familia una palabra clave que solo ellos conozcan.


**Caso 3. Las fotos de Maru**

Maru publica en redes cada viaje de su hija, con fechas y lugares.
- *¿Qué hace?* Hace privadas sus redes y deja de publicar viajes en curso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No colgar | Te mantienen asustada | Cuelga |
| Pagar para «resolver» | Piden más | Localiza primero |
| Confiar en la voz | Puede ser imitada | Palabra clave |
| Publicar todo en redes | Material para el engaño | Redes privadas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el secuestro virtual? a) Fingir un secuestro para que pagues rápido · b) Un secuestro real transmitido por internet · c) Un juego en redes sociales
2. ¿Qué haces primero ante la llamada? a) Pagas primero y luego verificas si tu familiar está bien · b) Cuelgas y localizas a tu familiar · c) Negocias una cantidad menor
3. ¿Para qué sirve la palabra clave? a) Para entrar a tu banco · b) Para las redes de la familia · c) Para saber si quien llama es de verdad tu familiar
**Respuestas:** 1-a: nadie está secuestrado. 2-b: localizar primero. 3-c: quien no la sabe, no es tu familiar.



#### Ponlo en práctica

Escribe tu plan en tres minutos con los teléfonos que necesitas: familiares, escuelas o trabajos, 089 y 911.
**Respuesta:** Por ejemplo: hijo (número), escuela (número), trabajo de mi hija (número), 089 y 911.



#### A tu plan

Acuerda hoy una palabra clave con tu familia y guarda los teléfonos de tu plan de tres minutos.



### Para saber más

- **Denuncia anónima 089** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «089», para reportar extorsiones.
- **Ciberseguridad** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** extorsión y recomendaciones.

### Palabras clave

- *Secuestro virtual:* extorsión en la que fingen tener a un familiar para que pagues rápido, sin que exista secuestro.
- *Extorsión:* exigir dinero con amenazas.
- *Palabra clave:* palabra que solo tu familia conoce para confirmar quién llama.

### Fuentes

Guardia Nacional · Gobierno de México, consultados el 29 de septiembre de 2026.

---

## M4 U05. En el cajero y la sucursal

**Lo que lograrás:** Usar el cajero y la sucursal con seguridad: no aceptar ayuda de desconocidos, cuidar tu NIP, revisar el cajero y reconocer el «cuento del tío» y el cambio de tarjeta.

**Para empezar:** A Lucía se le atoró la tarjeta en el cajero. Un señor amable se acercó: «a mí me pasó, marque su NIP y presione cancelar». Mientras ella lo hacía, él miraba. Cuando se fue, la tarjeta ya no estaba. En esta lección aprenderás a protegerte en esos momentos.

### Lo esencial (5 minutos)

#### Tu NIP es solo tuyo

Cubre el teclado con la mano al marcar tu NIP. Nunca lo digas en voz alta ni lo marques frente a alguien que «te ayuda».



#### Trucos frecuentes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ayuda en el cajero | Un desconocido te «ayuda» y ve tu NIP. | Luego te roba la tarjeta. |
| Cambio de tarjeta | Te distraen y te dan una tarjeta parecida. | Se llevan la tuya. |
| «Se le cayó dinero» | Te distraen mientras toman tus cosas. | Cuida tu bolsa. |
| Cuento del tío | Te piden dinero para cobrar una herencia o premio. | Nadie regala así. |

#### Si la tarjeta se atora

No aceptes ayuda. Llama desde ahí al número de tu tarjeta o al teléfono que aparece en el cajero **del banco** y bloquéala. Luego ve a la sucursal.



#### Un caso en un minuto

Hoy Lucía usa cajeros dentro de las sucursales, en horario de oficina. Si algo falla, habla con el personal del banco. Nunca acepta ayuda en el cajero.

> **Idea clave:** en el cajero no aceptas ayuda de nadie; si algo falla, bloqueas por teléfono y vas a la sucursal.



#### Comprueba lo que entendiste

1. ¿Qué haces si la tarjeta se atora?
*Respuesta:* Llamo al número de mi tarjeta para bloquearla y no acepto ayuda de desconocidos.

2. ¿Cómo marcas tu NIP?
*Respuesta:* Cubriendo el teclado con la mano, sin que nadie vea.


#### Para recordar

- Cubre tu NIP.
- Sin ayuda de desconocidos.
- Cajeros dentro de sucursales.



### Profundiza (5 minutos más)

#### Antes de usar el cajero

| Revisa | Por qué |
|---|---|
| Que la ranura no esté suelta o con piezas extra | Pueden tener un lector que copia tu tarjeta |
| Que nadie esté muy cerca | Pueden ver tu NIP |
| Que sea de día y dentro de una sucursal | Más seguridad |
| Que tu bolsa esté cerrada | Evitas robos por distracción |



#### En la sucursal

Haz tus trámites en ventanilla o con personal identificado. Si alguien se te acerca en la fila para «agilizar» tu trámite o te pide tu identificación, avisa al personal.



#### Retiros grandes

Si necesitas mucho efectivo, considera una transferencia en su lugar. Si debes retirar, ve acompañada, no lo cuentes en público y no lo comentes en la fila.

> **Antes de actuar, verifica:** si notas algo extraño en un cajero, no lo uses y avisa al banco.



#### Casos


**Caso 1. El señor amable de Lucía**

Su tarjeta se atora y un señor le ofrece ayuda a Lucía.
- *¿Qué hace?* No acepta ayuda y llama al número de su tarjeta para bloquearla.


**Caso 2. La ranura de Carmen**

Carmen nota que la ranura del cajero se mueve y tiene una pieza extra.
- *¿Qué hace?* No lo usa y avisa al banco.


**Caso 3. La herencia de Maru**

Una señora le pide a Maru dinero «para cobrar una herencia» y promete compartirla.
- *¿Qué hace?* No da nada: es el cuento del tío.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar ayuda | Roban tu NIP y tarjeta | Llama al banco |
| No cubrir el NIP | Te lo ven | Cubre el teclado |
| Usar cajeros aislados | Mayor riesgo | Dentro de sucursales |
| Creer historias de herencias | Pierdes dinero | Cuento del tío |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu tarjeta se atora. ¿Qué haces? a) Aceptas la ayuda de quien esté cerca · b) Bloqueas por teléfono y vas a la sucursal · c) Marcas el NIP varias veces hasta que el cajero te regrese la tarjeta
2. ¿Dónde es más seguro usar el cajero? a) En la calle, de noche · b) En una plaza sin vigilancia · c) Dentro de una sucursal, de día
3. Te piden dinero para cobrar una herencia. ¿Qué es? a) El cuento del tío · b) Una oportunidad rara · c) Un trámite notarial normal
**Respuestas:** 1-b: nunca aceptes ayuda de desconocidos. 2-c: más seguridad. 3-a: nadie regala así.



#### Ponlo en práctica

Escribe los cuatro puntos que revisas antes de usar un cajero.
**Respuesta:** Que la ranura no esté suelta, que nadie esté cerca, que sea de día en una sucursal y que tu bolsa esté cerrada.



#### A tu plan

Identifica el cajero dentro de una sucursal más cercano a tu casa y úsalo como tu cajero de siempre.



### Para saber más

- **Fraudes en cajeros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cajero automático» y «clonación».

### Palabras clave

- *NIP:* número secreto de tu tarjeta para usar el cajero o pagar.
- *Clonación:* copia de los datos de tu tarjeta con un aparato oculto.
- *Cuento del tío:* engaño en el que te piden dinero para cobrar una supuesta herencia o premio.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M4 U06. Robo de identidad

**Lo que lograrás:** Cuidar tu INE, CURP y firma, detectar si alguien usa tus datos (créditos y líneas de celular a tu nombre) y activar protecciones como el bloqueo en Buró de Crédito.

**Para empezar:** A Carmen le empezaron a llamar de cobranza por una tarjeta de una tienda departamental que nunca tramitó. Alguien usó una copia de su INE que dejó en un trámite. En esta lección aprenderás a detectar y frenar el robo de identidad.

### Lo esencial (5 minutos)

#### Qué es

El robo de identidad ocurre cuando alguien usa tus datos para pedir créditos, abrir cuentas o contratar líneas de celular. Te enteras tarde: por una llamada de cobranza o un reporte de crédito.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobranza de algo que no pediste | Una deuda que no reconoces. | Revisa tu reporte. |
| Correspondencia extraña | Tarjetas o estados de cuenta que no pediste. | Alguien usó tus datos. |
| Líneas a tu nombre | Celulares que no contrataste. | Consulta con tu CURP. |
| Tu reporte de crédito | Créditos o consultas que no conoces. | Revísalo cada año. |

#### Protecciones

Pide tu reporte de crédito sin costo una vez al año. Consulta las líneas de celular registradas con tu CURP. Si te preocupa, activa el bloqueo de tu historial en Buró de Crédito para que nadie pueda consultarlo sin ti.



#### Un caso en un minuto

Carmen pidió su reporte sin costo y encontró la tarjeta que no tramitó. Reclamó en la tienda y en el Buró, presentó denuncia y activó el bloqueo. Ahora, cuando entrega una copia de su INE, escribe sobre ella para qué es.

> **Idea clave:** revisa tu reporte cada año, cuida tus copias y actúa rápido si algo no es tuyo.



#### Comprueba lo que entendiste

1. ¿Cómo te das cuenta de un robo de identidad?
*Respuesta:* Por cobranzas o créditos que no reconoces, o al revisar mi reporte de crédito.

2. ¿Cada cuánto pides tu reporte sin costo?
*Respuesta:* Una vez al año.


#### Para recordar

- Reporte de crédito cada año.
- Copias de INE con nota.
- Bloqueo en Buró si te preocupa.



### Profundiza (5 minutos más)

#### Si alguien usa tus datos

| Paso | Qué haces |
|---|---|
| 1 | Pide tu reporte en Buró de Crédito y en Círculo de Crédito |
| 2 | Reclama cada crédito que no es tuyo en la institución y en la sociedad de información crediticia |
| 3 | Presenta denuncia ante la fiscalía o el Ministerio Público |
| 4 | Acude a la CONDUSEF si la institución no resuelve |
| 5 | Activa el bloqueo de tu historial |



#### Líneas de celular con tu CURP

En 2026 cada línea de celular se vincula con la CURP de su titular. Puedes consultar en cada compañía qué líneas están a tu nombre y pedir que desvinculen las que no son tuyas. Es sin costo.

> **Dato vigente:** en 2026 es obligatorio registrar las líneas móviles con la CURP, con plazo final el 31 de diciembre de 2026. La consulta y la desvinculación no tienen costo en portal.crt.gob.mx. Consultado el 29 de septiembre de 2026 a través de la Comisión Reguladora de Telecomunicaciones.



#### Tus papeles

Rompe antes de tirar estados de cuenta, cartas del banco y copias de identificaciones. No compartas fotos de tu INE ni de tus tarjetas por mensaje.

> **Antes de actuar, verifica:** el reporte sin costo solo se pide en los sitios oficiales de Buró de Crédito y Círculo de Crédito. Nunca con gestores.



#### Casos


**Caso 1. La tarjeta de Carmen**

A Carmen le cobran una tarjeta departamental que nunca tramitó.
- *¿Qué hace?* Pide su reporte, reclama, denuncia y activa el bloqueo de su historial.


**Caso 2. Las líneas de Lucía**

Lucía no sabe si alguien usó su CURP para contratar celulares.
- *¿Qué hace?* Consulta sin costo las líneas registradas con su CURP y desvincula las que no son suyas.


**Caso 3. Los papeles de Maru**

Maru tira a la basura estados de cuenta completos.
- *¿Qué hace?* Los rompe antes de tirarlos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar tu reporte | Te enteras tarde | Una vez al año |
| Copias de INE sin nota | Las usan para otra cosa | Anota para qué es |
| Tirar papeles enteros | Roban tus datos | Rómpelos |
| Pagar a gestores | Es sin costo | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te cobran un crédito que nunca pediste. ¿Qué haces primero? a) Lo pagas para que no te afecte · b) Esperas a que dejen de llamar, porque la deuda no es tuya · c) Pides tu reporte de crédito y reclamas
2. ¿Cuánto cuesta consultar las líneas con tu CURP? a) Nada · b) Lo que cobre cada compañía · c) Una cuota anual al gobierno
3. ¿Qué haces con estados de cuenta viejos? a) Los guardas sueltos en un cajón · b) Los rompes antes de tirarlos · c) Los tiras enteros a la basura
**Respuestas:** 1-c: primero sabes qué hay. 2-a: no tiene costo. 3-b: así no roban tus datos.



#### Ponlo en práctica

Escribe los cinco pasos si alguien usa tus datos.
**Respuesta:** Pedir reportes, reclamar cada crédito, denunciar, acudir a la CONDUSEF si no resuelven y activar el bloqueo.



#### A tu plan

Pide tu reporte de crédito sin costo este mes y consulta las líneas registradas con tu CURP.



### Para saber más

- **Reporte de Crédito Especial y bloqueo** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** reporte sin costo y «Bloqueo Buró».
- **Reporte de Círculo de Crédito** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** reporte sin costo.
- **Consulta de líneas** (Comisión Reguladora de Telecomunicaciones · español): https://portal.crt.gob.mx — **Qué buscar:** plataformas de consulta de las compañías.

### Palabras clave

- *Robo de identidad:* uso de tus datos para hacerse pasar por ti y pedir créditos o hacer trámites.
- *Reporte de crédito:* documento con tus créditos, pagos y consultas.
- *Bloqueo de historial:* servicio que impide que consulten tu historial sin tu autorización.

### Fuentes

Buró de Crédito · Círculo de Crédito · Comisión Reguladora de Telecomunicaciones · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M4 U07. Que dejen de llamarte: REPEP y REUS

**Lo que lograrás:** Inscribir tus números en el REPEP de Profeco y en el REUS de CONDUSEF para recibir menos llamadas de publicidad, y saber qué no cubren.

**Para empezar:** A Carmen le llaman diez veces al día: tarjetas, seguros, tiempos compartidos. Entre tantas llamadas, ya no distingue cuál es de verdad y cuál es un fraude. En esta lección limpiarás tu teléfono con dos registros sin costo.

### Lo esencial (5 minutos)

#### Menos ruido, menos riesgo

Si casi nadie te llama para venderte, una llamada extraña salta a la vista. Por eso conviene reducir las llamadas de publicidad.



#### Dos registros sin costo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| REPEP de Profeco | Publicidad de tiendas, telefonía, viajes. | Fijo o celular, sin vencimiento. |
| REUS de CONDUSEF | Publicidad de bancos y aseguradoras. | Dura dos años. |
| Lo que no cubren | Cobranza, fraudes, encuestas, partidos. | Para fraudes: cuelga. |
| Nadie cobra | Los registros no tienen costo. | Quien cobre, estafa. |

#### Cómo inscribirte

En el REPEP inscribes cada número en repep.profeco.gob.mx o por teléfono. En el REUS te registras en el sitio de CONDUSEF o por su teléfono.

> **Dato vigente:** REPEP: sin costo, fijo o celular; 55 5568 8722 (Ciudad de México) u 800 468 8722; 30 días para que dejen de llamar; no vence. REUS: hasta 45 días naturales; dura dos años; 55 5340 0999 u 800 999 8080. Consultado el 29 de septiembre de 2026 a través de Profeco y la CONDUSEF.



#### Un caso en un minuto

Carmen inscribió su celular y el fijo en el REPEP y se registró en el REUS. Al mes y medio recibía muchas menos llamadas.

> **Idea clave:** los dos registros no tienen costo; nadie te debe cobrar por inscribirte.



#### Comprueba lo que entendiste

1. ¿Qué registro detiene la publicidad de bancos?
*Respuesta:* El REUS de CONDUSEF.

2. ¿Los registros detienen las llamadas de fraude?
*Respuesta:* No. Ante un fraude, cuelgas y verificas.


#### Para recordar

- REPEP: tiendas y servicios.
- REUS: bancos y aseguradoras.
- Sin costo; los fraudes no se detienen con registros.



### Profundiza (5 minutos más)

#### Qué cubre y qué no

| Llamada | ¿Cómo se detiene? |
|---|---|
| Tiendas, telefonía, viajes | REPEP de Profeco |
| Tarjetas, créditos y seguros | REUS de CONDUSEF |
| Cobranza de una deuda | Ningún registro; tiene horario y reglas |
| Encuestas, partidos, beneficencia | No las cubre el REPEP |
| Fraudes | Ningún registro: cuelga y bloquea |



#### Si siguen llamando

Anota número, fecha, hora y empresa. Denuncia en el sitio del REPEP o ante la CONDUSEF después del plazo. Renueva el REUS cada dos años.



#### Registros falsos

Si te llaman para «inscribirte» y te piden pago, códigos o fotos de tu INE, es fraude. Hazlo tú en el sitio oficial.



#### Casos


**Caso 1. Las llamadas de Carmen**

A Carmen le llaman para venderle viajes y tiempos compartidos todo el día.
- *¿Qué hace?* Inscribe sus números en el REPEP y espera 30 días.


**Caso 2. El banco de Lucía**

Un banco llama a Lucía cada semana para ofrecerle una tarjeta.
- *¿Qué hace?* Se registra en el REUS de CONDUSEF.


**Caso 3. El cobro de Elena**

Le llaman a Elena para «inscribirla en el REPEP» por 300 pesos.
- *¿Qué hace?* No paga: el registro no tiene costo y lo hace ella en el sitio oficial.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por inscribirte | Es fraude | Sin costo y oficial |
| Inscribir solo un número | Siguen al otro | Cada número |
| Olvidar renovar el REUS | Vuelve la publicidad | Cada dos años |
| Esperar que detengan fraudes | No lo hacen | Cuelga y bloquea |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde inscribes tu número contra la publicidad de tiendas? a) En el REUS · b) En el REPEP · c) En el Buró de Crédito
2. ¿Cada cuánto renuevas el REUS? a) Cada dos años · b) Nunca, es permanente · c) Cada mes
3. Te cobran por inscribirte en el REPEP. ¿Qué es? a) Una cuota oficial · b) Un servicio exprés · c) Un fraude
**Respuestas:** 1-b: cubre bienes y servicios. 2-a: dura dos años. 3-c: no tiene costo.



#### Ponlo en práctica

Haz la lista de tus números por inscribir y la fecha en que renovarás el REUS.
**Respuesta:** Por ejemplo: celular y fijo en el REPEP y el REUS hoy; renovar el REUS en septiembre de 2028.



#### A tu plan

Inscribe hoy tus números en el REPEP y el REUS y anota en tu calendario la renovación del REUS.



### Para saber más

- **REPEP** (Profeco · español): https://repep.profeco.gob.mx — **Qué buscar:** «Registrar teléfono» y «Denunciar».
- **REUS** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REUS».

### Palabras clave

- *REPEP:* Registro Público para Evitar Publicidad, de Profeco.
- *REUS:* Registro Público de Usuarios, de CONDUSEF, para no recibir publicidad financiera.

### Fuentes

Profeco · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M4 U08. Si ya te pasó: tu plan de respuesta

**Lo que lograrás:** Seguir en orden los pasos cuando ya fuiste víctima: bloquear, llamar al número oficial, reclamar por escrito, acudir a la CONDUSEF, reportar y denunciar, sin culpa.

**Para empezar:** Lucía dio su contraseña en una página falsa. Esa noche vio dos transferencias que no hizo. Sintió vergüenza y pensó en no decirle a nadie. En esta lección aprenderás qué hacer en las primeras horas y por qué no es momento de culparte.

### Lo esencial (5 minutos)

#### Las primeras horas cuentan

Mientras más rápido actúes, más posibilidades tienes de frenar el daño y de que la reclamación proceda. No esperes al estado de cuenta.



#### Tu plan en orden

1. Bloquea tarjetas y accesos desde la app o el número oficial.
2. Cambia tus contraseñas desde otro dispositivo.
3. Presenta tu reclamación por escrito y guarda el folio.
4. Si no te resuelven, acude a la CONDUSEF.
5. Reporta al 088 y presenta denuncia.



#### Sin culpa

Los fraudes están diseñados por profesionales para engañar a cualquiera. Contarlo te protege a ti y a otras personas. Pide ayuda a tu persona de confianza.



#### Un caso en un minuto

Lucía llamó esa misma noche al banco, bloqueó todo y al día siguiente presentó su reclamación con folio. Presentó denuncia y le contó a su hija. Le devolvieron una de las transferencias; la otra siguió en reclamación.

> **Idea clave:** actúa en las primeras horas: bloquea, reclama con folio, acude a la CONDUSEF y denuncia.



#### Comprueba lo que entendiste

1. ¿Qué haces primero?
*Respuesta:* Bloquear tarjetas y accesos.

2. ¿Por qué pedir folio?
*Respuesta:* Es la constancia de tu reclamación.


#### Para recordar

- Bloquea.
- Reclama con folio.
- CONDUSEF, 088 y denuncia.



### Profundiza (5 minutos más)

#### Tu hoja de emergencia

| Qué | Teléfono o sitio |
|---|---|
| Mi banco (atrás de la tarjeta) | |
| CONDUSEF | 55 5340 0999 u 800 999 8080 |
| Reporte de delitos en línea | 088 |
| Emergencias | 911 |
| Mi persona de confianza | |



#### Guarda evidencia

Capturas de mensajes, números de teléfono, fechas y montos, y los folios de cada reclamación. Sin evidencia, la reclamación es más difícil.



#### Avisa sin exponerte

Avisa a tu familia y a tu comunidad para que no caigan en lo mismo, sin compartir tus datos personales ni tus estados de cuenta.

> **Dato vigente:** el 088 de la Guardia Nacional recibe reportes de delitos en línea; la CONDUSEF atiende en el 55 5340 0999 y el 800 999 8080. Consultado el 29 de septiembre de 2026 a través de la Guardia Nacional y la CONDUSEF.



#### Casos


**Caso 1. Las transferencias de Lucía**

Lucía ve dos transferencias que no hizo después de dar su contraseña en una página falsa.
- *¿Qué hace?* Bloquea todo esa misma noche, reclama con folio y denuncia.


**Caso 2. La vergüenza de Carmen**

Carmen cayó en un fraude y no quiere contárselo a nadie.
- *¿Qué hace?* Se lo cuenta a su persona de confianza y sigue su plan: no es su culpa.


**Caso 3. El aviso de Elena**

Elena quiere avisar a sus amigas del fraude que le hicieron.
- *¿Qué hace?* Comparte cómo fue el engaño sin publicar sus datos ni estados de cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar al estado de cuenta | Pierdes tiempo | Actúa hoy |
| Reclamar sin folio | Sin constancia | Pide folio |
| Callar por vergüenza | Nadie te ayuda | Cuéntalo |
| Publicar tus datos | Nuevo riesgo | Avisa sin exponerte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces primero si ves cargos que no reconoces? a) Bloqueas tarjetas y accesos · b) Esperas al estado de cuenta · c) Publicas los cargos en redes
2. ¿A dónde reportas delitos en línea? a) Al 070 · b) Al 088 · c) Al número que venga en un mensaje
3. ¿Qué guardas como evidencia? a) Nada, porque el banco ya tiene todos los registros de tus movimientos · b) Solo el último estado de cuenta · c) Capturas, fechas, montos y folios
**Respuestas:** 1-a: frena el daño. 2-b: el 088 recibe delitos en línea. 3-c: ayudan a tu reclamación.



#### Ponlo en práctica

Llena tu hoja de emergencia con los teléfonos que faltan.
**Respuesta:** Por ejemplo: banco (número de atrás de la tarjeta), CONDUSEF, 088, 911 y el celular de mi persona de confianza.



#### A tu plan

Llena y pega tu hoja de emergencia junto a tu teléfono o en tu carpeta.



### Para saber más

- **Reclamaciones y fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «Portal de Fraudes Financieros» y asesoría.
- **Ciberseguridad** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** reportes al 088.

### Palabras clave

- *Evidencia:* pruebas de lo que pasó.
- *Denuncia:* aviso formal de un delito ante la autoridad.

### Fuentes

CONDUSEF · Guardia Nacional, consultados el 29 de septiembre de 2026.

---


# Parte 6. Módulo 5. Tus cuentas y tu ahorro protegido

## M5 U01. Elige y revisa tus cuentas

**Lo que lograrás:** Revisar tus cuentas bancarias: para qué sirve cada una, cuánto te cuesta, cuánto te paga (GAT) y cerrar las que no usas.

**Para empezar:** Carmen tiene cinco cuentas en tres bancos. Son la de nómina vieja de Arturo, una de ahorro de hace años, la de la casa, la suya y una en dólares. Dos cobran comisión y ninguna le paga casi nada. En esta lección ordenarás tus cuentas.

### Lo esencial (5 minutos)

#### Una cuenta, un propósito

Tener muchas cuentas no te hace más ordenada. Lo que ayuda es que cada cuenta tenga un propósito: gasto de la casa, ahorro, gastos anuales. Las que no tienen propósito cuestan y confunden.



#### Qué revisar de cada cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisiones | Por manejo, saldo mínimo, retiros. | Un costo que se acumula. |
| GAT | Lo que te paga al año antes de impuestos. | Compáralo. |
| Protección | Si es banco, la protege el IPAB. | Módulo 5 U02. |
| Titular y beneficiarios | A nombre de quién y a quién pasa. | Módulo 10. |

#### La GAT

La GAT te dice cuánto te paga una cuenta al año. La **GAT real** descuenta la inflación: si es negativa, tu dinero pierde valor aunque veas intereses.



#### Un caso en un minuto

Carmen dejó tres cuentas: gasto de la casa, su cuenta propia y la de gastos anuales. Canceló por escrito las otras dos y dejó de pagar 250 pesos al mes de comisiones.

> **Idea clave:** menos cuentas, cada una con propósito, sin comisiones y con beneficiarios al día.



#### Comprueba lo que entendiste

1. ¿Qué es la GAT real?
*Respuesta:* Lo que te paga una cuenta al año descontando la inflación.

2. ¿Cómo cierras una cuenta que no usas?
*Respuesta:* Por escrito, con el banco, y guardando la constancia.


#### Para recordar

- Cada cuenta con propósito.
- Revisa comisiones y GAT.
- Cierra por escrito las que no usas.



### Profundiza (5 minutos más)

#### Revisión de tus cuentas

| Cuenta | Propósito | Comisión al mes | GAT | ¿Me quedo? |
|---|---|---|---|---|
| Casa | Gasto diario | 0 | 0.5% | Sí |
| Ahorro viejo | Ninguno | 150 | 0.1% | No |
| Gastos anuales | Predial, seguros | 0 | 3% | Sí |



#### Cómo cerrar una cuenta

Retira el saldo, cancela domiciliaciones, pide la cancelación por escrito y guarda la constancia. Una cuenta que solo dejas de usar puede seguir cobrando comisión y quedar con saldo negativo.



#### Cuentas sin movimiento

Si una cuenta pasa años sin movimientos, el banco puede traspasar el dinero a una cuenta global y, con el tiempo, al gobierno. Revisa tus cuentas olvidadas y reactívalas o ciérralas.

> **Antes de actuar, verifica:** las comisiones y la GAT de cada cuenta están en tu contrato y en el sitio del banco. Compáralas en los simuladores de CONDUSEF.



#### Casos


**Caso 1. Las cinco cuentas de Carmen**

Carmen tiene cinco cuentas y dos cobran comisión sin darle ningún uso.
- *¿Qué hace?* Se queda con las que tienen propósito y cancela por escrito las otras.


**Caso 2. La GAT de Lucía**

La cuenta de ahorro de Lucía tiene GAT real negativa.
- *¿Qué hace?* Busca una opción que al menos le gane a la inflación para su ahorro.


**Caso 3. La cuenta olvidada de Maru**

Maru tiene una cuenta de hace diez años sin movimientos.
- *¿Qué hace?* Pregunta al banco el saldo y decide si la reactiva o la cierra.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Muchas cuentas sin propósito | Comisiones y desorden | Una, un propósito |
| Dejar de usar sin cancelar | Sigue cobrando | Cancela por escrito |
| Ver solo la GAT nominal | Pierdes contra la inflación | Mira la GAT real |
| Olvidar cuentas viejas | Tu dinero se traspasa | Revísalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué indica la GAT real? a) Lo que te cobra el banco cada mes por manejo · b) Lo que te paga descontando la inflación · c) El saldo mínimo
2. ¿Cómo cancelas una cuenta? a) Por escrito y con constancia · b) Dejando de usarla para siempre · c) Retirando todo el saldo en el cajero
3. Una cuenta cobra 150 al mes y no la usas. ¿Cuánto pagas al año? a) 150 · b) 1,500 · c) 1,800
**Respuestas:** 1-b: descuenta la inflación. 2-a: si solo la dejas, sigue cobrando. 3-c: 150 por 12 son 1,800.



#### Ponlo en práctica

Dos cuentas cobran 150 y 100 al mes. ¿Cuánto ahorras al año si las cancelas?
**Respuesta:** 250 por 12: 3,000 al año.



#### A tu plan

Llena la tabla de revisión con tus cuentas y decide cuáles cierras.



### Para saber más

- **Simuladores y comparadores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuentas de ahorro» y comparadores de comisiones.

### Palabras clave

- *GAT:* Ganancia Anual Total: lo que te paga una cuenta o inversión al año, antes de impuestos.
- *Comisión:* cobro del banco por un servicio.
- *Domiciliación:* pago automático de un servicio con cargo a tu cuenta.

### Fuentes

CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M5 U02. El seguro del IPAB: hasta cuánto te protege

**Lo que lograrás:** Identificar qué protege el seguro de depósitos del IPAB, hasta cuánto (400,000 UDIS por persona y por banco) y cómo repartir tu ahorro si tienes más.

**Para empezar:** Lucía tiene 4.5 millones de pesos de la venta de una casa, todos en una cuenta del mismo banco. Leyó que «el gobierno protege tus ahorros» y está tranquila. Pero la protección tiene un límite. En esta lección verás cuánto cubre y cómo organizarte.

### Lo esencial (5 minutos)

#### Qué es el IPAB

El IPAB protege tus depósitos si un banco quiebra. Lo hace de forma automática y sin costo, sin trámites.



#### Lo esencial del seguro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Por persona | Suma todas tus cuentas en un mismo banco. | Un solo límite por banco. |
| Por banco | Si tienes en dos bancos, cada uno tiene su límite. | Repartir ayuda. |
| Qué protege | Cuentas, pagarés y depósitos a plazo en bancos. | Depósitos. |
| Qué no | Fondos, acciones, Cetes, seguros, SOFIPO. | Otras reglas. |

#### El límite

El límite es de 400,000 UDIS por persona y por banco, unos 3.5 millones de pesos en septiembre de 2026.

> **Dato vigente:** el seguro de depósitos del IPAB cubre hasta 400,000 UDIS por persona y por banco; al 27 de septiembre de 2026 equivalían a unos 3,531,000 pesos. Consultado el 29 de septiembre de 2026 a través del IPAB y la CONDUSEF.



#### Un caso en un minuto

Lucía repartió su dinero: una parte en su banco y otra en un segundo banco. Cada parte quedó dentro del límite. Una tercera parte la dejó en Cetes, que tienen otra forma de respaldo (M5 U04).

> **Idea clave:** el IPAB protege hasta 400,000 UDIS por persona y por banco; si tienes más, reparte.



#### Comprueba lo que entendiste

1. ¿El límite es por cuenta o por persona?
*Respuesta:* Por persona y por banco: todas tus cuentas en un banco suman un solo límite.

2. ¿El IPAB protege un fondo de inversión?
*Respuesta:* No. Protege depósitos bancarios.


#### Para recordar

- 400,000 UDIS por persona y por banco.
- Protege depósitos, no inversiones.
- Si tienes más, reparte.



### Profundiza (5 minutos más)

#### Ejemplo de reparto

| Dónde | Monto | ¿Dentro del límite? |
|---|---|---|
| Banco A | 3,000,000 | Sí |
| Banco B | 1,000,000 | Sí |
| Cetes | 500,000 | No aplica: respaldo del gobierno |
| **Total** | **4,500,000** | |



#### Cuentas mancomunadas

En una cuenta con dos titulares, la protección se reparte según las reglas del IPAB, no se duplica automáticamente. Pregunta en tu banco cómo aplica a tu cuenta.



#### Verifica que sea banco

Solo protege a bancos autorizados. Algunas apps no son bancos. Revisa en el padrón de la CNBV que tu institución sea banco (M2 U03).

> **Antes de actuar, verifica:** el valor de la UDI del día en el sitio de Banxico para saber el límite en pesos.



#### Casos


**Caso 1. Los 4.5 millones de Lucía**

Lucía tiene 4.5 millones en una sola cuenta del mismo banco.
- *¿Qué hace?* Reparte su dinero para que cada parte quede dentro del límite.


**Caso 2. Las tres cuentas de Carmen**

Carmen tiene tres cuentas en el mismo banco y cree que cada una tiene su propio límite.
- *¿Qué hace?* Suma las tres: el límite es por persona y por banco, no por cuenta.


**Caso 3. El fondo de Elena**

Elena cree que su fondo de inversión está protegido por el IPAB.
- *¿Qué hace?* Entiende que el IPAB protege depósitos, no fondos, y revisa el riesgo del fondo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que todo está protegido | Sorpresas | Solo depósitos |
| Contar el límite por cuenta | Rebasas el límite | Por persona y banco |
| Todo en un solo banco | Parte sin protección | Reparte |
| Suponer que una app es banco | Sin protección | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Hasta cuánto protege el IPAB? a) Todo lo que tengas en el banco · b) 400,000 UDIS por persona y por banco · c) 400,000 pesos
2. ¿Qué protege el IPAB? a) Tus depósitos bancarios · b) Tus fondos de inversión y acciones · c) Tu AFORE
3. Tienes 5 millones en un banco. ¿Qué conviene? a) Dejarlos juntos por comodidad, ya que el IPAB los cubre todos · b) Pasar todo a efectivo en casa · c) Repartirlos para quedar dentro del límite
**Respuestas:** 1-b: el límite está en UDIS. 2-a: solo depósitos. 3-c: así todo queda protegido.



#### Ponlo en práctica

Con el límite de unos 3.53 millones, ¿cuánto de 5 millones en un solo banco queda sin protección?
**Respuesta:** 5 millones menos 3.53 millones: unos 1.47 millones sin protección.



#### A tu plan

Suma lo que tienes en depósitos en cada banco y revisa si alguno pasa del límite.



### Para saber más

- **Seguro de depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** qué protege y cuánto.
- **Valor de la UDI** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «UDIS», para convertir el límite a pesos.

### Palabras clave

- *IPAB:* Instituto para la Protección al Ahorro Bancario, que protege tus depósitos si un banco quiebra.
- *UDIS:* unidad cuyo valor en pesos cambia con la inflación.
- *Cuenta mancomunada:* cuenta con dos o más titulares.

### Fuentes

IPAB · CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M5 U03. Tu fondo de emergencia

**Lo que lograrás:** Calcular y apartar tu fondo de emergencia, con una parte pensada para gastos médicos como deducibles y coaseguros.

**Para empezar:** Elena tuvo que operarse de la vesícula. Su seguro pagó casi todo, pero ella debía cubrir 25,000 de deducible y coaseguro. No los tenía y los pagó con la tarjeta. En esta lección apartarás el dinero para esos momentos.

### Lo esencial (5 minutos)

#### Qué es

Tu fondo de emergencia es dinero apartado solo para imprevistos: una reparación, una enfermedad, un gasto que no esperabas. No es para vacaciones ni para regalos.



#### ¿Cuánto?

Una guía es de tres a seis meses de tu gasto, más lo que tendrías que pagar si usas tu seguro médico.
- Tu mes promedio: **42,500**
- Meses: **3**
- Deducible y coaseguro: **25,000**
- Tu fondo: **152,500**
Empieza con una meta pequeña y crece poco a poco.


#### Dónde

Tu fondo debe estar disponible pronto y sin riesgo de perder: una cuenta bancaria protegida por el IPAB o Cetes de corto plazo (M5 U04). Separado de tu cuenta de gasto diario.



#### Un caso en un minuto

Elena calculó su fondo, lo abrió en una cuenta aparte y aparta cada quincena. Cuando su hijo se fracturó un brazo, pagó el deducible sin tocar la tarjeta.

> **Idea clave:** tu fondo de emergencia es de tres a seis meses de gasto, más tu deducible y coaseguro médico.



#### Comprueba lo que entendiste

1. ¿Para qué es el fondo de emergencia?
*Respuesta:* Solo para imprevistos.

2. ¿Por qué incluir el deducible médico?
*Respuesta:* Porque si usas tu seguro, esa parte la pagas tú.


#### Para recordar

- De tres a seis meses de gasto.
- Más deducible y coaseguro.
- Separado y disponible.



### Profundiza (5 minutos más)

#### Tu fondo por etapas

| Etapa | Meta | Ejemplo |
|---|---|---|
| 1 | Un mes de gasto | 42,500 |
| 2 | Deducible y coaseguro | 25,000 |
| 3 | Tres meses de gasto | 127,500 |
| 4 | Seis meses si tu ingreso es incierto | 255,000 |



#### Si lo usas

Si usas tu fondo, vuelve a llenarlo antes de otros ahorros. Es tu primera línea de protección.



#### No es inversión

Tu fondo no busca el mayor rendimiento, sino estar disponible y seguro. No lo metas en inversiones que pueden bajar ni en plazos largos.

> **Antes de actuar, verifica:** el deducible y el coaseguro de tu póliza (módulo 8) para calcular esa parte de tu fondo.



#### Casos


**Caso 1. La operación de Elena**

Elena debe pagar 25,000 de deducible y coaseguro y no tiene ahorro para eso.
- *¿Qué hace?* A partir de ahora aparta ese monto en su fondo de emergencia.


**Caso 2. El viaje de Carmen**

Carmen quiere usar su fondo de emergencia para un viaje de aniversario.
- *¿Qué hace?* Ahorra aparte para el viaje y deja el fondo solo para imprevistos.


**Caso 3. El fondo de Maru**

Maru quiere poner su fondo en acciones para que «rinda más».
- *¿Qué hace?* Lo deja en una cuenta protegida o en Cetes de corto plazo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener fondo | Pagas con tarjeta | Empieza pequeño |
| Usarlo para gustos | Sin protección | Solo imprevistos |
| Invertirlo con riesgo | Puede bajar | Disponible y seguro |
| No reponerlo | Te quedas sin red | Llénalo primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde conviene tu fondo de emergencia? a) En acciones, para que rinda más a largo plazo · b) En una cuenta protegida o Cetes de corto plazo · c) En un plazo fijo de cinco años
2. Tu gasto es 40,000 al mes. ¿Cuánto es un fondo de tres meses, sin deducible? a) 120,000 · b) 40,000 · c) 400,000
3. Usaste tu fondo. ¿Qué haces después? a) Lo repones antes que otros ahorros · b) Lo dejas vacío hasta el próximo año · c) Lo sustituyes con tu tarjeta de crédito
**Respuestas:** 1-b: disponible y seguro. 2-a: 40,000 por tres. 3-a: es tu primera red.



#### Ponlo en práctica

Tu mes promedio es 35,000 y tu deducible más coaseguro máximo es 20,000. ¿Cuánto es tu fondo de tres meses?
**Respuesta:** 35,000 por 3 son 105,000, más 20,000: 125,000.



#### A tu plan

Calcula tu fondo de emergencia y abre una cuenta aparte para irlo llenando.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Fondo de emergencia:* dinero apartado solo para imprevistos, disponible de inmediato.
- *Deducible:* la cantidad que pagas tú antes de que el seguro empiece a pagar.
- *Coaseguro:* el porcentaje del gasto que pagas tú después del deducible.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M5 U04. Ahorro con Cetes y BONDDIA

**Lo que lograrás:** Identificar Cetesdirecto, los Cetes y BONDDIA para ahorrar a corto plazo con respaldo del gobierno federal, y cómo empezar.

**Para empezar:** Maru tiene 60,000 de sus ventas en una cuenta que no le paga casi nada. Su comadre le habló de «los Cetes», pero a Maru le suena a algo de gente rica y complicado. En esta lección verás que puedes empezar con poco y sin intermediarios.

### Lo esencial (5 minutos)

#### Qué son los Cetes

Los Cetes son deuda del gobierno federal: le prestas dinero y te lo devuelve con un rendimiento al terminar el plazo (28, 91, 182 días o más).



#### Cetesdirecto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sin intermediarios | Programa del gobierno para invertir directo. | Sin comisiones. |
| Monto pequeño | Puedes empezar con poco. | Accesible. |
| Plazos | 28 días o más. | Elige según cuándo lo necesitas. |
| BONDDIA | Puedes retirar cualquier día hábil. | Para tu fondo de emergencia. |

#### Reinversión

Al terminar el plazo, puedes pedir que se reinvierta de forma automática. Así no tienes que volver a hacer nada cada mes.



#### Un caso en un minuto

Maru abrió su cuenta en Cetesdirecto desde el sitio oficial, con su hija a un lado explicándole. Puso una parte en BONDDIA para emergencias y otra en Cetes a 91 días con reinversión.

> **Idea clave:** Cetesdirecto te permite ahorrar con respaldo del gobierno federal, sin comisiones y con montos pequeños.



#### Comprueba lo que entendiste

1. ¿Qué es BONDDIA?
*Respuesta:* Una opción de Cetesdirecto que permite retirar cualquier día hábil.

2. ¿Cetesdirecto cobra comisión?
*Respuesta:* No.


#### Para recordar

- Deuda del gobierno federal.
- Sin comisiones, desde montos pequeños.
- BONDDIA para liquidez diaria.



### Profundiza (5 minutos más)

#### Cómo elegir el plazo

| Si necesitas el dinero… | Considera |
|---|---|
| En cualquier momento | BONDDIA |
| En uno a tres meses | Cetes a 28 o 91 días |
| En seis meses a un año | Cetes a 182 o 364 días |



#### Impuestos

Los rendimientos pagan impuestos; en 2026 la retención es de 0.90% anual sobre el capital, que se acredita en tu declaración (módulo 9).



#### Seguridad

Entra solo por el sitio oficial de Cetesdirecto, escribiendo tú la dirección. Hay páginas falsas que lo imitan. Nadie de Cetesdirecto te llama para ofrecerte «rendimientos especiales».

> **Antes de actuar, verifica:** la tasa del día y el monto mínimo en el sitio oficial de Cetesdirecto; cambian con el tiempo.



#### Casos


**Caso 1. Los 60,000 de Maru**

Maru tiene 60,000 en una cuenta que no le paga casi nada.
- *¿Qué hace?* Abre Cetesdirecto y reparte entre BONDDIA y Cetes según cuándo lo necesita.


**Caso 2. La llamada a Lucía**

Alguien «de Cetesdirecto» le ofrece a Lucía una tasa especial si deposita hoy.
- *¿Qué hace?* Cuelga: Cetesdirecto no llama para ofrecer tasas; entra solo al sitio oficial.


**Caso 3. El plazo de Elena**

Elena necesitará dinero para las inscripciones en tres meses.
- *¿Qué hace?* Elige Cetes a 91 días para tenerlo disponible a tiempo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es para ricos | No empiezas | Montos pequeños |
| Plazo más largo del necesario | No tienes el dinero | Elige por fecha |
| Entrar por enlaces | Página falsa | Sitio oficial |
| Creer ofertas por teléfono | Fraude | Nadie llama |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué son los Cetes? a) Acciones de empresas mexicanas grandes · b) Deuda del gobierno federal · c) Un seguro de ahorro
2. ¿Qué eliges si puedes necesitar el dinero cualquier día? a) BONDDIA · b) Cetes a 364 días, que pagan más · c) Un plazo fijo largo
3. Te llaman de «Cetesdirecto» con una tasa especial. ¿Qué haces? a) Aceptas si la tasa es mejor que la que ves en el sitio oficial · b) Pides que te manden el enlace · c) Cuelgas y entras solo al sitio oficial
**Respuestas:** 1-b: le prestas al gobierno. 2-a: retiro diario. 3-c: no llaman para ofrecer tasas.



#### Ponlo en práctica

Necesitas 30,000 en tres meses y 50,000 son tu fondo de emergencia. ¿Cómo los repartes?
**Respuesta:** Los 30,000 en Cetes a 91 días y los 50,000 en BONDDIA, para poder retirarlos cualquier día hábil.



#### A tu plan

Entra al sitio oficial de Cetesdirecto con tu persona de confianza y revisa los requisitos para abrir tu cuenta.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com — **Qué buscar:** requisitos, BONDDIA y tasas del día.

### Palabras clave

- *Cetes:* Certificados de la Tesorería: deuda del gobierno federal que te paga un rendimiento a un plazo.
- *BONDDIA:* opción de Cetesdirecto que permite retirar cualquier día hábil.
- *Reinversión:* volver a invertir automáticamente al terminar el plazo.

### Fuentes

Cetesdirecto · Ley de Ingresos de la Federación 2026, consultados el 29 de septiembre de 2026.

---

## M5 U05. Tu tarjeta de crédito: pago mínimo, pago para no generar intereses y meses sin intereses

**Lo que lograrás:** Leer tu estado de cuenta, distinguir el pago mínimo del pago para no generar intereses, usar bien los meses sin intereses y saber cuándo una tarjeta te conviene.

**Para empezar:** Carmen usa la tarjeta que le dio su banco y siempre paga «lo que dice el estado de cuenta»: el mínimo. Su saldo no baja desde hace un año. En esta lección verás por qué.

### Lo esencial (5 minutos)

#### Los tres números de tu estado de cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pago mínimo | Evita el atraso, pero cobra intereses. | La deuda casi no baja. |
| Pago para no generar intereses | Lo que gastaste en el periodo. | No pagas intereses. |
| Fecha límite de pago | El día para pagar. | Después hay intereses y cargos. |
| CAT | El costo anual total. | Para comparar tarjetas. |

#### Una tarjeta es un préstamo

La tarjeta de crédito no es dinero extra. Si pagas el total para no generar intereses cada mes, te sirve sin costo. Si pagas el mínimo, pagas intereses altos sobre intereses.



#### Meses sin intereses

Los meses sin intereses convienen si el precio es el mismo que de contado y si todos tus pagos caben en tu presupuesto. Si te atrasas en uno, puedes perder el beneficio y pagar intereses.



#### Un caso en un minuto

Carmen dejó de usar la tarjeta, pagó más del mínimo cada mes y en ocho meses la dejó en cero. Ahora la usa solo para lo que puede pagar completo en la fecha límite.

> **Idea clave:** paga el total para no generar intereses antes de la fecha límite; el mínimo solo evita el atraso.



#### Comprueba lo que entendiste

1. ¿Qué pago evita los intereses?
*Respuesta:* El pago para no generar intereses.

2. ¿Cuándo convienen los meses sin intereses?
*Respuesta:* Cuando el precio es igual al de contado y los pagos caben en tu presupuesto.


#### Para recordar

- La tarjeta es un préstamo.
- Paga el total antes de la fecha límite.
- Meses sin intereses solo si caben.



### Profundiza (5 minutos más)

#### Pon candados

Activa alertas por cada compra y pon un límite en la app. Si tienes el dinero en tu cuenta, domicilia el pago para no generar intereses (M3 U03).



#### Tarjetas adicionales

Si das una tarjeta adicional a un hijo o hija, todo lo que gaste se suma a tu deuda y a tu historial. Pon un límite bajo o no la des.

> **Dato vigente:** el Banco de México fija reglas para el pago mínimo de las tarjetas de crédito. Tu estado de cuenta debe mostrar el pago mínimo y el pago para no generar intereses. También cuánto tardarías en liquidar si pagas solo el mínimo. Consultado el 30 de septiembre de 2026 a través del Banco de México y CONDUSEF.

> **Antes de actuar, verifica:** en tu estado de cuenta el pago para no generar intereses y la fecha límite de pago.



#### Casos


**Caso 1. El mínimo de Carmen**

Carmen paga siempre el mínimo y su saldo no baja.
- *¿Qué hace?* Deja de usarla y paga más del mínimo cada mes.


**Caso 2. El refrigerador de Maru**

Maru quiere un refrigerador a 12 meses sin intereses, pero ya tiene dos compras así.
- *¿Qué hace?* Suma los tres pagos y compra solo si caben en su presupuesto.


**Caso 3. La adicional de Elena**

El hijo de Elena le pide una tarjeta adicional para sus gastos.
- *¿Qué hace?* Si se la da, le pone un límite bajo sabiendo que la deuda es suya.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar solo el mínimo | La deuda no baja | Paga el total |
| Pagar tarde | Intereses y cargos | Fecha límite |
| Meses sin intereses encimados | No te alcanza | Suma pagos |
| Adicional sin límite | Tu deuda crece | Límite bajo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Maru y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pago te libra de intereses? a) El pago mínimo · b) El pago para no generar intereses · c) Cualquier pago antes de fin de mes
2. Tu hijo gasta con una tarjeta adicional. ¿De quién es la deuda? a) Tuya · b) De tu hijo · c) Del banco
3. ¿Cuándo conviene comprar a meses sin intereses? a) Siempre que haya oferta · b) Cuando el precio es mayor que el de contado · c) Cuando el precio es igual al de contado y el pago cabe en tu presupuesto
**Respuestas:** 1-b: pagas lo del periodo sin intereses. 2-a: la titular responde. 3-c: si no, se vuelve carga.



#### Ponlo en práctica

Debes 6,000 en la tarjeta y pagas 1,000 más de lo que gastas cada mes. ¿En cuántos meses la dejas en cero, sin contar intereses?
**Respuesta:** En 6 meses.



#### A tu plan

Revisa tu último estado de cuenta: anota el pago para no generar intereses, la fecha límite y el CAT.



### Para saber más

- **Tarjetas de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «tarjetas de crédito» y el comparador.
- **Pago mínimo** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «tarjetas de crédito pago mínimo».

### Palabras clave

- *Pago mínimo:* lo menos que puedes pagar para no atrasarte; genera intereses.
- *Pago para no generar intereses:* lo que gastaste en el periodo; si lo pagas, no hay intereses.
- *CAT:* costo anual total de un crédito, para comparar.

### Fuentes

Banco de México · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M5 U06. Tu historial de crédito: Buró, Círculo y ser aval

**Lo que lograrás:** Identificar qué es tu historial de crédito, pedir tu reporte sin costo una vez al año, reclamar errores y decidir con información antes de ser aval.

**Para empezar:** A Lucía le negaron una tarjeta en la tienda «por el Buró». Nunca pidió un crédito a su nombre, pero hace años firmó como aval de su sobrino. En esta lección verás qué hay en tu historial y cómo cuidarlo.

### Lo esencial (5 minutos)

#### Qué es tu historial

Las sociedades de información crediticia reciben de bancos y tiendas cómo pagas. Los otorgantes lo consultan para decidir si te prestan y a qué costo. Estar en el Buró no es malo: lo que importa es cómo pagas.

> **Dato vigente:** puedes pedir tu reporte especial sin costo una vez cada 12 meses en Buró de Crédito y en Círculo de Crédito. Así lo dice la Ley para Regular las Sociedades de Información Crediticia, artículo 40. Consultado el 30 de septiembre de 2026 a través de sus sitios oficiales y CONDUSEF.



#### Cuida tu historial

1. Pide tu reporte sin costo una vez al año en cada sociedad, en su sitio oficial.
2. Revisa que todos los créditos sean tuyos y los saldos correctos.
3. Si hay un error, reclama sin costo ante la sociedad.
4. Paga a tiempo: eso es lo que más mejora tu historial.



#### Ser aval

Si firmas como aval, la deuda también es tuya si la otra persona no paga, y puede aparecer en tu historial. Firma solo si podrías pagarla tú.



#### Un caso en un minuto

Lucía pidió su reporte sin costo y encontró el crédito de su sobrino con atraso. Habló con él para ponerse al corriente y anotó en su carpeta no volver a firmar como aval sin revisar si podría pagar.

> **Idea clave:** revisa tu reporte sin costo cada año, reclama errores sin costo y firma como aval solo si podrías pagar esa deuda.



#### Comprueba lo que entendiste

1. ¿Cada cuándo puedes pedir tu reporte sin costo?
*Respuesta:* Una vez cada 12 meses en cada sociedad.

2. ¿Qué pasa si eres aval y la otra persona no paga?
*Respuesta:* Te pueden cobrar a ti y afectar tu historial.


#### Para recordar

- Reporte sin costo cada año.
- Reclamar no tiene costo.
- Aval solo si podrías pagar.



### Profundiza (5 minutos más)

#### Nadie «limpia» tu historial

Los despachos que cobran por «borrar tu Buró» son fraude. La información correcta se queda el tiempo que marca la ley, y las reclamaciones las haces tú, sin costo.



#### Cuánto tiempo se queda

Los atrasos se eliminan después de un plazo que depende del monto de la deuda. Consulta la guía de CONDUSEF sobre plazos.

> **Antes de actuar, verifica:** que estás en el sitio oficial de Buró de Crédito o Círculo de Crédito. Nadie te llama para cobrarte por tu reporte.



#### Casos


**Caso 1. El aval de Lucía**

Lucía encuentra en su reporte el crédito de su sobrino con atraso.
- *¿Qué hace?* Habla con él para ponerse al corriente y no vuelve a firmar sin revisar.


**Caso 2. El error de Elena**

En el reporte de Elena aparece una tarjeta que nunca tuvo.
- *¿Qué hace?* Reclama sin costo ante la sociedad y revisa si hay robo de identidad (M4 U06).


**Caso 3. El despacho de Carmen**

A Carmen le ofrecen «limpiar su Buró» por 3,000 pesos.
- *¿Qué hace?* No paga: es fraude y reclamar no tiene costo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Nunca revisar | No ves errores | Reporte anual |
| Firmar como aval sin pensar | Deuda ajena | Solo si podrías pagar |
| Pagar a despachos | Fraude | Reclamo sin costo |
| Creer que estar en Buró es malo | Miedo | Importa cómo pagas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Elena y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta tu reporte especial una vez al año? a) Nada · b) Lo que cobre el despacho · c) Un mes de intereses
2. Firmaste como aval y la otra persona no paga. ¿Qué pasa? a) Nada, no es tu crédito · b) Te pueden cobrar y afectar tu historial · c) El banco lo perdona
3. Te ofrecen borrar tu Buró por una cuota. ¿Qué es? a) Un servicio útil · b) Un trámite de CONDUSEF · c) Un fraude
**Respuestas:** 1-a: la ley lo hace sin costo. 2-b: el aval responde. 3-c: nadie borra información correcta.



#### Ponlo en práctica

Escribe los dos reportes que pedirás este año y en qué mes.
**Respuesta:** Por ejemplo: Buró de Crédito en febrero y Círculo de Crédito en agosto.



#### A tu plan

Pide tu reporte sin costo en una de las dos sociedades y anota la fecha en tu carpeta.



### Para saber más

- **Reporte de crédito especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.
- **Reporte de crédito especial** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.
- **Historial crediticio** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «historial crediticio» y «plazos de eliminación».

### Palabras clave

- *Historial de crédito:* registro de cómo pagas tus créditos.
- *Aval:* persona que se compromete a pagar si quien pidió el crédito no paga.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M5 U07. Aval, obligado solidario, fiador y referencia: ¿qué firmas?

**Lo que lograrás:** Distinguir aval, obligado solidario, fiador, garantía y referencia personal, saber qué te pueden cobrar en cada caso y decidir antes de firmar por otra persona.

**Para empezar:** El sobrino de Lucía le pide que firme como obligada solidaria para rentar un departamento. La hija de Elena la puso de referencia en su primera tarjeta. Ninguna sabe qué le pueden cobrar. En esta lección verás qué implica cada papel.

### Lo esencial (5 minutos)

#### Cada papel, una responsabilidad

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aval | Firma el pagaré: si no pagan, te cobran a ti todo. | Aparece en tu historial. |
| Obligado solidario | Respondes por todo el contrato como si fueras quien pidió. | Te pueden cobrar directo. |
| Fiador | Común en rentas: pagas si la otra persona no paga. | Revisa el contrato. |
| Referencia personal | Solo das tus datos de contacto. | No te pueden cobrar. |

#### «Garante» y «garantía»

«Garante» es una palabra general para quien respalda un crédito: en el contrato aparece como aval, obligado solidario o fiador. Una garantía es distinta: es un bien que puedes perder si no pagas.



#### Ser referencia no es ser aval

Cuando alguien pide una tarjeta o un préstamo, le piden referencias: nombre y teléfono de personas que lo conocen. Ser referencia personal no te obliga a pagar nada. Si no firmaste como aval, obligado solidario o fiador, esa deuda no es tuya.

> **Dato vigente:** las reglas de la CONDUSEF solo permiten a los despachos de cobranza cobrar al deudor, a sus avales y a sus obligados solidarios. No pueden cobrar a referencias personales ni amenazar a familiares o compañeros de trabajo. Las quejas se presentan en el REDECO. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF.



#### Un caso en un minuto

Lucía leyó el contrato: como obligada solidaria respondería por toda la renta. Le ofreció a su sobrino ayudarle a buscar un seguro de renta en lugar de firmar. Elena supo que, como referencia, no le pueden cobrar nada.

> **Idea clave:** aval, obligado solidario y fiador pagan si la otra persona no paga; una referencia solo da sus datos y no le pueden cobrar. Lee qué firmas y hazlo solo si podrías pagar esa deuda.



#### Comprueba lo que entendiste

1. ¿Te pueden cobrar si solo fuiste referencia personal?
*Respuesta:* No. Solo diste tus datos; no firmaste ninguna obligación.

2. ¿Qué pasa si firmas como aval y la otra persona no paga?
*Respuesta:* Te pueden cobrar a ti y puede aparecer en tu historial.


#### Para recordar

- Aval, obligado solidario y fiador: pagan si el otro no paga.
- Referencia: solo datos; no te cobran.
- Firma solo si podrías pagar.



### Profundiza (5 minutos más)

#### ¿Qué firmas?

| Papel | ¿Firmas? | ¿Te pueden cobrar? | ¿Afecta tu historial? |
|---|---|---|---|
| Aval | Sí, el pagaré | Sí, todo | Puede aparecer |
| Obligado solidario | Sí, el contrato | Sí, directo | Puede aparecer |
| Fiador | Sí, el contrato | Sí, si el otro no paga | Puede aparecer |
| Referencia personal | No | No | No |
| Titular con tarjeta adicional | Sí, como titular | Sí, todo lo que gaste la adicional | Sí |



#### Cómo decir que no

Pedirte que seas aval es pedirte que te hagas cargo de una deuda. Puedes decir: «Te quiero ayudar, pero no puedo firmar una deuda que no podría pagar». Ofrece otra ayuda: acompañarle a comparar créditos o armar un presupuesto.



#### Si te llaman como referencia

Si un despacho te presiona para pagar una deuda de la que solo eres referencia, no pagues ni des datos de más. Pide el nombre del despacho, anota fecha y hora y preséntalo en el REDECO de la CONDUSEF.

> **Antes de actuar, verifica:** qué dice el documento que te piden firmar (pagaré, contrato, solicitud) y en qué papel apareces.



#### Casos


**Caso 1. La renta del sobrino**

El sobrino de Lucía le pide que firme como obligada solidaria de su renta.
- *¿Qué hace Lucía?* Lee el contrato y firma solo si podría pagar la renta; si no, ofrece otra ayuda.


**Caso 2. La tarjeta de la hija de Elena**

A Elena le piden firmar como aval de la primera tarjeta de su hija «por si acaso».
- *¿Qué hace?* Pregunta si basta con ser referencia; firma como aval solo si podría pagar todo.


**Caso 3. La llamada a Maru**

Un despacho llama a Maru para cobrarle la deuda de un compañero del que solo fue referencia.
- *¿Qué hace?* No paga, pide el nombre del despacho y se queja en el REDECO.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin leer | Deuda ajena | Lee tu papel |
| Creer que la referencia paga | Pagas sin deber | No te obliga |
| Aval por compromiso | Pagas tú | Solo si podrías pagar |
| Adicional sin límite | Tu deuda crece | Límite bajo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Elena y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Diste tu nombre y teléfono como referencia para la tarjeta de un amigo. ¿Te pueden cobrar? a) Sí, la mitad · b) Sí, si él no paga · c) No, solo diste tus datos
2. ¿Quién responde por todo el contrato como si hubiera pedido el crédito? a) El obligado solidario · b) La referencia personal · c) El vendedor
3. Un despacho te presiona para pagar una deuda de la que solo eres referencia. ¿Qué haces? a) Pagas para que dejen de llamar · b) No pagas y te quejas en el REDECO · c) Das los datos de tu amigo y los de su familia
**Respuestas:** 1-c: la referencia no se obliga. 2-a: por eso le pueden cobrar directo. 3-b: no pueden cobrar a referencias.



#### Ponlo en práctica

Te piden ser aval de un préstamo de 30,000 a 24 meses. Si la otra persona deja de pagar a la mitad, ¿cuánto podrían cobrarte, sin contar intereses?
**Respuesta:** Unos 15,000 pesos: lo que falte por pagar, más intereses y cargos.



#### A tu plan

Antes de firmar por alguien, pregunta en qué papel apareces y decide solo si podrías pagar esa deuda.



### Para saber más

- **Aval y obligado solidario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «aval» y «obligado solidario».
- **Quejas contra despachos de cobranza** (CONDUSEF, REDECO · español): https://redeco.condusef.gob.mx — **Qué buscar:** si el despacho está registrado y cómo quejarte si te amenazan o cobran a terceros.

### Palabras clave

- *Aval:* persona que firma un pagaré y se obliga a pagar si quien pidió el crédito no paga.
- *Obligado solidario:* persona que responde por todo el contrato como si hubiera pedido el crédito.
- *Fiador:* persona que se obliga a pagar si el deudor no paga; común en contratos de renta.
- *Referencia personal:* persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no se obliga a pagar.

### Fuentes

CONDUSEF (disposiciones para despachos de cobranza y REDECO), consultados el 30 de septiembre de 2026.

---

## M5 U08. Préstamos de nómina y a cuenta de tu pensión

**Lo que lograrás:** Explicar cómo funcionan los préstamos que se descuentan de la nómina o de la pensión, cuánto te pueden descontar y cómo evitar a los intermediarios que cobran de más.

**Para empezar:** A Lucía la llaman casi a diario: «Por ser pensionada, tiene un préstamo preaprobado; solo mándenos su INE y su estado de cuenta». Y a Raúl, el esposo de Maru, le ofrecen un crédito que se descuenta de su quincena de maestro.

### Lo esencial (5 minutos)

#### Préstamos que se descuentan solos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Préstamo de nómina | Del banco donde cobras. | Se cobra de tu cuenta. |
| Préstamo a cuenta de pensión | IMSS (Ley 73) o financieras con convenio. | El IMSS retiene el pago. |
| Préstamo del ISSSTE | Para trabajadores y pensionados del Estado. | Pide en el ISSSTE. |
| «Preaprobado» por teléfono | Piden INE y estado de cuenta. | Riesgo de fraude. |

#### El tope y el seguro

Si tu pensión del IMSS es de la Ley 73, el descuento de un préstamo a cuenta de tu pensión **no puede pasar de 30%** de ella. Estos préstamos incluyen un seguro. Si la persona fallece, la deuda se cancela y no pasa a la familia.

> **Dato vigente:** los préstamos a cuenta de pensión del IMSS son para pensionados de la Ley del Seguro Social de 1973. El descuento es de hasta 30% de la pensión e incluyen un seguro que cancela la deuda por fallecimiento. Las financieras deben tener convenio con el IMSS. Consultado el 30 de septiembre de 2026 a través del IMSS y medios nacionales.



#### Verifica antes de dar un dato

Solo trata con financieras que aparezcan en el **listado oficial del IMSS** (o en el ISSSTE, si es tu caso). Nadie de una institución seria te pide tu NIP, tus contraseñas o un pago por adelantado para «liberar» tu préstamo.



#### Un caso en un minuto

Lucía colgó. Revisó el listado de financieras con convenio en la página del IMSS y comparó dos: la que más le prestaba cobraba 35,000 más en total. Pidió menos y eligió el pago que le dejaba vivir tranquila.

> **Idea clave:** un préstamo que se descuenta solo sigue siendo deuda. Compara el total a pagar y trata solo con financieras del listado oficial. Nunca pagues para que te «liberen» un préstamo.



#### Comprueba lo que entendiste

1. ¿Cuánto es lo más que te pueden descontar de tu pensión del IMSS por un préstamo?
*Respuesta:* 30% de tu pensión.

2. ¿Qué haces si te piden un pago para liberar tu préstamo?
*Respuesta:* No pagas: es señal de fraude.


#### Para recordar

- Tope de 30% de la pensión.
- Solo financieras del listado oficial.
- Nunca pagues por adelantado.



### Profundiza (5 minutos más)

#### Compara antes de firmar

| Pregunta | Anota |
|---|---|
| Monto que recibes | |
| Pago mensual | |
| Número de pagos | |
| Total a pagar | |
| CAT | |
| ¿Qué te queda de tu pensión o quincena? | |



#### Renovar antes de terminar

Te ofrecerán «renovar» para darte dinero nuevo. Con eso vuelves a empezar y pagas intereses otra vez. Hazlo solo si es para algo necesario y comparaste el total.



#### Si un familiar te pide que lo saques

Si un hijo o un sobrino te pide que saques un préstamo a cuenta de tu pensión para él, la deuda es tuya. Se descuenta de tu pensión aunque él no pague.



#### Casos


**Caso 1. La llamada a Lucía**

Le ofrecen a Lucía un préstamo preaprobado y le piden su INE y su estado de cuenta.
- *¿Qué hace?* Cuelga y verifica en el listado oficial del IMSS.


**Caso 2. El préstamo para el sobrino**

El sobrino de Carmen le pide que saque un préstamo a cuenta de su pensión.
- *¿Qué hace?* No lo saca: la deuda sería suya.


**Caso 3. La quincena de Raúl**

Raúl compara un préstamo del banco con uno del ISSSTE.
- *¿Qué compara?* El total a pagar, el CAT y cuánto le queda de su quincena.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar tus datos por teléfono | Te roban la identidad | Verifica tú primero |
| Pagar para «liberar» un préstamo | Pierdes ese dinero | Nunca pagues por adelantado |
| Sacarlo para otra persona | La deuda es tuya | Di que no |
| Renovar sin comparar | Pagas intereses otra vez | Compara el total |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Con quién tramitas un préstamo a cuenta de tu pensión del IMSS? a) Con quien te llame por teléfono · b) Con una financiera del listado oficial del IMSS · c) Con cualquier gestor
2. Te piden 1,500 para «liberar» tu préstamo. ¿Qué haces? a) No pagas: es fraude · b) Pagas la mitad · c) Pagas para no perder el préstamo
3. Sacas un préstamo para tu sobrino y él deja de pagar. ¿Qué pasa? a) Lo paga él · b) Se cancela · c) Te lo siguen descontando de tu pensión
**Respuestas:** 1-b: así tienes a quién reclamar. 2-a: nadie serio cobra por adelantado. 3-c: la deuda es tuya.



#### Ponlo en práctica

Tu pensión es de 9,000 al mes. ¿Cuál es el descuento más alto que te pueden hacer por un préstamo a cuenta de tu pensión?
**Respuesta:** 30% de 9,000 = 2,700 al mes.



#### A tu plan

Si tienes un préstamo de nómina o de pensión, anota cuánto te descuentan, cuántos pagos faltan y el total que pagarás.



### Para saber más

- **Préstamos a pensionados** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «préstamo a cuenta de pensión» y «entidades financieras».
- **Préstamos personales** (ISSSTE · español): https://www.gob.mx/issste — **Qué buscar:** «préstamos personales».
- **Compara créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador de crédito de nómina».

### Palabras clave

- *Préstamo a cuenta de pensión:* crédito que se paga con descuentos de tu pensión.
- *Seguro de liberación de adeudo:* seguro que cancela la deuda si la persona fallece.

### Fuentes

IMSS · ISSSTE · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M5 U09. Empeñar sin perder tus joyas

**Lo que lograrás:** Explicar cómo funciona un empeño, cuánto cuesta de verdad, qué son el refrendo y la demasía, y cómo verificar que la casa de empeño esté registrada.

**Para empezar:** Elena empeñó una pulsera de oro de su mamá para pagar el deducible del seguro. Le dieron 8,000. Ahora le quedan 10 días y todavía no sabe cuánto tiene que pagar para recuperarla.

### Lo esencial (5 minutos)

#### Cómo funciona

1. Llevas una **prenda** y hacen un **avalúo**.
2. Te prestan solo una parte de ese valor.
3. Tienes un **plazo** para pagar y recuperarla (**desempeño**).
4. Si no alcanzas, puedes **refrendar**: pagas los intereses y el plazo se alarga.
5. Si no pagas ni refrendas, la casa **vende** tu prenda.



#### La pulsera de Elena

- Préstamo: **8,000**
- Intereses y comisiones de 2 meses: **1,920**
- Para recuperarla: **9,920**
Por eso el empeño conviene solo para una urgencia corta.


#### Antes de empeñar

Busca la casa en el **Registro Público de Casas de Empeño de la PROFECO**. Compara el avalúo y el costo en dos casas, y pide todo por escrito. Guarda tu boleta.

> **Dato vigente:** todas las casas de empeño deben estar inscritas en el Registro Público de Casas de Empeño (RPCE) de la PROFECO. Deben tener un contrato de adhesión registrado y renovar su registro cada año. Consultado el 30 de septiembre de 2026 a través de la PROFECO.



#### Un caso en un minuto

Elena encontró su boleta, pagó el refrendo antes de la fecha y aparta 2,500 al mes para desempeñar la pulsera en cuatro meses. Después empezará su fondo para el deducible.

> **Idea clave:** empeñar sirve para una urgencia corta; compara en casas registradas, guarda tu boleta y anota la fecha límite.



#### Comprueba lo que entendiste

1. ¿Qué es refrendar?
*Respuesta:* Pagar los intereses para alargar el plazo sin perder la prenda.

2. ¿Qué es la demasía?
*Respuesta:* Lo que sobra si venden tu prenda en más de lo que debías; es tuya.


#### Para recordar

- Compara en dos casas registradas.
- Guarda la boleta.
- Anota la fecha límite.



### Profundiza (5 minutos más)

#### Si venden tu prenda: la demasía

Si venden tu prenda en más de lo que debías, la diferencia es tuya. Pregunta cómo reclamarla y en qué plazo; viene en tu contrato.



#### Las joyas de la familia

Una joya heredada vale más que su precio en oro. Antes de empeñarla, revisa si tu fondo de emergencia o un acuerdo de pago cubren la urgencia.



#### Empeñar o vender

Si sabes que no podrás recuperarla, compara vender directo: a veces recibes más que con un empeño que terminarás perdiendo.



#### Casos


**Caso 1. La boleta de Elena**

Elena no recuerda cuándo vence su empeño.
- *¿Qué hace?* Busca la boleta y paga el refrendo antes de la fecha.


**Caso 2. Dos casas**

Maru quiere empeñar un reloj.
- *¿Qué hace?* Compara el avalúo y el costo en dos casas registradas.


**Caso 3. La cadena de Carmen**

Carmen sabe que no podrá recuperar una cadena.
- *¿Qué hace?* Compara empeñar contra vender directo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin comparar | Pagas de más | Compara en dos casas |
| Perder la boleta | Complicas el trámite | Tómale foto |
| Olvidar la fecha | Venden tu prenda | Anótala |
| Empeñar lo que no podrás sacar | La pierdes igual | Compara con vender |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Maru y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde verificas que una casa de empeño esté registrada? a) En sus anuncios · b) En el registro de la PROFECO · c) Con una vecina
2. ¿Qué pasa si no pagas ni refrendas a tiempo? a) Te esperan · b) Te bajan el interés · c) La casa vende tu prenda
3. ¿De quién es la demasía? a) Tuya · b) De la casa de empeño · c) De la PROFECO
**Respuestas:** 1-b: así tienes a quién reclamar. 2-c: por eso anotas la fecha. 3-a: es lo que sobra de la venta.



#### Ponlo en práctica

Te prestan 6,000 y el costo es 10% al mes. ¿Cuánto pagas para recuperar tu prenda en dos meses?
**Respuesta:** 10% de 6,000 es 600 al mes; 1,200 en dos meses. Pagas 7,200.



#### A tu plan

Si tienes algo empeñado, anota la fecha límite y cuánto apartarás cada mes para recuperarlo.



### Para saber más

- **Registro Público de Casas de Empeño** (PROFECO · español): https://rpce.profeco.gob.mx — **Qué buscar:** el nombre de la casa de empeño.
- **Quejas** (PROFECO · español): 55 5568 8722 | Teléfono del Consumidor.

### Palabras clave

- *Desempeñar:* pagar el préstamo y los intereses para recuperar tu prenda.
- *Demasía:* lo que sobra si venden tu prenda en más de lo que debías.

### Fuentes

PROFECO (Registro Público de Casas de Empeño) · Ley Federal de Protección al Consumidor, consultados el 30 de septiembre de 2026.

---


# Parte 7. Módulo 6. Tus inversiones

## M6 U01. Rendimiento, riesgo, plazo y liquidez

**Lo que lograrás:** Hacerte cuatro preguntas antes de cualquier inversión (cuánto rinde, cuánto puede bajar, por cuánto tiempo y qué tan rápido lo recupero) y comparar contra la inflación.

**Para empezar:** Lucía heredó un fondo que el año pasado «ganó 12%» y este año bajó 3%. Se asustó y quiere sacarlo todo. No sabe si hizo bien su esposo en elegirlo ni si ella debe mantenerlo. En esta lección aprenderás las cuatro preguntas para entender cualquier inversión.

### Lo esencial (5 minutos)

#### Cuatro preguntas

Antes de invertir o de sacar una inversión, pregunta: **¿cuánto rinde?**, **¿cuánto puede bajar?**, **¿por cuánto tiempo?** y **¿qué tan rápido lo recupero?** Son el rendimiento, el riesgo, el plazo y la liquidez.



#### Los cuatro conceptos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Rendimiento | Lo que gana tu dinero. | Compáralo con la inflación. |
| Riesgo | Cuánto puede bajar. | Más rendimiento, más riesgo. |
| Plazo | Cuánto tiempo lo dejas. | Según cuándo lo necesitas. |
| Liquidez | Qué tan rápido lo conviertes en efectivo. | Para emergencias, alta. |

#### Rendimiento real

Si una inversión gana 7% y la inflación fue 4%, tu rendimiento real es de unos 3%. Si gana menos que la inflación, tu dinero compra menos que antes.



#### Un caso en un minuto

Lucía revisó su fondo: es de largo plazo y puede bajar algunos años. No necesita ese dinero en los próximos cinco. Decidió no venderlo por el susto y revisar si su riesgo le acomoda.

> **Idea clave:** ninguna inversión tiene todo: más rendimiento suele traer más riesgo o menos liquidez.



#### Comprueba lo que entendiste

1. ¿Qué es la liquidez?
*Respuesta:* Qué tan rápido conviertes una inversión en efectivo.

2. ¿Qué pasa si una inversión gana menos que la inflación?
*Respuesta:* Tu dinero pierde poder de compra.


#### Para recordar

- Rendimiento, riesgo, plazo y liquidez.
- Compara con la inflación.
- Más rendimiento suele traer más riesgo.



### Profundiza (5 minutos más)

#### Comparar tres opciones

| Opción | Rendimiento | Riesgo | Liquidez |
|---|---|---|---|
| Cuenta de ahorro | Bajo | Muy bajo | Alta |
| Cetes a 91 días | Moderado | Bajo | Al vencimiento |
| Fondo de acciones | Puede ser alto | Alto | Días |



#### El tiempo que tienes

El dinero que necesitarás pronto no debe estar en inversiones que puedan bajar. El que no necesitarás en muchos años puede tolerar más altibajos. A tu edad, conviene pensar en cuándo necesitarás cada peso.



#### Tu tolerancia

Si una baja del 10% te quitaría el sueño o te haría vender en pánico, esa inversión no es para ti, aunque sea «buena». Invertir bien también es dormir tranquila.

> **Antes de actuar, verifica:** el rendimiento pasado no garantiza el futuro; pide siempre el documento con la información clave de la inversión.



#### Casos


**Caso 1. El fondo de Lucía**

El fondo heredado de Lucía bajó 3% este año y ella quiere venderlo por el susto.
- *¿Qué hace?* Revisa su plazo y su riesgo antes de vender; si no necesita el dinero pronto, no decide por pánico.


**Caso 2. La cuenta de Carmen**

La cuenta de ahorro de Carmen paga 1% y la inflación fue 4%.
- *¿Qué hace?* Entiende que pierde poder de compra y busca una opción adecuada a su plazo.


**Caso 3. El dinero de Maru**

Maru necesitará dinero en seis meses y le ofrecen un fondo de acciones.
- *¿Qué hace?* Elige una opción de bajo riesgo para ese plazo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el rendimiento | Ignoras el riesgo | Cuatro preguntas |
| Vender por pánico | Conviertes la baja en pérdida | Revisa tu plazo |
| Invertir lo que necesitas pronto | Puede bajar | Bajo riesgo |
| Olvidar la inflación | Pierdes poder de compra | Rendimiento real |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Una inversión gana 8% y la inflación es 5%. ¿Cuál es el rendimiento real aproximado? a) 13% · b) 3% · c) 8%, porque la inflación no cuenta
2. ¿Qué inversión conviene para dinero que necesitas en tres meses? a) Una de bajo riesgo y corto plazo · b) Un fondo de acciones que ganó mucho el año pasado · c) Una a cinco años
3. ¿Qué es el riesgo? a) Lo que te cobra la institución · b) El plazo mínimo de la inversión · c) Cuánto puede bajar tu inversión
**Respuestas:** 1-b: 8 menos 5. 2-a: el plazo manda. 3-c: la posibilidad de perder.



#### Ponlo en práctica

Tienes 100,000 en una cuenta que paga 1% y la inflación es 4%. ¿Cuánto pierdes en poder de compra en un año, aproximadamente?
**Respuesta:** Unos 3,000 (3% de 100,000).



#### A tu plan

Para cada inversión de tu inventario, anota su rendimiento, riesgo, plazo y liquidez.



### Para saber más

- **Inversiones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «invertir» y conceptos básicos.
- **Inflación** (INEGI · español): https://www.inegi.org.mx — **Qué buscar:** «inflación», para comparar tu rendimiento.

### Palabras clave

- *Rendimiento real:* lo que gana tu dinero descontando la inflación.
- *Liquidez:* qué tan rápido conviertes una inversión en efectivo.
- *Riesgo:* la posibilidad de que tu inversión baje de valor.

### Fuentes

CONDUSEF · INEGI, consultados el 29 de septiembre de 2026.

---

## M6 U02. Qué hay en el menú

**Lo que lograrás:** Distinguir los instrumentos más comunes (pagarés, Cetes y bonos, fondos de inversión y acciones) y saber cuáles protege el IPAB.

**Para empezar:** En el estado de cuenta de Carmen aparecen palabras como «PRLV», «fondo de deuda» y «SIC». Ella no sabe qué tiene. En esta lección conocerás el menú básico de inversiones para entender lo que ya tienes.

### Lo esencial (5 minutos)

#### El menú básico

Hay muchos nombres, pero casi todo cae en cuatro grupos: depósitos a plazo en bancos, deuda de gobierno o empresas, fondos de inversión y acciones.



#### Cuatro grupos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pagaré bancario | Depósito a plazo en un banco. | Lo protege el IPAB. |
| Cetes y bonos | Le prestas al gobierno o a empresas. | Riesgo bajo a moderado. |
| Fondo de inversión | Juntas tu dinero con otras personas. | Diversifica; puede subir o bajar. |
| Acciones | Compras una parte de una empresa. | Riesgo alto. |

#### Diversificar

Diversificar es no poner todo en una sola cosa. Un fondo de inversión diversifica por ti, pero su valor cambia cada día.



#### Un caso en un minuto

Carmen preguntó a su casa de bolsa. El «PRLV» era un pagaré. El «fondo de deuda» invertía en bonos. El «SIC» eran acciones de empresas extranjeras. Ahora sabe qué partes pueden bajar.

> **Idea clave:** saber en qué grupo está cada inversión te dice cuánto riesgo tiene y si la protege el IPAB.



#### Comprueba lo que entendiste

1. ¿Qué grupo protege el IPAB?
*Respuesta:* Los pagarés y depósitos bancarios.

2. ¿Qué es diversificar?
*Respuesta:* Repartir tu dinero en distintas inversiones.


#### Para recordar

- Depósitos, deuda, fondos y acciones.
- Solo los depósitos bancarios tienen IPAB.
- Diversificar reduce el riesgo.



### Profundiza (5 minutos más)

#### Palabras de tu estado de cuenta

| Palabra | Qué es |
|---|---|
| PRLV o pagaré | Depósito a plazo en un banco |
| Cetes, Bonos M, Udibonos | Deuda del gobierno federal |
| Fondo de deuda | Fondo que invierte en bonos |
| Fondo de renta variable | Fondo que invierte en acciones |
| SIC | Acciones o fondos extranjeros que se compran en México |



#### Comisiones de los fondos

Los fondos cobran una comisión anual por administración que se descuenta de su valor. Una diferencia de 1% al año, por muchos años, es mucho dinero. Pregúntala y compárala.



#### Productos complejos

Si no entiendes cómo gana dinero una inversión, no la compres. Productos «estructurados» o con nombres complicados pueden tener riesgos que no ves.

> **Antes de actuar, verifica:** el prospecto o documento de información clave del fondo: su objetivo, riesgo y comisiones.



#### Casos


**Caso 1. El estado de cuenta de Carmen**

Carmen no entiende las palabras «PRLV», «fondo de deuda» y «SIC» de su estado de cuenta.
- *¿Qué hace?* Pregunta a su institución qué es cada una y la clasifica en su grupo.


**Caso 2. La propuesta a Lucía**

A Lucía le ofrecen «un estructurado con capital protegido» que no entiende.
- *¿Qué hace?* No lo compra hasta entender cómo gana y qué riesgos tiene.


**Caso 3. El único fondo de Elena**

Elena tiene todos sus ahorros en las acciones de una sola empresa.
- *¿Qué hace?* Considera diversificar para no depender de una sola inversión.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber qué tienes | No ves el riesgo | Clasifica cada inversión |
| Comprar lo que no entiendes | Riesgos ocultos | Pregunta o no compres |
| Ignorar comisiones | Menos rendimiento | Compáralas |
| Todo en una sola cosa | Mucho riesgo | Diversifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es un PRLV? a) Una acción de una empresa del extranjero · b) Un fondo de acciones · c) Un pagaré bancario
2. ¿Qué haces si no entiendes una inversión? a) No la compras hasta entenderla · b) La compras poco para probar · c) Confías en quien la ofrece
3. ¿Por qué importa la comisión de un fondo? a) No importa si el fondo es bueno · b) Se descuenta de tu rendimiento cada año · c) Solo se paga al entrar
**Respuestas:** 1-c: depósito a plazo. 2-a: nunca compres lo que no entiendes. 3-b: reduce tu ganancia.



#### Ponlo en práctica

Un fondo cobra 2% al año y otro 1%. Con 500,000 invertidos, ¿cuánto pagas de más al año en el primero?
**Respuesta:** 1% de 500,000: 5,000 al año.



#### A tu plan

Clasifica cada inversión de tu estado de cuenta en uno de los cuatro grupos.



### Para saber más

- **Fondos de inversión** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondos de inversión» y comparativos.
- **Padrón** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** operadoras de fondos y casas de bolsa.

### Palabras clave

- *Diversificar:* repartir tu dinero en distintas inversiones para no depender de una sola.
- *Fondo de inversión:* dinero de muchas personas que un administrador invierte junto.
- *Pagaré:* depósito a plazo en un banco.

### Fuentes

CONDUSEF · CNBV, consultados el 29 de septiembre de 2026.

---

## M6 U03. Lee tu estado de cuenta de inversión

**Lo que lograrás:** Leer tu estado de cuenta de inversión: posición, movimientos, rendimiento del periodo, comisiones y retenciones.

**Para empezar:** Cada mes le llega a Lucía un estado de cuenta de 12 páginas de la casa de bolsa. Lo guarda sin abrir porque «no le entiende». Ahí podría ver si le cobran de más o si alguien movió algo. En esta lección lo leerás en diez minutos.

### Lo esencial (5 minutos)

#### Cinco partes

Casi todos los estados de cuenta de inversión tienen cinco partes: datos del cliente, resumen o posición, movimientos, rendimiento y cargos (comisiones e impuestos).



#### Qué mirar primero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Posición | Qué tienes y cuánto vale hoy. | Tu foto del mes. |
| Movimientos | Compras, ventas, depósitos y retiros. | ¿Los reconoces todos? |
| Rendimiento | Cuánto ganó o perdió en el periodo. | Compara con meses anteriores. |
| Comisiones y retenciones | Lo que te cobran y lo que te retienen de impuestos. | Revisa que sean las pactadas. |

#### Los movimientos

Revisa que reconozcas todos los movimientos. Una compra o venta que no autorizaste es motivo de reclamación inmediata.



#### Un caso en un minuto

Lucía abrió su estado con la tabla de esta lección. Vio su posición, un rendimiento negativo del mes y una comisión mayor a la que le dijeron. Llamó a la institución y le explicaron un cobro por un servicio que no pidió; lo reclamó.

> **Idea clave:** diez minutos al mes con tu estado de cuenta te dicen qué tienes, qué pasó y cuánto te cobran.



#### Comprueba lo que entendiste

1. ¿Qué es la posición?
*Respuesta:* Lo que tienes y cuánto vale a la fecha del estado.

2. ¿Qué haces si ves un movimiento que no autorizaste?
*Respuesta:* Reclamo de inmediato a la institución.


#### Para recordar

- Posición, movimientos y rendimiento.
- Comisiones y retenciones.
- Reclama lo que no reconozcas.



### Profundiza (5 minutos más)

#### Tu revisión mensual

| Pregunta | Dónde | Sí o no |
|---|---|---|
| ¿Reconozco todos los movimientos? | Movimientos | |
| ¿La comisión es la pactada? | Cargos | |
| ¿El valor total es el que esperaba? | Posición | |
| ¿Hay retención de impuestos? | Cargos | |



#### Un mes malo no es un año malo

El rendimiento de un solo mes puede ser negativo en inversiones que suben y bajan. Mira el rendimiento de doce meses o más y compáralo con la inflación.



#### Guarda tus estados

Guarda al menos los del último año y la constancia anual de retenciones: la necesitas para tus impuestos (módulo 9).

> **Antes de actuar, verifica:** el formato cambia en cada institución; pide que te expliquen tu primer estado de cuenta en una cita.



#### Casos


**Caso 1. Las 12 páginas de Lucía**

Lucía guarda sus estados de cuenta sin abrirlos.
- *¿Qué hace?* Los revisa cada mes con la tabla: posición, movimientos, rendimiento y cargos.


**Caso 2. La venta de Carmen**

Carmen ve una venta de acciones que no autorizó.
- *¿Qué hace?* Reclama de inmediato a la institución, por escrito y con folio.


**Caso 3. El mes de Elena**

El fondo de Elena perdió 2% este mes.
- *¿Qué hace?* Revisa el rendimiento de doce meses antes de preocuparse.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No abrir el estado de cuenta | No ves errores | Revísalo cada mes |
| Ignorar movimientos raros | Pierdes plazo | Reclama pronto |
| Juzgar por un mes | Decisiones de pánico | Mira doce meses |
| Tirar los estados | Los necesitas | Guarda un año |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué parte muestra lo que tienes hoy? a) La posición · b) Los movimientos del mes · c) La lista de comisiones cobradas
2. Tu fondo bajó 2% en un mes. ¿Qué haces? a) Lo vendes todo de inmediato para no perder más este año · b) Revisas el rendimiento de doce meses · c) Cambias de institución hoy mismo
3. ¿Qué guardas para tus impuestos? a) Solo el último estado · b) Nada, lo tiene el SAT · c) La constancia anual de retenciones
**Respuestas:** 1-a: tu foto del mes. 2-b: un mes no es un año. 3-c: la necesitas para declarar.



#### Ponlo en práctica

Tu posición era 800,000 el mes pasado; este mes es 790,000 y no hubo retiros. ¿Cuánto cambió en porcentaje?
**Respuesta:** Bajó 10,000, que es 1.25% de 800,000.



#### A tu plan

Revisa tu último estado de cuenta de inversión con la tabla de revisión.



### Para saber más

- **Estados de cuenta** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «estado de cuenta» y cómo leerlo.

### Palabras clave

- *Posición:* lo que tienes y cuánto vale a la fecha del estado de cuenta.
- *Retención:* impuesto que la institución descuenta y entrega al SAT por ti.
- *Constancia de retenciones:* documento anual con lo que te retuvieron.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M6 U04. Tu asesor: verifica, pregunta y compara

**Lo que lograrás:** Verificar a un asesor de inversiones en el registro de la CNBV, hacerle las preguntas clave sobre comisiones y conflictos de interés, y comparar antes de decidir.

**Para empezar:** El asesor que manejaba las inversiones del esposo de Lucía la visita para «seguir atendiéndola» y le propone mover todo a un producto nuevo. Es amable y lo conoce desde hace años. ¿Cómo sabe si le conviene a ella o a él? En esta lección aprenderás a evaluar a tu asesor.

### Lo esencial (5 minutos)

#### Verifica

Si te asesora una persona independiente, debe estar en el Registro de Asesores en Inversiones de la CNBV. Si trabaja para un banco o casa de bolsa, confirma con la institución, por su teléfono oficial, que trabaja ahí.



#### Preguntas clave

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cómo te pagan? | Comisión por venta, cuota fija o porcentaje. | Revela conflictos. |
| ¿Cuánto me cuesta en total? | Comisiones de entrada, salida y anuales. | Por escrito. |
| ¿Cuánto puede bajar? | El peor escenario. | Riesgo real. |
| ¿Por qué cambiar? | Si propone mover lo que ya tienes. | Cada cambio puede costar. |

#### Conflicto de interés

Si tu asesor gana más al venderte ciertos productos, puede recomendarlos aunque no sean los mejores para ti. Es un conflicto de interés. Preguntar no es desconfiar: es cuidarte.



#### Un caso en un minuto

Lucía preguntó cuánto costaba el producto nuevo y cómo le pagaban al asesor. Resultó que cobraba una comisión alta de entrada. Pidió la propuesta por escrito y la comparó con otra institución. Decidió no cambiar.

> **Idea clave:** verifica, pregunta cómo le pagan y compara por escrito antes de mover tu dinero.



#### Comprueba lo que entendiste

1. ¿Dónde verificas a un asesor independiente?
*Respuesta:* En el Registro de Asesores en Inversiones de la CNBV.

2. ¿Por qué preguntar cómo le pagan?
*Respuesta:* Para saber si tiene un conflicto de interés.


#### Para recordar

- Verifica en la CNBV o con la institución.
- Pregunta costos y cómo le pagan.
- Compara por escrito.



### Profundiza (5 minutos más)

#### Propuesta por escrito

| Dato | Propuesta A | Propuesta B |
|---|---|---|
| Institución | | |
| Producto | | |
| Comisión de entrada | | |
| Comisión anual | | |
| Riesgo (peor año) | | |
| Plazo y liquidez | | |



#### Tu dinero, tu decisión

Tu asesor recomienda; tú decides. No firmes contratos en blanco ni des poder para que opere tu cuenta sin consultarte. Puedes pedir que toda operación requiera tu autorización.



#### Nunca a su cuenta

Ningún asesor recibe dinero en su cuenta personal. Tu dinero va a una cuenta a tu nombre en la institución.

> **Dato vigente:** los asesores en inversiones deben registrarse ante la CNBV y, si son personas físicas, contar con certificación de un organismo autorizado. Consultado el 29 de septiembre de 2026 a través de la CNBV.



#### Casos


**Caso 1. El producto nuevo para Lucía**

El asesor de siempre le propone a Lucía mover todo a un producto nuevo.
- *¿Qué hace?* Pregunta costos y cómo le pagan, pide la propuesta por escrito y compara.


**Caso 2. El contrato de Carmen**

Le piden a Carmen firmar un contrato que permite al asesor operar sin consultarla.
- *¿Qué hace?* Pide que cada operación requiera su autorización.


**Caso 3. El depósito de Maru**

Un asesor le pide a Maru depositar a su cuenta personal para «agilizar».
- *¿Qué hace?* No deposita: el dinero va solo a una cuenta a su nombre en la institución.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confiar por años de trato | No ves conflictos | Pregunta cómo le pagan |
| Mover sin comparar | Pagas comisiones | Compara por escrito |
| Dar poder amplio | Operan sin ti | Tu autorización |
| Depositar a una persona | Pierdes tu dinero | Solo a tu cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué preguntas a tu asesor antes de decidir? a) Cuántos clientes tiene y desde cuándo · b) Cómo le pagan y cuánto cuesta en total · c) Si ya lo compró él mismo
2. Un asesor independiente, ¿dónde lo verificas? a) En sus redes sociales y en las opiniones de otros clientes · b) En el registro de la CNBV · c) Con sus otros clientes
3. ¿Quién decide sobre tu dinero? a) Tu asesor, que sabe más del tema · b) Tu familia · c) Tú
**Respuestas:** 1-b: revela conflictos. 2-b: el registro oficial. 3-c: el asesor recomienda, tú decides.



#### Ponlo en práctica

Una propuesta cobra 3% de entrada sobre 1,000,000. ¿Cuánto pagas solo por entrar?
**Respuesta:** 3% de 1,000,000: 30,000.



#### A tu plan

Haz a tu asesor las cuatro preguntas clave y pide la respuesta por escrito.



### Para saber más

- **Registro de Asesores en Inversiones** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «Registro de Asesores en Inversiones».

### Palabras clave

- *Registro de Asesores en Inversiones:* registro de la CNBV donde aparecen los asesores autorizados.
- *Conflicto de interés:* situación en la que quien te aconseja gana más si decides de cierta forma.

### Fuentes

CNBV, consultado el 29 de septiembre de 2026.

---

## M6 U05. Inversiones milagro y «yo te lo manejo»

**Lo que lograrás:** Reconocer pirámides, rendimientos garantizados, criptomonedas «seguras» y a conocidos o familiares que ofrecen manejar tu dinero sin autorización.

**Para empezar:** En el grupo de amigas del club, una conocida cuenta que invirtió en «un negocio de divisas» que paga 5% mensual. Dice que ya recuperó lo invertido. Carmen tiene ahorros quietos y le da pena preguntar si es seguro. En esta lección verás las señales.

### Lo esencial (5 minutos)

#### Si suena demasiado bueno…

Las inversiones milagro prometen mucho, rápido y sin riesgo. Ninguna inversión legítima garantiza rendimientos altos. Si lo prometen, es la primera señal.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Garantizado y alto | «5% mensual seguro». | Imposible sin riesgo. |
| Trae a más personas | Te pagan por invitar. | Pirámide. |
| «Yo te lo manejo» | Un conocido invierte por ti sin estar registrado. | Sin protección. |
| Cripto «segura» | Te prometen ganancias fijas. | Muy volátil y sin protección. |

#### Cómo funciona una pirámide

En un esquema piramidal los primeros cobran con el dinero de los que entran después. Por eso algunos «ya recuperaron». Cuando deja de entrar gente, se derrumba.



#### Un caso en un minuto

Carmen preguntó el nombre de la empresa y lo buscó en la CNBV: había una advertencia. Meses después, el «negocio de divisas» dejó de pagar.

> **Idea clave:** rendimiento alto garantizado, pagos por invitar o alguien que «te lo maneja» sin registro son señales de fraude.



#### Comprueba lo que entendiste

1. ¿Por qué algunos «ya recuperaron» en una pirámide?
*Respuesta:* Porque les pagan con el dinero de quienes entran después.

2. ¿Existe una inversión legítima con rendimiento alto garantizado?
*Respuesta:* No.


#### Para recordar

- Garantizado y alto = alerta.
- Pagos por invitar = pirámide.
- Nadie maneja tu dinero sin registro.



### Profundiza (5 minutos más)

#### Antes de decir que sí

| Pregunta | Si la respuesta es… |
|---|---|
| ¿Está autorizada en la CNBV? | No: no inviertes |
| ¿Garantizan el rendimiento? | Sí: alerta |
| ¿Te pagan por traer gente? | Sí: pirámide |
| ¿El dinero va a una persona? | Sí: no inviertes |



#### Cuando viene de alguien cercano

Los fraudes se mueven entre amigas, familias y grupos de confianza. La persona que te invita puede creer de verdad en el negocio. No es un juicio sobre ella: es una verificación para ti.



#### Criptomonedas

Las criptomonedas pueden subir o bajar mucho en días y no las protege el IPAB. Si alguien te promete ganancias fijas con cripto, es fraude.

> **Antes de actuar, verifica:** las advertencias de la CNBV y el Portal de Fraudes Financieros de la CONDUSEF.



#### Casos


**Caso 1. El negocio de divisas de Carmen**

Una amiga del club le ofrece a Carmen 5% mensual en un negocio de divisas.
- *¿Qué hace?* Busca la empresa en la CNBV y no invierte si no está autorizada.


**Caso 2. El sobrino de Lucía**

El sobrino de Lucía le ofrece «manejarle» sus ahorros en la bolsa desde su cuenta.
- *¿Qué hace?* No le da su dinero: debe estar en una cuenta a su nombre en una institución autorizada.


**Caso 3. La invitación de Maru**

Le ofrecen a Maru ganar comisiones por cada amiga que invite a invertir.
- *¿Qué hace?* No entra: pagar por invitar es señal de pirámide.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer en lo garantizado | Pierdes todo | Desconfía |
| Invertir por confianza | Fraude entre conocidos | Verifica |
| Dar tu dinero a familiares | Sin protección | Cuenta a tu nombre |
| Invitar a otras | Las arrastras | Denuncia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te ofrecen 5% mensual garantizado. ¿Qué es? a) Una buena oportunidad si la persona es conocida · b) Una señal de fraude · c) Normal en divisas
2. Te pagan por invitar a más personas. ¿Qué es? a) Una pirámide · b) Un programa de referidos legítimo que conviene · c) Un bono de bienvenida
3. Tu sobrino quiere manejar tus ahorros en su cuenta. ¿Qué haces? a) Aceptas si firma un pagaré · b) Aceptas solo una parte · c) No: tu dinero va a una cuenta a tu nombre
**Respuestas:** 1-b: nada legítimo garantiza eso. 2-a: pagan con el dinero de nuevos. 3-c: sin protección en su cuenta.



#### Ponlo en práctica

Te prometen 5% mensual. ¿Cuánto sería al año, sin interés sobre interés, y cómo se compara con Cetes?
**Respuesta:** 60% al año, muchas veces más que los Cetes; un rendimiento así, garantizado, es imposible sin fraude.



#### A tu plan

Si alguien te ofrece una inversión, usa la tabla «antes de decir que sí» antes de responder.



### Para saber más

- **Advertencias** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** entidades no autorizadas.
- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** pirámides e inversiones fraudulentas.

### Palabras clave

- *Esquema piramidal:* fraude que paga a los primeros con el dinero de quienes entran después.
- *Criptomoneda:* dinero digital sin respaldo de un banco central y con precio muy variable.

### Fuentes

CNBV · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M6 U06. Noticias, rumores y cambios: ajusta tu plan sin pánico

**Lo que lograrás:** Distinguir información confiable de rumores, reconocer cuándo el miedo o «lo que hacen todos» decide por ti, y ajustar tu plan cuando cambian la economía, las tasas o las leyes.

**Para empezar:** Una noche, en el grupo de la familia de Lucía, circula que «van a quitar las pensiones» y que «las inversiones se van a desplomar». Su cuñado ya sacó todo de Cetes. Lucía no sabe si hacer lo mismo. En esta lección verás cómo responder con calma.

### Lo esencial (5 minutos)

#### Antes de actuar por una noticia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Quién lo dice? | Fuente oficial y fecha. | Sin fuente, no es dato. |
| ¿Estoy decidiendo con miedo? | El miedo empuja a vender en lo peor. | Espera. |
| ¿Lo hago porque todos lo hacen? | Seguir a la manada. | Tu plan es tuyo. |
| ¿Cambia mi meta o mi plazo? | Si no cambian, tu plan tampoco. | Revisa. |

#### Cuando sí cambia algo

Hay cambios reales que te afectan: suben los precios, cambian las tasas, se reforman las pensiones o las reglas de un apoyo. Confírmalos en la fuente oficial y ajusta una parte de tu plan a la vez: tu presupuesto, tu ahorro o tus fechas.



#### Un caso en un minuto

Lucía buscó el aviso en el sitio del IMSS y de la CONDUSEF: no había ningún cambio en su pensión de viudez. Dejó sus Cetes, que eran para una meta de dos años. Cuando subieron los precios del gas, ajustó su presupuesto del mes.

> **Idea clave:** confirma en la fuente oficial y no decidas con miedo ni por lo que hacen todos. Ajusta tu plan solo si cambia tu meta, tu plazo o una regla que te aplica.



#### Comprueba lo que entendiste

1. ¿Qué haces con un rumor sobre tu pensión?
*Respuesta:* Lo confirmas en el sitio oficial antes de actuar.

2. ¿Cuándo cambias tu plan de inversión?
*Respuesta:* Cuando cambia tu meta, tu plazo o una regla que te aplica, no por miedo.


#### Para recordar

- Fuente oficial y fecha.
- Ni miedo ni manada.
- Ajusta una parte a la vez.



### Profundiza (5 minutos más)

#### Tus sesgos

Todas las personas tenemos atajos mentales: sentimos más una pérdida que una ganancia igual, creemos más lo que vemos seguido y copiamos a los demás. Saberlo te ayuda a pausar antes de decidir.



#### Quién influye en la economía

Cada institución tiene su papel. El Banco de México fija la tasa de interés de referencia para cuidar la inflación. La Secretaría de Hacienda y el Congreso deciden impuestos y apoyos. El IMSS y el ISSSTE aplican las leyes de pensiones. Sus sitios publican los cambios oficiales.



#### Sigue aprendiendo

Revisa una vez al año lo que aprendiste en este curso y comparte con tus hijos y nietos lo que ya sabes. Una conversación en familia también cuida el bienestar financiero de todos.

> **Antes de actuar, verifica:** cualquier cambio en tu pensión, tus impuestos o tus apoyos. Hazlo en el sitio oficial del IMSS, el ISSSTE, el SAT o la Secretaría de Bienestar.



#### Casos


**Caso 1. El grupo de Lucía**

En el grupo de la familia dicen que «van a quitar las pensiones».
- *¿Qué hace Lucía?* Lo confirma en el sitio oficial del IMSS y no actúa por el rumor.


**Caso 2. Los Cetes del cuñado**

El cuñado de Lucía sacó todo de Cetes por miedo y le dice que haga lo mismo.
- *¿Qué hace?* Revisa su meta y su plazo y deja su dinero si no cambiaron.


**Caso 3. El gas de Maru**

Subió el precio del gas y de la luz en casa de Maru.
- *¿Qué hace?* Ajusta su presupuesto del mes antes de tocar su fondo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer sin fuente | Decides mal | Sitio oficial |
| Vender por miedo | Pierdes | Tu meta y plazo |
| Seguir a todos | No es tu plan | Decide tú |
| Ignorar un cambio real | El plan no sirve | Ajusta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, su cuñado y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Circula que van a quitar las pensiones. ¿Qué haces? a) Retiras todo lo que puedas · b) Lo confirmas en el sitio oficial antes de actuar · c) Lo reenvías a todos
2. Tus Cetes son para una meta de dos años y todos están vendiendo. ¿Qué haces? a) Vendes antes que los demás · b) Pasas todo a efectivo en casa · c) Revisas tu meta y tu plazo; si no cambiaron, sigues
3. ¿Quién fija la tasa de interés de referencia en México? a) El Banco de México · b) Tu banco · c) La CONDUSEF
**Respuestas:** 1-b: confirma antes. 2-c: el plan manda, no la manada. 3-a: para cuidar la inflación.



#### Ponlo en práctica

Tu recibo de luz subió de 400 a 520 al bimestre. ¿Cuánto más es al año?
**Respuesta:** 720 pesos más al año (120 por 6 bimestres).



#### A tu plan

Guarda en tu carpeta los sitios oficiales que consultarás antes de creer una noticia sobre tu dinero.



### Para saber más

- **Política monetaria e inflación** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** la inflación anual más reciente y la tasa de interés de referencia.
- **Alertas y orientación** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «alertas».

### Palabras clave

- *Sesgo:* atajo mental que puede llevarte a decidir mal.
- *Tasa de referencia:* tasa que fija el Banco de México y que influye en las demás tasas.

### Fuentes

Banco de México · CONDUSEF · IMSS, consultados el 30 de septiembre de 2026.

---


# Parte 8. Módulo 7. Pensión y retiro

## M7 U01. Tu mapa de pensiones

**Lo que lograrás:** Identificar qué pensiones podrías recibir (IMSS Ley 73 o Ley 97, ISSSTE, viudez y pensiones del Bienestar) y qué documento prueba cada una.

**Para empezar:** Maru trabajó en una empresa de 1990 a 2002. Su esposo trabaja en el gobierno. Ella piensa que «no tiene pensión» porque se dedicó a la casa. Puede que tenga más derechos de los que cree. En esta lección harás tu mapa de pensiones.

### Lo esencial (5 minutos)

#### Varias fuentes posibles

Tu retiro puede venir de varias fuentes: una pensión por tu propio trabajo, una pensión de viudez, las pensiones del Bienestar y tu propio ahorro. Conocer cada una evita sorpresas.



#### Las fuentes más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IMSS | Si trabajaste en una empresa privada. | Ley 73 o Ley 97. |
| ISSSTE | Si trabajaste para el gobierno. | Reglas propias (M7 U05). |
| Viudez | Si tu pareja cotizaba o tenía pensión. | M7 U04. |
| Bienestar | Mujeres de 60 a 64 y personas de 65 o más. | Programas sociales. |

#### Ley 73 y Ley 97

Si empezaste a cotizar en el IMSS **antes del 1 de julio de 1997**, tu pensión puede calcularse con la Ley 73. Con esa ley, la pensión suele depender de tus semanas y de tu salario de los últimos años. Si empezaste después, aplica la Ley 97: tu pensión depende de lo ahorrado en tu AFORE.



#### Un caso en un minuto

Maru descubrió que tiene unas 600 semanas cotizadas bajo la Ley 73 y una AFORE con saldo. No alcanza para pensión todavía, pero tiene opciones (M7 U03).

> **Idea clave:** aunque te hayas dedicado a la casa, puedes tener semanas cotizadas, una AFORE o derechos de viudez; averígualo.



#### Comprueba lo que entendiste

1. ¿Qué define si te aplica la Ley 73?
*Respuesta:* Haber cotizado en el IMSS antes del 1 de julio de 1997.

2. ¿De qué depende la pensión con la Ley 97?
*Respuesta:* De lo ahorrado en tu AFORE.


#### Para recordar

- Trabajo propio, viudez, Bienestar y ahorro.
- Ley 73 si cotizaste antes de julio de 1997.
- Averigua tus semanas.



### Profundiza (5 minutos más)

#### Tu mapa

| Fuente | ¿Me aplica? | Documento o dónde consultar |
|---|---|---|
| IMSS por mi trabajo | | Constancia de semanas cotizadas |
| ISSSTE | | Hoja única de servicios |
| AFORE | | Estado de cuenta; e-SAR |
| Viudez | | Resolución de pensión de viudez |
| Mujeres Bienestar o Adultos Mayores | | Programas para el Bienestar |



#### Tus semanas cotizadas

Puedes consultar tus semanas en el sitio del IMSS con tu CURP y NSS. Si trabajaste en varias empresas, revisa que aparezcan todos los periodos. Si falta alguno, reúne recibos o constancias y pregunta en tu clínica o subdelegación.



#### Si tu pareja es la que cotiza

Conoce qué pensión tiene o tendrá tu pareja y si tú apareces como beneficiaria. Eso define tu posible pensión de viudez (M7 U04).

> **Antes de actuar, verifica:** las reglas de pensión son técnicas. Antes de tomar una decisión grande, confirma tu caso en el IMSS o el ISSSTE. Si buscas un asesor en pensiones, que no te cobre por adelantado.



#### Casos


**Caso 1. Las semanas de Maru**

Maru cree que no tiene pensión porque se dedicó a la casa, pero trabajó 12 años.
- *¿Qué hace?* Consulta sus semanas cotizadas en el IMSS y su AFORE.


**Caso 2. El esposo de Carmen**

Carmen no sabe si aparece como beneficiaria de la pensión de Arturo.
- *¿Qué hace?* Revisa con Arturo sus documentos de pensión y sus beneficiarios.


**Caso 3. Los 60 años de Lucía**

Lucía cumplió 60 y no sabe qué programa del Bienestar le corresponde.
- *¿Qué hace?* Revisa en Programas para el Bienestar los requisitos de la pensión para mujeres de 60 a 64.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no tienes nada | Pierdes derechos | Consulta tus semanas |
| No revisar periodos faltantes | Menos pensión | Reúne constancias |
| Ignorar la pensión de tu pareja | Sorpresas en viudez | Revisa beneficiarios |
| Pagar a gestores por adelantado | Fraude | Pregunta en el IMSS |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Empezaste a cotizar en 1990. ¿Qué ley te puede aplicar? a) La Ley 73 · b) La Ley 97, que aplica a todos por igual · c) Ninguna, por la fecha
2. ¿Dónde consultas tus semanas cotizadas? a) En tu banco, con el número de tu cuenta de nómina · b) En el IMSS con tu CURP y NSS · c) En el SAT, con tu RFC
3. Te dedicaste a la casa y trabajaste antes. ¿Qué haces? a) Nada: no tienes pensión · b) Esperas a que te llamen · c) Consultas tus semanas y tu AFORE
**Respuestas:** 1-a: cotizaste antes de julio de 1997. 2-b: con tu CURP y NSS. 3-c: puedes tener derechos.



#### Ponlo en práctica

Llena tu mapa de pensiones con lo que sabes hoy y marca lo que te falta consultar.
**Respuesta:** Por ejemplo: IMSS, 600 semanas por consultar; AFORE, por localizar; viudez, revisar beneficiarios de mi esposo; Bienestar, a los 60.



#### A tu plan

Consulta tus semanas cotizadas en el sitio del IMSS y anota el resultado en tu mapa.



### Para saber más

- **Semanas cotizadas** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «constancia de semanas cotizadas».
- **Pensiones del Bienestar** (Programas para el Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** requisitos por edad.

### Palabras clave

- *Ley 73:* reglas del IMSS para quienes cotizaron antes del 1 de julio de 1997.
- *Ley 97:* reglas del IMSS para quienes empezaron a cotizar desde el 1 de julio de 1997; la pensión depende de tu AFORE.
- *Semanas cotizadas:* semanas en que se pagaron cuotas al IMSS a tu nombre.

### Fuentes

IMSS · Programas para el Bienestar, consultados el 29 de septiembre de 2026.

---

## M7 U02. Tu AFORE y tus semanas cotizadas

**Lo que lograrás:** Localizar tu AFORE, revisar tu estado de cuenta, actualizar beneficiarios y conocer las aportaciones voluntarias.

**Para empezar:** Elena cambió de trabajo varias veces y no sabe en qué AFORE está. Tampoco sabe a quién puso de beneficiaria hace 20 años: a su exesposo. En esta lección pondrás en orden tu AFORE.

### Lo esencial (5 minutos)

#### Localiza tu AFORE

Si alguna vez tuviste un trabajo formal, tienes una AFORE. La localizas sin costo con tu CURP en el sitio e-SAR o en la app AforeMóvil.



#### Qué revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Saldo | Cuánto tienes ahorrado. | En tu estado de cuenta. |
| Beneficiarios | A quién pasa si faltas. | Actualízalos. |
| Aportaciones voluntarias | Ahorro extra que puedes hacer tú. | Desde montos pequeños. |
| Tu AFORE | Puedes cambiarte si te conviene. | Compara rendimientos. |

#### Beneficiarios al día

Si tus beneficiarios son de hace años, pueden ser personas que ya no quieres o que ya no viven. Actualizarlos no tiene costo y se hace en tu AFORE o en la app.



#### Un caso en un minuto

Elena localizó su AFORE con su CURP. Tenía un saldo que no esperaba. Cambió a sus hijos como beneficiarios y empezó a hacer una aportación voluntaria pequeña cada mes.

> **Idea clave:** localiza tu AFORE, revisa tu saldo y actualiza tus beneficiarios; no tiene costo.



#### Comprueba lo que entendiste

1. ¿Cómo localizas tu AFORE?
*Respuesta:* Con tu CURP en e-SAR o en la app AforeMóvil.

2. ¿Cuánto cuesta actualizar beneficiarios?
*Respuesta:* Nada.


#### Para recordar

- Localízala con tu CURP.
- Actualiza beneficiarios.
- Aportaciones voluntarias suman.



### Profundiza (5 minutos más)

#### Tu revisión de AFORE

| Pregunta | Respuesta |
|---|---|
| ¿En qué AFORE estoy? | |
| ¿Cuánto tengo? | |
| ¿Quiénes son mis beneficiarios? | |
| ¿Hago aportaciones voluntarias? | |



#### Aportaciones voluntarias

Puedes ahorrar extra en tu AFORE aunque ya no trabajes formalmente: por la app, en tiendas o con domiciliación. Algunas aportaciones pueden deducirse de impuestos (módulo 9). Pregunta en tu AFORE las opciones de retiro de esas aportaciones.



#### Cuidado con gestores

Si alguien te llama para «recuperar» tu AFORE o cambiarte a otra a cambio de un regalo o un cobro, desconfía. Los trámites de AFORE no tienen costo y los haces tú.

> **Antes de actuar, verifica:** los rendimientos y comisiones de cada AFORE en el sitio de la CONSAR antes de cambiarte.



#### Casos


**Caso 1. La AFORE de Elena**

Elena no sabe en qué AFORE está después de varios trabajos.
- *¿Qué hace?* La localiza sin costo con su CURP en e-SAR o en AforeMóvil.


**Caso 2. El beneficiario de Maru**

El beneficiario de la AFORE de Maru es su papá, que ya falleció.
- *¿Qué hace?* Actualiza sus beneficiarios en su AFORE.


**Caso 3. El regalo de Carmen**

Un agente le ofrece a Carmen una licuadora si se cambia de AFORE.
- *¿Qué hace?* No se cambia por un regalo; compara rendimientos en la CONSAR.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber tu AFORE | Ahorro olvidado | Localízala |
| Beneficiarios viejos | Tu dinero a quien no quieres | Actualízalos |
| Cambiarte por regalos | Menos rendimiento | Compara |
| Pagar a gestores | Es sin costo | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Maru y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué necesitas para localizar tu AFORE? a) Tu CURP · b) Una cita con un gestor · c) El número de tu última empresa
2. Te ofrecen un regalo por cambiarte de AFORE. ¿Qué haces? a) Aceptas: el regalo no tiene costo · b) Comparas rendimientos en la CONSAR antes · c) Te cambias y, si no te gusta, regresas a tu AFORE anterior
3. ¿Puedes ahorrar en tu AFORE si ya no trabajas formalmente? a) No, solo con patrón · b) Solo si tienes más de 60 años · c) Sí, con aportaciones voluntarias
**Respuestas:** 1-a: con tu CURP. 2-b: el regalo no mejora tu retiro. 3-c: cualquiera puede aportar.



#### Ponlo en práctica

Si aportas 500 al mes durante 10 años, sin contar rendimiento, ¿cuánto sumas?
**Respuesta:** 500 por 120 meses: 60,000, más el rendimiento que genere.



#### A tu plan

Localiza tu AFORE con tu CURP y revisa tus beneficiarios.



### Para saber más

- **e-SAR** (CONSAR · español): https://www.e-sar.com.mx — **Qué buscar:** localizar AFORE con CURP.
- **Comparativo de AFORE** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** rendimientos y comisiones.

### Palabras clave

- *AFORE:* administradora que guarda e invierte tu ahorro para el retiro.
- *Aportación voluntaria:* ahorro extra que haces tú en tu AFORE.
- *NSS:* Número de Seguridad Social.

### Fuentes

CONSAR · IMSS, consultados el 29 de septiembre de 2026.

---

## M7 U03. Modalidad 40: ¿puedes y te conviene?

**Lo que lograrás:** Comprobar si puedes inscribirte a la Modalidad 40 del IMSS, cuánto cuesta en 2026 y cómo decidir con números antes de pagar.

**Para empezar:** Maru escuchó que con la Modalidad 40 «cualquiera puede tener una buena pensión». Un gestor le ofreció inscribirla por 15,000 pesos. En esta lección verás los requisitos reales, el costo y cómo decidir sin intermediarios.

### Lo esencial (5 minutos)

#### Qué es

La Modalidad 40 es la continuación voluntaria en el régimen del IMSS. Pagas tú las cuotas para sumar semanas y mejorar el salario con el que se calcula tu pensión. Sirve sobre todo a quienes cotizaron **antes de julio de 1997** (Ley 73).



#### Antes de pagar, revisa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu fecha de alta | Antes del 1 de julio de 1997. | Ley 73. |
| Tus semanas recientes | Al menos 52 en los últimos 5 años al darte de baja. | Requisito. |
| Tus plazos | Conservación de derechos. | Si pasó mucho tiempo, puede que no. |
| El costo | 14.438% del salario que registres en 2026. | Sube cada año. |

> **Dato vigente:** la Modalidad 40 pide al menos 52 semanas cotizadas en los últimos cinco años antes de la baja, dentro de los plazos para conservar derechos. En 2026 la cuota es de 14.438% del salario registrado y sube hasta 18.8% en 2030. Consultado el 29 de septiembre de 2026 a través del IMSS (LSS art. 218) y medios especializados.

#### Con números

Pide al IMSS una estimación de tu pensión **con** y **sin** Modalidad 40. Compara lo que pagarías en total contra lo que ganarías de pensión al mes. Si tardarías muchos años en recuperar lo pagado, quizá no te convenga.



#### Un caso en un minuto

Maru dejó de cotizar en 2002: pasaron más de cinco años sin semanas recientes. En el IMSS le confirmaron que hoy no puede inscribirse. Se ahorró los 15,000 del gestor y revisará otras opciones de ahorro para su retiro.

> **Idea clave:** la Modalidad 40 no es para todas; confirma tus requisitos en el IMSS y decide con números, sin gestores.



#### Comprueba lo que entendiste

1. ¿A quién le sirve más la Modalidad 40?
*Respuesta:* A quien cotizó en el IMSS antes de julio de 1997 y cumple los requisitos de semanas y plazos.

2. ¿Cuánto es la cuota en 2026?
*Respuesta:* 14.438% del salario que registres.


#### Para recordar

- Ley 73 y requisitos de semanas y plazos.
- 14.438% en 2026, sube cada año.
- Estimación con y sin, sin gestores.



### Profundiza (5 minutos más)

#### Ejemplo de costo mensual

Si registras un salario de 30,000 al mes en 2026, la cuota es el 14.438%: unos 4,331 al mes. Multiplica por los meses que planeas pagar para saber el costo total, y recuerda que el porcentaje sube cada año hasta 2030.



#### Decide con números

| Dato | Sin Modalidad 40 | Con Modalidad 40 |
|---|---|---|
| Pensión estimada al mes | | |
| Costo total de cuotas | 0 | |
| Años para recuperar lo pagado | — | |



#### Gestores

El trámite no tiene costo y se hace en el IMSS. Hay gestores que cobran por inscribirte o que ofrecen «financiar» tus cuotas con préstamos caros. Desconfía de quien te pide dinero por adelantado.

> **Antes de actuar, verifica:** tus requisitos y tu estimación directamente en el IMSS; las reglas y los porcentajes cambian cada año.



#### Casos


**Caso 1. El gestor de Maru**

Un gestor le ofrece a Maru inscribirla por 15,000.
- *¿Qué hace?* Confirma en el IMSS si puede inscribirse y hace el trámite sin costo.


**Caso 2. El cálculo de Elena**

Elena cotiza en Ley 97 y le ofrecen la Modalidad 40 «para subir su pensión».
- *¿Qué hace?* Pregunta en el IMSS si le conviene en su régimen antes de pagar.


**Caso 3. El préstamo de Carmen**

Le ofrecen a Carmen un préstamo para pagar de golpe sus cuotas de Modalidad 40.
- *¿Qué hace?* No se endeuda sin una estimación del IMSS y sin comparar costos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es para todas | Pagas sin derecho | Revisa requisitos |
| Usar gestores | Pagas de más | Trámite sin costo |
| Decidir sin números | No recuperas | Estimación con y sin |
| Endeudarte para pagar | Riesgo alto | Evalúa antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Elena y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces antes de pagar la Modalidad 40? a) Pagas un gestor para que lo revise · b) Confirmas requisitos y pides una estimación en el IMSS · c) Pagas un año para probar
2. Registras 20,000 de salario en 2026. ¿Cuánto es la cuota aproximada? a) 2,000 · b) 20,000 · c) 2,888
3. ¿Quién puede cobrarte por inscribirte? a) Nadie: el trámite no tiene costo · b) Un gestor autorizado por el IMSS para agilizar la inscripción · c) Tu AFORE, con una comisión
**Respuestas:** 1-b: decide con números. 2-c: 14.438% de 20,000. 3-a: no tiene costo.



#### Ponlo en práctica

Con una cuota de 4,331 al mes durante 5 años, ¿cuánto pagarías sin contar aumentos?
**Respuesta:** 4,331 por 60 meses: 259,860.



#### A tu plan

Si cotizaste antes de 1997, pide al IMSS tu estimación de pensión y pregunta si puedes inscribirte.



### Para saber más

- **Continuación voluntaria (Modalidad 40)** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «continuación voluntaria en el régimen obligatorio».

### Palabras clave

- *Modalidad 40:* continuación voluntaria en el IMSS: pagas tú las cuotas para mejorar tu pensión de Ley 73.
- *Conservación de derechos:* periodo después de tu baja en el que aún puedes hacer ciertos trámites.

### Fuentes

IMSS · Ley del Seguro Social, consultados el 29 de septiembre de 2026.

---

## M7 U04. Pensión de viudez y pensiones del Bienestar

**Lo que lograrás:** Identificar la pensión de viudez del IMSS (en general, 90% de la pensión de la persona fallecida), su trámite, y las pensiones del Bienestar para mujeres de 60 a 64 y personas de 65 o más.

**Para empezar:** Cuando falleció su esposo, Lucía tardó meses en tramitar su pensión de viudez porque no encontraba el acta de matrimonio ni sabía dónde ir. Ahora está por cumplir 65 y no sabe si puede recibir también la pensión del Bienestar. En esta lección verás ambas.

### Lo esencial (5 minutos)

#### Pensión de viudez

Si tu pareja tenía pensión del IMSS o cumplía requisitos, puedes tener derecho a una pensión de viudez. En general es el 90% de la pensión que recibía o habría recibido.

> **Dato vigente:** la pensión de viudez equivale, en general, al 90% de la pensión que recibía o habría recibido la persona asegurada. Consultado el 29 de septiembre de 2026 a través del IMSS y medios especializados.



#### Pensiones del Bienestar 2026

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mujeres Bienestar | De 60 a 64 años. | 3,100 pesos bimestrales. |
| Adultos Mayores | 65 años o más. | 6,400 pesos bimestrales. |
| Pago | En la Tarjeta del Bienestar. | Cada dos meses. |
| Sin costo | Nadie cobra por registrarte. | Solo módulos oficiales. |

> **Dato vigente:** en 2026, la Pensión Mujeres Bienestar entrega 3,100 pesos cada dos meses a mujeres de 60 a 64 años. La Pensión para Adultos Mayores entrega 6,400 pesos cada dos meses a personas de 65 años o más. Consultado el 29 de septiembre de 2026 a través de Programas para el Bienestar.

#### Los documentos

Para la viudez suelen pedir actas de matrimonio (o prueba de concubinato), de defunción y de nacimiento. También identificación, CURP y los datos del IMSS de tu pareja. Tenerlos en tu carpeta acelera el trámite.



#### Un caso en un minuto

Lucía reunió sus documentos en su carpeta. Al cumplir 65, se registró en el módulo oficial para la pensión de Adultos Mayores, que puede recibir además de su pensión de viudez.

> **Idea clave:** ten listos los documentos de viudez y registra a tiempo las pensiones del Bienestar; ambos trámites no tienen costo.



#### Comprueba lo que entendiste

1. ¿Cuánto es en general la pensión de viudez?
*Respuesta:* El 90% de la pensión que recibía o habría recibido la persona fallecida.

2. ¿Cuánto da la Pensión Mujeres Bienestar en 2026?
*Respuesta:* 3,100 pesos cada dos meses, de los 60 a los 64 años.


#### Para recordar

- Viudez: en general 90%.
- Bienestar: 60 a 64 y 65 o más.
- Trámites sin costo, documentos en tu carpeta.



### Profundiza (5 minutos más)

#### Documentos para la viudez

| Documento | Lo tengo |
|---|---|
| Acta de matrimonio o prueba de concubinato | |
| Acta de defunción | |
| Acta de nacimiento propia | |
| Identificación y CURP | |
| NSS o resolución de pensión de tu pareja | |



#### ¿Se pueden juntar?

Las pensiones del Bienestar son programas sociales y, por regla general, puedes recibirlas además de otras pensiones. Recibir dos pensiones del IMSS (por ejemplo, una propia y una de viudez) depende de las reglas de cada una. Confírmalo en el IMSS.



#### Fraudes en programas sociales

Nadie te pide dinero por registrarte ni por «aumentar» tu pensión. No des los datos de tu Tarjeta del Bienestar por teléfono.

> **Antes de actuar, verifica:** fechas de registro y requisitos en el sitio de Programas para el Bienestar; cambian cada año.



#### Casos


**Caso 1. Los 65 de Lucía**

Lucía cumplirá 65 y ya recibe pensión de viudez.
- *¿Qué hace?* Se registra en el módulo oficial de la pensión de Adultos Mayores.


**Caso 2. Los papeles de Carmen**

Carmen no sabe dónde está su acta de matrimonio.
- *¿Qué hace?* La tramita y la guarda en su carpeta junto con los datos del IMSS de Arturo.


**Caso 3. La llamada a Maru**

Le llaman a Maru para «aumentar su pensión del Bienestar» a cambio de un pago.
- *¿Qué hace?* Cuelga: el registro y la pensión no tienen costo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener documentos | Trámite lento | Carpeta lista |
| No registrarte a tiempo | Pierdes pagos | Revisa fechas |
| Pagar por registros | Fraude | Sin costo |
| Suponer que no se juntan | Dejas dinero | Confirma |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto da la Pensión de Adultos Mayores en 2026? a) 3,100 cada mes, igual que Mujeres Bienestar · b) 6,400 cada dos meses · c) 6,400 cada mes
2. Te piden dinero para aumentar tu pensión del Bienestar. ¿Qué es? a) Un fraude · b) Un trámite especial para adultos mayores · c) Una cuota voluntaria
3. La pensión de tu esposo es de 20,000 al mes. ¿Cuánto sería, en general, tu pensión de viudez? a) 20,000 · b) 10,000 · c) 18,000
**Respuestas:** 1-b: bimestral. 2-a: no tiene costo. 3-c: 90% de 20,000.



#### Ponlo en práctica

Si recibes 6,400 cada dos meses, ¿cuánto recibes al año?
**Respuesta:** 6,400 por 6 bimestres: 38,400.



#### A tu plan

Reúne en tu carpeta los documentos de la tabla y anota la fecha en que te corresponde registrarte a una pensión del Bienestar.



### Para saber más

- **Pensión de viudez** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «pensión de viudez» y requisitos.
- **Pensiones del Bienestar** (Programas para el Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** registro, montos y fechas.

### Palabras clave

- *Pensión de viudez:* pensión que recibe la pareja de una persona asegurada o pensionada que falleció.
- *Concubinato:* unión de pareja sin matrimonio, con efectos legales si se cumplen requisitos.

### Fuentes

IMSS · Programas para el Bienestar, consultados el 29 de septiembre de 2026.

---

## M7 U05. Si tú o tu pareja trabajaron para el gobierno: ISSSTE

**Lo que lograrás:** Identificar en qué régimen del ISSSTE están tú o tu pareja, qué requisitos hay en 2026 para jubilarse en el régimen anterior, cómo funciona la pensión de viudez del ISSSTE y qué documentos pedir.

**Para empezar:** Raúl, el esposo de Maru, es maestro y trabajó 31 años en escuelas públicas federales. Maru no sabe si él «está en el régimen viejo o en el de AFORE», ni qué le tocaría a ella si él faltara. En esta lección verás cómo averiguarlo sin gestores.

### Lo esencial (5 minutos)

#### Dos regímenes

Quien trabajaba para el gobierno cuando cambió la ley del ISSSTE en 2007 eligió entre dos caminos. Uno es el régimen del décimo transitorio: el Instituto paga la pensión según años de servicio y sueldo.

El otro son las cuentas individuales: la pensión sale del ahorro en una AFORE, con un bono por los años anteriores. Quien entró a trabajar después de 2007 está en cuentas individuales.



#### ¿En cuál está?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Décimo transitorio | Eligió quedarse en el régimen anterior. | Pensión por años de servicio y edad. |
| Cuentas individuales | Eligió el bono o entró después de 2007. | Pensión según su ahorro en la AFORE. |
| Hoja única de servicios | Documento que resume sus años y sueldos. | Se pide en su dependencia. |
| Gestor que «acelera» | Los trámites del ISSSTE no tienen costo. | No pagues por adelantado. |

> **Dato vigente:** en el régimen del décimo transitorio, en 2026 y 2027 las mujeres pueden jubilarse a los 56 años con 28 años de servicio. Los hombres, a los 58 con 30 años. La edad baja poco a poco hasta 53 y 55 años en 2034. Consultado el 29 de septiembre de 2026 a través del decreto publicado en el DOF el 24 de junio de 2025 y medios especializados.

#### Pensión de viudez del ISSSTE

Si tu pareja era pensionada del ISSSTE, o trabajaba y cumplía los requisitos, puedes tener derecho a pensión de viudez. En el régimen anterior equivale al 100% de la pensión que recibía o que le habría correspondido.

Si hay hijos con derecho, el monto se reparte entre la familia. En cuentas individuales se paga con su ahorro y un seguro de sobrevivencia.

> **Dato vigente:** la pensión por viudez del ISSSTE equivale al 100% de la pensión que recibía la persona pensionada o que le habría correspondido. Si la persona trabajadora murió por causas ajenas al trabajo, necesitaba al menos 3 años de cotización. Consultado el 29 de septiembre de 2026 a través del ISSSTE (gob.mx/issste) y medios especializados.



#### Un caso en un minuto

Maru le pidió a Raúl revisar juntos su hoja única de servicios. Raúl está en el décimo transitorio, tiene 31 años de servicio y 59 de edad: ya cumple los requisitos de 2026. También confirmaron que Maru aparece como su esposa en el registro del ISSSTE.

> **Idea clave:** averigua el régimen, los años de servicio y quién aparece como beneficiaria. Con eso sabes qué pensión esperar y qué te tocaría a ti.



#### Comprueba lo que entendiste

1. ¿Qué dos regímenes hay en el ISSSTE?
*Respuesta:* El décimo transitorio (el Instituto paga según años y sueldo) y las cuentas individuales (pensión con el ahorro en la AFORE).

2. ¿Cuánto es, en general, la pensión de viudez en el régimen anterior?
*Respuesta:* El 100% de la pensión que recibía o le habría correspondido, repartida si hay hijos con derecho.


#### Para recordar

- Primero, el régimen.
- Hoja única de servicios.
- Viudez: 100% en el régimen anterior.



### Profundiza (5 minutos más)

#### Lo que necesitas saber de tu pareja (o de ti)

| Dato | Dónde se consulta | Lo que encontré |
|---|---|---|
| Régimen (décimo transitorio o cuentas individuales) | ISSSTE o su dependencia | |
| Años de servicio | Hoja única de servicios | |
| AFORE (PENSIONISSSTE u otra) | e-SAR o PENSIONISSSTE | |
| Beneficiarios registrados | ISSSTE y AFORE | |
| Acta de matrimonio o prueba de concubinato | Registro Civil | |



#### Si tuviste IMSS e ISSSTE

Mucha gente trabajó una parte de su vida en empresas (IMSS) y otra en el gobierno (ISSSTE). En algunos casos se pueden sumar los periodos cotizados en ambos institutos para cumplir requisitos. Pide en el IMSS y en el ISSSTE que te revisen los dos historiales antes de decidir.



#### Viudez y tu propia pensión

Si tú también tienes pensión (del IMSS o del ISSSTE), pregunta en el ISSSTE si puedes recibir las dos completas o si hay límites. Las reglas de compatibilidad dependen del régimen y del tipo de pensión.



#### Cuando llegue el momento

Para el trámite de viudez suelen pedirse: acta de defunción, acta de matrimonio (o prueba de concubinato), identificación, CURP y comprobante de domicilio. También documentos de la pensión o del empleo de tu pareja. Tenerlos en tu carpeta (M1 U04) te ahorra meses.

> **Antes de actuar, verifica:** tu régimen, tus requisitos y tus montos directamente en el ISSSTE; las reglas cambian con decretos y dependen de cada caso.



#### Casos


**Caso 1. El régimen de Raúl**

Maru no sabe si Raúl está en el régimen anterior o en cuentas individuales.
- *¿Qué hacen?* Piden juntos la hoja única de servicios y confirman el régimen en el ISSSTE.


**Caso 2. La mamá de Elena**

La mamá de Elena es viuda de un maestro que era pensionado del ISSSTE y nunca tramitó la pensión de viudez.
- *¿Qué hace Elena?* La acompaña al ISSSTE con los documentos para iniciar el trámite, sin gestores.


**Caso 3. El gestor**

Un gestor ofrece a Carmen «acelerar» la pensión ISSSTE de su hermano por 20,000 pesos.
- *¿Qué le aconseja Carmen?* Que no pague: los trámites del ISSSTE no tienen costo y se hacen directamente.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber el régimen | Expectativas falsas | Hoja única de servicios |
| Beneficiarios sin revisar | Trámites largos | Revisa el registro |
| Pagar gestores | Fraude | Trámite sin costo |
| Olvidar años en el IMSS | Pierdes periodos | Revisa ambos historiales |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Elena y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué documento resume los años de servicio en el gobierno? a) El estado de cuenta del banco · b) La hoja única de servicios · c) La constancia del SAT
2. En el régimen del décimo transitorio, ¿con qué requisitos se jubila una mujer en 2026? a) 60 años y 25 años de servicio · b) 65 años y 1,000 semanas · c) 56 años y 28 años de servicio
3. Tu esposo recibía 20,000 de pensión del ISSSTE en el régimen anterior y no hay hijos con derecho. ¿Cuánto sería, en general, tu pensión de viudez? a) 20,000 · b) 18,000 · c) 10,000
**Respuestas:** 1-b: se pide en la dependencia. 2-c: requisitos de 2026 y 2027. 3-a: 100% de su pensión.



#### Ponlo en práctica

Un hombre en el décimo transitorio tiene 57 años y 30 años de servicio en 2026. ¿Ya puede jubilarse? ¿Cuándo sí?
**Respuesta:** Todavía no: en 2026 se piden 58 años. Podrá al cumplir 58; en 2028 la edad baja a 57.



#### A tu plan

Pregunta a tu pareja (o revisa tú) en qué régimen del ISSSTE está, pide la hoja única de servicios y confirma quién aparece como beneficiaria.



### Para saber más

- **Pensiones del ISSSTE** (ISSSTE · español): https://www.gob.mx/issste — **Qué buscar:** «pensión por causa de muerte» y «jubilación décimo transitorio».
- **PENSIONISSSTE** (español): https://www.gob.mx/pensionissste — **Qué buscar:** «estado de cuenta» y «beneficiarios».

### Palabras clave

- *ISSSTE:* Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado: seguridad social de quienes trabajan para el gobierno federal.
- *Régimen del décimo transitorio:* régimen anterior del ISSSTE: el Instituto paga la pensión según años de servicio, edad y sueldo.
- *Cuentas individuales:* régimen del ISSSTE en el que la pensión sale del ahorro en una AFORE, como PENSIONISSSTE.
- *Hoja única de servicios:* documento que resume los años de servicio y los sueldos de una persona en el gobierno.

### Fuentes

ISSSTE · PENSIONISSSTE · Diario Oficial de la Federación (24-jun-2025), consultados el 29 de septiembre de 2026.

---

## M7 U06. ¿Cuánto necesito para mi retiro?

**Lo que lograrás:** Estimar cuánto gastarás en tu retiro, cuánto recibirás de pensiones y cuánto ahorro necesitas para cubrir la diferencia.

**Para empezar:** Carmen y Arturo piensan que con la pensión de él «alcanza». Nunca lo han calculado. Al hacer números, descubren que la pensión cubre la mitad de su gasto actual. En esta lección harás tu propio cálculo.

### Lo esencial (5 minutos)

#### Tres números

Para tu retiro necesitas tres números: cuánto **gastarás** al mes, cuánto **recibirás** de pensiones y la **diferencia** que tendrás que cubrir con ahorro.



#### La diferencia

Carmen y Arturo calculan su mes de retiro.
- Gasto esperado al mes: **45,000**
- Pensión de Arturo más Bienestar: **28,000**
- Diferencia al mes: **17,000**
Esa diferencia se cubre con ahorro, rentas u otros ingresos.


#### Gastos que suben

En el retiro algunos gastos bajan (transporte, trabajo) y otros suben: salud, medicamentos, seguro médico y ayuda en casa. Calcula con honestidad, sin olvidar el seguro médico.



#### Un caso en un minuto

Carmen y Arturo calcularon la diferencia: 17,000 al mes, es decir, 204,000 al año. Con sus ahorros y la renta del departamento cubren buena parte. Decidieron no prestar más dinero a los hijos hasta asegurar su retiro.

> **Idea clave:** calcula tu gasto, tus pensiones y la diferencia; así sabes cuánto ahorro necesitas.



#### Comprueba lo que entendiste

1. ¿Cuáles son los tres números?
*Respuesta:* Gasto esperado, pensiones y la diferencia.

2. ¿Qué gastos suelen subir en el retiro?
*Respuesta:* Salud, medicamentos, seguro médico y ayuda en casa.


#### Para recordar

- Gasto, pensiones y diferencia.
- La salud sube.
- La diferencia se cubre con ahorro u otros ingresos.



### Profundiza (5 minutos más)

#### Tu cálculo

| Concepto | Al mes |
|---|---|
| Gasto esperado | |
| Pensión propia o de pareja | |
| Pensión del Bienestar (bimestral entre 2) | |
| Rentas u otros ingresos | |
| **Diferencia** | |



#### ¿Cuánto ahorro para cubrir la diferencia?

Una forma sencilla: multiplica la diferencia anual por los años que quieres cubrir. Con 204,000 al año y 20 años, serían 4,080,000 sin contar rendimientos ni inflación. No es exacto, pero te da una idea del tamaño.



#### Otros recursos

Hay otras formas de cubrir parte de la diferencia. Por ejemplo, rentar un inmueble, cambiarte a una casa más pequeña o trabajar medio tiempo. Evalúalas con calma y con tu familia.

> **Antes de actuar, verifica:** tus montos de pensión en tus resoluciones o estimaciones oficiales, no en cálculos de terceros.



#### Casos


**Caso 1. La pensión de Arturo**

Carmen y Arturo creen que la pensión alcanza sin haberlo calculado.
- *¿Qué hacen?* Calculan su gasto, su pensión y la diferencia.


**Caso 2. El seguro de Lucía**

Lucía calcula su retiro sin incluir su seguro médico.
- *¿Qué hace?* Agrega el costo del seguro y los medicamentos a su gasto esperado.


**Caso 3. El préstamo a los hijos de Elena**

Elena presta dinero a sus hijos cada vez que le piden, sin ver su propio retiro.
- *¿Qué hace?* Primero calcula su retiro y decide cuánto puede ayudar sin descuidarlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Suponer que alcanza | Sorpresas | Calcula |
| Olvidar la salud | Gasto mayor | Inclúyela |
| Contar pensiones inciertas | Te falta | Usa montos oficiales |
| Ayudar sin límite | Descuidas tu retiro | Primero tu cálculo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastarás 40,000 y recibirás 25,000 de pensiones. ¿Cuál es la diferencia al mes? a) 65,000 · b) 25,000 · c) 15,000
2. ¿Qué gasto suele subir en el retiro? a) Transporte al trabajo · b) Salud y medicamentos · c) Colegiaturas de los hijos
3. ¿Qué haces antes de prestar a tus hijos? a) Calculas tu retiro · b) Les prestas lo que pidan · c) Les pides un pagaré y listo
**Respuestas:** 1-c: 40,000 menos 25,000. 2-b: la salud aumenta. 3-a: primero tu seguridad.



#### Ponlo en práctica

Con una diferencia de 12,000 al mes, ¿cuánto necesitas para cubrir 15 años, sin contar rendimientos?
**Respuesta:** 12,000 por 12 son 144,000 al año; por 15 años: 2,160,000.



#### A tu plan

Llena tu cálculo de retiro con tus números y anota la diferencia.



### Para saber más

- **Calculadoras de retiro** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «calculadora de ahorro y retiro».

### Palabras clave

- *Diferencia de retiro:* lo que te falta cada mes entre tu gasto y tus pensiones.
- *Retiro:* etapa de la vida en la que dejas de trabajar y vives de pensiones y ahorros.

### Fuentes

CONSAR · IMSS, consultados el 29 de septiembre de 2026.

---


# Parte 9. Módulo 8. Salud y seguros

## M8 U01. Cómo funciona tu seguro de gastos médicos

**Lo que lograrás:** Explicar cómo funciona tu Seguro de Gastos Médicos Mayores: suma asegurada, deducible, coaseguro, tope de coaseguro y red hospitalaria.

**Para empezar:** Elena paga 48,000 al año por su seguro de gastos médicos, pero no sabe qué pagaría ella si la operan. En su póliza hay palabras como «deducible», «coaseguro» y «tabulador». En esta lección las entenderás con un ejemplo.

### Lo esencial (5 minutos)

#### Para qué sirve

El Seguro de Gastos Médicos Mayores (SGMM) paga gastos grandes: hospitalización, cirugías, tratamientos. No es para consultas pequeñas. Te protege de un gasto que podría acabar con tus ahorros.



#### Cuatro palabras

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Suma asegurada | Lo máximo que paga la aseguradora. | Mientras más, mejor protección. |
| Deducible | Lo que pagas tú primero. | Una vez por evento. |
| Coaseguro | Porcentaje que pagas después del deducible. | Por ejemplo, 10%. |
| Tope de coaseguro | Lo máximo que pagas de coaseguro. | Te protege de montos altos. |

#### Una cirugía de 200,000

Elena tiene deducible de 20,000 y coaseguro de 10%.
- Costo de la cirugía: **200,000**
- Deducible (lo pagas tú): **20,000**
- Base para el coaseguro: **180,000**
De esos 180,000, Elena paga el 10%: 18,000. En total paga 38,000 y la aseguradora 162,000.


#### Un caso en un minuto

Elena revisó su póliza: su tope de coaseguro es de 40,000. Aunque la cirugía costara un millón, ella nunca pagaría más de 20,000 de deducible más 40,000 de coaseguro.

> **Idea clave:** conoce tu deducible, tu coaseguro y tu tope: así sabes cuánto pagarías tú en un evento grave.



#### Comprueba lo que entendiste

1. ¿Qué es el deducible?
*Respuesta:* Lo que pagas tú primero en cada evento.

2. ¿Para qué sirve el tope de coaseguro?
*Respuesta:* Pone un máximo a lo que pagas de coaseguro.


#### Para recordar

- Suma asegurada, deducible, coaseguro y tope.
- Calcula tu parte en un evento grande.
- Para gastos grandes, no consultas.



### Profundiza (5 minutos más)

#### Datos de tu póliza

| Dato | Tu póliza |
|---|---|
| Suma asegurada | |
| Deducible | |
| Coaseguro | |
| Tope de coaseguro | |
| Red o nivel hospitalario | |
| Fecha de renovación | |



#### Red hospitalaria y tabulador

Tu póliza tiene una red de hospitales y un tabulador de honorarios médicos. Si vas a un hospital fuera de tu red o tu médico cobra más que el tabulador, la diferencia la pagas tú.



#### Antes de una cirugía programada

Pide a la aseguradora la **programación de cirugía**: te confirma qué cubre, en qué hospital y cuánto pagarás. Evitas sorpresas.

> **Antes de actuar, verifica:** todos estos datos están en la carátula y en las condiciones generales de tu póliza. Pide a tu agente que te los explique por escrito.



#### Casos


**Caso 1. La cirugía de Elena**

Elena no sabe cuánto pagaría ella si la operan.
- *¿Qué hace?* Revisa su deducible, coaseguro y tope, y calcula su parte.


**Caso 2. El hospital de Carmen**

Carmen quiere operarse en un hospital que no está en la red de su póliza.
- *¿Qué hace?* Pregunta a la aseguradora cuánto pagaría ella y considera un hospital de su red.


**Caso 3. La consulta de Lucía**

Lucía quiere usar su seguro de gastos mayores para una consulta de rutina.
- *¿Qué hace?* Entiende que el seguro es para gastos grandes y paga la consulta aparte.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No conocer tu deducible | Sorpresas | Revisa la carátula |
| Ignorar el tope | Miedo innecesario | Conócelo |
| Ir fuera de tu red | Pagas la diferencia | Revisa la red |
| Operarte sin programar | Pagos inesperados | Programación de cirugía |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el coaseguro? a) El porcentaje que pagas después del deducible · b) Lo máximo que paga la aseguradora por evento · c) Una cuota mensual extra que se suma a tu prima anual del seguro
2. Cirugía de 100,000, deducible 10,000 y coaseguro 10%. ¿Cuánto pagas tú? a) 10,000 · b) 19,000 · c) 20,000
3. ¿Qué pides antes de una cirugía programada? a) Un descuento al hospital · b) La programación de cirugía · c) Un préstamo al banco por si acaso
**Respuestas:** 1-a: tu parte después del deducible. 2-b: 10,000 más 10% de 90,000. 3-b: confirma cobertura.



#### Ponlo en práctica

Cirugía de 300,000, deducible 25,000, coaseguro 10% y tope de coaseguro 30,000. ¿Cuánto pagas?
**Respuesta:** 300,000 menos 25,000 son 275,000; el 10% sería 27,500, menor al tope. Pagas 25,000 más 27,500: 52,500.



#### A tu plan

Llena la tabla con los datos de tu póliza y guárdala en tu carpeta.



### Para saber más

- **Seguros de gastos médicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «gastos médicos mayores» y comparativos.

### Palabras clave

- *Seguro de Gastos Médicos Mayores:* seguro que paga gastos médicos grandes: hospitalización, cirugías y tratamientos.
- *Deducible:* la cantidad que pagas tú antes de que el seguro empiece a pagar.
- *Coaseguro:* el porcentaje del gasto que pagas tú después del deducible.
- *Tabulador:* lista de montos máximos que paga la aseguradora por los honorarios de cada procedimiento.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M8 U02. ¿Por qué sube tanto y cómo bajarlo sin quedarte sin protección?

**Lo que lograrás:** Explicar por qué sube la prima de tu seguro de gastos médicos y conocer formas de bajarla sin perder la protección, antes de pensar en cancelarlo.

**Para empezar:** A Elena le llegó la renovación: su seguro subió 30%. Su primera idea fue cancelarlo. Pero si lo cancela y después se enferma, podría no encontrar otro que la cubra igual. En esta lección verás qué opciones tiene.

### Lo esencial (5 minutos)

#### Por qué sube

La prima sube por tres razones. Por tu edad. Por la inflación médica: hospitales y medicinas suben más que otros precios. Y, a veces, por cómo usa el seguro el grupo de personas de tu edad.



#### Cómo bajarla sin quedarte sin protección

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Deducible más alto | Pagas más tú en un evento, menos prima. | Usa tu fondo de emergencia. |
| Zona o nivel de hospitales | Una red más acotada. | Cuesta menos. |
| Coberturas que no usas | Quita adicionales que no necesitas. | Revisa con calma. |
| Forma de pago | Anual suele ser más barato. | Compara. |

#### Por qué no cancelar sin pensar

Si cancelas y después quieres volver, la nueva aseguradora puede no cubrir preexistencias y aplicar periodos de espera. Perderías la **antigüedad** que ya ganaste.



#### Un caso en un minuto

Elena subió su deducible de 20,000 a 40,000 y cambió a una red de hospitales de su zona. Su prima bajó 22%. Apartó los 20,000 extra de deducible en su fondo de emergencia.

> **Idea clave:** antes de cancelar, sube tu deducible, ajusta la red o quita lo que no usas; perder la antigüedad puede salir caro.



#### Comprueba lo que entendiste

1. ¿Qué pasa con la prima si subes el deducible?
*Respuesta:* Baja, porque pagas más tú en caso de un evento.

2. ¿Por qué no cancelar sin pensar?
*Respuesta:* Podrías perder tu antigüedad y la cobertura de preexistencias.


#### Para recordar

- Sube por edad e inflación médica.
- Ajusta deducible, red y coberturas.
- No canceles sin pensar.



### Profundiza (5 minutos más)

#### Opciones para bajar tu prima

| Opción | Qué ganas | Qué cuidas |
|---|---|---|
| Deducible más alto | Prima menor | Tener el deducible en tu fondo |
| Red más acotada | Prima menor | Que tu hospital preferido esté |
| Quitar coberturas adicionales | Prima menor | No quitar lo que sí usarías |
| Pago anual | Descuento | Tener el dinero junto |



#### Si de verdad quieres cambiar

Antes de cancelar, pide a la nueva aseguradora por escrito si te reconoce la antigüedad y cómo trata tus padecimientos actuales. Solo cancela cuando la nueva póliza ya esté vigente.



#### Si ya no puedes pagarlo

Si el seguro ya no cabe en tu gasto, revisa otras opciones. Si trabajas por tu cuenta, la Modalidad 10 del IMSS. Si ya tienes IMSS o ISSSTE, sus servicios. O un seguro con suma asegurada menor. Lo peor es quedarte sin ninguna protección.

> **Antes de actuar, verifica:** cualquier cambio en tu póliza por escrito, con la fecha en que aplica.



#### Casos


**Caso 1. El 30% de Elena**

El seguro de Elena subió 30% y piensa cancelarlo.
- *¿Qué hace?* Prueba subir su deducible y ajustar la red antes de cancelar.


**Caso 2. El cambio de Carmen**

A Carmen le ofrecen otra aseguradora más barata.
- *¿Qué hace?* Pregunta por escrito si le reconocen antigüedad y padecimientos antes de cancelar la actual.


**Caso 3. El deducible de Lucía**

Lucía quiere subir su deducible, pero no tiene ahorro para pagarlo si la operan.
- *¿Qué hace?* Primero aparta ese monto en su fondo de emergencia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cancelar al primer aumento | Pierdes antigüedad | Ajusta primero |
| Cambiar sin confirmar | Preexistencias sin cubrir | Pide por escrito |
| Deducible alto sin ahorro | No puedes pagarlo | Fondo de emergencia |
| Quedarte sin nada | Riesgo enorme | Busca otra protección |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si cancelas y luego contratas otro seguro? a) Todo sigue igual en la nueva aseguradora · b) Te pueden excluir preexistencias · c) Te bajan la prima
2. ¿Qué opción baja tu prima? a) Subir tu deducible · b) Agregar coberturas nuevas · c) Pagar mensualmente en lugar de anual
3. ¿Cuándo cancelas tu póliza actual al cambiarte? a) En cuanto firmas la solicitud nueva · b) Un mes antes para ahorrar · c) Cuando la nueva ya está vigente
**Respuestas:** 1-b: pierdes antigüedad y coberturas. 2-a: pagas más en un evento, menos de prima. 3-c: nunca te quedes sin cobertura.



#### Ponlo en práctica

Tu prima es 48,000. Si subir el deducible la baja 20%, ¿cuánto ahorras al año?
**Respuesta:** 20% de 48,000: 9,600.



#### A tu plan

Antes de tu próxima renovación, pide a tu agente una cotización con deducible más alto y otra con red más acotada.



### Para saber más

- **Seguros de gastos médicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «gastos médicos mayores», preexistencias y antigüedad.
- **Aseguradoras autorizadas** (CNSF · español): https://www.gob.mx/cnsf — **Qué buscar:** aseguradoras autorizadas.

### Palabras clave

- *Prima:* lo que pagas por tu seguro.
- *Preexistencias:* enfermedades que ya tenías antes de contratar un seguro.
- *Periodo de espera:* tiempo que debe pasar para que el seguro cubra ciertos padecimientos.
- *Antigüedad:* tiempo que llevas asegurada sin interrupción.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M8 U03. Compara y lee tu póliza

**Lo que lograrás:** Leer tu póliza (carátula, exclusiones, periodos de espera y renovación) y comparar opciones con el mismo perfil.

**Para empezar:** Carmen tiene dos cotizaciones: una de 38,000 y otra de 45,000. Quiere la más barata, pero no sabe si cubren lo mismo. En esta lección aprenderás a comparar con las mismas reglas.

### Lo esencial (5 minutos)

#### La carátula

La carátula tiene lo más importante. Las **condiciones generales** explican exclusiones y reglas. Lee las dos.



#### Qué comparar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Suma asegurada | Igual o parecida en ambas. | Comparar peras con peras. |
| Deducible y coaseguro | Iguales para comparar precios. | Mismo perfil. |
| Exclusiones | Lo que no cubre. | Puede cambiar todo. |
| Periodos de espera | Cuánto tardan en cubrir ciertos padecimientos. | Revísalos. |

#### El mismo perfil

Pide las cotizaciones con la misma suma asegurada, deducible, coaseguro y red. Solo así comparas precios de verdad.



#### Un caso en un minuto

Carmen pidió las dos cotizaciones con el mismo deducible y la misma red. La de 38,000 tenía más exclusiones y una red más pequeña. Eligió la de 45,000.

> **Idea clave:** compara con el mismo perfil y revisa exclusiones y periodos de espera, no solo el precio.



#### Comprueba lo que entendiste

1. ¿Qué es la carátula?
*Respuesta:* La hoja con los datos principales de la póliza.

2. ¿Por qué pedir el mismo perfil?
*Respuesta:* Para comparar precios de coberturas iguales.


#### Para recordar

- Carátula y condiciones generales.
- Mismo perfil para comparar.
- Exclusiones y periodos de espera.



### Profundiza (5 minutos más)

#### Comparativo

| Dato | Opción A | Opción B |
|---|---|---|
| Aseguradora | | |
| Prima anual | | |
| Suma asegurada | | |
| Deducible y coaseguro | | |
| Tope de coaseguro | | |
| Red hospitalaria | | |
| Exclusiones importantes | | |
| Periodos de espera | | |



#### Renovación

Revisa si la póliza se renueva de forma automática y si hay una edad límite de renovación. Pregunta si la aseguradora puede cambiar condiciones en la renovación.



#### Tu agente

Un agente de seguros debe tener cédula de la CNSF. Pregunta cómo se le paga: normalmente por comisión de la aseguradora. Pídele las comparaciones por escrito.

> **Antes de actuar, verifica:** la aseguradora en la CNSF y el agente con su cédula vigente.



#### Casos


**Caso 1. Las dos cotizaciones de Carmen**

Carmen tiene dos cotizaciones con deducibles distintos.
- *¿Qué hace?* Pide ambas con el mismo perfil antes de comparar precios.


**Caso 2. La exclusión de Lucía**

Lucía encuentra que su póliza excluye un tratamiento que podría necesitar.
- *¿Qué hace?* Pregunta si existe una cobertura adicional y cuánto cuesta.


**Caso 3. El agente de Elena**

Elena no sabe si su agente está autorizado.
- *¿Qué hace?* Verifica su cédula en la CNSF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comparar solo precios | Coberturas distintas | Mismo perfil |
| No leer exclusiones | Sorpresas | Condiciones generales |
| Ignorar la renovación | Te quedas sin seguro | Pregunta |
| Agente sin verificar | Riesgo de fraude | Cédula CNSF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cómo comparas dos seguros? a) Con el mismo perfil de coberturas · b) Solo por el precio anual · c) Por la marca más conocida
2. ¿Dónde están las exclusiones? a) En la publicidad y los folletos que te da el agente · b) En las condiciones generales · c) En el recibo de pago
3. ¿Qué verificas de tu agente? a) Su cédula en la CNSF · b) Cuántos años lleva en la ciudad · c) Si tiene redes sociales
**Respuestas:** 1-a: así comparas lo mismo. 2-b: ahí están las reglas. 3-a: debe estar autorizado.



#### Ponlo en práctica

La opción A cuesta 38,000 con deducible de 30,000; la B, 45,000 con deducible de 15,000. ¿Cuál conviene si te operan una vez, sin coaseguro?
**Respuesta:** A: 38,000 más 30,000 = 68,000. B: 45,000 más 15,000 = 60,000. En ese caso conviene la B.



#### A tu plan

Llena el comparativo con tu póliza actual y una cotización con el mismo perfil.



### Para saber más

- **Comparativos de seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguros» y simuladores.
- **Agentes y aseguradoras** (CNSF · español): https://www.gob.mx/cnsf — **Qué buscar:** consulta de agentes.

### Palabras clave

- *Carátula:* primera hoja de la póliza con los datos principales: suma asegurada, deducible, coaseguro y vigencia.
- *Exclusión:* lo que el seguro no cubre.
- *Condiciones generales:* documento con todas las reglas de la póliza.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M8 U04. Seguro de vida y gastos funerarios

**Lo que lograrás:** Decidir si necesitas un seguro de vida a tu edad, para qué sirve, cómo mantener al día a tus beneficiarios y qué opciones hay para gastos funerarios.

**Para empezar:** Lucía tiene un seguro de vida que le vendieron hace años «con ahorro». Paga 1,800 al mes y no sabe cuánto recibirían sus hijos ni si todavía lo necesita. En esta lección verás cómo decidir.

### Lo esencial (5 minutos)

#### ¿Para qué lo necesitas?

Un seguro de vida protege a quien depende de tu ingreso o a quien quedaría con deudas. Si nadie depende de ti y tienes patrimonio suficiente, quizá necesites menos cobertura.



#### Tipos comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Temporal | Cubre por un plazo. | Más barato. |
| Con ahorro | Parte es seguro y parte ahorro. | Más caro; revisa condiciones. |
| Gastos funerarios | Cubre el funeral. | Suma pequeña. |
| Beneficiarios | Quién recibe el pago. | Mantenlos al día. |

#### Beneficiarios

Revisa a quién nombraste. Si es un menor de edad, pregunta cómo se le entregaría. Actualizarlos no tiene costo.



#### Un caso en un minuto

Lucía pidió a su aseguradora la suma asegurada, el valor de rescate de su ahorro y los beneficiarios. Sus hijos ya son independientes. Decidió mantener un seguro de gastos funerarios y revisar con calma si le conviene conservar el otro.

> **Idea clave:** un seguro de vida es para proteger a quien depende de ti; revisa si todavía lo necesitas y mantén tus beneficiarios al día.



#### Comprueba lo que entendiste

1. ¿Para quién es un seguro de vida?
*Respuesta:* Para quien depende de tu ingreso o quedaría con deudas.

2. ¿Qué revisas de tu póliza de vida?
*Respuesta:* Suma asegurada, beneficiarios y, si tiene ahorro, su valor de rescate.


#### Para recordar

- Protege a quien depende de ti.
- Temporal, con ahorro o funerario.
- Beneficiarios al día.



### Profundiza (5 minutos más)

#### Revisa tu seguro de vida

| Dato | Tu póliza |
|---|---|
| Suma asegurada | |
| Prima mensual o anual | |
| ¿Tiene ahorro? Valor de rescate | |
| Beneficiarios | |
| Vigencia | |



#### Antes de cancelar un seguro con ahorro

Cancelar pronto puede significar perder parte de lo aportado. Pide por escrito el valor de rescate y compáralo con lo que has pagado. Decide con esa información.



#### Gastos funerarios

Hay seguros funerarios y planes de previsión. Revisa qué cubren exactamente y quién los ofrece; verifica que sea una aseguradora autorizada o una empresa formal.

> **Antes de actuar, verifica:** la aseguradora en la CNSF y cualquier plan funerario por escrito.



#### Casos


**Caso 1. El seguro con ahorro de Lucía**

Lucía paga 1,800 al mes por un seguro con ahorro y no sabe qué tiene.
- *¿Qué hace?* Pide por escrito la suma asegurada, el valor de rescate y los beneficiarios.


**Caso 2. Los beneficiarios de Carmen**

La beneficiaria del seguro de vida de Carmen es su mamá, que falleció.
- *¿Qué hace?* Actualiza sus beneficiarios en la aseguradora.


**Caso 3. El plan de Maru**

A Maru le ofrecen un plan funerario de una empresa que no conoce.
- *¿Qué hace?* Verifica que sea una empresa formal y revisa por escrito qué cubre.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar sin saber qué tienes | Dinero perdido | Pide la información |
| Beneficiarios viejos | Pago a quien no quieres | Actualízalos |
| Cancelar sin valor de rescate | Pierdes aportaciones | Pide el dato |
| Planes informales | Fraude | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Para qué sirve un seguro de vida? a) Para ahorrar sin riesgo · b) Para pagar tus gastos médicos · c) Para proteger a quien depende de ti
2. ¿Qué pides antes de cancelar un seguro con ahorro? a) El valor de rescate por escrito · b) Un regalo por renovar o un descuento en la siguiente prima · c) Nada, solo lo cancelas
3. ¿Cuánto cuesta actualizar beneficiarios? a) Una comisión fija · b) Nada · c) Depende de la suma asegurada
**Respuestas:** 1-c: protege a tus dependientes. 2-a: para no perder aportaciones. 3-b: no tiene costo.



#### Ponlo en práctica

Has pagado 1,800 al mes durante 8 años y el valor de rescate es 120,000. ¿Cuánto has pagado y cuánto recuperarías?
**Respuesta:** 1,800 por 96 meses: 172,800 pagados; recuperarías 120,000.



#### A tu plan

Revisa tu seguro de vida con la tabla y actualiza a tus beneficiarios si hace falta.



### Para saber más

- **Seguros de vida** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de vida» y «buscador de seguros de vida» para saber si alguien te dejó un seguro.

### Palabras clave

- *Seguro de vida:* seguro que paga una suma a tus beneficiarios si falleces.
- *Valor de rescate:* lo que te devuelven si cancelas un seguro con ahorro.
- *Beneficiario:* persona que recibe el pago del seguro.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M8 U05. Casa y auto: lo básico

**Lo que lograrás:** Identificar qué cubren un seguro de casa y uno de auto, y qué revisar al renovar para no pagar de más ni quedarte sin cobertura.

**Para empezar:** El seguro del auto de Carmen se renovó solo por años, con el valor de un auto nuevo aunque el suyo ya tiene diez años. Y su casa no tiene seguro contra sismo. En esta lección revisarás lo básico.

### Lo esencial (5 minutos)

#### Seguro de auto

El seguro de auto cubre daños a terceros (obligatorio en muchas carreteras y estados), daños a tu auto, robo y gastos médicos de ocupantes. La responsabilidad civil es la más importante.



#### Seguro de casa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Daños a la construcción | Incendio, sismo, inundación. | Según tu zona. |
| Contenidos | Muebles y aparatos. | Declara el valor real. |
| Responsabilidad civil | Daños a vecinos. | Útil en edificios. |
| Robo | Con condiciones. | Revisa requisitos. |

#### Al renovar

Revisa el valor asegurado: en un auto viejo, el valor comercial baja; en una casa, el costo de reconstruir sube. Ajusta ambos.



#### Un caso en un minuto

Carmen pidió cotizar el auto con su valor comercial y agregó cobertura de sismo al seguro de la casa. Pagó casi lo mismo que antes, pero con protección que sí necesita.

> **Idea clave:** revisa al renovar: valor real, responsabilidad civil y riesgos de tu zona.



#### Comprueba lo que entendiste

1. ¿Qué es la responsabilidad civil?
*Respuesta:* La cobertura que paga los daños que causas a otras personas.

2. ¿Qué revisas al renovar?
*Respuesta:* El valor asegurado y los riesgos de tu zona.


#### Para recordar

- Responsabilidad civil primero.
- Valor real del auto y costo de reconstruir la casa.
- Riesgos de tu zona.



### Profundiza (5 minutos más)

#### Revisión de renovación

| Dato | Auto | Casa |
|---|---|---|
| Valor asegurado | | |
| Deducible | | |
| Responsabilidad civil | | |
| Coberturas de tu zona (sismo, inundación) | — | |
| Fecha de renovación | | |



#### Si tienes crédito hipotecario

El crédito suele incluir un seguro de daños y de vida. Revisa qué cubre y si necesitas algo adicional para tus contenidos.



#### En un siniestro

Llama a la aseguradora por su número oficial y toma fotos. En un choque, no admitas culpa antes de que llegue el ajustador. Guarda el número de reporte.

> **Antes de actuar, verifica:** tu póliza vigente en el auto y el número de la aseguradora en tu carpeta.



#### Casos


**Caso 1. El auto de Carmen**

El auto de Carmen está asegurado con el valor de un auto nuevo aunque tiene diez años.
- *¿Qué hace?* Pide cotizar con su valor comercial actual.


**Caso 2. La casa de Lucía**

La casa de Lucía no tiene cobertura de sismo y vive en una zona sísmica.
- *¿Qué hace?* Pide cotizar la cobertura de sismo.


**Caso 3. El choque de Elena**

Elena choca y el otro conductor le pide arreglarse sin llamar al seguro.
- *¿Qué hace?* Llama a su aseguradora y espera al ajustador sin admitir culpa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Valor desactualizado | Pagas de más o te falta | Ajusta al renovar |
| Sin cobertura de tu zona | Pérdida total | Sismo o inundación |
| Arreglarse sin el seguro | Riesgo | Llama al ajustador |
| Póliza fuera del auto | Problemas en carretera | Llévala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué cobertura del auto es la más importante? a) Cristales y rines, que son lo que más se daña · b) Asistencia vial · c) Responsabilidad civil
2. Chocas y te piden arreglarse sin el seguro. ¿Qué haces? a) Aceptas para ahorrar tiempo · b) Llamas a la aseguradora y esperas al ajustador · c) Das tus datos y te vas
3. ¿Qué revisas al renovar el seguro de la casa? a) El costo de reconstruir y los riesgos de tu zona · b) Solo el precio · c) El color de la póliza
**Respuestas:** 1-c: cubre daños a otros. 2-b: el ajustador protege tus derechos. 3-a: así te cubres bien.



#### Ponlo en práctica

Tu auto vale hoy 120,000 y está asegurado por 250,000. ¿Qué haces y por qué?
**Respuesta:** Pides cotizar con 120,000: en caso de pérdida total te pagarían el valor comercial, así que pagas prima de más.



#### A tu plan

Revisa las fechas de renovación de tus seguros de auto y casa y anótalas en tu calendario de gastos anuales.



### Para saber más

- **Seguros de auto y casa** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de auto» y «seguro de casa».

### Palabras clave

- *Responsabilidad civil:* cobertura que paga los daños que causas a otras personas o a sus bienes.
- *Valor comercial:* lo que vale hoy tu auto en el mercado.
- *Ajustador:* persona de la aseguradora que evalúa un siniestro.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado

**Lo que lograrás:** Preparar tus documentos, tu seguro y un fondo para un sismo, una inundación o un incendio, y saber qué hacer después para reclamar sin caer en fraudes.

**Para empezar:** Después de un sismo, la casa de Carmen tuvo grietas. No encontraba la póliza, no sabía si cubría sismo y un «perito» tocó a la puerta ofreciendo arreglar todo si le pagaba por adelantado. En esta lección verás cómo prepararte.

### Lo esencial (5 minutos)

#### Tu plan en cuatro partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Documentos protegidos | Escrituras, pólizas e identificaciones en bolsa y en copia digital. | Para reclamar y demostrar. |
| Fotos de la casa y tus cosas | Con fecha, cada año. | Pruebas del antes. |
| Seguro con tu riesgo | Sismo o inundación según tu zona. | Revísalo al renovar (M8 U05). |
| Fondo de emergencia en una cuenta | No todo en efectivo en casa. | Disponible aunque la casa se dañe. |

#### Después del siniestro

1. Primero tu seguridad: sigue a Protección Civil y no entres a una casa dañada.
2. Toma fotos y video de los daños antes de mover o tirar algo.
3. Reporta a tu aseguradora por su número oficial y anota el número de reporte.
4. Guarda notas y recibos de lo que gastes en lo urgente.
5. Contrata reparaciones solo después de la revisión del ajustador.

> **Dato vigente:** la Ley sobre el Contrato de Seguro da a la aseguradora 30 días para pagar. Cuentan desde que recibe todos los documentos e información que te pidió. Si no te responde o no estás de acuerdo, puedes reclamar sin costo en la CONDUSEF. Consultado el 29 de septiembre de 2026 a través de la CONDUSEF.



#### Un caso en un minuto

Carmen tenía copia digital de su póliza en el correo y encontró que sí cubría sismo. Tomó fotos, reportó por el número oficial y no pagó nada al «perito». El ajustador de la aseguradora revisó la casa y su reclamo siguió su curso.

> **Idea clave:** ten copia digital de tus documentos, fotos del antes, un seguro con el riesgo de tu zona y un fondo en una cuenta. Después del siniestro, reporta tú por el número oficial y no pagues por adelantado.



#### Comprueba lo que entendiste

1. ¿Qué haces antes de mover o tirar cosas dañadas?
*Respuesta:* Tomar fotos y video de los daños.

2. ¿Quién revisa los daños para tu seguro?
*Respuesta:* El ajustador de tu aseguradora, a quien llamas tú por su número oficial.


#### Para recordar

- Copia digital de todo.
- Fotos del antes y del después.
- Reporta tú; no pagues por adelantado.



### Profundiza (5 minutos más)

#### Fraudes después de un desastre

Aparecen falsos peritos, falsos funcionarios que cobran por «inscribirte» en apoyos, colectas falsas y constructores que piden todo por adelantado. Los apoyos de gobierno no tienen costo: nadie debe cobrarte por registrarte. Dona solo a organizaciones que puedas verificar.



#### Tu persona de confianza

Dile a tu persona de confianza dónde están tus documentos y tu póliza. Acuerden un punto de encuentro y un mensaje para avisarse que están bien. Si vives sola o solo, que alguien tenga copia de tus documentos.

> **Antes de actuar, verifica:** si tu seguro de casa cubre sismo e inundación. Ten a la mano el número de siniestros de tu aseguradora y revisa que tus documentos tengan copia digital.



#### Casos


**Caso 1. El perito de Carmen**

Un «perito» ofrece arreglar las grietas de Carmen si le paga por adelantado.
- *¿Qué hace?* No paga y reporta a su aseguradora por el número oficial.


**Caso 2. Los documentos de Lucía**

Las escrituras y pólizas de Lucía están en una caja en el piso de abajo, en zona que se inunda.
- *¿Qué hace?* Las guarda en bolsa en un lugar alto y saca copia digital.


**Caso 3. El apoyo de Maru**

Alguien en la colonia de Maru cobra 500 pesos por «inscribir» a las familias en los apoyos.
- *¿Qué hace?* No paga: los apoyos no tienen costo; se informa por los canales oficiales.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Papeles sin copia | No puedes demostrar | Copia digital |
| Tirar lo dañado sin fotos | Reclamo débil | Fotos primero |
| Pagar por adelantado | Fraude | Espera al ajustador |
| Pagar por apoyos | Fraude | Son sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces antes de limpiar después de una inundación? a) Tiras todo lo mojado para evitar hongos · b) Llamas al primer constructor que pase · c) Tomas fotos y video de los daños
2. Te cobran 500 pesos por inscribirte en un apoyo de gobierno. ¿Qué es? a) Un fraude: los apoyos no tienen costo · b) Un trámite normal · c) Una cuota de la aseguradora
3. La aseguradora no te responde después de entregar tus documentos. ¿Qué haces? a) Esperas sin plazo · b) Reclamas sin costo en la CONDUSEF · c) Contratas a un gestor que cobra por adelantado
**Respuestas:** 1-c: las fotos sostienen tu reclamo. 2-a: nadie cobra por registrarte. 3-b: la CONDUSEF atiende sin costo.



#### Ponlo en práctica

Tu seguro de casa tiene un deducible de 2% sobre una suma asegurada de 1,500,000 pesos. ¿Cuánto pagarías tú?
**Respuesta:** 30,000 pesos.



#### A tu plan

Esta semana toma fotos de tu casa y tus cosas, guarda copia digital de tus escrituras y pólizas y revisa si tu seguro cubre sismo o inundación.



### Para saber más

- **Seguro de casa y siniestros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de casa» y «siniestro».
- **Protección Civil** (Coordinación Nacional de Protección Civil · español): https://www.gob.mx/cnpc — **Qué buscar:** «plan familiar de protección civil».

### Palabras clave

- *Siniestro:* el daño que cubre el seguro, como un sismo o un incendio.
- *Suma asegurada:* el monto máximo que paga el seguro.

### Fuentes

CONDUSEF · Ley sobre el Contrato de Seguro · Coordinación Nacional de Protección Civil, consultados el 29 de septiembre de 2026.

---

## M8 U07. IMSS por tu cuenta: Seguro de Salud para la Familia y Modalidad 10

**Lo que lograrás:** Identificar las dos formas de tener IMSS pagando tú (Seguro de Salud para la Familia y personas trabajadoras independientes), cuánto cuestan en 2026 y cuándo conviene cada una frente a un seguro de gastos médicos privado.

**Para empezar:** A Elena le subió 30% su seguro de gastos médicos. Maru vende por catálogo y no tiene servicio médico. Las dos escucharon que «se puede pagar el IMSS por tu cuenta». En esta lección verás cómo.

### Lo esencial (5 minutos)

#### Dos formas de pagar tú el IMSS

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguro de Salud para la Familia | Solo servicio médico. | Cuota al año por persona y edad. |
| Personas trabajadoras independientes (Modalidad 10) | Médico, incapacidades, semanas y Afore. | Cuota mensual según tu ingreso. |
| Periodos de espera | Algunas atenciones se cubren después de meses. | Pregunta. |
| Enfermedades previas | Algunas no se cubren al inicio. | Pregunta antes. |

#### Seguro de Salud para la Familia: cuota anual por persona en 2026

| Edad | Cuota al año |
|---|---|
| 0 a 19 | 9,300 |
| 20 a 29 | 11,550 |
| 30 a 39 | 11,850 |
| 40 a 49 | 13,800 |
| 50 a 59 | 14,250 |
| 60 a 69 | 19,800 |
| 70 a 79 | 20,650 |
| 80 o más | 21,300 |

> **Dato vigente:** las cuotas anuales del Seguro de Salud para la Familia (Modalidad 33) están vigentes desde el 1 de marzo de 2026. En la Modalidad 10 se cotiza de un salario mínimo a 25 UMA. Con el mínimo, la cuota ronda 2,500 pesos al mes. Consultado el 30 de septiembre de 2026 a través del IMSS y medios nacionales; confirma en el IMSS antes de pagar.



#### ¿IMSS o seguro privado?

El IMSS pagado por tu cuenta cuesta menos que muchos seguros de gastos médicos privados, pero te atiendes en sus clínicas y hospitales. Un seguro privado te da hospitales privados, con deducible y coaseguro. Hay quienes combinan: IMSS como base y un seguro privado con deducible alto para lo grave.



#### Un caso en un minuto

Maru se inscribió como persona trabajadora independiente: tiene médico, incapacidades y suma semanas a su pensión. Elena inscribió a sus hijos adolescentes en el Seguro de Salud para la Familia. También subió el deducible de su seguro privado para bajar la prima.

> **Idea clave:** si no tienes IMSS, puedes pagarlo tú. El Seguro de Salud para la Familia da solo servicio médico, por una cuota anual según tu edad. La Modalidad 10 da además incapacidades y pensión. Compara con tu seguro privado y pregunta antes qué cubre.



#### Comprueba lo que entendiste

1. ¿Qué da el Seguro de Salud para la Familia?
*Respuesta:* Solo servicio médico.

2. ¿Qué da además la Modalidad 10?
*Respuesta:* Incapacidades, semanas para la pensión y Afore.


#### Para recordar

- Seguro familiar: salud, por edad.
- Modalidad 10: salud, incapacidades y pensión.
- Compara con tu seguro privado.



### Profundiza (5 minutos más)

#### Compara

| Punto | Seguro familiar IMSS | Modalidad 10 | Seguro privado |
|---|---|---|---|
| Costo | Cuota anual por edad | Mensual según ingreso | Prima que sube con la edad |
| Dónde te atiendes | IMSS | IMSS | Hospitales privados |
| Incapacidades | No | Sí | Según póliza |
| Pensión | No | Suma semanas | No |



#### Para tus papás

Si tus papás no tienen seguridad social, el Seguro de Salud para la Familia puede ser una opción. Para personas mayores también existen el IMSS-Bienestar y los centros de salud sin costo.



#### Casos


**Caso 1. El seguro de Elena**

El seguro privado de Elena subió 30%.
- *¿Qué hace?* Compara con el IMSS por su cuenta y con subir su deducible.


**Caso 2. El catálogo de Maru**

Maru vende por catálogo y no tiene servicio médico ni suma semanas.
- *¿Qué hace?* Revisa la Modalidad 10 como persona trabajadora independiente.


**Caso 3. La mamá de Carmen**

La mamá de Carmen tiene 72 años y una enfermedad del corazón.
- *¿Qué hace?* Pregunta antes de pagar si su enfermedad se cubre y desde cuándo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cancelar todo sin alternativa | Te quedas sin protección | Compara antes |
| Creer que el seguro familiar da pensión | No sumas semanas | Es solo salud |
| No preguntar por enfermedades previas | Sorpresas | Pregunta |
| Pagar gestores | Te cobran de más | Trámite directo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Maru y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta en 2026 el seguro familiar del IMSS para una persona de 55 años? a) 9,300 · b) 14,250 · c) 21,300
2. ¿Qué modalidad suma semanas para tu pensión? a) La Modalidad 10 · b) El seguro familiar · c) Ninguna de las dos
3. ¿Qué preguntas antes de pagar? a) El color de la credencial · b) Qué cubre y desde cuándo · c) Nada, todo está cubierto
**Respuestas:** 1-b: de 50 a 59 años. 2-a: es régimen obligatorio. 3-b: hay periodos de espera.



#### Ponlo en práctica

Quieres inscribir a tus dos hijos de 15 y 17 años en el seguro familiar. ¿Cuánto pagas al año y al mes?
**Respuesta:** 9,300 por 2: 18,600 al año; unos 1,550 al mes.



#### A tu plan

Anota quién en tu familia no tiene seguridad social y calcula su cuota en la tabla.



### Para saber más

- **Seguro de Salud para la Familia** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «Seguro de Salud para la Familia».
- **Personas trabajadoras independientes** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-independientes — **Qué buscar:** calculadora.

### Palabras clave

- *Seguro de Salud para la Familia:* seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- *Modalidad 10:* incorporación voluntaria al IMSS de personas trabajadoras independientes, con servicio médico, incapacidades y pensión.

### Fuentes

IMSS · medios nacionales que citan las cuotas 2026, consultados el 30 de septiembre de 2026.

---


# Parte 10. Módulo 9. Impuestos sin miedo

## M9 U01. ¿Tengo que declarar?

**Lo que lograrás:** Identificar en qué casos debes presentar declaración anual, qué es el RFC y la e.firma, y cómo acercarte al SAT sin miedo.

**Para empezar:** Lucía recibe su pensión de viudez, intereses de sus inversiones y la renta de un local. Su hijo le dice que «las pensionadas no declaran». Su contadora le dice que quizá sí. En esta lección verás de qué depende.

### Lo esencial (5 minutos)

#### Depende de tus ingresos

Si solo recibes una pensión dentro del límite exento y pocos intereses, muchas veces no tienes que declarar. Si recibes rentas, tienes un negocio, tu pensión pasa el límite exento o tus intereses son altos, probablemente sí.



#### Tus datos con el SAT

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| RFC | Tu clave ante el SAT. | La puedes obtener con tu CURP. |
| Contraseña del SAT | Para entrar al portal. | Trámite sencillo. |
| e.firma | Tu firma electrónica. | Para trámites importantes. |
| Buzón tributario | Donde el SAT te avisa. | Revísalo. |

#### Sin miedo

El SAT no persigue a quien cumple. Tener tu RFC y tu contraseña te permite ver qué sabe el SAT de ti, descargar tus constancias y, si te corresponde, recibir devoluciones.



#### Un caso en un minuto

Lucía revisó con una contadora sus ingresos: la renta del local la obliga a declarar. Tramitó su contraseña del SAT y ahora presenta su declaración en abril. En su primer año recibió un saldo a favor por sus gastos médicos.

> **Idea clave:** declarar depende de tus ingresos; tener tu RFC y contraseña te da control y, a veces, devoluciones.



#### Comprueba lo que entendiste

1. ¿Una pensión dentro del límite exento, sola, suele obligarte a declarar?
*Respuesta:* En general no, pero depende de tus otros ingresos.

2. ¿Qué te permite la contraseña del SAT?
*Respuesta:* Entrar al portal, ver tu información, descargar constancias y presentar declaraciones.


#### Para recordar

- Depende de tus ingresos.
- RFC y contraseña te dan control.
- Pide orientación si tienes dudas.



### Profundiza (5 minutos más)

#### ¿Probablemente declaras?

| Si recibes… | Probablemente |
|---|---|
| Solo pensión dentro del límite exento | No |
| Pensión que pasa el límite exento | Sí |
| Rentas de un inmueble | Sí |
| Un negocio o trabajo por tu cuenta | Sí |
| Intereses altos | Revisa con tu constancia |



#### Dónde pedir ayuda

El SAT orienta sin costo en sus oficinas y por teléfono. PRODECON ayuda sin costo si tienes un problema con el SAT. Un contador puede ayudarte con tu declaración; pide su cédula profesional.



#### Mensajes falsos del SAT

El SAT no te pide datos bancarios por mensaje ni te manda enlaces para devoluciones. Entra solo a sat.gob.mx escribiendo tú la dirección.

> **Antes de actuar, verifica:** tu caso particular con el SAT, PRODECON o un contador con cédula; las reglas dependen de tus ingresos exactos.



#### Casos


**Caso 1. La renta de Lucía**

Lucía recibe pensión, intereses y la renta de un local, y su hijo dice que no declara.
- *¿Qué hace?* Revisa sus ingresos con una contadora o el SAT para saber si debe declarar.


**Caso 2. La contraseña de Carmen**

Carmen nunca ha tenido contraseña del SAT y le da miedo tramitarla.
- *¿Qué hace?* La tramita para ver su información y descargar sus constancias.


**Caso 3. El mensaje de Maru**

A Maru le llega un mensaje del «SAT» con un enlace para cobrar una devolución.
- *¿Qué hace?* No abre el enlace y entra ella a sat.gob.mx.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Suponer que no declaras | Multas | Revisa tus ingresos |
| Evitar el SAT por miedo | Pierdes devoluciones | Tramita tu contraseña |
| Abrir enlaces del «SAT» | Fraude | Entra tú al sitio |
| Contador sin cédula | Errores | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Recibes rentas de un departamento. ¿Qué pasa? a) Nunca declaras si eres pensionada · b) Probablemente debes declarar · c) Solo declaras si el SAT te llama
2. ¿Dónde pides ayuda sin costo si tienes un problema con el SAT? a) PRODECON · b) Con un gestor que cobra · c) En el banco
3. Te llega un enlace del «SAT» para una devolución. ¿Qué haces? a) Lo abres rápido para no perderla · b) Lo reenvías a tu contadora · c) Entras tú a sat.gob.mx
**Respuestas:** 1-b: las rentas suelen obligarte. 2-a: no tiene costo. 3-c: el SAT no manda enlaces así.



#### Ponlo en práctica

Escribe tus ingresos del año y marca cuáles podrían obligarte a declarar.
**Respuesta:** Por ejemplo: pensión de viudez (revisar límite), intereses (revisar constancia), renta del local (probablemente sí).



#### A tu plan

Tramita tu contraseña del SAT y descarga tu constancia de situación fiscal.



### Para saber más

- **SAT** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «contraseña» y «declaración anual personas físicas».
- **PRODECON** (PRODECON · español): https://www.prodecon.gob.mx — **Qué buscar:** asesoría sin costo.

### Palabras clave

- *RFC:* Registro Federal de Contribuyentes, tu clave ante el SAT.
- *e.firma:* tu firma electrónica para trámites con el SAT.
- *Saldo a favor:* impuesto que pagaste de más y el SAT te puede devolver.

### Fuentes

SAT · PRODECON, consultados el 29 de septiembre de 2026.

---

## M9 U02. Lo que te retienen

**Lo que lograrás:** Explicar las retenciones de impuestos sobre tus intereses (0.90% sobre el capital en 2026) y sobre tu pensión si pasa de 15 UMA, y usar tus constancias de retenciones.

**Para empezar:** En el estado de cuenta de Carmen aparece «ISR retenido». Cree que el banco le cobra una comisión extra. En realidad es un impuesto que ya pagó por adelantado y que puede servirle en su declaración. En esta lección entenderás tus retenciones.

### Lo esencial (5 minutos)

#### Qué es una retención

Una retención es un impuesto que tu banco, casa de bolsa o pagador descuenta y entrega al SAT por ti. No es una comisión: es un pago adelantado de tu impuesto.



#### Retenciones comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Intereses | 0.90% anual sobre tu capital en 2026. | Sube respecto a 2025. |
| Pensión | Solo sobre lo que pasa de 15 UMA al mes. | La mayoría no paga. |
| Constancia | Documento anual con lo retenido. | Guárdala. |
| En tu declaración | Lo retenido se resta de tu impuesto. | Puede darte saldo a favor. |

> **Dato vigente:** en 2026, la tasa de retención anual por intereses es de 0.90% sobre el capital (0.50% en 2025). Las pensiones no pagan ISR hasta 15 UMA, es decir, 53,493.30 pesos al mes. Consultado el 29 de septiembre de 2026 a través de la Ley de Ingresos de la Federación 2026, la LISR (art. 93-IV) y el INEGI (UMA 2026).

#### Un ejemplo

Si tienes 500,000 en un pagaré todo el año, la retención sería de unos 4,500 pesos (0.90%). En tu declaración, el impuesto real se calcula sobre el interés que ganaste por encima de la inflación, y lo retenido se resta.



#### Un caso en un minuto

Carmen entendió que el «ISR retenido» no era una comisión. Guardó su constancia anual de retenciones en su carpeta para su declaración.

> **Idea clave:** las retenciones son impuesto pagado por adelantado; guarda tus constancias.



#### Comprueba lo que entendiste

1. ¿La retención es una comisión del banco?
*Respuesta:* No. Es un impuesto que el banco entrega al SAT por ti.

2. ¿Cuánto de tu pensión está exento?
*Respuesta:* Hasta 15 UMA al mes: 53,493.30 pesos en 2026.


#### Para recordar

- Retención = impuesto adelantado.
- 0.90% sobre el capital en 2026.
- Pensión exenta hasta 15 UMA.



### Profundiza (5 minutos más)

#### Tus constancias

| Institución | ¿Recibí constancia? | ¿Dónde la guardé? |
|---|---|---|
| Banco (intereses) | | |
| Casa de bolsa | | |
| IMSS o pagador de pensión | | |



#### Cómo obtenerlas

Las instituciones las envían o las publican en su portal a inicios de cada año. También aparecen en el portal del SAT con tu contraseña.



#### Si tu pensión pasa el límite

Si tu pensión pasa de 15 UMA al mes, solo lo que excede paga impuesto. Tu pagador puede retenerte y quizá debas declarar. Pide orientación.

> **Antes de actuar, verifica:** el valor de la UMA cambia cada febrero y la tasa de retención cada año con la Ley de Ingresos.



#### Casos


**Caso 1. El ISR de Carmen**

Carmen cree que el «ISR retenido» es una comisión extra del banco.
- *¿Qué hace?* Entiende que es impuesto pagado por adelantado y guarda su constancia.


**Caso 2. La pensión de Lucía**

La pensión de Lucía es de 25,000 al mes y teme pagar mucho impuesto.
- *¿Qué hace?* Revisa que está por debajo de 15 UMA y, por tanto, exenta.


**Caso 3. Las constancias de Elena**

Elena nunca descarga sus constancias de retenciones.
- *¿Qué hace?* Las descarga cada año del portal de sus instituciones o del SAT.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es comisión | Confusión | Es impuesto |
| Perder constancias | No las acreditas | Guárdalas |
| Temer por tu pensión | Angustia innecesaria | Revisa el límite |
| No revisar cambios anuales | Datos viejos | UMA y tasa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es una retención? a) Una comisión que cobra el banco por administrar · b) Impuesto pagado por adelantado · c) Una multa del SAT
2. Tienes 200,000 en un pagaré todo 2026. ¿Cuánto te retienen aproximadamente? a) 1,800 · b) 900 · c) 18,000
3. Tu pensión es de 30,000 al mes. ¿Paga ISR? a) Sí, toda la pensión paga impuesto desde el primer peso · b) Sí, la mitad · c) No, está dentro del límite exento
**Respuestas:** 1-b: se resta en tu declaración. 2-a: 0.90% de 200,000. 3-c: está por debajo de 15 UMA.



#### Ponlo en práctica

Tienes 800,000 en pagarés todo el año. ¿Cuánto te retienen en 2026?
**Respuesta:** 0.90% de 800,000: 7,200.



#### A tu plan

Llena la tabla de constancias y descarga las que te falten.



### Para saber más

- **Constancias y declaraciones** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «constancia de retenciones» y «declaración anual».

### Palabras clave

- *Retención:* impuesto que una institución descuenta de tus ingresos y entrega al SAT por ti.
- *UMA:* Unidad de Medida y Actualización, referencia para límites fiscales.
- *Exento:* ingreso que no paga impuesto.

### Fuentes

Ley de Ingresos de la Federación 2026 · LISR · INEGI · SAT, consultados el 29 de septiembre de 2026.

---

## M9 U03. Deducciones personales y tu declaración anual

**Lo que lograrás:** Identificar tus deducciones personales (gastos médicos, primas de gastos médicos, funerales, intereses de crédito hipotecario, aportaciones voluntarias), el tope y cómo pueden darte saldo a favor.

**Para empezar:** Elena paga 48,000 al año de seguro de gastos médicos y miles en consultas. No sabía que, si declara, esos gastos pueden reducir su impuesto. En esta lección verás qué puedes deducir.

### Lo esencial (5 minutos)

#### Qué es deducir

Una deducción personal es un gasto que restas de tus ingresos en tu declaración anual. Si ya te retuvieron impuesto, puede darte un saldo a favor.



#### Deducciones comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gastos médicos | Consultas, hospital, análisis. | Pago con tarjeta o transferencia. |
| Primas de gastos médicos | Tu seguro. | Con factura. |
| Gastos funerarios | Con límite. | Con factura. |
| Intereses reales de crédito hipotecario | Si tienes hipoteca. | Constancia del banco. |

#### Requisitos

Pide **factura** a tu nombre (con tu RFC) y paga con tarjeta, transferencia o cheque, no en efectivo. Sin eso, no puedes deducir.



#### Un caso en un minuto

Elena empezó a pedir factura de cada consulta y de su seguro. En su declaración de abril dedujo 70,000 y recibió un saldo a favor.

> **Idea clave:** con factura a tu nombre y pago no en efectivo, tus gastos médicos y tu seguro pueden reducir tu impuesto.



#### Comprueba lo que entendiste

1. ¿Qué necesitas para deducir un gasto médico?
*Respuesta:* Factura a tu nombre y pago con tarjeta, transferencia o cheque.

2. ¿Puedes deducir la prima de tu seguro de gastos médicos?
*Respuesta:* Sí, con factura.


#### Para recordar

- Factura a tu nombre.
- Pago no en efectivo.
- Hay un tope total.



### Profundiza (5 minutos más)

#### El tope

En general, tus deducciones personales no pueden pasar del menor entre cinco UMA anuales y el 15% de tus ingresos. Algunos conceptos (como ciertos gastos médicos por incapacidad o las aportaciones voluntarias al retiro) tienen reglas propias.

> **Dato vigente:** el tope general de deducciones personales es el menor entre 5 UMA anuales (213,973.20 pesos en 2026) y el 15% de tus ingresos. Consultado el 29 de septiembre de 2026 a través de la LISR (art. 151) y el INEGI.



#### Tu lista de facturas

| Gasto | ¿Factura a mi nombre? | ¿Pagué sin efectivo? |
|---|---|---|
| Seguro de gastos médicos | | |
| Consultas y análisis | | |
| Hospital | | |
| Lentes graduados | | |



#### Tu declaración

La declaración anual de personas físicas se presenta en abril. El SAT te muestra una propuesta con tus facturas; revísala. Si te sale saldo a favor, pide la devolución a tu cuenta.

> **Antes de actuar, verifica:** los requisitos de cada deducción en el sitio del SAT, o pide ayuda a un contador con cédula.



#### Casos


**Caso 1. El seguro de Elena**

Elena paga su seguro y consultas, pero nunca pide factura.
- *¿Qué hace?* Pide factura a su nombre y paga con tarjeta o transferencia.


**Caso 2. El efectivo de Carmen**

Carmen paga sus consultas en efectivo.
- *¿Qué hace?* Paga con tarjeta o transferencia para poder deducirlas.


**Caso 3. La devolución de Lucía**

Lucía tiene saldo a favor en su declaración y no sabe qué hacer.
- *¿Qué hace?* Solicita la devolución a su cuenta en la misma declaración.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No pedir factura | No deduces | Pídela siempre |
| Pagar en efectivo | No deduces | Tarjeta o transferencia |
| No revisar la propuesta del SAT | Errores | Revísala |
| Olvidar el saldo a favor | Pierdes dinero | Pide la devolución |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué necesitas para deducir? a) El ticket de la farmacia · b) Una nota firmada por el médico · c) Factura a tu nombre y pago no en efectivo
2. ¿En qué mes se presenta la declaración anual de personas físicas? a) Abril · b) Diciembre · c) Enero
3. ¿Qué haces con un saldo a favor? a) Lo dejas para el siguiente año · b) Lo pides en devolución · c) Nada, se pierde
**Respuestas:** 1-c: requisitos del SAT. 2-a: en abril. 3-b: es tu dinero.



#### Ponlo en práctica

Tus ingresos son 400,000 al año. ¿Cuál es tu tope general de deducciones: 15% de tus ingresos o 213,973.20?
**Respuesta:** 15% de 400,000 es 60,000, que es menor; tu tope general es 60,000.



#### A tu plan

Empieza hoy tu lista de facturas del año y pide factura de tu próximo gasto médico.



### Para saber más

- **Deducciones personales** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «deducciones personales».

### Palabras clave

- *Deducción personal:* gasto que puedes restar de tus ingresos en tu declaración anual para pagar menos impuesto.
- *Factura:* comprobante fiscal digital (CFDI) a tu nombre.

### Fuentes

SAT · LISR · INEGI, consultados el 29 de septiembre de 2026.

---


# Parte 11. Módulo 10. Patrimonio y familia

## M10 U01. Testamento: tu decisión por escrito

**Lo que lograrás:** Explicar por qué hacer testamento, qué pasa si no lo haces, cuánto cuesta y cómo aprovechar el Mes del Testamento.

**Para empezar:** El esposo de Lucía no dejó testamento. Aunque todo estaba claro en la familia, el juicio para repartir la casa y las inversiones tardó más de un año y costó mucho. Lucía no quiere que sus hijos pasen por lo mismo. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Qué es

Un testamento es tu decisión por escrito: a quién pasan tus bienes y quién se encarga del trámite. Se hace ante notario.



#### Con y sin testamento

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Con testamento | Se cumple lo que decidiste. | Trámite más ágil. |
| Sin testamento | Decide la ley y a veces un juez. | Más lento y caro. |
| Albacea | La persona que se encarga del trámite. | Elígela bien. |
| Mes del Testamento | Septiembre, con descuentos. | Buen momento. |

#### Cuánto cuesta

El costo depende del estado y la notaría. En el Mes del Testamento (septiembre) hay descuentos importantes en muchas notarías del país.

> **Dato vigente:** en el Mes del Testamento 2026 hubo descuentos de hasta 50%, con testamentos desde unos 2,750 pesos según el estado. Consultado el 29 de septiembre de 2026 a través de la Secretaría de Gobernación y medios nacionales.



#### Un caso en un minuto

Lucía hizo su testamento en septiembre. Nombró albacea a su hija mayor y anotó en su carpeta la notaría. Sus hijos saben que existe y dónde está.

> **Idea clave:** con testamento se cumple tu decisión y tu familia se ahorra tiempo, dinero y conflictos.



#### Comprueba lo que entendiste

1. ¿Qué es el albacea?
*Respuesta:* La persona que se encarga del trámite de tu herencia.

2. ¿Qué pasa sin testamento?
*Respuesta:* Decide la ley y el trámite suele ser más lento y caro.


#### Para recordar

- Tu decisión por escrito.
- Nombra albacea.
- Septiembre, Mes del Testamento.



### Profundiza (5 minutos más)

#### Prepara tu cita con la notaría

| Qué llevar | Lo tengo |
|---|---|
| Identificación oficial | |
| CURP y acta de nacimiento | |
| Lista de bienes (tu inventario) | |
| Nombres de herederos y albacea | |
| Datos de dos testigos, si te los piden | |



#### Testamento y beneficiarios

Tus cuentas, seguros y AFORE pasan a quienes nombraste como beneficiarios, sin importar el testamento, en los límites de cada ley. Por eso revisa ambos: que digan lo mismo (M10 U02).



#### Puedes cambiarlo

Puedes hacer un testamento nuevo cuando cambie tu vida: un divorcio, una viudez, un nuevo bien. El último testamento es el que vale.

> **Antes de actuar, verifica:** los costos y requisitos con la notaría de tu estado; hazlo siempre ante notario, no con formatos de internet.



#### Casos


**Caso 1. Los hijos de Lucía**

Lucía no quiere que sus hijos pasen por un juicio largo como ella.
- *¿Qué hace?* Hace su testamento ante notario y nombra albacea.


**Caso 2. El formato de Carmen**

Carmen quiere hacer su testamento con un formato de internet.
- *¿Qué hace?* Lo hace ante notario para que sea válido.


**Caso 3. El divorcio de Elena**

Elena hizo testamento cuando estaba casada y ya se divorció.
- *¿Qué hace?* Hace un testamento nuevo con su situación actual.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No hacerlo | Juicio largo | Hazlo |
| Formatos de internet | Puede no valer | Ante notario |
| No avisar que existe | Nadie lo busca | Díselo a tu familia |
| No actualizarlo | Refleja otra vida | Hazlo nuevo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Ante quién se hace un testamento? a) Ante un abogado cualquiera · b) Ante tu banco · c) Ante notario
2. ¿Qué testamento vale si hiciste varios? a) El último · b) El primero · c) El más largo
3. ¿Cuándo hay descuentos en muchas notarías? a) En diciembre · b) En septiembre · c) Nunca
**Respuestas:** 1-c: así es válido. 2-a: el último es el que vale. 3-b: el Mes del Testamento.



#### Ponlo en práctica

Llena la tabla para preparar tu cita con la notaría.
**Respuesta:** Por ejemplo: INE, CURP, acta de nacimiento, inventario, herederos (mis hijos) y albacea (mi hija mayor).



#### A tu plan

Agenda tu cita con una notaría, de preferencia en septiembre, y lleva tu inventario.



### Para saber más

- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento» y notarías participantes.

### Palabras clave

- *Testamento:* documento en el que decides a quién pasan tus bienes cuando faltes.
- *Albacea:* persona que se encarga del trámite de la herencia.
- *Heredero:* persona que recibe los bienes de otra al fallecer.

### Fuentes

Secretaría de Gobernación · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M10 U02. Beneficiarios: cuentas, seguros y AFORE

**Lo que lograrás:** Revisar y actualizar los beneficiarios de tus cuentas, seguros y AFORE, y saber sus límites y su relación con el testamento.

**Para empezar:** Cuando Carmen revisó sus cuentas, descubrió algo. En una, su beneficiario era su hermano, con quien ya no habla. En su seguro de vida era su mamá, que falleció. En esta lección pondrás al día a tus beneficiarios.

### Lo esencial (5 minutos)

#### Qué es un beneficiario

Un beneficiario recibe el dinero de una cuenta, un seguro o tu AFORE cuando faltas, con un trámite más rápido que la herencia.



#### Dónde revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuentas bancarias | En el contrato o la app. | Con porcentajes. |
| Seguros de vida | En la póliza. | Actualízalos. |
| AFORE | En tu AFORE o AforeMóvil. | Sin costo. |
| Inversiones | En el contrato. | Pregunta en tu institución. |

#### Tiene límites

En las cuentas bancarias, la ley pone un límite a lo que se entrega directamente a los beneficiarios. Lo que pase de ese límite puede requerir el trámite de herencia. Por eso el testamento y los beneficiarios se complementan.



#### Un caso en un minuto

Carmen actualizó a sus beneficiarios: sus dos hijos, 50% cada uno, en cuentas, seguro y AFORE. Anotó en su carpeta qué dice cada contrato.

> **Idea clave:** revisa tus beneficiarios en cuentas, seguros y AFORE; que coincidan con tu testamento y con tu vida de hoy.



#### Comprueba lo que entendiste

1. ¿Qué pasa si tu beneficiario falleció?
*Respuesta:* Debes nombrar uno nuevo; si no, el trámite se complica.

2. ¿Los beneficiarios sustituyen al testamento?
*Respuesta:* No del todo; se complementan porque hay límites.


#### Para recordar

- Cuentas, seguros, AFORE e inversiones.
- Con porcentajes claros.
- Complementan al testamento.



### Profundiza (5 minutos más)

#### Tu revisión de beneficiarios

| Producto | Beneficiarios y porcentaje | Fecha de revisión |
|---|---|---|
| Cuenta 1 | | |
| Cuenta 2 | | |
| Seguro de vida | | |
| AFORE | | |
| Inversión | | |



#### Beneficiarios menores de edad

Si nombras a una persona menor de edad, pregunta cómo se le entregaría el dinero; puede necesitar un tutor. A veces conviene nombrar a un adulto de confianza o prever un tutor en tu testamento.



#### Cuándo revisar

Revisa tus beneficiarios cuando cambie tu familia (matrimonio, divorcio, viudez, nacimientos) y una vez al año, junto con tu carpeta.

> **Antes de actuar, verifica:** los límites y el trámite con cada institución; pide constancia por escrito del cambio.



#### Casos


**Caso 1. El hermano de Carmen**

El beneficiario de una cuenta de Carmen es su hermano, con quien ya no habla.
- *¿Qué hace?* Actualiza a sus beneficiarios en esa cuenta.


**Caso 2. El nieto de Lucía**

Lucía quiere nombrar beneficiario a su nieto de 8 años.
- *¿Qué hace?* Pregunta cómo se le entregaría y prevé un tutor en su testamento.


**Caso 3. La AFORE de Elena**

Elena no sabe quién es su beneficiario en la AFORE.
- *¿Qué hace?* Lo consulta y actualiza en su AFORE o en AforeMóvil.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisarlos | Dinero a quien no quieres | Revisa cada año |
| Sin porcentajes | Conflictos | Pon porcentajes claros |
| Menores sin tutor | Trámite difícil | Prevé un tutor |
| Creer que bastan | Límites | Haz testamento |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde revisas tus beneficiarios de la AFORE? a) En tu AFORE o AforeMóvil · b) En el SAT, con tu RFC y tu contraseña · c) En tu banco
2. ¿Los beneficiarios reemplazan al testamento? a) Sí, siempre · b) Solo en el caso de las cuentas · c) No del todo: se complementan
3. ¿Cuándo revisas a tus beneficiarios? a) Cuando cambia tu familia y cada año · b) Solo al abrir la cuenta · c) Nunca
**Respuestas:** 1-a: ahí se actualizan. 2-c: hay límites. 3-a: así están al día.



#### Ponlo en práctica

Tienes dos hijos y quieres dejarles lo mismo. ¿Qué porcentaje pones a cada uno en tus cuentas?
**Respuesta:** 50% a cada uno.



#### A tu plan

Llena la tabla de beneficiarios y actualiza al menos uno este mes.



### Para saber más

- **Beneficiarios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «beneficiarios» y «testamento».

### Palabras clave

- *Beneficiario:* persona que recibe el dinero de una cuenta, seguro o AFORE cuando el titular fallece.
- *Tutor:* persona que cuida los intereses de un menor de edad.

### Fuentes

CONDUSEF · Ley de Instituciones de Crédito, consultadas el 29 de septiembre de 2026.

---

## M10 U03. Poder notarial y quién decide si tú no puedes

**Lo que lograrás:** Identificar los tipos de poder notarial, sus riesgos, y cómo dejar por escrito quién decide sobre tu salud y tus bienes si no puedes hacerlo.

**Para empezar:** La mamá de Elena tuvo un derrame y no podía firmar. Elena necesitaba pagar el hospital con los ahorros de su mamá, pero el banco no le dejó. En esta lección verás cómo prepararte para ese momento.

### Lo esencial (5 minutos)

#### El poder notarial

Un poder notarial autoriza a una persona de tu confianza a hacer trámites por ti. Puede ser amplio o solo para ciertas cosas.



#### Tipos de poder

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Especial | Para un trámite concreto. | Más control. |
| General | Para muchos actos. | Más riesgo. |
| Para vender o regalar | El más delicado. | Piénsalo bien. |
| Revocable | Puedes cancelarlo. | Ante notario. |

#### Si no puedes decidir

Además del poder, en varios estados puedes firmar una voluntad anticipada sobre tu atención médica. En algunos también puedes nombrar a quien sería tu tutor si lo necesitaras. Pregunta en tu notaría.



#### Un caso en un minuto

Después del susto, Elena y su mamá fueron a la notaría. Su mamá dio a Elena un poder especial para pagos médicos y trámites bancarios, y firmó su voluntad anticipada.

> **Idea clave:** un poder bien pensado y tu voluntad anticipada evitan que tu familia quede sin poder actuar.



#### Comprueba lo que entendiste

1. ¿Qué es un poder especial?
*Respuesta:* Un poder para un trámite concreto.

2. ¿Se puede cancelar un poder?
*Respuesta:* Sí, es revocable ante notario.


#### Para recordar

- Poder especial, más control.
- Voluntad anticipada para tu salud.
- Revocable.



### Profundiza (5 minutos más)

#### Riesgos de un poder amplio

Un poder general, sobre todo para vender o regalar bienes, puede usarse en tu contra. Dalo solo a quien confíes totalmente, por tiempo limitado si es posible, y pide que te informen de cada uso.



#### Antes de firmar

| Pregunta | Respuesta |
|---|---|
| ¿Para qué trámites exactamente? | |
| ¿A quién y por qué a esa persona? | |
| ¿Por cuánto tiempo? | |
| ¿Cómo me informará de cada uso? | |



#### Presión para firmar

Nadie debe presionarte para firmar un poder. Si alguien, aunque sea de tu familia, insiste en que firmes rápido un poder amplio, detente y consulta con otra persona de confianza (módulo 11).

> **Antes de actuar, verifica:** qué documentos existen en tu estado (voluntad anticipada, designación de tutor) y su costo en la notaría.



#### Casos


**Caso 1. La mamá de Elena**

Elena no pudo pagar el hospital con los ahorros de su mamá porque ella no podía firmar.
- *¿Qué hacen después?* Firman un poder especial para pagos médicos y trámites bancarios.


**Caso 2. El poder amplio de Lucía**

Un sobrino le pide a Lucía un poder general «para ayudarla con todo».
- *¿Qué hace?* No firma un poder amplio; si necesita ayuda, da un poder especial y limitado.


**Caso 3. La voluntad de Carmen**

Carmen quiere dejar por escrito qué tratamientos médicos quiere.
- *¿Qué hace?* Pregunta en su notaría por la voluntad anticipada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Poder amplio por confianza | Pueden usarlo mal | Especial y limitado |
| Firmar con prisa | Presión | Consulta antes |
| No revocar poderes viejos | Siguen vigentes | Revócalos |
| No prever tu salud | Otros deciden | Voluntad anticipada |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena, Lucía y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué poder te da más control? a) El especial · b) El general para todo · c) El poder para vender y regalar bienes
2. Te presionan para firmar un poder amplio rápido. ¿Qué haces? a) Firmas para evitar problemas · b) Firmas solo si es familia · c) Te detienes y consultas
3. ¿Qué documento dice qué tratamientos quieres? a) El testamento que haces ante notario · b) La voluntad anticipada · c) El poder general
**Respuestas:** 1-a: limita lo que pueden hacer. 2-c: la prisa es una alerta. 3-b: es sobre tu salud.



#### Ponlo en práctica

Llena la tabla «antes de firmar» para un poder que pienses dar.
**Respuesta:** Por ejemplo: pagos médicos y trámites bancarios; a mi hija mayor; por dos años; me enviará cada comprobante.



#### A tu plan

Decide a quién darías un poder especial y pregunta en tu notaría por la voluntad anticipada.



### Para saber más

- **Voluntad anticipada** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «voluntad anticipada» en tu estado.

### Palabras clave

- *Poder notarial:* documento ante notario en el que autorizas a otra persona a actuar por ti.
- *Voluntad anticipada:* documento en el que dices qué tratamientos médicos quieres o no si no puedes decidir.
- *Revocar:* cancelar un poder o un documento.

### Fuentes

Gobierno de México · notarías estatales, consultados el 29 de septiembre de 2026.

---

## M10 U04. Ayudar a los hijos sin descuidar tu futuro

**Lo que lograrás:** Poner límites sanos al apoyo económico a tus hijos: préstamos, avales y herencia en vida, sin descuidar tu retiro.

**Para empezar:** El hijo de Carmen le pide 300,000 para el enganche de un departamento, «prestado». También quiere que sea su aval en un crédito. Carmen quiere ayudar, pero ese dinero es parte de su retiro. En esta lección verás cómo decidir.

### Lo esencial (5 minutos)

#### Ayudar sí, pero con cuentas claras

Ayudar a tus hijos es natural. Lo importante es que tu ayuda no ponga en riesgo tu retiro ni tu salud. Primero calcula tu retiro (M7 U06); después decide cuánto puedes dar.



#### Formas de ayudar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Regalo | Das sin esperar que te devuelvan. | Solo lo que te sobra. |
| Préstamo | Esperas que te devuelvan. | Por escrito, con plazos. |
| Aval | Si tu hijo no paga, pagas tú. | El más riesgoso. |
| Herencia en vida | Transfieres bienes ahora. | Piénsalo con asesoría. |

#### Ser aval

Ser aval significa que si tu hijo no paga, la deuda es tuya y puede afectar tu historial. Hazlo solo si podrías pagar toda la deuda sin afectar tu retiro.



#### Un caso en un minuto

Carmen calculó su retiro: podía dar 100,000 sin afectarlo. Se lo regaló a su hijo para el enganche y no aceptó ser aval. Le explicó sus razones con cariño.

> **Idea clave:** ayuda con lo que te sobra después de asegurar tu retiro; ser aval es asumir la deuda.



#### Comprueba lo que entendiste

1. ¿Qué pasa si eres aval y tu hijo no paga?
*Respuesta:* La deuda es tuya.

2. ¿Qué calculas antes de ayudar?
*Respuesta:* Tu retiro, para saber cuánto puedes dar.


#### Para recordar

- Primero tu retiro.
- Préstamos por escrito.
- Aval = deuda tuya.



### Profundiza (5 minutos más)

#### Préstamo por escrito

| Dato | Acuerdo |
|---|---|
| Monto | |
| Plazo y fechas de pago | |
| ¿Con intereses? | |
| ¿Qué pasa si no paga a tiempo? | |
| Firma de ambos | |



#### Herencia en vida

Transferir tu casa o tus ahorros en vida puede dejarte sin recursos si los necesitas después, y tiene costos e impuestos. No lo hagas sin asesoría de una notaría y sin estar segura de que no lo necesitarás.



#### Entre hermanos

Si ayudas a un hijo, piensa si es justo para los demás. Anótalo; puedes considerarlo en tu testamento para evitar conflictos.

> **Antes de actuar, verifica:** antes de firmar como aval, lee el contrato completo y el monto total que podrías tener que pagar.



#### Casos


**Caso 1. El enganche del hijo de Carmen**

El hijo de Carmen le pide 300,000 prestados y que sea su aval.
- *¿Qué hace?* Calcula su retiro, da solo lo que puede y no firma como aval.


**Caso 2. La casa de Lucía**

Su hija le propone a Lucía poner la casa a su nombre «para evitar trámites».
- *¿Qué hace?* No transfiere sin asesoría notarial; considera el testamento en su lugar.


**Caso 3. El préstamo de Elena**

Elena presta 50,000 a su hijo sin anotar nada.
- *¿Qué hace?* Hace un acuerdo por escrito con monto y fechas de pago.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ayudar sin calcular | Descuidas tu retiro | Primero tu cálculo |
| Ser aval sin poder pagar | Deuda tuya | No firmes |
| Préstamos de palabra | Conflictos | Por escrito |
| Herencia en vida sin asesoría | Te quedas sin recursos | Consulta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué implica ser aval? a) Pagar la deuda si tu hijo no paga · b) Solo recomendar a tu hijo ante el banco · c) Recibir una comisión
2. ¿Qué haces antes de prestar dinero a un hijo? a) Prestas sin preguntar · b) Calculas tu retiro · c) Le pides que no se lo diga a nadie
3. ¿Cómo haces un préstamo familiar? a) De palabra, por confianza · b) Sin fechas, cuando pueda · c) Por escrito, con monto y fechas
**Respuestas:** 1-a: la deuda pasa a ti. 2-b: primero tu seguridad. 3-c: evita conflictos.



#### Ponlo en práctica

Tu retiro necesita 2,000,000 y tienes 2,300,000. ¿Cuánto podrías dar sin afectarlo?
**Respuesta:** 300,000, aunque conviene dejar un margen para imprevistos.



#### A tu plan

Antes de tu próxima ayuda económica, calcula cuánto puedes dar y, si es préstamo, escríbelo.



### Para saber más

- **Aval y créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ser aval».

### Palabras clave

- *Aval:* persona que se compromete a pagar una deuda si quien la pidió no paga.
- *Herencia en vida:* transferir bienes a tus herederos mientras vives.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M10 U05. Viudez o separación: los primeros 90 días

**Lo que lograrás:** Decidir qué hacer primero después de enviudar o separarte, qué no firmar con prisa y a quién acudir.

**Para empezar:** En las semanas después de la muerte de su esposo, a Lucía le llegaron ofertas. Un asesor quería «reacomodar» sus inversiones, un familiar le pedía dinero prestado y un agente le ofrecía un seguro. Ella estaba en duelo y no podía pensar. En esta lección verás cómo protegerte en esos días.

### Lo esencial (5 minutos)

#### Primero, pausa

En los primeros 90 días después de una pérdida o una separación, evita decisiones grandes: vender, invertir, prestar o firmar poderes. Tu prioridad es cuidarte y cubrir lo urgente.



#### Lo urgente

1. Asegura el dinero para tus gastos de los próximos meses.
2. Reúne documentos: actas, pólizas, estados de cuenta.
3. Avisa a bancos, aseguradoras y AFORE, por sus canales oficiales.
4. Inicia los trámites de seguros y pensión de viudez.
5. Protege tus cuentas: cambia contraseñas y revisa beneficiarios.



#### Lo que no firmas con prisa

Ventas de inmuebles, cambios de inversiones, poderes amplios, préstamos a terceros y seguros nuevos pueden esperar. Si alguien te presiona, es una señal para esperar.



#### Un caso en un minuto

Lucía hizo una lista de lo urgente y de lo que podía esperar. Dijo a todos: «lo veré en tres meses». Tramitó su pensión y el seguro de vida, y cambió sus contraseñas. Las demás decisiones las tomó con calma.

> **Idea clave:** en los primeros 90 días, atiende lo urgente y pon en pausa las decisiones grandes.



#### Comprueba lo que entendiste

1. ¿Qué evitas en los primeros 90 días?
*Respuesta:* Decisiones grandes: vender, invertir, prestar o firmar poderes.

2. ¿Qué haces primero?
*Respuesta:* Asegurar dinero para mis gastos y reunir documentos.


#### Para recordar

- Pausa en lo grande.
- Lo urgente primero.
- La presión es una señal para esperar.



### Profundiza (5 minutos más)

#### Urgente o puede esperar

| Asunto | Urgente | Puede esperar |
|---|---|---|
| Gasto de los próximos meses | ✔ | |
| Trámite de seguro de vida | ✔ | |
| Pensión de viudez | ✔ | |
| Vender la casa | | ✔ |
| Cambiar inversiones | | ✔ |
| Prestar dinero | | ✔ |



#### En una separación

Revisa qué cuentas son tuyas, cuáles compartidas y cuál es tu régimen patrimonial (M1 U03). Abre una cuenta a tu nombre si no la tienes. Busca asesoría legal antes de firmar convenios.



#### Pide ayuda

Apóyate en tu persona de confianza, en tu comunidad y en profesionales. Si te sientes muy mal, busca apoyo emocional; la Línea de la Vida atiende en el 800 911 2000.

> **Antes de actuar, verifica:** los requisitos de cada trámite en los canales oficiales de cada institución; nadie te cobra por avisar un fallecimiento.



#### Casos


**Caso 1. El asesor de Lucía**

A las dos semanas del fallecimiento, un asesor le propone a Lucía cambiar todas sus inversiones.
- *¿Qué hace?* Le dice que lo verá en tres meses y atiende primero lo urgente.


**Caso 2. La separación de Elena**

Elena se está separando y no tiene cuenta a su nombre.
- *¿Qué hace?* Abre una cuenta propia y busca asesoría antes de firmar convenios.


**Caso 3. El préstamo a Carmen**

Un familiar le pide dinero a Carmen días después de enviudar.
- *¿Qué hace?* Pospone la decisión: no presta en los primeros 90 días.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decidir en duelo | Decisiones que lamentas | Pausa de 90 días |
| Firmar por presión | Pérdidas | Espera |
| No asegurar el gasto | Angustia | Lo urgente primero |
| Quedarte sola | Más difícil | Pide apoyo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Elena y Carmen. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué puede esperar después de una pérdida? a) Tramitar la pensión de viudez · b) Vender la casa · c) Asegurar el gasto del mes
2. Te presionan para decidir rápido. ¿Qué significa? a) Que es una buena oportunidad · b) Que eres importante para el asesor · c) Que conviene esperar
3. ¿Qué haces en una separación si no tienes cuenta propia? a) Abres una a tu nombre · b) Usas la de tu expareja · c) Guardas todo en efectivo
**Respuestas:** 1-b: las decisiones grandes esperan. 2-c: la presión es una alerta. 3-a: es tu respaldo.



#### Ponlo en práctica

Clasifica: cobrar el seguro de vida, cambiar inversiones, pensión de viudez, prestar a un sobrino.
**Respuesta:** Urgente: seguro de vida y pensión de viudez. Puede esperar: cambiar inversiones y prestar.



#### A tu plan

Guarda en tu carpeta la lista de «lo urgente» de esta lección por si algún día la necesitas.



### Para saber más

- **Apoyo emocional** (Línea de la Vida · español): https://www.gob.mx — **Qué buscar:** «Línea de la Vida», 800 911 2000.
- **Trámites por fallecimiento** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fallecimiento del titular».

### Palabras clave

- *Duelo:* proceso emocional después de una pérdida.
- *Convenio de separación:* acuerdo sobre bienes y obligaciones al separarse.

### Fuentes

CONDUSEF · IMSS · Gobierno de México, consultados el 29 de septiembre de 2026.

---

## M10 U06. Tu casa: escrituras, predial y crédito en orden

**Lo que lograrás:** Revisar que tu casa esté bien escriturada, al día en predial y con su seguro del crédito, y saber qué pasa con tu subcuenta de vivienda al retirarte.

**Para empezar:** Maru y Raúl compraron su casa hace veinte años con crédito. Ya la terminaron de pagar, pero nunca recogieron la liberación de hipoteca y la escritura sigue con el gravamen. En esta lección pondrás tu casa en orden.

### Lo esencial (5 minutos)

#### Revisa estos cuatro papeles

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Escritura inscrita | En el Registro Público de la Propiedad. | Demuestra que es tuya. |
| Liberación de hipoteca | Al terminar de pagar. | Sin ella, la casa sigue gravada. |
| Predial al corriente | Recibos guardados. | Evitas recargos. |
| Seguro del crédito | Daños y vida. | Mientras debes. |

#### El seguro de tu crédito

Los créditos de Infonavit, Fovissste y bancos suelen incluir un seguro de daños a la vivienda y uno de vida. Si quien tiene el crédito fallece, la deuda se cubre. Guarda tu póliza o constancia: tu familia la necesitará para reclamar.



#### Tu subcuenta de vivienda

Si nunca usaste tu crédito, el saldo de tu subcuenta de vivienda no se pierde. Al pensionarte se te entrega o se suma a tu pensión, según tu régimen. Consulta tu saldo en Mi Cuenta Infonavit o en el Fovissste.



#### Un caso en un minuto

Maru pidió a Infonavit la carta de cancelación de hipoteca y la llevó a la notaría para inscribir la liberación. Revisó que el predial estuviera al corriente y guardó todo en su carpeta de patrimonio. Raúl consultó su saldo en el Fovissste.

> **Idea clave:** escritura inscrita, liberación de hipoteca al terminar, predial al día y el seguro del crédito localizable; tu subcuenta de vivienda no se pierde.



#### Comprueba lo que entendiste

1. ¿Qué pides al terminar de pagar tu crédito?
*Respuesta:* La carta de liberación o cancelación de hipoteca, para inscribirla.

2. ¿Qué pasa si fallece quien tiene un crédito de vivienda con seguro de vida?
*Respuesta:* El seguro cubre la deuda.


#### Para recordar

- Escritura inscrita.
- Liberación al terminar de pagar.
- Predial al día.



### Profundiza (5 minutos más)

#### Fraudes con casas y terrenos

Cuidado con tres engaños. Casas «recuperadas» o embargadas que se venden baratas y sin papeles. Terrenos ejidales que se venden como si fueran propiedad privada. Y «gestores» que prometen escriturar rápido si pagas por adelantado. Antes de pagar, pide un certificado de libertad de gravamen y consulta con una notaría.



#### El predial

Muchos municipios dan descuento si pagas el año completo en enero o febrero, y algunos tienen descuentos para personas adultas mayores o jubiladas. Pregunta en tu municipio y guarda cada recibo.

> **Antes de actuar, verifica:** cualquier compra, venta o trámite de tu casa con una notaría y en el Registro Público de la Propiedad. Nunca pagues por adelantado a un gestor.



#### Casos


**Caso 1. La liberación de Maru**

Maru terminó de pagar su crédito, pero la escritura sigue con el gravamen.
- *¿Qué hace?* Pide la carta de cancelación y la inscribe con una notaría.


**Caso 2. El terreno de Elena**

A Elena le ofrecen un terreno muy barato «con papeles del ejido» para su hijo.
- *¿Qué hace?* No paga hasta que una notaría revise el régimen y los gravámenes.


**Caso 3. El crédito de Lucía**

El esposo de Lucía tenía un crédito de vivienda cuando falleció.
- *¿Qué hace?* Busca el seguro de vida del crédito y reclama que cubra la deuda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No inscribir la liberación | La casa sigue gravada | Notaría |
| Predial atrasado | Recargos | Paga a tiempo |
| Comprar sin revisar | Pierdes el dinero | Libertad de gravamen |
| Olvidar el seguro del crédito | Tu familia paga | Guárdalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Elena y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Terminaste de pagar tu casa. ¿Qué te falta? a) Nada, ya es tuya · b) Inscribir la liberación de hipoteca · c) Pagar otro crédito
2. Te ofrecen un terreno ejidal muy barato. ¿Qué haces antes de pagar? a) Pides que una notaría lo revise · b) Pagas para apartarlo · c) Firmas un recibo con el vendedor
3. Nunca usaste tu crédito de vivienda. ¿Qué pasa con tu subcuenta? a) Se pierde al retirarte · b) Se queda en el gobierno · c) Se te entrega o se suma a tu pensión, según tu régimen
**Respuestas:** 1-b: sin ella sigue gravada. 2-a: evitas fraudes. 3-c: no se pierde.



#### Ponlo en práctica

Tu predial es de 3,600 pesos y te dan 10% de descuento por pagar en enero. ¿Cuánto ahorras?
**Respuesta:** 360 pesos.



#### A tu plan

Busca tu escritura, tu último recibo de predial y el seguro de tu crédito, y guárdalos en tu carpeta de patrimonio.



### Para saber más

- **Saldo y trámites de vivienda** (Infonavit · español): https://micuenta.infonavit.org.mx — **Qué buscar:** tu saldo, tus puntos y si ya puedes precalificar para un crédito.
- **Vivienda para trabajadores del Estado** (Fovissste · español): https://www.gob.mx/fovissste — **Qué buscar:** tu saldo y los tipos de crédito para trabajadores del Estado.
- **Notarías y escrituras** (Colegio Nacional del Notariado Mexicano · español): https://www.notariadomexicano.org.mx — **Qué buscar:** el colegio de notarios de tu estado y los programas de escrituración a bajo costo.

### Palabras clave

- *Subcuenta de vivienda:* dinero que tu patrón aporta para tu vivienda dentro de tu cuenta de ahorro para el retiro.
- *Gravamen:* carga sobre un inmueble, como una hipoteca, que aparece en el Registro Público.
- *Libertad de gravamen:* certificado que muestra si un inmueble tiene deudas o cargas.

### Fuentes

Infonavit · Fovissste · Colegio Nacional del Notariado Mexicano, consultados el 29 de septiembre de 2026.

---

## M10 U07. Si no hay testamento: unión libre, tierra ejidal y el trámite sucesorio

**Lo que lograrás:** Identificar qué pasa si alguien fallece sin testamento, cómo se hereda en unión libre y la tierra ejidal, y qué hacer para evitar pleitos.

**Para empezar:** El hermano de Lucía murió sin testamento. Vivía en unión libre desde hacía 15 años, tenía una parcela ejidal en su pueblo y una casa en Guadalajara. Su pareja, sus hijos y sus hermanos no se ponen de acuerdo. En esta lección verás cómo funciona.

### Lo esencial (5 minutos)

#### Cuando no hay testamento

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Trámite sucesorio | Juicio o ante notario si hay acuerdo. | Tarda y cuesta. |
| La ley decide | Hijos, pareja, padres, hermanos, en ese orden. | Puede no ser lo que querías. |
| Unión libre | Hereda si cumple lo que pide la ley del estado. | Tiempo o hijos en común. |
| Tierra ejidal | Con la lista de sucesión del ejidatario. | En el RAN. |

#### Ante notario, si hay acuerdo

Si toda la familia está de acuerdo y no hay menores de edad en conflicto, muchas veces el trámite se hace ante notario. Es más rápido que un juicio. Si no hay acuerdo, se va a juicio.



#### La parcela ejidal

Los derechos ejidales se heredan con la lista de sucesión depositada en el Registro Agrario Nacional o ante notario. Si no hay lista, la Ley Agraria pone el orden: pareja, luego hijos, luego otros.



#### Un caso en un minuto

La familia del hermano de Lucía pidió asesoría. La pareja pudo demostrar los años de vida en común. La parcela tenía lista de sucesión a nombre de su hijo mayor. La casa se tramitó ante notario porque todos se pusieron de acuerdo. Lucía hizo su testamento ese mismo septiembre.

> **Idea clave:** sin testamento, la ley decide y el trámite tarda y cuesta; la pareja en unión libre y la tierra ejidal tienen reglas propias. Tu testamento y tu lista de sucesión evitan pleitos.



#### Comprueba lo que entendiste

1. ¿Qué pasa si alguien fallece sin testamento?
*Respuesta:* Hay un trámite sucesorio y la ley decide quién hereda.

2. ¿Cómo se hereda la tierra ejidal?
*Respuesta:* Con la lista de sucesión del ejidatario.


#### Para recordar

- Sin testamento, decide la ley.
- Unión libre: requisitos del estado.
- Tierra ejidal: lista de sucesión.



### Profundiza (5 minutos más)

#### Qué revisar hoy

| Bien | Qué evita pleitos |
|---|---|
| Casa con escrituras | Testamento |
| Casa sin escrituras | Regularizar primero (M10 U06) |
| Parcela ejidal | Lista de sucesión en el RAN |
| Cuentas, Afore y seguros | Beneficiarios (M10 U02) |



#### Si vives en unión libre

Según el estado, la pareja en unión libre puede heredar si vivieron juntos cierto tiempo o tienen hijos en común. Un testamento y los beneficiarios lo dejan claro sin tener que probarlo.



#### Casos


**Caso 1. La familia del hermano de Lucía**

La pareja, los hijos y los hermanos no se ponen de acuerdo.
- *¿Qué hacen?* Piden asesoría y, si llegan a un acuerdo, hacen el trámite ante notario.


**Caso 2. La parcela de los papás de Maru**

Los papás de Maru tienen una parcela ejidal y nadie sabe si hay lista de sucesión.
- *¿Qué hace?* Pregunta en el Registro Agrario Nacional y, si no hay, les propone registrarla.


**Caso 3. La pareja de Elena**

Elena vive en unión libre desde hace 4 años.
- *¿Qué hace?* Hace su testamento y nombra beneficiarios para dejarlo claro.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que «todo es de la pareja» sin papeles | Pleitos | Testamento |
| Parcela sin lista | La ley decide | Regístrala |
| Esperar a que pase algo | Juicio largo | Hazlo hoy |
| No buscar acuerdo | Juicio caro | Notario si hay acuerdo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Maru y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si una persona fallece sin testamento? a) La ley decide quién hereda · b) El gobierno se queda con todo · c) Nadie hereda
2. ¿Con qué se heredan los derechos ejidales? a) Con un recibo de predial · b) Con una carta a mano · c) Con la lista de sucesión
3. Toda la familia está de acuerdo. ¿Dónde puede hacerse el trámite? a) En el banco · b) Ante notario · c) En el SAT
**Respuestas:** 1-a: hay un orden legal. 2-c: se registra en el RAN. 3-b: más rápido que un juicio.



#### Ponlo en práctica

Un trámite sucesorio ante notario cuesta 18,000 y un juicio 45,000. ¿Cuánto ahorra la familia si se pone de acuerdo?
**Respuesta:** 45,000 menos 18,000: 27,000.



#### A tu plan

Revisa si tus papás o tú tienen tierra ejidal y si hay lista de sucesión.



### Para saber más

- **Lista de sucesión** (Registro Agrario Nacional · español): https://www.gob.mx/ran — **Qué buscar:** «lista de sucesión».
- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento».

### Palabras clave

- *Trámite sucesorio:* proceso para repartir los bienes de quien falleció.
- *Lista de sucesión:* lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.
- *Unión libre:* pareja que vive junta sin estar casada.

### Fuentes

Ley Agraria (artículos 17 y 18) · Registro Agrario Nacional · Secretaría de Gobernación, consultados el 30 de septiembre de 2026.

---

## M10 U08. Heredar o dar en vida: impuestos, costos y riesgos

**Lo que lograrás:** Explicar qué impuestos hay (y cuáles no) al heredar, cuánto cuesta pasar una casa a tu nombre, y los riesgos y costos de dar en vida con donación, venta o usufructo.

**Para empezar:** Carmen quiere dejarle la casa a su hija. Una amiga le dice: «Mejor véndesela en vida por un peso, así no paga impuestos». Otra le dice que la done. Y su hija cree que heredar paga 30%. En esta lección verás qué conviene.

### Lo esencial (5 minutos)

#### Lo que es cierto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Heredar no paga ISR | Está exento. | Si pasa de 500,000, se informa en la declaración. |
| Escriturar sí cuesta | Impuesto estatal, notario y registro. | Varía por estado. |
| Donar entre padres e hijos | Exento de ISR. | Pero cuesta escriturar. |
| «Vender por un peso» | Puede generar impuestos y riesgos. | Pregunta antes. |

> **Dato vigente:** las herencias y los donativos entre cónyuges y entre padres e hijos no pagan ISR (Ley del ISR, artículo 93, fracciones XXII y XXIII). Quien presenta declaración anual debe informarlos si pasan de 500,000 pesos. Consultado el 30 de septiembre de 2026 a través del SAT y medios nacionales.

#### Dar en vida: pros y riesgos

Donar o vender en vida adelanta el trámite, pero **ya no es tuya**: si hay un conflicto, puedes quedarte sin casa. El usufructo vitalicio permite donar la propiedad y quedarte a vivir en ella de por vida. Una venta simulada puede generar ISR y problemas.



#### Si después se vende lo heredado

Si tu hija vende la casa heredada, puede pagar ISR sobre la ganancia. Se calcula con lo que pagaste tú y la fecha en que la compraste. Si ella vive ahí, puede aplicar la exención por casa habitación, con límites.



#### Un caso en un minuto

Carmen preguntó en una notaría. Decidió hacer su testamento dejándole la casa a su hija y nombrarla beneficiaria de sus cuentas. No la vendió «por un peso» ni la donó: así sigue siendo suya mientras viva.

> **Idea clave:** heredar y donar entre padres e hijos no paga ISR, pero escriturar sí cuesta; dar en vida significa que ya no es tuya. Pregunta en una notaría antes de decidir.



#### Comprueba lo que entendiste

1. ¿Se paga ISR por heredar una casa?
*Respuesta:* No, está exento.

2. ¿Qué riesgo tiene donar en vida?
*Respuesta:* La casa ya no es tuya.


#### Para recordar

- Heredar y donar a hijos: sin ISR.
- Escriturar cuesta.
- Dar en vida: ya no es tuya.



### Profundiza (5 minutos más)

#### Heredar, donar o vender

| Opción | ISR para quien recibe | Riesgo para ti |
|---|---|---|
| Testamento | No | Ninguno mientras vivas |
| Donación a hijos | No | Ya no es tuya |
| Donación con usufructo | No | Menor: vives ahí de por vida |
| Venta «por un peso» | Puede haber | Alto: problemas fiscales y legales |



#### Si tus hijos viven en Estados Unidos

Si heredan o reciben una donación del extranjero por más de 100,000 dólares, allá deben avisar al IRS con un formulario informativo, aunque no paguen impuesto. Que lo pregunten a una persona experta allá.



#### Casos


**Caso 1. La casa de Carmen**

Le aconsejan a Carmen venderle la casa a su hija por un peso.
- *¿Qué hace?* Pregunta en una notaría y compara testamento, donación con usufructo y venta.


**Caso 2. El 30% de la hija de Carmen**

La hija de Carmen cree que heredar la casa paga 30% de ISR.
- *¿Qué aprende?* Que heredar no paga ISR; solo los gastos de escriturar.


**Caso 3. La donación de Lucía**

Lucía quiere donarle ya su departamento a su hijo.
- *¿Qué hace?* Considera el usufructo vitalicio para seguir viviendo ahí.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Vender «por un peso» | Problemas fiscales | Pregunta |
| Donar sin usufructo | Te quedas sin casa | Usufructo |
| Creer que heredar paga 30% | No escrituran | Notaría |
| No informar herencias grandes | Multas | Declaración anual |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, su hija y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto ISR paga tu hija por heredar tu casa? a) Nada · b) 30% · c) 16%
2. ¿Qué es el usufructo vitalicio? a) Un seguro de vida · b) Tu derecho a vivir en la casa aunque sea de otra persona · c) Un crédito hipotecario que te da el banco para comprar una casa nueva
3. ¿Qué riesgo tiene donar tu casa en vida? a) Ninguno · b) Pagar ISR sobre el valor total de la casa · c) Que ya no sea tuya
**Respuestas:** 1-a: está exento. 2-b: vives ahí de por vida. 3-c: pasa a ser de otra persona.



#### Ponlo en práctica

Escriturar una casa de 1,200,000 cuesta 3% de impuesto estatal y 20,000 de notario. ¿Cuánto es en total?
**Respuesta:** 3% de 1,200,000: 36,000. Más 20,000: 56,000.



#### A tu plan

Escribe qué quieres que pase con tu casa y agenda una consulta en una notaría.



### Para saber más

- **Herencias y donaciones** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «herencias» y «donativos exentos».
- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento».

### Palabras clave

- *Usufructo:* derecho a usar una propiedad y vivir en ella aunque otra persona sea la dueña.
- *Donación:* dar un bien en vida sin cobrar.
- *Escriturar:* pasar legalmente una propiedad a nombre de otra persona ante notario.

### Fuentes

Ley del ISR (artículo 93) · SAT · Secretaría de Gobernación, consultados el 30 de septiembre de 2026.

---

## M10 U09. Violencia económica y patrimonial: tu dinero y tus bienes también son tuyos

**Lo que lograrás:** Reconocer la violencia económica y patrimonial, proteger tus cuentas, tus documentos y tus bienes, y saber dónde pedir ayuda sin costo.

**Para empezar:** Arturo siempre manejó todo. Cuando Carmen pidió ver el estado de cuenta, él le dijo que «no le iba a entender». Hace poco Carmen supo que Arturo quiere vender el terreno que compraron juntos, sin decirle.

### Lo esencial (5 minutos)

#### Señales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| No te dejan ver las cuentas | «No le vas a entender». | Es control. |
| Te dan «el gasto» y nada más | Y te piden cuentas de cada peso. | Es control. |
| Venden o esconden bienes comunes | Casa, terreno, auto. | Es violencia patrimonial. |
| Te hacen firmar sin explicar | Créditos, poderes, ventas. | Es abuso. |

#### Tiene nombre y protección

La ley la llama **violencia económica** (controlar o limitar tu dinero) y **violencia patrimonial** (quitar, dañar, esconder o vender tus bienes o documentos). También pasa entre hijos y padres mayores. Hablar de dinero en pareja no es desconfianza: es cuidar lo que construyeron juntos.

> **Dato vigente:** la ley reconoce la violencia patrimonial y la económica. Lo dice la Ley General de Acceso de las Mujeres a una Vida Libre de Violencia (artículo 6, fracciones III y IV). La Línea de las Mujeres 079, opción 1, da orientación jurídica y psicológica las 24 horas. Consultado el 30 de septiembre de 2026 a través de la Secretaría de las Mujeres.



#### Tres protecciones

1. **Conoce tu régimen matrimonial**: en sociedad conyugal, lo comprado durante el matrimonio es de los dos y para venderlo se necesita tu firma (M1 U03).
2. **Ten algo a tu nombre**: una cuenta y copia de tus documentos y escrituras.
3. **Nunca firmes sin leer**: pregunta qué es, para qué sirve y qué pasa si no firmas.



#### Un caso en un minuto

Carmen pidió una copia de la escritura del terreno en el Registro Público: aparece a nombre de los dos. Sin su firma, Arturo no puede venderlo. Llamó al 079 para orientarse y abrió una cuenta a su nombre.

> **Idea clave:** tu dinero y tus bienes también son tuyos. Conoce tu régimen matrimonial, ten documentos y una cuenta a tu nombre, y no firmes nada sin entenderlo.



#### Comprueba lo que entendiste

1. ¿Qué es la violencia patrimonial?
*Respuesta:* Quitar, dañar, esconder o vender tus bienes o documentos.

2. ¿Dónde te orientas sin costo?
*Respuesta:* En la Línea de las Mujeres 079, opción 1; en emergencia, 911.


#### Para recordar

- Conoce tu régimen matrimonial.
- Algo a tu nombre.
- No firmes sin entender.



### Profundiza (5 minutos más)

#### Dónde pedir copia de tus papeles

| Documento | Dónde |
|---|---|
| Acta de matrimonio | Registro Civil |
| Escritura de la casa o terreno | Registro Público de la Propiedad |
| Estado de cuenta de la Afore | Tu Afore o Afore Móvil |
| Póliza de seguro | La aseguradora |



#### Poderes notariales

Un poder amplio permite que otra persona venda, firme o saque dinero por ti. Antes de dar uno, pregunta en la notaría qué tan amplio es y si puedes limitarlo o cancelarlo.



#### Con los hijos grandes

También es violencia que un hijo tome tu pensión, tu tarjeta o tus papeles. Nadie más necesita tu NIP.



#### Casos


**Caso 1. El estado de cuenta de Carmen**

Arturo no deja que Carmen vea las cuentas.
- *¿Qué hace Carmen?* Pide ver los estados de cuenta y se orienta en el 079.


**Caso 2. El terreno**

Arturo quiere vender el terreno que compraron juntos.
- *¿Qué hace Carmen?* Pide copia de la escritura y revisa su régimen matrimonial.


**Caso 3. La tarjeta de Lucía**

Un hijo de Lucía le pide su tarjeta y su NIP para «ayudarle».
- *¿Qué hace Lucía?* No da su NIP y hace ella sus pagos o con su acompañamiento.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que «no vas a entender» | Pierdes el control | Pide ver las cuentas |
| No saber tu régimen | Pueden vender sin ti | Revisa tu acta |
| Dar un poder amplio sin preguntar | Firman por ti | Limítalo |
| Compartir tu NIP | Te vacían la cuenta | Nadie lo necesita |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. En sociedad conyugal, ¿se puede vender la casa sin tu firma? a) No, se necesita tu firma · b) Sí, si está a nombre de él · c) Sí, siempre
2. ¿Cuál es una señal de violencia económica? a) Ver juntos el estado de cuenta · b) Ahorrar para una meta en común · c) Que no te dejen ver las cuentas
3. Te piden firmar un poder notarial. ¿Qué haces? a) Firmas rápido · b) Preguntas qué tan amplio es y si puedes limitarlo · c) Firmas y guardas la copia
**Respuestas:** 1-a: lo compraron juntos. 2-c: es control del dinero. 3-b: un poder amplio permite vender por ti.



#### Ponlo en práctica

Carmen quiere apartar 800 al mes en una cuenta a su nombre. ¿Cuánto tendrá en un año?
**Respuesta:** 800 × 12 = 9,600.



#### A tu plan

Revisa esta semana: tu acta de matrimonio y régimen, dónde están tus escrituras y si tienes una cuenta a tu nombre.



### Para saber más

- **Línea de las Mujeres** (Secretaría de las Mujeres · español): 079, opción 1 | Orientación sin costo las 24 horas.
- **Emergencias** (español): 911.
- **Centros de Justicia para las Mujeres** (Secretaría de las Mujeres · español): https://www.gob.mx/mujeres — **Qué buscar:** «Centros de Justicia para las Mujeres».

### Palabras clave

- *Violencia patrimonial:* quitar, dañar, esconder o vender bienes o documentos de otra persona.
- *Poder notarial:* documento ante notario que permite a otra persona actuar por ti.

### Fuentes

Ley General de Acceso de las Mujeres a una Vida Libre de Violencia (artículo 6) · Secretaría de las Mujeres, consultados el 30 de septiembre de 2026.

---

## M10 U10. Pensión alimenticia: pedirla, cuidarla y hacerla durar

**Lo que lograrás:** Identificar qué cubre la pensión alimenticia, cómo se pide o se revisa, qué pasa si no se paga y cómo administrarla.

**Para empezar:** Elena se divorció hace dos años. Su exesposo pagaba la pensión de sus dos hijos, pero desde hace cuatro meses deposita la mitad «porque le bajó el trabajo». Elena no sabe si puede hacer algo.

### Lo esencial (5 minutos)

#### Qué cubren los alimentos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comida | Lo de cada día. | Base del cálculo. |
| Casa | Renta y servicios. | Parte proporcional. |
| Salud | Consultas, medicinas y seguro. | También imprevistos. |
| Escuela | Colegiaturas, útiles, uniformes. | Hasta que terminen. |

#### Solo un juez la cambia

Si la pensión la fijó un juez, **quien paga no puede bajarla por su cuenta**. Si su ingreso cambió, debe pedir al juez que la revise. Mientras tanto, lo que no pagó se acumula como deuda. Tú también puedes pedir que se revise si las necesidades de tus hijos aumentaron.



#### Si no se paga

Quien deja de pagar durante 60 días puede quedar inscrito en el **Registro Nacional de Obligaciones Alimentarias**. Con eso no puede sacar licencia de manejo ni pasaporte. El juez también puede ordenar que se descuente directo de su nómina.

> **Dato vigente:** desde 2023, las personas inscritas como deudoras alimentarias morosas no pueden obtener licencia de manejo ni pasaporte. En agosto de 2026 la SRE presentó un anteproyecto para revisar el registro antes de tramitar el pasaporte. Consultado el 30 de septiembre de 2026 a través de medios nacionales.



#### Un caso en un minuto

Elena juntó los comprobantes de depósito de los últimos seis meses y fue a la defensoría pública. Le explicaron que puede pedir el pago de lo atrasado y el descuento por nómina. Mientras, ajustó su presupuesto y usa la pensión solo para los gastos de sus hijos.

> **Idea clave:** si un juez fijó la pensión, solo un juez la cambia. Guarda tus comprobantes y pide orientación sin costo si no se paga completa.



#### Comprueba lo que entendiste

1. ¿Quien paga puede bajar la pensión por su cuenta?
*Respuesta:* No; debe pedirlo al juez.

2. ¿Qué junta Elena para ir a la defensoría?
*Respuesta:* Los comprobantes de depósito.


#### Para recordar

- Solo un juez la cambia.
- Guarda tus comprobantes.
- Lo atrasado se puede reclamar.



### Profundiza (5 minutos más)

#### Hijos que estudian

La pensión puede seguir después de los 18 años si tus hijos siguen estudiando, según la ley de tu estado y lo que diga el juez.



#### El seguro de gastos médicos de los hijos

Si el padre tenía a los hijos en su seguro de gastos médicos, revisa si siguen asegurados. Puedes pedir que forme parte del acuerdo.



#### Administra lo que recibes

Anota la pensión como ingreso de tus hijos, separa en una cuenta los gastos grandes del año (inscripciones, uniformes) y guarda los comprobantes.



#### Casos


**Caso 1. La mitad**

El exesposo de Elena deposita la mitad desde hace cuatro meses.
- *¿Qué hace Elena?* Junta sus comprobantes y pide orientación en la defensoría pública.


**Caso 2. La inscripción**

En agosto llega la inscripción de los hijos de Elena.
- *¿Qué hace?* Aparta cada mes una parte de la pensión para los gastos del año.


**Caso 3. El seguro de los hijos**

Maru ayuda a su sobrina, que se divorció y no sabe si sus hijos siguen en el seguro del papá.
- *¿Qué le sugiere?* Revisar la póliza y pedir que el seguro forme parte del acuerdo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar que bajen el pago sin juez | Pierdes lo que les toca | Pide revisión |
| No guardar comprobantes | No puedes reclamar | Guárdalos |
| Mezclar la pensión con todo | No alcanza para lo grande | Separa por meta |
| Olvidar el seguro médico | Tus hijos quedan sin cobertura | Revísalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Elena y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién puede cambiar una pensión fijada por un juez? a) Quien paga · b) Un juez · c) Quien la recibe
2. ¿Qué pasa con lo que no se pagó? a) Se acumula como deuda · b) Se olvida · c) Se divide a la mitad
3. ¿Qué puede ordenar el juez para que el pago llegue? a) Que pague en efectivo · b) Que pague cuando pueda · c) Que se descuente de su nómina
**Respuestas:** 1-b: nadie la cambia por su cuenta. 2-a: se puede reclamar. 3-c: así llega completa.



#### Ponlo en práctica

La pensión es de 8,000 al mes y desde hace 4 meses llegan 4,000. ¿Cuánto se debe?
**Respuesta:** Faltan 4,000 cada mes: 16,000.



#### A tu plan

Junta en una carpeta o en fotos los comprobantes de pensión de este año y anota cuánto falta, si falta algo.



### Para saber más

- **Orientación familiar** (DIF · español): https://www.gob.mx/difnacional — **Qué buscar:** «Procuraduría de Protección de Niñas, Niños y Adolescentes».
- **Defensoría pública** (Poder Judicial de tu estado · español) — **Qué buscar:** «defensoría pública familiar» y el nombre de tu estado.

### Palabras clave

- *Pensión alimenticia:* dinero para comida, casa, salud y escuela de los hijos.
- *Deudor alimentario moroso:* quien deja de pagar una pensión fijada por un juez durante 60 días o más.

### Fuentes

Ley General de los Derechos de Niñas, Niños y Adolescentes · Registro Nacional de Obligaciones Alimentarias · DIF, consultados el 30 de septiembre de 2026.

---


# Parte 12. Módulo 11. Decidir con calma y tu plan

## M11 U01. Decidir con calma: tus reglas

**Lo que lograrás:** Tener tus propias reglas para decidir sobre tu dinero: la regla de las 72 horas, la segunda opinión y las preguntas antes de firmar.

**Para empezar:** Maru compró un seguro «con ahorro» en una presentación de dos horas en la que le regalaron una comida. Firmó esa misma tarde. Al mes, se arrepintió. En esta lección harás tus reglas para no decidir con prisa.

### Lo esencial (5 minutos)

#### La regla de las 72 horas

Para cualquier decisión de dinero importante, espera **72 horas** antes de firmar. Si la oferta desaparece en ese tiempo, probablemente no era buena.



#### Tus tres reglas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 72 horas | Nada importante se firma el mismo día. | La prisa es del vendedor. |
| Segunda opinión | Pregunta a alguien sin interés en la venta. | Otra mirada. |
| Cinco preguntas | Costo, riesgo, plazo, salida y quién gana. | Por escrito. |
| Todo por escrito | Lo que no está escrito, no existe. | Pide el documento. |

#### Cinco preguntas antes de firmar

¿Cuánto me cuesta en total? ¿Qué puedo perder? ¿Por cuánto tiempo me compromete? ¿Cómo me salgo y cuánto cuesta? ¿Quién gana si digo que sí?



#### Un caso en un minuto

Maru canceló el seguro dentro del plazo que le daba el contrato. Ahora tiene una tarjeta en su cartera con sus tres reglas. En la siguiente presentación, pidió el documento y se lo llevó a casa.

> **Idea clave:** 72 horas, segunda opinión y cinco preguntas por escrito antes de firmar.



#### Comprueba lo que entendiste

1. ¿Qué dice la regla de las 72 horas?
*Respuesta:* Que esperes 72 horas antes de firmar una decisión importante de dinero.

2. ¿A quién pides segunda opinión?
*Respuesta:* A alguien sin interés en la venta.


#### Para recordar

- 72 horas.
- Segunda opinión.
- Cinco preguntas por escrito.



### Profundiza (5 minutos más)

#### Tus cinco preguntas

| Pregunta | Respuesta por escrito |
|---|---|
| ¿Cuánto me cuesta en total? | |
| ¿Qué puedo perder? | |
| ¿Por cuánto tiempo me compromete? | |
| ¿Cómo me salgo y cuánto cuesta? | |
| ¿Quién gana si digo que sí? | |



#### Presentaciones y regalos

Las presentaciones con comida, regalos o viajes están diseñadas para que decidas con emoción. Puedes asistir, pero no firmes ese día.



#### Si ya firmaste

Muchos contratos financieros te dan un periodo para cancelar sin costo. Revisa tu contrato y, si aplica, cancela por escrito dentro del plazo.

> **Antes de actuar, verifica:** el plazo de cancelación de cada contrato; si no lo sabes, pregúntalo antes de firmar.



#### Casos


**Caso 1. La presentación de Maru**

Al final de una presentación con comida, le piden a Maru que firme ese mismo día.
- *¿Qué hace?* Pide el documento, se lo lleva y espera 72 horas.


**Caso 2. La oferta de Carmen**

Le dicen a Carmen que la tasa especial «solo es hoy».
- *¿Qué hace?* No firma: la prisa es una señal para esperar.


**Caso 3. El contrato de Lucía**

Lucía firmó un contrato y al día siguiente se arrepintió.
- *¿Qué hace?* Revisa si tiene plazo de cancelación y cancela por escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar el mismo día | Te arrepientes | 72 horas |
| Preguntar solo al vendedor | Visión parcial | Segunda opinión |
| Promesas de palabra | No existen | Por escrito |
| No saber cómo salir | Te atrapa | Pregunta antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Maru, Carmen y Lucía. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te dicen «la oferta solo es hoy». ¿Qué haces? a) Esperas y comparas · b) Firmas para no perderla · c) Pides un descuento extra
2. ¿A quién pides segunda opinión? a) Al vendedor · b) A alguien sin interés en la venta · c) A quien te invitó a la presentación
3. Firmaste y te arrepientes al día siguiente. ¿Qué haces? a) Nada, ya firmaste · b) Dejas de pagar para que te cancelen el contrato · c) Revisas el plazo de cancelación
**Respuestas:** 1-a: la prisa es del vendedor. 2-b: sin conflicto de interés. 3-c: muchos contratos lo permiten.



#### Ponlo en práctica

Escribe tus tres reglas en una tarjeta para tu cartera.
**Respuesta:** 1) Nada importante se firma el mismo día; 2) pido segunda opinión; 3) las cinco preguntas por escrito.



#### A tu plan

Escribe tu tarjeta de reglas y guárdala en tu cartera.



### Para saber más

- **Derechos del usuario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cancelación de contratos».

### Palabras clave

- *Segunda opinión:* consulta con alguien que no gana nada con tu decisión.
- *Periodo de cancelación:* plazo para cancelar un contrato sin costo.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M11 U02. Presión familiar y control del dinero

**Lo que lograrás:** Reconocer la presión familiar y el control económico, poner límites y saber dónde pedir apoyo.

**Para empezar:** Desde que enviudó, un familiar de Lucía maneja «por ella» su tarjeta, le dice en qué puede gastar y se enoja si pregunta. Lucía siente que ya no decide sobre su propio dinero. En esta lección verás cómo reconocerlo y qué hacer.

### Lo esencial (5 minutos)

#### Ayuda o control

Ayudar es explicar y acompañar. Controlar es decidir por ti, quitarte el acceso a tu dinero o presionarte. El control económico es una forma de violencia, aunque venga de alguien cercano.



#### Señales de control

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te quitan el acceso | A tus cuentas o tarjetas. | Tu dinero es tuyo. |
| Te vigilan | Cada gasto, con enojo. | No es cuidado. |
| Te presionan para firmar | Poderes, préstamos, ventas. | Detente. |
| Te aíslan | No quieren que hables con otros. | Busca apoyo. |

#### Tus primeros pasos

Recupera el acceso a tus cuentas (cambia contraseñas y NIP), habla con tu persona de confianza y busca orientación. No tienes que resolverlo sola.



#### Un caso en un minuto

Lucía cambió el NIP de su tarjeta y se la quedó. Habló con su hija y llamaron juntas a una línea de orientación. Le ayudaron a poner límites con calma y con apoyo.

> **Idea clave:** tu dinero es tuyo; si alguien te lo controla, recupera el acceso y busca apoyo.



#### Comprueba lo que entendiste

1. ¿Qué diferencia hay entre ayudar y controlar?
*Respuesta:* Ayudar es explicar y acompañar; controlar es decidir por ti o quitarte el acceso.

2. ¿Qué haces primero si alguien controla tu dinero?
*Respuesta:* Recupero el acceso a mis cuentas y busco apoyo.


#### Para recordar

- Ayuda acompaña; control decide por ti.
- Recupera tu acceso.
- Busca apoyo.



### Profundiza (5 minutos más)

#### Frases para poner límites

| Situación | Puedes decir |
|---|---|
| Te piden tu tarjeta | «Prefiero manejarla yo; si necesito ayuda, te pido que me expliques» |
| Te presionan para prestar | «Lo pensaré 72 horas y te respondo» |
| Te piden firmar un poder | «Lo consultaré en la notaría antes» |
| Critican tus gastos | «Es mi dinero y lo estoy cuidando» |



#### Dónde pedir apoyo

Puedes buscar orientación en las instancias de las mujeres de tu estado, en el DIF o en los servicios de atención a personas adultas mayores. Si hay amenazas o riesgo, llama al 911. Para apoyo emocional, la Línea de la Vida: 800 911 2000.



#### Sin culpa

Poner límites no es desamor. Puedes querer a tu familia y cuidar tu dinero al mismo tiempo.

> **Antes de actuar, verifica:** los teléfonos de las instancias de tu estado y guárdalos en tu hoja de emergencia.



#### Casos


**Caso 1. La tarjeta de Lucía**

Un familiar maneja la tarjeta de Lucía y decide en qué gasta.
- *¿Qué hace?* Cambia su NIP, recupera la tarjeta y busca apoyo con su persona de confianza.


**Caso 2. La presión a Carmen**

Un sobrino presiona a Carmen para que le preste y se enoja si duda.
- *¿Qué hace?* Le dice que lo pensará 72 horas y no presta por presión.


**Caso 3. El aislamiento de Elena**

La pareja de Elena no quiere que hable de dinero con nadie más.
- *¿Qué hace?* Busca orientación en una instancia de apoyo a las mujeres.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Normalizar el control | Pierdes tu dinero | Reconócelo |
| Ceder por culpa | Más control | Pon límites |
| Resolverlo sola | Más difícil | Busca apoyo |
| Esperar a que cambie | Empeora | Actúa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lucía, Carmen y Elena. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un familiar se queda con tu tarjeta y decide tus gastos. ¿Qué es? a) Ayuda normal · b) Control económico · c) Una forma de cuidarte
2. ¿Qué haces primero? a) Recuperas el acceso a tus cuentas · b) Esperas a que cambie · c) Le das también tu contraseña
3. Te presionan para prestar dinero. ¿Qué respondes? a) Que sí, para evitar problemas · b) Que no hablarás más del tema · c) Que lo pensarás 72 horas
**Respuestas:** 1-b: deciden por ti. 2-a: tu dinero es tuyo. 3-c: la presión no decide.



#### Ponlo en práctica

Escribe una frase para poner un límite en una situación que hayas vivido.
**Respuesta:** Por ejemplo: «Prefiero manejar yo mi tarjeta; si necesito ayuda, te pido que me expliques».



#### A tu plan

Guarda en tu hoja de emergencia el teléfono de la instancia de las mujeres de tu estado y de la Línea de la Vida.



### Para saber más

- **Apoyo a mujeres** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** instancia de las mujeres de tu estado.
- **Línea de la Vida** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «Línea de la Vida», 800 911 2000.

### Palabras clave

- *Control económico:* cuando otra persona decide sobre tu dinero sin tu consentimiento o te impide usarlo.
- *Límite:* acuerdo claro sobre lo que aceptas y lo que no.

### Fuentes

Gobierno de México, consultado el 29 de septiembre de 2026.

---

## M11 U03. Tu plan de una página

**Lo que lograrás:** Reunir en una sola hoja tu mapa, tu protección contra fraudes, tu ahorro, tu retiro, tu salud y tu familia, con fechas para revisarlo.

**Para empezar:** Carmen tiene su inventario, sus candados en la app, su fondo de emergencia, su cálculo de retiro y su testamento. Pero están en hojas distintas. Quiere verlo todo junto y saber qué revisar cada año. En esta lección harás tu plan de una página.

### Lo esencial (5 minutos)

#### Todo en una hoja

Tu plan de una página no reemplaza tu carpeta: la resume. Te dice en un minuto dónde estás y qué sigue.



#### Las seis partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mapa | Tu inventario resumido. | Módulos 1 y 2. |
| Seguridad | Candados, persona de confianza, palabra clave. | Módulos 3 y 4. |
| Ahorro | Fondo de emergencia y dónde está. | Módulos 5 y 6. |
| Retiro, salud y familia | Pensiones, seguro, testamento, beneficiarios. | Módulos 7 a 10. |

#### Fechas para revisar

Anota cuándo revisas cada cosa. Tu carpeta, en septiembre. Tu reporte de crédito, una vez al año. Tu seguro, antes de renovar. Tu declaración, en abril.



#### Un caso en un minuto

Carmen llenó su plan en una tarde. Lo guardó al frente de su carpeta y le dio una copia a su persona de confianza, sin números de cuenta. Cada septiembre lo actualiza.



#### Tu compromiso

Escribe una meta con nombre («mi fondo de un año de gastos»), cuánto apartarás y cada cuándo. Cuéntaselo a tu persona de confianza para que te pregunte cómo vas. Programa el ahorro automático el día que recibes tu dinero y un recordatorio mensual con el nombre de tu meta.

> **Idea clave:** tu plan de una página resume tu carpeta y te dice qué revisar cada año. Un compromiso con nombre, testigo y recordatorio te ayuda a cumplirlo.



#### Comprueba lo que entendiste

1. ¿El plan reemplaza tu carpeta?
*Respuesta:* No. La resume.

2. ¿Cuándo revisas tu carpeta y tu plan?
*Respuesta:* Una vez al año, por ejemplo en septiembre.


#### Para recordar

- Seis partes en una hoja.
- Fechas para revisar.
- Sin números de cuenta.



### Profundiza (5 minutos más)

#### Tu plan de una página

| Parte | Lo que tengo hoy | Siguiente paso | Fecha |
|---|---|---|---|
| Mapa | | | |
| Seguridad | | | |
| Ahorro | | | |
| Inversiones | | | |
| Retiro | | | |
| Salud y seguros | | | |
| Familia y testamento | | | |
| Mi compromiso: meta, monto, fecha y testigo | | | |



#### Calendario del año

| Mes | Qué revisas |
|---|---|
| Enero | Gastos anuales del año |
| Abril | Declaración anual |
| Septiembre | Carpeta, testamento y plan |
| Antes de renovar | Seguros |
| Una vez al año | Reporte de crédito y beneficiarios |



#### Por qué funciona

Estudios en varios países encontraron que ponerle nombre a una meta, comprometerse con alguien y recibir un recordatorio mensual ayuda a ahorrar más. El ahorro automático también ayuda: no tienes que decidir cada mes.



#### Cuando cambia tu vida

Una viudez, una separación, una herencia o una enfermedad cambian tu plan. Actualízalo en cuanto puedas, con calma y con apoyo.

> **Antes de actuar, verifica:** que tu plan no tenga contraseñas, NIP ni números completos de cuenta.



#### Casos


**Caso 1. Las hojas de Carmen**

Carmen tiene todo en hojas distintas y no ve el conjunto.
- *¿Qué hace?* Llena su plan de una página y lo pone al frente de su carpeta.


**Caso 2. La copia de Lucía**

Lucía quiere darle una copia de su plan a su hija.
- *¿Qué hace?* Le da una copia sin números de cuenta ni contraseñas.


**Caso 3. La herencia de Maru**

Maru recibió una herencia y su plan ya no refleja su situación.
- *¿Qué hace?* Actualiza su plan con calma, respetando la pausa para decisiones grandes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo disperso | No ves el conjunto | Plan de una página |
| Datos sensibles en el plan | Riesgo | Sin números ni contraseñas |
| No fijar fechas | Se olvida | Calendario |
| No actualizar | Plan viejo | Revisa cada año |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Carmen, Lucía y Maru. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué incluye tu plan de una página? a) Tus contraseñas, para tenerlas juntas · b) Un resumen de mapa, seguridad, ahorro, retiro, salud y familia · c) Solo tus inversiones, que son lo más importante del plan
2. ¿Qué compartes con tu persona de confianza? a) Una copia sin números ni contraseñas · b) El plan con tus NIP · c) Nada, nunca
3. ¿Cuándo actualizas tu plan? a) Solo si pierdes dinero · b) Cada cinco años · c) Cada año y cuando cambia tu vida
**Respuestas:** 1-b: son sus seis partes. 2-a: sin datos sensibles. 3-c: así sigue al día.



#### Ponlo en práctica

Llena tu plan de una página con al menos un siguiente paso y una fecha para cada parte.
**Respuesta:** Por ejemplo: seguridad, fijar límite de transferencias (esta semana); ahorro, completar fondo (diciembre); familia, testamento (septiembre).



#### A tu plan

Llena tu plan de una página, ponlo al frente de tu carpeta y agenda su revisión en septiembre.



### Para saber más

- **Guías y herramientas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** herramientas de planeación.

### Palabras clave

- *Plan de una página:* resumen de tus decisiones de dinero en una sola hoja, con fechas para revisarlas.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026 · Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera».

---


# Parte 13. Materiales de apoyo

## Bienvenida

**Tu Patrimonio, Tu Tranquilidad, Tu Futuro** es un programa de bienestar financiero para mujeres que administran su casa y su patrimonio en México.

Aquí aprenderás a saber qué tienes y dónde está, entender el sistema financiero, usar el celular con seguridad, protegerte de fraudes, cuidar tu ahorro e inversiones, entender tu pensión, tu seguro médico y tus impuestos, y dejar en orden a tu familia.

No necesitas saber de finanzas ni de tecnología. Cada lección parte de una situación real y termina con una acción que puedes hacer esta semana.

Versión 1.2 · Septiembre de 2026.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos por lección |
| **¿Qué harías?** | Una actividad por lección: tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todas las lecciones del módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 a 20 minutos |

### Elige tu ruta en cada lección

- **Ruta rápida (5 min):** lee *Lo esencial* y pasa a *Practica*.
- **Ruta completa (10 min):** suma *Profundiza*, con casos, errores frecuentes y más datos.

Las **palabras en color** muestran su significado al pasar el cursor o al tocarlas en el teléfono. Las respuestas están ocultas: intenta primero y luego toca para verlas.

### No estás sola: acompañamiento

| Apoyo | Qué es |
|---|---|
| **Sesiones de acompañamiento** | Sesiones en grupo para repasar cada módulo y resolver dudas. |
| **Práctica guiada con el celular** | Ejercicios con capturas y un simulador, nunca en tu banca real frente al grupo. |
| **Comunidad Tu Patrimonio** | Un espacio aparte para dudas, avisos y alertas de fraude. |
| **Este libro** | Puedes imprimirlo y usarlo como cuaderno de trabajo. |

### Las personajes

- **Carmen** (58): casada con Arturo; él siempre manejó las cuentas y las inversiones.
- **Lucía** (64): viuda desde hace un año; recibe pensión de viudez y heredó inversiones.
- **Maru** (52): trabajó 12 años antes de casarse y vende por catálogo; su esposo, Raúl, es maestro con ISSSTE.
- **Elena** (47): divorciada, con dos hijos; su seguro médico subió 30%.

### Tres reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, códigos, fotos de tarjetas ni acceso a tu celular. Si alguien lo hace en nombre del programa, es un fraude.
2. **No te vendemos nada.** En las lecciones no hay recomendaciones comerciales.
3. **Una buena decisión puede ser esperar.** Comparar y no firmar también es aprender.

### Los datos cambian

Montos, tasas y reglas cambian. Los datos del programa se consultaron el **29 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa la información vigente en **CONDUSEF**, la **CNBV** o el **sitio oficial de la institución**.

### Cuándo pedir ayuda profesional

Este programa te enseña a entender, comparar y preparar preguntas. No da asesoría legal, fiscal ni de inversión personalizada. Para tu caso concreto, consulta a un notario, un contador, tu aseguradora o la institución. En **Dónde encontrar ayuda** hay opciones sin costo.

### Puntos, niveles e insignias

Ganas puntos al completar cada actividad. Hay seis niveles y ocho insignias: Mi mapa en orden, Celular con candado, Nadie me engaña, Ahorro protegido, Retiro claro, Salud asegurada, Familia en orden y Plan completo. Nadie ve tu nombre en una tabla de posiciones.

### Constancia

Al aprobar las once autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión** con código de verificación. Es un reconocimiento educativo del programa; no es una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados para que practiques sin compartir información personal. Los montos están en pesos. Resuelve cada caso antes de abrir la clave.

### E1. El mapa de Carmen (Módulos 1 y 2)

**Datos.** Carmen y Arturo tienen: cuenta de la casa en el Banco A (a nombre de ambos, 250,000), cuenta propia de Carmen en el Banco B (80,000), un fondo de deuda en una casa de bolsa a nombre de Arturo (900,000), un departamento que rentan en 12,000 al mes y un seguro de gastos médicos que renueva en marzo (48,000 al año). Sus gastos de cada mes son 38,000 y sus gastos anuales suman 84,000.

**Tareas.**

1. ¿Cuánto está a nombre de Carmen, sola o compartido?
2. ¿Cuál es su mes promedio?
3. ¿Qué parte de su patrimonio protege el IPAB?
4. ¿Qué institución verificarías primero y dónde?

**Clave.**

- A nombre de Carmen: 80,000 más 250,000 compartidos: 330,000.
- Mes promedio: 38,000 más 84,000 entre 12 (7,000): 45,000.
- El IPAB protege los depósitos de las cuentas bancarias (330,000); el fondo de la casa de bolsa no.
- La casa de bolsa, en el padrón de la CNBV y en el Buró de Entidades Financieras.

### E2. La semana de Lucía (Módulos 3 y 4)

**Datos.** En una semana, Lucía recibe: una llamada «del banco» que le pide el código que le llegó; un mensaje de paquetería para pagar 30 pesos; y una llamada con la voz de su nieto llorando que pide 50,000. Su límite de transferencias es el de 12,800 que puso el banco y nunca transfiere más de 3,000.

**Tareas.**

1. ¿Qué gancho usa cada intento?
2. ¿Qué hace en cada caso?
3. ¿Qué candado ajusta en su app?
4. Si hubiera dado el código, ¿cuáles son sus primeros tres pasos?

**Clave.**

- Llamada del banco: autoridad y urgencia. Paquetería: premio o urgencia. Voz del nieto: miedo.
- Cuelga y llama al número de su tarjeta; borra el mensaje; cuelga y localiza a su nieto por otro medio.
- Baja su límite de transferencias a 3,000.
- Bloquear tarjetas y accesos, cambiar contraseñas desde otro dispositivo y reclamar por escrito con folio.

### E3. Los ahorros de Maru (Módulos 5 y 6)

**Datos.** Maru tiene 60,000 de sus ventas en una cuenta con GAT real negativa. Su mes promedio es 20,000 y quiere un fondo de tres meses. Una amiga le ofrece «un negocio de divisas» que paga 5% mensual garantizado.

**Tareas.**

1. ¿Cuánto debe ser su fondo de emergencia?
2. ¿Dónde lo pondría?
3. ¿Qué señales de alerta tiene la oferta de su amiga?
4. ¿Cuánto sería 5% mensual al año, sin interés sobre interés?

**Clave.**

- 20,000 por 3: 60,000.
- En BONDDIA o una cuenta bancaria protegida, disponible y sin riesgo.
- Rendimiento alto y garantizado; probablemente pide traer a más personas; no está autorizada (verificar en la CNBV).
- 60% al año: imposible sin fraude.

### E4. La jubilación de Carmen y Arturo (Módulos 7 a 9)

**Datos.** Carmen y Arturo gastarán 45,000 al mes en su retiro. La pensión de Arturo será de 22,000 al mes y Carmen recibirá la Pensión de Adultos Mayores (6,400 cada dos meses). Su seguro de gastos médicos tiene deducible de 30,000 y coaseguro de 10% con tope de 40,000.

**Tareas.**

1. ¿Cuál es la diferencia mensual?
2. Si Carmen se opera y cuesta 250,000, ¿cuánto paga ella?
3. Si la pensión de Arturo es de 22,000 al mes, ¿paga ISR?
4. ¿Qué parte de su fondo de emergencia debería reservar para salud?

**Clave.**

- Pensiones: 22,000 más 3,200 (6,400 entre 2): 25,200. Diferencia: 19,800 al mes.
- 250,000 menos 30,000 son 220,000; el 10% sería 22,000, menor al tope. Paga 30,000 más 22,000: 52,000.
- No: está por debajo de 15 UMA (53,493.30 al mes en 2026).
- Al menos el deducible más el tope de coaseguro: 70,000.

### E5. El plan de Lucía (Módulos 10 y 11)

**Datos.** Lucía no tiene testamento. Sus beneficiarios en una cuenta son su esposo fallecido y en su seguro de vida, su hermana. Un sobrino le pide un poder general «para ayudarla» y 100,000 prestados. Su hija quiere que ponga la casa a su nombre.

**Tareas.**

1. ¿Qué tres documentos pone en orden primero?
2. ¿Qué responde al sobrino?
3. ¿Qué responde a su hija sobre la casa?
4. ¿Qué regla aplica antes de cualquier firma?

**Clave.**

- Testamento ante notario, beneficiarios de la cuenta y del seguro actualizados, y su plan de una página.
- Que no firmará un poder general; si necesita ayuda, un poder especial y limitado. Sobre el préstamo: lo pensará 72 horas y lo decidirá con su cálculo de retiro.
- Que no transferirá la casa sin asesoría notarial; su testamento cumplirá su voluntad.
- La regla de las 72 horas, con segunda opinión y las cinco preguntas por escrito.

## Formularios para tu plan

### Inventario

| Tipo | Institución | A nombre de | Últimos 4 dígitos | Saldo aproximado | Contacto |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |

### Hoja de emergencia

| Qué | Teléfono o sitio |
|---|---|
| Mi banco (atrás de la tarjeta) | |
| CONDUSEF | 55 5340 0999 u 800 999 8080 |
| Delitos en línea | 088 |
| Emergencias | 911 |
| Denuncia anónima | 089 |
| Mi persona de confianza | |


## Prácticas de cálculo

Resuelve cada práctica mostrando el procedimiento. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U02 | Gastos de cada mes 38,000 y gastos anuales 54,000. ¿Mes promedio? |
| P02 | M2 U04 | Un seguro no contratado de 350 al mes durante 14 meses. ¿Cuánto reclamas? |
| P03 | M3 U03 | Límite de 1,500 UDIS con UDI de 8.83 pesos. ¿Cuánto en pesos? |
| P04 | M5 U01 | Dos cuentas cobran 150 y 100 al mes. ¿Cuánto ahorras al año si las cancelas? |
| P05 | M5 U02 | 5 millones en un solo banco con un límite de 3.53 millones. ¿Cuánto queda sin protección? |
| P06 | M5 U03 | Mes promedio 35,000, tres meses, más 20,000 de deducible y coaseguro. ¿Fondo? |
| P07 | M6 U01 | Inversión que gana 8% con inflación de 5%. ¿Rendimiento real aproximado? |
| P08 | M6 U02 | Fondo con 2% de comisión contra otro con 1%, sobre 500,000. ¿Diferencia al año? |
| P09 | M7 U03 | Salario registrado de 25,000 en Modalidad 40 en 2026. ¿Cuota mensual aproximada? |
| P10 | M7 U04 | Pensión de 18,000 del esposo. ¿Pensión de viudez aproximada? |
| P11 | M7 U05 | Pensión ISSSTE del esposo de 20,000 en el régimen anterior, sin hijos con derecho. ¿Viudez aproximada? |
| P12 | M7 U06 | Gasto de 40,000 y pensiones de 26,000. ¿Diferencia al año? |
| P13 | M8 U01 | Cirugía de 180,000, deducible 20,000, coaseguro 10%, tope 30,000. ¿Cuánto pagas? |
| P14 | M9 U02 | 600,000 en pagarés todo 2026. ¿Retención aproximada? |
| P15 | M9 U03 | Ingresos de 300,000 al año. ¿Tope general de deducciones? |

### Respuestas

- **P01:** 54,000 entre 12 son 4,500; mes promedio 42,500.
- **P02:** 350 por 14: 4,900.
- **P03:** 1,500 por 8.83: unos 13,245 pesos (cambia con la UDI del día).
- **P04:** 250 por 12: 3,000.
- **P05:** 5,000,000 menos 3,530,000: unos 1,470,000.
- **P06:** 35,000 por 3 son 105,000, más 20,000: 125,000.
- **P07:** unos 3%.
- **P08:** 1% de 500,000: 5,000.
- **P09:** 14.438% de 25,000: unos 3,610.
- **P10:** 90% de 18,000: 16,200.
- **P11:** 100% de 20,000: 20,000 (en el IMSS sería el 90%: 18,000).
- **P12:** 14,000 al mes por 12: 168,000.
- **P13:** 180,000 menos 20,000 son 160,000; el 10% es 16,000 (menor al tope). Pagas 36,000.
- **P14:** 0.90% de 600,000: 5,400.
- **P15:** el 15% de 300,000 es 45,000, menor que 5 UMA anuales; tope 45,000.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu dinero hoy: mapa y orden

- **Caja de seguridad:** espacio que renta un banco para guardar objetos y documentos.
- **Capitulaciones:** el acuerdo que la pareja firma al casarse sobre sus bienes.
- **Carpeta de documentos:** el lugar donde guardas los papeles importantes de tu patrimonio y tu familia.
- **Gastos anuales:** pagos que llegan una o pocas veces al año, como predial, seguros o tenencia.
- **Inventario:** lista de todo lo que tienes y lo que debes, con dónde está cada cosa.
- **Mes promedio:** lo que gasta tu casa cada mes más la parte mensual de los gastos anuales.
- **Patrimonio:** lo que tienes menos lo que debes.
- **Precio por unidad:** precio dividido entre la cantidad.
- **Régimen patrimonial:** la regla que define de quién son los bienes en el matrimonio: sociedad conyugal o separación de bienes.
- **Suscripción:** pago que se cobra solo cada mes hasta que lo cancelas.
- **Titular:** la persona a cuyo nombre está una cuenta o un bien.

### Conoce el sistema financiero

- **Advertencia:** aviso de la autoridad sobre empresas que operan sin autorización.
- **Autoridad financiera:** organismo del gobierno que pone reglas, vigila o defiende a los usuarios.
- **Buró de Entidades Financieras:** herramienta de CONDUSEF que muestra quejas, sanciones y cómo resuelve cada institución.
- **Conciliación:** reunión que organiza la CONDUSEF entre tú y la institución para resolver una queja.
- **Depósito:** dinero que guardas en un banco y que te devuelven completo, con o sin intereses.
- **Folio:** el número que identifica tu reclamación.
- **Inversión:** dinero que pones a trabajar para que crezca, con la posibilidad de ganar o perder.
- **Nombre legal:** el nombre oficial de la institución, que aparece en el contrato.
- **SIPRES:** registro de prestadores de servicios financieros de CONDUSEF.
- **Sistema financiero:** el conjunto de autoridades e instituciones que manejan el ahorro, el crédito, los seguros, las inversiones y los pagos.
- **UNE:** la Unidad Especializada de Atención a Usuarios de cada institución, que recibe reclamaciones.

### El celular sin miedo

- **Banca móvil:** la app de tu banco en el celular.
- **Bloqueo de pantalla:** código, huella o rostro para abrir el celular.
- **CEP:** Comprobante Electrónico de Pago que emite Banxico para las transferencias SPEI.
- **CLABE:** número de 18 dígitos que identifica una cuenta para recibir transferencias.
- **Contraseña:** clave secreta para entrar a tu app; solo tú la conoces.
- **Código de verificación:** número que te llega por mensaje o genera tu token para confirmar una operación.
- **Gafete:** identificación visible del personal del banco.
- **Monto Transaccional del Usuario:** el límite de dinero que puedes transferir desde tu app, que tú misma fijas.
- **Persona de confianza:** alguien que eliges con calma para ayudarte con dudas, sin darle tus contraseñas.
- **SPEI:** el sistema de transferencias entre bancos de Banxico.
- **Tarjeta digital:** tarjeta virtual para compras en internet, con datos que cambian.
- **Token:** generador de códigos, en tu app o en un aparato, para autorizar operaciones.
- **UDI:** unidad cuyo valor en pesos cambia con la inflación.

### Fraudes: que no te pase

- **Bloqueo de historial:** servicio que impide que consulten tu historial sin tu autorización.
- **Clonación:** copia de los datos de tu tarjeta con un aparato oculto.
- **Cuenta segura:** engaño en el que te piden mover tu dinero a una cuenta del estafador.
- **Cuento del tío:** engaño en el que te piden dinero para cobrar una supuesta herencia o premio.
- **Denuncia:** aviso formal de un delito ante la autoridad.
- **Enlace:** dirección que te lleva a una página.
- **Evidencia:** pruebas de lo que pasó.
- **Extorsión:** exigir dinero con amenazas.
- **Fraude:** engaño para quitarte dinero o datos.
- **Ingeniería social:** engaño que usa emociones como la prisa o el miedo para que hagas algo que te perjudica.
- **NIP:** número secreto de tu tarjeta para usar el cajero o pagar.
- **Palabra clave:** palabra que solo tu familia conoce para confirmar quién llama.
- **Phishing:** engaño con mensajes o páginas falsas que imitan a una empresa para robar tus datos.
- **REPEP:** Registro Público para Evitar Publicidad, de Profeco.
- **Reporte de crédito:** documento con tus créditos, pagos y consultas.
- **REUS:** Registro Público de Usuarios, de CONDUSEF, para no recibir publicidad financiera.
- **Robo de identidad:** uso de tus datos para hacerse pasar por ti y pedir créditos o hacer trámites.
- **Secuestro virtual:** extorsión en la que fingen tener a un familiar para que pagues rápido, sin que exista secuestro.
- **Smishing:** phishing por mensaje de texto.
- **Vishing:** fraude por llamada telefónica que se hace pasar por una institución.

### Tus cuentas y tu ahorro protegido

- **Aval:** persona que se compromete a pagar si quien pidió el crédito no paga.
- **BONDDIA:** opción de Cetesdirecto que permite retirar cualquier día hábil.
- **CAT:** costo anual total de un crédito, para comparar.
- **Cetes:** Certificados de la Tesorería: deuda del gobierno federal que te paga un rendimiento a un plazo.
- **Coaseguro:** el porcentaje del gasto que pagas tú después del deducible.
- **Comisión:** cobro del banco por un servicio.
- **Cuenta mancomunada:** cuenta con dos o más titulares.
- **Deducible:** la cantidad que pagas tú antes de que el seguro empiece a pagar.
- **Demasía:** lo que sobra si venden tu prenda en más de lo que debías.
- **Desempeñar:** pagar el préstamo y los intereses para recuperar tu prenda.
- **Domiciliación:** pago automático de un servicio con cargo a tu cuenta.
- **Fiador:** persona que se obliga a pagar si el deudor no paga; común en contratos de renta.
- **Fondo de emergencia:** dinero apartado solo para imprevistos, disponible de inmediato.
- **GAT:** Ganancia Anual Total: lo que te paga una cuenta o inversión al año, antes de impuestos.
- **Historial de crédito:** registro de cómo pagas tus créditos.
- **IPAB:** Instituto para la Protección al Ahorro Bancario, que protege tus depósitos si un banco quiebra.
- **Obligado solidario:** persona que responde por todo el contrato como si hubiera pedido el crédito.
- **Pago mínimo:** lo menos que puedes pagar para no atrasarte; genera intereses.
- **Pago para no generar intereses:** lo que gastaste en el periodo; si lo pagas, no hay intereses.
- **Préstamo a cuenta de pensión:** crédito que se paga con descuentos de tu pensión.
- **Referencia personal:** persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no se obliga a pagar.
- **Reinversión:** volver a invertir automáticamente al terminar el plazo.
- **Seguro de liberación de adeudo:** seguro que cancela la deuda si la persona fallece.
- **UDIS:** unidad cuyo valor en pesos cambia con la inflación.

### Tus inversiones

- **Conflicto de interés:** situación en la que quien te aconseja gana más si decides de cierta forma.
- **Constancia de retenciones:** documento anual con lo que te retuvieron.
- **Criptomoneda:** dinero digital sin respaldo de un banco central y con precio muy variable.
- **Diversificar:** repartir tu dinero en distintas inversiones para no depender de una sola.
- **Esquema piramidal:** fraude que paga a los primeros con el dinero de quienes entran después.
- **Fondo de inversión:** dinero de muchas personas que un administrador invierte junto.
- **Liquidez:** qué tan rápido conviertes una inversión en efectivo.
- **Pagaré:** depósito a plazo en un banco.
- **Posición:** lo que tienes y cuánto vale a la fecha del estado de cuenta.
- **Registro de Asesores en Inversiones:** registro de la CNBV donde aparecen los asesores autorizados.
- **Rendimiento real:** lo que gana tu dinero descontando la inflación.
- **Retención:** impuesto que la institución descuenta y entrega al SAT por ti.
- **Riesgo:** la posibilidad de que tu inversión baje de valor.
- **Sesgo:** atajo mental que puede llevarte a decidir mal.
- **Tasa de referencia:** tasa que fija el Banco de México y que influye en las demás tasas.

### Pensión y retiro

- **AFORE:** administradora que guarda e invierte tu ahorro para el retiro.
- **Aportación voluntaria:** ahorro extra que haces tú en tu AFORE.
- **Concubinato:** unión de pareja sin matrimonio, con efectos legales si se cumplen requisitos.
- **Conservación de derechos:** periodo después de tu baja en el que aún puedes hacer ciertos trámites.
- **Cuentas individuales:** régimen del ISSSTE en el que la pensión sale del ahorro en una AFORE, como PENSIONISSSTE.
- **Diferencia de retiro:** lo que te falta cada mes entre tu gasto y tus pensiones.
- **Hoja única de servicios:** documento que resume los años de servicio y los sueldos de una persona en el gobierno.
- **ISSSTE:** Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado: seguridad social de quienes trabajan para el gobierno federal.
- **Ley 73:** reglas del IMSS para quienes cotizaron antes del 1 de julio de 1997.
- **Ley 97:** reglas del IMSS para quienes empezaron a cotizar desde el 1 de julio de 1997; la pensión depende de tu AFORE.
- **Modalidad 40:** continuación voluntaria en el IMSS: pagas tú las cuotas para mejorar tu pensión de Ley 73.
- **NSS:** Número de Seguridad Social.
- **Pensión de viudez:** pensión que recibe la pareja de una persona asegurada o pensionada que falleció.
- **Retiro:** etapa de la vida en la que dejas de trabajar y vives de pensiones y ahorros.
- **Régimen del décimo transitorio:** régimen anterior del ISSSTE: el Instituto paga la pensión según años de servicio, edad y sueldo.
- **Semanas cotizadas:** semanas en que se pagaron cuotas al IMSS a tu nombre.

### Salud y seguros

- **Ajustador:** persona de la aseguradora que evalúa un siniestro.
- **Antigüedad:** tiempo que llevas asegurada sin interrupción.
- **Beneficiario:** persona que recibe el pago del seguro.
- **Carátula:** primera hoja de la póliza con los datos principales: suma asegurada, deducible, coaseguro y vigencia.
- **Condiciones generales:** documento con todas las reglas de la póliza.
- **Exclusión:** lo que el seguro no cubre.
- **Modalidad 10:** incorporación voluntaria al IMSS de personas trabajadoras independientes, con servicio médico, incapacidades y pensión.
- **Periodo de espera:** tiempo que debe pasar para que el seguro cubra ciertos padecimientos.
- **Preexistencias:** enfermedades que ya tenías antes de contratar un seguro.
- **Prima:** lo que pagas por tu seguro.
- **Responsabilidad civil:** cobertura que paga los daños que causas a otras personas o a sus bienes.
- **Seguro de Gastos Médicos Mayores:** seguro que paga gastos médicos grandes: hospitalización, cirugías y tratamientos.
- **Seguro de Salud para la Familia:** seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- **Seguro de vida:** seguro que paga una suma a tus beneficiarios si falleces.
- **Siniestro:** el daño que cubre el seguro, como un sismo o un incendio.
- **Suma asegurada:** el monto máximo que paga el seguro.
- **Tabulador:** lista de montos máximos que paga la aseguradora por los honorarios de cada procedimiento.
- **Valor comercial:** lo que vale hoy tu auto en el mercado.
- **Valor de rescate:** lo que te devuelven si cancelas un seguro con ahorro.

### Impuestos sin miedo

- **Deducción personal:** gasto que puedes restar de tus ingresos en tu declaración anual para pagar menos impuesto.
- **e.firma:** tu firma electrónica para trámites con el SAT.
- **Exento:** ingreso que no paga impuesto.
- **Factura:** comprobante fiscal digital (CFDI) a tu nombre.
- **RFC:** Registro Federal de Contribuyentes, tu clave ante el SAT.
- **Saldo a favor:** impuesto que pagaste de más y el SAT te puede devolver.
- **UMA:** Unidad de Medida y Actualización, referencia para límites fiscales.

### Patrimonio y familia

- **Albacea:** persona que se encarga del trámite de la herencia.
- **Convenio de separación:** acuerdo sobre bienes y obligaciones al separarse.
- **Deudor alimentario moroso:** quien deja de pagar una pensión fijada por un juez durante 60 días o más.
- **Donación:** dar un bien en vida sin cobrar.
- **Duelo:** proceso emocional después de una pérdida.
- **Escriturar:** pasar legalmente una propiedad a nombre de otra persona ante notario.
- **Gravamen:** carga sobre un inmueble, como una hipoteca, que aparece en el Registro Público.
- **Heredero:** persona que recibe los bienes de otra al fallecer.
- **Herencia en vida:** transferir bienes a tus herederos mientras vives.
- **Libertad de gravamen:** certificado que muestra si un inmueble tiene deudas o cargas.
- **Lista de sucesión:** lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.
- **Pensión alimenticia:** dinero para comida, casa, salud y escuela de los hijos.
- **Poder notarial:** documento ante notario en el que autorizas a otra persona a actuar por ti.
- **Revocar:** cancelar un poder o un documento.
- **Subcuenta de vivienda:** dinero que tu patrón aporta para tu vivienda dentro de tu cuenta de ahorro para el retiro.
- **Testamento:** documento en el que decides a quién pasan tus bienes cuando faltes.
- **Trámite sucesorio:** proceso para repartir los bienes de quien falleció.
- **Tutor:** persona que cuida los intereses de un menor de edad.
- **Unión libre:** pareja que vive junta sin estar casada.
- **Usufructo:** derecho a usar una propiedad y vivir en ella aunque otra persona sea la dueña.
- **Violencia patrimonial:** quitar, dañar, esconder o vender bienes o documentos de otra persona.
- **Voluntad anticipada:** documento en el que dices qué tratamientos médicos quieres o no si no puedes decidir.

### Decidir con calma y tu plan

- **Control económico:** cuando otra persona decide sobre tu dinero sin tu consentimiento o te impide usarlo.
- **Límite:** acuerdo claro sobre lo que aceptas y lo que no.
- **Periodo de cancelación:** plazo para cancelar un contrato sin costo.
- **Plan de una página:** resumen de tus decisiones de dinero en una sola hoja, con fechas para revisarlas.
- **Segunda opinión:** consulta con alguien que no gana nada con tu decisión.


## Dónde encontrar ayuda

Cada opción tiene una función distinta. Todas las de esta tabla son oficiales y, salvo que se indique, sin costo. Información consultada el 29 de septiembre de 2026; confírmala en el sitio oficial de cada institución.

| Necesidad | Dónde | Costo | Qué verificar |
|---|---|---|---|
| Reclamar a un banco, aseguradora o AFORE | UNE de la institución y CONDUSEF: 55 5340 0999 u 800 999 8080 | Sin costo | Folio de tu reclamación |
| Verificar una institución | SIPRES y Buró de Entidades Financieras (CONDUSEF); padrón y advertencias (CNBV) | Sin costo | Nombre legal exacto |
| Verificar un asesor en inversiones | Registro de Asesores en Inversiones (CNBV) | Sin costo | Registro vigente |
| Verificar una aseguradora o agente | CNSF | Sin costo | Cédula del agente |
| Fraudes y delitos en línea | 088 de la Guardia Nacional y fiscalía de tu estado | Sin costo | Evidencia |
| Extorsión | 089 (denuncia anónima) y 911 | Sin costo | Localizar a tu familiar primero |
| Llamadas de publicidad | REPEP de Profeco (55 5568 8722 u 800 468 8722) y REUS de CONDUSEF | Sin costo | Nadie cobra por inscribirte |
| Reporte de crédito y bloqueo | Buró de Crédito y Círculo de Crédito | Un reporte sin costo al año en cada uno | Solo sitios oficiales |
| Líneas de celular con tu CURP | Comisión Reguladora de Telecomunicaciones (portal.crt.gob.mx) | Sin costo | Desvincula las que no son tuyas |
| Semanas cotizadas, Modalidad 40 y viudez | IMSS | Sin costo | Trámites sin gestores |
| Régimen, jubilación y viudez del gobierno federal | ISSSTE y PENSIONISSSTE; hoja única de servicios en la dependencia | Sin costo | Trámites sin gestores |
| AFORE | CONSAR, e-SAR y AforeMóvil | Sin costo | CURP |
| Pensiones del Bienestar | Programas para el Bienestar | Sin costo | Solo módulos oficiales |
| Dudas con el SAT | SAT y PRODECON | Sin costo | Tu contraseña del SAT |
| Testamento y poderes | Notarías; Mes del Testamento en septiembre | Con costo | Hazlo ante notario |
| Apoyo emocional | Línea de la Vida: 800 911 2000 | Sin costo | Atención 24 horas |
| Control económico o violencia | Instancia de las mujeres de tu estado, DIF; 911 si hay riesgo | Sin costo | Busca apoyo |

### Guion para pedir información

"Quiero entender [tema] antes de decidir. ¿Qué documentos necesito? ¿Tiene costo? ¿Cuánto tarda? ¿Cómo doy seguimiento? ¿Me lo pueden dar por escrito?"

---

## Preguntas frecuentes

**¿Necesito saber de finanzas o de tecnología para tomar el curso?** No. Cada lección empieza desde cero y hay sesiones de acompañamiento y práctica guiada.

**¿Tengo que dar mis datos reales?** No. Puedes usar datos inventados. Nunca te pediremos RFC, CURP, contraseñas, códigos ni números de cuenta.

**¿El curso me dice en qué banco o inversión poner mi dinero?** No. Te enseñamos a verificar y comparar. Las lecciones no incluyen recomendaciones comerciales.

**¿Qué hago si recibo una llamada o mensaje sospechoso?** Cuelga o no respondas, y verifica tú por el número de atrás de tu tarjeta o el sitio oficial (módulo 4).

**¿Qué hago si ya caí en un fraude?** Bloquea tarjetas y accesos, reclama por escrito con folio, acude a la CONDUSEF, reporta al 088 y denuncia (M4 U08).

**¿Me pueden ayudar a usar la app de mi banco en la sesión?** Te mostramos cómo con capturas y un simulador. Nadie del programa opera tu banca ni te pide tu celular desbloqueado.

**¿Puedo compartir el curso con mi familia?** Sí. Invitar a tu persona de confianza a las sesiones puede ayudarte.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo del programa, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Qué hago después de un sismo o una inundación?** Primero tu seguridad. Toma fotos de los daños, reporta a tu aseguradora por su número oficial y no pagues nada por adelantado. Los apoyos de gobierno no tienen costo (M8 U06).

**¿Terminé de pagar mi casa y ya está todo?** Falta inscribir la liberación de hipoteca con una notaría (M10 U06).

**¿Cómo sé qué hay en mi historial de crédito?** Pide tu reporte especial sin costo una vez al año en Buró de Crédito y en Círculo de Crédito, en sus sitios oficiales. Reclamar un error también no tiene costo (M5 U06).

**¿Qué hago con un rumor sobre mi pensión o mis inversiones?** Confírmalo en el sitio oficial antes de actuar y no decidas con miedo (M6 U06).

**¿Qué hago si un dato cambió?** Confírmalo en CONDUSEF, la CNBV o el sitio oficial de la institución y usa la información vigente.


## Referencias

Estas son las fuentes que usamos en el curso, para que puedas verificarlas. Consultadas el 29 de septiembre de 2026.

### Instituciones

- **I01** CONDUSEF: SIPRES, Buró de Entidades Financieras, REUS, reclamaciones, Portal de Fraudes Financieros.
- **I02** CNBV: padrón de entidades supervisadas, Registro de Asesores en Inversiones, advertencias, Monto Transaccional del Usuario.
- **I03** IPAB: seguro de depósitos.
- **I04** Banco de México: UDIS, SPEI y CEP.
- **I05** Cetesdirecto: Cetes y BONDDIA.
- **I06** CNSF: aseguradoras y agentes.
- **I07** IMSS: semanas cotizadas, Modalidad 40, pensión de viudez.
- **I07b** ISSSTE y PENSIONISSSTE: régimen del décimo transitorio, cuentas individuales, pensión por causa de muerte.
- **I08** CONSAR, e-SAR y AforeMóvil.
- **I09** Programas para el Bienestar: Pensión Mujeres Bienestar y Pensión para Adultos Mayores.
- **I10** SAT y PRODECON: declaraciones, retenciones, deducciones.
- **I11** Profeco: REPEP.
- **I12** Comisión Reguladora de Telecomunicaciones: líneas móviles y CURP.
- **I13** Buró de Crédito y Círculo de Crédito: reportes y bloqueo.
- **I14** Guardia Nacional: 088.
- **I15** Secretaría de Gobernación: Mes del Testamento.

### Leyes y disposiciones

- **L01** Ley de Protección y Defensa al Usuario de Servicios Financieros.
- **L02** Ley de Instituciones de Crédito (beneficiarios, art. 56).
- **L03** Ley del Seguro Social (continuación voluntaria, art. 218).
- **L04** Ley del Impuesto sobre la Renta (arts. 93 y 151).
- **L05** Ley de Ingresos de la Federación 2026 (retención por intereses).

### Comunicados y medios consultados

- **M01** CONDUSEF: cifras de reclamaciones por posible fraude (2025 y primer trimestre de 2026).
- **M02** Notas informativas sobre el Monto Transaccional del Usuario (MTU) de la CNBV.
- **M03** Notas informativas sobre montos 2026 de las pensiones del Bienestar.
- **M04** Notas informativas sobre Modalidad 40 y pensión de viudez del IMSS en 2026.
- **M06** Decreto del 24 de junio de 2025 (DOF) sobre la edad de jubilación en el décimo transitorio del ISSSTE y notas informativas de 2026.
- **M05** Notas informativas sobre el registro de líneas móviles con CURP.
- **M07** Ley sobre el Contrato de Seguro y guías de CONDUSEF sobre seguro de casa y siniestros.
- **M09** Buró de Crédito, Círculo de Crédito y reglas de tarjetas del Banco de México; Profeco, «Quién es quién en los precios».
- **M10** Innovations for Poverty Action y J-PAL, *Nudges para una óptima salud financiera*.
- **M08** Infonavit y Fovissste: seguro del crédito, cancelación de hipoteca y subcuenta de vivienda.


# Parte 14. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. ¿Qué tengo y dónde está?

**Caso 1. La lista de Carmen.** Carmen quiere hacer su inventario y piensa anotar el NIP de cada tarjeta «para no olvidarlo». **¿Qué hace?**

- ✔ Anota solo los últimos 4 dígitos.
- Anota el NIP junto a cada tarjeta.
- Guarda los NIP en una nota del celular.

**Caso 2. La herencia de Lucía.** Lucía heredó inversiones de su esposo y no sabe dónde están todas. **¿Qué hace?**

- ✔ Revisa estados de cuenta y constancias.
- Espera a que las instituciones la llamen.
- Pregunta a un conocido que sabe de inversiones.

**Caso 3. La cuenta olvidada de Elena.** Elena encuentra en su inventario una cuenta que no usa desde hace años y que cobra comisión. **¿Qué hace?**

- ✔ Confirma el saldo y la cancela por escrito.
- La deja así; algún día la usará de nuevo.
- Deja de pagar la comisión sin avisar al banco.

## M1 U02. ¿Cuánto cuesta vivir en mi casa, al mes y al año?

**Caso 1. El enero de Elena.** Elena paga en enero el seguro del auto, el predial y las inscripciones, y siempre usa su ahorro. **¿Qué hace?**

- ✔ Divide lo anual entre 12 y lo aparta.
- Sigue usando su ahorro cada enero.
- Pide un préstamo en diciembre para enero.

**Caso 2. El gasto de Carmen.** Carmen no sabe cuánto gasta la casa; Arturo dice que «unos 40 mil». **¿Qué hace?**

- ✔ Revisa tres meses de estados de cuenta.
- Usa los 40 mil que calcula Arturo porque él lleva las cuentas.
- Calcula a ojo lo que cree que gasta.

**Caso 3. La diferencia de Maru.** El mes promedio de Maru es 3,000 mayor que su ingreso y lo cubre con la tarjeta. **¿Qué hace?**

- ✔ Ajusta gastos y deja de usar la tarjeta.
- Sigue cubriendo la diferencia con la tarjeta.
- Pide un aumento de límite para estar tranquila.

## M1 U03. Mi dinero, nuestro dinero

**Caso 1. La cita de Carmen.** Carmen quiere saber qué tienen, pero teme que Arturo se moleste. **¿Qué hace?**

- ✔ Propone una cita con una meta común.
- Revisa a escondidas los papeles de Arturo.
- Espera a que Arturo saque el tema algún día.

**Caso 2. La cuenta de Maru.** Maru deposita lo que gana por catálogo en la cuenta de su esposo. **¿Qué hace?**

- ✔ Abre una cuenta a su nombre.
- Sigue depositando en la cuenta del esposo.
- Guarda lo que gana en efectivo en casa.

**Caso 3. El acta de Elena.** Elena no sabe qué régimen tuvo su matrimonio al divorciarse. **¿Qué hace?**

- ✔ Revisa su acta y consulta si hay dudas.
- Supone que todo fue en sociedad conyugal.
- Pregunta a una amiga qué régimen tuvo ella.

## M1 U04. Tu carpeta de documentos

**Caso 1. La carpeta de Lucía.** Lucía tiene sus documentos en tres cajones distintos y nadie sabe dónde. **¿Qué hace?**

- ✔ Los junta en una carpeta y avisa dónde está.
- Los deja en los cajones; ella sabe dónde.
- Manda fotos de todos los documentos al chat de la familia.

**Caso 2. El escaneo de Carmen.** Carmen quiere escanear su carpeta y mandarla por WhatsApp a sus hijos «por si acaso». **¿Qué hace?**

- ✔ Guarda las copias con contraseña.
- Manda los escaneos al grupo de sus hijos.
- Sube las copias a una red social privada.

**Caso 3. La copia de Maru.** Le piden a Maru una copia de su INE para registrarse como vendedora por catálogo. **¿Qué hace?**

- ✔ Anota en la copia para qué es y la fecha.
- Entrega la copia sin anotar nada.
- Manda la foto de su INE por WhatsApp.

## M1 U05. Compra inteligente: el súper, las ofertas y los pagos a plazos

**Caso 1. La lavadora de Elena.** Elena ve una lavadora a 18 meses sin intereses «solo hoy». **¿Qué hace?**

- ✔ Suma sus pagos a plazos, espera un día y decide.
- La compra hoy para no perder la oferta.
- La compra y deja de pagar otra cosa.

**Caso 2. El súper de Lucía.** Lucía cree que el «2 por 1» siempre conviene. **¿Qué hace?**

- ✔ Calcula el precio por unidad y compra si lo usará.
- Lleva el 2 por 1 porque siempre conviene.
- Compra el doble para aprovechar.

**Caso 3. El gimnasio de Carmen.** Carmen pagó un año de gimnasio y no va, pero quiere renovar «para no perder lo pagado». **¿Qué hace?**

- ✔ No renueva: lo ya pagado no se recupera.
- Renueva para no perder lo que pagó.
- Renueva y se promete ir más.

## M2 U01. ¿Quién es quién en el sistema financiero?

**Caso 1. La llamada de Lucía.** A Lucía le llama alguien «de la CONDUSEF» para recuperar dinero a cambio de un depósito. **¿Qué hace?**

- ✔ Cuelga y llama al número oficial.
- Hace el depósito para no perder el dinero.
- Pide a quien llamó su número de empleado.

**Caso 2. El fondo de Carmen.** Carmen quiere saber si la casa de bolsa donde está su fondo está autorizada. **¿Qué hace?**

- ✔ La busca en el padrón de la CNBV.
- Confía porque tiene oficinas en Reforma.
- Pregunta a su asesor si está autorizada.

**Caso 3. La queja de Elena.** El banco le cobró a Elena una comisión que no reconoce y no le resuelven. **¿Qué hace?**

- ✔ Reclama en el banco y luego en CONDUSEF.
- Paga a un gestor para que reclame por ella.
- Deja pasar el cargo para no complicarse.

## M2 U02. Bancos, casas de bolsa, aseguradoras y AFORE: ¿qué hace cada una?

**Caso 1. El fondo de Carmen.** Carmen cree que su fondo en la casa de bolsa está protegido por el IPAB. **¿Qué hace?**

- ✔ Entiende que es inversión, sin IPAB.
- Supone que el IPAB lo protege igual.
- Lo pasa todo a efectivo para estar segura.

**Caso 2. El ofrecimiento a Lucía.** En la sucursal le ofrecen a Lucía «una cuenta que da más» y resulta ser un fondo de inversión. **¿Qué hace?**

- ✔ Pregunta la institución y el riesgo.
- Firma porque se lo ofrece su propio banco.
- Acepta si le prometen que no puede bajar.

**Caso 3. La app de Elena.** Elena usa una app que promete «rendimientos diarios» y no sabe si es banco. **¿Qué hace?**

- ✔ Busca el nombre legal en la CNBV.
- Confía porque la app tiene buenas reseñas.
- Deposita poco para probar si paga.

## M2 U03. Verifica antes de confiar

**Caso 1. La financiera de Maru.** A Maru le ofrecen 2% mensual «garantizado» en una financiera nueva con oficinas elegantes. **¿Qué hace?**

- ✔ Verifica en el SIPRES y en la CNBV.
- Invierte porque la oficina se ve seria.
- Invierte poco primero para probarla.

**Caso 2. El promotor de Lucía.** Un promotor le pide a Lucía depositar a su cuenta personal «para agilizar». **¿Qué hace?**

- ✔ No deposita a una cuenta personal.
- Deposita si el promotor le da recibo.
- Deposita y le pide la factura después.

**Caso 3. El nombre de Carmen.** Carmen recibe un folleto de «Banco Nacional Mexicano Plus». **¿Qué hace?**

- ✔ Compara el nombre con el padrón.
- Cree que es su banco por el logotipo.
- Llama al teléfono que trae el folleto.

## M2 U04. Tus derechos y dónde reclamar

**Caso 1. El seguro de Elena.** Elena descubre un seguro de 350 pesos al mes que nunca contrató. **¿Qué hace?**

- ✔ Reclama en la UNE y guarda el folio.
- Acepta que el seguro venía con la tarjeta.
- Deja de pagar la tarjeta en protesta.

**Caso 2. La respuesta a Lucía.** El banco no respondió la reclamación de Lucía en el plazo. **¿Qué hace?**

- ✔ Acude a la CONDUSEF con su folio.
- Espera unos meses más a que respondan.
- Publica su queja en redes y espera.

**Caso 3. La llamada de Carmen.** Carmen reclama por teléfono y no le dan número de folio. **¿Qué hace?**

- ✔ Pide el folio o reclama por escrito.
- Confía en que lo anotaron en el sistema.
- Vuelve a llamar hasta que le resuelvan.

## M3 U01. Tu banco en el celular: lo que sí y lo que nunca

**Caso 1. El miedo de Lucía.** Lucía no usa la app por miedo y siempre hace fila con desconocidos alrededor. **¿Qué hace?**

- ✔ Pide que le activen la app en la sucursal.
- Sigue pidiendo ayuda a quien esté en la fila.
- Le da su tarjeta al nieto para que haga todo.

**Caso 2. La llamada a Carmen.** Alguien «del banco» le pide a Carmen el código que le acaba de llegar. **¿Qué hace?**

- ✔ Cuelga y llama al número de su tarjeta.
- Da el código porque parece el banco.
- Da solo la mitad del código para probar.

**Caso 3. La app de Maru.** A Maru le llega un mensaje con un enlace para «descargar la nueva app de tu banco». **¿Qué hace?**

- ✔ Busca la app en la tienda oficial.
- Abre el enlace; parece de su banco.
- Reenvía el enlace a su hija para que lo abra.

## M3 U02. Primeros pasos seguros en la app

**Caso 1. La contraseña de Lucía.** La contraseña de Lucía es su fecha de nacimiento y está anotada en la funda. **¿Qué hace?**

- ✔ Pone una frase propia y tira el papel.
- Deja la fecha pero quita el papel de la funda.
- Guarda la contraseña en una nota del celular.

**Caso 2. La ayuda de Carmen.** Su hija le ayuda a Carmen a instalar la app y ve la contraseña. **¿Qué hace?**

- ✔ Cambia la contraseña al terminar.
- La deja así: su hija es de confianza.
- Le pide a su hija que no la comparta.

**Caso 3. El celular viejo de Elena.** Elena va a regalar su celular viejo a su hijo. **¿Qué hace?**

- ✔ Cierra el banco, quita el token y lo borra.
- Solo borra sus fotos y conversaciones personales antes de regalarlo.
- Se lo da así; es para su propio hijo.

## M3 U03. Pon candados: alertas, límites y tarjeta apagada

**Caso 1. La cartera de Carmen.** A Carmen le roban la cartera y no tenía alertas ni forma de apagar la tarjeta. **¿Qué hace?**

- ✔ Activa alertas y apagado de tarjeta.
- Deja de llevar tarjetas y usa efectivo.
- Pide al banco un límite de crédito menor.

**Caso 2. El límite de Lucía.** Lucía nunca transfiere más de 3,000, pero su límite es el de 12,800 que puso el banco. **¿Qué hace?**

- ✔ Baja su límite a 3,000 en la app.
- Lo deja en 12,800 por si acaso.
- Lo sube al máximo para no tener problemas.

**Caso 3. La prisa de Maru.** Alguien le pide a Maru que suba su límite «ya» para recibir un reembolso. **¿Qué hace?**

- ✔ No lo sube y cuelga.
- Lo sube un rato y luego lo baja.
- Lo sube solo si el monto es pequeño.

## M3 U04. Transferir sin errores

**Caso 1. El error de Maru.** Maru se equivocó en un número de la CLABE y el dinero llegó a otra persona. **¿Qué hace?**

- ✔ Llama al banco y reclama de inmediato.
- Espera a que la otra persona lo devuelva.
- Vuelve a transferir la cantidad correcta.

**Caso 2. El aviso a Carmen.** Carmen recibe un correo de su jardinero: «cambié de cuenta, deposita a esta nueva». **¿Qué hace?**

- ✔ Confirma por un teléfono que ya tenía.
- Paga a la cuenta nueva del correo porque el nombre es el mismo.
- Responde el correo para confirmar.

**Caso 3. La prueba de Elena.** El casero dice que no le llegó la renta que Elena transfirió. **¿Qué hace?**

- ✔ Descarga el CEP en el sitio de Banxico.
- Le manda una foto de su saldo.
- Vuelve a transferir para evitar problemas.

## M3 U05. Tu persona de confianza

**Caso 1. El joven amable de Lucía.** Un desconocido amable se ofrece a ayudar a Lucía con la app en la sucursal. **¿Qué hace?**

- ✔ Pide ayuda al personal con gafete.
- Acepta porque el joven es muy amable.
- Le presta el celular solo un momento.

**Caso 2. La elección de Carmen.** Carmen piensa pedir ayuda al sobrino que siempre le pide dinero prestado. **¿Qué hace?**

- ✔ Elige a alguien que no la presione.
- Elige al sobrino porque vive cerca.
- No elige a nadie y pregunta en la fila.

**Caso 3. La hija de Elena.** La hija de Elena le pide su contraseña «para ayudarla más rápido». **¿Qué hace?**

- ✔ Le pide que le explique y ella escribe.
- Le da la contraseña a su hija.
- Le da la contraseña a su hija y luego, algún día, la cambia.

## M4 U01. Cómo piensa quien te quiere estafar

**Caso 1. La prisa de Lucía.** Una voz «del área de seguridad» le dice a Lucía que no cuelgue porque su cuenta será bloqueada en cinco minutos. **¿Qué hace?**

- ✔ Cuelga y llama al número de su tarjeta.
- Sigue en la línea para no perder la cuenta.
- Da sus datos, pero no la contraseña.

**Caso 2. El premio de Carmen.** A Carmen le avisan que ganó una camioneta y solo debe pagar 3,500 de «trámites». **¿Qué hace?**

- ✔ No paga: un premio real no cobra por entregarse.
- Paga los trámites porque el premio vale mucho más que los 3,500.
- Pide que le descuenten los trámites del premio.

**Caso 3. El secreto de Maru.** Le piden a Maru que no le cuente a nadie de una «inversión exclusiva». **¿Qué hace?**

- ✔ Lo cuenta a su persona de confianza y verifica.
- Guarda el secreto para no perder el lugar.
- Invierte poco para ver si es cierto.

## M4 U02. La llamada «del banco»

**Caso 1. El cargo de Carmen.** Le piden a Carmen el código que le llegó para «cancelar un cargo de 18,000». **¿Qué hace?**

- ✔ No lo da, cuelga y llama al banco.
- Da el código para que cancelen el cargo.
- Da el código, pero no su contraseña.

**Caso 2. La cuenta segura de Lucía.** Le dicen a Lucía que su dinero está en riesgo y que lo pase a una «cuenta segura». **¿Qué hace?**

- ✔ Cuelga y llama al número oficial del banco.
- Pasa su dinero a la cuenta que le dieron mientras resuelven el problema.
- Pasa solo la mitad, por si acaso.

**Caso 3. El mensajero de Elena.** «Del banco» le dicen a Elena que pasarán por su tarjeta para cambiarla. **¿Qué hace?**

- ✔ No la entrega y confirma con el banco.
- Entrega la tarjeta dentro de un sobre cerrado.
- Entrega la tarjeta, pero cambia su NIP.

## M4 U03. Mensajes y correos falsos

**Caso 1. La tarjeta de Lucía.** A Lucía le llega un mensaje: «su tarjeta fue bloqueada, ingrese aquí». **¿Qué hace?**

- ✔ Revisa en su app o llama al banco.
- Abre el enlace para reactivar la tarjeta.
- Responde el mensaje pidiendo más datos.

**Caso 2. El paquete de Carmen.** Carmen recibe un mensaje de una paquetería para pagar 30 pesos por un envío que no espera. **¿Qué hace?**

- ✔ Lo borra sin pagar.
- Paga los 30 pesos para recibir el paquete.
- Paga con otra tarjeta para no arriesgarse.

**Caso 3. El número nuevo de Elena.** A Elena le escribe «su hijo» desde un número nuevo pidiéndole dinero urgente. **¿Qué hace?**

- ✔ Llama a su hijo a su número de siempre.
- Envía el dinero porque la foto es de su hijo.
- Envía la mitad y le pide explicaciones.

## M4 U04. «Mamá, estoy en problemas»: extorsión y voces falsas

**Caso 1. La voz de Elena.** Elena oye la voz de su hijo llorando y un hombre le exige 50,000 sin colgar. **¿Qué hace?**

- ✔ Cuelga y localiza a su hijo en la escuela.
- Paga rápido para que no le pase nada.
- Negocia una cantidad menor sin colgar para ganar tiempo con el extorsionador.

**Caso 2. La palabra de Carmen.** Carmen quiere prepararse por si le llaman fingiendo ser su nieto. **¿Qué hace?**

- ✔ Acuerda una palabra clave con su familia.
- Pide a su nieto que le mande audios.
- Guarda una foto del nieto para comparar.

**Caso 3. Las fotos de Maru.** Maru publica en redes cada viaje de su hija, con fechas y lugares. **¿Qué hace?**

- ✔ Hace privadas sus redes y no publica viajes.
- Publica solo en sus historias de 24 horas, que desaparecen solas.
- Sigue publicando; nadie ve su perfil.

## M4 U05. En el cajero y la sucursal

**Caso 1. El señor amable de Lucía.** Su tarjeta se atora y un señor le ofrece ayuda a Lucía. **¿Qué hace?**

- ✔ No acepta y llama para bloquear su tarjeta.
- Sigue las indicaciones del señor amable.
- Marca el NIP otra vez para recuperarla.

**Caso 2. La ranura de Carmen.** Carmen nota que la ranura del cajero se mueve y tiene una pieza extra. **¿Qué hace?**

- ✔ No lo usa y avisa al banco.
- Lo usa rápido y revisa su saldo después.
- Empuja la pieza para que quede fija.

**Caso 3. La herencia de Maru.** Una señora le pide a Maru dinero «para cobrar una herencia» y promete compartirla. **¿Qué hace?**

- ✔ No da nada: es el cuento del tío.
- Da una parte para cobrar la herencia.
- Pide ver los papeles de la herencia.

## M4 U06. Robo de identidad

**Caso 1. La tarjeta de Carmen.** A Carmen le cobran una tarjeta departamental que nunca tramitó. **¿Qué hace?**

- ✔ Pide su reporte, reclama, denuncia y bloquea.
- Paga la tarjeta para que dejen de llamar.
- Ignora las llamadas hasta que se cansen.

**Caso 2. Las líneas de Lucía.** Lucía no sabe si alguien usó su CURP para contratar celulares. **¿Qué hace?**

- ✔ Consulta sin costo sus líneas con su CURP.
- Paga a un gestor para revisar sus líneas.
- Cambia de compañía telefónica por si acaso.

**Caso 3. Los papeles de Maru.** Maru tira a la basura estados de cuenta completos. **¿Qué hace?**

- ✔ Los rompe antes de tirarlos.
- Los tira enteros en bolsas separadas.
- Los guarda todos en una caja sin revisar.

## M4 U07. Que dejen de llamarte: REPEP y REUS

**Caso 1. Las llamadas de Carmen.** A Carmen le llaman para venderle viajes y tiempos compartidos todo el día. **¿Qué hace?**

- ✔ Inscribe sus números en el REPEP.
- Contesta y pide que ya no le llamen.
- Cambia de número de celular.

**Caso 2. El banco de Lucía.** Un banco llama a Lucía cada semana para ofrecerle una tarjeta. **¿Qué hace?**

- ✔ Se registra en el REUS de CONDUSEF.
- Cancela su cuenta con ese banco.
- Se inscribe en el REPEP de Profeco.

**Caso 3. El cobro de Elena.** Le llaman a Elena para «inscribirla en el REPEP» por 300 pesos. **¿Qué hace?**

- ✔ No paga y se inscribe ella en el sitio oficial.
- Paga los 300 para que sea más rápido.
- Paga, pero pide factura del trámite.

## M4 U08. Si ya te pasó: tu plan de respuesta

**Caso 1. Las transferencias de Lucía.** Lucía ve dos transferencias que no hizo después de dar su contraseña en una página falsa. **¿Qué hace?**

- ✔ Bloquea todo y reclama con folio esa noche.
- Espera al estado de cuenta para reclamar todo junto con más pruebas.
- Cambia de banco sin reclamar.

**Caso 2. La vergüenza de Carmen.** Carmen cayó en un fraude y no quiere contárselo a nadie. **¿Qué hace?**

- ✔ Lo cuenta y sigue su plan de respuesta.
- Lo calla para que su familia no se entere.
- Espera a ver si el banco la llama.

**Caso 3. El aviso de Elena.** Elena quiere avisar a sus amigas del fraude que le hicieron. **¿Qué hace?**

- ✔ Avisa sin publicar sus datos.
- Publica sus estados de cuenta como prueba.
- No avisa a nadie para no alarmar.

## M5 U01. Elige y revisa tus cuentas

**Caso 1. Las cinco cuentas de Carmen.** Carmen tiene cinco cuentas y dos cobran comisión sin darle ningún uso. **¿Qué hace?**

- ✔ Deja las útiles y cancela las otras por escrito.
- Deja todas abiertas por si algún día las vuelve a necesitar.
- Deja de usar las que cobran y ya.

**Caso 2. La GAT de Lucía.** La cuenta de ahorro de Lucía tiene GAT real negativa. **¿Qué hace?**

- ✔ Busca una opción que le gane a la inflación.
- La deja así porque los intereses se ven.
- Pasa todo a efectivo para no perder.

**Caso 3. La cuenta olvidada de Maru.** Maru tiene una cuenta de hace diez años sin movimientos. **¿Qué hace?**

- ✔ Pregunta el saldo y decide si la cierra.
- La deja así; algún día la usará.
- Supone que el banco ya la canceló.

## M5 U02. El seguro del IPAB: hasta cuánto te protege

**Caso 1. Los 4.5 millones de Lucía.** Lucía tiene 4.5 millones en una sola cuenta del mismo banco. **¿Qué hace?**

- ✔ Reparte para quedar dentro del límite en cada banco.
- Lo deja todo junto en su banco porque el IPAB cubre todos los depósitos.
- Lo pasa a efectivo y lo guarda en casa.

**Caso 2. Las tres cuentas de Carmen.** Carmen tiene tres cuentas en el mismo banco y cree que cada una tiene su propio límite. **¿Qué hace?**

- ✔ Suma las tres: el límite es por banco.
- Cree que cada cuenta tiene su límite.
- Abre una cuarta cuenta en el mismo banco.

**Caso 3. El fondo de Elena.** Elena cree que su fondo de inversión está protegido por el IPAB. **¿Qué hace?**

- ✔ Entiende que el fondo no tiene IPAB.
- Cree que la CNBV le garantiza el fondo.
- Pasa el fondo a otra casa de bolsa.

## M5 U03. Tu fondo de emergencia

**Caso 1. La operación de Elena.** Elena debe pagar 25,000 de deducible y coaseguro y no tiene ahorro para eso. **¿Qué hace?**

- ✔ Aparta en su fondo el deducible y coaseguro.
- Sigue pagando esos gastos con tarjeta.
- Cancela el seguro para no pagar deducibles.

**Caso 2. El viaje de Carmen.** Carmen quiere usar su fondo de emergencia para un viaje de aniversario. **¿Qué hace?**

- ✔ Ahorra aparte para el viaje.
- Usa el fondo y lo repone algún día.
- Usa el fondo; se lo merece.

**Caso 3. El fondo de Maru.** Maru quiere poner su fondo en acciones para que «rinda más». **¿Qué hace?**

- ✔ Lo deja en una cuenta protegida o en Cetes de corto plazo.
- Lo pasa a un fondo de acciones para que rinda más a largo plazo, por si acaso.
- Lo presta a su comadre con interés.

## M5 U04. Ahorro con Cetes y BONDDIA

**Caso 1. Los 60,000 de Maru.** Maru tiene 60,000 en una cuenta que no le paga casi nada. **¿Qué hace?**

- ✔ Abre Cetesdirecto y reparte según la fecha.
- Lo deja donde no le paga nada.
- Lo pone todo a 364 días porque paga más.

**Caso 2. La llamada a Lucía.** Alguien «de Cetesdirecto» le ofrece a Lucía una tasa especial si deposita hoy. **¿Qué hace?**

- ✔ Cuelga y entra solo al sitio oficial.
- Deposita hoy para no perder la tasa.
- Pide que le manden el enlace por mensaje.

**Caso 3. El plazo de Elena.** Elena necesitará dinero para las inscripciones en tres meses. **¿Qué hace?**

- ✔ Elige Cetes a 91 días.
- Elige Cetes a 364 días por la tasa.
- Lo deja en la cuenta sin rendimiento.

## M5 U05. Tu tarjeta de crédito: pago mínimo, pago para no generar intereses y meses sin intereses

**Caso 1. El mínimo de Carmen.** Carmen paga siempre el mínimo y su saldo no baja. **¿Qué hace?**

- ✔ Deja de usarla y paga más del mínimo cada mes.
- Sigue pagando el mínimo; así no se atrasa.
- Pide otra tarjeta para pagar esta.

**Caso 2. El refrigerador de Maru.** Maru quiere un refrigerador a 12 meses sin intereses, pero ya tiene dos compras así. **¿Qué hace?**

- ✔ Suma los tres pagos y compra solo si caben.
- Lo compra: es sin intereses.
- Lo compra y reduce el súper esos meses.

**Caso 3. La adicional de Elena.** El hijo de Elena le pide una tarjeta adicional para sus gastos. **¿Qué hace?**

- ✔ Si se la da, le pone un límite bajo.
- Se la da sin límite; él pagará.
- Se la da y le pide que pague el mínimo.

## M5 U06. Tu historial de crédito: Buró, Círculo y ser aval

**Caso 1. El aval de Lucía.** Lucía encuentra en su reporte el crédito de su sobrino con atraso. **¿Qué hace?**

- ✔ Habla con él para ponerse al corriente.
- Lo ignora: el crédito no es suyo.
- Firma como aval otra vez para ayudarlo.

**Caso 2. El error de Elena.** En el reporte de Elena aparece una tarjeta que nunca tuvo. **¿Qué hace?**

- ✔ Reclama sin costo y revisa si hay robo de identidad.
- Paga la tarjeta para que desaparezca.
- Contrata un despacho para quitarla.

**Caso 3. El despacho de Carmen.** A Carmen le ofrecen «limpiar su Buró» por 3,000 pesos. **¿Qué hace?**

- ✔ No paga: es fraude y reclamar no tiene costo.
- Paga la mitad para probar.
- Paga para limpiar su historial rápido.

## M5 U07. Aval, obligado solidario, fiador y referencia: ¿qué firmas?

**Caso 1. La renta del sobrino.** El sobrino de Lucía le pide que firme como obligada solidaria de su renta. **¿Qué hace Lucía?**

- ✔ Lee el contrato y firma solo si podría pagar.
- Firma: es familia y no le va a fallar.
- Firma y le pide un pagaré a su sobrino.

**Caso 2. La tarjeta de la hija de Elena.** A Elena le piden firmar como aval de la primera tarjeta de su hija «por si acaso». **¿Qué hace?**

- ✔ Pregunta si basta con ser referencia.
- Firma como aval sin leer.
- Le da su tarjeta en lugar de firmar.

**Caso 3. La llamada a Maru.** Un despacho llama a Maru para cobrarle la deuda de un compañero del que solo fue referencia. **¿Qué hace?**

- ✔ No paga y se queja en el REDECO.
- Paga para que dejen de llamar.
- Da los datos de la familia del deudor.

## M5 U08. Préstamos de nómina y a cuenta de tu pensión

**Caso 1. La llamada a Lucía.** Le ofrecen a Lucía un préstamo preaprobado y le piden su INE y su estado de cuenta. **¿Qué hace?**

- ✔ Cuelga y verifica en el listado oficial del IMSS.
- Manda su INE y su estado de cuenta para no perder la oferta.
- Pide que le manden el préstamo primero y luego sus datos.

**Caso 2. El préstamo para el sobrino.** El sobrino de Carmen le pide que saque un préstamo a cuenta de su pensión. **¿Qué hace?**

- ✔ No lo saca: la deuda sería suya.
- Lo saca porque su sobrino promete pagar cada mes sin falta.
- Lo saca a la mitad para ayudarle un poco nada más.

**Caso 3. La quincena de Raúl.** Raúl compara un préstamo del banco con uno del ISSSTE. **¿Qué compara?**

- ✔ El total a pagar, el CAT y lo que le queda de su quincena.
- Solo cuál le deposita más rápido en su cuenta de nómina.
- Solo cuál le presta más dinero, por si luego lo necesita.

## M5 U09. Empeñar sin perder tus joyas

**Caso 1. La boleta de Elena.** Elena no recuerda cuándo vence su empeño. **¿Qué hace?**

- ✔ Busca la boleta y paga el refrendo antes de la fecha.
- Espera a que la casa de empeño le avise que ya vence.
- Deja la pulsera y piensa en recuperarla el próximo año.

**Caso 2. Dos casas.** Maru quiere empeñar un reloj. **¿Qué hace?**

- ✔ Compara el avalúo y el costo en dos casas registradas.
- Empeña en la primera casa que encuentra en su camino.
- Empeña donde le prometen más dinero sin preguntar el costo.

**Caso 3. La cadena de Carmen.** Carmen sabe que no podrá recuperar una cadena. **¿Qué hace?**

- ✔ Compara empeñar contra vender directo.
- La empeña de todos modos y deja que la vendan después.
- La empeña y pide otro préstamo para pagar los intereses.

## M6 U01. Rendimiento, riesgo, plazo y liquidez

**Caso 1. El fondo de Lucía.** El fondo heredado de Lucía bajó 3% este año y ella quiere venderlo por el susto. **¿Qué hace?**

- ✔ Revisa su plazo y riesgo antes de vender.
- Vende todo hoy para no perder más.
- Compra más porque bajó de precio.

**Caso 2. La cuenta de Carmen.** La cuenta de ahorro de Carmen paga 1% y la inflación fue 4%. **¿Qué hace?**

- ✔ Busca una opción acorde a su plazo que le gane a la inflación.
- La deja así; al menos no pierde.
- Pasa todo a un fondo de acciones de inmediato para recuperar lo que perdió con la inflación.

**Caso 3. El dinero de Maru.** Maru necesitará dinero en seis meses y le ofrecen un fondo de acciones. **¿Qué hace?**

- ✔ Elige una opción de bajo riesgo.
- Acepta el fondo de acciones por su rendimiento.
- Invierte en cripto para ganar rápido.

## M6 U02. Qué hay en el menú

**Caso 1. El estado de cuenta de Carmen.** Carmen no entiende las palabras «PRLV», «fondo de deuda» y «SIC» de su estado de cuenta. **¿Qué hace?**

- ✔ Pregunta qué es cada una y las clasifica.
- Las ignora porque no las entiende.
- Pide que vendan todo lo que no entiende.

**Caso 2. La propuesta a Lucía.** A Lucía le ofrecen «un estructurado con capital protegido» que no entiende. **¿Qué hace?**

- ✔ No lo compra hasta entenderlo.
- Lo compra porque dice capital protegido.
- Compra una parte pequeña para probar.

**Caso 3. El único fondo de Elena.** Elena tiene todos sus ahorros en las acciones de una sola empresa. **¿Qué hace?**

- ✔ Considera diversificar sus ahorros.
- Compra más acciones de la misma empresa.
- Lo deja así; la empresa es muy conocida.

## M6 U03. Lee tu estado de cuenta de inversión

**Caso 1. Las 12 páginas de Lucía.** Lucía guarda sus estados de cuenta sin abrirlos. **¿Qué hace?**

- ✔ Los revisa cada mes con la tabla.
- Los guarda sin abrir; su asesor los revisa.
- Pide que ya no se los envíen.

**Caso 2. La venta de Carmen.** Carmen ve una venta de acciones que no autorizó. **¿Qué hace?**

- ✔ Reclama de inmediato, por escrito y con folio.
- Espera al siguiente estado de cuenta.
- Le pregunta a su asesor por mensaje.

**Caso 3. El mes de Elena.** El fondo de Elena perdió 2% este mes. **¿Qué hace?**

- ✔ Revisa el rendimiento de doce meses.
- Vende el fondo por la pérdida del mes.
- Cambia de fondo sin revisar.

## M6 U04. Tu asesor: verifica, pregunta y compara

**Caso 1. El producto nuevo para Lucía.** El asesor de siempre le propone a Lucía mover todo a un producto nuevo. **¿Qué hace?**

- ✔ Pregunta costos y compara por escrito.
- Acepta porque lo conoce desde hace años.
- Acepta mover solo la mitad.

**Caso 2. El contrato de Carmen.** Le piden a Carmen firmar un contrato que permite al asesor operar sin consultarla. **¿Qué hace?**

- ✔ Pide que cada operación requiera su autorización.
- Firma para que el asesor pueda operar tranquilo cuando vea oportunidades.
- Firma, pero revisa cada año.

**Caso 3. El depósito de Maru.** Un asesor le pide a Maru depositar a su cuenta personal para «agilizar». **¿Qué hace?**

- ✔ No deposita en una cuenta personal.
- Deposita porque el asesor es conocido.
- Deposita y pide un recibo firmado.

## M6 U05. Inversiones milagro y «yo te lo manejo»

**Caso 1. El negocio de divisas de Carmen.** Una amiga del club le ofrece a Carmen 5% mensual en un negocio de divisas. **¿Qué hace?**

- ✔ La busca en la CNBV y no invierte.
- Invierte poco porque su amiga ya ganó.
- Invierte y retira en cuanto recupere.

**Caso 2. El sobrino de Lucía.** El sobrino de Lucía le ofrece «manejarle» sus ahorros en la bolsa desde su cuenta. **¿Qué hace?**

- ✔ No le da su dinero; usa una cuenta a su nombre.
- Le da una parte para que la maneje.
- Le da todo con un pagaré firmado.

**Caso 3. La invitación de Maru.** Le ofrecen a Maru ganar comisiones por cada amiga que invite a invertir. **¿Qué hace?**

- ✔ No entra: pagar por invitar es pirámide.
- Entra e invita solo a quien tiene dinero.
- Entra sin invitar a nadie.

## M6 U06. Noticias, rumores y cambios: ajusta tu plan sin pánico

**Caso 1. El grupo de Lucía.** En el grupo de la familia dicen que «van a quitar las pensiones». **¿Qué hace Lucía?**

- ✔ Lo confirma en el sitio oficial del IMSS.
- Retira todo lo que puede por si acaso.
- Lo reenvía a toda la familia.

**Caso 2. Los Cetes del cuñado.** El cuñado de Lucía sacó todo de Cetes por miedo y le dice que haga lo mismo. **¿Qué hace?**

- ✔ Revisa su meta y su plazo y deja su dinero.
- Vende todo como su cuñado.
- Pasa todo a efectivo en casa.

**Caso 3. El gas de Maru.** Subió el precio del gas y de la luz en casa de Maru. **¿Qué hace?**

- ✔ Ajusta su presupuesto antes de tocar su fondo.
- Usa su fondo de emergencia cada mes.
- Paga la luz con la tarjeta y difiere.

## M7 U01. Tu mapa de pensiones

**Caso 1. Las semanas de Maru.** Maru cree que no tiene pensión porque se dedicó a la casa, pero trabajó 12 años. **¿Qué hace?**

- ✔ Consulta sus semanas y su AFORE.
- Da por hecho que no tiene nada.
- Paga a un gestor para que lo averigüe.

**Caso 2. El esposo de Carmen.** Carmen no sabe si aparece como beneficiaria de la pensión de Arturo. **¿Qué hace?**

- ✔ Revisa con Arturo sus documentos y beneficiarios.
- Supone que por estar casada ya aparece.
- Espera a que Arturo se jubile para preguntar por los beneficiarios.

**Caso 3. Los 60 años de Lucía.** Lucía cumplió 60 y no sabe qué programa del Bienestar le corresponde. **¿Qué hace?**

- ✔ Revisa los requisitos de Mujeres Bienestar.
- Espera a cumplir 65 para preguntar.
- Paga a quien le ofrece registrarla.

## M7 U02. Tu AFORE y tus semanas cotizadas

**Caso 1. La AFORE de Elena.** Elena no sabe en qué AFORE está después de varios trabajos. **¿Qué hace?**

- ✔ La localiza sin costo con su CURP.
- Paga a un gestor para encontrarla.
- Llama a cada AFORE para preguntar.

**Caso 2. El beneficiario de Maru.** El beneficiario de la AFORE de Maru es su papá, que ya falleció. **¿Qué hace?**

- ✔ Actualiza sus beneficiarios en su AFORE.
- Lo deja así; ya pasará a sus hermanos.
- Espera a jubilarse para cambiarlos.

**Caso 3. El regalo de Carmen.** Un agente le ofrece a Carmen una licuadora si se cambia de AFORE. **¿Qué hace?**

- ✔ Compara rendimientos en la CONSAR antes.
- Se cambia porque el regalo es útil.
- Se cambia y regresa si no le gusta.

## M7 U03. Modalidad 40: ¿puedes y te conviene?

**Caso 1. El gestor de Maru.** Un gestor le ofrece a Maru inscribirla por 15,000. **¿Qué hace?**

- ✔ Confirma en el IMSS y hace el trámite sin costo.
- Paga los 15,000 para asegurar su lugar.
- Paga la mitad ahora y el resto cuando el gestor confirme la inscripción.

**Caso 2. El cálculo de Elena.** Elena cotiza en Ley 97 y le ofrecen la Modalidad 40 «para subir su pensión». **¿Qué hace?**

- ✔ Pregunta en el IMSS si le conviene.
- Se inscribe porque a su amiga le funcionó.
- Paga un año para ver si su pensión sube.

**Caso 3. El préstamo de Carmen.** Le ofrecen a Carmen un préstamo para pagar de golpe sus cuotas de Modalidad 40. **¿Qué hace?**

- ✔ Pide una estimación del IMSS antes de endeudarse.
- Toma el préstamo para asegurar la pensión.
- Pide el préstamo a sus hijos.

## M7 U04. Pensión de viudez y pensiones del Bienestar

**Caso 1. Los 65 de Lucía.** Lucía cumplirá 65 y ya recibe pensión de viudez. **¿Qué hace?**

- ✔ Se registra en el módulo oficial.
- Supone que no puede por tener viudez.
- Paga a un gestor para registrarse.

**Caso 2. Los papeles de Carmen.** Carmen no sabe dónde está su acta de matrimonio. **¿Qué hace?**

- ✔ La tramita y la guarda en su carpeta.
- Espera a necesitarla para buscarla.
- Le pide a Arturo que la guarde él.

**Caso 3. La llamada a Maru.** Le llaman a Maru para «aumentar su pensión del Bienestar» a cambio de un pago. **¿Qué hace?**

- ✔ Cuelga: el registro no tiene costo.
- Paga para que le aumenten la pensión.
- Da los datos de su tarjeta para el depósito.

## M7 U05. Si tú o tu pareja trabajaron para el gobierno: ISSSTE

**Caso 1. El régimen de Raúl.** Maru no sabe si Raúl está en el régimen anterior o en cuentas individuales. **¿Qué hacen?**

- ✔ Piden la hoja única y confirman el régimen.
- Suponen que está en el régimen viejo.
- Pagan a un gestor para que lo averigüe.

**Caso 2. La mamá de Elena.** La mamá de Elena es viuda de un maestro que era pensionado del ISSSTE y nunca tramitó la pensión de viudez. **¿Qué hace Elena?**

- ✔ La acompaña al ISSSTE con los documentos.
- Le dice que ya pasó mucho tiempo.
- Busca a un gestor que lo haga por ella.

**Caso 3. El gestor.** Un gestor ofrece a Carmen «acelerar» la pensión ISSSTE de su hermano por 20,000 pesos. **¿Qué le aconseja Carmen?**

- ✔ Que no pague: el trámite no tiene costo.
- Que pague la mitad al empezar.
- Que pague si le da recibo.

## M7 U06. ¿Cuánto necesito para mi retiro?

**Caso 1. La pensión de Arturo.** Carmen y Arturo creen que la pensión alcanza sin haberlo calculado. **¿Qué hacen?**

- ✔ Calculan gasto, pensión y diferencia.
- Suponen que la pensión alcanza.
- Esperan a jubilarse para ver qué pasa.

**Caso 2. El seguro de Lucía.** Lucía calcula su retiro sin incluir su seguro médico. **¿Qué hace?**

- ✔ Agrega el seguro y los medicamentos a su gasto.
- Lo deja fuera: ya lo paga cada año.
- Supone que el IMSS cubrirá todo.

**Caso 3. El préstamo a los hijos de Elena.** Elena presta dinero a sus hijos cada vez que le piden, sin ver su propio retiro. **¿Qué hace?**

- ✔ Calcula su retiro y decide cuánto ayudar.
- Presta todo lo que le piden sus hijos.
- Deja de ayudar sin hablarlo con ellos.

## M8 U01. Cómo funciona tu seguro de gastos médicos

**Caso 1. La cirugía de Elena.** Elena no sabe cuánto pagaría ella si la operan. **¿Qué hace?**

- ✔ Revisa deducible, coaseguro y tope y calcula su parte.
- Supone que el seguro paga todo.
- Cancela el seguro por no entenderlo.

**Caso 2. El hospital de Carmen.** Carmen quiere operarse en un hospital que no está en la red de su póliza. **¿Qué hace?**

- ✔ Pregunta cuánto pagaría y considera su red.
- Se opera ahí y reclama después.
- Paga todo y pide reembolso completo.

**Caso 3. La consulta de Lucía.** Lucía quiere usar su seguro de gastos mayores para una consulta de rutina. **¿Qué hace?**

- ✔ Paga la consulta aparte.
- Usa el seguro para cada consulta.
- Pide a su agente que la cubra.

## M8 U02. ¿Por qué sube tanto y cómo bajarlo sin quedarte sin protección?

**Caso 1. El 30% de Elena.** El seguro de Elena subió 30% y piensa cancelarlo. **¿Qué hace?**

- ✔ Prueba subir deducible y ajustar la red.
- Cancela hoy para no pagar el aumento.
- Deja de pagar y espera a ver qué pasa.

**Caso 2. El cambio de Carmen.** A Carmen le ofrecen otra aseguradora más barata. **¿Qué hace?**

- ✔ Pide por escrito que le reconozcan antigüedad.
- Cancela la actual y contrata la barata.
- Cambia sin preguntar porque es más barata y cubre casi lo mismo.

**Caso 3. El deducible de Lucía.** Lucía quiere subir su deducible, pero no tiene ahorro para pagarlo si la operan. **¿Qué hace?**

- ✔ Primero aparta ese monto en su fondo.
- Sube el deducible y confía en que no pase nada.
- Sube el deducible y lo paga con tarjeta.

## M8 U03. Compara y lee tu póliza

**Caso 1. Las dos cotizaciones de Carmen.** Carmen tiene dos cotizaciones con deducibles distintos. **¿Qué hace?**

- ✔ Pide ambas con el mismo perfil.
- Elige la más barata sin revisar.
- Elige la de la marca más conocida.

**Caso 2. La exclusión de Lucía.** Lucía encuentra que su póliza excluye un tratamiento que podría necesitar. **¿Qué hace?**

- ✔ Pregunta por una cobertura adicional.
- Cancela la póliza completa.
- Supone que la exclusión no aplicará.

**Caso 3. El agente de Elena.** Elena no sabe si su agente está autorizado. **¿Qué hace?**

- ✔ Verifica su cédula en la CNSF.
- Confía porque es amigo de la familia.
- Le pide una recomendación a otro cliente.

## M8 U04. Seguro de vida y gastos funerarios

**Caso 1. El seguro con ahorro de Lucía.** Lucía paga 1,800 al mes por un seguro con ahorro y no sabe qué tiene. **¿Qué hace?**

- ✔ Pide la suma, el rescate y los beneficiarios.
- Lo cancela sin preguntar nada.
- Sigue pagando sin revisar.

**Caso 2. Los beneficiarios de Carmen.** La beneficiaria del seguro de vida de Carmen es su mamá, que falleció. **¿Qué hace?**

- ✔ Actualiza sus beneficiarios.
- Lo deja así; su papá cobraría.
- Cancela el seguro y contrata otro.

**Caso 3. El plan de Maru.** A Maru le ofrecen un plan funerario de una empresa que no conoce. **¿Qué hace?**

- ✔ Verifica la empresa y lo que cubre.
- Contrata porque el precio es bajo.
- Paga por adelantado para asegurar el precio.

## M8 U05. Casa y auto: lo básico

**Caso 1. El auto de Carmen.** El auto de Carmen está asegurado con el valor de un auto nuevo aunque tiene diez años. **¿Qué hace?**

- ✔ Pide cotizar con su valor comercial.
- Lo deja así; más valor es mejor.
- Cancela el seguro del auto viejo.

**Caso 2. La casa de Lucía.** La casa de Lucía no tiene cobertura de sismo y vive en una zona sísmica. **¿Qué hace?**

- ✔ Pide cotizar la cobertura de sismo.
- Supone que el seguro la incluye.
- Espera a que haya un sismo para revisar.

**Caso 3. El choque de Elena.** Elena choca y el otro conductor le pide arreglarse sin llamar al seguro. **¿Qué hace?**

- ✔ Llama a su aseguradora y espera al ajustador.
- Acepta arreglarse sin llamar al seguro.
- Admite la culpa para terminar rápido.

## M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado

**Caso 1. El perito de Carmen.** Un «perito» ofrece arreglar las grietas de Carmen si le paga por adelantado. **¿Qué hace?**

- ✔ No paga y reporta a su aseguradora.
- Paga la mitad para apartar la obra.
- Paga todo para que empiece hoy.

**Caso 2. Los documentos de Lucía.** Las escrituras y pólizas de Lucía están en una caja en el piso de abajo, en zona que se inunda. **¿Qué hace?**

- ✔ Las guarda en alto y saca copia digital.
- Las deja en la caja; nunca se ha inundado.
- Se las da a un vecino para que las guarde.

**Caso 3. El apoyo de Maru.** Alguien en la colonia de Maru cobra 500 pesos por «inscribir» a las familias en los apoyos. **¿Qué hace?**

- ✔ No paga y se informa por canales oficiales.
- Paga para no quedarse sin el apoyo.
- Paga y pide recibo para comprobar.

## M8 U07. IMSS por tu cuenta: Seguro de Salud para la Familia y Modalidad 10

**Caso 1. El seguro de Elena.** El seguro privado de Elena subió 30%. **¿Qué hace?**

- ✔ Compara con el IMSS por su cuenta y con subir su deducible.
- Cancela su seguro de golpe sin tener ninguna otra protección.
- Sigue pagando igual cada año aunque le suba cada vez más.

**Caso 2. El catálogo de Maru.** Maru vende por catálogo y no tiene servicio médico ni suma semanas. **¿Qué hace?**

- ✔ Revisa la Modalidad 10 como persona trabajadora independiente.
- Espera a que la contraten en una empresa para tener IMSS algún día.
- Paga a un gestor para que la inscriba sin saber en qué.

**Caso 3. La mamá de Carmen.** La mamá de Carmen tiene 72 años y una enfermedad del corazón. **¿Qué hace?**

- ✔ Pregunta antes de pagar si su enfermedad se cubre y desde cuándo.
- Paga la cuota sin preguntar porque da por hecho que la cubren.
- No la inscribe porque cree que a su edad no la aceptan.

## M9 U01. ¿Tengo que declarar?

**Caso 1. La renta de Lucía.** Lucía recibe pensión, intereses y la renta de un local, y su hijo dice que no declara. **¿Qué hace?**

- ✔ Revisa sus ingresos con una contadora o el SAT.
- Hace caso a su hijo y no declara.
- Espera a que el SAT la busque.

**Caso 2. La contraseña de Carmen.** Carmen nunca ha tenido contraseña del SAT y le da miedo tramitarla. **¿Qué hace?**

- ✔ La tramita para ver su información.
- La evita para que el SAT no la note.
- Le pide a un gestor que la tramite.

**Caso 3. El mensaje de Maru.** A Maru le llega un mensaje del «SAT» con un enlace para cobrar una devolución. **¿Qué hace?**

- ✔ No abre el enlace y entra a sat.gob.mx.
- Abre el enlace para cobrar rápido.
- Reenvía el mensaje a su contadora.

## M9 U02. Lo que te retienen

**Caso 1. El ISR de Carmen.** Carmen cree que el «ISR retenido» es una comisión extra del banco. **¿Qué hace?**

- ✔ Entiende que es impuesto y guarda su constancia.
- Reclama al banco la comisión extra.
- Cambia de banco para no pagarla.

**Caso 2. La pensión de Lucía.** La pensión de Lucía es de 25,000 al mes y teme pagar mucho impuesto. **¿Qué hace?**

- ✔ Revisa que está debajo del límite exento.
- Pide que le reduzcan la pensión.
- Contrata un contador por miedo.

**Caso 3. Las constancias de Elena.** Elena nunca descarga sus constancias de retenciones. **¿Qué hace?**

- ✔ Las descarga cada año del portal.
- Espera a que se las manden por mensaje.
- No las busca; el SAT ya las tiene.

## M9 U03. Deducciones personales y tu declaración anual

**Caso 1. El seguro de Elena.** Elena paga su seguro y consultas, pero nunca pide factura. **¿Qué hace?**

- ✔ Pide factura y paga con tarjeta.
- Guarda los tickets de la farmacia.
- Paga en efectivo para que sea más barato.

**Caso 2. El efectivo de Carmen.** Carmen paga sus consultas en efectivo. **¿Qué hace?**

- ✔ Paga con tarjeta o transferencia.
- Sigue pagando en efectivo con recibo.
- Pide al médico una nota firmada.

**Caso 3. La devolución de Lucía.** Lucía tiene saldo a favor en su declaración y no sabe qué hacer. **¿Qué hace?**

- ✔ Pide la devolución a su cuenta.
- Lo deja para el siguiente año.
- No hace nada; el SAT se lo depositará.

## M10 U01. Testamento: tu decisión por escrito

**Caso 1. Los hijos de Lucía.** Lucía no quiere que sus hijos pasen por un juicio largo como ella. **¿Qué hace?**

- ✔ Hace su testamento ante notario y nombra albacea.
- Les dice a sus hijos lo que quiere, de palabra y frente a todos, para que no haya dudas.
- Pone todo a nombre de su hija mayor.

**Caso 2. El formato de Carmen.** Carmen quiere hacer su testamento con un formato de internet. **¿Qué hace?**

- ✔ Lo hace ante notario.
- Llena el formato y lo guarda en casa.
- Lo firma frente a dos testigos en casa.

**Caso 3. El divorcio de Elena.** Elena hizo testamento cuando estaba casada y ya se divorció. **¿Qué hace?**

- ✔ Hace un testamento nuevo.
- Tacha el nombre de su exesposo.
- Deja el anterior; ya no aplica.

## M10 U02. Beneficiarios: cuentas, seguros y AFORE

**Caso 1. El hermano de Carmen.** El beneficiario de una cuenta de Carmen es su hermano, con quien ya no habla. **¿Qué hace?**

- ✔ Actualiza a sus beneficiarios.
- Lo deja así; su hermano es familia.
- Cierra la cuenta para evitar problemas.

**Caso 2. El nieto de Lucía.** Lucía quiere nombrar beneficiario a su nieto de 8 años. **¿Qué hace?**

- ✔ Pregunta cómo se entregaría y prevé un tutor.
- Lo nombra sin preguntar nada más.
- Pone la cuenta a nombre del niño.

**Caso 3. La AFORE de Elena.** Elena no sabe quién es su beneficiario en la AFORE. **¿Qué hace?**

- ✔ Lo consulta y lo actualiza en su AFORE.
- Supone que son sus hijos.
- Espera a jubilarse para revisarlo.

## M10 U03. Poder notarial y quién decide si tú no puedes

**Caso 1. La mamá de Elena.** Elena no pudo pagar el hospital con los ahorros de su mamá porque ella no podía firmar. **¿Qué hacen después?**

- ✔ Firman un poder especial para pagos médicos y bancos.
- Esperan a que pase otra emergencia.
- Elena usa la tarjeta de su mamá.

**Caso 2. El poder amplio de Lucía.** Un sobrino le pide a Lucía un poder general «para ayudarla con todo». **¿Qué hace?**

- ✔ Da solo un poder especial y limitado.
- Firma el poder general para que la ayude.
- Firma el poder general por un año.

**Caso 3. La voluntad de Carmen.** Carmen quiere dejar por escrito qué tratamientos médicos quiere. **¿Qué hace?**

- ✔ Pregunta por la voluntad anticipada.
- Se lo dice de palabra a sus hijos.
- Lo escribe en una hoja en su carpeta.

## M10 U04. Ayudar a los hijos sin descuidar tu futuro

**Caso 1. El enganche del hijo de Carmen.** El hijo de Carmen le pide 300,000 prestados y que sea su aval. **¿Qué hace?**

- ✔ Calcula su retiro, da lo que puede y no avala.
- Presta los 300,000 y firma como aval.
- Firma como aval, pero no presta dinero, porque su hijo siempre ha pagado a tiempo.

**Caso 2. La casa de Lucía.** Su hija le propone a Lucía poner la casa a su nombre «para evitar trámites». **¿Qué hace?**

- ✔ No transfiere sin asesoría notarial.
- Pone la casa a nombre de su hija.
- Vende la casa y reparte el dinero.

**Caso 3. El préstamo de Elena.** Elena presta 50,000 a su hijo sin anotar nada. **¿Qué hace?**

- ✔ Hace un acuerdo por escrito.
- Confía en que se lo pagará.
- Le cobra intereses de palabra.

## M10 U05. Viudez o separación: los primeros 90 días

**Caso 1. El asesor de Lucía.** A las dos semanas del fallecimiento, un asesor le propone a Lucía cambiar todas sus inversiones. **¿Qué hace?**

- ✔ Le dice que lo verá en tres meses.
- Acepta el cambio para no perder rendimiento.
- Vende todo y lo deja en la cuenta.

**Caso 2. La separación de Elena.** Elena se está separando y no tiene cuenta a su nombre. **¿Qué hace?**

- ✔ Abre una cuenta propia y busca asesoría.
- Firma el convenio para terminar rápido.
- Sigue usando la cuenta de su pareja.

**Caso 3. El préstamo a Carmen.** Un familiar le pide dinero a Carmen días después de enviudar. **¿Qué hace?**

- ✔ Pospone la decisión 90 días.
- Presta porque el familiar lo necesita.
- Presta la mitad para quedar bien.

## M10 U06. Tu casa: escrituras, predial y crédito en orden

**Caso 1. La liberación de Maru.** Maru terminó de pagar su crédito, pero la escritura sigue con el gravamen. **¿Qué hace?**

- ✔ Pide la carta y la inscribe con una notaría.
- Lo deja así; ya pagó todo.
- Pide a un gestor que lo arregle sin notaría.

**Caso 2. El terreno de Elena.** A Elena le ofrecen un terreno muy barato «con papeles del ejido» para su hijo. **¿Qué hace?**

- ✔ No paga hasta que una notaría lo revise.
- Paga el apartado para no perderlo.
- Firma un recibo con el vendedor y paga.

**Caso 3. El crédito de Lucía.** El esposo de Lucía tenía un crédito de vivienda cuando falleció. **¿Qué hace?**

- ✔ Busca el seguro de vida del crédito y reclama.
- Sigue pagando el crédito sin preguntar.
- Deja de pagar y espera noticias.

## M10 U07. Si no hay testamento: unión libre, tierra ejidal y el trámite sucesorio

**Caso 1. La familia del hermano de Lucía.** La pareja, los hijos y los hermanos no se ponen de acuerdo. **¿Qué hacen?**

- ✔ Piden asesoría y, si hay acuerdo, hacen el trámite ante notario.
- Se van a juicio de inmediato para que un juez decida por ellos.
- Se reparten las cosas de palabra sin hacer ningún trámite.

**Caso 2. La parcela de los papás de Maru.** Los papás de Maru tienen una parcela ejidal y nadie sabe si hay lista de sucesión. **¿Qué hace?**

- ✔ Pregunta en el RAN y, si no hay lista, les propone registrarla.
- Da por hecho que la parcela será para el hijo mayor.
- Le pide a sus papás que vendan la parcela antes de que haya problemas.

**Caso 3. La pareja de Elena.** Elena vive en unión libre desde hace 4 años. **¿Qué hace?**

- ✔ Hace su testamento y nombra beneficiarios para dejarlo claro.
- Lo deja así porque su pareja heredará todo sin problema.
- Pone todo a nombre de su pareja desde ahora sin testamento.

## M10 U08. Heredar o dar en vida: impuestos, costos y riesgos

**Caso 1. La casa de Carmen.** Le aconsejan a Carmen venderle la casa a su hija por un peso. **¿Qué hace?**

- ✔ Pregunta en una notaría y compara testamento, donación con usufructo y venta.
- Le vende la casa a su hija por un peso para ahorrar impuestos.
- Le regala la casa a su hija hoy mismo sin ningún papel.

**Caso 2. El 30% de la hija de Carmen.** La hija de Carmen cree que heredar la casa paga 30% de ISR. **¿Qué aprende?**

- ✔ Que heredar no paga ISR; solo los gastos de escriturar.
- Que de verdad hay que pagar 30% y mejor no escriturar.
- Que conviene no avisarle nada al SAT para no pagar.

**Caso 3. La donación de Lucía.** Lucía quiere donarle ya su departamento a su hijo. **¿Qué hace?**

- ✔ Considera el usufructo vitalicio para seguir viviendo ahí.
- Le dona el departamento sin condiciones para no complicarse.
- Le vende el departamento por un peso para que sea más rápido.

## M10 U09. Violencia económica y patrimonial: tu dinero y tus bienes también son tuyos

**Caso 1. El estado de cuenta de Carmen.** Arturo no deja que Carmen vea las cuentas. **¿Qué hace Carmen?**

- ✔ Pide ver los estados de cuenta y se orienta en el 079.
- Deja que él siga manejando todo porque así ha sido siempre.
- Le pide a su hija que revise las cuentas a escondidas.

**Caso 2. El terreno.** Arturo quiere vender el terreno que compraron juntos. **¿Qué hace Carmen?**

- ✔ Pide copia de la escritura y revisa su régimen matrimonial.
- Deja que él lo venda porque el terreno lo pagó con su sueldo.
- Firma lo que le pidan para no pelear con su esposo.

**Caso 3. La tarjeta de Lucía.** Un hijo de Lucía le pide su tarjeta y su NIP para «ayudarle». **¿Qué hace Lucía?**

- ✔ No da su NIP y hace sus pagos ella o acompañada.
- Le da la tarjeta y el NIP porque es su hijo y confía en él.
- Le da solo el NIP y se queda con la tarjeta en su bolsa.

## M10 U10. Pensión alimenticia: pedirla, cuidarla y hacerla durar

**Caso 1. La mitad.** El exesposo de Elena deposita la mitad desde hace cuatro meses. **¿Qué hace Elena?**

- ✔ Junta sus comprobantes y pide orientación en la defensoría.
- Acepta la mitad porque a él le bajó el trabajo este año.
- Deja de pedirle porque cree que ya no se puede hacer nada.

**Caso 2. La inscripción.** En agosto llega la inscripción de los hijos de Elena. **¿Qué hace?**

- ✔ Aparta cada mes una parte para los gastos del año.
- Espera a agosto y ve cómo le hace con la inscripción.
- Usa la tarjeta de crédito para pagar la inscripción completa.

**Caso 3. El seguro de los hijos.** Maru ayuda a su sobrina, que se divorció y no sabe si sus hijos siguen en el seguro del papá. **¿Qué le sugiere?**

- ✔ Revisar la póliza y pedir que el seguro esté en el acuerdo.
- Esperar a que los niños se enfermen para ver si hay seguro.
- Contratar otro seguro de inmediato sin revisar el que tienen.

## M11 U01. Decidir con calma: tus reglas

**Caso 1. La presentación de Maru.** Al final de una presentación con comida, le piden a Maru que firme ese mismo día. **¿Qué hace?**

- ✔ Pide el documento y espera 72 horas.
- Firma para no perder el regalo.
- Firma y cancela después si no le gusta.

**Caso 2. La oferta de Carmen.** Le dicen a Carmen que la tasa especial «solo es hoy». **¿Qué hace?**

- ✔ No firma: la prisa es una señal.
- Firma para no perder la tasa especial.
- Firma y pide que la llamen mañana.

**Caso 3. El contrato de Lucía.** Lucía firmó un contrato y al día siguiente se arrepintió. **¿Qué hace?**

- ✔ Revisa el plazo de cancelación y cancela por escrito.
- Deja de pagar para que lo cancelen.
- Espera a ver si le conviene.

## M11 U02. Presión familiar y control del dinero

**Caso 1. La tarjeta de Lucía.** Un familiar maneja la tarjeta de Lucía y decide en qué gasta. **¿Qué hace?**

- ✔ Cambia su NIP, recupera la tarjeta y pide apoyo.
- Lo deja así para no pelear.
- Le da también su contraseña de la app.

**Caso 2. La presión a Carmen.** Un sobrino presiona a Carmen para que le preste y se enoja si duda. **¿Qué hace?**

- ✔ Lo pensará 72 horas y no cede a la presión.
- Le presta para que se calme.
- Le presta menos de lo que pide para quedar bien con la familia.

**Caso 3. El aislamiento de Elena.** La pareja de Elena no quiere que hable de dinero con nadie más. **¿Qué hace?**

- ✔ Busca orientación en una instancia de apoyo.
- Guarda silencio para evitar problemas.
- Le cede el manejo de todo su dinero.

## M11 U03. Tu plan de una página

**Caso 1. Las hojas de Carmen.** Carmen tiene todo en hojas distintas y no ve el conjunto. **¿Qué hace?**

- ✔ Llena su plan y lo pone al frente de la carpeta.
- Junta las hojas con un clip.
- Lo deja para el próximo año.

**Caso 2. La copia de Lucía.** Lucía quiere darle una copia de su plan a su hija. **¿Qué hace?**

- ✔ Le da una copia sin números ni contraseñas.
- Le da una copia con sus NIP.
- Le manda una foto del plan completo.

**Caso 3. La herencia de Maru.** Maru recibió una herencia y su plan ya no refleja su situación. **¿Qué hace?**

- ✔ Actualiza su plan con calma.
- Invierte la herencia de inmediato.
- Deja el plan como estaba.

# Parte 15. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Qué va en tu inventario?

- Tus contraseñas, para tenerlas juntas
- ✔ Qué tienes, dónde está y a nombre de quién
- Solo las cuentas con más dinero, porque las demás no importan

*¡Correcto! Es el mapa básico.*

**M1 U01 P2.** ¿Qué datos de una cuenta anotas?

- ✔ Los últimos cuatro dígitos
- El número completo y el NIP
- Ninguno, solo el banco sin detalles

*¡Correcto! Así la lista no sirve para robarte.*

**M1 U01 P3.** Encuentras una inversión que no reconoces. ¿Qué haces?

- Llamas al número que viene en un papel viejo
- Esperas a que te llamen
- ✔ Llamas al número oficial de la institución

*¡Correcto! Solo el número oficial es seguro.*

**M1 U02 P1.** ¿Cuál es un gasto anual?

- El súper de cada semana
- La luz de cada bimestre, que casi no cambia
- ✔ El seguro de gastos médicos

*¡Correcto! Llega una vez al año.*

**M1 U02 P2.** Tus gastos anuales suman 60,000. ¿Cuánto apartas al mes?

- ✔ 5,000
- 6,000
- 60,000, todo en enero

*¡Correcto! 60,000 entre 12 son 5,000.*

**M1 U02 P3.** Tu mes promedio es mayor que tu ingreso. ¿Qué haces primero?

- Lo cubres con la tarjeta de crédito
- ✔ Revisas gastos anuales y servicios que no usas
- Cancelas tu seguro médico para ajustar el gasto de inmediato

*¡Correcto! Ajustar es mejor que endeudarte.*

**M1 U03 P1.** ¿Dónde consultas el régimen de tu matrimonio?

- En tu estado de cuenta
- En la escritura de la casa
- ✔ En tu acta de matrimonio

*¡Correcto! El acta lo indica.*

**M1 U03 P2.** ¿Qué es la sociedad conyugal?

- ✔ Lo adquirido en el matrimonio es de las dos personas
- Cada quien conserva lo que compró, aunque sea durante el matrimonio
- Una cuenta de banco compartida por la pareja

*¡Correcto! Se comparte lo adquirido.*

**M1 U03 P3.** ¿Cuál es un buen primer paso para hablar de dinero?

- ✔ Hacer juntos el inventario
- Pedir todas las contraseñas de golpe
- Esperar a que haya un problema

*¡Correcto! Es concreto y sin juicios.*

**M1 U04 P1.** ¿Qué NO va en tu carpeta?

- ✔ Tu NIP y tus contraseñas
- La copia de tu testamento
- Las pólizas de seguro vigentes

*¡Correcto! Nunca se escriben.*

**M1 U04 P2.** ¿Cuándo conviene revisar la carpeta?

- Solo cuando hay una emergencia
- ✔ Una vez al año
- Nunca, si ya está hecha

*¡Correcto! Así se mantiene al día.*

**M1 U04 P3.** ¿Cómo entregas una copia de tu INE para un trámite?

- Sin anotar nada, como te la pidan
- Por WhatsApp a quien la pida, para que el trámite sea rápido
- ✔ Con una nota de para qué es y la fecha

*¡Correcto! Dificulta que la usen para otra cosa.*

**M1 U05 P1.** Un aceite de 1 litro cuesta 48 y uno de 3 litros cuesta 150. ¿Cuál sale más barato por litro?

- El de 3 litros
- ✔ El de 1 litro
- Cuestan igual

*¡Correcto! 48 contra 50 por litro.*

**M1 U05 P2.** ¿Qué haces antes de una compra nueva a plazos?

- ✔ Sumas los pagos que ya tienes
- Compras si es sin intereses
- Pides otra tarjeta

*¡Correcto! Tu presupuesto tiene límite.*

**M1 U05 P3.** Ya pagaste algo que no usas. ¿Qué haces?

- Sigues pagando para no perder lo pagado
- Pagas otro año más
- ✔ Decides por lo que te conviene de hoy en adelante

*¡Correcto! Lo pagado no se recupera.*

## Módulo 2

**M2 U01 P1.** ¿Qué hace la CONDUSEF?

- Vende seguros y créditos a mejor precio que los bancos
- ✔ Orienta y defiende a los usuarios
- Presta dinero en emergencias

*¡Correcto! No tiene costo y defiende a los usuarios.*

**M2 U01 P2.** ¿Dónde verificas si un banco está autorizado?

- ✔ En el padrón de la CNBV
- En su página de redes sociales
- Preguntando al asesor que te llamó

*¡Correcto! La CNBV tiene el padrón.*

**M2 U01 P3.** Alguien «del SAT» te pide un depósito para evitar una multa. ¿Qué es?

- Un trámite normal si es urgente
- Una promoción del gobierno
- ✔ Un fraude: las autoridades no piden depósitos así

*¡Correcto! Cuelga y verifica en el canal oficial.*

**M2 U02 P1.** ¿Qué protege el IPAB?

- Los fondos de inversión de una casa de bolsa
- ✔ Los depósitos en bancos
- Todas las inversiones del país

*¡Correcto! Protege depósitos bancarios.*

**M2 U02 P2.** ¿Qué es una inversión?

- ✔ Dinero que puede subir o bajar de valor
- Dinero que siempre te devuelven igual
- Un seguro de vida con ahorro garantizado

*¡Correcto! Puede ganar o perder.*

**M2 U02 P3.** En la sucursal te ofrecen un producto. ¿Qué preguntas primero?

- Si hay regalo por contratar
- ✔ Quién es la institución que lo da
- Cuántas personas ya lo compraron

*¡Correcto! La protección depende de la institución.*

**M2 U03 P1.** ¿Qué revisas primero de una institución?

- Si tiene oficinas bonitas
- Si alguien conocido ya invirtió
- ✔ Si existe y está autorizada

*¡Correcto! Primero que exista y esté autorizada.*

**M2 U03 P2.** Un promotor te pide depositar a su cuenta personal. ¿Qué haces?

- ✔ No depositas: solo a cuenta de la institución
- Depositas si te da un recibo firmado con el logotipo de la institución
- Depositas la mitad para probar

*¡Correcto! Nunca a personas.*

**M2 U03 P3.** ¿Dónde ves quejas y multas de una institución?

- En sus redes sociales
- ✔ En el Buró de Entidades Financieras
- En los comentarios de su página

*¡Correcto! Es la herramienta oficial de CONDUSEF.*

**M2 U04 P1.** ¿Dónde reclamas primero?

- En redes sociales del banco
- ✔ En la UNE de la institución
- Con un gestor que cobra

*¡Correcto! La UNE es el primer paso.*

**M2 U04 P2.** ¿Qué haces si no te resuelven?

- Te olvidas del cargo
- Pagas para que un despacho reclame
- ✔ Acudes a la CONDUSEF con tu folio

*¡Correcto! La CONDUSEF no tiene costo.*

**M2 U04 P3.** Un seguro de 350 al mes que no pediste, durante un año. ¿Cuánto reclamas?

- ✔ 4,200
- 350
- 3,500

*¡Correcto! 350 por 12 meses son 4,200.*

## Módulo 3

**M3 U01 P1.** ¿Qué nunca te pide tu banco?

- Que revises tus movimientos
- ✔ El código de un mensaje
- Que actives los avisos

*¡Correcto! Los códigos son solo tuyos.*

**M3 U01 P2.** ¿De dónde descargas la app de tu banco?

- ✔ De la tienda oficial del celular
- De un enlace que te llegó
- De la página que te recomendó un conocido

*¡Correcto! Evita apps falsas.*

**M3 U01 P3.** ¿Cuál es el teléfono seguro de tu banco?

- El que viene en un mensaje
- El que te da quien te llamó
- ✔ El de atrás de tu tarjeta

*¡Correcto! Es el oficial.*

**M3 U02 P1.** ¿Cuál es mejor contraseña?

- ✔ Una frase propia con números
- Tu fecha de nacimiento, que nunca se te olvida
- 123456, fácil de recordar

*¡Correcto! Difícil de adivinar.*

**M3 U02 P2.** Tu hija vio tu contraseña al ayudarte. ¿Qué haces?

- Nada, es de confianza
- ✔ La cambias por una que solo tú sepas
- Se la das también a tu otro hijo

*¡Correcto! Solo tú debes saberla.*

**M3 U02 P3.** ¿Qué haces antes de regalar tu celular?

- Solo quitas las fotos
- Nada, ya es de tu familia
- ✔ Cierras el banco, quitas el token y lo borras

*¡Correcto! Así nadie entra a tu banco.*

**M3 U03 P1.** Nunca transfieres más de 4,000. ¿Qué límite fijas?

- El más alto posible
- ✔ 4,000
- El que ponga el banco

*¡Correcto! El límite a tu medida.*

**M3 U03 P2.** ¿Qué usas para comprar en internet?

- ✔ La tarjeta digital
- La tarjeta física de débito
- La tarjeta de otra persona

*¡Correcto! Protege tu tarjeta física.*

**M3 U03 P3.** ¿Recibir un reembolso requiere subir tu límite?

- Sí, siempre que el reembolso sea mayor que tu límite actual
- Solo si es urgente
- ✔ No: el límite es para lo que tú envías

*¡Correcto! Quien lo pida busca robarte.*

**M3 U04 P1.** ¿Qué es el CEP?

- ✔ El comprobante oficial de una transferencia SPEI
- Una clave para entrar a tu app
- Un cobro por transferir

*¡Correcto! Lo emite Banxico.*

**M3 U04 P2.** Te llega un correo: «cambié mi cuenta». ¿Qué haces?

- Pagas a la cuenta nueva
- ✔ Confirmas por teléfono con un número que ya tenías
- Contestas el correo para confirmar

*¡Correcto! Es un fraude común.*

**M3 U04 P3.** ¿Qué revisas antes de enviar?

- Solo la CLABE, porque el nombre lo pone el banco
- Solo el monto
- ✔ El nombre del titular y el monto

*¡Correcto! Ambos evitan errores.*

**M3 U05 P1.** ¿Quién puede ayudarte en el cajero?

- ✔ Nadie desconocido
- Quien se ofrezca amablemente
- Cualquier persona formada detrás

*¡Correcto! Ayuda de desconocidos es un riesgo.*

**M3 U05 P2.** ¿Qué hace tu persona de confianza?

- ✔ Te explica y tú haces los pasos
- Opera tu banca con tu contraseña
- Guarda tu celular por ti

*¡Correcto! Tú mantienes el control.*

**M3 U05 P3.** Tu hija te pide la contraseña para ayudarte. ¿Qué haces?

- Se la das: es tu hija y así te ayuda más rápido cuando no estás
- ✔ Le pides que te explique y tú la escribes
- Le das la mitad de la contraseña

*¡Correcto! Nadie más debe saberla.*

## Módulo 4

**M4 U01 P1.** ¿Qué gancho usa «tiene cinco minutos o pierde su dinero»?

- Premio
- ✔ Urgencia
- Ninguno, es un aviso normal

*¡Correcto! La prisa es el gancho.*

**M4 U01 P2.** Te piden guardar el secreto. ¿Qué haces?

- ✔ Lo cuentas a tu persona de confianza
- Lo guardas para no meterte en problemas
- Pides más detalles a quien llama

*¡Correcto! El secreto es una señal de fraude.*

**M4 U01 P3.** ¿Cuál es la regla de oro?

- Dar solo los datos que ya tienen, para confirmar que son del banco
- Pedir el nombre completo de quien llama
- ✔ Colgar y verificar tú por un canal conocido

*¡Correcto! Siempre verifica tú.*

**M4 U02 P1.** ¿Para qué sirve en realidad el código que te piden?

- Para cancelar el cargo
- ✔ Para autorizar una operación a favor del estafador
- Para verificar tu identidad ante el banco

*¡Correcto! El código autoriza operaciones.*

**M4 U02 P2.** ¿Qué haces si te piden mover tu dinero a una cuenta segura?

- ✔ Cuelgas y llamas al número oficial
- Lo mueves solo una parte
- Pides el nombre de la cuenta

*¡Correcto! La cuenta segura no existe.*

**M4 U02 P3.** Ya diste el código. ¿Qué haces primero?

- Esperas a ver si pasa algo
- Le reclamas a quien llamó y le pides que devuelva lo que tomó
- ✔ Llamas al banco y pides bloquear todo

*¡Correcto! Cada minuto cuenta.*

**M4 U03 P1.** ¿Qué haces con un mensaje que dice que tu cuenta será cancelada?

- ✔ Abres tu app sin usar el enlace
- Entras al enlace para revisar
- Respondes el mensaje con tus datos

*¡Correcto! Nunca uses el enlace.*

**M4 U03 P2.** Te llega un cobro de paquetería que no esperas. ¿Qué es?

- Un envío olvidado que debes pagar
- ✔ Un intento de robar tu tarjeta
- Un regalo de un familiar

*¡Correcto! Buscan tus datos.*

**M4 U03 P3.** «Tu hijo» te escribe desde un número nuevo pidiéndote dinero. ¿Qué haces?

- Envías poco para ayudar
- Le pides una foto para confirmar
- ✔ Le llamas a su número de siempre

*¡Correcto! Confirma por un canal conocido.*

**M4 U04 P1.** ¿Qué es el secuestro virtual?

- ✔ Fingir un secuestro para que pagues rápido
- Un secuestro real transmitido por internet
- Un juego en redes sociales

*¡Correcto! Nadie está secuestrado.*

**M4 U04 P2.** ¿Qué haces primero ante la llamada?

- Pagas primero y luego verificas si tu familiar está bien
- ✔ Cuelgas y localizas a tu familiar
- Negocias una cantidad menor

*¡Correcto! Localizar primero.*

**M4 U04 P3.** ¿Para qué sirve la palabra clave?

- Para entrar a tu banco
- Para las redes de la familia
- ✔ Para saber si quien llama es de verdad tu familiar

*¡Correcto! Quien no la sabe, no es tu familiar.*

**M4 U05 P1.** Tu tarjeta se atora. ¿Qué haces?

- Aceptas la ayuda de quien esté cerca
- ✔ Bloqueas por teléfono y vas a la sucursal
- Marcas el NIP varias veces hasta que el cajero te regrese la tarjeta

*¡Correcto! Nunca aceptes ayuda de desconocidos.*

**M4 U05 P2.** ¿Dónde es más seguro usar el cajero?

- En la calle, de noche
- En una plaza sin vigilancia
- ✔ Dentro de una sucursal, de día

*¡Correcto! Más seguridad.*

**M4 U05 P3.** Te piden dinero para cobrar una herencia. ¿Qué es?

- ✔ El cuento del tío
- Una oportunidad rara
- Un trámite notarial normal

*¡Correcto! Nadie regala así.*

**M4 U06 P1.** Te cobran un crédito que nunca pediste. ¿Qué haces primero?

- Lo pagas para que no te afecte
- Esperas a que dejen de llamar, porque la deuda no es tuya
- ✔ Pides tu reporte de crédito y reclamas

*¡Correcto! Primero sabes qué hay.*

**M4 U06 P2.** ¿Cuánto cuesta consultar las líneas con tu CURP?

- ✔ Nada
- Lo que cobre cada compañía
- Una cuota anual al gobierno

*¡Correcto! No tiene costo.*

**M4 U06 P3.** ¿Qué haces con estados de cuenta viejos?

- Los guardas sueltos en un cajón
- ✔ Los rompes antes de tirarlos
- Los tiras enteros a la basura

*¡Correcto! Así no roban tus datos.*

**M4 U07 P1.** ¿Dónde inscribes tu número contra la publicidad de tiendas?

- En el REUS
- ✔ En el REPEP
- En el Buró de Crédito

*¡Correcto! Cubre bienes y servicios.*

**M4 U07 P2.** ¿Cada cuánto renuevas el REUS?

- ✔ Cada dos años
- Nunca, es permanente
- Cada mes

*¡Correcto! Dura dos años.*

**M4 U07 P3.** Te cobran por inscribirte en el REPEP. ¿Qué es?

- Una cuota oficial
- Un servicio exprés
- ✔ Un fraude

*¡Correcto! No tiene costo.*

**M4 U08 P1.** ¿Qué haces primero si ves cargos que no reconoces?

- ✔ Bloqueas tarjetas y accesos
- Esperas al estado de cuenta
- Publicas los cargos en redes

*¡Correcto! Frena el daño.*

**M4 U08 P2.** ¿A dónde reportas delitos en línea?

- Al 070
- ✔ Al 088
- Al número que venga en un mensaje

*¡Correcto! El 088 recibe delitos en línea.*

**M4 U08 P3.** ¿Qué guardas como evidencia?

- Nada, porque el banco ya tiene todos los registros de tus movimientos
- Solo el último estado de cuenta
- ✔ Capturas, fechas, montos y folios

*¡Correcto! Ayudan a tu reclamación.*

## Módulo 5

**M5 U01 P1.** ¿Qué indica la GAT real?

- Lo que te cobra el banco cada mes por manejo
- ✔ Lo que te paga descontando la inflación
- El saldo mínimo

*¡Correcto! Descuenta la inflación.*

**M5 U01 P2.** ¿Cómo cancelas una cuenta?

- ✔ Por escrito y con constancia
- Dejando de usarla para siempre
- Retirando todo el saldo en el cajero

*¡Correcto! Si solo la dejas, sigue cobrando.*

**M5 U01 P3.** Una cuenta cobra 150 al mes y no la usas. ¿Cuánto pagas al año?

- 150
- 1,500
- ✔ 1,800

*¡Correcto! 150 por 12 son 1,800.*

**M5 U02 P1.** ¿Hasta cuánto protege el IPAB?

- Todo lo que tengas en el banco
- ✔ 400,000 UDIS por persona y por banco
- 400,000 pesos

*¡Correcto! El límite está en UDIS.*

**M5 U02 P2.** ¿Qué protege el IPAB?

- ✔ Tus depósitos bancarios
- Tus fondos de inversión y acciones
- Tu AFORE

*¡Correcto! Solo depósitos.*

**M5 U02 P3.** Tienes 5 millones en un banco. ¿Qué conviene?

- Dejarlos juntos por comodidad, ya que el IPAB los cubre todos
- Pasar todo a efectivo en casa
- ✔ Repartirlos para quedar dentro del límite

*¡Correcto! Así todo queda protegido.*

**M5 U03 P1.** ¿Dónde conviene tu fondo de emergencia?

- En acciones, para que rinda más a largo plazo
- ✔ En una cuenta protegida o Cetes de corto plazo
- En un plazo fijo de cinco años

*¡Correcto! Disponible y seguro.*

**M5 U03 P2.** Tu gasto es 40,000 al mes. ¿Cuánto es un fondo de tres meses, sin deducible?

- ✔ 120,000
- 40,000
- 400,000

*¡Correcto! 40,000 por tres.*

**M5 U03 P3.** Usaste tu fondo. ¿Qué haces después?

- ✔ Lo repones antes que otros ahorros
- Lo dejas vacío hasta el próximo año
- Lo sustituyes con tu tarjeta de crédito

*¡Correcto! Es tu primera red.*

**M5 U04 P1.** ¿Qué son los Cetes?

- Acciones de empresas mexicanas grandes
- ✔ Deuda del gobierno federal
- Un seguro de ahorro

*¡Correcto! Le prestas al gobierno.*

**M5 U04 P2.** ¿Qué eliges si puedes necesitar el dinero cualquier día?

- ✔ BONDDIA
- Cetes a 364 días, que pagan más
- Un plazo fijo largo

*¡Correcto! Retiro diario.*

**M5 U04 P3.** Te llaman de «Cetesdirecto» con una tasa especial. ¿Qué haces?

- Aceptas si la tasa es mejor que la que ves en el sitio oficial
- Pides que te manden el enlace
- ✔ Cuelgas y entras solo al sitio oficial

*¡Correcto! No llaman para ofrecer tasas.*

**M5 U05 P1.** ¿Qué pago te libra de intereses?

- El pago mínimo
- ✔ El pago para no generar intereses
- Cualquier pago antes de fin de mes

*¡Correcto! Pagas lo del periodo sin intereses.*

**M5 U05 P2.** Tu hijo gasta con una tarjeta adicional. ¿De quién es la deuda?

- ✔ Tuya
- De tu hijo
- Del banco

*¡Correcto! La titular responde.*

**M5 U05 P3.** ¿Cuándo conviene comprar a meses sin intereses?

- Siempre que haya oferta
- Cuando el precio es mayor que el de contado
- ✔ Cuando el precio es igual al de contado y el pago cabe en tu presupuesto

*¡Correcto! Si no, se vuelve carga.*

**M5 U06 P1.** ¿Cuánto cuesta tu reporte especial una vez al año?

- ✔ Nada
- Lo que cobre el despacho
- Un mes de intereses

*¡Correcto! La ley lo hace sin costo.*

**M5 U06 P2.** Firmaste como aval y la otra persona no paga. ¿Qué pasa?

- Nada, no es tu crédito
- ✔ Te pueden cobrar y afectar tu historial
- El banco lo perdona

*¡Correcto! El aval responde.*

**M5 U06 P3.** Te ofrecen borrar tu Buró por una cuota. ¿Qué es?

- Un servicio útil
- Un trámite de CONDUSEF
- ✔ Un fraude

*¡Correcto! Nadie borra información correcta.*

**M5 U07 P1.** Diste tu nombre y teléfono como referencia para la tarjeta de un amigo. ¿Te pueden cobrar?

- Sí, la mitad
- Sí, si él no paga
- ✔ No, solo diste tus datos

*¡Correcto! La referencia no se obliga.*

**M5 U07 P2.** ¿Quién responde por todo el contrato como si hubiera pedido el crédito?

- ✔ El obligado solidario
- La referencia personal
- El vendedor

*¡Correcto! Por eso le pueden cobrar directo.*

**M5 U07 P3.** Un despacho te presiona para pagar una deuda de la que solo eres referencia. ¿Qué haces?

- Pagas para que dejen de llamar
- ✔ No pagas y te quejas en el REDECO
- Das los datos de tu amigo y los de su familia

*¡Correcto! No pueden cobrar a referencias.*

**M5 U08 P1.** ¿Con quién tramitas un préstamo a cuenta de tu pensión del IMSS?

- Con quien te llame por teléfono
- ✔ Con una financiera del listado oficial del IMSS
- Con cualquier gestor

*¡Correcto! Así tienes a quién reclamar.*

**M5 U08 P2.** Te piden 1,500 para «liberar» tu préstamo. ¿Qué haces?

- ✔ No pagas: es fraude
- Pagas la mitad
- Pagas para no perder el préstamo

*¡Correcto! Nadie serio cobra por adelantado.*

**M5 U08 P3.** Sacas un préstamo para tu sobrino y él deja de pagar. ¿Qué pasa?

- Lo paga él
- Se cancela
- ✔ Te lo siguen descontando de tu pensión

*¡Correcto! La deuda es tuya.*

**M5 U09 P1.** ¿Dónde verificas que una casa de empeño esté registrada?

- En sus anuncios
- ✔ En el registro de la PROFECO
- Con una vecina

*¡Correcto! Así tienes a quién reclamar.*

**M5 U09 P2.** ¿Qué pasa si no pagas ni refrendas a tiempo?

- Te esperan
- Te bajan el interés
- ✔ La casa vende tu prenda

*¡Correcto! Por eso anotas la fecha.*

**M5 U09 P3.** ¿De quién es la demasía?

- ✔ Tuya
- De la casa de empeño
- De la PROFECO

*¡Correcto! Es lo que sobra de la venta.*

## Módulo 6

**M6 U01 P1.** Una inversión gana 8% y la inflación es 5%. ¿Cuál es el rendimiento real aproximado?

- 13%
- ✔ 3%
- 8%, porque la inflación no cuenta

*¡Correcto! 8 menos 5.*

**M6 U01 P2.** ¿Qué inversión conviene para dinero que necesitas en tres meses?

- ✔ Una de bajo riesgo y corto plazo
- Un fondo de acciones que ganó mucho el año pasado
- Una a cinco años

*¡Correcto! El plazo manda.*

**M6 U01 P3.** ¿Qué es el riesgo?

- Lo que te cobra la institución
- El plazo mínimo de la inversión
- ✔ Cuánto puede bajar tu inversión

*¡Correcto! La posibilidad de perder.*

**M6 U02 P1.** ¿Qué es un PRLV?

- Una acción de una empresa del extranjero
- Un fondo de acciones
- ✔ Un pagaré bancario

*¡Correcto! Depósito a plazo.*

**M6 U02 P2.** ¿Qué haces si no entiendes una inversión?

- ✔ No la compras hasta entenderla
- La compras poco para probar
- Confías en quien la ofrece

*¡Correcto! Nunca compres lo que no entiendes.*

**M6 U02 P3.** ¿Por qué importa la comisión de un fondo?

- No importa si el fondo es bueno
- ✔ Se descuenta de tu rendimiento cada año
- Solo se paga al entrar

*¡Correcto! Reduce tu ganancia.*

**M6 U03 P1.** ¿Qué parte muestra lo que tienes hoy?

- ✔ La posición
- Los movimientos del mes
- La lista de comisiones cobradas

*¡Correcto! Tu foto del mes.*

**M6 U03 P2.** Tu fondo bajó 2% en un mes. ¿Qué haces?

- Lo vendes todo de inmediato para no perder más este año
- ✔ Revisas el rendimiento de doce meses
- Cambias de institución hoy mismo

*¡Correcto! Un mes no es un año.*

**M6 U03 P3.** ¿Qué guardas para tus impuestos?

- Solo el último estado
- Nada, lo tiene el SAT
- ✔ La constancia anual de retenciones

*¡Correcto! La necesitas para declarar.*

**M6 U04 P1.** ¿Qué preguntas a tu asesor antes de decidir?

- Cuántos clientes tiene y desde cuándo
- ✔ Cómo le pagan y cuánto cuesta en total
- Si ya lo compró él mismo

*¡Correcto! Revela conflictos.*

**M6 U04 P2.** Un asesor independiente, ¿dónde lo verificas?

- En sus redes sociales y en las opiniones de otros clientes
- ✔ En el registro de la CNBV
- Con sus otros clientes

*¡Correcto! El registro oficial.*

**M6 U04 P3.** ¿Quién decide sobre tu dinero?

- Tu asesor, que sabe más del tema
- Tu familia
- ✔ Tú

*¡Correcto! El asesor recomienda, tú decides.*

**M6 U05 P1.** Te ofrecen 5% mensual garantizado. ¿Qué es?

- Una buena oportunidad si la persona es conocida
- ✔ Una señal de fraude
- Normal en divisas

*¡Correcto! Nada legítimo garantiza eso.*

**M6 U05 P2.** Te pagan por invitar a más personas. ¿Qué es?

- ✔ Una pirámide
- Un programa de referidos legítimo que conviene
- Un bono de bienvenida

*¡Correcto! Pagan con el dinero de nuevos.*

**M6 U05 P3.** Tu sobrino quiere manejar tus ahorros en su cuenta. ¿Qué haces?

- Aceptas si firma un pagaré
- Aceptas solo una parte
- ✔ No: tu dinero va a una cuenta a tu nombre

*¡Correcto! Sin protección en su cuenta.*

**M6 U06 P1.** Circula que van a quitar las pensiones. ¿Qué haces?

- Retiras todo lo que puedas
- ✔ Lo confirmas en el sitio oficial antes de actuar
- Lo reenvías a todos

*¡Correcto! Confirma antes.*

**M6 U06 P2.** Tus Cetes son para una meta de dos años y todos están vendiendo. ¿Qué haces?

- Vendes antes que los demás
- Pasas todo a efectivo en casa
- ✔ Revisas tu meta y tu plazo; si no cambiaron, sigues

*¡Correcto! El plan manda, no la manada.*

**M6 U06 P3.** ¿Quién fija la tasa de interés de referencia en México?

- ✔ El Banco de México
- Tu banco
- La CONDUSEF

*¡Correcto! Para cuidar la inflación.*

## Módulo 7

**M7 U01 P1.** Empezaste a cotizar en 1990. ¿Qué ley te puede aplicar?

- ✔ La Ley 73
- La Ley 97, que aplica a todos por igual
- Ninguna, por la fecha

*¡Correcto! Cotizaste antes de julio de 1997.*

**M7 U01 P2.** ¿Dónde consultas tus semanas cotizadas?

- En tu banco, con el número de tu cuenta de nómina
- ✔ En el IMSS con tu CURP y NSS
- En el SAT, con tu RFC

*¡Correcto! Con tu CURP y NSS.*

**M7 U01 P3.** Te dedicaste a la casa y trabajaste antes. ¿Qué haces?

- Nada: no tienes pensión
- Esperas a que te llamen
- ✔ Consultas tus semanas y tu AFORE

*¡Correcto! Puedes tener derechos.*

**M7 U02 P1.** ¿Qué necesitas para localizar tu AFORE?

- ✔ Tu CURP
- Una cita con un gestor
- El número de tu última empresa

*¡Correcto! Con tu CURP.*

**M7 U02 P2.** Te ofrecen un regalo por cambiarte de AFORE. ¿Qué haces?

- Aceptas: el regalo no tiene costo
- ✔ Comparas rendimientos en la CONSAR antes
- Te cambias y, si no te gusta, regresas a tu AFORE anterior

*¡Correcto! El regalo no mejora tu retiro.*

**M7 U02 P3.** ¿Puedes ahorrar en tu AFORE si ya no trabajas formalmente?

- No, solo con patrón
- Solo si tienes más de 60 años
- ✔ Sí, con aportaciones voluntarias

*¡Correcto! Cualquiera puede aportar.*

**M7 U03 P1.** ¿Qué haces antes de pagar la Modalidad 40?

- Pagas un gestor para que lo revise
- ✔ Confirmas requisitos y pides una estimación en el IMSS
- Pagas un año para probar

*¡Correcto! Decide con números.*

**M7 U03 P2.** Registras 20,000 de salario en 2026. ¿Cuánto es la cuota aproximada?

- 2,000
- 20,000
- ✔ 2,888

*¡Correcto! 14.438% de 20,000.*

**M7 U03 P3.** ¿Quién puede cobrarte por inscribirte?

- ✔ Nadie: el trámite no tiene costo
- Un gestor autorizado por el IMSS para agilizar la inscripción
- Tu AFORE, con una comisión

*¡Correcto! No tiene costo.*

**M7 U04 P1.** ¿Cuánto da la Pensión de Adultos Mayores en 2026?

- 3,100 cada mes, igual que Mujeres Bienestar
- ✔ 6,400 cada dos meses
- 6,400 cada mes

*¡Correcto! Bimestral.*

**M7 U04 P2.** Te piden dinero para aumentar tu pensión del Bienestar. ¿Qué es?

- ✔ Un fraude
- Un trámite especial para adultos mayores
- Una cuota voluntaria

*¡Correcto! No tiene costo.*

**M7 U04 P3.** La pensión de tu esposo es de 20,000 al mes. ¿Cuánto sería, en general, tu pensión de viudez?

- 20,000
- 10,000
- ✔ 18,000

*¡Correcto! 90% de 20,000.*

**M7 U05 P1.** ¿Qué documento resume los años de servicio en el gobierno?

- El estado de cuenta del banco
- ✔ La hoja única de servicios
- La constancia del SAT

*¡Correcto! Se pide en la dependencia.*

**M7 U05 P2.** En el régimen del décimo transitorio, ¿con qué requisitos se jubila una mujer en 2026?

- 60 años y 25 años de servicio
- 65 años y 1,000 semanas
- ✔ 56 años y 28 años de servicio

*¡Correcto! Requisitos de 2026 y 2027.*

**M7 U05 P3.** Tu esposo recibía 20,000 de pensión del ISSSTE en el régimen anterior y no hay hijos con derecho. ¿Cuánto sería, en general, tu pensión de viudez?

- ✔ 20,000
- 18,000
- 10,000

*¡Correcto! 100% de su pensión.*

**M7 U06 P1.** Gastarás 40,000 y recibirás 25,000 de pensiones. ¿Cuál es la diferencia al mes?

- 65,000
- 25,000
- ✔ 15,000

*¡Correcto! 40,000 menos 25,000.*

**M7 U06 P2.** ¿Qué gasto suele subir en el retiro?

- Transporte al trabajo
- ✔ Salud y medicamentos
- Colegiaturas de los hijos

*¡Correcto! La salud aumenta.*

**M7 U06 P3.** ¿Qué haces antes de prestar a tus hijos?

- ✔ Calculas tu retiro
- Les prestas lo que pidan
- Les pides un pagaré y listo

*¡Correcto! Primero tu seguridad.*

## Módulo 8

**M8 U01 P1.** ¿Qué es el coaseguro?

- ✔ El porcentaje que pagas después del deducible
- Lo máximo que paga la aseguradora por evento
- Una cuota mensual extra que se suma a tu prima anual del seguro

*¡Correcto! Tu parte después del deducible.*

**M8 U01 P2.** Cirugía de 100,000, deducible 10,000 y coaseguro 10%. ¿Cuánto pagas tú?

- 10,000
- ✔ 19,000
- 20,000

*¡Correcto! 10,000 más 10% de 90,000.*

**M8 U01 P3.** ¿Qué pides antes de una cirugía programada?

- Un descuento al hospital
- ✔ La programación de cirugía
- Un préstamo al banco por si acaso

*¡Correcto! Confirma cobertura.*

**M8 U02 P1.** ¿Qué pasa si cancelas y luego contratas otro seguro?

- Todo sigue igual en la nueva aseguradora
- ✔ Te pueden excluir preexistencias
- Te bajan la prima

*¡Correcto! Pierdes antigüedad y coberturas.*

**M8 U02 P2.** ¿Qué opción baja tu prima?

- ✔ Subir tu deducible
- Agregar coberturas nuevas
- Pagar mensualmente en lugar de anual

*¡Correcto! Pagas más en un evento, menos de prima.*

**M8 U02 P3.** ¿Cuándo cancelas tu póliza actual al cambiarte?

- En cuanto firmas la solicitud nueva
- Un mes antes para ahorrar
- ✔ Cuando la nueva ya está vigente

*¡Correcto! Nunca te quedes sin cobertura.*

**M8 U03 P1.** ¿Cómo comparas dos seguros?

- ✔ Con el mismo perfil de coberturas
- Solo por el precio anual
- Por la marca más conocida

*¡Correcto! Así comparas lo mismo.*

**M8 U03 P2.** ¿Dónde están las exclusiones?

- En la publicidad y los folletos que te da el agente
- ✔ En las condiciones generales
- En el recibo de pago

*¡Correcto! Ahí están las reglas.*

**M8 U03 P3.** ¿Qué verificas de tu agente?

- ✔ Su cédula en la CNSF
- Cuántos años lleva en la ciudad
- Si tiene redes sociales

*¡Correcto! Debe estar autorizado.*

**M8 U04 P1.** ¿Para qué sirve un seguro de vida?

- Para ahorrar sin riesgo
- Para pagar tus gastos médicos
- ✔ Para proteger a quien depende de ti

*¡Correcto! Protege a tus dependientes.*

**M8 U04 P2.** ¿Qué pides antes de cancelar un seguro con ahorro?

- ✔ El valor de rescate por escrito
- Un regalo por renovar o un descuento en la siguiente prima
- Nada, solo lo cancelas

*¡Correcto! Para no perder aportaciones.*

**M8 U04 P3.** ¿Cuánto cuesta actualizar beneficiarios?

- Una comisión fija
- ✔ Nada
- Depende de la suma asegurada

*¡Correcto! No tiene costo.*

**M8 U05 P1.** ¿Qué cobertura del auto es la más importante?

- Cristales y rines, que son lo que más se daña
- Asistencia vial
- ✔ Responsabilidad civil

*¡Correcto! Cubre daños a otros.*

**M8 U05 P2.** Chocas y te piden arreglarse sin el seguro. ¿Qué haces?

- Aceptas para ahorrar tiempo
- ✔ Llamas a la aseguradora y esperas al ajustador
- Das tus datos y te vas

*¡Correcto! El ajustador protege tus derechos.*

**M8 U05 P3.** ¿Qué revisas al renovar el seguro de la casa?

- ✔ El costo de reconstruir y los riesgos de tu zona
- Solo el precio
- El color de la póliza

*¡Correcto! Así te cubres bien.*

**M8 U06 P1.** ¿Qué haces antes de limpiar después de una inundación?

- Tiras todo lo mojado para evitar hongos
- Llamas al primer constructor que pase
- ✔ Tomas fotos y video de los daños

*¡Correcto! Las fotos sostienen tu reclamo.*

**M8 U06 P2.** Te cobran 500 pesos por inscribirte en un apoyo de gobierno. ¿Qué es?

- ✔ Un fraude: los apoyos no tienen costo
- Un trámite normal
- Una cuota de la aseguradora

*¡Correcto! Nadie cobra por registrarte.*

**M8 U06 P3.** La aseguradora no te responde después de entregar tus documentos. ¿Qué haces?

- Esperas sin plazo
- ✔ Reclamas sin costo en la CONDUSEF
- Contratas a un gestor que cobra por adelantado

*¡Correcto! La CONDUSEF atiende sin costo.*

**M8 U07 P1.** ¿Cuánto cuesta en 2026 el seguro familiar del IMSS para una persona de 55 años?

- 9,300
- ✔ 14,250
- 21,300

*¡Correcto! De 50 a 59 años.*

**M8 U07 P2.** ¿Qué modalidad suma semanas para tu pensión?

- ✔ La Modalidad 10
- El seguro familiar
- Ninguna de las dos

*¡Correcto! Es régimen obligatorio.*

**M8 U07 P3.** ¿Qué preguntas antes de pagar?

- El color de la credencial
- ✔ Qué cubre y desde cuándo
- Nada, todo está cubierto

*¡Correcto! Hay periodos de espera.*

## Módulo 9

**M9 U01 P1.** Recibes rentas de un departamento. ¿Qué pasa?

- Nunca declaras si eres pensionada
- ✔ Probablemente debes declarar
- Solo declaras si el SAT te llama

*¡Correcto! Las rentas suelen obligarte.*

**M9 U01 P2.** ¿Dónde pides ayuda sin costo si tienes un problema con el SAT?

- ✔ PRODECON
- Con un gestor que cobra
- En el banco

*¡Correcto! No tiene costo.*

**M9 U01 P3.** Te llega un enlace del «SAT» para una devolución. ¿Qué haces?

- Lo abres rápido para no perderla
- Lo reenvías a tu contadora
- ✔ Entras tú a sat.gob.mx

*¡Correcto! El SAT no manda enlaces así.*

**M9 U02 P1.** ¿Qué es una retención?

- Una comisión que cobra el banco por administrar
- ✔ Impuesto pagado por adelantado
- Una multa del SAT

*¡Correcto! Se resta en tu declaración.*

**M9 U02 P2.** Tienes 200,000 en un pagaré todo 2026. ¿Cuánto te retienen aproximadamente?

- ✔ 1,800
- 900
- 18,000

*¡Correcto! 0.90% de 200,000.*

**M9 U02 P3.** Tu pensión es de 30,000 al mes. ¿Paga ISR?

- Sí, toda la pensión paga impuesto desde el primer peso
- Sí, la mitad
- ✔ No, está dentro del límite exento

*¡Correcto! Está por debajo de 15 UMA.*

**M9 U03 P1.** ¿Qué necesitas para deducir?

- El ticket de la farmacia
- Una nota firmada por el médico
- ✔ Factura a tu nombre y pago no en efectivo

*¡Correcto! Requisitos del SAT.*

**M9 U03 P2.** ¿En qué mes se presenta la declaración anual de personas físicas?

- ✔ Abril
- Diciembre
- Enero

*¡Correcto! En abril.*

**M9 U03 P3.** ¿Qué haces con un saldo a favor?

- Lo dejas para el siguiente año
- ✔ Lo pides en devolución
- Nada, se pierde

*¡Correcto! Es tu dinero.*

## Módulo 10

**M10 U01 P1.** ¿Ante quién se hace un testamento?

- Ante un abogado cualquiera
- Ante tu banco
- ✔ Ante notario

*¡Correcto! Así es válido.*

**M10 U01 P2.** ¿Qué testamento vale si hiciste varios?

- ✔ El último
- El primero
- El más largo

*¡Correcto! El último es el que vale.*

**M10 U01 P3.** ¿Cuándo hay descuentos en muchas notarías?

- En diciembre
- ✔ En septiembre
- Nunca

*¡Correcto! El Mes del Testamento.*

**M10 U02 P1.** ¿Dónde revisas tus beneficiarios de la AFORE?

- ✔ En tu AFORE o AforeMóvil
- En el SAT, con tu RFC y tu contraseña
- En tu banco

*¡Correcto! Ahí se actualizan.*

**M10 U02 P2.** ¿Los beneficiarios reemplazan al testamento?

- Sí, siempre
- Solo en el caso de las cuentas
- ✔ No del todo: se complementan

*¡Correcto! Hay límites.*

**M10 U02 P3.** ¿Cuándo revisas a tus beneficiarios?

- ✔ Cuando cambia tu familia y cada año
- Solo al abrir la cuenta
- Nunca

*¡Correcto! Así están al día.*

**M10 U03 P1.** ¿Qué poder te da más control?

- ✔ El especial
- El general para todo
- El poder para vender y regalar bienes

*¡Correcto! Limita lo que pueden hacer.*

**M10 U03 P2.** Te presionan para firmar un poder amplio rápido. ¿Qué haces?

- Firmas para evitar problemas
- Firmas solo si es familia
- ✔ Te detienes y consultas

*¡Correcto! La prisa es una alerta.*

**M10 U03 P3.** ¿Qué documento dice qué tratamientos quieres?

- El testamento que haces ante notario
- ✔ La voluntad anticipada
- El poder general

*¡Correcto! Es sobre tu salud.*

**M10 U04 P1.** ¿Qué implica ser aval?

- ✔ Pagar la deuda si tu hijo no paga
- Solo recomendar a tu hijo ante el banco
- Recibir una comisión

*¡Correcto! La deuda pasa a ti.*

**M10 U04 P2.** ¿Qué haces antes de prestar dinero a un hijo?

- Prestas sin preguntar
- ✔ Calculas tu retiro
- Le pides que no se lo diga a nadie

*¡Correcto! Primero tu seguridad.*

**M10 U04 P3.** ¿Cómo haces un préstamo familiar?

- De palabra, por confianza
- Sin fechas, cuando pueda
- ✔ Por escrito, con monto y fechas

*¡Correcto! Evita conflictos.*

**M10 U05 P1.** ¿Qué puede esperar después de una pérdida?

- Tramitar la pensión de viudez
- ✔ Vender la casa
- Asegurar el gasto del mes

*¡Correcto! Las decisiones grandes esperan.*

**M10 U05 P2.** Te presionan para decidir rápido. ¿Qué significa?

- Que es una buena oportunidad
- Que eres importante para el asesor
- ✔ Que conviene esperar

*¡Correcto! La presión es una alerta.*

**M10 U05 P3.** ¿Qué haces en una separación si no tienes cuenta propia?

- ✔ Abres una a tu nombre
- Usas la de tu expareja
- Guardas todo en efectivo

*¡Correcto! Es tu respaldo.*

**M10 U06 P1.** Terminaste de pagar tu casa. ¿Qué te falta?

- Nada, ya es tuya
- ✔ Inscribir la liberación de hipoteca
- Pagar otro crédito

*¡Correcto! Sin ella sigue gravada.*

**M10 U06 P2.** Te ofrecen un terreno ejidal muy barato. ¿Qué haces antes de pagar?

- ✔ Pides que una notaría lo revise
- Pagas para apartarlo
- Firmas un recibo con el vendedor

*¡Correcto! Evitas fraudes.*

**M10 U06 P3.** Nunca usaste tu crédito de vivienda. ¿Qué pasa con tu subcuenta?

- Se pierde al retirarte
- Se queda en el gobierno
- ✔ Se te entrega o se suma a tu pensión, según tu régimen

*¡Correcto! No se pierde.*

**M10 U07 P1.** ¿Qué pasa si una persona fallece sin testamento?

- ✔ La ley decide quién hereda
- El gobierno se queda con todo
- Nadie hereda

*¡Correcto! Hay un orden legal.*

**M10 U07 P2.** ¿Con qué se heredan los derechos ejidales?

- Con un recibo de predial
- Con una carta a mano
- ✔ Con la lista de sucesión

*¡Correcto! Se registra en el RAN.*

**M10 U07 P3.** Toda la familia está de acuerdo. ¿Dónde puede hacerse el trámite?

- En el banco
- ✔ Ante notario
- En el SAT

*¡Correcto! Más rápido que un juicio.*

**M10 U08 P1.** ¿Cuánto ISR paga tu hija por heredar tu casa?

- ✔ Nada
- 30%
- 16%

*¡Correcto! Está exento.*

**M10 U08 P2.** ¿Qué es el usufructo vitalicio?

- Un seguro de vida
- ✔ Tu derecho a vivir en la casa aunque sea de otra persona
- Un crédito hipotecario que te da el banco para comprar una casa nueva

*¡Correcto! Vives ahí de por vida.*

**M10 U08 P3.** ¿Qué riesgo tiene donar tu casa en vida?

- Ninguno
- Pagar ISR sobre el valor total de la casa
- ✔ Que ya no sea tuya

*¡Correcto! Pasa a ser de otra persona.*

**M10 U09 P1.** En sociedad conyugal, ¿se puede vender la casa sin tu firma?

- ✔ No, se necesita tu firma
- Sí, si está a nombre de él
- Sí, siempre

*¡Correcto! Lo compraron juntos.*

**M10 U09 P2.** ¿Cuál es una señal de violencia económica?

- Ver juntos el estado de cuenta
- Ahorrar para una meta en común
- ✔ Que no te dejen ver las cuentas

*¡Correcto! Es control del dinero.*

**M10 U09 P3.** Te piden firmar un poder notarial. ¿Qué haces?

- Firmas rápido
- ✔ Preguntas qué tan amplio es y si puedes limitarlo
- Firmas y guardas la copia

*¡Correcto! Un poder amplio permite vender por ti.*

**M10 U10 P1.** ¿Quién puede cambiar una pensión fijada por un juez?

- Quien paga
- ✔ Un juez
- Quien la recibe

*¡Correcto! Nadie la cambia por su cuenta.*

**M10 U10 P2.** ¿Qué pasa con lo que no se pagó?

- ✔ Se acumula como deuda
- Se olvida
- Se divide a la mitad

*¡Correcto! Se puede reclamar.*

**M10 U10 P3.** ¿Qué puede ordenar el juez para que el pago llegue?

- Que pague en efectivo
- Que pague cuando pueda
- ✔ Que se descuente de su nómina

*¡Correcto! Así llega completa.*

## Módulo 11

**M11 U01 P1.** Te dicen «la oferta solo es hoy». ¿Qué haces?

- ✔ Esperas y comparas
- Firmas para no perderla
- Pides un descuento extra

*¡Correcto! La prisa es del vendedor.*

**M11 U01 P2.** ¿A quién pides segunda opinión?

- Al vendedor
- ✔ A alguien sin interés en la venta
- A quien te invitó a la presentación

*¡Correcto! Sin conflicto de interés.*

**M11 U01 P3.** Firmaste y te arrepientes al día siguiente. ¿Qué haces?

- Nada, ya firmaste
- Dejas de pagar para que te cancelen el contrato
- ✔ Revisas el plazo de cancelación

*¡Correcto! Muchos contratos lo permiten.*

**M11 U02 P1.** Un familiar se queda con tu tarjeta y decide tus gastos. ¿Qué es?

- Ayuda normal
- ✔ Control económico
- Una forma de cuidarte

*¡Correcto! Deciden por ti.*

**M11 U02 P2.** ¿Qué haces primero?

- ✔ Recuperas el acceso a tus cuentas
- Esperas a que cambie
- Le das también tu contraseña

*¡Correcto! Tu dinero es tuyo.*

**M11 U02 P3.** Te presionan para prestar dinero. ¿Qué respondes?

- Que sí, para evitar problemas
- Que no hablarás más del tema
- ✔ Que lo pensarás 72 horas

*¡Correcto! La presión no decide.*

**M11 U03 P1.** ¿Qué incluye tu plan de una página?

- Tus contraseñas, para tenerlas juntas
- ✔ Un resumen de mapa, seguridad, ahorro, retiro, salud y familia
- Solo tus inversiones, que son lo más importante del plan

*¡Correcto! Son sus seis partes.*

**M11 U03 P2.** ¿Qué compartes con tu persona de confianza?

- ✔ Una copia sin números ni contraseñas
- El plan con tus NIP
- Nada, nunca

*¡Correcto! Sin datos sensibles.*

**M11 U03 P3.** ¿Cuándo actualizas tu plan?

- Solo si pierdes dinero
- Cada cinco años
- ✔ Cada año y cuando cambia tu vida

*¡Correcto! Así sigue al día.*
