# Tu Talento, Tu Marca, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 4.5.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_TALENTO_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Talento, Tu Marca, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 4.5, el tema Boost, Level Up (block_xp) y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### En Moodle 4.5: dónde está cada cosa

El sitio usa **Moodle 4.5**. Donde estas instrucciones nombran un menú, búscalo así:

| Para | En Moodle 4.5 |
|---|---|
| Editar el curso | Interruptor **Modo de edición**, arriba a la derecha |
| Configuración, participantes, insignias, banco de preguntas, banco de contenido, finalización | Menú del curso (pestañas bajo el título): *Configuración*, *Participantes* y *Más* > *Banco de preguntas*, *Banco de contenido*, *Insignias*, *Finalización del curso* |
| Métodos de inscripción | *Participantes* > selector de arriba > *Métodos de inscripción* |
| Importar capítulos de un libro | Dentro del libro, menú de acciones (⋮ o *Más*) > *Importar capítulo* |
| Importar entradas del glosario | Dentro del glosario, selector o menú de acciones > *Importar entradas* |
| Importar preguntas de una encuesta (Retroalimentación) | Dentro de la actividad, pestaña *Preguntas* > menú > *Importar preguntas* |
| Ver como estudiante | Menú de tu usuario (arriba a la derecha) > *Cambiar rol a…* > *Estudiante* |
| Finalización de una actividad | En su configuración, sección *Condiciones de finalización* |

**Para ahorrar horas** (el curso tiene muchas piezas):

1. **Finalización predeterminada antes de crear los libros:** *Más > Finalización del curso* > selector > *Finalización de actividad predeterminada*. Para **Libro**: "Ver". Para **Cuestionario**: "Recibir una calificación aprobatoria". Así cada libro nuevo ya nace con su finalización.
2. **Edición masiva:** en modo de edición, *Edición masiva* (arriba a la derecha) permite mover, mostrar u ocultar varias actividades a la vez.
3. **Trabaja por etapas y reporta en cada una:** primero la sección General (Bienvenida, foro, «Mi meta», encuesta de inicio, «Tu punto de partida») y la Parte 1 completa. Detente, toma capturas y reporta a la persona antes de seguir con las demás partes.
4. Si una opción de estas instrucciones no existe con ese nombre en 4.5, usa la equivalente y anótala en el reporte.

**Mosaicos (Tiles) en 4.5:** si *Usar submosaicos para las actividades* o *Mostrar progreso* no aparecen en la configuración del curso, pueden estar desactivados para todo el sitio; no cambies la configuración del sitio: repórtalo.

**Level Up en 4.5:** las versiones nuevas agrupan las reglas en *Level Up > Puntos*. Si existe la regla de **finalización de actividad**, úsala con 25 puntos en lugar del evento. La *Clasificación* puede llamarse *Tabla de posiciones*.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `DT-TALENTO-MX-ES`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Talento, Tu Marca, Tu Futuro |
| Nombre corto | DT-TALENTO-MX-ES |
| Visibilidad | **Mostrar** |
| Formato | **Mosaicos** (Tiles). 13 secciones |
| Seguimiento de finalización | Sí |

**Formato Mosaicos:**
- *Mostrar progreso en los mosaicos*: **como porcentaje**.
- **Usar submosaicos para las actividades: Sí** (cada lección se ve como un mosaico dentro de su parte).
- La sección General (Bienvenida) va arriba de los mosaicos.

**Íconos de los mosaicos** (se eligen en modo de edición, en cada mosaico; si un nombre no aparece en el selector, usa el más parecido):

| Mosaico | Ícono | Qué se ve |
|---|---|---|
| Tu dinero real | `money` | billetes |
| Tu carrera como negocio | `briefcase` | portafolio |
| Contratos y regalías | `handshake-o` | apretón de manos |
| El sistema financiero | `university` | edificio de banco |
| Compara y elige | `balance-scale` | balanza |
| El crédito es deuda | `credit-card` | tarjeta |
| Buró y Círculo de Crédito | `bar-chart` | gráfica de barras |
| Sal de deudas | `unlock` | candado abierto |
| Que no te engañen | `exclamation-triangle` | señal de alerta |
| Protección y prevención | `shield` | escudo |
| Tu futuro | `hourglass-half` | reloj de arena |
| Materiales de apoyo | `book` | libro |
| Cierre y constancia | `flag-checkered` | bandera de meta |
| Programas y apoyos (extra) | `life-ring` | salvavidas |

- Oculta el bloque *Tabla de posiciones* o *Ranking* de Level Up si aparece en la columna derecha.

**Inscripción:** *Métodos de inscripción* > activa **Autoinscripción** con la **clave de inscripción** que te dé la persona (si no la tienes, deja "[por definir]" y repórtalo). Desactiva el acceso de invitados.

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Libro «Bienvenida», foro "Dudas y comentarios", encuesta de inicio, «Tu punto de partida» y «Mi meta» |
| 1 | Tu dinero real | Contenido de `1_libros/M1_resumen.html` |
| 2 | Tu carrera como negocio | `M2_resumen.html` |
| 3 | Contratos y regalías | `M3_resumen.html` |
| 4 | El sistema financiero | `M4_resumen.html` |
| 5 | Compara y elige | `M5_resumen.html` |
| 6 | El crédito es deuda | `M6_resumen.html` |
| 7 | Buró y Círculo de Crédito | `M7_resumen.html` |
| 8 | Sal de deudas | `M8_resumen.html` |
| 9 | Que no te engañen | `M9_resumen.html` |
| 10 | Protección y prevención | `M10_resumen.html` |
| 11 | Tu futuro | `M11_resumen.html` |
| 12 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 13 | Cierre y constancia | "Lo que lograste, tu constancia y hasta pronto." |

Descripción del foro "Dudas y comentarios": "No compartas RFC, CURP, números de cuenta, contraseñas ni montos reales."

#### Bienvenida y despedida (libros con diseño)

Son lo primero y lo último que ve la persona: no los omitas.

1. **Sección General, arriba de todo:** crea el libro `Bienvenida` (formato de capítulo "Nada", navegación "Texto") e importa `1_libros/Bienvenida_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Deben quedar 4 capítulos: Te damos la bienvenida, Cómo funciona el curso, Guía de contacto y comunidad, Antes de empezar. Finalización: "Ver".
2. Debajo, el foro **"Dudas y comentarios"** (foro general). **No crees un foro de presentaciones:** pedir que la gente se presente invita a compartir datos personales.
   Después, la tarea **"Mi meta"**: tipo *Tarea*, entrega "Texto en línea" (límite de 60 palabras), **sin calificación**, sin fecha límite, sin avisos a otros participantes; las entregas solo las ven la persona y el equipo del curso. Instrucciones: "En una frase: qué esperas del programa y qué quieres lograr. No escribas datos personales ni montos reales. Al final del curso la vuelves a abrir." Permite editar la entrega en cualquier momento. Finalización: "Enviar".
3. Debajo, la **Encuesta de inicio** (sección 8) y el cuestionario **«Tu punto de partida»**: importa `4_preguntas/diagnostica.gift.txt` (crea su propia categoría «Diagnóstica»), todas las preguntas, calificación sobre 0 (no cuenta para la calificación), **un intento**, tiempo máximo 10 minutos, revisión con respuesta correcta al terminar.
4. **Restringir acceso** de la primera lección de la Parte 1: el libro `Bienvenida` debe estar visto.
5. **Sección 13, arriba de todo:** crea el libro `Cierre y despedida` con la misma configuración e importa `1_libros/Cierre_libro_Moodle.zip` (4 capítulos: Lo que lograste, Tu plan sigue, Encuesta final y constancia, Hasta pronto). Restringir acceso: la autoevaluación de la última parte debe estar completa. Debajo van la encuesta final y la constancia.
6. **Guía para imprimir o compartir:** `7_guias/Guia_de_contacto_y_comunidad.html`. Ábrela en el navegador > Imprimir > Guardar como PDF, y compártela en la sesión presencial o por WhatsApp.

### 3. Lecciones: un libro por lección

La estructura completa (nombres, orden, archivos y minutos) está en `estructura_moodle.json`. En cada sección, por cada lección y en orden:

1. Crea un **Libro** con el nombre de la lección **tal cual** (la pregunta, sin claves como «M1 U01»). Formato de capítulo "Nada"; estilo de navegación "Texto".
2. Menú del libro > **Importar capítulo** > el zip de la lección (`1_libros/MN/NN_MN_UYY.zip`), tipo "Cada archivo HTML representa un capítulo". Deben quedar 4 capítulos: Empieza, Lo esencial, Profundiza, Practica.
3. **Finalización:** "Ver".
4. **Restringir acceso:** la lección anterior debe estar completa (la primera de cada parte, sin restricción; la primera de la parte 2 en adelante pide la última de la parte anterior). Muestra la lección bloqueada en gris, no oculta.

| Parte | Lecciones | Carpeta |
|---|---|---|
| Tu dinero real | 7 | `1_libros/M1/` |
| Tu carrera como negocio | 5 | `1_libros/M2/` |
| Contratos y regalías | 6 | `1_libros/M3/` |
| El sistema financiero | 5 | `1_libros/M4/` |
| Compara y elige | 8 | `1_libros/M5/` |
| El crédito es deuda | 8 | `1_libros/M6/` |
| Buró y Círculo de Crédito | 10 | `1_libros/M7/` |
| Sal de deudas | 6 | `1_libros/M8/` |
| Que no te engañen | 10 | `1_libros/M9/` |
| Protección y prevención | 8 | `1_libros/M10/` |
| Tu futuro | 9 | `1_libros/M11/` |

### 4. Libro de apoyo

En la sección 12, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos).

Debajo, crea el libro **`Para ir a fondo`** con la misma configuración e importa `1_libros/Fondo_libro_Moodle.zip` (12 capítulos: «Cómo ir a fondo» y uno por parte). Descripción: "Opcional. Para quien quiere leer las fuentes oficiales, las reglas y los documentos de cada tema." **Finalización: ninguna** (es opcional y no cuenta para terminar el curso).

En la misma sección 12, agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con el archivo de `10_herramientas/`. Mostrar: "Forzar descarga". Descripción: "Presupuesto, lista de deudas, fondo de emergencia y meta con interés compuesto; y para tu negocio: costo y precio, punto de equilibrio y flujo de 8 semanas; además: tus ingresos de 12 meses y tu fondo de sequía, tus bienes y quién los recibe. Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver".

### 5. Glosario

En la sección 12, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_ttmf.gift.txt`. Se crean *Tu Talento v1.0/M1* a *M11*, con 246 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Talento v1.0/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 | M10 | M11 |
|---|---|---|---|---|---|---|---|---|---|---|
| 21 | 15 | 18 | 15 | 24 | 24 | 30 | 18 | 30 | 24 | 27 |

### 7. Práctica dentro de cada lección (82 H5P)

La práctica **no** va como actividad aparte en la sección: va incrustada en el capítulo «Practica» de su libro.

1. *Banco de contenido* del curso > **Subir** los 82 archivos de `2_h5p/MN/` (`MN_UYY_practica.h5p`).
2. Abre el capítulo «Practica» de cada libro en modo edición. Verás un recuadro rosa con el texto `[[H5P MN_UYY_practica.h5p]]`.
3. Borra **todo el recuadro** y en su lugar inserta el H5P con el botón **Insertar H5P** del editor, eligiendo ese archivo del banco de contenido.
4. Guarda y comprueba con *Cambiar rol a > Estudiante* que se vean las situaciones y preguntas, una por pantalla.

**Nota:** la práctica incrustada no registra calificación. El avance de cada lección se marca al verla, y la calificación del módulo sale de la autoevaluación.

**Orden final de cada sección:** las lecciones en orden y al final la autoevaluación (restringida a completar la última lección de la parte).

### 8. Encuestas del programa

En `8_encuestas/` están las encuestas y su documento `encuestas.md`. Usa el módulo **Retroalimentación** (Feedback), modo **anónimo**, y en cada una *Plantillas > Importar preguntas* con su XML (si la importación falla, créalas a mano con `encuestas.md`):

| Actividad | Sección | Archivo | Finalización |
|---|---|---|---|
| `Encuesta de inicio` | General | `encuesta_inicio.xml` | Enviar |
| `Encuesta final` | 13 | `encuesta_final.xml` | Enviar; es requisito de la constancia |
| `Seguimiento a 30 días` | 13 | `encuesta_seguimiento.xml` | Enviar |
| `Seguimiento a 90 días` | 13 | `encuesta_seguimiento.xml` | Enviar |

Restringe los seguimientos por fecha: 30 y 90 días después de la fecha de fin de la cohorte ("[por definir]"). La encuesta final es la evidencia de resultados del programa: no la omitas.

### 9. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`; cada nombre lleva el curso para que sea único en la plataforma), 4 (finalización con las 11 autoevaluaciones) y 5 (constancia con la plantilla estándar y los datos de `6_constancia/constancia.md`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### Sección extra: Programas y apoyos

Esta sección va **aparte**: nada del curso depende de ella.

1. Agrega una sección **al final** del curso llamada `Programas y apoyos` (descripción: "Programas de gobierno y servicios públicos que pueden servirte. Información revisada; confírmala en el sitio oficial."). Elige un ícono de «ayuda» para su mosaico.
2. Crea el libro `Programas y apoyos` con la misma configuración e importa `1_libros/Programas_libro_Moodle.zip` (9 capítulos).
3. **Finalización: ninguna.** No lo incluyas en la finalización del curso ni en las restricciones de otras actividades, y no le des puntos.
4. **Para quitarla:** oculta la sección (ojo > Ocultar) o bórrala. El resto del curso sigue igual.
5. Si llega un paquete nuevo de este libro, reemplaza solo este libro.

### 10. Revisión final (con rol de estudiante)

- La portada muestra un mosaico por parte con su porcentaje; dentro de cada parte, un submosaico por lección sin claves técnicas.
- La primera lección: capítulos Empieza, Lo esencial, Profundiza y Practica; «Cuidado con estos errores» al final de Lo esencial; la práctica incrustada funciona.
- La segunda lección aparece bloqueada hasta ver la primera.
- No hay ranking ni tabla de posiciones visible.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 11. Reporte para la persona

Enlace del curso; libros por parte; H5P incrustadas; preguntas por autoevaluación; encuestas creadas; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de la portada en mosaicos, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **visible**, con inscripción por clave. Para la ficha del catálogo usa `tarjeta_catalogo.md`.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 4.5 con Level Up (block_xp) y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada parte

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro por lección (con la práctica incrustada) | 82 | Ver |
| Cuestionario "Autoevaluación del Módulo N" | 1 por parte (11) | Calificación aprobatoria de 70% |

**Las autoevaluaciones:** usan el banco de 246 preguntas con tres opciones y retroalimentación, en las categorías *Tu Talento v1.0/M1* a *M11*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 2,325 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Lecciones | 82 | 2,050 |
| Autoevaluaciones | 11 | 275 |
| **Total** | 93 | **2,325** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Casting | 0 | Al entrar |
| 2 | Ensayo | 250 | Durante el Módulo 2 |
| 3 | Llamado | 700 | Durante el Módulo 5 |
| 4 | Estreno | 1,200 | Durante el Módulo 7 |
| 5 | Temporada | 1,700 | Durante el Módulo 9 |
| 6 | Trayectoria | 2,150 | Durante el Módulo 11 |

**Clasificación (ranking): desactivada.** En *Level Up > Clasificación* elige no mostrarla, y quita o esconde el bloque de tabla de posiciones. Cada persona ve solo sus puntos, su nivel y sus insignias.

### 3. Insignias

*Más > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca. Los nombres llevan el curso para que no se repitan en la plataforma: úsalos tal cual.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_dinero_real.png | Dinero real · Tu Talento | Autoevaluación del Módulo 1 | Calculas tu ganancia real, te pagas un sueldo fijo y tienes meta de fondo de sequía. |
| 02_carrera_en_regla.png | Carrera en regla · Tu Talento | Autoevaluaciones de los Módulos 2 y 3 | Conoces tu régimen fiscal, tus contratos y a quién acudir por tus regalías. |
| 03_se_elegir.png | Sé elegir · Tu Talento | Autoevaluaciones de los Módulos 4 y 5 | Distingues instituciones, las verificas y comparas productos antes de contratar. |
| 04_credito_bajo_control.png | Crédito bajo control · Tu Talento | Autoevaluaciones de los Módulos 6, 7 y 8 | Sabes que el crédito es deuda, revisas tu Buró y Círculo y tienes plan de salida. |
| 05_nadie_me_engana.png | Nadie me engaña · Tu Talento | Autoevaluación del Módulo 9 | Reconoces fraudes, proteges tu identidad y sabes cómo responder. |
| 06_proteccion_activa.png | Protección activa · Tu Talento | Autoevaluación del Módulo 10 | Tienes plan de salud, IMSS, seguros, marca y documentos para tu familia. |
| 07_futuro_en_escena.png | Futuro en escena · Tu Talento | Autoevaluación del Módulo 11 | Tu retiro, tu carrera larga y tu plan de una página están escritos. |
| 08_plan_completo.png | Plan completo · Tu Talento | Finalización del curso | Concluiste los once módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Más > Finalización del curso*: condición de finalización de actividades con **todas** las 11 autoevaluaciones. Opcional: los 11 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado** con la **plantilla estándar de la plataforma** (sin imagen de fondo): nombre "Constancia de conclusión".
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 11 autoevaluaciones, "debe estar completa con calificación aprobatoria", y la **Encuesta final** enviada.
3. En la plantilla cambia solo estos datos (también están en `6_constancia/constancia.md`):

   | Campo | Texto |
   |---|---|
   | Título del curso | Tu Talento, Tu Marca, Tu Futuro |
   | Línea | por concluir el programa de bienestar financiero Tu Talento, Tu Marca, Tu Futuro |
   | Tema 1 | Dinero e impuestos |
   | Tema 2 | Contratos y regalías |
   | Tema 3 | Crédito y Buró |
   | Tema 4 | Fraudes y protección |
   | Tema 5 | Retiro y futuro |

4. Revisa la **Vista previa en PDF** y activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo · Tu Talento** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.


# Parte 3. Comunidad y canales


### 1. Espacio de la comunidad en Moodle

Un curso aparte, **"Comunidad Tu Talento"** (nombre corto `DT-TALENTO-MX-ES-COM`), con:

- Un foro **"Dudas de la comunidad"** (foro de uso general).
- Un foro **"Avisos"** (solo el equipo publica).
- La descripción: "Aquí resolvemos dudas entre la comunidad. No compartas RFC, CURP, números de cuenta, montos reales ni capturas de tus estados de cuenta. Los casos personales se atienden por mensaje privado o se canalizan a un profesional."

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Talento" y agregarla con el método de inscripción "Sincronización de cohortes" en el curso del programa y en la comunidad.

### 2. Canal de WhatsApp

- Nombre: "Tu Talento · Desarrolla Talento".
- Contenido: avisos del curso, fechas del SAT, alertas de fraude, recordatorios (reportes de crédito sin costo, Mes del Testamento, declaración anual) y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles.

### 3. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial se publican **solo** en el canal y en el foro de avisos, nunca en lecciones, actividades, autoevaluaciones ni constancia:

- Agencia de marca personal y redes (servicio propio).
- Despachos contables especializados en la industria creativa (referido).
- Agentes de seguros y planes de retiro (referido).

Cada publicación debe decir: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 4. Reglas de moderación

1. Borrar publicaciones con datos personales o capturas de cuentas y avisar en privado.
2. No permitir que participantes promuevan productos financieros, préstamos o inversiones.
3. Reportar de inmediato cualquier mensaje que parezca fraude (M9).
4. Canalizar casos fiscales, legales o de deudas complejas a PRODECON, CONDUSEF o un profesional.


# Parte 4. Mantenimiento


| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Enero | UMA, salario mínimo y tarifas de RESICO del año | M2, M10 U02, M11 |
| Enero | Cuotas de la Modalidad 10 y de la Modalidad 40 | M10 U02, M11 U03 |
| Cada seis meses | Precios de reportes, score, bloqueo y alertas de Buró y Círculo | M7 |
| Cada año | Tarifas de INDAUTOR e IMPI | M10 U05 |
| Cada año | REPEP, REUS y registro de líneas con CURP | M9 U08 |
| Cada año | Meta de inflación y tasa de referencia del Banco de México | M4 U05 |
| Septiembre | Mes del Testamento: costos y notarías | M10 U06 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco, y volver a armar la carpeta | herramientas_cursos/curso.py |

