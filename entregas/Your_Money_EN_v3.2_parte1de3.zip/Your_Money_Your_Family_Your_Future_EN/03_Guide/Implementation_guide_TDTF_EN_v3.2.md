# Your Money, Your Family, Your Future: implementation guide

For the team that sets up and runs the English course in Moodle 3.10. Part 1 (installation) is written in Spanish because it is addressed to Claude and the site administrator; the names to type in Moodle are in English.

# Part 1. Installation in Moodle, step by step

The same file is in `04_Moodle/README_INSTALAR_CURSO_INGLES_PARA_CLAUDE.md`.


Vas a crear el curso en inglés "Your Money, Your Family, Your Future" en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert), que ya está instalado.

Es un curso separado del curso en español (TDTF-CA-ES). Si ese curso existe, **no lo toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

Todo el contenido del curso va en inglés. Estas instrucciones están en español; los nombres que debes escribir en Moodle están en inglés, entre comillas o en `código`.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TDTF-CA-EN`. Si existe, detente y pregunta.
2. Confirma en *Administración del sitio > Extensiones > Resumen de extensiones* que existen **Certificado personalizado** y **Level Up**.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

*Administración del sitio > Cursos > Agregar un nuevo curso*:

| Campo | Valor |
|---|---|
| Nombre | Your Money, Your Family, Your Future (California pilot) |
| Nombre corto | TDTF-CA-EN |
| Visibilidad | **Ocultar** |
| Idioma forzado | Inglés, solo si el paquete de idioma inglés está instalado; si no, déjalo sin forzar |
| Formato | Temas, 7 secciones |
| Seguimiento de finalización | Sí |

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Welcome | Enlace al capítulo 1 del libro de apoyo y foro "Questions and comments" |
| 1 | Module 1. Understand your money and organize your finances | contenido de `1_books/M1_summary.html` |
| 2 | Module 2. Understand the financial system and plan your remittances | `M2_summary.html` |
| 3 | Module 3. Build your credit and manage your debts | `M3_summary.html` |
| 4 | Module 4. Protect your money, your identity and your family | `M4_summary.html` |
| 5 | Module 5. Build wealth and prepare your future | `M5_summary.html` |
| 6 | Support materials | "Cases, practice, glossary and where to get help." |
| 7 | Assessment and certificate | "Your certificate of completion." |

Descripción del foro "Questions and comments": "Don't share account numbers, SSN, ITIN, passwords or your immigration status."

### 3. Libros de lecciones (M1 a M5)

En cada sección de módulo:

1. Crea un libro:
   - Nombre: `Module N Lessons`.
   - Formato de capítulo: Nada.
   - Finalización: Ver.
2. Menú del libro > **Importar capítulo** > `1_books/MN_book_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba las páginas. En cada lección, la portada va primero y sus 3 subcapítulos sangrados debajo.

   | Módulo | Capítulos | Páginas |
   |---|---|---|
   | M1 | 14 | 56 |
   | M2 | 13 | 52 |
   | M3 | 10 | 40 |
   | M4 | 11 | 44 |
   | M5 | 11 | 44 |

### 4. Libro de apoyo

En la sección 6, crea el libro `Support materials` con la misma configuración e importa `1_books/Support_book_Moodle.zip` (6 capítulos).

En la sección General, agrega una **URL** o etiqueta que apunte al capítulo 1 ("Welcome") de este libro.

### 5. Glosario

En la sección 6, crea el glosario `Course key words` e importa `3_glossary/Course_glossary_Moodle.xml`, con destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Administración del curso > Banco de preguntas > Importar*: formato GIFT, archivo `4_questions/question_bank_v3_en.gift.txt`.
   - Se crean las categorías *Your Money v3/M1* a *M5*, con 177 preguntas.
2. En cada sección de módulo, crea el cuestionario `Module N Self-assessment`:
   - Calificación aprobatoria: 70.
   - Intentos: ilimitados.
   - Método: calificación más alta.
   - Ordenar al azar las respuestas: sí.
   - Revisión: después del intento, mostrar si fue correcta, la retroalimentación y la respuesta correcta.
   - Finalización: "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Your Money v3/MN*, 10 por página:

   | Módulo | Preguntas |
   |---|---|
   | M1 | 42 |
   | M2 | 39 |
   | M3 | 30 |
   | M4 | 33 |
   | M5 | 33 |

### 7. Actividades H5P (59)

Los archivos están en `2_h5p/MN/`, en orden. En cada sección de módulo, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · What would you do?`. Por ejemplo: `M1 U01 · What would you do?`.
3. Sube `MN_UYY_what_would_you_do.h5p`.
4. Opciones de H5P: permitir descarga no; botón de incrustar no; botón de derechos de autor sí.
5. Calificación: seguimiento de intentos sí; método "calificación más alta".
6. Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P de sus lecciones en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos en inglés, 3 opciones por caso y la calificación al terminar.

### 8. Level Up

Agrega el bloque Level Up al curso y sigue la sección 2 de `7_guides/gamification_guide_v3.md`: reglas, 6 niveles con sus nombres en inglés y clasificación anónima.

### 9. Insignias

Sigue la sección 3 de la guía con las 8 imágenes de `5_badges/`. Crea cada insignia con su nombre y descripción en inglés, y actívalas al final.

### 10. Finalización del curso y constancia

1. Configura la **Finalización del curso** con las 5 autoevaluaciones (sección 4 de la guía).
2. En la sección 7 crea el **Certificado personalizado** "Certificate of Completion" según la sección 5 de la guía, con `6_certificate/certificate_background.png`.
3. Revisa la vista previa en PDF y compárala con `certificate_sample.png`.

### 11. Revisión final (con rol de estudiante)

- M1 U01: la portada aparece primero, con los dos botones de ruta; los términos en color muestran su significado.
- La página *Practice* describe "What would you do?" y su quiz tiene 3 opciones.
- La H5P de M1 U01 funciona y registra la calificación.
- La autoevaluación de M1 muestra 3 opciones por pregunta.
- El libro de apoyo muestra "See the key" en los casos integradores.
- No aparece texto en español en el contenido, salvo los nombres propios de México (AFORE, CURP, matrícula consular) y los términos en español entre paréntesis del glosario, que son intencionales.

### 12. Reporte para la persona

Incluye el enlace del curso, el número de páginas de cada libro, las H5P subidas por módulo, las preguntas por autoevaluación, las insignias creadas, la configuración de Level Up, si la constancia quedó lista, todo lo que no pudiste hacer y por qué, y capturas de: una portada de lección, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **oculto**. La persona decide cuándo mostrarlo.


# Part 2. Activities, points, badges and certificate


This guide is for Moodle 3.10 with Level Up (block_xp) 3.15.2 and the Custom certificate plugin (mod_customcert), which is already installed on the site.

The goal is to motivate without competing. Points reward moving forward, not a perfect grade. Nobody's name is ever shown on a leaderboard.

### 1. What's in each module

| Activity | How many | Completion |
|---|---|---|
| Book "Module N Lessons" | 1 per module | View |
| H5P activity "MN UYY · What would you do?" | 1 per lesson (59 in total) | Receive a grade |
| Quiz "Module N Self-assessment" | 1 per module | Passing grade of 70% |

**The H5P activities:**

- Each one has three cases from the lesson, with three options each.
- They shuffle the options, mark the correct answer and allow retries.
- They're *Single Choice Set* activities. They include their libraries, in versions compatible with Moodle 3.10.
- Upload them as an **H5P activity** (mod_h5pactivity, part of Moodle since 3.9).

**Settings for each H5P activity:**

- H5P options: no download button, copyright button on, embed off.
- Attempts: tracking on, grading method "Highest grade".
- Completion: "Student must receive a grade".

**The self-assessments:**

- They use the v3 question bank: 177 questions with three options and feedback.
- Each module has its own category: *Your Money v3/M1* to *M5*.
- Settings: 70% passing grade, unlimited attempts and review with the correct answer and feedback at the end.

### 2. Level Up: levels and points

The free version of Level Up gives points for **events**. Set up a single main rule, so it works with both the free version and Level Up+.

**Rules** (*Level Up > Rules*):

1. **Remove or set the default rules to 0.** That way, opening a page or viewing a resource doesn't give points.
2. **For completing any activity:** 25 points. Use the event "Course module completion updated" (`\core\event\course_module_completion_updated`).
3. **For taking part in the forum:** 5 points. Use the event "Post created" (`\mod_forum\event\post_created`).
4. Keep Level Up's **cheat guard** on. It stops the same repeated event from adding points.

With these rules, completing the whole course gives about 1,725 points:

| Activities | How many | Points |
|---|---|---|
| H5P activities | 59 | 1,475 |
| Books | 5 | 125 |
| Self-assessments | 5 | 125 |
| **Total** | 69 | **1,725** |

**Levels** (*Level Up > Levels*, 6 levels, no automatic algorithm):

| Level | Name | Points | Reached roughly |
|---|---|---|---|
| 1 | Getting started | 0 | On entry |
| 2 | Getting organized | 150 | Halfway through Module 1 |
| 3 | Using my account | 450 | During Module 2 |
| 4 | Caring for my credit | 800 | During Module 3 |
| 5 | Protecting my family | 1,150 | During Module 4 |
| 6 | Building my future | 1,500 | During Module 5 |

**Ladder** (*Level Up > Ladder*):

- Anonymity on.
- Show only nearby neighbors, or turn the ladder off.

### 3. Badges

Create them in *Course administration > Badges > Add a new badge*. The images are in `5_badges/`.

For each badge:

- **Issuer:** Desarrolla Talento.
- **Expiry:** never.
- **Criteria:** "Activity completion", except "Complete plan", which uses "Course completion".

| Image | Badge | Criteria | Description |
|---|---|---|---|
| 01_M1_my_money_in_order.png | My money in order | Module 1 Self-assessment completed (passed) | You organized your cash flow, your budget and your taxes. 14 lessons, about 3 hours. |
| 02_M2_smart_sending.png | Smart sending | Module 2 Self-assessment | You know how to choose an account, compare remittances and protect your family from fraud. 13 lessons. |
| 03_M3_credit_on_track.png | Credit on track | Module 3 Self-assessment | You understand your report, compare loans and have a debt plan. 10 lessons. |
| 04_M4_protected_family.png | Protected family | Module 4 Self-assessment | You have a plan for protection, insurance and family preparedness. 11 lessons. |
| 05_M5_future_in_motion.png | Future in motion | Module 5 Self-assessment | Your goals, your retirement and your one-page plan are in writing. 11 lessons. |
| 06_scam_detective.png | Scam detective | H5P for M2 U11, M4 U01 and M4 U02 completed | You recognize the signs of fraud and verify before you act. |
| 07_expert_comparer.png | Expert comparer | H5P for M2 U08, M3 U05 and M5 U05 completed | You compare by total cost, not just the advertised price. |
| 08_complete_plan.png | Complete plan | Course completion | You completed the program's five modules. |

When you're done, **enable** each badge (*Enable access*). Moodle doesn't let you change the criteria of a badge that has already been awarded.

### 4. Course completion

*Course administration > Course completion*:

- **Condition:** activity completion, with **all** of these: the 5 self-assessments.
- **Optional:** also add the 5 books.

### 5. Certificate of completion (Custom certificate)

1. In the "Assessment and certificate" section, add a **Custom certificate** activity.
   - **Name:** Certificate of Completion.
   - **Size:** A4 landscape (297 × 210 mm).
2. **Restrict access:** add one "Activity completion" condition for each of the 5 self-assessments, with the option "must be marked complete and pass grade".
3. **Edit certificate.** Add these elements:

   | Element | Approximate position (mm) | Format |
   |---|---|---|
   | Background image | Covers the page | `6_certificate/certificate_background.png` |
   | Student name | X 0, Y 74, width 297, centered | Bold, 32 pt, color #0B1220 |
   | Date (course completion date) | X 17, Y 170, width 70, centered | 12 pt, color #E4007C |
   | Code | X 210, Y 170, width 70, centered | 12 pt, color #E4007C |

4. Use **Preview PDF** and adjust the Y positions if anything overlaps. Compare with `certificate_sample.png`.
5. **Optional:** turn on "Verify certificate" so anyone can check the code.

### 6. What not to do

- Don't give points for viewing pages.
- Don't publish names on leaderboards.
- Don't ask for real data to pass.
- Don't create badges with criteria that depend on amounts of money or on signing up for products.


# Part 3. Maintenance

| When | What to review | Where |
|---|---|---|
| Every month | Product comparison matrix | Operator manual, section 6 |
| Before tax season (January) | M1 U09 to U13: tax credits, ITIN, VITA, preparers | IRS and Franchise Tax Board |
| Every year | All content, "Learn more" links and dated figures | Official sites |
| When a law or program changes | Public charge, Medi-Cal, remittance tax and other sensitive topics | Official source of the change |
| After any content change | Rebuild books, H5P and bank in both languages and rebuild this folder | Project tools |
