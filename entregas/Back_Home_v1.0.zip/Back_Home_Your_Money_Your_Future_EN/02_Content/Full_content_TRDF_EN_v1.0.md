# Back Home, Your Money, Your Future: full content

Version 1.0 · Desarrolla Talento. Everything participants see: lessons, support book, H5P activities and question bank.

# Part 1. Characters

| Character | Who they are |
|---|---|
| Don Rafa | 52 years old. Worked 18 years in construction in Texas. Deported in March; went back to Michoacán. |
| Lupita | 38 years old. Returned by her own decision to Guanajuato with two U.S.-born children. |
| Memo | 24 years old. Arrived in the U.S. at age 6; returned to Puebla and barely knows Mexico. |
| Chayo | 45 years old. Lives in Oaxaca; received remittances from her husband, who just returned. |

## 2. Module map

| Module | Outcome | Badge |
|---|---|---|
| Module 1. Your papers | Your list of papers in order: repatriation record, CURP, birth certificate, INE and your children's papers. | Papers in order |
| Module 2. Your account in Mexico | An account in your name to receive support and money, and your returnee cards used well. | Account in my name |
| Module 3. Credit from scratch | Your first credit history in Mexico, starting small and with no traps. | History from scratch |
| Module 4. What you left in the United States | Your list of what was left there: last paycheck, accounts, taxes and retirement. | Nothing left behind |
| Module 5. Your Afore, your IMSS and your weeks | Your contribution weeks checked and your Afore located. | Weeks counted |
| Module 6. Your first 90 days | Your return budget for the first three months. | Ninety days |
| Module 7. Work or a business with what you know how to do | Your plan to use what you know how to do: a job, a trade or a small business. | What I know how to do |
| Module 8. Don't get scammed when you return | Your protocol against fake fixers, fraud and extortion targeting people who return. |  |

At the end of the program: badge **Complete plan** and certificate with the topics: Papers and account, Credit from scratch, What was left there, Afore and weeks, Return plan.

## 3. Lessons

# Part 2. Module 1. Your papers

## M1 U01. Your repatriation record and your CURP: the first two papers

**What you will be able to do:** Explain what the repatriation record is for and how to get your CURP to start any paperwork.

**To start:** Don Rafa arrived in Michoacán with a paper from the National Migration Institute folded in his wallet. His brother told him to throw it away because he «was already in Mexico». In this lesson you'll see why that paper is worth gold.

### The essentials (5 minutes)

#### The repatriation record

If you were sent back from the United States, the National Migration Institute (INM) gave you a paper. It's the **Record of Reception of Repatriated Mexicans** (Constancia de Recepción de Mexicanos Repatriados). It works as a temporary ID for your first steps. Use it for your CURP, birth certificate, health services, jobs and support from México te Abraza.



#### What it's for

| Type | Description | What it means for you |
|---|---|---|
| CURP | To get or recover your CURP. | First step. |
| Health | Basic medical care and continuing treatment. | IMSS and health institutions. |
| Jobs | Register with the National Employment Service. | Job board. |
| Support | Tarjeta Bienestar Paisano and Tarjeta FINABIEN Paisano. | Module 2. |

#### The CURP is the key

Almost everything in Mexico asks for your CURP: a bank account, IMSS, Afore, your children's school, a job. If you already had a CURP, you can look it up and print it at gob.mx/curp at no cost. If you never had one, you get it at the Civil Registry or at a help center for returnees.



#### A one-minute case

Don Rafa kept his record, looked up his CURP at an internet café and printed it. With those two papers he could ask for his birth certificate and sign up for support.

> **Key idea:** keep your repatriation record and get your CURP first; they open all the other doors.



#### Check your understanding

1. What is the repatriation record for?
*Answer:* It's a temporary ID for your first steps in Mexico.

2. How much does it cost to look up your CURP at gob.mx?
*Answer:* Nothing: looking it up and printing it has no cost.


#### Remember

- Keep the record.
- Get your CURP first.
- No CURP process costs money.



### Go deeper (5 more minutes)

#### Your list of papers

| Paper | I have it | Where to get it |
|---|---|---|
| Repatriation record | | INM, when you arrive |
| CURP | | gob.mx/curp or Civil Registry |
| Birth certificate | | gob.mx/actas or Civil Registry |
| INE (voter ID) | | INE office |



#### If you lost the record

Ask for a copy at the INM office or at the help center for returnees in your state. In the meantime, any other paper you have (birth certificate, consular ID, even an expired passport) helps prove who you are.



#### Cases


**Case 1. Don Rafa's paper**

His brother tells him to throw away the record because he «is already in Mexico».
- *What does he do?* He keeps it with his other papers.


**Case 2. Memo's CURP**

Memo doesn't know if he has a CURP; he left for the U.S. when he was 6.
- *What does he do?* He looks for it at gob.mx/curp with his name and date of birth.


**Case 3. The «fixer» at the plaza**

A man offers to get Lupita's CURP for 500 pesos.
- *What does she do?* She doesn't pay: looking it up at gob.mx has no cost.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Throwing away the record | You're left without ID | Keep it |
| Paying for the CURP | You lose money | It has no cost |
| Leaving the CURP for later | Everything else gets stuck | CURP first |
| Giving your papers to a stranger | Identity theft | Do it yourself |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Memo and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What paper does the INM give you when you're sent back? a) The Record of Reception of Repatriated Mexicans · b) A new INE voter ID, ready to vote · c) Your birth certificate
2. What is the key to almost every process? a) Your U.S. work badge · b) The CURP · c) The electric bill
3. How much does it cost to print your CURP at gob.mx? a) 500 pesos · b) 150 pesos · c) Nothing
**Answers:** 1-a: it's your temporary ID. 2-b: almost everything asks for it. 3-c: it has no cost.



#### Put it into practice

You have your record and your CURP, but no birth certificate or INE. Which two papers are missing from the basic list?
**Answer:** The birth certificate and the INE.



#### Your plan

Fill in your list of papers: check what you have and write where you'll get what's missing.



### Learn more

- **Look up your CURP** (Government of Mexico · Spanish): https://www.gob.mx/curp — **What to look for:** «consulta e impresión» (look up and print).
- **México te Abraza** (SEGOB · Spanish): https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza — **What to look for:** «servicios» (services).

### Key words

- *Repatriation:* a person's return to their country.
- *Record (constancia):* an official paper that proves something.
- *CURP:* Mexico's unique population ID code.

### Sources

SEGOB, México te Abraza; INM, Record of Reception of Repatriated Mexicans; checked October 5, 2026.

---

## M1 U02. Your birth certificate and your INE

**What you will be able to do:** Get your birth certificate and apply for your INE voter ID, which the bank and employers will ask for.

**To start:** Chayo went with her husband to the bank to open an account. They asked for an INE. He only had his Texas driver's license. They went home without an account. In this lesson you'll see how to avoid that.

### The essentials (5 minutes)

#### The birth certificate

You can get a certified copy of your birth certificate at gob.mx/actas with your CURP. Pay online or at a bank, and print it. It's worth the same as the one from the Civil Registry. The cost depends on the state.



#### The INE

The INE voter ID is the ID people ask for most. Applying for it has no cost. Bring to the INE office: your birth certificate, a photo ID (the repatriation record or a document with your photo) and proof of address.



#### If you don't have proof of address

| Type | Description | What it means for you |
|---|---|---|
| A relative's bill | Electricity, water or property tax in the name of whoever takes you in. | Ask the office what they accept. |
| Witnesses | Some offices accept two witnesses. | Ask before you go. |
| Proof of residence | Issued by the municipality or local authority. | Useful in small towns. |

#### A one-minute case

Chayo's husband got his birth certificate online, asked the municipality for a proof of residence and went to the INE office. Two weeks later he had his ID and opened his account.

> **Key idea:** with your birth certificate and proof of address, you get your INE at no cost. It's the ID that opens a bank account.



#### Check your understanding

1. Where can you get your birth certificate without going to the Civil Registry?
*Answer:* At gob.mx/actas, with your CURP.

2. How much does the INE cost?
*Answer:* Nothing: applying is free of charge.


#### Remember

- Birth certificate at gob.mx/actas.
- INE at no cost.
- Proof of address: ask about options.



### Go deeper (5 more minutes)

#### What to bring to the INE office

| Requirement | What you can bring |
|---|---|
| Nationality | Birth certificate |
| Photo ID | Repatriation record, passport or consular ID |
| Address | Utility bill or proof of residence |



#### While your INE arrives

Ask the office for your application receipt and keep it. If you need to collect support before then, ask the program office which ID they accept.



#### Cases


**Case 1. The Texas license**

Chayo's husband wants to open an account with his Texas driver's license.
- *What does he do?* He applies for his INE with his birth certificate and proof of address.


**Case 2. No bills in his name**

Memo lives with his aunt and no bill is in his name.
- *What does he do?* He asks the office if they accept his aunt's bill or witnesses.


**Case 3. The paid appointment**

A website asks for 300 pesos to «book an appointment» at the INE.
- *What does he do?* He doesn't pay: the appointment and the ID are free of charge.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Arriving without a birth certificate | They send you back | Bring it printed |
| Paying for an INE appointment | Fraud | It has no cost |
| Not asking about proof of address | Wasted trip | Ask first |
| Throwing away the application receipt | You can't pick up your ID | Keep it |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Chayo's husband and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What do you need for the INE? a) A valid U.S. passport · b) Birth certificate, photo ID and proof of address · c) A co-signer who owns a house and their proof of address
2. How much does the INE ID cost? a) Nothing · b) 300 pesos · c) It depends on the state
3. You have no bills in your name. What do you do? a) Wait until you own a house · b) Use any electric bill you find on the street, even if it isn't from your home · c) Ask if they accept a relative's bill, witnesses or a proof of residence
**Answers:** 1-b: those are the three requirements. 2-a: it has no cost. 3-c: there are options.



#### Put it into practice

You have your birth certificate and your repatriation record. You live with your mom and the electric bill is in her name. What do you need to confirm before going to the office?
**Answer:** Whether they accept your mom's bill as proof of address.



#### Your plan

Get your birth certificate online and call or ask the nearest INE office which proof of address they accept.



### Learn more

- **Birth certificate online** (Government of Mexico · Spanish): https://www.gob.mx/actas — **What to look for:** «copia certificada» (certified copy).
- **ID requirements** (INE · Spanish): https://www.ine.mx — **What to look for:** «requisitos credencial para votar» (voter ID requirements).

### Key words

- *Certified copy:* an official copy that counts as the original.
- *Proof of address:* a paper that shows where you live.
- *INE office (módulo):* the office where you apply for the INE.

### Sources

INE, requirements for the voter ID; Government of Mexico, birth certificates online; checked October 5, 2026.

---

## M1 U03. Papers for your children born in the United States

**What you will be able to do:** Register your U.S.-born children in Mexico so they have a CURP, school and services.

**To start:** Lupita's children were born in Houston. At the school in Guanajuato she was told that without a CURP they couldn't enroll. In this lesson you'll see how dual citizenship works.

### The essentials (5 minutes)

#### They're Mexican too

If your child was born in the U.S. and you are Mexican, your child is also Mexican by birth. For Mexico to recognize it, you **register the birth** at the Civil Registry or at a consulate. That way your child gets a Mexican birth certificate and a CURP.



#### What they usually ask for

| Type | Description | What it means for you |
|---|---|---|
| U.S. birth certificate | The original birth certificate. | Some states ask for an apostille. |
| Translation | Into Spanish, if they ask for it. | Ask first. |
| Your papers | Your Mexican birth certificate and ID. | Mom's or dad's. |
| Your child | Must be present, or as the office says. | Ask. |

#### School should not wait

Mexico's Education Ministry (SEP) says children can enroll even if papers are missing, while they're being sorted out. Ask the school to enroll them and tell them the process is underway.



#### A one-minute case

Lupita took her children's birth certificates to the Civil Registry. They told her what her state requires. In the meantime, her children started school with provisional enrollment.

> **Key idea:** register your children in Mexico so they have a birth certificate and a CURP; school should not wait for those papers.



#### Check your understanding

1. Can your U.S.-born child be Mexican?
*Answer:* Yes, if their mom or dad is Mexican; you register the birth.

2. What do you do if the school asks for a CURP and you don't have it yet?
*Answer:* Ask for enrollment while the process is completed.


#### Remember

- Register the birth.
- Ask about requirements in your state.
- School doesn't wait.



### Go deeper (5 more minutes)

#### Checklist for your children

| Paper | Child 1 | Child 2 |
|---|---|---|
| U.S. birth certificate | | |
| Apostille (if requested) | | |
| Mexican birth certificate | | |
| CURP | | |



#### Apostille

An apostille is a seal that recognizes a document from another country. For a U.S. birth certificate, you request it in the state where the child was born. Some civil registries no longer ask for it: ask before you pay.



#### Cases


**Case 1. Lupita's school**

She's told there's no spot for her children without a CURP.
- *What does she do?* She asks for enrollment while the birth registration is finished.


**Case 2. The original certificate**

Lupita only has a plain copy of the birth certificate.
- *What does she do?* She asks the Civil Registry if they accept it or how to request a certified one.


**Case 3. The expensive translation**

She's offered a translation of the certificates for 2,000 pesos each.
- *What does she do?* First she asks whether her state requires a translation and who can do it.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking they aren't Mexican | You don't register them | They are |
| Paying for an apostille without asking | Extra cost | Ask first |
| Keeping the kids out of school | They lose the year | Provisional enrollment |
| Losing the U.S. birth certificate | Hard to replace from Mexico | Keep the original |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita and her children. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Your child was born in the U.S. and you are Mexican. What is your child? a) Only American · b) Also Mexican, if you register the birth · c) A foreigner until turning 18 and deciding
2. What do you do before paying for an apostille or translation? a) Ask whether your state requires it · b) Pay for the most expensive apostille and translation to be safe · c) Nothing, registering isn't needed
3. The school asks for a CURP and it's in process. What do you do? a) Wait for the next school year · b) Enroll them next year, once they have their CURP · c) Ask for enrollment while it's sorted out
**Answers:** 1-b: you register the birth. 2-a: not every state asks for it. 3-c: school should not wait.



#### Put it into practice

You have two U.S.-born children with birth certificates. Which two Mexican papers will they have when the process is done?
**Answer:** A Mexican birth certificate and a CURP.



#### Your plan

Ask the Civil Registry in your municipality what they need to register your children's births and fill in the checklist.



### Learn more

- **Dual citizenship** (SRE · Spanish): https://www.gob.mx/sre — **What to look for:** «inscripción de nacimiento doble nacionalidad» (birth registration, dual citizenship).
- **School enrollment** (SEP · Spanish): https://www.gob.mx/sep — **What to look for:** «inscripción niñas y niños migrantes» (enrollment of migrant children).

### Key words

- *Dual citizenship:* being a citizen of two countries at once.
- *Apostille:* a seal that recognizes a foreign document.
- *Birth registration:* recording in Mexico a birth that happened abroad.

### Sources

SRE, dual citizenship; SEP, enrollment rules for migrant children; checked October 5, 2026.

---


# Part 3. Module 2. Your account in Mexico

## M2 U01. Your returnee cards

**What you will be able to do:** Tell apart the Tarjeta Bienestar Paisano and the Tarjeta FINABIEN Paisano, and use the 2,000 pesos well.

**To start:** At the reception center, Don Rafa was given a card with 2,000 pesos. A man on the bus told him «more would come every month». In this lesson you'll see what each card is and what it isn't.

### The essentials (5 minutes)

#### Two different cards

| Type | Description | What it means for you |
|---|---|---|
| Bienestar Paisano | A one-time support of 2,000 pesos. | For the trip home and first expenses. |
| FINABIEN Paisano | An account to receive and send money. | Remittances and payments. |

#### The support comes only once

The 2,000 pesos on the Tarjeta Bienestar Paisano are given once and don't repeat every month. Use them to get to your community and for what's most urgent: food, transportation, papers.



#### FINABIEN is the one to keep

The Tarjeta FINABIEN Paisano is an account: you can receive money from the U.S., save and pay. You request it at FINABIEN branches. Use it while you open another account, or as your main account.



#### A one-minute case

Don Rafa used 900 pesos of the support for the bus to his town and kept the rest for his birth certificate and his first days. Then he got his FINABIEN card so his son could send him money from Dallas.

> **Key idea:** the 2,000-peso support comes only once; FINABIEN is an account to keep receiving money.



#### Check your understanding

1. How often does the Tarjeta Bienestar Paisano support arrive?
*Answer:* Only once.

2. What is the Tarjeta FINABIEN Paisano for?
*Answer:* To receive, save and send money, like an account.


#### Remember

- 2,000 pesos, once.
- FINABIEN is an account.
- Urgent things first.



### Go deeper (5 more minutes)

#### Don Rafa's 2,000 pesos

- Support: **2,000**
- Bus to his town: **900**
- Birth certificate and copies: **250**
- Food for the first week: **600**
- For the unexpected: **250**


#### Your PIN is only yours

No one from the program will ask for your PIN or password by phone. If someone asks, it's fraud (Module 8).



#### Cases


**Case 1. «More every month»**

Don Rafa is told the support repeats every month.
- *What does he do?* He plans with 2,000 pesos, one time only.


**Case 2. The son in Dallas**

Don Rafa's son wants to send him money every two weeks.
- *What does he do?* He uses his FINABIEN card to receive it.


**Case 3. The call «from the program»**

Someone calls «from the program» to «activate» the card with his PIN.
- *What does he do?* He hangs up: no one from the program asks for the PIN.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Waiting for more deposits | You run out of money | It's only once |
| Mixing up the cards | You can't receive remittances | FINABIEN is an account |
| Giving out your PIN | They empty your card | Never give it |
| Spending it all on day one | No money for papers | Urgent things first |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa and his son. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What is the Tarjeta Bienestar Paisano? a) A one-time support of 2,000 pesos · b) A pension paid into your account every month · c) A loan
2. Which card lets you receive money from the U.S.? a) Neither · b) The FINABIEN Paisano · c) A department store card
3. Someone asks for your PIN «to activate» the card. What is it? a) A normal step · b) A bank requirement · c) Fraud
**Answers:** 1-a: it's only once. 2-b: it's an account. 3-c: no one asks for the PIN.



#### Put it into practice

You received 2,000 pesos. The bus costs 650 and your papers 300. How much is left?
**Answer:** 1,050 pesos.



#### Your plan

Make your list of how you'll use the 2,000 pesos: trip, papers, food and a little set aside.



### Learn more

- **México te Abraza** (SEGOB · Spanish): https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza — **What to look for:** «Bienestar Paisano».
- **FINABIEN** (Government of Mexico · Spanish): https://www.gob.mx/finabien — **What to look for:** «Tarjeta FINABIEN Paisano».

### Key words

- *One-time support:* money given only once.
- *Remittance:* money a relative sends from another country.
- *PIN:* your card's secret number.

### Sources

SEGOB, México te Abraza; Ministry of Welfare, Tarjeta Bienestar Paisano; FINABIEN, Tarjeta FINABIEN Paisano; checked October 5, 2026.

---

## M2 U02. Choose an account with no fees

**What you will be able to do:** Compare basic accounts and choose one in your name that doesn't charge you for keeping your money.

**To start:** Lupita opened an account at the first branch she found. Three months later she saw she was being charged 120 pesos a month for «minimum balance». In this lesson you'll see what to check before signing.

### The essentials (5 minutes)

#### Basic accounts

Banks must offer a **basic account**: no opening fee, no minimum balance and no monthly maintenance fee. Ask for that account by name.



#### Before signing, ask

| Type | Description | What it means for you |
|---|---|---|
| Is there a maintenance fee? | A monthly charge for having the account. | Look for zero. |
| Is there a minimum balance? | If you go below an amount, they charge you. | Look for none. |
| Free withdrawals? | Which ATMs don't charge. | Ask which ones. |
| Is it protected? | The institution must be authorized. | Check with CONDUSEF. |

#### Check the institution

We don't recommend any bank: we teach you to check. Look up the institution in CONDUSEF's SIPRES registry. If it isn't there, don't deposit there.



#### A one-minute case

Lupita went to another branch and asked for the basic account. She pays nothing a month. She closed the old one and stopped losing 120 pesos.

> **Key idea:** ask for the basic account and ask about fees before you sign.



#### Check your understanding

1. What must a basic account not charge you?
*Answer:* No opening fee, no minimum balance and no monthly maintenance fee.

2. Where do you check that an institution is authorized?
*Answer:* In CONDUSEF's SIPRES registry.


#### Remember

- Ask for the basic account.
- Ask about fees.
- Check with CONDUSEF.



### Go deeper (5 more minutes)

#### What Lupita was losing

- Fee per month: **120**
- Months: **12**
- Per year, for nothing: **1,440**


#### Read the contract and the summary sheet

The summary sheet (carátula) sums up the contract. That's where the fees are. Ask for a copy and keep it.



#### Cases


**Case 1. The minimum balance**

Lupita is offered an account with a gold card and a 3,000-peso minimum balance.
- *What does she do?* She asks for the basic account with no minimum balance.


**Case 2. The town savings box**

Chayo is offered a place to keep her money that pays 4% a month.
- *What does she do?* She looks it up in CONDUSEF's SIPRES before depositing.


**Case 3. No contract**

Memo signed and didn't get a copy.
- *What does he do?* He asks for his contract and the summary sheet with the fees.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Signing without asking | Hidden fees | Ask first |
| Accepting a minimum balance | You're charged if you go below | Basic account |
| Depositing in unauthorized places | You can lose it | Check |
| Not keeping the contract | You can't complain | Ask for a copy |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Chayo and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Which account do you ask for to avoid fees? a) The gold card · b) The basic account · c) The investment account
2. You're offered 4% a month. What do you do first? a) Check the institution with CONDUSEF · b) Deposit everything, because 4% a month is a good return · c) Invite your family
3. Where are the fees listed? a) In the ad · b) In what the bank clerk tells you out loud · c) On the contract's summary sheet
**Answers:** 1-b: no fees. 2-a: check first. 3-c: the summary sheet lists them.



#### Put it into practice

An account charges 85 pesos a month. How much do you pay in a year?
**Answer:** 1,020 pesos.



#### Your plan

Write down the four questions and ask them before opening your account. Keep the summary sheet.



### Learn more

- **SIPRES** (CONDUSEF · Spanish): https://webapps.condusef.gob.mx/SIPRES — **What to look for:** the institution's name.
- **Basic accounts** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «cuenta básica» (basic account).

### Key words

- *Basic account:* an account with no opening or maintenance fees.
- *Fee:* a charge for a service.
- *Summary sheet (carátula):* the summary of the contract.

### Sources

CONDUSEF, basic accounts and SIPRES; checked October 5, 2026.

---

## M2 U03. Getting paid, paying and disputing

**What you will be able to do:** Use your account to get paid and pay safely, and know how to dispute a charge you didn't make.

**To start:** Memo got his first payment by transfer and saw a 1,800-peso charge he doesn't recognize. He doesn't know if it's a mistake, fraud or «just how Mexico is». In this lesson you'll see what to do in the first hours.

### The essentials (5 minutes)

#### Ways to move your money

| Type | Description | What it means for you |
|---|---|---|
| Transfer (SPEI) | With the 18-digit CLABE. | Arrives in minutes. |
| Debit card | You pay with your own money. | It isn't credit. |
| Bank app | Check and transfer. | Only the official one. |
| ATM withdrawal | Prefer ATMs with no fee. | Watch your surroundings. |

#### Turn on alerts

Ask for a text message for every transaction. That way you see a strange charge the same day.



#### If you see a charge you didn't make

1. Call the bank at the number on the back of your card and block it.
2. Ask for a reference number (folio) for your claim.
3. If they don't solve it, go to CONDUSEF: 55 5340 0999.



#### A one-minute case

Memo called the bank, blocked the card and wrote down his reference number. The bank reviewed it and returned the 1,800 pesos.

> **Key idea:** turn on alerts; if you see a strange charge, block the card, get a reference number and dispute it.



#### Check your understanding

1. What do you need to receive a transfer?
*Answer:* Your 18-digit CLABE.

2. What do you do first about a charge you didn't make?
*Answer:* Call the bank, block the card and get a reference number.


#### Remember

- Alerts on.
- Block and get a reference number.
- CONDUSEF if they don't solve it.



### Go deeper (5 more minutes)

#### Your account card

| Item | I have it |
|---|---|
| CLABE (18 digits) | |
| Bank phone number | |
| Alerts turned on | |
| Claim reference number (if any) | |



#### Time matters

Dispute the charge as soon as you see it. The longer you wait, the harder it is to prove it wasn't you.



#### Cases


**Case 1. Memo's charge**

He sees 1,800 pesos he didn't spend.
- *What does he do?* He blocks the card, gets a reference number and disputes it.


**Case 2. The CLABE for the boss**

Don Rafa's boss asks for his details to pay him.
- *What does he do?* He gives his CLABE, never his PIN or password.


**Case 3. «That's just how Mexico is»**

A friend tells Memo not to complain because «they never give it back».
- *What does he do?* He disputes it and, if they don't solve it, goes to CONDUSEF.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not disputing | You lose the money | Dispute it soon |
| Giving your PIN to get paid | Fraud | Only the CLABE |
| Not getting a reference number | No proof | Always get one |
| Unofficial apps | Data theft | Only the bank's app |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Memo and Don Rafa. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What do you give so someone can pay you? a) Your PIN · b) Your CLABE · c) Your app password
2. What do you ask for when you dispute at the bank? a) A reference number · b) A discount · c) Nothing
3. The bank doesn't solve it. Where do you go? a) To the traffic police · b) To another bank · c) To CONDUSEF
**Answers:** 1-b: only the CLABE. 2-a: it's your proof. 3-c: it defends users.



#### Put it into practice

How many digits does a CLABE have?
**Answer:** 18.



#### Your plan

Fill in your account card and turn on text alerts.



### Learn more

- **Claims** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «presentar una reclamación» (file a claim). Phone 55 5340 0999.

### Key words

- *CLABE:* the 18-digit number for transfers.
- *SPEI:* the system for transfers between banks.
- *Reference number (folio):* the number that proves your claim.

### Sources

CONDUSEF, claims; Banco de México, SPEI; checked October 5, 2026.

---


# Part 4. Module 3. Credit from scratch

## M3 U01. Your U.S. credit history doesn't count here

**What you will be able to do:** Explain that in Mexico you start with no credit history, and check your report at no cost.

**To start:** Don Rafa had good credit in Texas: he paid off his truck on time for years. In Mexico he asked for a loan and was told he «doesn't show up anywhere». In this lesson you'll see why and what to do.

### The essentials (5 minutes)

#### Two countries, two histories

Your U.S. credit history doesn't carry over to Mexico. Here it's kept by credit bureaus such as **Buró de Crédito** and **Círculo de Crédito**. If you never had credit in Mexico, you show up with no history. That isn't bad: it's starting from zero.



#### What your report says

| Type | Description | What it means for you |
|---|---|---|
| Your credit | Who lent to you and how much. | Banks, stores, apps. |
| How you paid | On time or late. | What weighs most. |
| Who checked you | Who looked at your report. | Watch out for many checks. |

#### Check it at no cost

You can request your special report at no cost once every 12 months from each bureau. Do it to confirm no one opened credit in your name while you were away.



#### A one-minute case

Don Rafa requested his report: he had no credit. But his cousin's showed a loan from an app he never asked for. He disputed it in time.

> **Key idea:** in Mexico you start with no history; check your report at no cost to see that no one used your name.



#### Check your understanding

1. Does your U.S. history count in Mexico?
*Answer:* No: here you start from zero.

2. How often can you get your report at no cost?
*Answer:* Once every 12 months from each bureau.


#### Remember

- You start from zero.
- Report at no cost every 12 months.
- Check that no one used your name.



### Go deeper (5 more minutes)

#### Your check

| Bureau | I requested it | Date | All good? |
|---|---|---|---|
| Buró de Crédito | | | |
| Círculo de Crédito | | | |



#### If something isn't yours

File a dispute with the bureau (on its website) and notify the institution that gave the credit. If they don't solve it, go to CONDUSEF.



#### Cases


**Case 1. «You don't show up»**

Don Rafa is told he has no history.
- *What does he do?* He understands he's starting from zero and requests his report to check it.


**Case 2. Someone else's loan**

His cousin's report shows an app he never used.
- *What does he do?* He files a dispute with the bureau.


**Case 3. The paid report**

A website charges Memo 400 pesos for his report.
- *What does he do?* He requests it on the official website, at no cost once a year.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking your U.S. credit works here | You get frustrated | Start from zero |
| Not checking your report | You miss fraud | Request it |
| Paying for the yearly report | You lose money | It's no cost once a year |
| Ignoring someone else's loan | You end up paying | Dispute it |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, his cousin and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You had good credit in Texas. How do you show up in Mexico? a) With no history · b) With the same score · c) With bad credit
2. How many times a year is your special report at no cost? a) Never · b) Once · c) Every month
3. A loan you never asked for shows up. What do you do? a) Pay it to avoid problems · b) File a dispute · c) Nothing
**Answers:** 1-a: you start from zero. 2-b: once every 12 months. 3-b: you dispute it.



#### Put it into practice

You requested your Buró report in January. From what month can you request it again at no cost?
**Answer:** From January of the next year.



#### Your plan

Request your special report from Buró de Crédito and Círculo de Crédito and write down the date.



### Learn more

- **Reporte de Crédito Especial** (Buró de Crédito · Spanish): https://www.burodecredito.com.mx — **What to look for:** «reporte de crédito especial» (special credit report).
- **Credit report** (Círculo de Crédito · Spanish): https://www.circulodecredito.com.mx — **What to look for:** «reporte de crédito» (credit report).

### Key words

- *Credit history:* a record of how you've repaid what you borrowed.
- *Credit bureau:* an authorized company that keeps that record.
- *Special report:* your full history, at no cost once a year.

### Sources

Buró de Crédito and Círculo de Crédito, special report; CONDUSEF; checked October 5, 2026.

---

## M3 U02. Start small and pay on time

**What you will be able to do:** Build a credit history in Mexico with a small credit you can pay in full and on time.

**To start:** Memo wants a credit card «to have a history» and is offered one with a 20,000-peso limit. He earns 9,000 a month. In this lesson you'll see how to start without sinking.

### The essentials (5 minutes)

#### Start small

To build a history you don't need much credit. You need **one** small credit and to pay it on time for several months. It can be a low-limit card or a small installment purchase you were going to make anyway.



#### The three rules

| Type | Description | What it means for you |
|---|---|---|
| On time | Pay before the due date. | What counts most. |
| Use little | Don't use more than a third of the limit. | Example: of 3,000, use up to 1,000. |
| Pay it all | Pay the full balance, not the minimum. | That way you pay no interest. |

#### The minimum payment is a trap

If you pay only the minimum, the debt lasts years and you pay much more in interest. Use the card only for what you already have in your account to pay.



#### A one-minute case

Memo asked for a card with a 3,000 limit. He uses it for his phone top-up and gas, and pays it in full every month. In a year he already has a history.

> **Key idea:** a small credit, low use and full payment on time build your history.



#### Check your understanding

1. How much of the limit should you use?
*Answer:* No more than a third.

2. Why not pay only the minimum?
*Answer:* Because the debt lasts years and you pay a lot of interest.


#### Remember

- One small credit.
- Use little.
- Pay it all, on time.



### Go deeper (5 more minutes)

#### Memo's limit

- Limit: **3,000**
- One third: **3**
- The most you should use: **1,000**


#### Compare with the CAT

The Costo Anual Total (CAT, total annual cost) adds up interest and fees. Between two similar credits, the one with the lower CAT is cheaper. You see it on the summary sheet and in CONDUSEF's calculators.



#### Cases


**Case 1. The 20,000 limit**

Memo is offered a 20,000 limit; he earns 9,000.
- *What does he do?* He asks for a low limit he can pay in full.


**Case 2. The minimum payment**

Lupita's statement says «minimum payment 250».
- *What does she do?* She pays the full balance to avoid interest.


**Case 3. Three cards at once**

Don Rafa is offered three cards in one week.
- *What does he do?* He starts with just one and pays it on time.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Asking for a high limit | You get into debt | Start small |
| Paying the minimum | Years of interest | Pay it all |
| Using the whole limit | Hurts your history | One third |
| Many cards at the start | Hard to control | One |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Memo, Lupita and Don Rafa. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What builds your history best? a) Many cards open at the same time · b) A small credit paid on time · c) Paying the minimum
2. Your limit is 6,000. What's the most you should use? a) 2,000 · b) 6,000 · c) 4,500
3. Which indicator compares the cost of two credits? a) The card's color · b) The minimum payment · c) The CAT
**Answers:** 1-b: small and on time. 2-a: one third. 3-c: it adds up interest and fees.



#### Put it into practice

Your limit is 4,500. How much is one third?
**Answer:** 1,500 pesos.



#### Your plan

If you decide to get credit, write down your maximum limit, what you'll use it for and how you'll pay it in full every month.



### Learn more

- **Calculators and comparison tools** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «simulador tarjeta de crédito» (credit card calculator).

### Key words

- *Credit limit:* the most they'll lend you.
- *Minimum payment:* the least you can pay without being late; it generates interest.
- *CAT:* the credit's total annual cost.

### Sources

CONDUSEF, credit cards and CAT; Banco de México; checked October 5, 2026.

---

## M3 U03. «No credit check» loans and apps that overcharge

**What you will be able to do:** Recognize the expensive loans that target people with no history, and compare them before signing.

**To start:** Lupita needs 5,000 pesos for her children's school uniforms. An app promises her the money in 10 minutes, «no credit check, no paperwork». In a week she owes 7,800. In this lesson you'll see how it happens.

### The essentials (5 minutes)

#### «No credit check» doesn't mean no cost

People with no history are targeted by fast loans with very high interest and terms of one or two weeks. Some apps also ask for access to your contacts to pressure you.



#### Warning signs

| Type | Description | What it means for you |
|---|---|---|
| Very short term | 7 to 15 days. | Hard to pay. |
| They ask for your contacts | Access to your phone book and photos. | To pressure you. |
| They don't show the CAT | They don't show the total cost. | Bad sign. |
| Not registered | It isn't listed with CONDUSEF. | Don't use it. |

#### Do the math first

Ask how much you'll pay **in total** and over how long. If you borrow 5,000 and pay 7,800 in a week, the loan costs you 2,800: more than half.



#### A one-minute case

Lupita deleted the app before accepting. She asked her comadre to wait two weeks and used part of her savings circle (tanda). If she ever needs credit, she'll compare the total cost.

> **Key idea:** before borrowing, ask how much you'll pay in total. If they won't tell you, or they ask for your contacts, don't sign.



#### Check your understanding

1. What do you ask before any loan?
*Answer:* How much I'll pay in total and over how long.

2. Why does an app ask for your contacts?
*Answer:* To pressure you through your family if you fall behind.


#### Remember

- Ask for the total.
- Don't give your contacts.
- Check with CONDUSEF.



### Go deeper (5 more minutes)

#### The app loan

- What you'd pay: **7,800**
- What they lend you: **5,000**
- What it costs, in one week: **2,800**


#### If you're already being harassed

Keep screenshots, don't pay into personal accounts and file a complaint with CONDUSEF. If they threaten you, report it to the Fiscalía (public prosecutor). Module 8 covers this in depth.



#### Cases


**Case 1. The 10 minutes**

An app promises Lupita 5,000 in 10 minutes with no paperwork.
- *What does she do?* She asks for the total; since they won't say, she doesn't use it.


**Case 2. The contacts**

The app asks for access to Memo's phone book.
- *What does he do?* He denies permission and uninstalls it.


**Case 3. The store loan**

The furniture store offers Chayo «tiny» payments.
- *What does she do?* She adds up all the payments and compares with the cash price.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not asking for the total | You pay double | Always ask |
| Giving access to contacts | Your family gets harassed | Deny it |
| Using unregistered apps | No one to complain to | Check |
| Looking only at the small payment | Hidden cost | Add it all up |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Memo and Chayo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You borrow 3,000 and pay 4,500 in two weeks. How much does it cost you? a) 4,500 · b) 1,500 · c) Nothing
2. An app asks for your contacts. What do you do? a) Deny it and don't use the app · b) Accept · c) Give only your family's numbers
3. What must any loan tell you before you sign? a) Only the weekly payment · b) The collector's name and phone number · c) How much you'll pay in total
**Answers:** 1-b: 4,500 minus 3,000. 2-a: it's to pressure you. 3-c: the total.



#### Put it into practice

You're offered 12 weekly payments of 450 for a phone that costs 3,900 in cash. How much extra do you pay?
**Answer:** 1,500 pesos (12 times 450 is 5,400).



#### Your plan

Write three ways to get urgent money without expensive loans: savings, selling something, support, more time from the person you owe.



### Learn more

- **Loan apps** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «apps de préstamos» (loan apps) and «SIPRES».

### Key words

- *Term:* the time you have to pay.
- *Total cost:* everything you pay, minus what you borrowed.
- *Collection harassment:* illegal pressure to make you pay.

### Sources

CONDUSEF, alerts on loan apps and debt collection; checked October 5, 2026.

---


# Part 5. Module 4. What you left in the United States

## M4 U01. Your last paycheck and your account back there

**What you will be able to do:** Recover the wages you're owed and decide what to do with your U.S. bank account.

**To start:** Don Rafa was detained on a Thursday; Friday was payday. His boss owes him a week, and 1,400 dollars were left in his Texas account. He thinks he lost them. In this lesson you'll see that's not necessarily true.

### The essentials (5 minutes)

#### Your wages are yours

What you worked must be paid to you, even if you're no longer in the U.S. You can ask your boss to deposit it into your account there or to send a check to someone you trust. The Mexican consulate can guide you if the boss doesn't pay.



#### Your U.S. account: options

| Type | Description | What it means for you |
|---|---|---|
| Keep using it | With the bank's app or website. | Check for inactivity fees. |
| Send the money to Mexico | Transfer or send it to your account here. | Compare the cost. |
| Close it | Ask for the balance by transfer or check. | Do it in writing. |

#### Don't leave it forgotten

An account with no activity can charge fees and, after a few years, the money goes to the state as «unclaimed property». It can be recovered, but it takes more paperwork.



#### A one-minute case

Don Rafa logged into his bank's app from Mexico and transferred 1,350 dollars to his FINABIEN card. His nephew in Houston picked up the check for his last week and deposited it for him.

> **Key idea:** your last paycheck and your account back there are still yours; decide what to do with them soon.



#### Check your understanding

1. Do you lose your last paycheck if you were sent back?
*Answer:* No: it's owed to you; you can ask your boss for it.

2. What happens to an account forgotten for years?
*Answer:* It charges fees and the money goes to the state as unclaimed property.


#### Remember

- Your wages are owed to you.
- Decide about your account.
- The consulate can guide you.



### Go deeper (5 more minutes)

#### What was left there: money

| Item | Amount | Who helps me | Done |
|---|---|---|---|
| Last paycheck | | | |
| Account balance | | | |
| Rent deposit | | | |
| Money I lent someone | | | |



#### Unclaimed property

Every U.S. state has a website to search for unclaimed money in your name (accounts, checks, deposits). Searching is free of charge; be wary of anyone who charges to search.



#### Cases


**Case 1. Payday**

Don Rafa's boss owes him a week.
- *What does he do?* He asks for payment by deposit or by check to someone he trusts.


**Case 2. The forgotten account**

Lupita left 300 dollars in an account a year ago.
- *What does she do?* She checks for fees and decides whether to use it or close it.


**Case 3. «I'll get your money»**

Someone offers to recover Memo's money if he gives them his bank password.
- *What does he do?* He doesn't give his password; he does it himself or with the consulate.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Writing off your paycheck | You lose what you worked | Ask for it |
| Forgetting the account | Fees | Decide soon |
| Giving out passwords | They empty your account | Never |
| Paying to search for unclaimed money | Needless expense | It's no cost |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Lupita and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You're owed a week's wages in the U.S. What do you do? a) Ask for it by deposit or check · b) Write it off · c) Give your password to a fixer
2. What can happen to a forgotten account? a) Nothing, it never changes · b) It charges fees and goes to the state · c) They close it and send you double
3. Who can guide you if the boss doesn't pay? a) A fixer in the town square who knows the bosses · b) The Mexican consulate · c) No one
**Answers:** 1-a: it's yours. 2-b: unclaimed property. 3-b: the consulate guides you.



#### Put it into practice

Your account back there charges 12 dollars a month and has 150. In how many months will it be empty?
**Answer:** In 13 months (12.5 rounded up).



#### Your plan

Fill in the table of what was left there and mark who you'll ask for help with each item.



### Learn more

- **Consular protection** (SRE · Spanish): https://consulmex.sre.gob.mx — **What to look for:** «protección» (protection) and the consulate for the city where you worked.
- **Unclaimed property** (NAUPA · English): https://unclaimed.org — **What to look for:** the state where you lived.

### Key words

- *Last paycheck:* wages still owed when a job ends.
- *Unclaimed property:* forgotten money the state holds.
- *Consulate:* Mexico's office in another country.

### Sources

SRE, consular protection; NAUPA, unclaimed property; checked October 5, 2026.

---

## M4 U02. Your U.S. taxes

**What you will be able to do:** Check whether it's worth filing your U.S. tax return to recover taxes that were withheld.

**To start:** Lupita had taxes withheld from every check at the restaurant in Houston. She never filed because «what for». In this lesson you'll see there may be money waiting for you.

### The essentials (5 minutes)

#### Withholding

If you worked on payroll in the U.S., taxes were taken out of every paycheck. When you file your yearly tax return, you sometimes get part of it back: that's your **refund**.



#### What you need

| Type | Description | What it means for you |
|---|---|---|
| Your number | SSN or ITIN. | The one you worked with. |
| W-2 forms | The ones your employer gave you. | One per employer. |
| The year | Each return is for one year. | You can file past years. |
| Your address | So the check reaches you. | It can be in Mexico. |

#### The refund can reach Mexico

The IRS doesn't deposit into Mexican accounts. But it can mail a check to your address or to someone you trust in the U.S. You generally have up to three years to claim a refund.



#### A one-minute case

Lupita asked her former employer for her W-2 forms. With help from an organization linked to the consulate, she filed two years. A check arrived at her sister's house in Houston.

> **Key idea:** if taxes were withheld, file your return; there may be a refund for you.



#### Check your understanding

1. What is the refund?
*Answer:* Part of the withheld taxes that you get back when you file.

2. Until when can you claim it?
*Answer:* Generally up to three years.


#### Remember

- Taxes were withheld.
- Ask for your W-2s.
- You have about three years.



### Go deeper (5 more minutes)

#### Your working years

| Year | Employer | W-2 | Did I file? |
|---|---|---|---|
| | | | |
| | | | |



#### Watch out for people who «get you more»

Some preparers promise huge refunds and charge a percentage. If they make up information, the problem is yours. Look for help from free-of-charge programs or through the consulate.



#### Cases


**Case 1. «What for»**

Lupita never filed.
- *What does she do?* She asks for her W-2s and checks whether she has a refund.


**Case 2. No W-2**

Don Rafa doesn't have his forms.
- *What does he do?* He asks his employer, or the IRS with his number.


**Case 3. The miracle preparer**

Memo is offered «double the refund» for a 30% fee.
- *What does he do?* He looks for no-cost help and doesn't make up information.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not filing | You lose your refund | Check |
| Waiting many years | It expires | About three years |
| Making up information | Penalties | Only real information |
| Paying high percentages | You lose your money | No-cost help |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Don Rafa and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Which form does your employer give you with what you earned and what was withheld? a) The W-2 · b) The CURP · c) The rent receipt
2. Does the IRS deposit into a Mexican account? a) Yes, always · b) Only into a FINABIEN Paisano account · c) No; it mails a check
3. Generally, how long do you have to claim a refund? a) One month · b) About three years · c) Forever, there's no deadline
**Answers:** 1-a: the W-2. 2-c: a mailed check. 3-b: about three years.



#### Put it into practice

2,400 dollars were withheld and what you owed in taxes was 1,700. How much would your refund be?
**Answer:** 700 dollars.



#### Your plan

Write down the years you worked on payroll and which employer you'll ask for each W-2.



### Learn more

- **Refunds** (IRS · English and Spanish): https://www.irs.gov — **What to look for:** «refund» and «taxpayers living abroad».
- **Consular protection** (SRE · Spanish): https://consulmex.sre.gob.mx — **What to look for:** «ventanillas de asesoría financiera» (financial advice windows).

### Key words

- *Withholding:* tax taken out of each paycheck.
- *Refund:* what you get back if you paid too much.
- *W-2:* a form with your yearly wages and withholdings.

### Sources

IRS, refunds and the deadline to claim them; checked October 5, 2026.

---

## M4 U03. Your U.S. retirement: 401(k) and Social Security

**What you will be able to do:** Check whether you left retirement money in the U.S. and who to ask so you don't lose it.

**To start:** Memo worked five years at a warehouse with a 401(k). A friend told him that if he didn't take it all out now, «the government keeps it». In this lesson you'll see what to ask before deciding.

### The essentials (5 minutes)

#### Your 401(k) is yours

If your employer had a 401(k) plan and you contributed, that money is yours. You can leave it, move it or withdraw it. If you withdraw it before age 59½, there's normally a penalty and taxes are withheld.



#### Before withdrawing, ask

| Type | Description | What it means for you |
|---|---|---|
| How much do I have? | The plan balance. | Ask the plan administrator. |
| How much is withheld? | Taxes and penalty. | In writing. |
| Can I leave it? | Keep the money invested. | And withdraw it later. |
| How do they pay me? | Transfer or check. | In your name. |

#### U.S. Social Security

If you worked with a valid Social Security number, your contributions were recorded. With 40 credits (about 10 years) you could be entitled to a pension when you reach the age. The rules for collecting it while living in Mexico depend on your case: ask the Federal Benefits Unit at the U.S. Embassy.



#### A one-minute case

Memo called the plan administrator. They explained how much would be withheld. He decided to leave the money invested and not touch it until he has a steady job.

> **Key idea:** your U.S. retirement is still yours; ask how much is withheld before taking it out.



#### Check your understanding

1. What happens if you withdraw your 401(k) before age 59½?
*Answer:* There's normally a penalty and tax withholding.

2. Where do you ask about your U.S. Social Security?
*Answer:* At the Embassy's Federal Benefits Unit.


#### Remember

- Your 401(k) is yours.
- Ask about withholding.
- Social Security: ask about your case.



### Go deeper (5 more minutes)

#### Your U.S. retirement

| Plan | Administrator | Balance | Decision |
|---|---|---|---|
| 401(k) | | | |
| Social Security | | Credits: | |



#### Don't take it out out of fear

Taking everything out at once out of fear of losing it can cost you a good part in penalties and taxes. Get informed first; the money doesn't disappear because you live in Mexico.



#### Cases


**Case 1. «The government keeps it»**

Memo is told to take it all out now.
- *What does he do?* He asks the administrator how much would be withheld before deciding.


**Case 2. Ten years in construction**

Don Rafa worked 10 years with a Social Security number.
- *What does he do?* He asks the Embassy whether he's entitled and how to collect it.


**Case 3. The WhatsApp advisor**

Someone messages Lupita offering to «move her retirement» if she gives her information.
- *What does she do?* She gives no information; she talks directly with the plan administrator.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Taking it all out of fear | Penalty | Ask first |
| Forgetting the plan | Lost money | Write down the administrator |
| Giving information on WhatsApp | Theft | Only with the plan |
| Thinking you're not entitled | You don't ask | Ask about your case |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Memo, Don Rafa and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Your 401(k) belongs to… a) Your employer · b) You · c) The U.S. government
2. You withdraw your 401(k) at age 35. What normally happens? a) You get a bonus for taking it out early · b) Nothing · c) You pay a penalty and withholding
3. How many credits are usually required for a U.S. Social Security pension? a) 40 · b) 4 · c) 400
**Answers:** 1-b: it's yours. 2-c: before age 59½. 3-a: about 10 years.



#### Put it into practice

You have 8,000 dollars in your 401(k). If 30% in total is withheld and penalized, how much would you receive?
**Answer:** 5,600 dollars.



#### Your plan

Write down your plan administrator's name and call to ask the four questions before deciding.



### Learn more

- **Federal Benefits Unit** (U.S. Embassy in Mexico · English and Spanish): https://mx.usembassy.gov — **What to look for:** «Federal Benefits Unit».
- **Social Security** (SSA · English): https://www.ssa.gov — **What to look for:** «payments outside the U.S.».

### Key words

- *401(k):* a retirement plan from a U.S. job.
- *Penalty:* an extra charge for withdrawing early.
- *Social Security credit:* a unit that counts the work you paid into.

### Sources

IRS, early withdrawals from retirement plans; SSA, payments outside the U.S.; checked October 5, 2026.

---


# Part 6. Module 5. Your Afore, your IMSS and your weeks

## M5 U01. Do you have an Afore? Find it

**What you will be able to do:** Check whether you have an Afore account from when you worked in Mexico, and locate it.

**To start:** Before leaving, Don Rafa worked six years at a factory in Morelia with IMSS. He doesn't know whether that money «got lost». In this lesson you'll see how to find it.

### The essentials (5 minutes)

#### Your Afore is waiting for you

If you worked in Mexico with IMSS after 1997, you have an Afore (retirement savings) account in your name. The money isn't lost because you left: it's still there and earning returns.



#### How to locate it

| Type | Description | What it means for you |
|---|---|---|
| AforeMóvil app | With your CURP. | Tells you which Afore you're in. |
| e-SAR | CONSAR's website. | Locates your Afore. |
| SARTEL | 55 1328 5000. | No cost. |

#### If you never worked formally

If you don't have an Afore, you can open one with your CURP in the AforeMóvil app, even if you're self-employed. That way you start saving for retirement (U03).



#### A one-minute case

Don Rafa downloaded AforeMóvil, entered his CURP and his account appeared with the savings from his six years at the factory. He updated his phone number and address.

> **Key idea:** if you worked formally in Mexico, your Afore is still there; locate it with your CURP.



#### Check your understanding

1. Is your Afore lost if you went to the U.S.?
*Answer:* No: it's still there in your name.

2. What do you need to locate it?
*Answer:* Your CURP.


#### Remember

- Your Afore isn't lost.
- Locate it with your CURP.
- Update your details.



### Go deeper (5 more minutes)

#### Your Afore

| Item | I have it |
|---|---|
| Which Afore I'm in | |
| Approximate balance | |
| Registered beneficiaries | |
| Contact details up to date | |



#### Register your beneficiaries

They're the people who would receive your savings if you pass away. Check them at your Afore; if you named them years ago, they may no longer be who you want.



#### Cases


**Case 1. «It got lost»**

Don Rafa thinks he lost his factory savings.
- *What does he do?* He looks for it with his CURP in AforeMóvil.


**Case 2. Never formal**

Memo never worked formally in Mexico.
- *What does he do?* He opens his Afore with his CURP to start saving.


**Case 3. The Afore fixer**

Chayo is offered help to «get out» her husband's Afore for a fee.
- *What does she do?* She doesn't pay: the lookup is no cost and he does it with his CURP.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Writing off your Afore | Forgotten money | Look for it |
| Not updating your details | They can't reach you | Update |
| Old beneficiaries | The money goes to someone you don't want | Check them |
| Paying fixers | Fraud | It's no cost |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Memo and Chayo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You worked in Mexico with IMSS in 2005. Do you have an Afore? a) Probably yes · b) No, it was erased · c) Only if you've lived in Mexico since then
2. What do you use to locate your Afore? a) Your U.S. driver's license · b) Your CURP · c) Your electricity bill
3. What are beneficiaries? a) The people who'd receive your savings if you pass away · b) The Afore's owners and directors · c) Your bosses
**Answers:** 1-a: if you contributed, you have one. 2-b: with the CURP. 3-a: the ones who receive it.



#### Put it into practice

Besides the balance, what two things do you check when you find your Afore?
**Answer:** Your contact details and your beneficiaries.



#### Your plan

Locate your Afore with your CURP and fill in the table.



### Learn more

- **Locate your Afore** (CONSAR · Spanish): https://www.gob.mx/consar — **What to look for:** «localiza tu Afore» (locate your Afore) and «AforeMóvil». SARTEL 55 1328 5000.

### Key words

- *Afore:* the company that manages your retirement savings.
- *Return:* what your savings earn over time.
- *Beneficiary:* the person who receives your savings if you pass away.

### Sources

CONSAR, account location and AforeMóvil; checked October 5, 2026.

---

## M5 U02. Your contribution weeks

**What you will be able to do:** Look up your IMSS contribution weeks and calculate how many you're missing for a pension.

**To start:** Chayo heard that her husband «can't get a pension anymore because he was gone for many years». No one has checked how many weeks he has. In this lesson you'll see how to do it.

### The essentials (5 minutes)

#### Weeks aren't erased

Every week you worked with IMSS in Mexico stays on record. When you left, the count stopped, but it wasn't lost. You can check it at no cost on the IMSS website with your CURP and your social security number.



#### Which law applies to you?

| Type | Description | What it means for you |
|---|---|---|
| Ley 73 | You started contributing before July 1, 1997. | Requires 500 weeks. |
| Ley 97 | You started after that. | In 2026 it requires 875 weeks. |

#### Ley 97 goes up every year

Under Ley 97, the requirement goes up 25 weeks every year until it reaches 1,000 in 2031. If you're short of weeks, you can contribute again with a formal job or on your own (U03).



#### A one-minute case

Chayo's husband checked: he has 610 weeks and started in 1993, so he's under Ley 73. He's already over 500. When he reaches the age, he'll be able to review his pension.

> **Key idea:** your weeks aren't erased; check them and find out which law applies to you.



#### Check your understanding

1. What happens to your weeks when you go to the U.S.?
*Answer:* They stay on record; the count stops, but they aren't erased.

2. How many weeks does Ley 97 require in 2026?
*Answer:* 875.


#### Remember

- Weeks aren't erased.
- Ley 73: 500.
- Ley 97: 875 in 2026.



### Go deeper (5 more minutes)

#### How many Don Rafa is missing (Ley 97)

- Requirement in 2026: **875**
- Weeks he has: **312**
- Weeks he's missing: **563**


#### About 52 weeks per year

A full year of formal work adds about 52 weeks. 563 weeks takes almost 11 years; that's why it's best to start soon.



#### Cases


**Case 1. «He can't get it anymore»**

Chayo is told her husband lost everything.
- *What does she do?* They check his weeks at IMSS with his CURP.


**Case 2. Which law?**

Don Rafa started formal work in 2001.
- *What does he do?* He knows Ley 97 applies and calculates how many weeks he's missing.


**Case 3. Missing weeks**

Don Rafa is missing more than 500 weeks.
- *What does he do?* He looks for a formal job or contributes on his own.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking they were erased | You don't collect | Check |
| Mixing up the law | You count wrong | Check your start date |
| Waiting until 60 | No time left | Start soon |
| Paying for the lookup | Fraud | It's no cost |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Chayo and Don Rafa. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You started contributing in 1990. Which law applies? a) Ley 97 · b) Ley 73 · c) Neither
2. How many weeks does Ley 97 require in 2026? a) 500 · b) 1,250 · c) 875
3. How many weeks does a full year of formal work add? a) About 52 · b) 12 · c) 365, one per day of the year
**Answers:** 1-b: before July 1997. 2-c: 875. 3-a: about 52.



#### Put it into practice

You have 700 weeks and you're under Ley 97. How many are you missing in 2026?
**Answer:** 175.



#### Your plan

Check your weeks on the IMSS website and write down how many you have and which law applies to you.



### Learn more

- **Contribution weeks certificate** (IMSS · Spanish): https://serviciosdigitales.imss.gob.mx — **What to look for:** «semanas cotizadas» (contribution weeks).

### Key words

- *Contribution weeks:* weeks worked with IMSS.
- *Ley 73 and Ley 97:* pension rules based on when you started contributing.
- *NSS:* social security number.

### Sources

IMSS, contribution weeks certificate and Ley 73 and Ley 97 pension requirements; checked October 5, 2026.

---

## M5 U03. Save for retirement even if you're self-employed

**What you will be able to do:** Make voluntary contributions to your Afore, and explain how to enroll in IMSS if you're self-employed.

**To start:** Don Rafa now does masonry jobs on his own. He has no boss and no IMSS. He thinks retirement «isn't for him anymore». In this lesson you'll see he can still do something.

### The essentials (5 minutes)

#### Voluntary contributions

You can deposit into your Afore from 50 pesos at convenience stores, in the AforeMóvil app or by automatic debit. That money is yours and adds to your retirement.



#### Ways to save

| Type | Description | What it means for you |
|---|---|---|
| At the store | From 50 pesos. | With your CURP. |
| In the app | AforeMóvil. | Whenever you want. |
| Automatic debit | A fixed amount from your account. | Automatic. |

#### IMSS if you're self-employed

Self-employed workers can enroll in IMSS voluntarily and pay their contribution. It gives them medical care and counts weeks. Check the requirements and cost on the IMSS website.



#### A one-minute case

Don Rafa decided to set aside 200 pesos every two weeks for his Afore at the store. In a year he'll have saved 4,800 pesos plus returns.

> **Key idea:** even if you're self-employed, you can save in your Afore from 50 pesos.



#### Check your understanding

1. From how much can you make a voluntary contribution at a store?
*Answer:* From 50 pesos.

2. What does enrolling in IMSS as self-employed give you?
*Answer:* Medical care and contribution weeks.


#### Remember

- From 50 pesos.
- Store, app or automatic debit.
- Voluntary IMSS exists.



### Go deeper (5 more minutes)

#### Don Rafa's savings

- Every two weeks: **200**
- Pay periods a year: **24**
- In a year, plus returns: **4,800**


#### Long-term contributions

Voluntary contributions can have tax benefits if you leave them until retirement. Ask your Afore which type of contribution suits you.



#### Cases


**Case 1. «It's not for me»**

Don Rafa thinks that without a boss he can't save for retirement.
- *What does he do?* He contributes to his Afore every two weeks at the store.


**Case 2. No medical care**

Lupita sells food and doesn't have IMSS.
- *What does she do?* She checks the requirements to enroll as self-employed.


**Case 3. Saving with an acquaintance**

An acquaintance offers to keep Memo's retirement savings «with good interest».
- *What does he do?* He saves in his Afore, which is in his name.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking you can't | You don't save | From 50 pesos |
| Waiting to have a boss | You lose years | Start now |
| Saving with acquaintances | Risk of losing it | In your Afore |
| Not checking voluntary IMSS | No medical care | Get informed |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Lupita and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Where can you contribute to your Afore? a) Only at the bank where your boss paid you · b) At a store, in the app or by automatic debit · c) Only when you retire
2. You save 100 pesos a week in your Afore. How much in a year? a) 1,200 · b) 5,200 · c) 520
3. What does enrolling in IMSS as self-employed give you? a) A loan · b) A credit card with a limit based on your contribution · c) Medical care and weeks
**Answers:** 1-b: you have three ways. 2-b: 52 weeks times 100. 3-c: medical care and weeks.



#### Put it into practice

You contribute 300 pesos a month. How much in two years, not counting returns?
**Answer:** 7,200 pesos.



#### Your plan

Decide how much you'll contribute to your Afore and how often. Write it down and make the first contribution.



### Learn more

- **Voluntary savings** (CONSAR · Spanish): https://www.gob.mx/consar — **What to look for:** «ahorro voluntario» (voluntary savings).
- **Self-employed workers** (IMSS · Spanish): https://www.imss.gob.mx — **What to look for:** «personas trabajadoras independientes» (self-employed workers).

### Key words

- *Voluntary contribution:* money you add to your Afore yourself.
- *Automatic debit:* an automatic charge to your account.
- *Self-employed worker:* someone who works without a boss.

### Sources

CONSAR, voluntary savings; IMSS, enrollment of self-employed workers; checked October 5, 2026.

---


# Part 7. Module 6. Your first 90 days

## M6 U01. Think in pesos: your return budget

**What you will be able to do:** Make a budget in pesos for your first 90 days, with what really comes in and goes out.

**To start:** Memo earned 18 dollars an hour in the U.S. In Puebla he's offered 2,400 pesos a week. He does the math in dollars and feels «it's not enough for anything». In this lesson you'll see how to do math that actually helps.

### The essentials (5 minutes)

#### Switch your mindset

Comparing your pay there with your pay here only discourages you: prices are different too. Do your math in pesos, with the prices in your community.



#### Your 90-day budget

| Type | Description | What it means for you |
|---|---|---|
| What comes in | Wages, odd jobs, support, savings you brought. | Only what's certain. |
| The basics | Food, housing, transportation, health. | First. |
| Papers | Certificates, copies, travel. | One-time expense. |
| A little set aside | For the unexpected. | Even if it's small. |

#### Three months, not one

In the first months, less money almost always comes in than you expect. Plan for 90 days and count only the money that's certain, not the money that «might» come.



#### A one-minute case

Memo wrote down what he spends in Puebla: shared rent, food and bus fare add up to 7,600 a month. With 2,400 a week he brings in about 10,400. He has 2,800 left for papers and his little savings.

> **Key idea:** do your math in pesos and for 90 days, with what's certain.



#### Check your understanding

1. Why not compare your pay in dollars with your pay here?
*Answer:* Because prices are different too; what helps is doing the math in pesos.

2. What money do you count in your budget?
*Answer:* Only money that's certain.


#### Remember

- Math in pesos.
- Plan 90 days.
- Only what's certain.



### Go deeper (5 more minutes)

#### Memo's month

- Comes in (2,400 a week, about 4.3 weeks): **10,400**
- Shared rent: **2,500**
- Food: **3,600**
- Transportation: **1,500**
- For papers and savings: **2,800**


#### Your 90 days

| Item | Month 1 | Month 2 | Month 3 |
|---|---|---|---|
| Comes in | | | |
| Food | | | |
| Housing | | | |
| Transportation | | | |
| Papers | | | |
| Set aside | | | |



#### Cases


**Case 1. The 18 dollars**

Memo compares his pay there with his pay here.
- *What does he do?* He makes his budget in pesos with Puebla prices.


**Case 2. The promised job**

Don Rafa is promised a job «in a month».
- *What does he do?* He doesn't count it until it's certain.


**Case 3. Everything in the first month**

Lupita wants to spend all her savings furnishing the house.
- *What does she do?* She spreads her savings over the three months.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking in dollars | You get discouraged | Math in pesos |
| Counting uncertain money | You fall short | Only what's certain |
| Planning one month | Savings run out | 90 days |
| Forgetting the papers | Surprise expenses | Include them |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Memo, Don Rafa and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. How far ahead do you plan when you return? a) One week · b) 90 days · c) One day
2. You're promised a job «in a month». Do you count it? a) Yes, all of it · b) Half, in case they do hire you · c) No, not until it's certain
3. How do you do your math? a) In pesos with prices here · b) In dollars · c) With prices there, to compare better
**Answers:** 1-b: the first months. 2-c: only what's certain. 3-a: in pesos.



#### Put it into practice

9,000 comes in a month and you spend 7,200 on the basics. How much is left?
**Answer:** 1,800 pesos.



#### Your plan

Fill in your 90-day table with the money that's certain and the basics.



### Learn more

- **Budgeting** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «presupuesto personal» (personal budget).

### Key words

- *Budget:* a plan for what comes in and goes out.
- *Certain income:* money you know will arrive.
- *Little savings (guardadito):* small savings for the unexpected.

### Sources

CONDUSEF, budgeting tools; checked October 5, 2026.

---

## M6 U02. Welcome-home obligations

**What you will be able to do:** Set kind limits on the spending and loans people ask of you when you return.

**To start:** When he arrived, Don Rafa's family threw him a welcome party that he paid for. Then his compadre asked to borrow money «since he's back from over there». In two weeks, half his savings were gone. In this lesson you'll see how to say no without a fight.

### The essentials (5 minutes)

#### «You came back with dollars»

Many people believe that whoever returns brings money. Sometimes it's true; often it isn't. Your savings have to last until you have income.



#### Three answers that help

| Type | Description | What it means for you |
|---|---|---|
| «I can't right now» | Without over-explaining. | Short and kind. |
| «When I have a job» | Change the when. | Without promising an amount. |
| «I'll help you another way» | Time, contacts, skills. | Not only money. |

#### Decide an amount ahead of time

If you want to help, decide ahead of time how much you can give without putting your 90 days at risk. Give it as a gift, not as a loan that will hurt to collect.



#### A one-minute case

Don Rafa decided he could give his mother 500 pesos a month and nothing more. He told his compadre: «Not right now; when I have a job, we'll see». His savings lasted three months.

> **Key idea:** your return savings have to last; decide ahead of time how much you can help, and say no kindly.



#### Check your understanding

1. Why take care of your savings when you return?
*Answer:* Because they have to last until you have income.

2. How do you help without throwing yourself off balance?
*Answer:* You decide an amount ahead of time and give it as a gift.


#### Remember

- Your savings have to last.
- Decide an amount.
- Say no kindly.



### Go deeper (5 more minutes)

#### What was gone in two weeks

- Don Rafa's savings: **8,000**
- Welcome party: **2,500**
- Loan to his compadre: **1,500**
- Half was left: **4,000**


#### It isn't selfish

Taking care of your savings also takes care of your family: if you end up with nothing, someone will later have to help you.



#### Cases


**Case 1. The party**

Don Rafa's family wants a party he would pay for.
- *What does he do?* He suggests something simple and sets a cap.


**Case 2. The compadre**

His compadre asks for 1,500 «since he's back from over there».
- *What does he do?* He says «not right now; when I have a job, we'll see».


**Case 3. Lupita's mother**

Lupita wants to help her mother every month.
- *What does she do?* She decides a fixed amount that doesn't put her 90 days at risk.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying for everything out of obligation | Savings disappear | Set a cap |
| Lending without thinking | Hard to collect | A gift or nothing |
| Over-explaining | They talk you into it | Short answer |
| Feeling guilty | You give in | Protecting your savings protects everyone |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, his compadre and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. People ask to borrow money when you arrive. What helps you? a) Lending everything · b) A short, kind answer · c) Borrowing so you can lend to your family
2. When do you decide how much to help? a) Ahead of time, based on your 90 days · b) When they ask, based on what each person needs · c) Never
3. If you help with money, it's best to give it as… a) A loan with interest · b) An advance · c) A gift you can afford
**Answers:** 1-b: short and kind. 2-a: ahead of time. 3-c: without expecting it back.



#### Put it into practice

You have 9,000 in savings and need 2,500 a month to cover your expenses. How much can you give away over three months without falling short?
**Answer:** 1,500 pesos.



#### Your plan

Write down how much you can give each month and your sentence for saying no.



### Learn more

- **Family finances** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «prestar dinero a familiares» (lending money to relatives).

### Key words

- *Cap:* the most you'll spend.
- *Obligation:* an expense you feel you're expected to make.
- *Limit:* how far you can go without harming yourself.

### Sources

CONDUSEF, recommendations on loans between relatives; checked October 5, 2026.

---

## M6 U03. When the remittances stop

**What you will be able to do:** Reorganize household spending when the relative who sent money comes back or stops sending.

**To start:** Chayo received 300 dollars a month from her husband. Now he's back and there's no remittance. The bills and school costs keep coming. In this lesson you'll see how to adjust the household together.

### The essentials (5 minutes)

#### The household's numbers change

If the household depended on the remittance, you need a new budget with what comes in now. In 2025, remittances to Mexico fell 4.6%: many families are in the same situation.



#### Four steps as a family

| Type | Description | What it means for you |
|---|---|---|
| What comes in today | Wages, support, sales. | From everyone. |
| What gets cut | What isn't basic. | Together. |
| What isn't touched | Food, school, health. | Priority. |
| Monthly review | How we're doing. | As a family. |

#### Check for support programs

Some families are entitled to scholarships or programs they haven't applied for. Check with your municipality and the Bienestar programs.



#### A one-minute case

Chayo and her husband added up what comes in: her sales and his odd jobs. They cut cable TV and the expensive phone plan. They signed their daughter up for the middle-school scholarship. It's enough, just barely.

> **Key idea:** if the remittance ends, make a new budget as a family and protect the basics.



#### Check your understanding

1. Which expenses aren't touched?
*Answer:* Food, school and health.

2. Besides cutting, what can they check?
*Answer:* Support or scholarships they're entitled to.


#### Remember

- A new budget.
- The basics first.
- Check for support.



### Go deeper (5 more minutes)

#### Chayo's household

- Chayo's sales: **6,000**
- His odd jobs: **4,500**
- What comes in today: **10,500**


#### Talk without blame

The remittance didn't end because of anyone's fault. Talking with numbers helps you decide together instead of fighting.



#### Cases


**Case 1. No remittance**

Chayo no longer receives the 300 dollars.
- *What does she do?* She makes a new budget with her husband.


**Case 2. Cable TV and school**

There isn't enough for everything.
- *What does she do?* They cut what isn't basic and protect school.


**Case 3. The scholarship**

Her daughter could get a scholarship and they haven't applied.
- *What does she do?* She checks the requirements and applies.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Spending the same as before | Debt | A new budget |
| Cutting school or health | Greater harm | Protect them |
| Blaming each other | Fights | Talk with numbers |
| Not checking for support | Money that doesn't come | Get informed |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Chayo and her family. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. The remittance ended. What do they do first? a) A new budget with what comes in today · b) Take out a loan to keep spending as before · c) Keep going the same
2. Which expense is protected? a) Cable TV · b) School · c) The expensive phone plan
3. What else can they check? a) Nothing · b) Online betting to make up for the remittance · c) Support or scholarships they're entitled to
**Answers:** 1-a: with real numbers. 2-b: it's basic. 3-c: there may be support.



#### Put it into practice

10,500 comes in and the basics cost 9,200. How much is left for everything else?
**Answer:** 1,300 pesos.



#### Your plan

Sit down as a family and fill in together what comes in today and the basics. Set a date to review it every month.



### Learn more

- **Programas para el Bienestar** (Government of Mexico · Spanish): https://programasparaelbienestar.gob.mx — **What to look for:** «becas» (scholarships) and «requisitos» (requirements).

### Key words

- *Remittance:* money a relative sends from another country.
- *Cut:* an expense you remove or reduce.
- *Scholarship:* support to study.

### Sources

Banco de México, 2025 remittance income; Ministry of Welfare; checked October 5, 2026.

---


# Part 8. Module 7. Work or a business with what you know how to do

## M7 U01. What you know how to do has value

**What you will be able to do:** List your skills and identify how to prove them to get a job.

**To start:** Don Rafa knows how to install drywall, read blueprints in English and run a crew. In the interview he only said «I do a bit of everything». They didn't call him. In this lesson you'll see how to tell what you know.

### The essentials (5 minutes)

#### Your experience is your capital

Your years in the U.S. left you trades, English, discipline and customer skills. That's valuable here, but you need to say it clearly and, if possible, prove it.



#### Your list of what you know

| Type | Description | What it means for you |
|---|---|---|
| Trade | Construction, cooking, cleaning, mechanics. | With years. |
| Language | Spoken or written English. | In high demand. |
| Leadership | Coordinating people. | Supervision. |
| Proof | Photos, letters, certificates. | What proves it. |

#### Where to look

The Servicio Nacional de Empleo (national employment service) has a job board and serves repatriated people. Also, CONOCER can certify what you already know how to do, even if you have no diploma.



#### A one-minute case

Don Rafa wrote: «12 years in drywall, I read blueprints, I coordinated crews of 8, I speak English». He brought photos of his work. At the next interview they hired him as foreman.

> **Key idea:** make a list of what you know how to do and bring it with proof.



#### Check your understanding

1. What did your years in the U.S. leave you?
*Answer:* Trades, language, discipline and customer skills.

2. Who can certify what you know without a diploma?
*Answer:* CONOCER.


#### Remember

- Make your list.
- Bring proof.
- SNE and CONOCER.



### Go deeper (5 more minutes)

#### Your list

| What I know how to do | Years | Proof |
|---|---|---|
| | | |
| | | |
| | | |



#### English opens doors

Call centers, tourism and exporting companies look for people who speak English. If you speak it, put it first.



#### Cases


**Case 1. «I do a bit of everything»**

Don Rafa doesn't say what he knows how to do.
- *What does he do?* He writes his list with trade, years and proof.


**Case 2. Memo's English**

Memo speaks English like a native, but doesn't put it on his application.
- *What does he do?* He puts it first and looks for jobs that require it.


**Case 3. No diploma**

Lupita cooked for 10 years in a restaurant, but has no paper that says so.
- *What does she do?* She looks into certifying her experience with CONOCER.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Saying «everything» | They don't remember you | Be specific |
| Hiding your English | You miss opportunities | Put it first |
| Thinking it's worthless without a diploma | You don't get certified | CONOCER |
| Going without proof | They don't believe you | Photos and letters |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Memo and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. How do you present your experience? a) «I do a bit of everything» · b) Trade, years and proof · c) Only your name and the country where you worked
2. Who has a job board for repatriated people? a) The Servicio Nacional de Empleo · b) A fixer · c) No one
3. You speak English. What do you do? a) Hide it · b) Mention it only if they ask · c) Put it first
**Answers:** 1-b: specific. 2-a: the SNE. 3-c: it's in high demand.



#### Put it into practice

Write one sentence about your experience with your trade, years and what you coordinated.
**Answer:** Example: «8 years in a restaurant kitchen, I prepared 200 dishes per shift and trained two helpers».



#### Your plan

Fill in your list with three things you know how to do and gather one piece of proof for each.



### Learn more

- **Servicio Nacional de Empleo** (STPS · Spanish): https://www.empleo.gob.mx — **What to look for:** «repatriados» (repatriated people).
- **Skills certification** (CONOCER · Spanish): https://conocer.gob.mx — **What to look for:** «certifícate» (get certified).

### Key words

- *Skill:* something you know how to do well.
- *Certification:* an official paper that recognizes what you know.
- *Job board:* a list of available jobs.

### Sources

STPS, Servicio Nacional de Empleo; CONOCER; checked October 5, 2026.

---

## M7 U02. Compare offers: wages and benefits

**What you will be able to do:** Compare a formal job and an informal one by adding up what you don't see in the wage.

**To start:** Memo is offered two jobs: one for 2,400 a week with IMSS and another for 2,700 «in cash, no paperwork». Which to take seems obvious to him. In this lesson you'll see what else counts.

### The essentials (5 minutes)

#### The wage isn't everything

A formal job includes benefits: IMSS (health), Afore, aguinaldo (year-end bonus), paid vacation and Infonavit housing credit. An informal job pays only the wage.



#### What a formal job adds

| Type | Description | What it means for you |
|---|---|---|
| IMSS | Doctor, sick leave. | For you and your family. |
| Afore | Retirement savings. | Adds weeks. |
| Aguinaldo | At least 15 days' wages. | Every December. |
| Vacation | Paid days. | By law. |

#### Do the full math

A doctor's visit and medicine without IMSS can cost more than the difference in wages. And every formal week brings you closer to a pension (Module 5).



#### A one-minute case

Memo added up the aguinaldo and what he'd spend on doctors. The formal job was the better deal. He also started adding weeks.

> **Key idea:** compare the wage plus benefits, not just what you're paid each week.



#### Check your understanding

1. Besides the wage, what does a formal job include?
*Answer:* IMSS, Afore, aguinaldo, vacation and Infonavit.

2. What is the minimum aguinaldo?
*Answer:* 15 days' wages.


#### Remember

- Wage plus benefits.
- Aguinaldo: 15 days.
- Weeks toward your pension.



### Go deeper (5 more minutes)

#### Memo's aguinaldo

- Daily wage (2,400 divided by 7): **343**
- Days: **15**
- Minimum aguinaldo: **5,145**


#### Ask to be registered with IMSS

If the job is formal, the employer must register you from day one. You can check your registration on the IMSS website with your CURP.



#### Cases


**Case 1. The 300-peso difference**

Memo compares 2,400 with IMSS against 2,700 with no paperwork.
- *What does he do?* He adds up benefits and health costs before deciding.


**Case 2. «I'll register you later»**

Don Rafa's boss says he'll register him in three months.
- *What does he do?* He asks to be registered from day one and checks it.


**Case 3. No aguinaldo**

Lupita is told that at her job aguinaldo «isn't a thing».
- *What does she do?* She knows it's a right and asks PROFEDET.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Looking only at the wage | You compare wrong | Add up benefits |
| Accepting registration later | No IMSS and no weeks | From day one |
| Not checking your registration | You don't know if you're contributing | Check it |
| Giving up your rights | You lose money | Ask PROFEDET |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Memo, Don Rafa and Lupita. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What does an informal job NOT give you? a) A wage · b) IMSS and Afore · c) Pay for the hours you work
2. You earn 300 pesos a day. What is your minimum aguinaldo? a) 4,500 · b) 300 · c) 9,000
3. From when must you be registered with IMSS? a) From day one · b) After three months, once you pass the trial period · c) After a year
**Answers:** 1-b: there are no benefits. 2-a: 15 days. 3-a: from the start.



#### Put it into practice

You earn 2,100 a week. What is your daily wage?
**Answer:** 300 pesos.



#### Your plan

If you have two offers, write down for each one: wage, IMSS, aguinaldo and vacation.



### Learn more

- **Labor rights** (PROFEDET · Spanish): https://www.gob.mx/profedet — **What to look for:** «aguinaldo». Phone 800 911 7877.
- **Check your registration** (IMSS · Spanish): https://www.imss.gob.mx — **What to look for:** «semanas cotizadas» (contribution weeks).

### Key words

- *Benefits (prestaciones):* what you receive besides the wage.
- *Aguinaldo:* a yearly payment of at least 15 days' wages.
- *IMSS registration (alta):* the record of your job for social security.

### Sources

Ley Federal del Trabajo (federal labor law), aguinaldo and vacation; PROFEDET; IMSS; checked October 5, 2026.

---

## M7 U03. A small business without risking your savings

**What you will be able to do:** Test a business idea on a small scale before putting in all your money.

**To start:** Lupita wants to open a taco shop «like the ones in Houston». She got quotes for a space, a griddle and tables: 85,000 pesos, all her savings. In this lesson you'll see how to test before betting everything.

### The essentials (5 minutes)

#### Test first

Before renting a space, sell on a small scale: orders from neighbors, a stand on weekends, made to order. That way you see whether people buy and at what price.



#### Three numbers you need

| Type | Description | What it means for you |
|---|---|---|
| Cost | What it costs you to make each product. | Ingredients, gas, packaging. |
| Price | What you charge. | Higher than the cost. |
| Sales | How many you sell. | Per week. |

#### Keep business money separate

Use an account or an envelope only for the business. If you mix household money with business money, you don't know whether you're making or losing money.



#### A one-minute case

Lupita sold tacos to order for six weekends. Each taco costs her 9 pesos and she sells it for 18. She sells about 300 per weekend. Now she knows her idea works and how much she can invest.

> **Key idea:** test on a small scale, know your cost and your price, and keep the business money separate.



#### Check your understanding

1. What do you do before renting a space?
*Answer:* You test on a small scale whether people buy and at what price.

2. Why keep business money separate?
*Answer:* To know whether you're making or losing money.


#### Remember

- Test on a small scale.
- Cost, price, sales.
- Keep money separate.



### Go deeper (5 more minutes)

#### Lupita's tacos

- Price: **18**
- Cost: **9**
- She keeps per taco: **9**
- Tacos per weekend: **300**
- She keeps per weekend: **2,700**


#### To keep learning

If your idea works, the Tu Negocio, Tu Dinero, Tu Futuro program goes deeper into pricing, cash flow, SAT taxes and credit to grow.



#### Cases


**Case 1. The full taco shop**

Lupita wants to invest all her savings at once.
- *What does she do?* She sells to order first to test it.


**Case 2. The price**

Lupita doesn't know how much each taco costs her.
- *What does she do?* She adds up ingredients, gas and packaging per taco.


**Case 3. All in the same pocket**

Don Rafa uses the money from his jobs for the household without writing it down.
- *What does he do?* He keeps the business money separate in an account or envelope.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Investing everything at once | You could lose your savings | Test small |
| Not knowing your cost | You lose without noticing | Calculate it |
| Mixing money | You don't know if you profit | Separate it |
| Copying prices from there | It doesn't sell | Prices from here |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita and Don Rafa. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What do you do before investing your savings in a business? a) Test it on a small scale · b) Take out a loan · c) Rent the biggest space
2. A product costs you 25 and you sell it for 40. How much do you keep per piece? a) 65 · b) 15 · c) 40
3. Why keep business money separate? a) Just because · b) Because the law requires it of every business, even small ones · c) To know whether you're making or losing money
**Answers:** 1-a: test first. 2-b: 40 minus 25. 3-c: to see if you profit.



#### Put it into practice

You sell 120 pieces a week and keep 12 pesos per piece. How much do you keep per week?
**Answer:** 1,440 pesos.



#### Your plan

If you have an idea, write how you'll test it on a small scale, its cost, its price and where you'll keep the business money.



### Learn more

- **Starting a business** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «emprendedores» (entrepreneurs).

### Key words

- *Cost:* what it costs you to make or buy what you sell.
- *Price:* what you charge.
- *Profit:* what you keep after the cost.

### Sources

CONDUSEF, guides for entrepreneurs; checked October 5, 2026.

---


# Part 9. Module 8. Don't get scammed when you return

## M8 U01. Fake fixers

**What you will be able to do:** Recognize people who charge for no-cost procedures or keep your papers.

**To start:** Outside the reception center, a man in a vest offered to «speed up» Don Rafa's CURP, birth certificate and support for 1,500 pesos. All he had to do was leave him his original papers. In this lesson you'll see why not.

### The essentials (5 minutes)

#### Who a fake fixer is

Someone who charges you for something that has no cost or that you can do yourself, and who sometimes keeps your papers or your information. They wait outside offices and reception centers, or find you on social media.



#### Signs

| Type | Description | What it means for you |
|---|---|---|
| Charges for no-cost things | CURP, INE, support, checking your weeks. | All of that has no cost. |
| Asks for originals | So «he can take them». | Never let them go. |
| Promises speed | «I know someone». | There's no shortcut. |
| Vest or badge | Looks official. | Not enough to believe him. |

#### What to do

Go into the office and ask at the service window. If someone says they're from the government, ask for their name and verify it inside. You can do the procedures in this course yourself.



#### A one-minute case

Don Rafa didn't give him his papers. He went in, asked at the window and was told everything had no cost. He did his paperwork that same day.

> **Key idea:** if they charge you for a no-cost procedure or ask for your originals, it isn't help: it's a fake fixer.



#### Check your understanding

1. How much does it cost to get your CURP or your INE?
*Answer:* Nothing; if they charge you, be wary.

2. What do you do if someone in a vest offers help outside?
*Answer:* You go in and ask at the window.


#### Remember

- No-cost things aren't paid for.
- Keep your originals with you.
- Ask at the window.



### Go deeper (5 more minutes)

#### No-cost procedures in this course

| Procedure | Does it cost anything? |
|---|---|
| Looking up and printing your CURP | No |
| INE voter ID | No |
| Locating your Afore | No |
| Checking your weeks at IMSS | No |
| Special credit report (once a year) | No |



#### Copies, not originals

For most procedures they ask to see the original and you keep it; they make a copy. Don't leave your originals with anyone outside the service window.



#### Cases


**Case 1. The vest**

A man in a vest offers to speed everything up for 1,500.
- *What does he do?* He goes in and asks at the window.


**Case 2. The Facebook group**

In a group for repatriated people, someone offers to «get your support» with your information.
- *What does he do?* He gives no information; he applies at the program's office.


**Case 3. The originals**

Memo is asked to leave his original birth certificate «for the procedure».
- *What does he do?* He hands over a copy and keeps his original.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying for no-cost things | You lose money | Ask at the window |
| Leaving originals | Identity theft | Copies |
| Trusting the vest | Deception | Verify inside |
| Giving information on social media | Fraud | Only at offices |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. Someone charges you to process your INE. What is it? a) A fake fixer · b) Normal · c) A legal express service
2. Where do you verify whether someone is from the government? a) By their vest · b) Inside the office · c) On their business card
3. What do you leave for a procedure? a) Your originals · b) Your PIN · c) Copies, and you show the original
**Answers:** 1-a: it has no cost. 2-b: ask inside. 3-c: copies.



#### Put it into practice

A fixer charges 1,500 for three no-cost procedures. How much do you save if you do them yourself?
**Answer:** 1,500 pesos.



#### Your plan

Review the table of no-cost procedures and save it on your phone.



### Learn more

- **Fraud and fixers** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «gestores» (fixers) and «fraudes» (fraud).

### Key words

- *Fixer (gestor):* a person who does paperwork for others.
- *Original:* the real document, not the copy.
- *Service window (ventanilla):* the official place where you're served.

### Sources

CONDUSEF, alerts on fixers and fraud; SEGOB, México te Abraza; checked October 5, 2026.

---

## M8 U02. Fraud and extortion against people who return

**What you will be able to do:** Recognize the most common frauds and extortion against people who return, and decide what to do.

**To start:** Lupita got a call saying they had her brother «detained at the border» and she needed to deposit 8,000 pesos right away. She could hear someone crying. In this lesson you'll see how to act.

### The essentials (5 minutes)

#### The most common

| Type | Description | What it means for you |
|---|---|---|
| Relative «detained» | They ask for an urgent deposit. | Extortion. |
| Job with upfront payment | «Pay for the training or uniform». | Fraud. |
| Miracle investment | «Double your dollars». | Fraud. |
| «I'll process your U.S. retirement» | They ask for your information and a payment. | Fraud. |

#### The golden rule

When you get an urgent call: **hang up, breathe and call** your relative or the institution yourself, using a number you already have. Criminals use urgency so you don't think.



#### If you already paid or they threaten you

Keep the numbers and screenshots. Report it to 089 (anonymous) or at the Fiscalía (public prosecutor). If it went through a bank, tell the bank right away.



#### A one-minute case

Lupita hung up and called her brother. He was at work in Dallas. She blocked the number and reported it to 089.

> **Key idea:** when someone rushes you, hang up and call yourself; no serious person asks for urgent deposits by phone.



#### Check your understanding

1. What do you do when an urgent call asks for money?
*Answer:* I hang up and call my relative myself with a number I already have.

2. What number do you call to report extortion?
*Answer:* 089, anonymously.


#### Remember

- Hang up and call yourself.
- No urgent deposits.
- 089 to report.



### Go deeper (5 more minutes)

#### Be careful what you post

Posting that you just returned, who you live with or where you work gives information to extortionists. Check who can see your social media.



#### Real job offers

A real job doesn't charge you to hire you. If they ask for payment for training, a uniform or a test before you start, be wary.



#### Cases


**Case 1. The detained brother**

Lupita is asked for 8,000 pesos to free her brother.
- *What does she do?* She hangs up and calls her brother herself.


**Case 2. The job with a fee**

Don Rafa is offered a job if he pays 1,200 for the uniform.
- *What does he do?* He doesn't pay: a real job doesn't charge to hire you.


**Case 3. Double your dollars**

Memo is offered to double his savings in three months.
- *What does he do?* He doesn't invest: no one doubles money without risk.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Depositing out of fear | You lose money | Hang up and call yourself |
| Paying for a job | Fraud | Don't pay |
| Believing in quick profits | You lose your savings | Be wary |
| Posting too much | They find you | Protect your social media |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Don Rafa and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. You get a call: your relative is detained and they want money now. What do you do? a) Hang up and call your relative yourself · b) Deposit · c) Give your information
2. A job asks you to pay for the uniform before starting. What is it? a) Normal · b) A benefit the employer gives you to start · c) A sign of fraud
3. What number do you call to report anonymously? a) Only 911 · b) 089 · c) The number that called you
**Answers:** 1-a: verify yourself. 2-c: you don't pay to work. 3-b: 089.



#### Put it into practice

You're offered to turn 10,000 into 20,000 in three months. What do you do?
**Answer:** I don't invest; it's a sign of fraud.



#### Your plan

Agree on a code word with your family for emergencies and save 089 on your phone.



### Learn more

- **Anonymous reporting** (Government of Mexico · Spanish): 089.
- **Financial fraud** (CONDUSEF · Spanish): https://www.condusef.gob.mx — **What to look for:** «fraudes» (fraud).

### Key words

- *Extortion:* a threat to make you hand over money.
- *Anonymous report:* a report without giving your name.
- *Code word:* a family password to confirm emergencies.

### Sources

CONDUSEF, fraud alerts; Executive Secretariat of the SNSP, 089 line; checked October 5, 2026.

---

## M8 U03. Your return plan on one page

**What you will be able to do:** Bring together on a single page your papers, your account, your credit history, what you left there, your retirement and your budget.

**To start:** Don Rafa has notes in three notebooks and photos on his phone. When someone asks him «how's it going?», he doesn't know where to start. In this lesson you'll put it all on one page.

### The essentials (5 minutes)

#### Your page has six parts

| Type | Description | What it means for you |
|---|---|---|
| Papers | What you have and what's missing. | M1. |
| Account | Your CLABE and alerts. | M2. |
| Credit | Your report checked. | M3. |
| What's back there | Wages, account, taxes, retirement. | M4. |
| Retirement | Afore and weeks. | M5. |
| 90 days | Budget and work. | M6 and M7. |

#### One action per part

For each part, write the next action and a date. You don't need to solve everything today; you need to know what's next.



#### A one-minute case

Don Rafa made his page. He still needs his INE (appointment on Monday), to ask for his W-2s (this week) and to locate his Afore (already done). Now he knows where to go next.

> **Key idea:** put everything on one page with the next action and a date for each part.



#### Check your understanding

1. How many parts does your plan have?
*Answer:* Six: papers, account, credit, what's back there, retirement and 90 days.

2. What do you write in each part?
*Answer:* The next action and a date.


#### Remember

- Six parts.
- One action per part.
- With a date.



### Go deeper (5 more minutes)

#### Your return plan

| Part | How I'm doing | Next action | Date |
|---|---|---|---|
| Papers | | | |
| Account | | | |
| Credit | | | |
| What's back there | | | |
| Retirement | | | |
| 90 days | | | |



#### Review it every month

Your situation changes fast in the first months. Review your page every month and cross off what you've done.



#### Cases


**Case 1. Three notebooks**

Don Rafa has scattered notes.
- *What does he do?* He brings everything together in his one-page plan.


**Case 2. Everything today**

Lupita wants to solve all six parts in one day.
- *What does she do?* She writes the next action for each part with a date.


**Case 3. The plan in a drawer**

Memo made his plan and forgot it in a drawer.
- *What does he do?* He reviews it every month and crosses off his progress.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Scattered notes | You don't see progress | One page |
| Wanting everything today | You get overwhelmed | One action per part |
| No dates | It stays an idea | Add a date |
| Not reviewing it | It's forgotten | Every month |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Rafa, Lupita and Memo. Choose the best decision in each one; if you miss, you can try again. You earn experience points.



#### Quiz

1. What goes in each part of your plan? a) Only what you've already done · b) The next action and a date · c) A drawing of how you see yourself in a year
2. How often do you review your plan? a) Every month · b) Every five years · c) Never
3. Which of these is a part of the plan? a) Your social media · b) Your papers · c) Your vacation
**Answers:** 1-b: action and date. 2-a: every month. 3-b: papers.



#### Put it into practice

You still need your INE, your W-2s and your credit report. Write the next action for one of them with a date.
**Answer:** Example: «Go to the INE office on Monday the 12th with my birth certificate and proof of address».



#### Your plan

Fill in your one-page return plan and put a date on each next action.



### Learn more

- **Everything in the course** (Desarrolla Talento · English): review the lists from Modules 1 to 7.

### Key words

- *Plan:* a list of what you'll do and when.
- *Next action:* the next concrete step.
- *Review:* looking again at how you're doing.

### Sources

Developed by the program, based on Modules 1 to 7.

---


# Part 10. Support materials

## Welcome

**Back Home, Your Money, Your Future** — Financial well-being program for people returning from the United States to Mexico, whether deported or by their own decision: 8 modules and 24 short lessons. Hybrid format: one in-person kickoff session and the rest online. Also available in Spanish and as a bilingual group.

Version 0.1 · October 2026.

### What you'll achieve

- **Your papers:** Your list of papers in order: repatriation record, CURP, birth certificate, INE and your children's papers.
- **Your account in Mexico:** An account in your name to receive support and money, and your returnee cards used well.
- **Credit from scratch:** Your first credit history in Mexico, starting small and with no traps.
- **What you left in the United States:** Your list of what was left there: last paycheck, accounts, taxes and retirement.
- **Your Afore, your IMSS and your weeks:** Your contribution weeks checked and your Afore located.
- **Your first 90 days:** Your return budget for the first three months.
- **Work or a business with what you know how to do:** Your plan to use what you know how to do: a job, a trade or a small business.
- **Don't get scammed when you return:** Your protocol against fake fixers, fraud and extortion targeting people who return.

### How each lesson works

| Part | What you'll find |
|---|---|
| **Start** | A short situation and what you'll achieve. |
| **The essentials** | What you must know, with the most common mistakes. |
| **Go deeper** | Math, cases and more facts, if you want to know more. |
| **Practice** | «What would you do?», three questions and your plan for this week. |

Each lesson takes **8 to 8 minutes** including practice. There are 24 lessons in 8 parts. Each part ends with a self-assessment: you pass with 70% and can try as many times as you want.

### The characters

- **Don Rafa:** 52 years old. Worked 18 years in construction in Texas. Deported in March; went back to Michoacán.
- **Lupita:** 38 years old. Returned by her own decision to Guanajuato with two U.S.-born children.
- **Memo:** 24 years old. Arrived in the U.S. at age 6; returned to Puebla and barely knows Mexico.
- **Chayo:** 45 years old. Lives in Oaxaca; received remittances from her husband, who just returned.

### Program rules

1. **We'll never ask for personal data**, passwords, PINs, your CURP or real amounts.
2. **We don't sell you anything** or recommend institutions: we teach you to verify them.
3. **Your information is yours.** If an organization offers you the course, it doesn't receive your personal or financial data.
4. **No immigration or legal advice is given:** participants are referred to consulates, the Embassy and public offices.

### Facts change

The program's facts were checked on **October 5, 2026** and each lesson lists its sources. Before deciding, check the current information on the official site.

### Points, badges and certificate

You earn points for each activity and there are 8 badges. When you pass all the self-assessments you get the **Complete plan** badge and your **certificate of completion**. It's an educational recognition, not a license or official accreditation.


## Integrated cases

The cases use made-up data. Solve each case before opening the key.

### E1. Don Rafa's first week (Modules 1 and 2)

**Data.** Don Rafa arrived with his repatriation record and the Tarjeta Bienestar Paisano with 2,000 pesos. The bus to his town costs 650, his birth certificate and copies 250, and food for the week 600. Outside the center, a man charges 500 to «get his CURP».

**Tasks.**

1. How much is left of the 2,000?
2. Does he pay the man for the CURP?
3. Which card does his son use to send him money from Dallas?
4. Which account does he ask for at the bank, and what does he check first?

**Key.**

- 2,000 minus 1,500: 500. The support comes only once.
- No: looking up and printing the CURP on gob.mx has no cost.
- The Tarjeta FINABIEN Paisano, which works as an account.
- The basic account; he checks the institution in CONDUSEF's SIPRES and asks for the summary sheet.

### E2. What was left in Texas (Modules 3 and 4)

**Data.** His boss owes Don Rafa a week: 900 dollars. His account there has 1,400 dollars and charges 12 a month. 2,400 dollars in taxes were withheld last year and he owed 1,700. An «advisor» offers him «good credit in Mexico» if he pays 400 pesos for his report.

**Tasks.**

1. What does he do about the week he's owed?
2. How much does he lose in a year if he leaves the account forgotten?
3. How much would his refund be?
4. What does he do about the credit report?

**Key.**

- He asks for it by deposit or by check to someone he trusts; the consulate guides him if he isn't paid.
- 12 times 12: 144 dollars.
- 2,400 minus 1,700: 700 dollars.
- He requests it at no cost on the official website, once a year from each bureau; in Mexico he starts from zero.

### E3. Lupita's weeks (Modules 5 and 6)

**Data.** Lupita worked in Mexico from 2003 to 2007 with IMSS (about 210 weeks). Now 9,000 comes in each month and her basics are 7,600. Her family asks her for 1,500 for a welcome party.

**Tasks.**

1. Which law applies to her, and how many weeks does it require in 2026?
2. How many is she missing?
3. How much is left each month after the basics?
4. What does she say about the party?

**Key.**

- Ley 97, because she started after July 1997: 875 weeks in 2026.
- 875 minus 210: 665.
- 9,000 minus 7,600: 1,400.
- She suggests something simple with a cap that doesn't put her 90 days at risk.

### E4. Memo's job (Modules 7 and 8)

**Data.** Memo is offered 2,400 a week with IMSS or 2,700 in cash with no paperwork. Another «job» asks him for 1,200 for the uniform before starting. He gets a call: «We have your cousin at the border, deposit 8,000».

**Tasks.**

1. What is his minimum aguinaldo at the formal job?
2. What else does the formal job add?
3. What does he do about the job that charges for the uniform?
4. What does he do about the call?

**Key.**

- 2,400 divided by 7 is about 343 a day; times 15 days: about 5,145.
- IMSS, Afore, vacation and Infonavit; and weeks toward his pension.
- He doesn't pay: a real job doesn't charge to hire you.
- He hangs up and calls his cousin with a number he already has; he reports it to 089.


## Practice exercises

Solve each exercise. The answers are at the end.

| Key | Lesson | Exercise |
|---|---|---|
| P01 | M1 U01 | You have your record and your CURP, but no birth certificate or INE. Which two papers are missing from the basic list? |
| P02 | M1 U02 | You have your birth certificate and your repatriation record. You live with your mom and the electric bill is in her name. What do you need to confirm before going to the office? |
| P03 | M1 U03 | You have two U.S.-born children with birth certificates. Which two Mexican papers will they have when the process is done? |
| P04 | M2 U01 | You received 2,000 pesos. The bus costs 650 and your papers 300. How much is left? |
| P05 | M2 U02 | An account charges 85 pesos a month. How much do you pay in a year? |
| P06 | M2 U03 | How many digits does a CLABE have? |
| P07 | M3 U01 | You requested your Buró report in January. From what month can you request it again at no cost? |
| P08 | M3 U02 | Your limit is 4,500. How much is one third? |
| P09 | M3 U03 | You're offered 12 weekly payments of 450 for a phone that costs 3,900 in cash. How much extra do you pay? |
| P10 | M4 U01 | Your account back there charges 12 dollars a month and has 150. In how many months will it be empty? |
| P11 | M4 U02 | 2,400 dollars were withheld and what you owed in taxes was 1,700. How much would your refund be? |
| P12 | M4 U03 | You have 8,000 dollars in your 401(k). If 30% in total is withheld and penalized, how much would you receive? |
| P13 | M5 U01 | Besides the balance, what two things do you check when you find your Afore? |
| P14 | M5 U02 | You have 700 weeks and you're under Ley 97. How many are you missing in 2026? |
| P15 | M5 U03 | You contribute 300 pesos a month. How much in two years, not counting returns? |
| P16 | M6 U01 | 9,000 comes in a month and you spend 7,200 on the basics. How much is left? |
| P17 | M6 U02 | You have 9,000 in savings and need 2,500 a month to cover your expenses. How much can you give away over three months without falling short? |
| P18 | M6 U03 | 10,500 comes in and the basics cost 9,200. How much is left for everything else? |
| P19 | M7 U01 | Write one sentence about your experience with your trade, years and what you coordinated. |
| P20 | M7 U02 | You earn 2,100 a week. What is your daily wage? |
| P21 | M7 U03 | You sell 120 pieces a week and keep 12 pesos per piece. How much do you keep per week? |
| P22 | M8 U01 | A fixer charges 1,500 for three no-cost procedures. How much do you save if you do them yourself? |
| P23 | M8 U02 | You're offered to turn 10,000 into 20,000 in three months. What do you do? |
| P24 | M8 U03 | You still need your INE, your W-2s and your credit report. Write the next action for one of them with a date. |

### Answers

- **P01:** The birth certificate and the INE.
- **P02:** Whether they accept your mom's bill as proof of address.
- **P03:** A Mexican birth certificate and a CURP.
- **P04:** 1,050 pesos.
- **P05:** 1,020 pesos.
- **P06:** 18.
- **P07:** From January of the next year.
- **P08:** 1,500 pesos.
- **P09:** 1,500 pesos (12 times 450 is 5,400).
- **P10:** In 13 months (12.5 rounded up).
- **P11:** 700 dollars.
- **P12:** 5,600 dollars.
- **P13:** Your contact details and your beneficiaries.
- **P14:** 175.
- **P15:** 7,200 pesos.
- **P16:** 1,800 pesos.
- **P17:** 1,500 pesos.
- **P18:** 1,300 pesos.
- **P19:** Example: «8 years in a restaurant kitchen, I prepared 200 dishes per shift and trained two helpers».
- **P20:** 300 pesos.
- **P21:** 1,440 pesos.
- **P22:** 1,500 pesos.
- **P23:** I don't invest; it's a sign of fraud.
- **P24:** Example: «Go to the INE office on Monday the 12th with my birth certificate and proof of address».


## Glossary

Plain-language definitions of the course words, grouped by module.

### Your papers

- **Apostille:** a seal that recognizes a foreign document.
- **Birth registration:** recording in Mexico a birth that happened abroad.
- **Certified copy:** an official copy that counts as the original.
- **CURP:** Mexico's unique population ID code.
- **Dual citizenship:** being a citizen of two countries at once.
- **INE office (módulo):** the office where you apply for the INE.
- **Proof of address:** a paper that shows where you live.
- **Record (constancia):** an official paper that proves something.
- **Repatriation:** a person's return to their country.

### Your account in Mexico

- **Basic account:** an account with no opening or maintenance fees.
- **CLABE:** the 18-digit number for transfers.
- **Fee:** a charge for a service.
- **One-time support:** money given only once.
- **PIN:** your card's secret number.
- **Reference number (folio):** the number that proves your claim.
- **Remittance:** money a relative sends from another country.
- **SPEI:** the system for transfers between banks.
- **Summary sheet (carátula):** the summary of the contract.

### Credit from scratch

- **CAT:** the credit's total annual cost.
- **Collection harassment:** illegal pressure to make you pay.
- **Credit bureau:** an authorized company that keeps that record.
- **Credit history:** a record of how you've repaid what you borrowed.
- **Credit limit:** the most they'll lend you.
- **Minimum payment:** the least you can pay without being late; it generates interest.
- **Special report:** your full history, at no cost once a year.
- **Term:** the time you have to pay.
- **Total cost:** everything you pay, minus what you borrowed.

### What you left in the United States

- **401(k):** a retirement plan from a U.S. job.
- **Consulate:** Mexico's office in another country.
- **Last paycheck:** wages still owed when a job ends.
- **Penalty:** an extra charge for withdrawing early.
- **Refund:** what you get back if you paid too much.
- **Social Security credit:** a unit that counts the work you paid into.
- **Unclaimed property:** forgotten money the state holds.
- **W-2:** a form with your yearly wages and withholdings.
- **Withholding:** tax taken out of each paycheck.

### Your Afore, your IMSS and your weeks

- **Afore:** the company that manages your retirement savings.
- **Automatic debit:** an automatic charge to your account.
- **Beneficiary:** the person who receives your savings if you pass away.
- **Contribution weeks:** weeks worked with IMSS.
- **Ley 73 and Ley 97:** pension rules based on when you started contributing.
- **NSS:** social security number.
- **Return:** what your savings earn over time.
- **Self-employed worker:** someone who works without a boss.
- **Voluntary contribution:** money you add to your Afore yourself.

### Your first 90 days

- **Budget:** a plan for what comes in and goes out.
- **Cap:** the most you'll spend.
- **Certain income:** money you know will arrive.
- **Cut:** an expense you remove or reduce.
- **Limit:** how far you can go without harming yourself.
- **Little savings (guardadito):** small savings for the unexpected.
- **Obligation:** an expense you feel you're expected to make.
- **Scholarship:** support to study.

### Work or a business with what you know how to do

- **Aguinaldo:** a yearly payment of at least 15 days' wages.
- **Benefits (prestaciones):** what you receive besides the wage.
- **Certification:** an official paper that recognizes what you know.
- **Cost:** what it costs you to make or buy what you sell.
- **IMSS registration (alta):** the record of your job for social security.
- **Job board:** a list of available jobs.
- **Price:** what you charge.
- **Profit:** what you keep after the cost.
- **Skill:** something you know how to do well.

### Don't get scammed when you return

- **Anonymous report:** a report without giving your name.
- **Code word:** a family password to confirm emergencies.
- **Extortion:** a threat to make you hand over money.
- **Fixer (gestor):** a person who does paperwork for others.
- **Next action:** the next concrete step.
- **Original:** the real document, not the copy.
- **Plan:** a list of what you'll do and when.
- **Review:** looking again at how you're doing.
- **Service window (ventanilla):** the official place where you're served.


## Where to find help

Official, no-cost sources that appear in the lessons. Information checked on October 5, 2026; confirm it on the official site.

| Topic | Where | What to look for | Lessons |
|---|---|---|---|
| Look up your CURP | Government of Mexico: https://www.gob.mx/curp | «consulta e impresión» (look up and print) | M1 U01 |
| México te Abraza | SEGOB: https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza | «servicios» (services) | M1 U01, M2 U01 |
| Birth certificate online | Government of Mexico: https://www.gob.mx/actas | «copia certificada» (certified copy) | M1 U02 |
| ID requirements | INE: https://www.ine.mx | «requisitos credencial para votar» (voter ID requirements) | M1 U02 |
| Dual citizenship | SRE: https://www.gob.mx/sre | «inscripción de nacimiento doble nacionalidad» (birth registration, dual citizenship) | M1 U03 |
| School enrollment | SEP: https://www.gob.mx/sep | «inscripción niñas y niños migrantes» (enrollment of migrant children) | M1 U03 |
| FINABIEN | Government of Mexico: https://www.gob.mx/finabien | «Tarjeta FINABIEN Paisano» | M2 U01 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | the institution's name | M2 U02 |
| Basic accounts | CONDUSEF: https://www.condusef.gob.mx | «cuenta básica» (basic account) | M2 U02 |
| Claims | CONDUSEF: https://www.condusef.gob.mx | «presentar una reclamación» (file a claim). Phone 55 5340 0999 | M2 U03 |
| Reporte de Crédito Especial | Buró de Crédito: https://www.burodecredito.com.mx | «reporte de crédito especial» (special credit report) | M3 U01 |
| Credit report | Círculo de Crédito: https://www.circulodecredito.com.mx | «reporte de crédito» (credit report) | M3 U01 |
| Calculators and comparison tools | CONDUSEF: https://www.condusef.gob.mx | «simulador tarjeta de crédito» (credit card calculator) | M3 U02 |
| Loan apps | CONDUSEF: https://www.condusef.gob.mx | «apps de préstamos» (loan apps) and «SIPRES» | M3 U03 |
| Consular protection | SRE: https://consulmex.sre.gob.mx | «protección» (protection) and the consulate for the city where you worked | M4 U01, M4 U02 |
| Unclaimed property | NAUPA: https://unclaimed.org | the state where you lived | M4 U01 |
| Refunds | IRS: https://www.irs.gov | «refund» and «taxpayers living abroad» | M4 U02 |
| Federal Benefits Unit | U.S. Embassy in Mexico: https://mx.usembassy.gov | «Federal Benefits Unit» | M4 U03 |
| Social Security | SSA: https://www.ssa.gov | «payments outside the U.S.» | M4 U03 |
| Locate your Afore | CONSAR: https://www.gob.mx/consar | «localiza tu Afore» (locate your Afore) and «AforeMóvil». SARTEL 55 1328 5000 | M5 U01 |
| Contribution weeks certificate | IMSS: https://serviciosdigitales.imss.gob.mx | «semanas cotizadas» (contribution weeks) | M5 U02 |
| Voluntary savings | CONSAR: https://www.gob.mx/consar | «ahorro voluntario» (voluntary savings) | M5 U03 |
| Self-employed workers | IMSS: https://www.imss.gob.mx | «personas trabajadoras independientes» (self-employed workers) | M5 U03 |
| Budgeting | CONDUSEF: https://www.condusef.gob.mx | «presupuesto personal» (personal budget) | M6 U01 |
| Family finances | CONDUSEF: https://www.condusef.gob.mx | «prestar dinero a familiares» (lending money to relatives) | M6 U02 |
| Programas para el Bienestar | Government of Mexico: https://programasparaelbienestar.gob.mx | «becas» (scholarships) and «requisitos» (requirements) | M6 U03 |
| Servicio Nacional de Empleo | STPS: https://www.empleo.gob.mx | «repatriados» (repatriated people) | M7 U01 |
| Skills certification | CONOCER: https://conocer.gob.mx | «certifícate» (get certified) | M7 U01 |
| Labor rights | PROFEDET: https://www.gob.mx/profedet | «aguinaldo». Phone 800 911 7877 | M7 U02 |
| Check your registration | IMSS: https://www.imss.gob.mx | «semanas cotizadas» (contribution weeks) | M7 U02 |
| Starting a business | CONDUSEF: https://www.condusef.gob.mx | «emprendedores» (entrepreneurs) | M7 U03 |
| Fraud and fixers | CONDUSEF: https://www.condusef.gob.mx | «gestores» (fixers) and «fraudes» (fraud) | M8 U01 |
| Anonymous reporting | Government of Mexico: 089 | — | M8 U02 |
| Financial fraud | CONDUSEF: https://www.condusef.gob.mx | «fraudes» (fraud) | M8 U02 |

---

## Frequently asked questions

**Do I have to give real information?** No. Use made-up or rounded numbers; the course never asks for personal data.

**Does the course lend me money or recommend an institution?** No. It teaches you to compare and to verify in CONDUSEF's SIPRES.

**Can someone charge me for the procedures in the course?** The official procedures we cover have no cost. If someone charges you for them, be wary and ask at the official service window.

**Can I take the course on my phone?** Yes. It's made for that.

**Is the certificate officially valid?** It's an educational recognition that can be verified online. It's not a license or official accreditation.

**Where do I complain if a financial institution overcharges me?** First at the institution, with a reference number; if they don't solve it, at CONDUSEF: 55 5340 0999.

**What if I'm going through a very hard time?** Call Línea de la Vida: 800 911 2000, no cost, 24 hours a day (Spanish).


## References

Sources we used in the course, checked on October 5, 2026.

### Your papers

- **M1 U01 · Your repatriation record and your CURP: the first two papers.** SEGOB, México te Abraza; INM, Record of Reception of Repatriated Mexicans; checked October 5, 2026.
- **M1 U02 · Your birth certificate and your INE.** INE, requirements for the voter ID; Government of Mexico, birth certificates online; checked October 5, 2026.
- **M1 U03 · Papers for your children born in the United States.** SRE, dual citizenship; SEP, enrollment rules for migrant children; checked October 5, 2026.

### Your account in Mexico

- **M2 U01 · Your returnee cards.** SEGOB, México te Abraza; Ministry of Welfare, Tarjeta Bienestar Paisano; FINABIEN, Tarjeta FINABIEN Paisano; checked October 5, 2026.
- **M2 U02 · Choose an account with no fees.** CONDUSEF, basic accounts and SIPRES; checked October 5, 2026.
- **M2 U03 · Getting paid, paying and disputing.** CONDUSEF, claims; Banco de México, SPEI; checked October 5, 2026.

### Credit from scratch

- **M3 U01 · Your U.S. credit history doesn't count here.** Buró de Crédito and Círculo de Crédito, special report; CONDUSEF; checked October 5, 2026.
- **M3 U02 · Start small and pay on time.** CONDUSEF, credit cards and CAT; Banco de México; checked October 5, 2026.
- **M3 U03 · «No credit check» loans and apps that overcharge.** CONDUSEF, alerts on loan apps and debt collection; checked October 5, 2026.

### What you left in the United States

- **M4 U01 · Your last paycheck and your account back there.** SRE, consular protection; NAUPA, unclaimed property; checked October 5, 2026.
- **M4 U02 · Your U.S. taxes.** IRS, refunds and the deadline to claim them; checked October 5, 2026.
- **M4 U03 · Your U.S. retirement: 401(k) and Social Security.** IRS, early withdrawals from retirement plans; SSA, payments outside the U.S.; checked October 5, 2026.

### Your Afore, your IMSS and your weeks

- **M5 U01 · Do you have an Afore? Find it.** CONSAR, account location and AforeMóvil; checked October 5, 2026.
- **M5 U02 · Your contribution weeks.** IMSS, contribution weeks certificate and Ley 73 and Ley 97 pension requirements; checked October 5, 2026.
- **M5 U03 · Save for retirement even if you're self-employed.** CONSAR, voluntary savings; IMSS, enrollment of self-employed workers; checked October 5, 2026.

### Your first 90 days

- **M6 U01 · Think in pesos: your return budget.** CONDUSEF, budgeting tools; checked October 5, 2026.
- **M6 U02 · Welcome-home obligations.** CONDUSEF, recommendations on loans between relatives; checked October 5, 2026.
- **M6 U03 · When the remittances stop.** Banco de México, 2025 remittance income; Ministry of Welfare; checked October 5, 2026.

### Work or a business with what you know how to do

- **M7 U01 · What you know how to do has value.** STPS, Servicio Nacional de Empleo; CONOCER; checked October 5, 2026.
- **M7 U02 · Compare offers: wages and benefits.** Ley Federal del Trabajo (federal labor law), aguinaldo and vacation; PROFEDET; IMSS; checked October 5, 2026.
- **M7 U03 · A small business without risking your savings.** CONDUSEF, guides for entrepreneurs; checked October 5, 2026.

### Don't get scammed when you return

- **M8 U01 · Fake fixers.** CONDUSEF, alerts on fixers and fraud; SEGOB, México te Abraza; checked October 5, 2026.
- **M8 U02 · Fraud and extortion against people who return.** CONDUSEF, fraud alerts; Executive Secretariat of the SNSP, 089 line; checked October 5, 2026.
- **M8 U03 · Your return plan on one page.** Developed by the program, based on Modules 1 to 7.


# Part 11. H5P activities "What would you do?"

One per lesson. The option marked ✔ is correct; on the platform options appear in random order.

## M1 U01. Your repatriation record and your CURP: the first two papers

**Case 1. Don Rafa's paper.** His brother tells him to throw away the record because he «is already in Mexico». **What does he do?**

- ✔ He keeps it with his other papers, because it's his temporary ID.
- He throws it away, because he won't need it in Mexico.
- He gives it to his brother to keep at his house.

**Case 2. Memo's CURP.** Memo doesn't know if he has a CURP; he left for the U.S. when he was 6. **What does he do?**

- ✔ He looks it up on gob.mx with his name and date of birth.
- He pays an acquaintance to get him a new CURP.
- He waits for it to arrive by mail at his aunt's house.

**Case 3. The «fixer» at the plaza.** A man offers to get Lupita's CURP for 500 pesos. **What does she do?**

- ✔ He doesn't pay, because on gob.mx the lookup and printout have no cost.
- He pays the 500 pesos so his CURP comes out faster.
- He gives his information and pays half up front.

## M1 U02. Your birth certificate and your INE

**Case 1. The Texas license.** Chayo's husband wants to open an account with his Texas driver's license. **What does he do?**

- ✔ He applies for his INE with his birth certificate and proof of address.
- He insists on his Texas license, because it also has a photo.
- He asks Chayo to open the account in her name.

**Case 2. No bills in his name.** Memo lives with his aunt and no bill is in his name. **What does he do?**

- ✔ He asks at the office whether they accept his aunt's bill or witnesses.
- He waits until he rents his own house to have bills.
- He uses an electricity bill he found in the street.

**Case 3. The paid appointment.** A website asks for 300 pesos to «book an appointment» at the INE. **What does he do?**

- ✔ He doesn't pay: the appointment and the card have no cost.
- He pays the 300 pesos to secure an appointment this week.
- He gives his information on the website and pays later.

## M1 U03. Papers for your children born in the United States

**Case 1. Lupita's school.** She's told there's no spot for her children without a CURP. **What does she do?**

- ✔ She asks for enrollment while her children are being registered.
- She keeps her children home until they have their CURP.
- She enrolls them with a nephew's CURP in the meantime.

**Case 2. The original certificate.** Lupita only has a plain copy of the birth certificate. **What does she do?**

- ✔ She asks the Civil Registry whether they accept that copy or how to get a certified one.
- She makes several photocopies of the plain copy and brings them.
- She gives up on the procedure because she doesn't have the original.

**Case 3. The expensive translation.** She's offered a translation of the certificates for 2,000 pesos each. **What does she do?**

- ✔ She first asks whether her state requires a translation.
- She pays the 2,000 per certificate so she doesn't lose time.
- She translates the certificates with a phone app and signs them.

## M2 U01. Your returnee cards

**Case 1. «More every month».** Don Rafa is told the support repeats every month. **What does he do?**

- ✔ He plans with 2,000 pesos, one time only.
- He spends it all, expecting another deposit next month.
- He borrows money counting on next month's deposit.

**Case 2. The son in Dallas.** Don Rafa's son wants to send him money every two weeks. **What does he do?**

- ✔ He uses his Tarjeta FINABIEN Paisano, which works as an account, to receive it.
- He asks his son to send it in cash with an acquaintance who travels.
- He asks his son to deposit it on the Tarjeta Bienestar Paisano.

**Case 3. The call «from the program».** Someone calls «from the program» to «activate» the card with his PIN. **What does he do?**

- ✔ He hangs up: no one from the program asks for the PIN.
- He gives the PIN because otherwise they could take away the support.
- He gives only the first two digits of the PIN.

## M2 U02. Choose an account with no fees

**Case 1. The minimum balance.** Lupita is offered an account with a gold card and a 3,000-peso minimum balance. **What does she do?**

- ✔ She asks for the basic account, with no minimum balance.
- She takes the gold card because it looks more serious at the bank.
- She opens both accounts to have options.

**Case 2. The town savings box.** Chayo is offered a place to keep her money that pays 4% a month. **What does she do?**

- ✔ She looks up the savings box in CONDUSEF's SIPRES before depositing a peso.
- She deposits all her savings because it pays 4% every month.
- She deposits half to test whether it's trustworthy.

**Case 3. No contract.** Memo signed and didn't get a copy. **What does he do?**

- ✔ He asks for his contract and the summary sheet.
- He trusts what they told him out loud at the branch.
- He takes a photo of the branch's ad just in case.

## M2 U03. Getting paid, paying and disputing

**Case 1. Memo's charge.** He sees 1,800 pesos he didn't spend. **What does he do?**

- ✔ He blocks the card, gets a reference number and disputes it.
- He waits for the next statement to see if it fixes itself.
- He leaves it, because disputing takes too long.

**Case 2. The CLABE for the boss.** Don Rafa's boss asks for his details to pay him. **What does he do?**

- ✔ He gives his 18-digit CLABE and nothing else.
- He gives his PIN so the boss can deposit without errors.
- He lends his card so the boss can register it on payroll.

**Case 3. «That's just how Mexico is».** A friend tells Memo not to complain because «they never give it back». **What does he do?**

- ✔ He disputes it and, if they don't solve it, goes to CONDUSEF.
- He doesn't dispute it, because his friend says they never give it back.
- He posts his complaint on social media and waits.

## M3 U01. Your U.S. credit history doesn't count here

**Case 1. «You don't show up».** Don Rafa is told he has no history. **What does he do?**

- ✔ He requests his report and understands he starts from zero.
- He insists that his good Texas credit has to count here.
- He takes out an app loan to show up quickly.

**Case 2. Someone else's loan.** His cousin's report shows an app he never used. **What does he do?**

- ✔ He files a dispute with the credit bureau.
- He pays the app loan so he won't get into trouble.
- He ignores it because he didn't ask for it.

**Case 3. The paid report.** A website charges Memo 400 pesos for his report. **What does he do?**

- ✔ He requests it at no cost on the official website.
- He pays the 400 pesos on that website because it's faster.
- He asks a friend for their login to see the report.

## M3 U02. Start small and pay on time

**Case 1. The 20,000 limit.** Memo is offered a 20,000 limit; he earns 9,000. **What does he do?**

- ✔ He asks for a low limit he can pay.
- He accepts the 20,000 limit in case he needs it someday.
- He accepts and uses the whole limit to build history fast.

**Case 2. The minimum payment.** Lupita's statement says «minimum payment 250». **What does she do?**

- ✔ She pays the month's full balance so she pays no interest.
- She pays the minimum every month, because then she's never late.
- She pays whenever she remembers, even if it's late.

**Case 3. Three cards at once.** Don Rafa is offered three cards in one week. **What does he do?**

- ✔ He starts with just one and pays it on time.
- He accepts all three cards to build more history faster.
- He accepts two and cancels the third one later.

## M3 U03. «No credit check» loans and apps that overcharge

**Case 1. The 10 minutes.** An app promises Lupita 5,000 in 10 minutes with no paperwork. **What does she do?**

- ✔ She doesn't use it: they won't tell her the total.
- She accepts because the money arrives in 10 minutes and it's urgent.
- She accepts and pays only what she can each week.

**Case 2. The contacts.** The app asks for access to Memo's phone book. **What does he do?**

- ✔ He denies access to his contacts and deletes the app.
- He gives permission because the app doesn't work without it.
- He gives permission, but first deletes some contacts.

**Case 3. The store loan.** The furniture store offers Chayo «tiny» payments. **What does she do?**

- ✔ She adds up all the payments and compares.
- She signs because the weekly payments are tiny.
- She signs now and asks the total later.

## M4 U01. Your last paycheck and your account back there

**Case 1. Payday.** Don Rafa's boss owes him a week. **What does he do?**

- ✔ He asks for his pay by deposit or by check to someone he trusts.
- He writes it off, because he's no longer in the United States.
- He gives his bank password to a coworker to collect it.

**Case 2. The forgotten account.** Lupita left 300 dollars in an account a year ago. **What does she do?**

- ✔ She checks for fees and decides what to do.
- She leaves it forgotten, because it's only a few dollars.
- She shares her password with her cousin so she can close it.

**Case 3. «I'll get your money».** Someone offers to recover Memo's money if he gives them his bank password. **What does he do?**

- ✔ He doesn't give his password and does it himself.
- He gives his password so they recover the money faster.
- He pays up front so they start the process.

## M4 U02. Your U.S. taxes

**Case 1. «What for».** Lupita never filed. **What does she do?**

- ✔ She asks for her W-2s and checks for a refund.
- She drops it, because she can't file from Mexico anymore.
- She waits for the IRS to find her and pay her.

**Case 2. No W-2.** Don Rafa doesn't have his forms. **What does he do?**

- ✔ He asks his employer, or the IRS with his work number.
- He makes up the amounts from memory so he doesn't lose time.
- He gives up on filing because he doesn't have the forms.

**Case 3. The miracle preparer.** Memo is offered «double the refund» for a 30% fee. **What does he do?**

- ✔ He looks for no-cost help and doesn't make up information.
- He agrees to pay 30% in exchange for double the refund.
- He agrees if they promise no one will check.

## M4 U03. Your U.S. retirement: 401(k) and Social Security

**Case 1. «The government keeps it».** Memo is told to take it all out now. **What does he do?**

- ✔ He asks the administrator how much would be withheld before deciding.
- He takes it all out this week for fear they'll take it away.
- He forgets about it, because he no longer lives in the U.S.

**Case 2. Ten years in construction.** Don Rafa worked 10 years with a Social Security number. **What does he do?**

- ✔ He asks the Embassy about his case.
- He assumes he lost everything when he returned to Mexico.
- He pays a fixer to process it for him.

**Case 3. The WhatsApp advisor.** Someone messages Lupita offering to «move her retirement» if she gives her information. **What does she do?**

- ✔ She talks directly with the administrator.
- She gives her information to the WhatsApp advisor to move it.
- She sends a photo of her statement to the advisor.

## M5 U01. Do you have an Afore? Find it

**Case 1. «It got lost».** Don Rafa thinks he lost his factory savings. **What does he do?**

- ✔ He looks for it with his CURP in AforeMóvil.
- He writes it off, because he was gone for many years.
- He pays a fixer to look for it.

**Case 2. Never formal.** Memo never worked formally in Mexico. **What does he do?**

- ✔ He opens his Afore with his CURP in the app, even though he's self-employed.
- He waits until he has a boss to think about retirement.
- He saves for retirement in a can at home.

**Case 3. The Afore fixer.** Chayo is offered help to «get out» her husband's Afore for a fee. **What does she do?**

- ✔ She doesn't pay: the lookup has no cost.
- She pays the fixer's fee so she doesn't have to struggle.
- She gives the fixer her husband's CURP so he can get started.

## M5 U02. Your contribution weeks

**Case 1. «He can't get it anymore».** Chayo is told her husband lost everything. **What does she do?**

- ✔ They check his weeks on the IMSS website with his CURP.
- They write off the weeks, because he was gone for many years.
- They pay a fixer to recover them.

**Case 2. Which law?.** Don Rafa started formal work in 2001. **What does he do?**

- ✔ He calculates how many he's missing under Ley 97.
- He assumes it's Ley 73, because it requires fewer weeks.
- He checks nothing, because he still has a long way to go.

**Case 3. Missing weeks.** Don Rafa is missing more than 500 weeks. **What does he do?**

- ✔ He looks into contributing with a formal job or on his own.
- He gives up, because he's missing more than 500 weeks.
- He waits until he turns 60 to see what happens.

## M5 U03. Save for retirement even if you're self-employed

**Case 1. «It's not for me».** Don Rafa thinks that without a boss he can't save for retirement. **What does he do?**

- ✔ He contributes to his Afore every two weeks at the store, from 50 pesos.
- He decides retirement isn't for him anymore, because he has no boss.
- He waits until he has a boss to start saving.

**Case 2. No medical care.** Lupita sells food and doesn't have IMSS. **What does she do?**

- ✔ She checks how to enroll as self-employed.
- She goes without medical care, because she has no boss.
- She uses a cousin's card when she gets sick.

**Case 3. Saving with an acquaintance.** An acquaintance offers to keep Memo's retirement savings «with good interest». **What does he do?**

- ✔ He saves in his Afore, in his name.
- He gives his savings to the acquaintance, who offers more interest.
- He splits his savings between the acquaintance and the Afore.

## M6 U01. Think in pesos: your return budget

**Case 1. The 18 dollars.** Memo compares his pay there with his pay here. **What does he do?**

- ✔ He makes his budget in pesos.
- He gets discouraged and decides not to do the math for now.
- He does his math in dollars to compare with over there.

**Case 2. The promised job.** Don Rafa is promised a job «in a month». **What does he do?**

- ✔ He doesn't count that wage in his budget until it's certain.
- He counts all of it from now on, because they promised it.
- He borrows money counting on that wage.

**Case 3. Everything in the first month.** Lupita wants to spend all her savings furnishing the house. **What does she do?**

- ✔ She spreads her savings over three months.
- She spends it all on furniture, so the house is ready.
- She spends half on furniture and sees what happens.

## M6 U02. Welcome-home obligations

**Case 1. The party.** Don Rafa's family wants a party he would pay for. **What does he do?**

- ✔ He suggests something simple with a cap.
- He pays for whatever party they want, because that's the family custom.
- He borrows money for the party.

**Case 2. The compadre.** His compadre asks for 1,500 «since he's back from over there». **What does he do?**

- ✔ He kindly says: «Not right now; when I have a job, we'll see».
- He lends the 1,500 so he doesn't look bad with his compadre.
- He lends half so he doesn't look bad.

**Case 3. Lupita's mother.** Lupita wants to help her mother every month. **What does she do?**

- ✔ She decides a fixed amount she can give.
- She gives whatever her mother asks each month, even if she falls short.
- She gives nothing even though she can.

## M6 U03. When the remittances stop

**Case 1. No remittance.** Chayo no longer receives the 300 dollars. **What does she do?**

- ✔ She makes a new budget with her husband.
- They keep spending the same, hoping there'll be work soon.
- They take out a loan to keep things the same.

**Case 2. Cable TV and school.** There isn't enough for everything. **What does she do?**

- ✔ They cut what isn't basic and protect school.
- They take their daughter out of school while they settle in.
- They cut food and keep cable TV.

**Case 3. The scholarship.** Her daughter could get a scholarship and they haven't applied. **What does she do?**

- ✔ She checks the scholarship requirements and applies for her daughter.
- She doesn't apply, because she thinks they won't get anything.
- She pays someone to apply for it.

## M7 U01. What you know how to do has value

**Case 1. «I do a bit of everything».** Don Rafa doesn't say what he knows how to do. **What does he do?**

- ✔ He writes his list with trade, years and proof.
- He keeps saying «I do a bit of everything», so he seems to know more.
- He stops looking for work for a while.

**Case 2. Memo's English.** Memo speaks English like a native, but doesn't put it on his application. **What does he do?**

- ✔ He puts English first and looks for jobs that require it.
- He leaves English off the application so he doesn't seem boastful.
- He mentions it only if they ask.

**Case 3. No diploma.** Lupita cooked for 10 years in a restaurant, but has no paper that says so. **What does she do?**

- ✔ She looks into getting certified with CONOCER.
- She stops applying to kitchens because she has no diploma.
- She buys a diploma online.

## M7 U02. Compare offers: wages and benefits

**Case 1. The 300-peso difference.** Memo compares 2,400 with IMSS against 2,700 with no paperwork. **What does he do?**

- ✔ He adds up benefits and health costs before deciding.
- He takes the 2,700 one without thinking, because it pays more each week.
- He takes both jobs at the same time.

**Case 2. «I'll register you later».** Don Rafa's boss says he'll register him in three months. **What does he do?**

- ✔ He asks to be registered from day one.
- He agrees to wait three months so he doesn't lose the job.
- He quits without asking.

**Case 3. No aguinaldo.** Lupita is told that at her job aguinaldo «isn't a thing». **What does she do?**

- ✔ She knows aguinaldo is a right and asks PROFEDET.
- She accepts going without aguinaldo, because that's how it is at that job.
- She asks for an advance instead of the aguinaldo.

## M7 U03. A small business without risking your savings

**Case 1. The full taco shop.** Lupita wants to invest all her savings at once. **What does she do?**

- ✔ She sells to order for a few weekends first to test it.
- She invests the 85,000 at once to open as soon as possible.
- She borrows money to open the biggest space.

**Case 2. The price.** Lupita doesn't know how much each taco costs her. **What does she do?**

- ✔ She adds up ingredients, gas and packaging.
- She charges what they charged in Houston, but in pesos.
- She charges whatever the neighbor charges.

**Case 3. All in the same pocket.** Don Rafa uses the money from his jobs for the household without writing it down. **What does he do?**

- ✔ He keeps the business money separate.
- He keeps mixing everything, because in the end it's the same money.
- He keeps it all in his wallet.

## M8 U01. Fake fixers

**Case 1. The vest.** A man in a vest offers to speed everything up for 1,500. **What does he do?**

- ✔ He goes in and asks at the window.
- He pays the 1,500 so everything gets done the same day.
- He leaves his originals so the man can take them.

**Case 2. The Facebook group.** In a group for repatriated people, someone offers to «get your support» with your information. **What does he do?**

- ✔ He applies at the program's office.
- He sends his information by message so they get him the support.
- He pays the fee the group asks for.

**Case 3. The originals.** Memo is asked to leave his original birth certificate «for the procedure». **What does he do?**

- ✔ He hands over a copy and keeps his original.
- He leaves his original certificate so the procedure doesn't get stuck.
- He leaves the original and asks for a receipt.

## M8 U02. Fraud and extortion against people who return

**Case 1. The detained brother.** Lupita is asked for 8,000 pesos to free her brother. **What does she do?**

- ✔ She hangs up and calls her brother herself.
- She deposits the 8,000 right away so nothing happens to him.
- She deposits half to buy time.

**Case 2. The job with a fee.** Don Rafa is offered a job if he pays 1,200 for the uniform. **What does he do?**

- ✔ He doesn't pay: a real job doesn't charge.
- He pays for the uniform to secure the job before someone else.
- He pays half now and the rest later.

**Case 3. Double your dollars.** Memo is offered to double his savings in three months. **What does he do?**

- ✔ He doesn't invest: no one doubles money in three months without risk.
- He invests all his savings to double them before year's end.
- He invests half to test it.

## M8 U03. Your return plan on one page

**Case 1. Three notebooks.** Don Rafa has scattered notes. **What does he do?**

- ✔ He brings everything together in his one-page plan.
- He sticks with his three notebooks, because everything is there.
- He keeps it all in his head.

**Case 2. Everything today.** Lupita wants to solve all six parts in one day. **What does she do?**

- ✔ She writes the next action and a date.
- She tries to solve all six parts today.
- She leaves everything for next month.

**Case 3. The plan in a drawer.** Memo made his plan and forgot it in a drawer. **What does he do?**

- ✔ He reviews it every month and crosses off his progress.
- He leaves it in the drawer, because he already did it once.
- He makes a new one every week without reviewing the last.

# Part 12. Question bank

The option marked ✔ is correct; the feedback is below it.

## Module 1

**M1 U01 P1.** What paper does the INM give you when you're sent back?

- ✔ The Record of Reception of Repatriated Mexicans
- A new INE voter ID, ready to vote
- Your birth certificate

*Correct! It's your temporary ID.*

**M1 U01 P2.** What is the key to almost every process?

- Your U.S. work badge
- ✔ The CURP
- The electric bill

*Correct! Almost everything asks for it.*

**M1 U01 P3.** How much does it cost to print your CURP at gob.mx?

- 500 pesos
- 150 pesos
- ✔ Nothing

*Correct! It has no cost.*

**M1 U02 P1.** What do you need for the INE?

- A valid U.S. passport
- ✔ Birth certificate, photo ID and proof of address
- A co-signer who owns a house and their proof of address

*Correct! Those are the three requirements.*

**M1 U02 P2.** How much does the INE ID cost?

- ✔ Nothing
- 300 pesos
- It depends on the state

*Correct! It has no cost.*

**M1 U02 P3.** You have no bills in your name. What do you do?

- Wait until you own a house
- Use any electric bill you find on the street, even if it isn't from your home
- ✔ Ask if they accept a relative's bill, witnesses or a proof of residence

*Correct! There are options.*

**M1 U03 P1.** Your child was born in the U.S. and you are Mexican. What is your child?

- Only American
- ✔ Also Mexican, if you register the birth
- A foreigner until turning 18 and deciding

*Correct! You register the birth.*

**M1 U03 P2.** What do you do before paying for an apostille or translation?

- ✔ Ask whether your state requires it
- Pay for the most expensive apostille and translation to be safe
- Nothing, registering isn't needed

*Correct! Not every state asks for it.*

**M1 U03 P3.** The school asks for a CURP and it's in process. What do you do?

- Wait for the next school year
- Enroll them next year, once they have their CURP
- ✔ Ask for enrollment while it's sorted out

*Correct! School should not wait.*

## Module 2

**M2 U01 P1.** What is the Tarjeta Bienestar Paisano?

- ✔ A one-time support of 2,000 pesos
- A pension paid into your account every month
- A loan

*Correct! It's only once.*

**M2 U01 P2.** Which card lets you receive money from the U.S.?

- Neither
- ✔ The FINABIEN Paisano
- A department store card

*Correct! It's an account.*

**M2 U01 P3.** Someone asks for your PIN «to activate» the card. What is it?

- A normal step
- A bank requirement
- ✔ Fraud

*Correct! No one asks for the PIN.*

**M2 U02 P1.** Which account do you ask for to avoid fees?

- The gold card
- ✔ The basic account
- The investment account

*Correct! No fees.*

**M2 U02 P2.** You're offered 4% a month. What do you do first?

- ✔ Check the institution with CONDUSEF
- Deposit everything, because 4% a month is a good return
- Invite your family

*Correct! Check first.*

**M2 U02 P3.** Where are the fees listed?

- In the ad
- In what the bank clerk tells you out loud
- ✔ On the contract's summary sheet

*Correct! The summary sheet lists them.*

**M2 U03 P1.** What do you give so someone can pay you?

- Your PIN
- ✔ Your CLABE
- Your app password

*Correct! Only the CLABE.*

**M2 U03 P2.** What do you ask for when you dispute at the bank?

- ✔ A reference number
- A discount
- Nothing

*Correct! It's your proof.*

**M2 U03 P3.** The bank doesn't solve it. Where do you go?

- To the traffic police
- To another bank
- ✔ To CONDUSEF

*Correct! It defends users.*

## Module 3

**M3 U01 P1.** You had good credit in Texas. How do you show up in Mexico?

- ✔ With no history
- With the same score
- With bad credit

*Correct! You start from zero.*

**M3 U01 P2.** How many times a year is your special report at no cost?

- Never
- ✔ Once
- Every month

*Correct! Once every 12 months.*

**M3 U01 P3.** A loan you never asked for shows up. What do you do?

- Pay it to avoid problems
- ✔ File a dispute
- Nothing

*Correct! You dispute it.*

**M3 U02 P1.** What builds your history best?

- Many cards open at the same time
- ✔ A small credit paid on time
- Paying the minimum

*Correct! Small and on time.*

**M3 U02 P2.** Your limit is 6,000. What's the most you should use?

- ✔ 2,000
- 6,000
- 4,500

*Correct! One third.*

**M3 U02 P3.** Which indicator compares the cost of two credits?

- The card's color
- The minimum payment
- ✔ The CAT

*Correct! It adds up interest and fees.*

**M3 U03 P1.** You borrow 3,000 and pay 4,500 in two weeks. How much does it cost you?

- 4,500
- ✔ 1,500
- Nothing

*Correct! 4,500 minus 3,000.*

**M3 U03 P2.** An app asks for your contacts. What do you do?

- ✔ Deny it and don't use the app
- Accept
- Give only your family's numbers

*Correct! It's to pressure you.*

**M3 U03 P3.** What must any loan tell you before you sign?

- Only the weekly payment
- The collector's name and phone number
- ✔ How much you'll pay in total

*Correct! The total.*

## Module 4

**M4 U01 P1.** You're owed a week's wages in the U.S. What do you do?

- ✔ Ask for it by deposit or check
- Write it off
- Give your password to a fixer

*Correct! It's yours.*

**M4 U01 P2.** What can happen to a forgotten account?

- Nothing, it never changes
- ✔ It charges fees and goes to the state
- They close it and send you double

*Correct! Unclaimed property.*

**M4 U01 P3.** Who can guide you if the boss doesn't pay?

- A fixer in the town square who knows the bosses
- ✔ The Mexican consulate
- No one

*Correct! The consulate guides you.*

**M4 U02 P1.** Which form does your employer give you with what you earned and what was withheld?

- ✔ The W-2
- The CURP
- The rent receipt

*Correct! The W-2.*

**M4 U02 P2.** Does the IRS deposit into a Mexican account?

- Yes, always
- Only into a FINABIEN Paisano account
- ✔ No; it mails a check

*Correct! A mailed check.*

**M4 U02 P3.** Generally, how long do you have to claim a refund?

- One month
- ✔ About three years
- Forever, there's no deadline

*Correct! About three years.*

**M4 U03 P1.** Your 401(k) belongs to…

- Your employer
- ✔ You
- The U.S. government

*Correct! It's yours.*

**M4 U03 P2.** You withdraw your 401(k) at age 35. What normally happens?

- You get a bonus for taking it out early
- Nothing
- ✔ You pay a penalty and withholding

*Correct! Before age 59½.*

**M4 U03 P3.** How many credits are usually required for a U.S. Social Security pension?

- ✔ 40
- 4
- 400

*Correct! About 10 years.*

## Module 5

**M5 U01 P1.** You worked in Mexico with IMSS in 2005. Do you have an Afore?

- ✔ Probably yes
- No, it was erased
- Only if you've lived in Mexico since then

*Correct! If you contributed, you have one.*

**M5 U01 P2.** What do you use to locate your Afore?

- Your U.S. driver's license
- ✔ Your CURP
- Your electricity bill

*Correct! With the CURP.*

**M5 U01 P3.** What are beneficiaries?

- ✔ The people who'd receive your savings if you pass away
- The Afore's owners and directors
- Your bosses

*Correct! The ones who receive it.*

**M5 U02 P1.** You started contributing in 1990. Which law applies?

- Ley 97
- ✔ Ley 73
- Neither

*Correct! Before July 1997.*

**M5 U02 P2.** How many weeks does Ley 97 require in 2026?

- 500
- 1,250
- ✔ 875

*Correct! 875.*

**M5 U02 P3.** How many weeks does a full year of formal work add?

- ✔ About 52
- 12
- 365, one per day of the year

*Correct! About 52.*

**M5 U03 P1.** Where can you contribute to your Afore?

- Only at the bank where your boss paid you
- ✔ At a store, in the app or by automatic debit
- Only when you retire

*Correct! You have three ways.*

**M5 U03 P2.** You save 100 pesos a week in your Afore. How much in a year?

- 1,200
- ✔ 5,200
- 520

*Correct! 52 weeks times 100.*

**M5 U03 P3.** What does enrolling in IMSS as self-employed give you?

- A loan
- A credit card with a limit based on your contribution
- ✔ Medical care and weeks

*Correct! Medical care and weeks.*

## Module 6

**M6 U01 P1.** How far ahead do you plan when you return?

- One week
- ✔ 90 days
- One day

*Correct! The first months.*

**M6 U01 P2.** You're promised a job «in a month». Do you count it?

- Yes, all of it
- Half, in case they do hire you
- ✔ No, not until it's certain

*Correct! Only what's certain.*

**M6 U01 P3.** How do you do your math?

- ✔ In pesos with prices here
- In dollars
- With prices there, to compare better

*Correct! In pesos.*

**M6 U02 P1.** People ask to borrow money when you arrive. What helps you?

- Lending everything
- ✔ A short, kind answer
- Borrowing so you can lend to your family

*Correct! Short and kind.*

**M6 U02 P2.** When do you decide how much to help?

- ✔ Ahead of time, based on your 90 days
- When they ask, based on what each person needs
- Never

*Correct! Ahead of time.*

**M6 U02 P3.** If you help with money, it's best to give it as…

- A loan with interest
- An advance
- ✔ A gift you can afford

*Correct! Without expecting it back.*

**M6 U03 P1.** The remittance ended. What do they do first?

- ✔ A new budget with what comes in today
- Take out a loan to keep spending as before
- Keep going the same

*Correct! With real numbers.*

**M6 U03 P2.** Which expense is protected?

- Cable TV
- ✔ School
- The expensive phone plan

*Correct! It's basic.*

**M6 U03 P3.** What else can they check?

- Nothing
- Online betting to make up for the remittance
- ✔ Support or scholarships they're entitled to

*Correct! There may be support.*

## Module 7

**M7 U01 P1.** How do you present your experience?

- «I do a bit of everything»
- ✔ Trade, years and proof
- Only your name and the country where you worked

*Correct! Specific.*

**M7 U01 P2.** Who has a job board for repatriated people?

- ✔ The Servicio Nacional de Empleo
- A fixer
- No one

*Correct! The SNE.*

**M7 U01 P3.** You speak English. What do you do?

- Hide it
- Mention it only if they ask
- ✔ Put it first

*Correct! It's in high demand.*

**M7 U02 P1.** What does an informal job NOT give you?

- A wage
- ✔ IMSS and Afore
- Pay for the hours you work

*Correct! There are no benefits.*

**M7 U02 P2.** You earn 300 pesos a day. What is your minimum aguinaldo?

- ✔ 4,500
- 300
- 9,000

*Correct! 15 days.*

**M7 U02 P3.** From when must you be registered with IMSS?

- ✔ From day one
- After three months, once you pass the trial period
- After a year

*Correct! From the start.*

**M7 U03 P1.** What do you do before investing your savings in a business?

- ✔ Test it on a small scale
- Take out a loan
- Rent the biggest space

*Correct! Test first.*

**M7 U03 P2.** A product costs you 25 and you sell it for 40. How much do you keep per piece?

- 65
- ✔ 15
- 40

*Correct! 40 minus 25.*

**M7 U03 P3.** Why keep business money separate?

- Just because
- Because the law requires it of every business, even small ones
- ✔ To know whether you're making or losing money

*Correct! To see if you profit.*

## Module 8

**M8 U01 P1.** Someone charges you to process your INE. What is it?

- ✔ A fake fixer
- Normal
- A legal express service

*Correct! It has no cost.*

**M8 U01 P2.** Where do you verify whether someone is from the government?

- By their vest
- ✔ Inside the office
- On their business card

*Correct! Ask inside.*

**M8 U01 P3.** What do you leave for a procedure?

- Your originals
- Your PIN
- ✔ Copies, and you show the original

*Correct! Copies.*

**M8 U02 P1.** You get a call: your relative is detained and they want money now. What do you do?

- ✔ Hang up and call your relative yourself
- Deposit
- Give your information

*Correct! Verify yourself.*

**M8 U02 P2.** A job asks you to pay for the uniform before starting. What is it?

- Normal
- A benefit the employer gives you to start
- ✔ A sign of fraud

*Correct! You don't pay to work.*

**M8 U02 P3.** What number do you call to report anonymously?

- Only 911
- ✔ 089
- The number that called you

*Correct! 089.*

**M8 U03 P1.** What goes in each part of your plan?

- Only what you've already done
- ✔ The next action and a date
- A drawing of how you see yourself in a year

*Correct! Action and date.*

**M8 U03 P2.** How often do you review your plan?

- ✔ Every month
- Every five years
- Never

*Correct! Every month.*

**M8 U03 P3.** Which of these is a part of the plan?

- Your social media
- ✔ Your papers
- Your vacation

*Correct! Papers.*
