BACK HOME, YOUR MONEY, YOUR FUTURE
Version 1.0 · Desarrolla Talento · October 2026

Financial well-being program for people returning from the United States to Mexico, whether deported or by their own decision: 8 modules and 24 short lessons. Hybrid format: one in-person kickoff session and the rest online. Also available in Spanish and as a bilingual group.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt   This file.
01_Manual/      Program manual: audience, rules, modules and lessons, characters and verified facts.
02_Content/     Full content: lessons, support book, H5P and question bank (.docx and .md).
03_Guide/       Implementation guide: Moodle installation, gamification and maintenance (.docx and .md).
04_Moodle/      Package to install: books, H5P, glossary, bank, badges, certificate data, surveys, guides, preview and the README for Claude.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Coordination read the program manual
[ ] Content reviewed by specialists in the course topics
[ ] Current facts confirmed on official sites
[ ] Course installed with 04_Moodle/README_INSTALL_BACK_HOME_FOR_CLAUDE.md
[ ] Level Up, badges, certificate and surveys configured
[ ] Review with the student role

KEEP IN MIND
------------
- The course doesn't recommend institutions or products: it teaches how to verify them (CONDUSEF's SIPRES).
- No personal data is requested: no accounts, PINs, passwords, CURP or real amounts.
- No immigration or legal advice is given: participants are referred to consulates, the Embassy and public offices.
