# Actualización 1.2 → 1.3 · Tu Turno, Tu Dinero, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.2 a la 1.3. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M2 U03: texto corregido; M2 U04: texto corregido; M4 U03: texto corregido; M5 U02: texto corregido; M6 U05: texto corregido; M7: lecciones nuevas U05, U06, U07; M7 U04: texto corregido; Apoyo: capítulos 4, 5 corregidos; Preguntas: 9 nuevas; Glosario: 2 términos nuevos; categoría de preguntas: Tu Turno v1.3.

## 1. Categoría de preguntas

En *Banco de preguntas > Categorías*, renombra `Tu Turno v1.2` a `Tu Turno v1.3` (sus subcategorías M1… se quedan). Hazlo antes de importar preguntas.

## 2. Por módulo

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. En «M2 U03. Quién te protege y dónde reclamar», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis.» por «Sin costo.» y guarda.
2. En «M2 U04. ¿A quién le crees? Información confiable y cambios que te afectan», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis y sin venderte nada.» por «Sin costo y sin venderte nada.» y guarda.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. En «M4 U03. Tu casa: Infonavit y el crédito de 100 puntos», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Gratis» por «Sin costo» y guarda.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M5 U02. Tu reporte sin costo y cómo reclamar».
2. *Importar capítulo* > `1_libros/M5/M5_U02_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U02. Tu reporte sin costo y cómo reclamar» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. Qué es el Buró de Crédito» → «M5 U02. Tu reporte sin costo y cómo reclamar» → «M5 U03. Cómo mejorar tu historial» → «M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?».

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M6 U05. Tu identidad y que dejen de llamarte».
2. *Importar capítulo* > `1_libros/M6/M6_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U05. Tu identidad y que dejen de llamarte» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M6 U01. Llamadas y mensajes falsos» → «M6 U02. Apps «montadeudas»» → «M6 U03. Extorsión telefónica» → «M6 U04. Si ya te pasó: qué hacer» → «M6 U05. Tu identidad y que dejen de llamarte» → «M6 U06. Voces y videos falsos con inteligencia artificial».

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U04. Si llega un desastre: sismo, inundación o incendio», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M7 U05. Salud para tu familia: el seguro del IMSS que pagas tú.» y guarda.
2. *Importar capítulo* > `1_libros/M7/M7_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U05. Salud para tu familia: el seguro del IMSS que pagas tú» con 3 subcapítulos.
3. *Importar capítulo* > `1_libros/M7/M7_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U06. Que tu familia no quede atorada: beneficiarios y testamento» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M7/M7_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U07. Tu casa, tu tierra y lo que se hereda» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. Tu fondo de emergencia, de poco a poco» → «M7 U02. Tu salud y la de tu familia: estar preparado» → «M7 U03. Seguro de vida, gastos funerarios y beneficiarios» → «M7 U04. Si llega un desastre: sismo, inundación o incendio» → «M7 U05. Salud para tu familia: el seguro del IMSS que pagas tú» → «M7 U06. Que tu familia no quede atorada: beneficiarios y testamento» → «M7 U07. Tu casa, tu tierra y lo que se hereda».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U05 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U06 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U07 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 3. Libro «Materiales de apoyo»

- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.

## 4. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 2 términos nuevos.

## 5. Preguntas y autoevaluaciones

1. **Nuevas (9):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Turno v1.3/MN`.
2. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 7`: M7 U05 P1, M7 U05 P2, M7 U05 P3, M7 U06 P1, M7 U06 P2, M7 U06 P3, M7 U07 P1, M7 U07 P2, M7 U07 P3.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
