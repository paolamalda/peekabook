# Update 3.3 → 3.4 · Your Money, Your Family, Your Future · for Claude

This package updates a course **already installed** in Moodle 3.10 from version 3.3 to 3.4. It only contains what changed. Activity names stay the same. **Do not reinstall the course and do not delete activities, attempts, grades, badges or Level Up points.**

Before starting: make a course backup (*Course administration > Backup*, no user data is fine) and turn editing on. If a step can't be done, skip it and report it at the end.

## Change list

M1 U06: text corrected; M1 U09: text corrected; M1 U11: text corrected; M1 U12: text corrected; M3 U02: text corrected; M3 U10: text corrected; M5: new lesson U12; M5 U08: text corrected; M5 U11: text corrected; Support book: chapters 5, 6 corrected; Questions: 3 new; question category: Your Money v3.4.

## 1. Question category

In *Question bank > Categories*, rename `Your Money v3.3` to `Your Money v3.4` (its M1… subcategories stay). Do it before importing questions.

## 2. By module

### Module 1

**Book `Module 1 lessons`**
1. In "M1 U06. Can a small purchase add up to a lot?", subchapter "Go deeper · +5 min", *Edit*: change the text ""Free trials" usually ask for your card and charge you automatically when they end. Write down the date so you can cancel before." to ""No-cost trials" usually ask for your card and charge you automatically when they end. Write down the date so you can cancel before." and save.
2. In "M1 U09. Does filing taxes mean I'll get money back?", subchapter "Practice", *Edit*: change the text "Free tax help in California" to "No-cost tax help in California" and save.
3. In "M1 U11. What tax benefits are there if I file with an ITIN?", subchapter "M1 U11. What tax benefits are there if I file with an ITIN?", *Edit*: change the text "Free help to file" to "No-cost help to file" and save.
4. In "M1 U11. What tax benefits are there if I file with an ITIN?", subchapter "The essentials · 5 min", *Edit*: change the text "Free help to file" to "No-cost help to file" and save.
5. In "M1 U11. What tax benefits are there if I file with an ITIN?", subchapter "Practice", *Edit*: change the text "Free tax return preparation (VITA)" to "No-cost tax return preparation (VITA)" and save.
6. In "M1 U12. How do I choose someone to help me with taxes?", subchapter "Practice", *Edit*: change the text "Free tax return preparation (VITA)" to "No-cost tax return preparation (VITA)" and save.

### Module 3

**Book `Module 3 lessons`**
1. In "M3 U02. How do I know what information is used about my debts?", subchapter "Practice", *Edit*: change the text "Free credit reports" to "No-cost credit reports" and save.
2. In "M3 U10. What's my next step with credit?", subchapter "Practice", *Edit*: change the text "Free credit reports" to "No-cost credit reports" and save.

### Module 5

**Book `Module 5 lessons`**
1. In "M5 U08. What happens to my family if something happens to me?", subchapter "Go deeper · +5 min", *Edit*: change the text "Free legal clinics from community organizations." to "No-cost legal clinics from community organizations." and save.
2. In "M5 U11. What's my financial plan?", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M5 U12. What happens if I inherit or leave something across two countries?." and save.
3. *Import chapter* > `1_books/M5/M5_U12_lesson.zip`, type "Each HTML file represents one chapter". It creates "M5 U12. What happens if I inherit or leave something across two countries?" with 3 subchapters.
4. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M5 U01. How do I turn a wish into a goal?» → «M5 U02. Does having more money mean my investment made money?» → «M5 U03. Does opening an account mean I already invested?» → «M5 U04. Rent or buy? What rights do I have as a tenant?» → «M5 U05. Is the advertised price all it costs?» → «M5 U06. What will I live on when I work less or stop working?» → «M5 U07. What happens to what I saved in Mexico?» → «M5 U08. What happens to my family if something happens to me?» → «M5 U09. How do I plan when my income changes every month?» → «M5 U10. How do I formalize my business?» → «M5 U11. What's my financial plan?» → «M5 U12. What happens if I inherit or leave something across two countries?».

**Section summary:** *Edit section* for Module 5 > summary, HTML source view, replace everything with `5_section_summaries/M5_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M5 U12 · What would you do?`, file `2_h5p/M5/M5_U12_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

## 3. "Support materials" book

- Chapter 5 "Where to find help": delete it, *Import chapter* > `1_books/Apoyo/05_apoyo.zip` and move it up with the arrows to position 5.
- Chapter 6 "References": delete it, *Import chapter* > `1_books/Apoyo/06_apoyo.zip` and move it up with the arrows to position 6.

## 4. Questions and self-assessments

1. **New (3):** *Question bank > Import*, GIFT format, `4_questions/new_questions.gift.txt`. They go into `Your Money v3.4/MN`.
2. Add the new ones to their self-assessment, 10 per page. **If the quiz already has attempts, Moodle won't let you add questions:** don't delete attempts; leave it and note it in your report.
   - `Module 5 self-assessment`: M5 U12 P1, M5 U12 P2, M5 U12 P3.

## 5. Check and report

With *Switch role to > Student*, open one new lesson and its H5P. Report: chapters per changed book, new or replaced H5P, corrected and imported questions, quizzes that couldn't change because they have attempts, imported terms, platform adjustments done and anything you couldn't do.

The `9_for_the_team/` folder (facilitator kit, WhatsApp and audio scripts, OECD map) is for the program team: **don't upload it to Moodle**.
