# Actualización 3.3 → 3.4 · Tu Dinero, Tu Familia, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 3.3 a la 3.4. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M5: lección nueva U12; M5 U11: texto corregido; Apoyo: capítulo 5 corregido; Preguntas: 3 nuevas; categoría de preguntas: Tu Dinero v3.4.

## 1. Categoría de preguntas

En *Banco de preguntas > Categorías*, renombra `Tu Dinero v3.3` a `Tu Dinero v3.4` (sus subcategorías M1… se quedan). Hazlo antes de importar preguntas.

## 2. Por módulo

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. En «M5 U11. ¿Cuál es mi plan financiero?», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U12. ¿Qué pasa si heredo o dejo algo entre dos países?.» y guarda.
2. *Importar capítulo* > `1_libros/M5/M5_U12_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U12. ¿Qué pasa si heredo o dejo algo entre dos países?» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. ¿Cómo convierto un deseo en una meta?» → «M5 U02. ¿Tener más dinero significa que mi inversión ganó?» → «M5 U03. ¿Abrir una cuenta significa que ya invertí?» → «M5 U04. ¿Rentar o comprar? ¿Qué derechos tengo como inquilino?» → «M5 U05. ¿El precio anunciado es todo lo que cuesta?» → «M5 U06. ¿De qué viviré cuando trabaje menos o deje de trabajar?» → «M5 U07. ¿Qué pasa con lo que ahorré en México?» → «M5 U08. ¿Qué pasa con mi familia si algo me pasa?» → «M5 U09. ¿Cómo hago un plan cuando el ingreso cambia cada mes?» → «M5 U10. ¿Cómo formalizo mi negocio?» → «M5 U11. ¿Cuál es mi plan financiero?» → «M5 U12. ¿Qué pasa si heredo o dejo algo entre dos países?».

**Resumen de la sección:** *Editar sección* del Módulo 5 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M5_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U12 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U12_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 3. Libro «Materiales de apoyo»

- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.

## 4. Preguntas y autoevaluaciones

1. **Nuevas (3):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Dinero v3.4/MN`.
2. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 5`: M5 U12 P1, M5 U12 P2, M5 U12 P3.

## 5. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
