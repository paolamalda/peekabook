# Actualización 1.2 → 1.3 · Tu Patrimonio, Tu Tranquilidad, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.2 a la 1.3. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M2 U04: texto corregido; M4 U07: texto corregido; M7 U04: texto corregido; M8: lección nueva U07; M8 U06: texto corregido; M10: lecciones nuevas U07, U08; M10 U02: texto corregido; M10 U06: texto corregido; Apoyo: capítulos 4, 5 corregidos; Preguntas: 9 nuevas; Glosario: 2 términos nuevos; categoría de preguntas: Tu Patrimonio v1.3.

## 1. Categoría de preguntas

En *Banco de preguntas > Categorías*, renombra `Tu Patrimonio v1.2` a `Tu Patrimonio v1.3` (sus subcategorías M1… se quedan). Hazlo antes de importar preguntas.

## 2. Por módulo

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. En «M2 U04. Tus derechos y dónde reclamar», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratuita.» por «Sin costo.» y guarda.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. En «M4 U07. Que dejen de llamarte: REPEP y REUS», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis; los fraudes no se detienen con registros.» por «Sin costo; los fraudes no se detienen con registros.» y guarda.
2. En «M4 U07. Que dejen de llamarte: REPEP y REUS», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Gratis y oficial» por «Sin costo y oficial» y guarda.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U04. Pensión de viudez y pensiones del Bienestar», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis» por «Sin costo» y guarda.
2. En «M7 U04. Pensión de viudez y pensiones del Bienestar», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Gratis» por «Sin costo» y guarda.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. En «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U07. IMSS por tu cuenta: Seguro de Salud para la Familia y Modalidad 10.» y guarda.
2. *Importar capítulo* > `1_libros/M8/M8_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U07. IMSS por tu cuenta: Seguro de Salud para la Familia y Modalidad 10» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Cómo funciona tu seguro de gastos médicos» → «M8 U02. ¿Por qué sube tanto y cómo bajarlo sin quedarte sin protección?» → «M8 U03. Compara y lee tu póliza» → «M8 U04. Seguro de vida y gastos funerarios» → «M8 U05. Casa y auto: lo básico» → «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado» → «M8 U07. IMSS por tu cuenta: Seguro de Salud para la Familia y Modalidad 10».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U07 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U02. Beneficiarios: cuentas, seguros y AFORE», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis.» por «Sin costo.» y guarda.
2. En «M10 U06. Tu casa: escrituras, predial y crédito en orden», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U07. Si no hay testamento: unión libre, tierra ejidal y el trámite sucesorio.» y guarda.
3. *Importar capítulo* > `1_libros/M10/M10_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U07. Si no hay testamento: unión libre, tierra ejidal y el trámite sucesorio» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M10/M10_U08_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U08. Heredar o dar en vida: impuestos, costos y riesgos» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Testamento: tu decisión por escrito» → «M10 U02. Beneficiarios: cuentas, seguros y AFORE» → «M10 U03. Poder notarial y quién decide si tú no puedes» → «M10 U04. Ayudar a los hijos sin descuidar tu futuro» → «M10 U05. Viudez o separación: los primeros 90 días» → «M10 U06. Tu casa: escrituras, predial y crédito en orden» → «M10 U07. Si no hay testamento: unión libre, tierra ejidal y el trámite sucesorio» → «M10 U08. Heredar o dar en vida: impuestos, costos y riesgos».

**Resumen de la sección:** *Editar sección* del Módulo 10 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M10_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U07 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U08 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U08_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 3. Libro «Materiales de apoyo»

- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.

## 4. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 2 términos nuevos.

## 5. Preguntas y autoevaluaciones

1. **Nuevas (9):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Patrimonio v1.3/MN`.
2. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 8`: M8 U07 P1, M8 U07 P2, M8 U07 P3.
   - `Autoevaluación del Módulo 10`: M10 U07 P1, M10 U07 P2, M10 U07 P3, M10 U08 P1, M10 U08 P2, M10 U08 P3.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
