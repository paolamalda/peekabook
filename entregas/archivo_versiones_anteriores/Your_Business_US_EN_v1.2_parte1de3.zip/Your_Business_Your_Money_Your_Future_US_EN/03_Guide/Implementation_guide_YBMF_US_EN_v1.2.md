# Your Business, Your Money, Your Future · U.S.: implementation guide

For the team that sets up and runs the course in Moodle 3.10.

# Part 1. Installation in Moodle, step by step

The same file is in `04_Moodle/README_INSTALL_YOUR_BUSINESS_US_EN_FOR_CLAUDE.md`.


You will create the course **Your Business, Your Money, Your Future · U.S.** on academia.desarrollatalento.com. The site runs Moodle 3.10, the Boost theme, Level Up 3.15.2 and the **Custom certificate** plugin (mod_customcert).

If other courses exist on the site, **do not touch them.**

Work in the browser with the administrator session the person opened.

Rules:

- Use only the web interface.
- Do not use SSH.
- Do not install plugins.
- Do not change site settings.
- Do not touch other courses.
- If anything does not match these instructions, stop and ask.

### 0. Before you start

1. Confirm that no course with the short name `YBMF-US-EN` exists. If it does, stop and ask.
2. Check in *Site administration > Plugins > Plugins overview* whether **Custom certificate** and **Level Up** exist. Note it for the report.
3. If the site has no H5P activities yet, the first one you upload installs its libraries: upload it with the administrator account. If a library error appears, stop and report the exact message.

### 1. Create the course

| Field | Value |
|---|---|
| Full name | Your Business, Your Money, Your Future · U.S. |
| Short name | YBMF-US-EN |
| Visibility | **Show** |
| Format | **Tiles** if installed; otherwise Topics. 11 sections |
| Completion tracking | Yes |
| Force language | English |

**Tiles format (if available):** in course settings, *Show progress on tiles*: **as a percentage**; one icon per module that fits its topic; the General section above the tiles. If Tiles doesn't exist, use Topics with "Show one section per page."

**Enrolment:** *Enrolment methods* > enable **Self enrolment** with the **enrolment key** the person gives you (if you don't have it, leave "[TBD]" and report it). Turn off guest access.

### 2. Sections

| Section | Name | Description |
|---|---|---|
| General | Welcome | Link to chapter 1 of the support book and the forum "Questions and comments" |
| 1 | Module 1. Your business and your home: separate money | Content of `1_books/M1_resumen.html` |
| 2 | Module 2. Costs and price | `M2_resumen.html` |
| 3 | Module 3. Cash flow | `M3_resumen.html` |
| 4 | Module 4. Get paid and sell without losing | `M4_resumen.html` |
| 5 | Module 5. Formalize and handle taxes without fear | `M5_resumen.html` |
| 6 | Module 6. Credit for your business | `M6_resumen.html` |
| 7 | Module 7. Protect your business | `M7_resumen.html` |
| 8 | Module 8. Grow in an orderly way | `M8_resumen.html` |
| 9 | Module 9. Your future | `M9_resumen.html` |
| 10 | Support materials | "Cases, practice, glossary and where to get help." |
| 11 | Assessment and certificate | "Your certificate of completion." |

Description of the forum "Questions and comments": "Do not share your SSN, ITIN, EIN, passwords, account numbers, your business's real amounts or your immigration status."

### 3. Lesson books

In each module section:

1. Create a book: name `Module N lessons`, chapter formatting "None", completion "View".
2. Book menu > **Import chapter** > `1_books/MN_libro_Moodle.zip`, type "Each HTML file represents one chapter".
3. Check that each lesson has its cover page first and 3 indented subchapters.

| Module | Chapters | Pages |
|---|---|---|
| M1 | 6 | 24 |
| M2 | 4 | 16 |
| M3 | 4 | 16 |
| M4 | 3 | 12 |
| M5 | 5 | 20 |
| M6 | 5 | 20 |
| M7 | 7 | 28 |
| M8 | 6 | 24 |
| M9 | 3 | 12 |

### 4. Support book

In section 10, create the book `Support materials` with the same settings and import `1_books/Apoyo_libro_Moodle.zip` (6 chapters). In the General section, add a **URL** or label to chapter 1 ("Welcome").

In the same section 10, add a **File** resource named `Tools for your numbers (Excel)` with the file in `10_tools/`. Display: "Force download". Description: "Budget, debt list, emergency fund and compound-interest goal; and for your business: cost and price, break-even and 8-week cash flow. Type only in the pink cells; the file is yours and isn't shared." Completion: "View".

### 5. Glossary

In section 10, create the glossary `Course key words` and import `3_glossary/Glosario_curso_Moodle.xml`, destination "current glossary".

### 6. Question bank and self-assessments

1. *Question bank > Import*: GIFT format, `4_questions/question_bank_ybmf_us_en.gift.txt`. Categories *Your Business US EN v1.2/M1* to *M9* are created, with 129 questions.
2. In each module section, create the quiz `Module N self-assessment`: grade to pass 70, unlimited attempts, highest grade, shuffle answers, review with correct answer and feedback, completion "Require passing grade".
3. Add **all** questions from *Your Business US EN v1.2/MN*, 10 per page:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 |
|---|---|---|---|---|---|---|---|---|
| 18 | 12 | 12 | 9 | 15 | 15 | 21 | 18 | 9 |

### 7. H5P activities (43)

Files in `2_h5p/MN/`, in order. In each section, **after the book** and in lesson order:

1. *Add an activity > H5P*.
2. Name: `MN UYY · What would you do?`.
3. Upload `MN_UYY_what_would_you_do.h5p`.
4. Options: download no, embed no, copyright yes.
5. Grade: tracking yes, "highest grade". Completion: "Student must receive a grade".

**Final order of each section:** book, H5P in order, self-assessment.

**Check:** open 3 random activities with *Switch role to > Student*. You should see 3 cases, 3 options per case and the grade at the end.

### 8. Program surveys

`8_surveys/` has the surveys and their document `surveys.md`. Use the **Feedback** module in **anonymous** mode and, in each one, *Templates > Import questions* with its XML (if the import fails, build them by hand from `surveys.md`):

| Activity | Section | File | Completion |
|---|---|---|---|
| `Start survey` | General | `survey_start.xml` | Submit |
| `Final survey` | 11 | `survey_final.xml` | Submit; required for the certificate |
| `30-day follow-up` | 11 | `survey_follow_up.xml` | Submit |
| `90-day follow-up` | 11 | `survey_follow_up.xml` | Submit |

Restrict the follow-ups by date: 30 and 90 days after the cohort's end date ("[TBD]"). The final survey is the program's evidence of results: don't skip it.

### 9. Level Up, badges, completion and certificate

Follow `7_guides/gamification_guide.md`: sections 2 (Level Up), 3 (8 badges with `5_badges/`; each name includes the course so it's unique on the platform), 4 (completion with the 9 self-assessments) and 5 (certificate with the standard template and the data in `6_certificate/certificate.md`). If Level Up or Custom certificate does not exist, do not install it: skip that step and report it.

### 9. Community (optional, ask first)

Ask the person whether they want you to create the course **Your Business Community · U.S.** (`YBMF-US-EN-COM`, hidden). It has its own folder and instructions: `README_CREATE_COMMUNITY_FOR_CLAUDE.md`.

### 11. Final review (as a student)

- M1 U01: cover page first, two path buttons, colored terms with their meaning and "Current fact" or "Before you act, check" boxes.
- One H5P per module opens, shows 3 cases and records a grade.
- One self-assessment shows 3 options per question.
- The support book shows "See the key" in the case studies and collapsible frequently asked questions.

### 12. Report for the person

Course link; pages per book; H5P per module; questions per self-assessment; surveys created; active badges; Level Up settings; certificate status; what you could not do and why; screenshots of the tiles home page, an H5P, a self-assessment and the certificate preview.

The course stays **visible**, with enrolment by key. For the catalog listing, use `catalog_card.md`.


# Part 2. Activities, points, badges and certificate


This guide is for Moodle 3.10 with Level Up (block_xp) 3.15.2 and the Custom certificate plugin (mod_customcert).

The goal is to motivate without competing. Points reward progress, not perfect scores. Nobody's name is ever shown in a table.

### 1. What each module has

| Activity | How many | Completion |
|---|---|---|
| Book "Module N lessons" | 1 per module (9) | View |
| H5P activity "MN UYY · What would you do?" | 1 per lesson (43) | Receive a grade |
| Quiz "Module N self-assessment" | 1 per module (9) | Passing grade of 70% |

**Each H5P activity:** no download button, copyright button on, embed off; attempt tracking with "Highest grade"; completion "Student must receive a grade".

**Self-assessments:** use the bank of 129 three-option questions with feedback, in categories *Your Business US EN v1.2/M1* to *M9*. Passing grade 70%, unlimited attempts, shuffled answers and review with the correct answer and feedback at the end.

### 2. Level Up: levels and points

**Rules** (*Level Up > Rules*):

1. Remove the default rules or set them to 0.
2. **For completing any activity:** 25 points, event "Course module completion updated" (`\core\event\course_module_completion_updated`).
3. **For posting in the forum:** 5 points, event "Post created" (`\mod_forum\event\post_created`).
4. Keep cheat guard on.

Completing the whole course gives about 1,525 points:

| Activities | How many | Points |
|---|---|---|
| H5P activities | 43 | 1,075 |
| Books | 9 | 225 |
| Self-assessments | 9 | 225 |
| **Total** | 61 | **1,525** |

**Levels** (6 levels, no automatic algorithm):

| Level | Name | Points | Reached around |
|---|---|---|---|
| 1 | Idea | 0 | On arrival |
| 2 | Launch | 200 | During Module 2 |
| 3 | Up and running | 400 | During Module 4 |
| 4 | Formal | 650 | During Module 5 |
| 5 | Growing | 900 | During Module 7 |
| 6 | Established | 1,100 | During Module 9 |

**Ladder:** anonymity on; show only nearby neighbors or turn it off.

### 3. Badges

*Course administration > Badges > Add a new badge*. Images in `5_badges/`. Issuer: Desarrolla Talento. Expiry: never. Names include the course so they're unique on the platform: use them exactly.

| Image | Badge | Criterion (activity completion, with passing grade) | Description |
|---|---|---|---|
| 01_separate_money.png | Separate money · Your Business US EN | Module 1 self-assessment | You separated business and household money and pay yourself a salary. |
| 02_fair_price.png | Fair price · Your Business US EN | Module 2 self-assessment | You know your costs, your margin and your break-even point. |
| 03_cash_flow_under_control.png | Cash flow under control · Your Business US EN | Module 3 and 4 self-assessments | You manage your cash flow, customer credit and payment methods without losing. |
| 04_formal_business.png | Formal business · Your Business US EN | Module 5 self-assessment | Your structure, numbers, permits and taxes are in order. |
| 05_smart_credit.png | Smart credit · Your Business US EN | Module 6 self-assessment | You know whether you need credit and what it really costs. |
| 06_protected_business.png | Protected business · Your Business US EN | Module 7 self-assessment | You protected your health, business and trademark, and you guard against scams. |
| 07_orderly_growth.png | Orderly growth · Your Business US EN | Module 8 and 9 self-assessments | You grow in an orderly way and have your one-page plan. |
| 08_full_plan.png | Full plan · Your Business US EN | Course completion | You completed all nine modules of the program. |

When done, **enable** each badge.

### 4. Course completion

*Course administration > Course completion*: activity completion condition with **all** 9 self-assessments. Optional: the 9 books.

### 5. Certificate of completion (Custom certificate)

1. In the section "Assessment and certificate", add **Custom certificate** using the **platform's standard template** (no background image): name "Certificate of completion".
2. **Restrict access:** one "Activity completion" condition for each of the 9 self-assessments, "must be marked complete and pass", and the **Final survey** submitted.
3. In the template change only these data (also in `6_certificate/certificate.md`):

   | Field | Text |
   |---|---|
   | Course title | Your Business, Your Money, Your Future · U.S. |
   | Line | for completing the financial well-being program Your Business, Your Money, Your Future · U.S. |
   | Topic 1 | Separate money |
   | Topic 2 | Price and cash flow |
   | Topic 3 | Taxes and formality |
   | Topic 4 | Credit and protection |
   | Topic 5 | Growth and future |

4. Check the **PDF preview** and turn on "Verify certificate".

If Custom certificate is not installed, the **Full plan · Your Business US EN** badge works as a digital certificate.

### 6. What not to do

- Do not give points for viewing pages.
- Do not post names in rankings.
- Do not ask for real data to pass.
- Do not tie badges or the certificate to buying services or products.


# Part 3. Community and channels


### 1. Your Business Community in Moodle

A separate course, **"Your Business Community · U.S."** (short name `YBMF-US-EN-COM`), that complements this course. It has announcements, question forums by topic, scam alerts, the "Introduce your business" forum, wins, a monthly live session and a separate commercial referrals forum. Its setup is in its own folder.

To enroll the group at once, the site administrator can create a **cohort** "Your Business US EN" and add it with "Cohort sync" in both the course and the community.

### 2. Monthly live session

- One 60-minute video session a month: the month's topic (for example, "Your estimated payments," "Price with margin") and questions.
- Made-up examples only. **Never** open a participant's IRS account, bank or platform in front of the group.
- If an expert is invited (tax preparer, CPA, SBDC adviser), it's made clear that it's general orientation.

### 3. WhatsApp channel

- Name: "Your Business U.S. · Desarrolla Talento".
- Content: course announcements, tax dates (estimated payments, April return), scam alerts against businesses and referrals.
- Only the team posts; followers can't see each other's numbers.
- Avoid WhatsApp group chats: numbers are visible there and scams and "loan" offers circulate.

### 4. Commercial referrals (channels only)

Services with a commercial agreement (for example, payment processors, tax preparers or insurance) are posted **only** in the channel and the referrals forum, never in lessons, activities, self-assessments or the certificate. Every post says: **"Commercial referral: Desarrolla Talento may receive a commission. Compare with at least one other option. Using this service is voluntary and doesn't affect your access, points or certificate."**

### 5. Moderation rules

1. Remove posts with personal or tax data (SSN, ITIN, EIN, passwords, account screenshots, immigration status) and notify privately.
2. Don't allow participants to promote loans, investments, financial products or tax schemes.
3. In "Introduce your business," one post a month per person.
4. Review any scam alert the same day.
5. Refer tax, legal, employment or immigration cases to the IRS, VITA, a preparer, an SBDC or an accredited attorney or organization.


# Part 4. Maintenance


Every figure in the lessons goes in a "Current fact" box with a date and source. The full table is in the program manual, section 7.

| When | What to check | Lessons |
|---|---|---|
| November and December | Next year's retirement limits (IRS) | M9 U01 |
| December and July | Standard mileage rate (the IRS may adjust it mid-year) | M1 U04 |
| October | Social Security wage base and amount per credit (SSA) | M5 U03, M9 U01 |
| January | 1099 thresholds (inflation-adjusted from 2027) | M5 U04, M8 U02 |
| January | California and city minimum wages | M8 U01 |
| Every year | California LLC minimum, sales tax rates, CSLB limit | M5 U01, M5 U02, M5 U05 |
| Every year | USPTO fees | M7 U04 |
| Every year | Freeze, alert, no-cost report and Do Not Call rules (FTC) | M7 U05 |
| Every year | SBA disaster loan limits and state betting laws | M1 U05, M7 U07 |
| Every six months | Processor and platform fees | M4 U01, M8 U02 |
| Before open enrollment | Covered California and Medi-Cal rules | M7 U01 |
| Every year | SBA and CDFI programs and help lines | M1 U06, M8 U05 |
| After any content change | Regenerate books, H5P and question bank and rebuild the folder | Project tools |

