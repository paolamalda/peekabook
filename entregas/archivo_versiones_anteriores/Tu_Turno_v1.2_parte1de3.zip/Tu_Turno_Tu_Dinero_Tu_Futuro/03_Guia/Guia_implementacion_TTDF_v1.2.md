# Tu Turno, Tu Dinero, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_TURNO_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Turno, Tu Dinero, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TTDF-MX`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Turno, Tu Dinero, Tu Futuro |
| Nombre corto | TTDF-MX |
| Visibilidad | **Mostrar** |
| Formato | **Mosaicos** (Tiles) si está instalado; si no, Temas. 10 secciones |
| Seguimiento de finalización | Sí |

**Formato Mosaicos (si existe):** en la configuración del curso, *Mostrar progreso en los mosaicos*: **como porcentaje**; un ícono por módulo acorde a su tema; la sección General arriba de los mosaicos. Si Mosaicos no existe, usa Temas con "Mostrar una sección por página".

**Inscripción:** *Métodos de inscripción* > activa **Autoinscripción** con la **clave de inscripción** que te dé la persona (si no la tienes, deja "[por definir]" y repórtalo). Desactiva el acceso de invitados.

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Tu quincena rinde | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Tu cuenta y tu dinero | `M2_resumen.html` |
| 3 | Módulo 3. Tus deudas claras | `M3_resumen.html` |
| 4 | Módulo 4. Tandas y ahorro en grupo | `M4_resumen.html` |
| 5 | Módulo 5. Buró de Crédito sin miedo | `M5_resumen.html` |
| 6 | Módulo 6. Que no te extorsionen | `M6_resumen.html` |
| 7 | Módulo 7. Tu familia y los imprevistos | `M7_resumen.html` |
| 8 | Módulo 8. Tu futuro | `M8_resumen.html` |
| 9 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 10 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas números de cuenta, contraseñas, códigos ni montos reales de tus deudas."

### 3. Libros de lecciones

En cada sección de módulo:

1. Crea un libro: nombre `Lecciones del Módulo N`, formato de capítulo "Nada", finalización "Ver".
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba que cada lección tenga su portada primero y 3 subcapítulos sangrados.

| Módulo | Capítulos | Páginas |
|---|---|---|
| M1 | 6 | 24 |
| M2 | 6 | 24 |
| M3 | 5 | 20 |
| M4 | 3 | 12 |
| M5 | 4 | 16 |
| M6 | 6 | 24 |
| M7 | 4 | 16 |
| M8 | 3 | 12 |

### 4. Libro de apoyo

En la sección 9, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos). En la sección General, agrega una **URL** o etiqueta al capítulo 1 ("Bienvenida").

En la misma sección 9, agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con el archivo de `10_herramientas/`. Mostrar: "Forzar descarga". Descripción: "Presupuesto, lista de deudas, fondo de emergencia y meta con interés compuesto. Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver".

### 5. Glosario

En la sección 9, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_ttdf.gift.txt`. Se crean *Tu Turno v1.2/M1* a *M8*, con 111 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Turno v1.2/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 |
|---|---|---|---|---|---|---|---|
| 18 | 18 | 15 | 9 | 12 | 18 | 12 | 9 |

### 7. Actividades H5P (37)

Archivos en `2_h5p/MN/`, en orden. En cada sección, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones: descarga no, incrustar no, derechos de autor sí.
5. Calificación: seguimiento sí, "calificación más alta". Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos, 3 opciones por caso y la calificación al terminar.

### 8. Encuestas del programa

En `8_encuestas/` están las encuestas y su documento `encuestas.md`. Usa el módulo **Retroalimentación** (Feedback), modo **anónimo**, y en cada una *Plantillas > Importar preguntas* con su XML (si la importación falla, créalas a mano con `encuestas.md`):

| Actividad | Sección | Archivo | Finalización |
|---|---|---|---|
| `Encuesta de inicio` | General | `encuesta_inicio.xml` | Enviar |
| `Encuesta final` | 10 | `encuesta_final.xml` | Enviar; es requisito de la constancia |
| `Seguimiento a 30 días` | 10 | `encuesta_seguimiento.xml` | Enviar |
| `Seguimiento a 90 días` | 10 | `encuesta_seguimiento.xml` | Enviar |

Restringe los seguimientos por fecha: 30 y 90 días después de la fecha de fin de la cohorte ("[por definir]"). La encuesta final es la evidencia de resultados del programa: no la omitas.

### 9. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`; cada nombre lleva el curso para que sea único en la plataforma), 4 (finalización con las 8 autoevaluaciones) y 5 (constancia con la plantilla estándar y los datos de `6_constancia/constancia.md`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### 9. Canal de avisos (pregunta antes)

Este curso no tiene comunidad en Moodle; se acompaña con un **canal de WhatsApp** de avisos (ver `7_guias/comunidad_y_canales.md`). En la sección General agrega una **URL** `Canal de avisos` con el enlace que te dé la persona (si no lo tiene, escribe "[por definir]" y repórtalo). Confirma que las lecciones se ven bien en el celular: el público las toma entre turnos.

### 11. Revisión final (con rol de estudiante)

- M1 U01: portada primero, dos botones de ruta, términos en color con su significado y recuadros "Dato vigente" o "Antes de actuar, verifica".
- Una H5P por módulo abre, muestra 3 casos y registra calificación.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 12. Reporte para la persona

Enlace del curso; páginas por libro; H5P por módulo; preguntas por autoevaluación; encuestas creadas; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de la portada en mosaicos, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **visible**, con inscripción por clave. Para la ficha del catálogo usa `tarjeta_catalogo.md`.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2 y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo (8) | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (37) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo (8) | Calificación aprobatoria de 70% |

**Configuración de cada actividad H5P:** sin botón de descarga, con botón de derechos de autor e incrustar desactivado; seguimiento de intentos con "Calificación más alta"; finalización "El estudiante debe recibir una calificación".

**Las autoevaluaciones:** usan el banco de 111 preguntas con tres opciones y retroalimentación, en las categorías *Tu Turno v1.2/M1* a *M8*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 1,325 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 37 | 925 |
| Libros | 8 | 200 |
| Autoevaluaciones | 8 | 200 |
| **Total** | 53 | **1,325** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Primer turno | 0 | Al entrar |
| 2 | Quincena en orden | 150 | Durante el Módulo 2 |
| 3 | Sin deudas ocultas | 350 | Durante el Módulo 3 |
| 4 | Alerta | 550 | Durante el Módulo 5 |
| 5 | Protegido | 750 | Durante el Módulo 7 |
| 6 | Con futuro | 900 | Durante el Módulo 8 |

**Clasificación:** anonimato activado; mostrar solo vecinos cercanos o desactivarla.

### 3. Insignias

*Administración del curso > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca. Los nombres llevan el curso para que no se repitan en la plataforma: úsalos tal cual.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_quincena_en_orden.png | Quincena en orden · Tu Turno | Autoevaluaciones de los Módulos 1 y 2 | Tu quincena tiene presupuesto, ahorro apartado y una cuenta sin comisiones. |
| 02_deudas_claras.png | Deudas claras · Tu Turno | Autoevaluación del Módulo 3 | Conoces todas tus deudas, lo que cuestan y tu plan para salir. |
| 03_tanda_segura.png | Tanda segura · Tu Turno | Autoevaluación del Módulo 4 | Sabes organizar una tanda con reglas o ahorrar por tu cuenta. |
| 04_buro_sin_miedo.png | Buró sin miedo · Tu Turno | Autoevaluación del Módulo 5 | Revisaste tu reporte de crédito y sabes cómo mejorarlo. |
| 05_nadie_me_extorsiona.png | Nadie me extorsiona · Tu Turno | Autoevaluación del Módulo 6 | Reconoces fraudes, apps montadeudas y extorsiones, y sabes qué hacer. |
| 06_familia_protegida.png | Familia protegida · Tu Turno | Autoevaluación del Módulo 7 | Tienes fondo de emergencia y protección para tu familia. |
| 07_futuro_en_marcha.png | Futuro en marcha · Tu Turno | Autoevaluación del Módulo 8 | Ahorras para tu retiro y tienes tu plan de una página. |
| 08_plan_completo.png | Plan completo · Tu Turno | Finalización del curso | Concluiste los ocho módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*: condición de finalización de actividades con **todas** las 8 autoevaluaciones. Opcional: los 8 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado** con la **plantilla estándar de la plataforma** (sin imagen de fondo): nombre "Constancia de conclusión".
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 8 autoevaluaciones, "debe estar completa con calificación aprobatoria", y la **Encuesta final** enviada.
3. En la plantilla cambia solo estos datos (también están en `6_constancia/constancia.md`):

   | Campo | Texto |
   |---|---|
   | Título del curso | Tu Turno, Tu Dinero, Tu Futuro |
   | Línea | por concluir el programa de bienestar financiero Tu Turno, Tu Dinero, Tu Futuro |
   | Tema 1 | Quincena y cuenta |
   | Tema 2 | Deudas y tandas |
   | Tema 3 | Buró y fraudes |
   | Tema 4 | Familia |
   | Tema 5 | Futuro |

4. Revisa la **Vista previa en PDF** y activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo · Tu Turno** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.


# Parte 3. Comunidad y canales


Este curso no tiene una comunidad en Moodle. Se acompaña con un canal de WhatsApp de avisos, porque el público toma las lecciones en el celular y entre turnos.

### 1. Canal de WhatsApp

- Nombre: "Tu Turno · Desarrolla Talento".
- Solo publica el equipo; los seguidores no ven el número de los demás.
- Dos publicaciones por quincena: el **reto de la quincena** (el día de pago) y una **alerta de fraude**.
- Todas las publicaciones terminan igual: «Desarrolla Talento nunca te pide datos, contraseñas ni dinero».

### 2. Retos de la quincena

| Quincena | Reto | Lección |
|---|---|---|
| 1 | Anota cuánto te llega de verdad | M1 U01 |
| 2 | Calcula tu gasto de turnos por 15 | M1 U02 |
| 3 | Aparta aunque sean 100 hoy | M1 U04 |
| 4 | Revisa si tu cuenta cobra comisiones | M2 U01 |
| 5 | Haz tu lista de deudas | M3 U01 |
| 6 | Elige tu primera deuda para pagar | M3 U04 |
| 7 | Pide tu reporte de crédito sin costo | M5 U02 |
| 8 | Revisa los permisos de tus apps | M6 U02 |
| 9 | Acuerda una palabra clave con tu familia | M6 U03 |
| 10 | Anota tu clínica y el hospital cercano | M7 U02 |
| 11 | Localiza tu AFORE con tu CURP | M8 U01 |
| 12 | Llena tu plan de una página y tu compromiso | M8 U03 |

### 3. Si una empresa ofrece el curso

- La empresa puede invitar y dar tiempo para tomarlo, pero **no recibe** información personal, financiera ni de avance individual; si pide reportes, solo agregados y anónimos.
- El curso no aborda la relación laboral de las personas con la empresa.

### 4. Referencias comerciales

Solo en el canal, siempre marcadas y nunca préstamos. Cada publicación dice: «Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Es voluntario y no afecta tu acceso ni tu constancia.»


# Parte 4. Mantenimiento


| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Enero | Salario mínimo del año | M1 U01 |
| Cada año | Límites de la cuenta básica | M2 U01 |
| Cada año | Monto mínimo de aportaciones voluntarias a la AFORE | M8 U01 |
| Cada seis meses | Alertas de la CONDUSEF sobre préstamos fraudulentos | M3 U03, M6 U02 |
| Cada año | REPEP, REUS y registro de líneas con CURP | M6 U05 |
| Cada año | Reglas y tasas de crédito de Infonavit | M4 U03 |
| Cada año | Meta de inflación del Banco de México y funcionamiento de Cetesdirecto | M2 U05, M2 U06 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco y volver a armar la carpeta | Herramientas del proyecto |

