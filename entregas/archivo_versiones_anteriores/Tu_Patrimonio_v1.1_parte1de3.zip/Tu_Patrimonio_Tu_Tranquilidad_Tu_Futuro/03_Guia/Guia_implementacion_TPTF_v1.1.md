# Tu Patrimonio, Tu Tranquilidad, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_PATRIMONIO_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Patrimonio, Tu Tranquilidad, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TPTF-MX`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Patrimonio, Tu Tranquilidad, Tu Futuro |
| Nombre corto | TPTF-MX |
| Visibilidad | **Ocultar** |
| Formato | Temas, 13 secciones |
| Seguimiento de finalización | Sí |

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Tu dinero hoy: mapa y orden | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Conoce el sistema financiero | `M2_resumen.html` |
| 3 | Módulo 3. El celular sin miedo | `M3_resumen.html` |
| 4 | Módulo 4. Fraudes: que no te pase | `M4_resumen.html` |
| 5 | Módulo 5. Tus cuentas y tu ahorro protegido | `M5_resumen.html` |
| 6 | Módulo 6. Tus inversiones | `M6_resumen.html` |
| 7 | Módulo 7. Pensión y retiro | `M7_resumen.html` |
| 8 | Módulo 8. Salud y seguros | `M8_resumen.html` |
| 9 | Módulo 9. Impuestos sin miedo | `M9_resumen.html` |
| 10 | Módulo 10. Patrimonio y familia | `M10_resumen.html` |
| 11 | Módulo 11. Decidir con calma y tu plan | `M11_resumen.html` |
| 12 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 13 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas números de cuenta, contraseñas, códigos, fotos de tarjetas ni montos reales. El equipo nunca te pedirá esos datos."

### 3. Libros de lecciones

En cada sección de módulo:

1. Crea un libro: nombre `Lecciones del Módulo N`, formato de capítulo "Nada", finalización "Ver".
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba que cada lección tenga su portada primero y 3 subcapítulos sangrados.

| Módulo | Capítulos | Páginas |
|---|---|---|
| M1 | 4 | 16 |
| M2 | 4 | 16 |
| M3 | 5 | 20 |
| M4 | 8 | 32 |
| M5 | 4 | 16 |
| M6 | 5 | 20 |
| M7 | 6 | 24 |
| M8 | 5 | 20 |
| M9 | 3 | 12 |
| M10 | 5 | 20 |
| M11 | 3 | 12 |

### 4. Libro de apoyo

En la sección 12, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos). En la sección General, agrega una **URL** o etiqueta al capítulo 1 ("Bienvenida").

### 5. Glosario

En la sección 12, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_tptf.gift.txt`. Se crean *Tu Patrimonio/M1* a *M11*, con 156 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Patrimonio/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 | M10 | M11 |
|---|---|---|---|---|---|---|---|---|---|---|
| 12 | 12 | 15 | 24 | 12 | 15 | 18 | 15 | 9 | 15 | 9 |

### 7. Actividades H5P (52)

Archivos en `2_h5p/MN/`, en orden. En cada sección, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones: descarga no, incrustar no, derechos de autor sí.
5. Calificación: seguimiento sí, "calificación más alta". Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos, 3 opciones por caso y la calificación al terminar.

### 8. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`), 4 (finalización con las 11 autoevaluaciones) y 5 (constancia con `6_certificado/certificado_fondo.png`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### 9. Comunidad y acompañamiento (pregunta antes)

Este curso se acompaña con sesiones en grupo y la **Comunidad Tu Patrimonio** (`TPTF-COM`), que tiene su propia carpeta e instrucciones (`README_CREAR_COMUNIDAD_PARA_CLAUDE.md`). Pregunta a la persona si quieres crearla. En la sección General del curso agrega una **URL** `Comunidad Tu Patrimonio` y una etiqueta con el horario de la línea de apoyo que te indique la persona (si no lo tiene, escribe "[por definir]" y repórtalo).

### 10. Revisión final (con rol de estudiante)

- M1 U01: portada primero, dos botones de ruta, términos en color con su significado y recuadros "Dato vigente" o "Antes de actuar, verifica".
- Una H5P por módulo abre, muestra 3 casos y registra calificación.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 11. Reporte para la persona

Enlace del curso; páginas por libro; H5P por módulo; preguntas por autoevaluación; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de una portada, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **oculto**. La persona decide cuándo mostrarlo.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2 y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo (11) | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (52) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo (11) | Calificación aprobatoria de 70% |

**Configuración de cada actividad H5P:** sin botón de descarga, con botón de derechos de autor e incrustar desactivado; seguimiento de intentos con "Calificación más alta"; finalización "El estudiante debe recibir una calificación".

**Las autoevaluaciones:** usan el banco de 156 preguntas con tres opciones y retroalimentación, en las categorías *Tu Patrimonio/M1* a *M11*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 1,850 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 52 | 1,300 |
| Libros | 11 | 275 |
| Autoevaluaciones | 11 | 275 |
| **Total** | 74 | **1,850** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Primer paso | 0 | Al entrar |
| 2 | Mi mapa | 200 | Durante el Módulo 2 |
| 3 | Con candado | 500 | Durante el Módulo 4 |
| 4 | Protegida | 850 | Durante el Módulo 5 |
| 5 | Con rumbo | 1,200 | Durante el Módulo 8 |
| 6 | Tranquila | 1,550 | Durante el Módulo 10 |

**Clasificación:** anonimato activado; mostrar solo vecinos cercanos o desactivarla.

### 3. Insignias

*Administración del curso > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_mi_mapa_en_orden.png | Mi mapa en orden | Autoevaluaciones de los Módulos 1 y 2 | Sabes qué tienes, dónde está y cómo verificar cualquier institución. |
| 02_celular_con_candado.png | Celular con candado | Autoevaluación del Módulo 3 | Tu banca en el celular tiene alertas, límite de transferencias y una persona de confianza. |
| 03_nadie_me_engana.png | Nadie me engaña | Autoevaluación del Módulo 4 | Reconoces los fraudes y tienes tu plan de respuesta. |
| 04_ahorro_protegido.png | Ahorro protegido | Autoevaluaciones de los Módulos 5 y 6 | Tu ahorro está protegido y entiendes tus inversiones y a tu asesor. |
| 05_retiro_claro.png | Retiro claro | Autoevaluación del Módulo 7 | Conoces tus pensiones y calculaste tu retiro. |
| 06_salud_asegurada.png | Salud asegurada | Autoevaluaciones de los Módulos 8 y 9 | Entiendes tu seguro médico, tus retenciones y tus deducciones. |
| 07_familia_en_orden.png | Familia en orden | Autoevaluación del Módulo 10 | Tu testamento, tus beneficiarios y tus documentos están en orden. |
| 08_plan_completo.png | Plan completo | Finalización del curso | Concluiste los once módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*: condición de finalización de actividades con **todas** las 11 autoevaluaciones. Opcional: los 11 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado**: nombre "Constancia de conclusión", tamaño A4 horizontal (297 × 210 mm).
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 11 autoevaluaciones, "debe estar completa con calificación aprobatoria".
3. **Editar certificado:**

   | Elemento | Posición aproximada (mm) | Formato |
   |---|---|---|
   | Imagen de fondo | Cubre la página | `6_certificado/certificado_fondo.png` |
   | Nombre del estudiante | X 0, Y 74, ancho 297, centrado | Negrita, 32 pt, color #0B1220 |
   | Fecha (finalización del curso) | X 17, Y 170, ancho 70, centrado | 12 pt, color #E4007C |
   | Código | X 210, Y 170, ancho 70, centrado | 12 pt, color #E4007C |

4. Revisa la **Vista previa en PDF** y compárala con `certificado_muestra.png`. Activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.


# Parte 3. Comunidad y canales


### 1. Comunidad Tu Patrimonio en Moodle

Un curso aparte, **"Comunidad Tu Patrimonio"** (nombre corto `TPTF-COM`), complemento de este curso. Tiene avisos, foros de dudas por tema, alertas de fraude, logros, sesiones de acompañamiento y un foro separado de referencias comerciales. Su creación está en su propia carpeta.

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Patrimonio" y agregarla con "Sincronización de cohortes" en el curso y en la comunidad.

### 2. Sesiones de acompañamiento

- Una sesión en grupo por módulo o cada dos semanas, presencial o por videollamada, de 60 a 90 minutos.
- En los módulos 3 y 4, práctica guiada con capturas y un simulador. **Nunca** en la banca real de una participante frente al grupo y **nunca** tomando su celular.
- Se invita a la persona de confianza de cada participante, si ella quiere.

### 3. Canal de WhatsApp

- Nombre: "Tu Patrimonio · Desarrolla Talento".
- Contenido: avisos del curso, alertas de fraude, recordatorios (declaración anual, Mes del Testamento, renovación de seguros, pensiones del Bienestar) y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles y circulan fraudes.

### 4. Línea de apoyo

- Horario fijo semanal para dudas del curso por teléfono o mensaje.
- El equipo **nunca** pide datos personales, contraseñas, códigos ni fotos de tarjetas, y **nunca** opera la banca de una participante ni pide instalar apps de control remoto.
- Todos los mensajes del programa se firman igual y dan el mismo número, publicado en el curso, para que las participantes puedan distinguirlo de un fraude.

### 5. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial se publican **solo** en el canal y en el foro de referencias, nunca en lecciones, actividades, autoevaluaciones ni constancia. Cada publicación dice: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 6. Reglas de moderación

1. Borrar publicaciones con datos personales o capturas de cuentas y avisar en privado.
2. No permitir que participantes promuevan productos financieros, préstamos, inversiones o asesores.
3. Revisar el mismo día cualquier alerta de fraude.
4. Canalizar casos legales, fiscales, de pensión o de control económico a la institución o profesional adecuado.


# Parte 4. Mantenimiento


Cada cifra de las lecciones va en un recuadro «Dato vigente» con fecha y fuente. La tabla completa está en el manual del programa, sección 7.

| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Enero | Pensiones del Bienestar (montos y fechas de registro) | M7 U04 |
| Enero | Retención de ISR por intereses (Ley de Ingresos del año) | M5 U04, M9 U02 |
| Febrero | Nueva UMA: límite exento de pensiones y tope de deducciones | M9 |
| Enero | Porcentaje de cuota de Modalidad 40 (sube cada año hasta 2030) | M7 U03 |
| Enero | Edad y años de servicio del décimo transitorio del ISSSTE (bajan gradualmente hasta 2034) | M7 U05 |
| Cada seis meses | Valor de la UDI: límite del IPAB y del MTU en pesos | M3 U03, M5 U02 |
| Cada seis meses | Cifras de fraude de CONDUSEF | M4 U01 |
| Cada año | REPEP, REUS y registro de líneas con CURP | M4 U06, M4 U07 |
| Septiembre | Mes del Testamento: costos y notarías | M10 U01 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco y volver a armar la carpeta | Herramientas del proyecto |

