# Update 1.1 → 1.2 · Your Business, Your Money, Your Future · U.S. · for Claude

This package updates a course **already installed** in Moodle 3.10 from version 1.1 to 1.2. It only contains what changed. Activity names stay the same. **Do not reinstall the course and do not delete activities, attempts, grades, badges or Level Up points.**

Before starting: make a course backup (*Course administration > Backup*, no user data is fine) and turn editing on. If a step can't be done, skip it and report it at the end.

## Change list

M1: new lessons U05, U06; M1 U01: text corrected; M1 U04: text corrected; M2 U01: text corrected; M2 U04: text corrected; M3: new lesson U04; M3 U02: text corrected; M3 U03: text corrected; M4 U01: text corrected; M5 U01: text corrected; M5 U02: text corrected; M5 U03: text corrected; M5 U05: text corrected; M6: new lesson U05; M6 U01: text corrected; M6 U02: text corrected; M6 U04: text corrected; M7: new lessons U06, U07; M7 U04: text corrected; M7 U05: text corrected; M8: new lessons U04, U05, U06; M8 U02: text corrected; M8 U03: text corrected; M9 U01: text corrected; M9 U02: text corrected; M9 U03: text corrected; Support book: chapters 1, 4, 5, 6 corrected; Questions: 27 new; Questions: 7 with corrected text; Glossary: 5 new terms; Support: Excel tools (new resource); Platform: versioned category, badges with course name, standard certificate, surveys, visible course with key and tiles.

## 1. Platform adjustments (one time)

1. **Question category:** in *Question bank > Categories*, rename `Your Business US EN` to `Your Business US EN v1.2` (its M1… subcategories stay).
2. **Badges:** rename each badge so it's unique on the platform: «Separate money» → «Separate money · Your Business US EN»; «Fair price» → «Fair price · Your Business US EN»; «Cash flow under control» → «Cash flow under control · Your Business US EN»; «Formal business» → «Formal business · Your Business US EN»; «Smart credit» → «Smart credit · Your Business US EN»; «Protected business» → «Protected business · Your Business US EN»; «Orderly growth» → «Orderly growth · Your Business US EN»; «Full plan» → «Full plan · Your Business US EN». Badges already issued are kept.
3. **Certificate:** edit the Custom certificate, remove the background image and use the platform's standard template with: course title «Your Business, Your Money, Your Future · U.S.», line «for completing the financial well-being program Your Business, Your Money, Your Future · U.S.» and topics Separate money · Price and cash flow · Taxes and formality · Credit and protection · Growth and future (also in `7_certificate/`). Add the **Final survey** as an access condition.
4. **Visibility and enrolment:** course **visible**; *Enrolment methods* > **Self enrolment** with the enrolment key the person gives you ("[TBD]" if you don't have it). Guest access off.
5. **Format:** if **Tiles** is installed, switch the course format to Tiles with progress on tiles **as a percentage**; otherwise leave Topics.
6. **Surveys:** with the **Feedback** module (anonymous), create `Start survey` (General section), `Final survey`, `30-day follow-up` and `90-day follow-up` (last section) and import the XML files in `6_surveys/` (`surveys.md` explains them). Restrict the follow-ups by date ("[TBD]").
7. **Catalog:** update the course listing with `catalog_card.md`.

## 2. Excel tools

In the "Support materials" section, add a **File** resource named `Tools for your numbers (Excel)` with `8_tools/Tools_YBMF.xlsx`. Display: "Force download". Description: "Type only in the pink cells; the file is yours and isn't shared." Completion: "View". It doesn't count toward course completion.

## 3. By module

### Module 1

**Book `Module 1 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M1/M1_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 6 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 1 > summary, HTML source view, replace everything with `5_section_summaries/M1_resumen.html`.

**H5P activities**
- Changed: open `M1 U04 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M1/M1_U04_what_would_you_do.h5p`. Previous attempts are kept.
- New: *Add an activity > H5P*, name `M1 U05 · What would you do?`, file `2_h5p/M1/M1_U05_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- New: *Add an activity > H5P*, name `M1 U06 · What would you do?`, file `2_h5p/M1/M1_U06_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 2

**Book `Module 2 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M2 U04. Inventory and waste».
2. In "M2 U01. Fixed and variable costs", subchapter "Go deeper · +5 min", *Edit*: change the text "You work for free" to "You work without pay" and save.
3. In "M2 U01. Fixed and variable costs", subchapter "Practice", *Edit*: change the text "1-b: it goes up with each sale. 2-a: $600 divided by 200. 3-c: without it you work for free." to "1-b: it goes up with each sale. 2-a: $600 divided by 200. 3-c: without it you work without pay." and save.
4. *Import chapter* > `1_books/M2/M2_U04_lesson.zip`, type "Each HTML file represents one chapter". It creates "M2 U04. Inventory and waste" with 3 subchapters.
5. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M2 U01. Fixed and variable costs» → «M2 U02. How much should you charge?» → «M2 U03. Your break-even point» → «M2 U04. Inventory and waste».

**H5P activities**
- Changed: open `M2 U04 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M2/M2_U04_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 3

**Book `Module 3 lessons`**
1. In "M3 U02. Customer credit, invoices and collections", subchapter "The essentials · 5 min", *Edit*: change the text "When you deliver before you get paid, you lend your money interest-free. It can help you sell more, but if it grows without control, it leaves you without cash." to "When you deliver before you get paid, you lend your money no-interest. It can help you sell more, but if it grows without control, it leaves you without cash." and save.
2. In "M3 U02. Customer credit, invoices and collections", subchapter "Practice", *Edit*: change the text "b) An interest-free loan to your customer" to "b) An no-interest loan to your customer" and save.
3. In "M3 U03. Your reserve and slow seasons", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M3 U04. Inflation, interest rates and compound interest in your business." and save.
4. *Import chapter* > `1_books/M3/M3_U04_lesson.zip`, type "Each HTML file represents one chapter". It creates "M3 U04. Inflation, interest rates and compound interest in your business" with 3 subchapters.
5. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M3 U01. Profit isn't cash» → «M3 U02. Customer credit, invoices and collections» → «M3 U03. Your reserve and slow seasons» → «M3 U04. Inflation, interest rates and compound interest in your business».

**Section summary:** *Edit section* for Module 3 > summary, HTML source view, replace everything with `5_section_summaries/M3_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M3 U04 · What would you do?`, file `2_h5p/M3/M3_U04_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 4

**Book `Module 4 lessons`**
1. In "M4 U01. Cash, card, apps or payment link", subchapter "M4 U01. Cash, card, apps or payment link", *Edit*: change the text "Don Ramón's customers want to pay by card and with apps. He's offered a "free" card reader, but he doesn't know what he'll be charged or when he'll get the deposits. In this lesson you'll see how to compare." to "Don Ramón's customers want to pay by card and with apps. He's offered a "at no cost" card reader, but he doesn't know what he'll be charged or when he'll get the deposits. In this lesson you'll see how to compare." and save.
2. In "M4 U01. Cash, card, apps or payment link", subchapter "Go deeper · +5 min", *Edit*: change the text "Don Ramón is offered a "free" reader with a two-year contract." to "Don Ramón is offered a "at no cost" reader with a two-year contract." and save.

**H5P activities**
- Changed: open `M4 U01 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M4/M4_U01_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 5

**Book `Module 5 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M5 U02. Numbers and permits: EIN, ITIN and licenses».
2. In "M5 U01. Sole proprietor, LLC or something else?", subchapter "Go deeper · +5 min", *Edit*: change the text "your state's rules and costs on the Secretary of State's site; if you have questions, talk to an accountant or a free SBA center (SBDC)." to "your state's rules and costs on the Secretary of State's site; if you have questions, talk to an accountant or a no-cost SBA center (SBDC)." and save.
3. In "M5 U03. Your federal taxes as an owner", subchapter "Go deeper · +5 min", *Edit*: change the text "VITA programs help people with moderate incomes for free, although not all of them handle businesses with complex expenses. As your business grows, an accountant or a preparer with a PTIN saves you mistakes. Your state (in California, the Franchise Tax Board) also charges income tax." to "VITA programs help people with moderate incomes at no cost, although not all of them handle businesses with complex expenses. As your business grows, an accountant or a preparer with a PTIN saves you mistakes. Your state (in California, the Franchise Tax Board) also charges income tax." and save.
4. In "M5 U05. Sales tax", subchapter "The essentials · 5 min", *Edit*: change the text "in California, the base statewide sales tax rate is 7.25%, and many cities and counties add local rates. Selling taxable products requires a seller's permit from the CDTFA, which is free. Accessed September 29, 2026 through the CDTFA." to "in California, the base statewide sales tax rate is 7.25%, and many cities and counties add local rates. Selling taxable products requires a seller's permit from the CDTFA, which costs nothing. Accessed September 29, 2026 through the CDTFA." and save.
5. *Import chapter* > `1_books/M5/M5_U02_lesson.zip`, type "Each HTML file represents one chapter". It creates "M5 U02. Numbers and permits: EIN, ITIN and licenses" with 3 subchapters.
6. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M5 U01. Sole proprietor, LLC or something else?» → «M5 U02. Numbers and permits: EIN, ITIN and licenses» → «M5 U03. Your federal taxes as an owner» → «M5 U04. Quarterly payments and 1099 forms» → «M5 U05. Sales tax».

**H5P activities**
- Changed: open `M5 U02 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M5/M5_U02_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 6

**Book `Module 6 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M6 U02. Credit options and how to check them».
2. In "M6 U01. Do you need credit?", subchapter "Practice", *Edit*: change the text "1-b: payment higher than profit. 2-c: it can pay for itself. 3-a: an interest-free alternative." to "1-b: payment higher than profit. 2-c: it can pay for itself. 3-a: an no-interest alternative." and save.
3. In "M6 U04. Don't mix debts, and be careful about cosigning", subchapter "Go deeper · +5 min", *Edit*: change the text "A card in the business's name, used carefully and paid in full, helps separate expenses. Check your personal credit report for free every year at AnnualCreditReport.com." to "A card in the business's name, used carefully and paid in full, helps separate expenses. Check your personal credit report at no cost every year at AnnualCreditReport.com." and save.
4. In "M6 U04. Don't mix debts, and be careful about cosigning", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M6 U05. Cosigner, guarantor, authorized user and reference: what are you signing?." and save.
5. *Import chapter* > `1_books/M6/M6_U02_lesson.zip`, type "Each HTML file represents one chapter". It creates "M6 U02. Credit options and how to check them" with 3 subchapters.
6. *Import chapter* > `1_books/M6/M6_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M6 U05. Cosigner, guarantor, authorized user and reference: what are you signing?" with 3 subchapters.
7. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M6 U01. Do you need credit?» → «M6 U02. Credit options and how to check them» → «M6 U03. The total cost: APR, fees and guarantees» → «M6 U04. Don't mix debts, and be careful about cosigning» → «M6 U05. Cosigner, guarantor, authorized user and reference: what are you signing?».

**Section summary:** *Edit section* for Module 6 > summary, HTML source view, replace everything with `5_section_summaries/M6_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M6 U05 · What would you do?`, file `2_h5p/M6/M6_U05_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 7

**Book `Module 7 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M7 U05. Identity theft and unwanted calls».
2. In "M7 U04. Your brand and your name", subchapter "Go deeper · +5 min", *Edit*: change the text "If someone says your name is their trademark, check the USPTO before replying. If their registration is real and covers your products, changing your name is usually the wisest move. Some universities have free intellectual property law clinics." to "If someone says your name is their trademark, check the USPTO before replying. If their registration is real and covers your products, changing your name is usually the wisest move. Some universities have no-cost intellectual property law clinics." and save.
3. *Import chapter* > `1_books/M7/M7_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U05. Identity theft and unwanted calls" with 3 subchapters.
4. *Import chapter* > `1_books/M7/M7_U06_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U06. AI scams: fake voices, videos and messages" with 3 subchapters.
5. *Import chapter* > `1_books/M7/M7_U07_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U07. If disaster strikes: your business ready" with 3 subchapters.
6. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M7 U01. Your health when you work for yourself» → «M7 U02. Insurance for your business» → «M7 U03. Scams against businesses» → «M7 U04. Your brand and your name» → «M7 U05. Identity theft and unwanted calls» → «M7 U06. AI scams: fake voices, videos and messages» → «M7 U07. If disaster strikes: your business ready».

**Section summary:** *Edit section* for Module 7 > summary, HTML source view, replace everything with `5_section_summaries/M7_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M7 U06 · What would you do?`, file `2_h5p/M7/M7_U06_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- New: *Add an activity > H5P*, name `M7 U07 · What would you do?`, file `2_h5p/M7/M7_U07_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 8

**Book `Module 8 lessons`**
1. In "M8 U02. Selling online and on platforms", subchapter "The essentials · 5 min", *Edit*: change the text "Daniela figured out what she keeps per channel. On one platform she kept $20; on her own site, $26, but she sells less. She raised her platform price to $44 and offers free shipping on her site for two or more pieces." to "Daniela figured out what she keeps per channel. On one platform she kept $20; on her own site, $26, but she sells less. She raised her platform price to $44 and offers no-cost shipping on her site for two or more pieces." and save.
2. In "M8 U03. Your monthly numbers", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M8 U04. Stress, business and family." and save.
3. *Import chapter* > `1_books/M8/M8_U04_lesson.zip`, type "Each HTML file represents one chapter". It creates "M8 U04. Stress, business and family" with 3 subchapters.
4. *Import chapter* > `1_books/M8/M8_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M8 U05. Your one-page business plan and how to pitch it" with 3 subchapters.
5. *Import chapter* > `1_books/M8/M8_U06_lesson.zip`, type "Each HTML file represents one chapter". It creates "M8 U06. Your business and its surroundings: competition, economy, community and rule changes" with 3 subchapters.
6. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M8 U01. Hiring help» → «M8 U02. Selling online and on platforms» → «M8 U03. Your monthly numbers» → «M8 U04. Stress, business and family» → «M8 U05. Your one-page business plan and how to pitch it» → «M8 U06. Your business and its surroundings: competition, economy, community and rule changes».

**Section summary:** *Edit section* for Module 8 > summary, HTML source view, replace everything with `5_section_summaries/M8_resumen.html`.

**H5P activities**
- Changed: open `M8 U01 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M8/M8_U01_what_would_you_do.h5p`. Previous attempts are kept.
- New: *Add an activity > H5P*, name `M8 U04 · What would you do?`, file `2_h5p/M8/M8_U04_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- New: *Add an activity > H5P*, name `M8 U05 · What would you do?`, file `2_h5p/M8/M8_U05_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- New: *Add an activity > H5P*, name `M8 U06 · What would you do?`, file `2_h5p/M8/M8_U06_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 9

**Book `Module 9 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M9 U03. Your one-page plan».
2. In "M9 U01. Your retirement when you work for yourself", subchapter "Go deeper · +5 min", *Edit*: change the text "Contributions to a traditional IRA, SEP or Solo 401(k) can lower your taxes today; with a Roth you pay taxes today and withdraw tax-free in retirement, if you follow the rules. Withdrawing before age 59½ usually carries a penalty. Ask your preparer which one fits you." to "Contributions to a traditional IRA, SEP or Solo 401(k) can lower your taxes today; with a Roth you pay taxes today and withdraw without taxes in retirement, if you follow the rules. Withdrawing before age 59½ usually carries a penalty. Ask your preparer which one fits you." and save.
3. In "M9 U02. If the business changes or you're not there", subchapter "Go deeper · +5 min", *Edit*: change the text "The business's equipment, inventory and money are part of your estate. A will or living trust and up-to-date beneficiaries on accounts, IRAs and insurance spare your family long proceedings. There are free or low-cost legal clinics." to "The business's equipment, inventory and money are part of your estate. A will or living trust and up-to-date beneficiaries on accounts, IRAs and insurance spare your family long proceedings. There cost nothing or low-cost legal clinics." and save.
4. *Import chapter* > `1_books/M9/M9_U03_lesson.zip`, type "Each HTML file represents one chapter". It creates "M9 U03. Your one-page plan" with 3 subchapters.
5. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M9 U01. Your retirement when you work for yourself» → «M9 U02. If the business changes or you're not there» → «M9 U03. Your one-page plan».

## 4. "Support materials" book

- Chapter 1 "Welcome": delete it, *Import chapter* > `1_books/Apoyo/01_apoyo.zip` and move it up with the arrows to position 1.
- Chapter 4 "Glossary": delete it, *Import chapter* > `1_books/Apoyo/04_apoyo.zip` and move it up with the arrows to position 4.
- Chapter 5 "Where to get help": delete it, *Import chapter* > `1_books/Apoyo/05_apoyo.zip` and move it up with the arrows to position 5.
- Chapter 6 "References": delete it, *Import chapter* > `1_books/Apoyo/06_apoyo.zip` and move it up with the arrows to position 6.

## 5. Glossary

In the `Course key words` glossary: *Import entries* > `3_glossary/Glossary_new_terms.xml`, destination "current glossary". It only has the 5 new terms.

## 6. Questions and self-assessments

1. **Corrected text (7):** in the bank, open each question and *Edit*; replace the stem, options and feedback with those in `4_questions/corrected_questions_reference.gift.txt` (same name, don't import it). Editing doesn't delete attempts. Questions: M1 U01 P3, M1 U04 P3, M2 U01 P3, M3 U02 P1, M5 U02 P1, M6 U01 P3, M7 U05 P1.
2. **New (27):** *Question bank > Import*, GIFT format, `4_questions/new_questions.gift.txt`. They go into `Your Business US EN v1.2/MN`.
3. Add the new ones to their self-assessment, 10 per page. **If the quiz already has attempts, Moodle won't let you add questions:** don't delete attempts; leave it and note it in your report.
   - `Module 1 self-assessment`: M1 U05 P1, M1 U05 P2, M1 U05 P3, M1 U06 P1, M1 U06 P2, M1 U06 P3.
   - `Module 3 self-assessment`: M3 U04 P1, M3 U04 P2, M3 U04 P3.
   - `Module 6 self-assessment`: M6 U05 P1, M6 U05 P2, M6 U05 P3.
   - `Module 7 self-assessment`: M7 U06 P1, M7 U06 P2, M7 U06 P3, M7 U07 P1, M7 U07 P2, M7 U07 P3.
   - `Module 8 self-assessment`: M8 U04 P1, M8 U04 P2, M8 U04 P3, M8 U05 P1, M8 U05 P2, M8 U05 P3, M8 U06 P1, M8 U06 P2, M8 U06 P3.

## 7. Check and report

With *Switch role to > Student*, open one new lesson and its H5P. Report: chapters per changed book, new or replaced H5P, corrected and imported questions, quizzes that couldn't change because they have attempts, imported terms, platform adjustments done and anything you couldn't do.

The `9_for_the_team/` folder (facilitator kit, WhatsApp and audio scripts, OECD map) is for the program team: **don't upload it to Moodle**.
