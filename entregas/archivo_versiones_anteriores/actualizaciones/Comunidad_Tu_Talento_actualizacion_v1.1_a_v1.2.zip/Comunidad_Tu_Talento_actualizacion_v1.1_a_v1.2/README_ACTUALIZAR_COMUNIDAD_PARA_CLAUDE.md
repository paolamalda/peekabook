# Actualización 1.1 → 1.2 · Comunidad Tu Talento · para Claude

Este paquete actualiza la comunidad **ya creada** (`TTMF-COM`) en Moodle 3.10. Solo trae lo que cambió. No borres foros, publicaciones ni participantes.

## Lista de cambios

Guía: capítulo 1 corregido; Guía: capítulo 3 corregido; Guía: capítulo 4 corregido; Guía: capítulo 5 corregido; Guía: capítulo 6 corregido; Plataforma: curso visible con clave de inscripción; Equipo: guia_moderacion.md, calendario_editorial.md, manual_profesor.md.

## 1. Visibilidad e inscripción

En *Editar ajustes* del curso: visibilidad **Mostrar**. En *Participantes > Métodos de inscripción*: **Autoinscripción** activa con la clave que te dé la persona («[por definir]» si no la tienes); sin acceso de invitados. Las fechas de sesiones y los enlaces de WhatsApp se quedan como «[por definir]» hasta que la persona los dé.

## 2. Libro «Guía de la comunidad»

- Capítulo 1: borra «Bienvenida a la comunidad» y usa *Importar capítulo* > `1_libro/01_comunidad.zip` ("Cada archivo HTML representa un capítulo"); crea «Bienvenida a la comunidad». Súbelo con las flechas a la posición 1.
- Capítulo 3: borra «Cómo preguntar para recibir una buena respuesta» y usa *Importar capítulo* > `1_libro/03_comunidad.zip` ("Cada archivo HTML representa un capítulo"); crea «Cómo preguntar para recibir una buena respuesta». Súbelo con las flechas a la posición 3.
- Capítulo 4: borra «Tu calendario del año» y usa *Importar capítulo* > `1_libro/04_comunidad.zip` ("Cada archivo HTML representa un capítulo"); crea «Tu calendario del año». Súbelo con las flechas a la posición 4.
- Capítulo 5: borra «Sesiones en vivo y actividades» y usa *Importar capítulo* > `1_libro/05_comunidad.zip` ("Cada archivo HTML representa un capítulo"); crea «Sesiones en vivo y actividades». Súbelo con las flechas a la posición 5.
- Capítulo 6: borra «Cómo funcionan las referencias comerciales» y usa *Importar capítulo* > `1_libro/06_comunidad.zip` ("Cada archivo HTML representa un capítulo"); crea «Cómo funcionan las referencias comerciales». Súbelo con las flechas a la posición 6.
- Si alguna página o etiqueta copió texto de estos capítulos (por ejemplo, «Sesiones de acompañamiento»), actualiza ese texto igual.

La carpeta `2_para_el_equipo/` es para el equipo de moderación: **no se sube a Moodle**.

## Reporte

Reporta los capítulos reemplazados, la clave usada (sin escribirla en foros) y lo que no pudiste hacer.
