# Update 1.1 → 1.2 · Your Business Community · U.S. · for Claude

This package updates the community **already created** (`YBMF-US-EN-COM`) in Moodle 3.10. It only contains what changed. Don't delete forums, posts or participants.

## Change list

Guide: chapter 6 corrected; Platform: visible course with enrolment key; Team: guia_moderacion.md, manual_profesor.md.

## 1. Visibility and enrolment

In the course's *Edit settings*: visibility **Show**. In *Participants > Enrolment methods*: **Self enrolment** enabled with the key the person gives you ("[TBD]" if you don't have it); no guest access. Session dates and WhatsApp links stay as "[TBD]" until the person provides them.

## 2. "Community guide" book

- Chapter 6: delete "How commercial referrals work" and use *Import chapter* > `1_libro/06_comunidad.zip` ("Each HTML file represents one chapter"); it creates "How commercial referrals work". Move it up with the arrows to position 6.
- If any page or label copied text from these chapters (for example, "Support sessions"), update that text too.

The `2_for_the_team/` folder is for the moderation team: **don't upload it to Moodle**.

## Report

Report the chapters replaced, that the key was set (don't post it in forums) and anything you couldn't do.
