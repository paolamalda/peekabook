YOUR MONEY, YOUR FAMILY, YOUR FUTURE
English course · Version 3.2 · Desarrolla Talento · September 2026

Free personal finance course for immigrants in the U.S. (California pilot): 5 modules, 59 lessons. Same content as the Spanish course.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt   This file.
01_Manual/      Operator manual v3.0: program, rules, editorial guide, assessment and keys, metrics, matrix, state expansion, privacy and traceability.
02_Content/     Full content v3.2: 59 lessons, support book, 59 H5P activities and 177-question bank (.docx and .md).
03_Guide/       Implementation guide v3.2: Moodle installation, points, badges and certificate, and maintenance (.docx and .md).
04_Moodle/      Installation package: books, H5P, glossary, bank, badges, certificate, gamification guide, preview and the README for Claude.

HOW IT FITS TOGETHER
--------------------
The folder comes in 3 zips because of size. Unzip them all in the same place: they merge into this folder.
Part 1 has everything except the H5P activities; the other parts add 04_Moodle/2_h5p.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Coordinator read the operator manual
[ ] Content reviewed by a native English speaker and subject experts
[ ] Course installed with 04_Moodle/README_INSTALAR_CURSO_INGLES_PARA_CLAUDE.md
[ ] Level Up, badges and certificate set up
[ ] Review with the student role
[ ] Maintenance calendar assigned (03_Guide, part 3)

KEEP IN MIND
------------
- Never ask for SSN, ITIN, immigration status or passwords; never give immigration advice.
- Some lesson facts are marked [POR CONFIRMAR]: confirm them at the official source before opening the course.
- Mexican names (AFORE, CURP, IMSS, matrícula consular) stay in Spanish on purpose.
