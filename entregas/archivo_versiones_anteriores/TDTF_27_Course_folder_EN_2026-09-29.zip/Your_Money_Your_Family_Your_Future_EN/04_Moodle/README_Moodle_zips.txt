MOODLE PACKAGES FOR THIS COURSE

Copy these zips here (they are in the deliveries folder; they are not included in this zip because of their size). Unzip all parts in the same place and follow the guide in 03_Guide.

- TDTF_25_Full_course_EN_v3.2_parte1_curso_2026-09-28.zip
- TDTF_25_Full_course_EN_v3.2_parte2_H5P_M1-M2_2026-09-28.zip
- TDTF_25_Full_course_EN_v3.2_parte3_H5P_M3-M5_2026-09-28.zip
