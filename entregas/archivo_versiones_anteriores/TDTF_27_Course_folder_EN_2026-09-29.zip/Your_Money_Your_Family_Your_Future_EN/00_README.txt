YOUR MONEY, YOUR FAMILY, YOUR FUTURE
English course · Version 3.2 · Desarrolla Talento · 2026-09-29

Free personal finance course for immigrants in the U.S. (California pilot): 5 modules, 59 lessons. Same content as the Spanish course.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt         This file.
01_Manual/            Operator Manual: the program, rules, assessment, metrics, privacy and traceability.
02_Content/           Full content: 59 lessons, support book, H5P and question bank (.docx and .md).
03_Guide/             Implementation guide: Moodle installation, gamification and maintenance (.docx and .md).
04_Moodle/            Put the Moodle course zips here (see the list inside).
05_Graphics/          Badges and certificate background and sample.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Operator Manual read by the coordinator
[ ] Content reviewed by the team and subject experts
[ ] Moodle zips copied into 04_Moodle
[ ] Course installed following 03_Guide, part 1
[ ] Level Up, badges and certificate set up (03_Guide, part 2)
[ ] Review with the student role
[ ] Maintenance calendar assigned to a person (03_Guide, part 3)

KEEP IN MIND
------------
- The Operator Manual is version 2.0: its framework (rules, privacy, metrics, state expansion) still applies, but lesson structure, H5P types and platform grading changed in version 3. On those points, follow 03_Guide.
- The Participant Manual v2.1 was replaced by the v3.2 content (same 59 lessons, rewritten). It is not included, to avoid two versions.
- Never ask for SSN, ITIN, immigration status or passwords; never give immigration advice.
