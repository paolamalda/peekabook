# Comunidad Tu Idea: contenido

## Bienvenida a la comunidad

**Comunidad Tu Idea** es el espacio de quienes toman el programa *Tu Idea, Tu Dinero, Tu Futuro*. Aquí resuelves dudas, compartes tus avances, cumples retos y te enteras de las sesiones con tu escuela. Es un espacio moderado por el equipo y pensado para jóvenes de 15 a 18 años.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas, retos, sesiones y alertas. Solo publica el equipo. |
| **Lo que quiero lograr** | En una frase, qué quieres lograr. Sin datos personales. |
| **Foros de dudas** | Tres foros: mi dinero y lo digital; crear y crecer; invertir, crédito y protección. |
| **Vitrina de ideas** | Cuenta tu idea y pide retroalimentación. No se vende ni se cobra aquí. |
| **Alertas de fraude** | Avisa de ofertas de «dinero fácil», cuentas mula o sorteos falsos. |
| **Logros** | Celebra tus avances: tu primera venta, tu meta, tu seguro activado. |
| **Sesiones con tu escuela** | Sesiones en grupo para repasar cada módulo. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar, compartir ideas y apoyarse.
- **No es** un lugar para vender, cobrar, pedir o prestar dinero, ni para invitar a inversiones, cripto o apuestas.
- **No hay mensajes privados** entre participantes: todo se habla en los foros, donde el equipo modera.

### Cómo reconocer al equipo

El equipo **nunca** te pide datos personales, fotos, tu ubicación, tus redes, contraseñas ni códigos, ni te escribe por fuera de la plataforma. Si alguien lo hace en nombre de la comunidad, avisa a un adulto de confianza y al equipo.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Si quieres, comparte en **Lo que quiero lograr** qué te gustaría lograr, en una frase y sin datos personales.
3. Revisa los retos del mes (capítulo 5).
4. Cuando tengas una duda, usa la plantilla del capítulo 3.


## Reglas que te cuidan

Estas reglas protegen tu información, tu seguridad y la de todas y todos.

### Tus datos

- **Nunca publiques** tu apellido, dirección, escuela, horarios, teléfono, redes sociales, fotos tuyas, contraseñas, códigos ni números de cuenta.
- Usa **números inventados** en tus ejemplos.
- Los foros no permiten adjuntar archivos.

### Seguridad en línea

- No aceptes invitaciones para hablar por otras apps o redes con personas de la comunidad.
- No quedes de verte en persona con nadie de la comunidad fuera de las sesiones de tu escuela.
- Si alguien te hace sentir incómodo, te pide fotos o te amenaza: no respondas, guarda capturas y avisa a un adulto de confianza y al equipo.

### Respeto

- Sin burlas, insultos ni acoso. Todas las ideas empiezan pequeñas.
- Critica ideas, no personas.

### Lo que no se permite

1. Vender, cobrar, pedir o prestar dinero.
2. Invitar a inversiones, cripto, trading, apuestas, tandas o «negocios» de invitar amigos.
3. Publicar enlaces de sitios no oficiales.
4. Hacerse pasar por otra persona o por el equipo.

### Qué hace el equipo

- Retira publicaciones con datos personales y te avisa.
- Retira publicaciones que venden o invitan a apostar o invertir.
- Suspende a quien acose o incumpla las reglas.
- Avisa a la escuela cuando hay un riesgo para alguien.


## Cómo preguntar y pedir ayuda

### Plantilla

**Módulo o tema:** (por ejemplo, M3 precio)
**Mi situación, con números inventados:** (por ejemplo, «mi pulsera me cuesta 22»)
**Lo que ya revisé:** (por ejemplo, «leí M3 U03»)
**Mi duda concreta:** (una pregunta)

### Lo que la comunidad puede y no puede resolver

| Sí | No |
|---|---|
| Dudas del curso | Abrirte cuentas o hacer trámites |
| Retroalimentación a tu idea | Comprarte o venderte algo |
| Cómo reconocer un fraude | Recomendarte apps, cripto o inversiones |
| A qué institución acudir | Guardar tus datos o contraseñas |

### Si algo no está bien

Si te sientes en riesgo, te amenazan o alguien te pide algo que te incomoda, avisa a un adulto de confianza y al equipo. Si hay peligro, llama al 911. Para apoyo emocional, la Línea de la Vida atiende las 24 horas en el 800 911 2000.

### Responder a otras personas

Comparte tu experiencia con respeto, sin recomendar marcas ni personas. Si no estás seguro, remite a la lección.


## Tu calendario del ciclo escolar

Fechas que importan para tu dinero y tus ideas. En **Avisos** te las recordamos.

| Mes | Recordatorio | Lección |
|---|---|---|
| Agosto y septiembre | Revisa el registro de tu beca y activa tu seguro de estudiante | M1 U04 · M7 U02 |
| Septiembre | Haz tu presupuesto del semestre | M1 U04 |
| Octubre | Lista de 10 problemas para tu idea | M3 U01 |
| Noviembre | Cuidado con compras de temporada y ofertas «solo hoy» | M1 U03 |
| Diciembre | Si recibes dinero extra: guardar, crear y gastar | M1 U01 |
| Enero | Pon tu meta del año con nombre y fecha | M5 U01 |
| Febrero | Prueba tu idea con poco dinero | M3 U02 |
| Marzo | Revisa tus contraseñas y la verificación en dos pasos | M7 U04 |
| Abril | Revisa tu costo, tu precio y tu ganancia | M3 U03 |
| Mayo | Carpeta familiar de papeles | M8 U04 |
| Junio | Plan para después de la prepa | M9 U01 |
| Julio | Tu plan de una página | M9 U03 |

Las fechas oficiales pueden cambiar. Confírmalas en el sitio de cada institución.


## Sesiones con tu escuela, retos y vitrina de ideas

### Sesiones

Una sesión por módulo o cada dos semanas, en tu escuela o por videollamada del grupo, con tu profesora o profesor. La fecha se publica en **Avisos** («[por definir]» hasta confirmarla).

- Duración: 50 a 60 minutos.
- Repasamos el módulo, resolvemos dudas y hacemos un reto en equipo con números inventados.

### Retos del mes

| Mes | Reto |
|---|---|
| 1 | Tu presupuesto: guardar, crear y gastar (M1 U04) |
| 2 | Tu lista de 7 días para compras (M1 U03) |
| 3 | Tu lista de 10 problemas (M3 U01) |
| 4 | Diseña tu prueba con poco dinero (M3 U02) |
| 5 | Calcula costo, precio y ganancia (M3 U03) |
| 6 | Tu meta con nombre y fecha (M5 U01) |
| 7 | Activa tu seguro de estudiante (M7 U02) |
| 8 | Verificación en dos pasos en tu correo (M7 U04) |
| 9 | Tu plan de una página con compromiso (M9 U03) |

### Vitrina de ideas

Cuenta tu idea en tres líneas: qué problema resuelves, para quién y cómo lo probarías. Otras personas te dan retroalimentación con respeto. **No se vende ni se cobra en la comunidad** y no se publican datos de contacto.

### Encuesta de la comunidad

Una vez por semestre te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima.


## Contenido del programa y ofertas comerciales

Queremos que sepas exactamente qué es contenido del programa y qué es una oferta comercial.

### En esta comunidad

Como participan menores de edad, **esta comunidad no publica referencias comerciales**. Todo lo que ves aquí es contenido del programa o publicaciones de participantes moderadas por el equipo.

### Si alguien te ofrece algo

Si en la comunidad o fuera de ella alguien te ofrece un producto, una app, una inversión o un «negocio», aplica lo del curso:

- Verifica la institución en el SIPRES de la CONDUSEF (M8 U01).
- Desconfía de «dinero fácil», ganancias garantizadas o invitar amigos (M5 U04 y M7 U03).
- Habla con un adulto de confianza antes de decidir.

### Qué nunca verás

- Préstamos, cripto, trading ni apuestas.
- Ofertas de trabajo que pidan pagar o usar tu cuenta.
- Presión para decidir.

