# Comunidad Tu Negocio: manual de la comunidad

# Parte 1. Comunidad y canales


### 1. Comunidad Tu Negocio en Moodle

Un curso aparte, **"Comunidad Tu Negocio"** (nombre corto `DT-NEGOCIO-MX-ES-COM`), complemento de este curso. Tiene avisos, foros de dudas por tema, alertas de fraude, el foro «Presenta tu negocio», logros, una sesión mensual en vivo y un foro separado de referencias comerciales. Su creación está en su propia carpeta.

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Negocio MX" y agregarla con "Sincronización de cohortes" en el curso y en la comunidad.

### 2. Sesión mensual en vivo

- Una sesión al mes por videollamada, de 60 minutos: tema del mes (por ejemplo, «Tu declaración mensual en RESICO», «Precio con margen») y preguntas.
- Se usan ejemplos inventados. **Nunca** se abre el portal del SAT, la banca o la plataforma de una participante frente al grupo.
- Si se invita a una persona experta (contador, IMSS, PRODECON), se aclara que es orientación general.

### 3. Canal de WhatsApp

- Nombre: "Tu Negocio MX · Desarrolla Talento".
- Contenido: avisos del curso, fechas fiscales (día 17, declaración anual en abril), alertas de fraude a negocios y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles y circulan fraudes y ofertas de «créditos».

### 4. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial (por ejemplo, terminales, facturación o contabilidad) se publican **solo** en el canal y en el foro de referencias, nunca en lecciones, actividades, autoevaluaciones ni constancia. Cada publicación dice: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 5. Reglas de moderación

1. Borrar publicaciones con datos personales o fiscales (RFC, contraseñas, e.firma, capturas de cuentas) y avisar en privado.
2. No permitir que participantes promuevan préstamos, inversiones, «tandas», productos financieros ni venta de facturas.
3. En «Presenta tu negocio», una publicación al mes por persona.
4. Revisar el mismo día cualquier alerta de fraude.
5. Canalizar casos fiscales, legales o laborales al SAT, PRODECON, el IMSS o un profesional.


# Parte 2. Guía de moderación


Para el equipo que modera los foros y el canal. Versión 1.0 · Septiembre de 2026.

### 1. Principios

1. **Proteger datos personales y fiscales** antes que cualquier otra cosa.
2. **Orientar, no asesorar:** explicamos reglas generales y canalizamos; no resolvemos casos fiscales, legales o laborales concretos.
3. **Nunca operar por ellas:** no entramos al portal del SAT, a la banca ni a la plataforma de nadie; explicamos y la persona hace los pasos.
4. **Cero venta de productos financieros**; los negocios se presentan solo en su foro, y las referencias comerciales, solo en su foro y con aviso.
5. **Tono del curso:** tuteo cercano, sin juicios sobre la informalidad.

### 2. Tiempos de respuesta

| Tipo | Meta |
|---|---|
| Publicación con datos personales o fiscales | Retirar en menos de 2 horas hábiles |
| Alerta de fraude | Revisar el mismo día y fijar si es relevante |
| Fraude o extorsión en curso (mensaje privado) | Responder de inmediato con el protocolo |
| Duda general | Responder en 48 horas hábiles |

### 3. Qué hacer en cada caso

| Situación | Acción | Mensaje privado sugerido |
|---|---|---|
| Publica RFC, e.firma, cuenta o captura del SAT o del banco | Retirar la publicación | "Retiramos tu publicación porque tenía datos personales o fiscales. Puedes volver a preguntar con números inventados o redondeados." |
| Ofrece préstamos, inversiones o tandas | Retirar y advertir | "En la comunidad no se permiten ofertas financieras. Revisa las reglas en el capítulo 2." |
| Ofrece facturas o «bajar impuestos» | Retirar, advertir y avisar a coordinación | "La compra y venta de facturas es ilegal y no se permite en la comunidad (M5 U03)." |
| Promociona su negocio fuera de su foro o más de una vez al mes | Mover o retirar | "Te pedimos usar **Presenta tu negocio**, una vez al mes. ¡Gracias por compartir!" |
| Recomienda un gestor del SAT o del IMSS | Retirar y explicar | "Los trámites del SAT y del IMSS no tienen costo y se hacen en sus sitios oficiales (M5 U01 y M7 U01)." |
| Pide que revisemos su declaración o su régimen | Responder lo general y canalizar | "Tu caso depende de tus datos. Te sugerimos el SAT o PRODECON, que orientan sin costo; la lección [lección] te ayuda a llevar tus preguntas." |
| Fraude al vender en curso | Responder de inmediato | "Guarda evidencia, reporta a tu banco o proveedor de pagos, reclama por escrito con folio y denuncia al 088 (M4 U03)." |
| Extorsión o «cobro de piso» | Responder de inmediato | "No negocies y cuelga. Denuncia al 089 o al 088; si hay riesgo, 911 (M7 U03)." |
| Conflicto laboral con un trabajador | Responder lo general y canalizar | "Las obligaciones como patrón se revisan con el IMSS, el SAT y un profesional (M8 U01)." |
| Conflicto entre participantes | Recordar reglas; si sigue, suspender | "Te pedimos mantener el respeto. Es la regla de la comunidad." |

### 4. Respuestas tipo

**Duda que ya está en el curso:**
"¡Buena pregunta! Lo explicamos en [lección]. En corto: [resumen de 2 líneas]. Si después de leerla sigues con dudas, cuéntanos qué parte."

**Dato fiscal que cambia:**
"Este dato cambia con cada reforma. Al [fecha] era [dato] según [fuente]. Confírmalo en el SAT antes de decidir."

**Petición de recomendación:**
"No recomendamos bancos, terminales, plataformas ni contadores específicos. Te dejamos cómo comparar: [lección]. Si quieres, comparte las opciones que ves, sin datos personales, y te ayudamos a revisar qué preguntar."

### 5. Qué nunca hacemos

- Pedir RFC, contraseñas, e.firma, números de cuenta o montos reales.
- Entrar al portal del SAT, a la banca o a la plataforma de una participante.
- Recomendar una institución, un producto, un contador o un proveedor fuera del foro de referencias.
- Prometer resultados fiscales o de crédito.

### 6. Escalamiento

1. Moderación responde o canaliza.
2. Coordinación revisa casos repetidos, ofertas de facturas, quejas sobre referencias y suspensiones.
3. Si un contenido del curso resulta incorrecto o desactualizado, se registra para la siguiente versión.

### 7. Métricas mensuales

| Métrica | Para qué |
|---|---|
| Personas activas y nuevas | Saber si la comunidad crece |
| Dudas publicadas y respondidas en 48 horas | Calidad de atención |
| Temas más preguntados | Mejorar lecciones y sesiones |
| Alertas de fraude | Detectar tendencias |
| Asistencia a la sesión mensual | Participación |
| Publicaciones en «Presenta tu negocio» | Vida de la comunidad |
| Publicaciones retiradas | Ajustar reglas y avisos |

