# Comunidad Tu Negocio: contenido

## Bienvenida a la comunidad

**Comunidad Tu Negocio** es el espacio de quienes toman el programa *Tu Negocio, Tu Dinero, Tu Futuro* en México. Es un complemento del curso: aquí resuelves dudas, compartes avances, conoces otros negocios, te enteras de fechas fiscales y te alertas de fraudes con otras personas que emprenden.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas fiscales, recordatorios, sesión mensual y alertas. Solo publica el equipo. |
| **Preséntate** | Di quién eres, qué negocio tienes y qué quieres lograr. |
| **Foros de dudas** | Tres foros por tema: dinero, precio y flujo; SAT y formalidad; crédito, protección y futuro. |
| **Presenta tu negocio** | Una publicación al mes para contar qué haces. Sin ofertas financieras. |
| **Alertas de fraude** | Avisa de llamadas «del SAT», proveedores falsos, capturas falsas o extorsiones. |
| **Logros** | Celebra avances: te pagaste un sueldo, calculaste tu precio, te inscribiste en el RFC. |
| **Sesión mensual en vivo** | Un tema al mes y preguntas. |
| **Referencias comerciales** | Servicios con acuerdo comercial, separados y señalados. Son opcionales. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar y apoyarnos entre personas que emprenden.
- **No es** asesoría fiscal, legal ni contable personalizada. Para tu caso concreto, te orientamos hacia el SAT, PRODECON, el IMSS o un profesional.
- **No es** un lugar para ofrecer préstamos, inversiones, tandas ni facturas.

### Cómo reconocer al equipo

El equipo **nunca** te pide tu RFC, contraseñas del SAT, e.firma, números de cuenta ni montos reales de tu negocio. Si alguien lo hace en nombre de la comunidad, es un fraude: repórtalo en **Alertas de fraude**.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Preséntate en el foro **Preséntate**.
3. Anota la fecha de la sesión mensual (capítulo 5).
4. Cuando tengas una duda, usa la plantilla del capítulo 3.


## Reglas y privacidad

Estas reglas protegen tu información y la de todas las personas.

### Tus datos

- **Nunca publiques** RFC, CURP, contraseñas del SAT, e.firma, números de cuenta o tarjeta, códigos, montos reales de ventas ni capturas de tu banco, del SAT o de tus facturas.
- Si quieres dar un ejemplo, usa **números inventados o redondeados**: «vendo unos 30 mil al mes».
- Los foros no permiten adjuntar archivos, para evitar que se compartan documentos por error.

### Respeto

- Sin burlas ni juicios: todos empezamos en algún lugar, formales o no.
- Sin discusiones personales ni publicaciones sobre clientes, proveedores o terceros con nombre y apellido.

### Lo que no se permite

1. Ofrecer préstamos, inversiones, tandas, «negocios» de referidos o productos financieros.
2. Vender o comprar facturas, o prestar tu RFC.
3. Recomendar gestores que «arreglan» el SAT, el IMSS o el Buró.
4. Publicar enlaces acortados o de sitios no oficiales para trámites.
5. Promocionar tu negocio fuera del foro **Presenta tu negocio**.
6. Hacerse pasar por el equipo, por una autoridad o por otra persona.

### Presenta tu negocio

Una publicación al mes por persona: qué haces, dónde y cómo contactarte por tus canales públicos. Sin precios engañosos, sin ofertas financieras y sin datos personales de nadie.

### Si algo te parece fraude

Publícalo en **Alertas de fraude** sin datos personales, o escribe en privado al equipo. Si ya te afectó: guarda evidencia, reporta a tu banco o proveedor de pagos, reclama por escrito y denuncia al 088 o a la fiscalía (M4 U03 y M7 U03).

### Qué hace el equipo

- Retira publicaciones con datos personales o fiscales y te avisa en privado.
- Retira publicaciones que venden productos financieros, facturas o invitan a invertir.
- Responde dudas generales y canaliza los casos personales.


## Cómo preguntar y presentar tu negocio

Una pregunta clara recibe una respuesta útil más rápido.

### Plantilla para dudas

**Módulo o tema:** (por ejemplo, M5 RESICO)
**Mi negocio, sin datos personales:** (por ejemplo, «vendo comida, unos 30 mil al mes, casi todo en efectivo»)
**Lo que ya revisé:** (por ejemplo, «leí la lección M5 U02»)
**Mi duda concreta:** (una pregunta, no cinco)

### Lo que la comunidad puede y no puede resolver

| Sí | No |
|---|---|
| Dudas sobre lo que explica el curso | Revisar tus declaraciones o facturas reales |
| Cómo calcular precio, flujo o punto de equilibrio | Decirte qué banco, terminal o plataforma contratar |
| A qué institución acudir | Hacer trámites del SAT o del IMSS por ti |
| Cómo reconocer un fraude | Entrar a tu portal del SAT o a tu banca |

### Plantilla para «Presenta tu negocio»

**Qué haces:** (una o dos líneas)
**Dónde:** (ciudad o «en línea»)
**Qué aprendiste del curso que ya aplicas:** (una línea)
**Cómo encontrarte:** (tus redes o página pública del negocio)

### Responder a otras personas

Puedes compartir tu experiencia: di que es tu experiencia, no una regla; no recomiendes marcas, contadores ni proveedores por nombre; si no estás seguro, remite a la lección o a la institución oficial. Recuerda que los impuestos dependen de cada caso.


## Tu calendario del año

Fechas que importan a quien emprende en México. En **Avisos** y en el canal te recordamos cada una a tiempo.

| Mes | Recordatorio | Lección |
|---|---|---|
| Cada mes, día 17 | Pago mensual de ISR e IVA del mes anterior | M5 U05 |
| Enero | Revisa los cambios fiscales del año y el nuevo salario mínimo | M5 U02, M8 U01 |
| Enero | Temporada baja para muchos negocios: usa tu reserva, no crédito caro | M3 U03 |
| Febrero | Nueva UMA: cuotas del IMSS y topes | M7 U01 |
| Marzo | Revisa tu punto de equilibrio con los costos del año | M2 U03 |
| Abril | Declaración anual de personas físicas, si te corresponde | M5 U05 |
| Mayo | Revisa tu AFORE y tu aportación voluntaria | M9 U01 |
| Junio | Revisa tus seguros del negocio | M7 U02 |
| Julio | Tablero de medio año: ventas, margen, ganancia | M8 U03 |
| Agosto | Prepara la temporada alta: compras en partes y reserva | M3 U01 |
| Septiembre | Revisa tu marca y tu carpeta del negocio | M7 U04, M9 U02 |
| Octubre y noviembre | Aparta para el aguinaldo de tu equipo y para enero | M3 U03 |
| Diciembre | Aguinaldo (a más tardar el 20) y plan de una página para el próximo año | M8 U01, M9 U03 |

Las fechas oficiales pueden cambiar. Confírmalas en el sitio del SAT, el IMSS y cada institución.


## Sesión mensual y retos

### Sesión mensual en vivo

Una sesión al mes por videollamada. La fecha y el enlace se publican en **Avisos** y en el canal.

- Duración: 60 minutos.
- Un tema del mes, un ejercicio con números inventados y preguntas.
- Nunca abrimos tu portal del SAT, tu banca ni tu plataforma frente al grupo.
- Si hay una persona invitada (contador, IMSS, PRODECON), es orientación general.

### Retos del mes

Cada mes proponemos un reto corto en **Avisos**. Cuando lo cumplas, compártelo en **Logros**, sin datos personales ni montos reales.

| Mes | Reto |
|---|---|
| 1 | Anota ventas y gastos 7 días seguidos (M1 U04) |
| 2 | Separa la cuenta o caja del negocio (M1 U02) |
| 3 | Fija tu sueldo y tu día de pago (M1 U03) |
| 4 | Calcula el costo real de tu producto principal (M2 U01) |
| 5 | Calcula tu punto de equilibrio y tu meta diaria (M2 U03) |
| 6 | Haz tu calendario de flujo de 4 semanas (M3 U01) |
| 7 | Escribe tus reglas de fiado (M3 U02) |
| 8 | Activa alertas de depósito y ajusta tu límite de transferencias (M4 U02) |
| 9 | Revisa los requisitos de tu RFC o tu régimen (M5 U01) |
| 10 | Calcula tu cuota de Modalidad 10 en el IMSS (M7 U01) |
| 11 | Busca tu nombre en MarcaNET (M7 U04) |
| 12 | Llena tu plan de una página (M9 U03) |

### Encuesta de la comunidad

Dos veces al año te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima.


## Cómo funcionan las referencias comerciales

Queremos que sepas exactamente qué es educación y qué es una oferta comercial.

### Dónde aparecen

- **Solo** en el foro **Referencias comerciales** y en el canal de WhatsApp.
- **Nunca** en las lecciones, las actividades, las autoevaluaciones, las insignias, la constancia ni la sesión mensual.

### Qué dicen siempre

> **Referencia comercial:** Desarrolla Talento puede recibir una comisión si contratas este servicio. Compara con al menos otra opción. Usarlo es voluntario y no afecta tu acceso, tus puntos ni tu constancia.

### Antes de contratar cualquier servicio

- Verifica la institución en CONDUSEF o la CNBV (M6 U02).
- Compara el costo total con tus números reales (M4 U01 y M6 U03).
- Pide la propuesta por escrito y compara con al menos otra opción.

### Qué nunca verás

- Recomendaciones de SOFIPO, SOCAP ni SOFOM.
- Créditos «sin Buró» ni apps de préstamo rápido.
- Venta de facturas ni esquemas para «pagar menos impuestos».
- Presión para decidir.

