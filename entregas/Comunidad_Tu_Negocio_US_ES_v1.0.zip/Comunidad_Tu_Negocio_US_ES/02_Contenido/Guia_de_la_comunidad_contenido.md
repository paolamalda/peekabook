# Comunidad Tu Negocio EE. UU.: contenido

## Bienvenida a la comunidad

**Comunidad Tu Negocio EE. UU.** es el espacio de quienes toman el programa *Tu Negocio, Tu Dinero, Tu Futuro* en Estados Unidos. Es un complemento del curso: aquí resuelves dudas, compartes avances, conoces otros negocios, te enteras de fechas de impuestos y te alertas de fraudes con otras personas que emprenden.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas de impuestos, recordatorios, sesión mensual y alertas. Solo publica el equipo. |
| **Preséntate** | Di quién eres, qué negocio tienes y qué quieres lograr. |
| **Foros de dudas** | Tres foros por tema: dinero, precio y flujo; impuestos y formalidad; crédito, protección y futuro. |
| **Presenta tu negocio** | Una publicación al mes para contar qué haces. Sin ofertas financieras. |
| **Alertas de fraude** | Avisa de llamadas «del IRS», cartas que imitan al gobierno, cheques de más o proveedores falsos. |
| **Logros** | Celebra avances: te pagaste un sueldo, calculaste tu precio, sacaste tu EIN. |
| **Sesión mensual en vivo** | Un tema al mes y preguntas. |
| **Referencias comerciales** | Servicios con acuerdo comercial, separados y señalados. Son opcionales. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar y apoyarnos entre personas que emprenden.
- **No es** asesoría fiscal, legal ni contable personalizada. Para tu caso concreto, te orientamos hacia el IRS, VITA, un SBDC o un profesional. No damos asesoría migratoria.
- **No es** un lugar para ofrecer préstamos, inversiones ni esquemas para «pagar menos impuestos».

### Cómo reconocer al equipo

El equipo **nunca** te pide tu SSN, ITIN, EIN, contraseñas, números de cuenta, montos reales de tu negocio ni tu situación migratoria. Si alguien lo hace en nombre de la comunidad, es un fraude: repórtalo en **Alertas de fraude**.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Preséntate en el foro **Preséntate**.
3. Anota la fecha de la sesión mensual (capítulo 5).
4. Cuando tengas una duda, usa la plantilla del capítulo 3.


## Reglas y privacidad

Estas reglas protegen tu información y la de todas las personas.

### Tus datos

- **Nunca publiques** SSN, ITIN, EIN, contraseñas, números de cuenta o tarjeta, códigos, montos reales de ventas, capturas de tu banco o del IRS, ni tu situación migratoria ni la de otras personas.
- Si quieres dar un ejemplo, usa **números inventados o redondeados**: «vendo unos 30 mil al mes».
- Los foros no permiten adjuntar archivos, para evitar que se compartan documentos por error.

### Respeto

- Sin burlas ni juicios: todos empezamos en algún lugar, formales o no.
- Sin discusiones personales ni publicaciones sobre clientes, proveedores o terceros con nombre y apellido.

### Lo que no se permite

1. Ofrecer préstamos, inversiones, «negocios» de referidos o productos financieros.
2. Ofrecer esquemas para «pagar menos impuestos» o prestar tu número fiscal.
3. Recomendar «notarios» o gestores que «arreglan» impuestos, papeles o crédito.
4. Publicar enlaces acortados o de sitios no oficiales para trámites.
5. Promocionar tu negocio fuera del foro **Presenta tu negocio**.
6. Hacerse pasar por el equipo, por una autoridad o por otra persona.

### Presenta tu negocio

Una publicación al mes por persona: qué haces, dónde y cómo contactarte por tus canales públicos. Sin precios engañosos, sin ofertas financieras y sin datos personales de nadie.

### Si algo te parece fraude

Publícalo en **Alertas de fraude** sin datos personales, o escribe en privado al equipo. Si ya te afectó: guarda evidencia, reporta a tu banco o proveedor de pagos, y reporta en ReportFraud.ftc.gov (M4 U03 y M7 U03).

### Qué hace el equipo

- Retira publicaciones con datos personales o fiscales y te avisa en privado.
- Retira publicaciones que venden productos financieros o invitan a invertir.
- Responde dudas generales y canaliza los casos personales.


## Cómo preguntar y presentar tu negocio

Una pregunta clara recibe una respuesta útil más rápido.

### Plantilla para dudas

**Módulo o tema:** (por ejemplo, M5 pagos estimados)
**Mi negocio, sin datos personales:** (por ejemplo, «vendo comida, unos 30 mil al mes, casi todo en efectivo»)
**Lo que ya revisé:** (por ejemplo, «leí la lección M5 U02»)
**Mi duda concreta:** (una pregunta, no cinco)

### Lo que la comunidad puede y no puede resolver

| Sí | No |
|---|---|
| Dudas sobre lo que explica el curso | Revisar tus declaraciones o facturas reales |
| Cómo calcular precio, flujo o punto de equilibrio | Decirte qué banco, terminal o plataforma contratar |
| A qué institución acudir | Hacer trámites del IRS o de tu estado por ti |
| Cómo reconocer un fraude | Entrar a tu cuenta del IRS o a tu banca |

### Plantilla para «Presenta tu negocio»

**Qué haces:** (una o dos líneas)
**Dónde:** (ciudad o «en línea»)
**Qué aprendiste del curso que ya aplicas:** (una línea)
**Cómo encontrarte:** (tus redes o página pública del negocio)

### Responder a otras personas

Puedes compartir tu experiencia: di que es tu experiencia, no una regla; no recomiendes marcas, preparadores ni proveedores por nombre; si no estás seguro, remite a la lección o a la institución oficial. Recuerda que los impuestos dependen de cada caso.


## Tu calendario del año

Fechas que importan a quien emprende en Estados Unidos. En **Avisos** y en el canal te recordamos cada una a tiempo.

| Mes | Recordatorio | Lección |
|---|---|---|
| Enero, 15 | Cuarto pago estimado del año anterior | M5 U04 |
| Enero | Revisa los nuevos límites de retiro, la tarifa por milla y el salario mínimo | M1 U04, M8 U01, M9 U01 |
| Enero y febrero | Llegan tus 1099; envía los 1099-NEC que te toquen | M5 U04 |
| Abril, 15 | Declaración anual y primer pago estimado | M5 U03, M5 U04 |
| Abril | En California, pago del impuesto mínimo de tu LLC, si tienes | M5 U01 |
| Mayo | Revisa tu estimado de retiro en ssa.gov | M9 U01 |
| Junio, 15 | Segundo pago estimado | M5 U04 |
| Julio | Tablero de medio año: ventas, margen, ganancia | M8 U03 |
| Agosto | Revisa tus seguros del negocio | M7 U02 |
| Septiembre, 15 | Tercer pago estimado | M5 U04 |
| Octubre | Aparta para la temporada baja y los gastos de fin de año | M3 U03 |
| Noviembre a enero | Inscripción abierta de seguro médico | M7 U01 |
| Diciembre | Aporta a tu cuenta de retiro y llena tu plan de una página | M9 U01, M9 U03 |

Tu fecha de declaración de sales tax depende de la frecuencia que te asigne el CDTFA o tu estado. Las fechas oficiales pueden cambiar; confírmalas en el IRS y en tu estado.


## Sesión mensual y retos

### Sesión mensual en vivo

Una sesión al mes por videollamada. La fecha y el enlace se publican en **Avisos** y en el canal.

- Duración: 60 minutos.
- Un tema del mes, un ejercicio con números inventados y preguntas.
- Nunca abrimos tu cuenta del IRS, tu banca ni tu plataforma frente al grupo.
- Si hay una persona invitada (preparador de impuestos, asesor de un SBDC), es orientación general.

### Retos del mes

Cada mes proponemos un reto corto en **Avisos**. Cuando lo cumplas, compártelo en **Logros**, sin datos personales ni montos reales.

| Mes | Reto |
|---|---|
| 1 | Anota ventas, gastos y millas 7 días seguidos (M1 U04) |
| 2 | Abre tu cuenta del negocio y tu cuenta para impuestos (M1 U02 y U03) |
| 3 | Fija tu sueldo y tu porcentaje para impuestos (M1 U03) |
| 4 | Calcula el costo real de tu producto principal (M2 U01) |
| 5 | Calcula tu punto de equilibrio y tu meta diaria (M2 U03) |
| 6 | Haz tu calendario de flujo con tus pagos estimados (M3 U01) |
| 7 | Activa alertas y autenticación en dos pasos (M4 U02) |
| 8 | Revisa en CalGold o en tu ciudad qué permisos pide tu giro (M5 U02) |
| 9 | Solicita tu IP PIN del IRS (M5 U04) |
| 10 | Cotiza un seguro para tu negocio (M7 U02) |
| 11 | Revisa tus opciones de seguro médico antes de la inscripción abierta (M7 U01) |
| 12 | Revisa tu estimado en ssa.gov y llena tu plan de una página (M9) |

### Encuesta de la comunidad

Dos veces al año te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima.


## Cómo funcionan las referencias comerciales

Queremos que sepas exactamente qué es educación y qué es una oferta comercial.

### Dónde aparecen

- **Solo** en el foro **Referencias comerciales** y en el canal de WhatsApp.
- **Nunca** en las lecciones, las actividades, las autoevaluaciones, las insignias, la constancia ni la sesión mensual.

### Qué dicen siempre

> **Referencia comercial:** Desarrolla Talento puede recibir una comisión si contratas este servicio. Compara con al menos otra opción. Usarlo es voluntario y no afecta tu acceso, tus puntos ni tu constancia.

### Antes de contratar cualquier servicio

- Verifica la licencia de la institución con el regulador de tu estado (M6 U02).
- Compara el costo total con tus números reales (M4 U01 y M6 U03).
- Pide la propuesta por escrito y compara con al menos otra opción.

### Qué nunca verás

- Adelantos sobre ventas ni préstamos de día de pago.
- Préstamos «sin revisar crédito» con cuota por adelantado.
- Esquemas para «pagar menos impuestos».
- Presión para decidir.

