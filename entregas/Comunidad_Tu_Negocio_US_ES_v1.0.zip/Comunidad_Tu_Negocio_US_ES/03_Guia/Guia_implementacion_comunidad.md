# Comunidad Tu Negocio EE. UU.: guía de implementación

# Parte 1. Crear la comunidad en Moodle, paso a paso


Vas a crear el curso **Comunidad Tu Negocio EE. UU.** en academia.desarrollatalento.com. Es un espacio aparte del curso *Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.* (TNDF-US-ES). No toques otros cursos.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TNDF-US-ES-COM`. Si existe, detente y pregunta.
2. Pregunta a la persona:
   - la fecha y el enlace de la primera sesión mensual en vivo;
   - el enlace del canal de WhatsApp;
   - si quiere inscribir a las personas con una cohorte (la crea la persona administradora del sitio) o de forma manual.
   Si no tiene esos datos, deja el texto "[por definir]" y repórtalo.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Comunidad Tu Negocio EE. UU. |
| Nombre corto | TNDF-US-ES-COM |
| Visibilidad | **Ocultar** |
| Formato | Temas, 4 secciones |
| Seguimiento de finalización | No |
| Mostrar calificaciones | No |
| Resumen | "El espacio de la comunidad de Tu Negocio, Tu Dinero, Tu Futuro (EE. UU.): dudas, avisos, fechas de impuestos, alertas de fraude, presenta tu negocio, logros y sesión mensual en vivo." |

### 2. Secciones y actividades

#### General · Bienvenida

1. Ya existe el foro **Avisos** (foro de noticias). Configúralo:
   - Nombre: `Avisos`.
   - Descripción: "Fechas de impuestos, recordatorios, alertas de fraude, retos del mes y sesión mensual. Solo publica el equipo. Desarrolla Talento nunca te pide tu SSN, ITIN, contraseñas, números de cuenta ni tu situación migratoria."
   - Suscripción: forzosa.
2. **Libro** `Guía de la comunidad`: formato de capítulo "Nada". Menú del libro > Importar capítulo > `1_libro/Comunidad_libro_Moodle.zip`, "Cada archivo HTML representa un capítulo" (6 capítulos).
3. **URL** `Canal de avisos en WhatsApp`: enlace que te dé la persona; abrir en ventana nueva. Descripción: "Solo publica el equipo; nadie ve tu número. Las dudas se resuelven en los foros."

#### Sección 1 · Participa

Crea estos foros. En **todos**:

- Número máximo de archivos adjuntos: **0**.
- Tamaño máximo de archivo adjunto: no se permite subir archivos.
- Calificación: ninguna. Evaluaciones (ratings): desactivadas.
- Modo de grupo: sin grupos.
- Suscripción: opcional.
- Copia la advertencia al inicio de cada descripción: "No publiques SSN, ITIN, EIN, contraseñas, números de cuenta, montos reales, capturas de tu banco o del IRS, ni tu situación migratoria."

| Nombre | Tipo de foro | Descripción (después de la advertencia) |
|---|---|---|
| Preséntate | Foro para uso general | "Cuéntanos quién eres, qué negocio tienes y qué quieres lograr este año." |
| Dudas: dinero, precio, flujo y cobros | Foro estándar que aparece en un formato similar a un blog | "Módulos 1 a 4. Usa la plantilla del capítulo 3 de la guía." |
| Dudas: impuestos y formalidad | Foro estándar que aparece en un formato similar a un blog | "Módulo 5. Orientación general; tu caso lo revisas con un preparador de impuestos o CPA. No se tratan temas migratorios. Usa la plantilla del capítulo 3." |
| Dudas: crédito, protección, crecer y futuro | Foro estándar que aparece en un formato similar a un blog | "Módulos 6 a 9. Usa la plantilla del capítulo 3 de la guía." |
| Presenta tu negocio | Foro para uso general | "Una publicación al mes por persona, con la plantilla del capítulo 3. Sin préstamos, inversiones ni esquemas fiscales." |
| Alertas de fraude | Foro para uso general | "Avisa de llamadas «del IRS», cartas que imitan al gobierno, cheques de más o proveedores falsos, sin datos personales. Si ya te afectó, sigue M4 U03 y M7 U03." |
| Logros | Foro para uso general | "Comparte tus avances y los retos del mes que cumpliste." |

Si en tu versión de Moodle el tipo "similar a un blog" no aparece con ese nombre, usa "Foro para uso general" y repórtalo.

#### Sección 2 · Sesión mensual en vivo

1. **Página** `Sesión mensual en vivo`: copia el contenido del capítulo 5 (primera parte) y agrega la fecha y el enlace que te dio la persona.
2. **Consulta** (Choice) `¿Qué tema quieres en la próxima sesión?`:
   - Opciones: "Precio y costos", "Flujo y facturas", "Cobros y fraudes al vender", "LLC, EIN y permisos", "Impuestos y pagos estimados", "Sales tax", "Crédito", "Salud y seguros", "Vender en línea", "Retiro".
   - Permitir actualizar la respuesta: sí. Mostrar resultados: después de responder. Privacidad: publicar resultados anónimos.
3. **Encuesta** (Feedback) `Encuesta de la comunidad`, anónima, con estas preguntas:
   - Opción múltiple: "¿Qué tan útil te resulta la comunidad?" (Muy útil / Útil / Poco útil / Nada útil).
   - Opción múltiple: "¿Qué espacio usas más?" (Avisos / Foros de dudas / Presenta tu negocio / Alertas / Logros / Sesión mensual / Canal de WhatsApp).
   - Texto largo: "¿Qué tema te gustaría que agregáramos al curso?"
   - Texto largo: "¿Qué mejorarías de la comunidad?"

#### Sección 3 · Referencias comerciales

1. **Etiqueta** con este texto: "Referencias comerciales. Aquí publicamos servicios con acuerdo comercial. Desarrolla Talento puede recibir una comisión. Usarlos es voluntario y no afecta tu acceso, tus puntos ni tu constancia. Compara siempre con al menos otra opción (capítulo 6 de la guía)."
2. **Foro** `Referencias comerciales`, tipo "Foro de noticias" o, si no se puede agregar otro, "Foro para uso general" con esta restricción: en *Permisos* del foro, quita a Estudiante la capacidad `mod/forum:startdiscussion` y `mod/forum:replypost`. Si no puedes cambiar permisos, detente y pregunta.

### 3. Enlazar desde el curso principal

En el curso **TNDF-US-ES**, sección General, agrega una **URL** `Comunidad Tu Negocio EE. UU.` al curso nuevo, con la descripción: "Dudas, fechas de impuestos, alertas de fraude, presenta tu negocio y sesión mensual."

### 4. Inscripción

- Si la persona creó la cohorte "Tu Negocio US ES": en ambos cursos, *Participantes > Métodos de inscripción > Agregar método > Sincronización de cohortes*, cohorte "Tu Negocio US ES", rol Estudiante.
- Si no: deja activada la inscripción manual y repórtalo.
- Agrega al equipo de moderación con rol **Profesor sin permiso de edición** (o Profesor, si lo pide la persona).

### 5. Revisión (con rol de estudiante)

- No se pueden adjuntar archivos en los foros.
- El estudiante puede publicar en Preséntate, Dudas, Presenta tu negocio, Alertas y Logros.
- El estudiante no puede publicar en Avisos ni en Referencias comerciales.
- El libro muestra 6 capítulos.
- La consulta y la encuesta funcionan.

### 6. Reporte

Enlace del curso; lista de foros con su configuración; estado de la consulta y la encuesta; método de inscripción; lo que quedó "[por definir]"; capturas de la página principal del curso y de un foro con la advertencia.

El curso queda **oculto** hasta que la persona decida mostrarlo.


# Parte 2. Calendario editorial


Cuatro publicaciones al mes: fechas, reto, alerta de fraude y aviso de la sesión. Las referencias comerciales van aparte, como máximo dos al mes. Además, se recuerda cada pago estimado dos semanas antes.

| Mes | Semana 1 · Fechas | Semana 2 · Reto | Semana 3 · Alerta de fraude | Semana 4 · Sesión |
|---|---|---|---|---|
| Enero | Pago estimado del 15 y nuevos límites | Anota 7 días seguidos | Llamadas «del IRS» | Sesión: separa tu dinero |
| Febrero | Llegan los 1099 | Cuenta del negocio y de impuestos | Preparadores que prometen reembolsos enormes | Sesión: impuestos por cuenta propia |
| Marzo | Prepara tu declaración | Tu sueldo y tu % de impuestos | Sitios que cobran por el EIN | Sesión: costos y precio |
| Abril | Declaración y pago del 15 | Costo real de tu producto | Cartas que imitan al gobierno | Sesión: punto de equilibrio |
| Mayo | Revisa ssa.gov | Punto de equilibrio | Cheques de más | Sesión: flujo y facturas |
| Junio | Pago estimado del 15 | Calendario de flujo | Correos de «pago pendiente» | Sesión: cobros y apps |
| Julio | Tablero de medio año | Alertas y dos pasos | Proveedores falsos | Sesión: LLC y permisos |
| Agosto | Seguros del negocio | Permisos de tu giro | «Notarios» | Sesión: sales tax |
| Septiembre | Pago estimado del 15 | IP PIN | Adelantos sobre ventas | Sesión: crédito y APR |
| Octubre | Temporada baja | Cotiza un seguro | Avisos falsos de marca | Sesión: seguros y salud |
| Noviembre | Inscripción abierta de salud | Opciones de seguro médico | Fraudes de fin de año | Sesión: vender en línea |
| Diciembre | Aporta a tu retiro | Plan de una página | Tarjetas robadas en compras grandes | Sesión: tu plan |

### Formato para el canal de WhatsApp

- Máximo 5 líneas, sin abreviaturas.
- Un solo enlace, siempre al curso, al foro o a un sitio oficial.
- Todas las publicaciones terminan igual: «Desarrolla Talento nunca te pide tu SSN, ITIN, contraseñas ni tu situación migratoria».

**Plantilla de alerta:**
"⚠️ Alerta: [fraude]. Cómo reconocerlo: [señal]. Qué hacer: [acción]. Más en [lección]. Desarrolla Talento nunca te pide tu SSN, ITIN, contraseñas ni tu situación migratoria."

**Plantilla de pago estimado:**
"📅 El [fecha] vence tu pago estimado de impuestos. Usa lo que apartaste y paga en irs.gov; nunca desde un enlace de un mensaje. Más en M5 U04."

**Plantilla de reto:**
"🎯 Reto de [mes]: [reto]. Te toma [tiempo]. Cuando lo cumplas, compártelo en Logros, sin datos personales."

