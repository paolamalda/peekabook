# Módulo 1. Tu dinero real: ingresos variables

## M1 U01. ¿Todo lo que cobro por una producción es mi ganancia real?

**Lo que lograrás:** Separar el monto del contrato de lo que realmente te queda después de comisión, impuestos y gastos del proyecto.

**Para empezar:** Gael acaba de firmar 100,000 pesos por grabar una miniserie. Ya piensa en cambiar de auto. Cuando termina de pagar a su mánager, apartar impuestos y cubrir vestuario y traslados, le quedan unos 63,750. En esta lección aprenderás a calcular tu ganancia real antes de gastarla.

### Lo esencial (5 minutos)

#### El contrato no es lo que te queda

El monto del contrato es tu **ingreso bruto**.

Lo que puedes usar para tu vida es tu **ganancia real**. Si decides con el monto bruto, te comprometes con dinero que no tienes.



#### A dónde se va un pago

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Contrato | 100,000 por la miniserie. | Lo que promete la productora. |
| Comisión del mánager | 15%: 15,000. | Revisa sobre qué monto se calcula. |
| Impuestos | ISR retenido en RESICO: 1.25%, 1,250. | El IVA que cobras tampoco es tuyo. |
| Gastos del proyecto | 12,000 de vestuario y 8,000 de traslados. | En RESICO no se deducen. |

#### Tu ganancia real

Así se ve el pago de Gael.
- Contrato: **100,000**
- Comisión e ISR retenido: **16,250**
- Vestuario y traslados: **20,000**
- Tu ganancia real: **63,750**
Es el dinero con el que sí puedes planear tu vida.


#### El IVA no es tuyo

Si facturas 100,000 más IVA, recibes 116,000 menos retenciones. Ese IVA se entrega al SAT.

Apártalo en cuanto llegue el pago. Tu contador te dice cuánto te toca enterar cada mes.



#### Un caso en un minuto

Valeria cobra 30,000 por una publicidad y le piden cuatro cambios de ropa que cuestan 18,000.

Antes de aceptar, pregunta si la marca le reembolsa la ropa. Le dicen que no, y negocia que la marca preste el vestuario.

> **Idea clave:** el monto del contrato paga el proyecto; tu ganancia real paga tu vida.



#### Hazlo con tu último pago

1. **Anota el monto del contrato**, sin IVA.
2. **Resta la comisión** de tu mánager o agencia.
3. **Resta el ISR** que te retuvieron o que te toca pagar.
4. **Resta los gastos del proyecto** que pagaste tú: vestuario, traslados, hospedaje.
5. **Anota el resultado:** esa es tu ganancia real.

> **Antes de actuar, verifica:** con tu contador cuánto ISR e IVA te corresponde según tu régimen. Las tasas de este ejemplo son ilustrativas.

> **Dato vigente:** retención de ISR de 1.25% cuando una persona en RESICO factura a una empresa (artículo 113-J de la LISR). Consultado el 29 de septiembre de 2026 a través del SAT y la LISR.



#### Comprueba lo que entendiste

1. ¿El monto del contrato es lo que puedes gastar?
*Respuesta:* No. Primero restas comisión, impuestos y gastos del proyecto.

2. En RESICO, ¿el vestuario te baja los impuestos?
*Respuesta:* No. RESICO no permite deducir gastos; el vestuario solo reduce tu ganancia real.


#### Para recordar

- Calcula tu ganancia real antes de comprometerte.
- El IVA que cobras no es tuyo.
- En RESICO los gastos no se deducen.



### Profundiza (5 minutos más)

#### Eres un negocio de una persona

Cada pago es la venta de un servicio, no un sueldo. Una parte paga los costos de tu negocio y otra los impuestos.

Si tratas cada pago como ganancia personal, no tendrás con qué pagar tu siguiente casting, tus fotos o tus clases.



#### Gastos del proyecto y gastos personales

| Gasto del proyecto | Gasto personal |
|---|---|
| Comisión del mánager | Renta de tu casa |
| Vestuario pedido por la producción | Ropa de diario |
| Clases de actuación, canto o acento | Entretenimiento |
| Headshots y demo reel | Salidas con amigos |
| Traslados a locación | Viajes de descanso |



#### ¿Y si mis gastos son muy altos?

En RESICO pagas una tasa baja sobre lo que cobras, pero no deduces gastos. En Actividad Empresarial pagas sobre tu ganancia, con tasas más altas, pero sí deduces.

Si tus gastos del proyecto son una parte grande de lo que cobras, pide a tu contador que compare los dos regímenes con tus números.



#### Casos


**Caso 1. El llamado fuera de la ciudad**

Gael acepta un llamado de 3 días en Guadalajara por 15,000. No le pagan viáticos: gasta 4,500 en vuelos, 3,000 en hotel y 1,500 en comidas. Su agencia cobra 15%.
- *¿Cuánto le queda?* 3,750 antes de impuestos: 1,250 por día de trabajo.


**Caso 2. La publicidad de Valeria**

Valeria cobra 30,000 y debe comprar ropa por 18,000 que no le reembolsan.
- *¿Qué hace antes de aceptar?* Negocia que la marca preste o pague el vestuario, o sube su tarifa. Con esas condiciones le quedarían 12,000 antes de comisión e impuestos.


**Caso 3. La comisión de Gael**

El mánager de Gael calcula su 15% sobre el pago con IVA incluido.
- *¿Es correcto?* Depende de lo que diga su contrato. Normalmente la comisión se calcula sobre el honorario sin IVA; Gael lo revisa y lo pide por escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar el pago antes de restar la comisión | Te quedas corto cuando el mánager cobra | Separa la comisión en cuanto llegue el pago |
| Gastar el IVA | Debes dinero al SAT | Apártalo el mismo día |
| Creer que en RESICO deduces tus gastos | Calculas mal tus impuestos | Pregunta a tu contador qué aplica en tu régimen |
| Aceptar gastos sin reembolso | Trabajas casi gratis | Negocia antes de firmar |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te ofrecen 40,000 por un personaje. ¿Con qué número decides si te alcanza para un compromiso nuevo? a) Lo que queda después de comisión, impuestos y gastos · b) 40,000 · c) 40,000 más el IVA que te pagan, porque ya es tuyo
2. Estás en RESICO y gastas 10,000 en vestuario. ¿Qué pasa con tus impuestos? a) No cambian · b) Bajan 10,000 · c) Bajan a la mitad
3. Cobras 20,000 más IVA. ¿Qué haces con el IVA? a) Lo usas como ganancia · b) Lo usas para pagar tu tarjeta · c) Lo apartas para el SAT
**Respuestas:** 1-a: tu ganancia real es la que paga tu vida. 2-a: RESICO no permite deducir gastos. 3-c: el IVA no es tuyo.



#### Ponlo en práctica

Gael recibe 40,000 por un personaje. Paga 15% a su mánager, le retienen 1.25% de ISR y gasta 6,000 en vestuario. ¿Cuál es su ganancia real?
**Respuesta:** Comisión 6,000; ISR 500; vestuario 6,000. Total 12,500. Ganancia real: 27,500.



#### A tu plan

Calcula la ganancia real de tus últimos tres proyectos. Anota qué porcentaje del contrato se fue en comisión, impuestos y gastos.



### Para saber más

- **RESICO para personas físicas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Régimen Simplificado de Confianza" y la tabla de tasas.
- **Facturación CFDI 4.0** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** cómo emitir tu factura y qué retenciones aplican cuando facturas a una empresa.

### Palabras clave

- *Ingreso bruto:* lo que dice el contrato, antes de descuentos.
- *Ganancia real:* lo que te queda después de comisión, impuestos y gastos.
- *RESICO:* régimen del SAT con tasas de 1% a 2.5%, sin deducciones.
- *IVA:* impuesto que cobras en tu factura y entregas al SAT.

### Fuentes

LISR, artículos 113-E y 113-J (RESICO), consultados el 29 de septiembre de 2026 · Ley del IVA · SAT, CFDI 4.0.

---

## M1 U02. ¿Cómo me pago un sueldo si no tengo sueldo fijo?

**Lo que lograrás:** Separar el dinero que entra de lo que gastas cada mes con una cuenta concentradora y un sueldo fijo personal.

**Para empezar:** Valeria cobra 80,000 por una campaña en marzo y nada en abril ni en mayo. En marzo sale a cenar, compra ropa y paga meses sin intereses. En mayo ya no le alcanza para la renta. En esta lección aprenderás a pagarte un sueldo, aunque tus ingresos lleguen a saltos.

### Lo esencial (5 minutos)

#### Tu ingreso sube y baja; tu renta no

En el medio, el dinero llega por proyecto: un mes mucho, otro mes nada. Tus gastos, en cambio, llegan cada mes.

Si gastas según lo que entró ese mes, en los meses buenos gastas de más y en los malos te endeudas.



#### Dos cuentas que te ordenan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta concentradora | Aquí cae todo lo que cobras: contratos, eventos, regalías. | No pagas nada desde aquí. |
| Cuenta de gastos | Cada quincena pasas la misma cantidad: tu sueldo. | De aquí pagas tu vida. |

#### ¿Cuánto es tu sueldo?

Valeria suma lo que gana en un año normal, ya sin comisión, impuestos ni gastos de trabajo.
- Ganancia real del año: **312,000**
- Lo que aparta para su fondo de sequía y su retiro: **48,000**
- Lo que puede gastar en el año: **264,000**
264,000 ÷ 12 = 22,000 al mes: 11,000 cada quincena.


#### Págate siempre el mismo día

Elige dos fechas, por ejemplo el 1 y el 16. Ese día pasa tu sueldo de la concentradora a tu cuenta de gastos.

Si un mes cobraste mucho, tu sueldo no sube. Lo que sobra se queda para los meses sin llamados.



#### Un caso en un minuto

Valeria abrió una segunda cuenta y programó una transferencia de 11,000 cada quincena. Cuando llegó el pago de la campaña, no cambió nada: siguió recibiendo su sueldo.

En mayo, sin trabajo, su renta estaba cubierta.

> **Idea clave:** no vivas de lo que cobraste este mes. Vive de tu sueldo.



#### Arma tu sistema esta semana

1. **Suma tus ingresos** de los últimos 12 meses, después de comisión, impuestos y gastos.
2. **Aparta** una parte para tu fondo de sequía y tu retiro.
3. **Divide** lo que queda entre 12: ese es tu sueldo mensual.
4. **Programa** la transferencia quincenal a tu cuenta de gastos.



#### Comprueba lo que entendiste

1. ¿Desde qué cuenta pagas tus gastos del mes?
*Respuesta:* Desde tu cuenta de gastos, donde cae tu sueldo fijo.

2. Si un mes cobras el doble, ¿subes tu sueldo?
*Respuesta:* No. Lo extra se queda en la concentradora para los meses bajos.


#### Para recordar

- Todo lo que cobras entra a una sola cuenta.
- Tú te pagas un sueldo fijo cada quincena.
- Lo extra de los meses buenos paga los meses malos.



### Profundiza (5 minutos más)

#### Si es tu primer año o tus ingresos cambiaron

Si no tienes 12 meses de historia, usa tus gastos básicos como sueldo: renta, comida, transporte, salud y servicios.

Revisa tu sueldo cada seis meses. Si tu concentradora crece mucho, puedes subirlo un poco. Si baja rápido, bájalo.



#### El año de Valeria con sueldo fijo

| Mes | Cobró | Se pagó | Queda en la concentradora |
|---|---|---|---|
| Enero | 30,000 | 22,000 | 8,000 |
| Febrero | 0 | 22,000 | −14,000 del saldo anterior |
| Marzo | 80,000 | 22,000 | +58,000 |
| Abril | 0 | 22,000 | −22,000 |
| Mayo | 0 | 22,000 | −22,000 |

Para empezar, necesita un saldo inicial en la concentradora. Por eso el fondo de sequía (M1 U03) va de la mano con este método.



#### Qué cuentas usar

Las dos cuentas pueden estar en el mismo banco o en bancos distintos. Lo importante es que sean cuentas de depósito sin comisiones altas y con protección del IPAB.

Si te pagan por nómina (asimilados), tienes derecho a elegir en qué banco recibirla con la portabilidad de nómina (M5 U02).

> **Dato adicional:** la cuenta concentradora puede ser una cuenta de inversión a la vista que genere rendimiento, siempre que puedas sacar tu dinero el mismo día o al siguiente (M1 U04).



#### Si compartes gastos con tu pareja

Cada quien puede tener su concentradora y aportar una cantidad fija a una cuenta común para la casa. Así, un mes sin trabajo de uno no rompe el presupuesto de los dos.



#### Casos


**Caso 1. La campaña de Valeria**

Valeria cobra 80,000 en marzo. Su sueldo fijo es de 22,000 al mes.
- *¿Qué hace con los 58,000 restantes?* Los deja en su concentradora para cubrir sus sueldos de los meses sin trabajo.


**Caso 2. El primer año de Gael**

Gael empieza a trabajar por su cuenta y no tiene historia de ingresos. Sus gastos básicos son 18,000 al mes.
- *¿Cuál es su sueldo inicial?* 18,000 al mes, lo que cuestan sus gastos básicos. Lo revisa en seis meses.


**Caso 3. La concentradora de Renata**

Renata paga sus tarjetas y sus salidas directo desde la cuenta donde le depositan los eventos.
- *¿Qué le recomiendas?* Separar: una cuenta solo para cobrar y otra para gastar, con un sueldo fijo cada quincena.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar según lo que entró ese mes | Te endeudas en los meses sin trabajo | Págate un sueldo fijo |
| Subir el sueldo cada vez que cobras bien | Nunca juntas reserva | Revisa el sueldo solo cada seis meses |
| Pagar todo desde la concentradora | Pierdes el control | Paga solo desde la cuenta de gastos |
| Calcular el sueldo con el ingreso bruto | Te sobreestimas | Usa tu ganancia real |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu ganancia real del año es 240,000 y apartas 36,000 para reserva y retiro. ¿Cuál es tu sueldo mensual? a) 17,000 · b) 20,000 · c) 23,000
2. Este mes cobraste el triple de lo normal. ¿Qué haces con tu sueldo? a) Lo mantienes igual · b) Lo triplicas · c) Lo subes a la mitad
3. ¿Desde qué cuenta pagas tu renta? a) Desde la concentradora · b) Desde la tarjeta de crédito · c) Desde tu cuenta de gastos
**Respuestas:** 1-a: 240,000 − 36,000 = 204,000; entre 12 son 17,000. 2-a: lo extra se queda para los meses bajos. 3-c: tu vida se paga con tu sueldo.



#### Ponlo en práctica

Calcula tu sueldo fijo: suma tu ganancia real de los últimos 12 meses, resta lo que apartarás para reserva y retiro, y divide entre 12.
**Respuesta:** Por ejemplo: ganancia real 300,000, aparto 45,000, quedan 255,000. Mi sueldo es 21,250 al mes: 10,625 cada quincena.



#### A tu plan

Abre o elige tu cuenta concentradora y programa tu primera transferencia de sueldo.



### Para saber más

- **Calculadora de presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores y calculadoras" y la herramienta de presupuesto personal.
- **Portabilidad de nómina** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "Portabilidad de nómina" para saber cómo elegir el banco donde recibes tu pago.

### Palabras clave

- *Cuenta concentradora:* cuenta donde cae todo lo que cobras.
- *Sueldo fijo personal:* la cantidad que te pagas cada quincena.
- *Ingreso variable:* ingreso que cambia de mes a mes.

### Fuentes

CONDUSEF, educación financiera · Banco de México, portabilidad de nómina, consultado el 29 de septiembre de 2026.

---

## M1 U03. ¿Cuánto necesito en mi fondo de sequía?

**Lo que lograrás:** Calcular tu fondo de sequía con tus gastos básicos y los meses promedio que pasan entre tus proyectos.

**Para empezar:** Gael lleva cuatro meses sin llamados. La primera semana usó la tarjeta para la renta; la segunda, para el súper. Hoy debe 60,000. Si hubiera tenido un fondo para la sequía, no tendría esa deuda. En esta lección calcularás cuánto necesitas tú.

### Lo esencial (5 minutos)

#### La sequía no es una emergencia: es parte del oficio

En el medio, pasar meses sin trabajo es normal. No es mala suerte: es el ciclo de las producciones, las temporadas y las campañas.

Si ya sabes que va a pasar, puedes prepararte. Para eso sirve el **fondo de sequía**.



#### Tu meta

Gael gasta 18,000 al mes en lo básico y suele pasar 4 meses entre producciones.
- Gastos básicos del mes: **18,000**
- Meses promedio sin proyecto: **4**
- Meta de su fondo de sequía: **72,000**
Se multiplica: 18,000 × 4 = 72,000.


#### Qué cuenta como gasto básico

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Vivienda | Renta o hipoteca, luz, agua, gas, internet. | Sí entra. |
| Comida | El súper y lo indispensable. | Sí entra. |
| Salud | Seguro, medicinas, consultas. | Sí entra. |
| Salidas y ropa nueva | Lo que puedes pausar en la sequía. | No entra. |

#### Empieza con un mes

72,000 puede sonar imposible. No tienes que juntarlo de un jalón.

Tu primera meta es un mes de gastos básicos. Luego dos. Cada pago grande que cobres, aparta una parte hasta llegar a tu meta.



#### Un caso en un minuto

Toño gasta 15,000 al mes en lo básico y sus meses sin sesiones suelen ser tres: su meta es 45,000.

Decide apartar 20% de cada pago. En ocho meses juntó 30,000. Cuando llegó enero, sin grabaciones, no usó la tarjeta.

> **Idea clave:** el fondo de sequía convierte los meses sin trabajo en meses tranquilos.



#### Comprueba lo que entendiste

1. Tus gastos básicos son 20,000 y pasas 3 meses sin proyecto. ¿Cuál es tu meta?
*Respuesta:* 60,000.

2. ¿Tu fondo de sequía es para comprar equipo cuando hay una oferta?
*Respuesta:* No. Es para tus gastos básicos en los meses sin trabajo.


#### Para recordar

- Multiplica tus gastos básicos por los meses sin proyecto.
- Empieza con un mes.
- Aparta una parte de cada pago grande.



### Profundiza (5 minutos más)

#### ¿Cómo sé cuántos meses pasan entre proyectos?

Revisa tus depósitos de los últimos dos o tres años. Marca los meses en que no entró dinero de trabajo. Saca el promedio de esos periodos.

Si no tienes historia, usa de 3 a 6 meses. Cuanto más irregular sea tu trabajo, más meses conviene tener.



#### Tu meta según tu perfil

| Perfil | Meses sugeridos |
|---|---|
| Trabajo constante con pocas pausas | 3 |
| Proyectos por temporada | 4 a 5 |
| Trabajo muy irregular o un solo cliente grande | 6 |



#### Fondo de sequía y fondo de emergencias

El fondo de sequía paga tu vida cuando no hay trabajo. Una emergencia (un accidente, una reparación urgente) es otra cosa.

Al principio pueden estar juntos. Cuando llegues a tu meta, empieza a juntar un colchón extra para emergencias, sobre todo si no tienes seguro médico (M10 U01).



#### No lo toques para otra cosa

Una oferta de equipo, un viaje o un cambio de celular no son sequía. Si usas el fondo para eso, te quedarás sin él cuando llegue la temporada baja.

Si lo usas en una sequía, está bien: para eso existe. Vuelve a llenarlo con tus siguientes pagos.



#### Casos


**Caso 1. La meta de Gael**

Gael gasta 18,000 al mes en lo básico y 6,000 en salidas. Pasa 4 meses sin producciones.
- *¿Cuál es su meta?* 72,000: solo cuenta los gastos básicos, no las salidas.


**Caso 2. La oferta de Valeria**

Valeria tiene 50,000 en su fondo y ve una oferta de micrófono de 18,000.
- *¿Lo paga con el fondo?* No. El fondo es para la sequía. Si necesita el micrófono, junta aparte o lo evalúa como inversión de trabajo.


**Caso 3. El mes sin sesiones de Toño**

Toño no tiene grabaciones en enero y tiene 30,000 en su fondo.
- *¿Usa la tarjeta o el fondo?* El fondo: para eso lo juntó. Después lo vuelve a llenar con sus siguientes pagos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar salidas y ropa como gastos básicos | La meta se vuelve imposible | Cuenta solo lo indispensable |
| Esperar a tener todo para empezar | Nunca empiezas | Empieza con un mes |
| Usar el fondo para ofertas | No hay reserva en la sequía | Separa tus metas |
| Guardar el fondo en la cartera o bajo el colchón | Se gasta o se pierde | Guárdalo en un lugar seguro (M1 U04) |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastos básicos de 16,000 y 5 meses sin proyecto. ¿Meta del fondo? a) 80,000 · b) 21,000 · c) 16,000
2. ¿Qué gasto NO entra en el cálculo? a) Luz, agua, gas e internet de tu casa · b) Medicinas · c) Salidas con amigos
3. Usaste tu fondo en un mes sin trabajo. ¿Qué sigue? a) Dejarlo en cero · b) Pedir un préstamo para rellenarlo de inmediato y no quedarte sin nada · c) Volver a llenarlo con tus siguientes pagos
**Respuestas:** 1-a: 16,000 × 5. 2-c: se pueden pausar en la sequía. 3-c: se rellena poco a poco.



#### Ponlo en práctica

Calcula tu meta: suma tus gastos básicos del mes y multiplícalos por los meses que sueles pasar sin proyecto.
**Respuesta:** Por ejemplo: renta 8,000, comida 5,000, servicios 1,500, salud 1,500, transporte 2,000 = 18,000. Paso 4 meses sin proyecto: meta 72,000. Primera meta: 18,000.



#### A tu plan

Escribe tu meta del fondo de sequía y qué porcentaje de cada pago apartarás.



### Para saber más

- **Calculadora de ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" y la calculadora de ahorro para ver en cuánto tiempo llegas a tu meta.
- **Pequeño Cerdo Capitalista** (Sofía Macías · libro en español): https://www.pequenocerdocapitalista.com — **Qué buscar:** los artículos sobre fondo de emergencia.

### Palabras clave

- *Fondo de sequía:* dinero para tus gastos básicos en los meses sin proyectos.
- *Gastos básicos:* lo indispensable para vivir cada mes.
- *Temporada baja:* meses en que hay menos trabajo en tu área.

### Fuentes

CONDUSEF, educación financiera · Macías, S., Pequeño Cerdo Capitalista.

---

## M1 U04. ¿Dónde guardo mi fondo de sequía?

**Lo que lograrás:** Elegir un lugar seguro para tu fondo, que no pierda contra la inflación y del que puedas sacar dinero rápido.

**Para empezar:** Valeria tiene 60,000 en su cuenta de nómina, sin rendimiento. Una amiga le dice que lo meta todo a la bolsa porque "subió mucho este año". Otro amigo le recomienda una app que promete 15% al mes. En esta lección aprenderás dónde sí conviene guardar tu fondo de sequía.

### Lo esencial (5 minutos)

#### Lo que necesita tu fondo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguridad | Que no se pierda ni baje de valor de golpe. | Lo más importante. |
| Liquidez | Que lo puedas sacar el mismo día o al siguiente. | Lo necesitas en la sequía. |
| Rendimiento | Que gane algo para no perder contra la inflación. | Importa, pero va al final. |

#### Opción 1: Cetes en Cetesdirecto

Los **Cetes** son préstamos que le haces al gobierno federal. En Cetesdirecto abres tu cuenta desde 100 pesos y sin comisiones.

Para tu fondo conviene **BONDDIA**: puedes retirar tu dinero y lo tienes al día siguiente hábil.



#### Opción 2: cuenta o inversión a la vista en un banco

Muchos bancos, incluidos bancos digitales, pagan rendimiento en cuentas a la vista: sacas tu dinero cuando quieras.

Lo importante es que sea un **banco** autorizado por la CNBV. Tus depósitos en un banco los protege el **IPAB** hasta 400,000 UDIS por persona y por banco.

> **Dato vigente:** al 29 de septiembre de 2026, Revolut y Nu México cuentan con autorización de la CNBV para operar como bancos (Nu inició operaciones como banco en julio de 2026), según la CNBV y los comunicados de cada institución. Antes de depositar, confírmalo en el padrón de la CNBV y en el sitio oficial de la institución, y revisa que tu contrato diga "Institución de Banca Múltiple".



#### Lo que no es para tu fondo de sequía

- **Acciones o fondos que siguen a la bolsa** (como NAFTRAC): pueden bajar justo cuando necesitas tu dinero.
- **Apps o personas que prometen rendimientos muy altos:** casi siempre son fraude (M9 U07).
- **Tu cuenta de gastos:** te lo acabas sin darte cuenta.



#### Un caso en un minuto

Valeria dividió su fondo: 30,000 en BONDDIA y 30,000 en una cuenta a la vista de un banco que verificó en el padrón de la CNBV.

No lo metió a la bolsa. En junio se quedó sin campañas y sacó su dinero al día siguiente, sin perder nada.

> **Idea clave:** para el fondo de sequía, primero seguridad, luego liquidez y al final rendimiento.



#### Comprueba lo que entendiste

1. ¿Por qué no guardas tu fondo de sequía en acciones?
*Respuesta:* Porque pueden bajar justo cuando necesitas el dinero.

2. ¿Qué protege el IPAB?
*Respuesta:* Tus depósitos en bancos, hasta 400,000 UDIS por persona y por banco.


#### Para recordar

- Cetes (BONDDIA) o cuenta a la vista en un banco.
- Verifica en la CNBV que sea banco.
- Nada de promesas de rendimientos altos.



### Profundiza (5 minutos más)

#### Cómo comparar el rendimiento

Compara la **GAT** nominal y la GAT real. La real ya descuenta la inflación: si es negativa, tu dinero pierde poder de compra.

Pregunta también si el rendimiento tiene tope (por ejemplo, solo hasta cierto saldo) o si es promocional por unos meses.



#### Cetesdirecto y cuenta a la vista

| | BONDDIA en Cetesdirecto | Cuenta a la vista en banco |
|---|---|---|
| Quién respalda | Gobierno federal | El banco, con protección del IPAB |
| Mínimo | 100 pesos | Depende del banco |
| Retiro | Al día siguiente hábil | Casi siempre inmediato |
| Comisiones | Sin comisiones | Revisa el contrato |



#### Cómo verificar que es banco

1. Busca el nombre en el padrón de entidades supervisadas de la CNBV.
2. Revisa en tu contrato el nombre legal: debe decir "Institución de Banca Múltiple".
3. Consulta el Buró de Entidades Financieras de CONDUSEF para ver quejas y sanciones.

Otras entidades (como SOFIPO o cooperativas) funcionan con reglas y protecciones distintas. En este curso no las recomendamos para tu fondo.



#### Divide si tienes mucho

Si tu fondo pasa de 400,000 UDIS, repártelo entre bancos o combina banco y Cetes para que todo quede protegido.

> **Dato vigente:** el IPAB protege hasta 400,000 UDIS, unos 3.4 millones de pesos. Consultado el 29 de septiembre de 2026 a través del IPAB. El valor de la UDI cambia cada día.



#### Casos


**Caso 1. La amiga de Valeria**

Una amiga le recomienda a Valeria meter su fondo de sequía a la bolsa porque "subió mucho este año".
- *¿Qué hace Valeria?* No lo hace: la bolsa puede bajar cuando necesite el dinero. Usa Cetes o una cuenta a la vista en un banco.


**Caso 2. La app de Renata**

Renata encuentra una app que promete 15% al mes.
- *¿Qué hace?* No deposita: busca la app en la CNBV y en CONDUSEF. Un rendimiento así es señal de fraude.


**Caso 3. El banco digital de Gael**

Gael quiere abrir una cuenta en un banco digital que le paga rendimiento diario.
- *¿Qué revisa primero?* Que aparezca como banco en el padrón de la CNBV y que su contrato diga "Institución de Banca Múltiple".


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar el fondo en acciones | Puede bajar cuando lo necesitas | Usa Cetes o cuenta a la vista |
| Creer en rendimientos muy altos | Pierdes todo | Verifica en CNBV y CONDUSEF |
| No revisar quién está detrás de la app | Tu dinero puede no estar protegido | Confirma que sea banco |
| Dejarlo en la cuenta de gastos | Te lo acabas | Sepáralo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es lo más importante para tu fondo de sequía? a) La seguridad y poder sacarlo rápido · b) El rendimiento más alto que encuentres en cualquier app · c) Que esté en una app nueva
2. ¿Qué opción de Cetesdirecto te permite retirar al día siguiente? a) BONDDIA · b) Cetes a un año · c) Bonos a 10 años
3. ¿Dónde confirmas que una entidad es un banco? a) En sus redes sociales · b) En el padrón de la CNBV · c) En las reseñas de la app
**Respuestas:** 1-a: primero seguridad y liquidez. 2-a: BONDDIA tiene liquidez diaria. 3-b: la CNBV supervisa a los bancos.



#### Ponlo en práctica

Escribe dónde está hoy tu fondo de sequía y revisa si cumple con seguridad, liquidez y rendimiento.
**Respuesta:** Por ejemplo: "Está en mi cuenta de gastos. No es seguro para mi meta porque me lo gasto. Lo moveré a BONDDIA y a una cuenta a la vista en un banco verificado."



#### A tu plan

Verifica en el padrón de la CNBV la institución donde está tu fondo y anota su GAT real.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com — **Qué buscar:** cómo abrir tu cuenta y qué es BONDDIA.
- **Padrón de entidades supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** "Padrón de entidades supervisadas" y busca el nombre legal del banco.
- **Seguro de depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** qué depósitos protege y hasta cuánto.

### Palabras clave

- *Cetes:* deuda del gobierno federal que te paga rendimiento.
- *BONDDIA:* inversión en Cetesdirecto con retiro diario.
- *IPAB:* protege tus depósitos en bancos.
- *GAT:* lo que te paga una cuenta al año.

### Fuentes

Cetesdirecto · CNBV, padrón de entidades supervisadas · IPAB · Comunicados de Nu México y Revolut, consultados el 29 de septiembre de 2026.

---

## M1 U05. Vestuario, imagen y estilismo: ¿gasto necesario o fuga?

**Lo que lograrás:** Separar el vestuario que pide una producción del mantenimiento de tu imagen, y presupuestar los dos sin descapitalizarte.

**Para empezar:** Valeria aceptó una publicidad de 30,000. La producción le pidió cuatro cambios de ropa de marca que costaron 18,000. Además, esa semana se hizo uñas, pestañas y un corte "para verse bien". Al final, ganó menos que si no hubiera aceptado. En esta lección aprenderás a controlar tus gastos de imagen.

### Lo esencial (5 minutos)

#### Dos tipos de gasto de imagen

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Vestuario de proyecto | Lo que pide vestuarismo para un personaje o campaña. | Negócialo antes de firmar. |
| Mantenimiento de imagen | Corte, gimnasio, dermatología, clases de voz. | Presupuéstalo cada mes. |

#### El vestuario de proyecto se negocia

Antes de aceptar, pregunta: ¿la producción presta la ropa? ¿La reembolsa? ¿Puedo usar mi propia ropa?

Si tú lo pagas, súmalo como costo del proyecto (M1 U01). A veces el proyecto deja de convenir.



#### El mantenimiento de imagen se presupuesta

Tu imagen es tu herramienta de trabajo, pero no puede comerse tu sueldo.

Pon un monto fijo al mes para imagen, por ejemplo 8% de tu sueldo, y respétalo.



#### ¿Te conviene la publicidad?

Así se veía el trabajo de Valeria.
- Pago de la publicidad: **30,000**
- Comisión del mánager (15%): **4,500**
- Ropa que no le reembolsan: **18,000**
- Lo que le queda antes de impuestos: **7,500**
Por dos días de trabajo, con ropa que tal vez no vuelva a usar.


#### Un caso en un minuto

En la siguiente campaña, Valeria preguntó por el vestuario antes de firmar. La marca aceptó prestarle la ropa.

Su ganancia pasó de 7,500 a 25,500 por el mismo trabajo.

> **Idea clave:** el vestuario de proyecto se negocia antes; el de imagen se presupuesta siempre.



#### Comprueba lo que entendiste

1. ¿Cuándo negocias el vestuario de una producción?
*Respuesta:* Antes de firmar o aceptar el proyecto.

2. ¿El gimnasio y el corte de cabello son vestuario de proyecto?
*Respuesta:* No. Son mantenimiento de imagen y van en tu presupuesto mensual.


#### Para recordar

- Pregunta por el vestuario antes de aceptar.
- Suma el vestuario al costo del proyecto.
- Ten un presupuesto fijo para tu imagen.



### Profundiza (5 minutos más)

#### Pide todo por escrito

Si la producción promete reembolsar, pide por escrito cuánto, cuándo y con qué comprobantes. Guarda los tickets y facturas.

Si facturas en Actividad Empresarial, pide la factura a tu nombre: puede ser deducible. En RESICO no se deduce, pero sí te sirve para cobrar el reembolso (M2 U03).



#### Presupuesto de imagen de Gael

| Gasto | Al mes |
|---|---|
| Gimnasio | 900 |
| Corte y barba | 500 |
| Dermatología (prorrateada) | 400 |
| Clases de voz | 1,200 |
| **Total** | **3,000** |

3,000 es 12% de su sueldo de 25,000. Decidió bajar a un gimnasio de 500 para quedar en 10%.



#### Tu propio clóset de trabajo

Algunos artistas arman un clóset básico de trabajo: prendas neutras que sirven para muchos castings y llamados. Se compran una vez y se cuidan.

Así no compras ropa nueva para cada audición.



#### Headshots, book y demo reel

Son inversiones que te consiguen trabajo, pero no todos los años. Cotiza con al menos tres fotógrafos o editores y pregunta qué incluye cada paquete.

Desconfía de quien cobra un book obligatorio para darte un casting (M9 U02).



#### Casos


**Caso 1. La publicidad de Valeria**

La marca le pide a Valeria ropa por 18,000 y le paga 30,000.
- *¿Qué hace antes de aceptar?* Pregunta si prestan o reembolsan la ropa. Si no, negocia su tarifa o evalúa si le conviene.


**Caso 2. El presupuesto de Gael**

Gael gasta en imagen 12% de su sueldo y quiere bajarlo a 10%.
- *¿Qué hace?* Revisa gasto por gasto y cambia lo que puede, como un gimnasio más barato.


**Caso 3. El book de Renata**

Una agencia le dice a Renata que necesita un book de 9,000 con "su fotógrafo" para entrar a castings.
- *¿Qué hace?* Desconfía: cotiza con otros fotógrafos y verifica a la agencia. Un book obligatorio con un proveedor único es señal de alerta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar el vestuario sin preguntar | El proyecto deja poca ganancia | Negocia antes |
| No guardar comprobantes | No cobras el reembolso | Pide todo por escrito |
| Comprar ropa nueva para cada casting | Gastas de más | Arma un clóset de trabajo |
| Pagar un book obligatorio | Puede ser fraude | Cotiza y verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te pagan 20,000 y debes comprar ropa por 12,000 sin reembolso. Tu mánager cobra 15%. ¿Cuánto te queda? a) 8,000 · b) 5,000 · c) 17,000
2. ¿Qué gasto es mantenimiento de imagen? a) El vestuario de un personaje · b) Tu corte de cabello · c) La ropa de una campaña
3. Te piden un book obligatorio con un fotógrafo específico. ¿Qué haces? a) Lo pagas para no perder la oportunidad · b) Cotizas y verificas a la agencia · c) Pides prestado para pagarlo
**Respuestas:** 1-b: 20,000 − 3,000 − 12,000 = 5,000. 2-b: es parte de tu presupuesto mensual. 3-b: es una señal de alerta.



#### Ponlo en práctica

Suma tus gastos de imagen de un mes y calcula qué porcentaje de tu sueldo representan.
**Respuesta:** Por ejemplo: gimnasio 700, corte 400, uñas 500, clases 1,000 = 2,600. Mi sueldo es 20,000: 13%. Voy a bajar a 10%.



#### A tu plan

Escribe tu presupuesto mensual de imagen y tres preguntas que harás sobre vestuario antes de aceptar un proyecto.



### Para saber más

- **Quién es Quién en los Precios** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** comparadores de precios antes de comprar.
- **Tus derechos como consumidor** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** qué hacer si un proveedor no cumple lo que te vendió.

### Palabras clave

- *Vestuario de proyecto:* ropa que pide una producción para un personaje o campaña.
- *Mantenimiento de imagen:* gastos para cuidar tu imagen de trabajo.
- *Book:* portafolio de fotos profesionales.

### Fuentes

Profeco · Prácticas del medio artístico.

---

## M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?

**Lo que lograrás:** Hacer un calendario de cobros y pagos con los tiempos reales en que pagan productoras, agencias y plataformas.

**Para empezar:** Gael terminó de grabar en marzo. La productora le paga en junio. Su tarjeta vence en abril y la renta en cada mes. Cree que "ya tiene el dinero" porque firmó el contrato. En esta lección aprenderás a planear con la fecha en que el dinero llega, no con la fecha en que lo ganas.

### Lo esencial (5 minutos)

#### Ganado no es cobrado

Firmar un contrato o terminar un trabajo no pone dinero en tu cuenta. En el medio, es común que paguen a 30, 60 o 90 días después de entregar tu factura.

Para decidir, cuenta solo el dinero que ya está en tu cuenta.



#### Tres fechas que debes conocer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fecha de trabajo | Cuando grabas, cantas o posas. | Todavía no hay dinero. |
| Fecha de factura | Cuando entregas tu factura o recibo. | Empieza a correr el plazo. |
| Fecha de pago | Cuando el dinero llega a tu cuenta. | Solo aquí es tuyo. |

#### Tu calendario de flujo

Haz una tabla con los próximos seis meses. En cada mes anota lo que va a entrar (con fecha real de pago) y lo que tienes que pagar.

Así ves con anticipación los meses en que no alcanza.



#### El abril de Gael

Gael revisa su calendario.
- Lo que tiene en su cuenta de gastos: **5,000**
- Sus gastos de abril: **18,000**
- Lo que le falta en abril: **-13,000**
El pago de 60,000 llega hasta junio. Necesita su fondo de sequía en abril y mayo.


#### Un caso en un minuto

Gael hizo su calendario y vio el hueco de abril y mayo. Usó 26,000 de su fondo de sequía y no tocó la tarjeta.

Cuando llegó el pago en junio, repuso su fondo primero.

> **Idea clave:** planea con la fecha de pago, no con la fecha de trabajo.



#### Comprueba lo que entendiste

1. Firmaste un contrato de 50,000 que pagan en 90 días. ¿Cuándo es tuyo ese dinero?
*Respuesta:* Cuando llega a tu cuenta.

2. ¿Para qué sirve tu calendario de flujo?
*Respuesta:* Para ver antes los meses en que no alcanza y prepararte.


#### Para recordar

- Ganado no es cobrado.
- Anota la fecha real de pago.
- Revisa tu calendario cada mes.



### Profundiza (5 minutos más)

#### Pregunta el plazo antes de firmar

Pregunta y pide por escrito: ¿cuándo pagan? ¿Contra qué documento? ¿Qué pasa si se atrasan?

Algunos contratos incluyen intereses o penalización por pago tardío. Si no está, puedes negociarlo (M3 U01).



#### Calendario de Gael

| Mes | Entra | Sale | Saldo |
|---|---|---|---|
| Abril | 0 | 18,000 | −13,000 (usa su fondo) |
| Mayo | 0 | 18,000 | usa su fondo |
| Junio | 60,000 | 18,000 | repone su fondo |
| Julio | 15,000 | 18,000 | usa lo que sobró |



#### Da seguimiento a tus facturas

Lleva una lista de facturas pendientes: cliente, monto, fecha de entrega y fecha de pago prometida. Cuando se pase la fecha, escribe un recordatorio amable y por escrito.

Si pasan semanas sin respuesta, revisa qué dice tu contrato y busca orientación (M3 U06).



#### No cubras el hueco con la tarjeta

Si usas la tarjeta mientras llega el pago, pagarás intereses y te arriesgas a que el pago se atrase más. Primero usa tu fondo de sequía.

Si no tienes fondo, habla con tus acreedores antes de la fecha límite (M8 U02).



#### Casos


**Caso 1. El pago de Gael**

Gael terminó en marzo y le pagan en junio. En abril le faltan 13,000.
- *¿Qué hace?* Usa su fondo de sequía para abril y mayo, y lo repone cuando llega el pago.


**Caso 2. La factura de Valeria**

Valeria entregó su factura hace 75 días y el contrato dice 60.
- *¿Qué hace?* Envía un recordatorio por escrito y revisa si el contrato prevé penalización por atraso.


**Caso 3. La tarjeta de Renata**

Renata va a cobrar un evento en 60 días y quiere comprar ropa hoy con la tarjeta "porque ya viene el dinero".
- *¿Le conviene?* No. Ese dinero todavía no es suyo y el pago podría atrasarse.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar dinero que aún no llega | Te endeudas si se atrasa | Cuenta solo lo que está en tu cuenta |
| No preguntar el plazo de pago | Te sorprende la espera | Pregunta antes de firmar |
| No dar seguimiento a facturas | Se olvidan tus pagos | Lleva una lista |
| Cubrir huecos con la tarjeta | Pagas intereses | Usa tu fondo de sequía |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Con qué fecha planeas tus gastos? a) La fecha en que trabajas · b) La fecha en que te pagan · c) La fecha en que firmas
2. Tienes 4,000 y gastos de 15,000 este mes; tu pago llega en dos meses. ¿Cuánto te falta este mes? a) 15,000 · b) 19,000 · c) 11,000
3. Tu factura lleva 20 días de retraso. ¿Qué haces? a) Esperar sin decir nada · b) Publicarlo en redes para presionar a la productora · c) Enviar un recordatorio por escrito
**Respuestas:** 1-b: solo el dinero en tu cuenta es tuyo. 2-c: 15,000 − 4,000. 3-c: el seguimiento por escrito ayuda y deja registro.



#### Ponlo en práctica

Haz tu calendario de los próximos tres meses con lo que entrará (fecha real) y lo que pagarás. ¿En qué mes te falta?
**Respuesta:** Por ejemplo: octubre entra 0 y salen 17,000; noviembre entran 40,000 y salen 17,000. En octubre me faltan 17,000: uso mi fondo.



#### A tu plan

Arma tu lista de facturas pendientes con cliente, monto y fecha prometida de pago.



### Para saber más

- **Planea tu presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Educación financiera" y las guías para ordenar tus ingresos y gastos.
- **Verifica tus facturas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Verificación de comprobantes fiscales" para confirmar que tu factura está registrada.

### Palabras clave

- *Flujo de efectivo:* cuándo entra y cuándo sale tu dinero.
- *Plazo de pago:* días que tarda un cliente en pagarte.
- *Factura pendiente:* trabajo cobrado que aún no te pagan.

### Fuentes

CONDUSEF, educación financiera · SAT, verificación de CFDI.

---


---

# Módulo 2. Tu carrera como negocio: régimen fiscal e impuestos

## M2 U01. ¿RESICO, Asimilados o Actividad Empresarial?

**Lo que lograrás:** Conocer cómo funciona cada forma de pagar impuestos para llegar preparado a la conversación con tu contador.

**Para empezar:** Gael factura en RESICO, pero una productora le paga como "asimilado". Además gasta mucho en vestuario y clases, y creía que en RESICO podía deducirlos. Su contador le dice que tiene que revisar las dos cosas. En esta lección conocerás los tres caminos más comunes para gente del medio.

### Lo esencial (5 minutos)

#### Tu régimen decide cómo pagas

El **régimen fiscal** define cuánto ISR pagas, si puedes deducir gastos y qué declaraciones presentas.

Elegirlo bien depende de cuánto ganas, cuánto gastas para trabajar y cómo te pagan. Esa decisión se toma con un contador.



#### Los tres caminos más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| RESICO | Pagas de 1% a 2.5% sobre lo que cobras, sin deducir gastos. | Sencillo si tus gastos son bajos. |
| Asimilados a salarios | La productora te retiene ISR con la tarifa de sueldos, hasta 35%. | No te da IMSS ni prestaciones. |
| Actividad Empresarial y Profesional | Pagas sobre tus ingresos menos tus gastos deducibles, con tarifa progresiva. | Conviene si gastas mucho para trabajar. |

#### Tasas de RESICO por ingreso del mes

| Lo que cobras en el mes (sin IVA) | Tasa de ISR |
|---|---|
| Hasta 25,000 | 1% |
| Hasta 50,000 | 1.1% |
| Hasta 83,333.33 | 1.5% |
| Hasta 208,333.33 | 2% |
| Hasta 3.5 millones al año | 2.5% |

> **Dato vigente:** tasas del artículo 113-E de la LISR, sin cambios para 2026. Consultado el 29 de septiembre de 2026 a través del SAT y la LISR.



#### Asimilados y RESICO no siempre se pueden combinar

Si cobras honorarios como asimilado a salarios porque así lo pediste por escrito, o porque le trabajas principalmente a un solo cliente, la ley te excluye de RESICO.

Esta combinación es común en el medio. Llévala a tu contador antes de tu siguiente contrato.



#### Un caso en un minuto

Gael revisó con su contador: el año pasado gastó 35% de lo que cobró en vestuario, clases y traslados, y además cobró como asimilado.

Su contador le propuso pasar a Actividad Empresarial para deducir sus gastos y ordenar cómo le pagan. Gael ya entiende por qué.

> **Idea clave:** no hay un régimen mejor para todos. El mejor es el que corresponde a cómo trabajas y cuánto gastas.



#### Comprueba lo que entendiste

1. ¿En RESICO puedes deducir tu vestuario?
*Respuesta:* No. RESICO no permite deducir gastos.

2. ¿Asimilados te da IMSS y aguinaldo?
*Respuesta:* No. Solo te retienen ISR como si fuera sueldo.


#### Para recordar

- RESICO: tasa baja, sin deducciones.
- Asimilados: retención alta, sin prestaciones.
- Actividad Empresarial: deduces gastos, tarifa progresiva.



### Profundiza (5 minutos más)

#### Comparación rápida

| | RESICO | Asimilados | Actividad Empresarial |
|---|---|---|---|
| ISR | 1% a 2.5% de lo cobrado | Tarifa de sueldos, hasta 35% | Tarifa progresiva sobre la utilidad, hasta 35% |
| Deducciones | No | No del negocio | Sí, con factura |
| Retención si facturas a una empresa | 1.25% de ISR | La empresa retiene todo el ISR | 10% de ISR |
| IVA | Cobras IVA en tus servicios | No cobras IVA | Cobras IVA en tus servicios |
| Límite de ingresos | 3.5 millones al año | No aplica | No aplica |



#### Quién no puede estar en RESICO

Entre otros casos: socios o accionistas de empresas, personas con ciertos ingresos asimilados a salarios y quienes superan 3.5 millones al año.

Si superas el límite o dejas de cumplir, el SAT te cambia de régimen. Revisa tu constancia de situación fiscal para saber en cuál estás.

> **Dato vigente:** exclusiones del artículo 113-E de la LISR. Consultado el 29 de septiembre de 2026 a través del SAT. Tu caso concreto confírmalo con tu contador.



#### También pueden retenerte IVA

Cuando facturas servicios a una empresa, esta suele retenerte dos terceras partes del IVA y enterarlo por ti. Tu factura debe mostrar esas retenciones.



#### Un ejemplo con números

Gael cobra 600,000 al año y gasta 210,000 para trabajar.

En RESICO pagaría alrededor de 1.5% a 2% de los 600,000, sin restar gastos. En Actividad Empresarial pagaría sobre 390,000 (600,000 − 210,000), con tarifa progresiva.

Cuál conviene depende de los números exactos de cada año. Pide a tu contador que haga las dos cuentas.



#### Casos


**Caso 1. El vestuario de Gael**

Gael está en RESICO y quiere deducir 60,000 de vestuario.
- *¿Puede?* No. En RESICO no hay deducciones. Si sus gastos son altos, puede revisar con su contador si le conviene Actividad Empresarial.


**Caso 2. El contrato de Valeria**

Una productora le propone a Valeria pagarle "como asimilada" y ella está en RESICO.
- *¿Qué hace antes de firmar?* Consulta a su contador, porque esa forma de pago puede sacarla de RESICO.


**Caso 3. La constancia de Toño**

Toño no sabe en qué régimen está.
- *¿Dónde lo revisa?* En su constancia de situación fiscal, que descarga en el portal del SAT.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que en RESICO deduces gastos | Pagas menos de lo debido y el SAT te cobra | Pregunta qué aplica en tu régimen |
| Aceptar pagos como asimilado sin revisar | Puedes salir de RESICO | Consulta antes de firmar |
| Elegir régimen por lo que hace un amigo | No corresponde a tu caso | Haz las cuentas con tu contador |
| No saber en qué régimen estás | Presentas mal tus declaraciones | Descarga tu constancia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. En RESICO cobras 40,000 en el mes. ¿Qué tasa de ISR aplica? a) 1.1% · b) 2.5% · c) 10%
2. Gastas 40% de lo que cobras en tu trabajo. ¿Qué te conviene revisar con tu contador? a) Pasarte a asimilados para que te retengan todo a ti · b) Dejar de facturar · c) Si te conviene Actividad Empresarial
3. ¿Dónde confirmas tu régimen actual? a) En tu estado de cuenta · b) En tu contrato con la productora que te paga más · c) En tu constancia de situación fiscal
**Respuestas:** 1-a: hasta 50,000 al mes es 1.1%. 2-c: ahí puedes deducir gastos. 3-c: la constancia del SAT dice tu régimen.



#### Ponlo en práctica

Suma lo que cobraste el año pasado y lo que gastaste para trabajar. ¿Qué porcentaje fueron tus gastos?
**Respuesta:** Por ejemplo: cobré 400,000 y gasté 120,000: 30%. Con gastos así de altos, le pido a mi contador que compare RESICO y Actividad Empresarial.



#### A tu plan

Descarga tu constancia de situación fiscal y anota tu régimen. Escribe tres preguntas para tu contador.



### Para saber más

- **Régimen Simplificado de Confianza** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "RESICO personas físicas", la tabla de tasas y quiénes no pueden tributar en él.
- **Constancia de situación fiscal** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Genera tu constancia de situación fiscal" con tu RFC y contraseña o e.firma.
- **Orientación gratuita al contribuyente** (PRODECON · español): https://www.gob.mx/prodecon — **Qué buscar:** "Asesoría" para resolver dudas fiscales sin costo.

### Palabras clave

- *Régimen fiscal:* la forma en que el SAT te pide pagar impuestos.
- *RESICO:* régimen con tasas de 1% a 2.5%, sin deducciones.
- *Asimilados a salarios:* pago de honorarios con retención como si fuera sueldo.
- *Actividad Empresarial y Profesional:* régimen donde deduces gastos.

### Fuentes

LISR, artículos 94, 96, 100 a 110 y 113-E a 113-J, consultados el 29 de septiembre de 2026 a través del SAT · PRODECON.

---

## M2 U02. El IVA: el dinero que cobras pero no es tuyo

**Lo que lograrás:** Entender que el IVA que cobras en tus facturas se entrega al SAT y apartarlo el mismo día que te pagan.

**Para empezar:** Valeria facturó 50,000 más IVA por una campaña. Le depositaron 58,000 y los usó como si fueran suyos. Al mes siguiente su contador le dijo que debía 8,000 de IVA y no los tenía. En esta lección aprenderás a separar el IVA desde el primer día.

### Lo esencial (5 minutos)

#### ¿Qué es el IVA de tus facturas?

Cuando facturas servicios, le sumas 16% de **IVA** a tu precio. Tu cliente te lo paga, pero tú solo lo cobras por cuenta del SAT.

Ese dinero no es ganancia. Hay que entregarlo en tu declaración del mes.



#### La factura de Valeria

Así se ve una factura de 50,000 más IVA a una persona física.
- Tu precio: **50,000**
- IVA (16%): **8,000**
- Lo que te pagan: **58,000**
De esos 58,000, 8,000 son del SAT.


#### Lo que puedes restar: el IVA acreditable

El IVA que tú pagas en gastos de tu trabajo, con factura a tu nombre y pagados con transferencia o tarjeta, puede restarse del IVA que cobraste. Se llama **IVA acreditable**.

Si compraste un micrófono de 11,600 (con 1,600 de IVA), podrías entregar 8,000 − 1,600 = 6,400. Tu contador confirma qué gastos califican.



#### Un caso en un minuto

Desde entonces, Valeria abrió una subcuenta llamada "Impuestos". Cada vez que le pagan, pasa ahí el IVA y un porcentaje para el ISR.

El día 17 del mes siguiente, cuando presenta su declaración, el dinero ya está apartado.

> **Idea clave:** el IVA que cobras nunca fue tuyo. Apártalo el mismo día.



#### Tres casos de IVA en tus facturas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Facturas a una persona | Cobras 16% de IVA completo y lo entregas tú. | Apártalo todo. |
| Facturas a una empresa | La empresa suele retenerte dos tercios del IVA y lo entera por ti. | Tú entregas el resto. |
| Facturas a un cliente del extranjero | Puede aplicar tasa de 0% como exportación de servicios. | Confírmalo con tu contador. |

#### Comprueba lo que entendiste

1. Facturas 20,000 más IVA a una persona. ¿Cuánto IVA apartas?
*Respuesta:* 3,200.

2. ¿El IVA que cobras es parte de tu ganancia?
*Respuesta:* No. Lo cobras por cuenta del SAT.


#### Para recordar

- El IVA es 16% sobre tu precio.
- Apártalo el mismo día que te pagan.
- El IVA de tus gastos con factura puede restarse.



### Profundiza (5 minutos más)

#### Cuándo se paga

El IVA se declara cada mes, a más tardar el día 17 del mes siguiente. Se paga sobre lo que efectivamente cobraste ese mes, no sobre lo que facturaste y aún no te pagan.

Si un mes tu IVA acreditable es mayor que el que cobraste, tienes saldo a favor. Tu contador te dice cómo usarlo.

> **Dato vigente:** tasa general de IVA de 16% y declaración mensual a más tardar el día 17. Consultado el 29 de septiembre de 2026 a través del SAT y la Ley del IVA.



#### Factura a una empresa, en RESICO

| Concepto | Monto |
|---|---|
| Precio del servicio | 50,000 |
| IVA 16% | 8,000 |
| Retención de ISR (1.25%) | −625 |
| Retención de IVA (dos tercios) | −5,333.33 |
| **Te depositan** | **52,041.67** |

Tú entregas al SAT el IVA que no te retuvieron (2,666.67), menos tu IVA acreditable.



#### ¿Y la comisión del mánager?

Tu mánager también debe facturarte con IVA. Ese IVA puede ser acreditable para ti si la factura está a tu nombre y la pagaste por transferencia.

Pide que la comisión se calcule sobre tu honorario sin IVA (M3 U03).



#### Si ya te gastaste el IVA

No lo ignores. Si no declaras, se acumulan recargos y multas. Habla con tu contador para declarar y, si no puedes pagar todo, pregunta por el pago en parcialidades que ofrece el SAT.



#### Casos


**Caso 1. El depósito de Valeria**

A Valeria le depositan 58,000 por una factura de 50,000 más IVA a una persona.
- *¿Cuánto aparta para IVA?* 8,000, menos el IVA acreditable de sus gastos con factura que confirme su contador.


**Caso 2. El micrófono de Toño**

Toño compró un micrófono de 11,600 con factura a su nombre, pagado con tarjeta.
- *¿Qué parte le puede servir para su IVA?* Los 1,600 de IVA, como IVA acreditable, si su contador confirma que es gasto de su actividad.


**Caso 3. El IVA que Gael no apartó**

Gael se gastó el IVA de tres meses y no ha declarado.
- *¿Qué hace?* Habla con su contador para declarar y revisar el pago en parcialidades, antes de que crezcan los recargos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Usar el IVA como ganancia | Debes dinero al SAT | Apártalo el mismo día |
| Pedir facturas sin tu RFC | No puedes acreditar el IVA | Pide factura a tu nombre |
| Pagar gastos en efectivo | Puede que no se acredite | Paga con transferencia o tarjeta |
| No declarar por no tener dinero | Recargos y multas | Declara y pide parcialidades |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Facturas 30,000 más IVA a una persona. ¿Cuánto es el IVA? a) 4,800 · b) 3,000 · c) 1,200
2. ¿Qué IVA puedes restar del que cobraste? a) El de tu súper · b) El de tus gastos de trabajo con factura a tu nombre · c) Cualquier IVA que pagues en el mes, sea de trabajo o personal
3. ¿Hasta qué día declaras el IVA del mes? a) El día 17 del mes siguiente · b) El último día del mes · c) En abril, una vez al año
**Respuestas:** 1-a: 16% de 30,000. 2-b: solo el de tu actividad, con factura. 3-a: es una declaración mensual.



#### Ponlo en práctica

Toma tu último cobro con factura. ¿Cuánto IVA cobraste y cuánto IVA acreditable tuviste ese mes?
**Respuesta:** Por ejemplo: facturé 25,000 más 4,000 de IVA. Tuve gastos con factura con 900 de IVA. Aparto 4,000 y mi contador calcula el pago de 3,100.



#### A tu plan

Abre una subcuenta o apartado para impuestos y define qué porcentaje de cada cobro pasarás ahí.



### Para saber más

- **Declaraciones mensuales** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Declaraciones de pagos mensuales" de personas físicas.
- **Pago en parcialidades** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Pago a plazos" o "Pago en parcialidades" para regularizarte.

### Palabras clave

- *IVA:* impuesto de 16% que cobras y entregas al SAT.
- *IVA acreditable:* IVA de tus gastos de trabajo que restas del que cobraste.
- *Retención:* impuesto que tu cliente te descuenta y entrega por ti.

### Fuentes

Ley del IVA, artículos 1, 1-A y 5 · SAT, declaraciones mensuales, consultados el 29 de septiembre de 2026.

---

## M2 U03. ¿Qué gastos de mi carrera sí puedo deducir, y en qué régimen?

**Lo que lograrás:** Armar tu carpeta de comprobantes sabiendo que las deducciones del negocio aplican en Actividad Empresarial, no en RESICO.

**Para empezar:** Toño guarda tickets de todo en una caja: gasolina, cuerdas, un amplificador, comidas con amigos. Cree que "todo es deducible". Su contador solo puede usar una parte, y en su régimen actual, ninguna. En esta lección aprenderás qué sí cuenta y cuándo.

### Lo esencial (5 minutos)

#### Deducir es restar gastos de trabajo

En Actividad Empresarial y Profesional pagas ISR sobre tu utilidad: ingresos menos **deducciones autorizadas**.

En RESICO no se deduce nada. Por eso primero confirma tu régimen (M2 U01).



#### Gastos de tu carrera que pueden ser deducibles

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Formación | Clases de actuación, canto, baile, acento. | Con factura a tu nombre. |
| Promoción | Headshots, demo reel, sitio web, publicidad en redes. | Con factura a tu nombre. |
| Herramientas | Instrumentos, equipo de audio, cómputo, vestuario de trabajo. | Algunos se deducen en varios años. |
| Gastos personales | Comidas con amigos, ropa de diario, vacaciones. | No son deducibles. |

#### Tres requisitos de un gasto deducible

1. **Es necesario para tu trabajo.** Tiene relación clara con tu actividad.
2. **Tiene factura (CFDI) a tu nombre y RFC**, con el uso correcto.
3. **Lo pagaste con transferencia, tarjeta o cheque** cuando pasa de 2,000 pesos.



#### Un caso en un minuto

Toño separó su caja: de 42 tickets, solo 11 eran gastos de trabajo con factura. Con su contador revisaron si le convenía cambiar de RESICO a Actividad Empresarial.

Desde entonces, pide factura en el momento y paga con tarjeta de débito.

> **Idea clave:** un gasto sin factura a tu nombre no se deduce, aunque sea de trabajo.



#### Comprueba lo que entendiste

1. ¿Una cena con amigos es deducible?
*Respuesta:* No. Es un gasto personal.

2. ¿En RESICO puedes deducir tus clases de canto?
*Respuesta:* No. RESICO no permite deducciones.


#### Para recordar

- Solo se deduce en Actividad Empresarial, no en RESICO.
- Necesitas factura a tu nombre.
- Paga con medios electrónicos.



### Profundiza (5 minutos más)

#### Equipo que se deduce en varios años

Una laptop, un instrumento caro o una cámara no se deducen de golpe: se deducen poco a poco, según un porcentaje anual que marca la ley. Tu contador lo calcula.

Guarda la factura mientras uses el equipo y al menos cinco años después.



#### Deducible o no

| Gasto | ¿Deducible en Actividad Empresarial? |
|---|---|
| Clases de actuación con factura | Sí |
| Comisión del mánager con factura | Sí |
| Vestuario pedido por una producción, con factura | Sí, si está relacionado |
| Gimnasio | Depende; pregunta a tu contador |
| Ropa de uso diario | No |
| Gasolina pagada en efectivo | No |



#### Tu carpeta de comprobantes

Cada mes descarga tus facturas recibidas desde el portal del SAT y guárdalas en carpetas por mes. Anota a qué proyecto corresponde cada gasto.

Así tu contador trabaja más rápido y tú sabes cuánto te costó cada proyecto.

> **Dato vigente:** requisitos de las deducciones del artículo 27 y los artículos 103 a 105 de la LISR. Consultado el 29 de septiembre de 2026 a través del SAT.



#### Cuidado con facturas falsas

Algunas personas venden facturas de gastos que no existieron. Usarlas es un delito fiscal y el SAT puede detectarlas. Nunca compres facturas.



#### Casos


**Caso 1. La caja de Toño**

Toño tiene 42 tickets, pero solo 11 son de trabajo con factura a su nombre.
- *¿Cuáles lleva al contador?* Los 11 de trabajo con factura. Los demás son personales o no tienen factura.


**Caso 2. La laptop de Valeria**

Valeria compró una laptop de 30,000 para editar sus videos.
- *¿Se deduce toda en el año?* No. Se deduce poco a poco con el porcentaje anual que marca la ley.


**Caso 3. Las facturas de Gael**

Un conocido le ofrece a Gael facturas de gastos "para pagar menos".
- *¿Qué hace?* No acepta. Usar facturas falsas es delito fiscal.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar tickets sin factura | No puedes deducir | Pide factura en el momento |
| Pagar en efectivo gastos grandes | La deducción no procede | Paga con tarjeta o transferencia |
| Deducir gastos personales | El SAT los rechaza | Separa trabajo y vida personal |
| Comprar facturas | Delito fiscal | Nunca lo hagas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿En qué régimen puedes deducir tus gastos de trabajo? a) RESICO · b) Actividad Empresarial y Profesional · c) En ninguno: los gastos de trabajo nunca se pueden deducir
2. ¿Qué gasto NO es deducible? a) Clases de canto con factura · b) Comisión del mánager con factura · c) Ropa de uso diario
3. Compraste equipo de 3,000 en efectivo. ¿Qué pasa? a) Se deduce igual · b) Se deduce el doble porque fue un pago en efectivo · c) Puede no deducirse por pagarlo en efectivo
**Respuestas:** 1-b: RESICO no permite deducciones. 2-c: es un gasto personal. 3-c: arriba de 2,000 debe pagarse con medios electrónicos.



#### Ponlo en práctica

Revisa tus gastos del último mes y sepáralos en tres grupos: de trabajo con factura, de trabajo sin factura y personales.
**Respuesta:** Por ejemplo: con factura, clase de canto y comisión; sin factura, taxis a castings; personales, súper y salidas. Desde ahora pido factura de los taxis por app.



#### A tu plan

Crea tu carpeta mensual de facturas y descarga las del último mes desde el SAT.



### Para saber más

- **Factura electrónica (CFDI)** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Consulta tus facturas emitidas y recibidas".
- **Deducciones de personas físicas con actividad empresarial** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Actividad empresarial y profesional" y sus deducciones.

### Palabras clave

- *Deducción autorizada:* gasto de trabajo que puedes restar de tus ingresos.
- *CFDI:* factura electrónica.
- *Utilidad:* ingresos menos gastos deducibles.

### Fuentes

LISR, artículos 27 y 103 a 105, consultados el 29 de septiembre de 2026 a través del SAT.

---

## M2 U04. Facturar, declarar y no atrasarte con el SAT

**Lo que lograrás:** Conocer tu calendario fiscal y las herramientas del SAT para cumplir a tiempo y responder si te llega un aviso.

**Para empezar:** Toño dejó de declarar dos años porque "casi no facturaba". Un día le llegó una carta invitación del SAT a su buzón tributario, que nunca revisaba. Se asustó y no supo qué hacer. En esta lección armarás tu calendario y sabrás a quién pedir ayuda.

### Lo esencial (5 minutos)

#### Tus herramientas con el SAT

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| e.firma | Tu firma electrónica. Sirve para trámites importantes. | Guárdala y no la compartas. |
| Constancia de situación fiscal | Dice tu régimen, domicilio y obligaciones. | Te la piden para facturar. |
| Buzón tributario | El SAT te avisa por ahí. | Registra tu correo y celular. |
| Opinión de cumplimiento | Dice si estás al día. | Algunas productoras la piden. |

#### Tu calendario básico

- **Cada mes, a más tardar el día 17:** declaración de ISR e IVA del mes anterior (RESICO o Actividad Empresarial).
- **En abril:** declaración anual de personas físicas, si te corresponde.
- **Cada vez que cobras:** factura (CFDI 4.0) con los datos correctos de tu cliente.



#### Aunque no factures, declara

Si un mes no tuviste ingresos, en muchos casos igual debes presentar tu declaración en ceros. No presentarla genera multas.



#### Un caso en un minuto

Toño habilitó su buzón tributario y encontró la carta invitación. Fue a PRODECON, que lo orientó gratis. Con un contador presentó las declaraciones atrasadas y pidió pagar en parcialidades.

Hoy tiene su opinión de cumplimiento en positivo y ya puede facturar a una disquera grande.

> **Idea clave:** el SAT avisa por el buzón tributario. Revísalo cada mes.



#### Comprueba lo que entendiste

1. ¿Hasta qué día presentas tu declaración mensual?
*Respuesta:* A más tardar el día 17 del mes siguiente.

2. ¿Qué haces si te llega una carta invitación?
*Respuesta:* Revisarla, no ignorarla, y pedir orientación a PRODECON o a tu contador.


#### Para recordar

- Declara cada mes, aunque sea en ceros.
- Revisa tu buzón tributario.
- PRODECON orienta gratis.



### Profundiza (5 minutos más)

#### Datos para facturar (CFDI 4.0)

| Dato del cliente | Dónde lo obtienes |
|---|---|
| RFC | Constancia de situación fiscal del cliente |
| Nombre o razón social exacta | Constancia de situación fiscal |
| Código postal fiscal | Constancia de situación fiscal |
| Régimen fiscal | Constancia de situación fiscal |
| Uso del CFDI | Te lo indica el cliente |

Si un dato no coincide, la factura se rechaza. Pide la constancia de tu cliente antes de facturar.



#### Qué es una carta invitación

Es un aviso del SAT: detectó algo que no cuadra, como ingresos no declarados o declaraciones faltantes. No es una multa, pero sí una señal para regularizarte.

Respóndela a tiempo. Si la ignoras, puede convertirse en un requerimiento formal.



#### PRODECON: tu defensoría gratuita

La **PRODECON** te orienta gratis, te ayuda a entender lo que te pide el SAT y puede presentar quejas si crees que el SAT te trata de forma incorrecta.

> **Dato vigente:** servicios gratuitos de asesoría y quejas de PRODECON. Consultado el 29 de septiembre de 2026 a través de su sitio oficial.



#### Elige bien a tu contador

Pide su cédula profesional, pregunta cuánto cobra al mes y qué incluye (declaraciones mensuales, anual, atención de avisos). Pide acceso a los acuses de cada declaración.

Nunca le entregues tu e.firma sin un acuerdo claro por escrito; con ella se pueden hacer trámites a tu nombre.



#### Casos


**Caso 1. La carta de Toño**

A Toño le llegó una carta invitación por no declarar dos años.
- *¿Qué hace primero?* Busca orientación en PRODECON o con un contador para regularizarse, en lugar de ignorarla.


**Caso 2. El mes sin trabajo de Valeria**

Valeria no facturó nada en agosto.
- *¿Presenta declaración?* En muchos casos sí, en ceros. Lo confirma con su contador.


**Caso 3. La factura rechazada de Gael**

A Gael le rechazaron una factura porque el código postal no coincidía.
- *¿Qué hace?* Pide la constancia de situación fiscal de la productora y vuelve a facturar con los datos exactos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar el buzón tributario | No te enteras de avisos | Regístrate y revísalo cada mes |
| No declarar en ceros | Multas | Declara aunque no factures |
| Facturar sin la constancia del cliente | La factura se rechaza | Pide los datos exactos |
| Entregar tu e.firma sin acuerdo | Pueden hacer trámites a tu nombre | Cuídala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Por dónde te avisa el SAT? a) Por redes sociales · b) Por una llamada de un número desconocido · c) Por el buzón tributario
2. ¿Qué institución te orienta gratis frente al SAT? a) CONDUSEF · b) Profeco · c) PRODECON
3. Un mes no facturaste. ¿Qué haces? a) Nada · b) Facturar algo aunque sea pequeño para no quedar en ceros ese mes · c) Presentar la declaración en ceros, si te corresponde
**Respuestas:** 1-c: es el canal oficial. 2-c: defiende al contribuyente. 3-c: no presentarla genera multas.



#### Ponlo en práctica

Escribe tu calendario fiscal: qué declaras cada mes, qué declaras en abril y quién te ayuda.
**Respuesta:** Por ejemplo: el día 17 de cada mes, ISR e IVA de RESICO; en abril, la anual si me corresponde; mi contador y PRODECON si tengo dudas.



#### A tu plan

Habilita tu buzón tributario y descarga tu opinión de cumplimiento.



### Para saber más

- **Buzón tributario** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Buzón tributario" y cómo registrar tus medios de contacto.
- **Opinión del cumplimiento** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Opinión del cumplimiento de obligaciones fiscales".
- **PRODECON** (Gobierno de México · español): https://www.gob.mx/prodecon — **Qué buscar:** "Asesoría y consulta" y cómo agendar una cita.

### Palabras clave

- *e.firma:* tu firma electrónica ante el SAT.
- *Buzón tributario:* canal por el que el SAT te avisa.
- *Carta invitación:* aviso del SAT para que te regularices.
- *PRODECON:* orienta y defiende gratis al contribuyente.

### Fuentes

SAT, buzón tributario y CFDI 4.0 · PRODECON, consultados el 29 de septiembre de 2026.

---

## M2 U05. Deducciones personales y tu declaración anual

**Lo que lograrás:** Conocer las deducciones personales, cuándo aplican y cómo pueden darte saldo a favor en tu declaración anual.

**Para empezar:** Gael pagó una cirugía de rodilla, sus consultas de psicología y un PPR. Nunca los usó en su declaración anual porque no sabía que existían. Cuando cobra por asimilados, esas deducciones pueden devolverle dinero. En esta lección aprenderás cuáles son y quién puede usarlas.

### Lo esencial (5 minutos)

#### Deducciones personales: gastos de tu vida que te regresan dinero

Además de los gastos de trabajo, la ley permite restar algunos gastos personales en tu **declaración anual**: los médicos, los hospitalarios, las primas de seguros de gastos médicos, los intereses reales de tu crédito hipotecario, tus aportaciones a un plan de retiro y algunas colegiaturas.



#### ¿Quién puede usarlas?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sueldos y asimilados | Sí, en su declaración anual. | Pueden tener saldo a favor. |
| Actividad Empresarial | Sí, en su declaración anual. | Además de sus deducciones de trabajo. |
| RESICO | No, para los ingresos de RESICO. | Tienen tasa baja a cambio. |

#### Para que cuenten

1. **Factura a tu nombre** (o de tu cónyuge, hijos o padres, según el caso).
2. **Pago con tarjeta, transferencia o cheque.** El efectivo no cuenta para gastos médicos.
3. **Guárdalas todo el año** y llévalas a tu contador en abril.



#### Un caso en un minuto

Gael cobró parte del año como asimilado. En abril, su contador sumó sus facturas médicas, de psicología y su aportación al PPR.

Le salió saldo a favor y pidió la devolución. Llegó a su cuenta en unas semanas.

> **Idea clave:** si pagas gastos médicos, pide factura y paga con tarjeta. Pueden regresarte dinero.



#### Comprueba lo que entendiste

1. ¿Las consultas de psicología pueden ser deducción personal?
*Respuesta:* Sí, con factura a tu nombre y pagadas por medio electrónico.

2. ¿En RESICO usas deducciones personales?
*Respuesta:* No, para los ingresos de RESICO no aplican.


#### Para recordar

- Hay gastos personales que te regresan dinero.
- Aplican en sueldos, asimilados y Actividad Empresarial.
- Factura y pago electrónico.



### Profundiza (5 minutos más)

#### Deducciones personales más comunes

| Deducción | Qué revisar |
|---|---|
| Honorarios médicos, dentales, de psicología y nutrición | Factura y pago electrónico |
| Gastos hospitalarios y lentes graduados | Lentes con tope anual |
| Primas de seguro de gastos médicos | Póliza a tu nombre o de tu familia |
| Intereses reales de crédito hipotecario | Constancia del banco |
| Aportaciones voluntarias al retiro y PPR | Tope propio (M11 U04) |
| Colegiaturas | Por nivel escolar, con tope |
| Donativos | A donatarias autorizadas, con tope |



#### Tienen un tope

El total de deducciones personales no puede pasar de la cantidad menor entre 5 UMA anuales y 15% de tus ingresos del año. Con la UMA de 2026 (117.31 pesos diarios; 42,794.64 al año), 5 UMA anuales son 213,973.20 pesos.

No cuentan dentro de ese tope: los donativos, las colegiaturas, los gastos médicos por incapacidad o discapacidad de 50% o más, y las aportaciones voluntarias al retiro y PPR, que tienen su propio límite (M11 U04).

> **Dato vigente:** tope global de deducciones personales del artículo 151 de la LISR y UMA 2026 publicada por el INEGI en el DOF el 9 de enero de 2026 (vigente del 1 de febrero de 2026 al 31 de enero de 2027). Consultado el 29 de septiembre de 2026 a través del SAT, el INEGI y el DOF. Los topes cambian cada año con la UMA.



#### Saldo a favor y devolución

Si en el año te retuvieron más de lo que te toca pagar, tienes saldo a favor. Puedes pedir la devolución en la misma declaración anual, a una cuenta a tu nombre.

Verifica que la CLABE sea correcta: si no coincide con tu RFC, la devolución se rechaza.



#### ¿Tengo que presentar anual?

Depende de tus ingresos y régimen. Por ejemplo, quienes están en Actividad Empresarial la presentan cada abril. Quienes solo tienen sueldos con un patrón y no rebasan cierto monto a veces no tienen que presentarla, pero pueden hacerlo para pedir su saldo a favor.

En RESICO, la ley (artículo 113-G) la pide, pero la Resolución Miscelánea Fiscal (regla 3.13.7) libera de presentarla a quien estuvo en RESICO todo el año, presentó todos sus pagos mensuales, no rebasó 3.5 millones y no tuvo ingresos de otro tipo. Si faltó algún pago mensual o tuviste otros ingresos, la anual es obligatoria.

> **Dato vigente:** regla 3.13.7 de la Resolución Miscelánea Fiscal 2026 (DOF 28 de diciembre de 2025) y artículo 113-G de la LISR. Consultado el 29 de septiembre de 2026 a través del SAT. La RMF se publica cada año: revisa la del ejercicio que declaras.



#### Casos


**Caso 1. La cirugía de Gael**

Gael pagó su cirugía con tarjeta y pidió factura a su nombre. Cobró como asimilado todo el año.
- *¿Puede usarla en su anual?* Sí, como deducción personal, dentro del tope.


**Caso 2. La dentista de Valeria**

Valeria pagó a su dentista en efectivo y sin factura.
- *¿Puede deducirlo?* No. Necesita factura y pago con tarjeta, transferencia o cheque.


**Caso 3. Las deducciones de Toño**

Toño solo tiene ingresos en RESICO y quiere deducir sus lentes.
- *¿Puede?* No, para ingresos de RESICO no aplican deducciones personales.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar en efectivo al médico | No se deduce | Paga con tarjeta o transferencia |
| No pedir factura a tu nombre | Pierdes la deducción | Da tu RFC al pagar |
| Poner una CLABE equivocada | Rechazan tu devolución | Revisa que la cuenta sea tuya |
| Creer que en RESICO aplican | Declaras mal | Pregunta a tu contador |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué gasto puede ser deducción personal? a) Tu súper del mes, si pagas con tarjeta y guardas el ticket de compra · b) Tus vacaciones · c) Tu consulta de psicología con factura, pagada con tarjeta
2. ¿Quién NO usa deducciones personales para esos ingresos? a) Quien cobra por asimilados · b) Quien está en Actividad Empresarial · c) Quien está en RESICO
3. ¿Qué pasa si la CLABE de tu devolución no está a tu nombre? a) Llega igual · b) La devolución se rechaza · c) Te la mandan en efectivo
**Respuestas:** 1-c: con factura y pago electrónico. 2-c: RESICO no usa deducciones personales. 3-b: la cuenta debe ser tuya.



#### Ponlo en práctica

Lista los gastos médicos, de seguros o de retiro que pagaste este año. ¿Cuáles tienen factura a tu nombre y pago electrónico?
**Respuesta:** Por ejemplo: dentista con tarjeta y factura, sí; consulta pagada en efectivo, no; seguro de gastos médicos, sí. Llevaré las que sí cumplen a mi contador.



#### A tu plan

Crea una carpeta de "Deducciones personales" y guarda ahí tus facturas médicas del año.



### Para saber más

- **Declaración anual de personas físicas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Declaración anual" y "Deducciones personales".
- **Devoluciones** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** cómo consultar el estado de tu devolución.

### Palabras clave

- *Deducción personal:* gasto de tu vida que puedes restar en la anual.
- *Saldo a favor:* impuesto que pagaste de más.
- *Declaración anual:* cálculo de tus impuestos de todo el año, en abril.

### Fuentes

LISR, artículos 150 y 151 · Resolución Miscelánea Fiscal · SAT, consultados el 29 de septiembre de 2026.

---


---

# Módulo 3. Contratos, representación y regalías

## M3 U01. Lo que revisas antes de firmar un llamado o una exclusividad

**Lo que lograrás:** Identificar en un contrato la vigencia, el territorio, los medios, la exclusividad, las fechas de pago y las penalizaciones.

**Para empezar:** Valeria firmó una campaña "para redes sociales" por seis meses. Tres años después su foto seguía en espectaculares y en la televisión de otro país. El contrato decía "todos los medios, a perpetuidad" y ella no lo leyó. En esta lección aprenderás qué revisar antes de firmar.

### Lo esencial (5 minutos)

#### Lo que firmas es lo que vale

Una llamada, un mensaje o una promesa del productor no cuentan si el contrato dice otra cosa. Lo que vale es lo escrito.

Lee todo antes de firmar, aunque te digan que es "el formato de siempre". Si no entiendes una cláusula, pregunta o pide tiempo.



#### Seis cosas que revisas siempre

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Vigencia | Por cuánto tiempo pueden usar tu trabajo. | Evita "a perpetuidad". |
| Territorio | En qué países. | México no es lo mismo que "mundial". |
| Medios | TV, cine, plataformas, redes, espectaculares. | Cada medio vale distinto. |
| Exclusividad | Qué te prohíben hacer y por cuánto tiempo. | Exige pago extra por ella. |
| Pago | Monto, fecha, contra qué documento. | Con penalización por atraso. |
| Penalizaciones | Qué pasa si tú o ellos no cumplen. | Que sean parejas. |

#### Casi todo se puede negociar

Vigencia, medios, exclusividad y fechas de pago se negocian. Si piden más tiempo o más medios, pide más dinero.

Negociar con respeto no te quita el trabajo; muchas veces te da más.



#### Un caso en un minuto

En su siguiente campaña, Valeria pidió cambiar "todos los medios, a perpetuidad" por "redes sociales en México, por un año". Si querían más, se pagaba aparte.

La marca aceptó. Al año siguiente renovaron y le pagaron otra vez.

> **Idea clave:** más tiempo, más medios o más países significan más pago.



#### Comprueba lo que entendiste

1. ¿Qué significa "a perpetuidad"?
*Respuesta:* Que pueden usar tu trabajo para siempre.

2. Te piden exclusividad por un año. ¿Qué pides a cambio?
*Respuesta:* Un pago adicional por esa exclusividad.


#### Para recordar

- Lee todo antes de firmar.
- Revisa vigencia, territorio, medios y exclusividad.
- Pide por escrito las fechas de pago.



### Profundiza (5 minutos más)

#### Frases que conviene revisar

| Frase | Qué significa | Qué puedes pedir |
|---|---|---|
| "A perpetuidad" | Para siempre | Un plazo: 1, 2 o 3 años |
| "Todos los medios conocidos o por conocerse" | Cualquier medio, incluso futuros | Lista cerrada de medios |
| "Territorio mundial" | Todos los países | Solo México o una región |
| "Cesión total de derechos" | Dejas de tener control | Licencia limitada |
| "Pago a 90 días contra factura" | Tardan tres meses | 30 días y penalización por atraso |



#### Exclusividad

La exclusividad te impide trabajar con marcas o empresas competidoras. Puede costarte otros trabajos.

Pide que diga exactamente qué marcas o giros incluye, por cuánto tiempo y cuánto te pagan por ella.



#### Si eres agremiado de la ANDA

Si trabajas en una producción que tiene contrato con la ANDA, hay condiciones mínimas pactadas. Pregunta a tu sindicato qué aplica a tu caso antes de firmar (M3 U04).



#### Cuándo pedir ayuda legal

Si el contrato es por mucho dinero, por varios años o incluye cesión de derechos, pide que un abogado lo revise. Cuesta menos que un mal contrato.

> **Antes de actuar, verifica:** este curso no da asesoría legal. Para tu contrato concreto, consulta a un abogado especialista en derechos de autor o entretenimiento.



#### Casos


**Caso 1. La campaña de Valeria**

El contrato dice "todos los medios, a perpetuidad, territorio mundial".
- *¿Qué pide Valeria?* Limitar medios, tiempo y territorio, y que cualquier uso extra se pague aparte.


**Caso 2. La exclusividad de Gael**

Una marca de refrescos le pide a Gael exclusividad de dos años sin pago extra.
- *¿Qué hace?* Negocia un pago por la exclusividad y que se limite a bebidas, o reduce el plazo.


**Caso 3. El pago de Renata**

El contrato de un evento de Renata dice "pago a 120 días".
- *¿Qué negocia?* Un plazo más corto, un anticipo y penalización por pago tardío.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin leer | Cedes más de lo que crees | Lee cada cláusula |
| Aceptar "a perpetuidad" | Pierdes ingresos futuros | Pide un plazo |
| Exclusividad sin pago | Pierdes otros trabajos | Cobra por ella |
| No pedir fechas de pago | Cobras tarde | Pide plazo y penalización |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué frase te da menos control sobre tu trabajo? a) Redes sociales en México por un año · b) Televisión abierta por seis meses · c) Todos los medios a perpetuidad
2. Te piden exclusividad. ¿Qué es razonable pedir? a) Nada, es normal · b) Un pago adicional y un plazo claro · c) Que no haya contrato escrito para poder negociar después
3. ¿Cuándo conviene que un abogado revise tu contrato? a) Nunca · b) Solo si ya firmaste y hay un problema con la productora · c) Cuando es por mucho dinero o cedes derechos
**Respuestas:** 1-c: pueden usarlo siempre y en cualquier medio. 2-b: la exclusividad te cuesta otros trabajos. 3-c: antes de firmar es cuando más ayuda.



#### Ponlo en práctica

Toma un contrato que hayas firmado. Anota su vigencia, territorio, medios, exclusividad y fecha de pago.
**Respuesta:** Por ejemplo: vigencia un año; territorio México; medios redes y TV abierta; exclusividad en bebidas por un año; pago a 60 días. La próxima vez pediré pago a 30 días.



#### A tu plan

Haz tu lista de revisión de contratos con las seis preguntas de esta lección y guárdala en tu celular.



### Para saber más

- **Ley Federal del Derecho de Autor** (Cámara de Diputados · español): https://www.diputados.gob.mx/LeyesBiblio/ — **Qué buscar:** la ley y los artículos sobre artistas intérpretes.
- **INDAUTOR** (Secretaría de Cultura · español): https://www.indautor.gob.mx — **Qué buscar:** "Registro de contratos" y la orientación sobre derechos de autor.

### Palabras clave

- *Vigencia:* tiempo que dura el uso pactado.
- *Territorio:* países donde pueden usar tu trabajo.
- *Exclusividad:* prohibición de trabajar con competidores.
- *A perpetuidad:* para siempre.

### Fuentes

Ley Federal del Derecho de Autor · INDAUTOR, consultados el 29 de septiembre de 2026.

---

## M3 U02. Derechos de imagen y voz: qué cedes y por cuánto tiempo

**Lo que lograrás:** Distinguir entre ceder, licenciar y autorizar el uso de tu imagen y tu voz, incluidos el doblaje y la inteligencia artificial.

**Para empezar:** Gael grabó la voz de un personaje para un comercial. Meses después escuchó "su voz" diciendo frases que nunca grabó: la habían creado con inteligencia artificial a partir de su grabación. Su contrato decía que la marca podía usar su voz "en cualquier forma". En esta lección aprenderás a proteger tu imagen y tu voz.

### Lo esencial (5 minutos)

#### Tu imagen y tu voz son tuyas

En México, para usar tu retrato o tu imagen se necesita tu consentimiento. Como intérprete, también tienes derechos sobre tus actuaciones.

Cuando firmas, decides qué permites, por cuánto tiempo y a cambio de qué.



#### Tres formas de dar permiso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cesión | Transfieres los derechos; tú ya no decides. | Pide que sea limitada y bien pagada. |
| Licencia | Das permiso de uso con límites de tiempo, medio y lugar. | La forma más sana. |
| Autorización puntual | Permiso para un uso específico. | Para algo concreto. |

#### Inteligencia artificial: pide una cláusula

Revisa si el contrato permite usar tu voz o tu imagen para "entrenar", "sintetizar" o "generar" contenido nuevo.

Pide que se prohíba, o que cualquier uso con inteligencia artificial requiera tu autorización por escrito y un pago aparte.



#### Un caso en un minuto

En su siguiente contrato de doblaje, Gael agregó una cláusula: "No se podrá usar la voz del artista para crear contenido con inteligencia artificial sin su autorización por escrito y un pago adicional".

La empresa aceptó. Gael guardó el contrato firmado en su carpeta.

> **Idea clave:** si no pones límites, el contrato puede permitir usos que nunca imaginaste.



#### Comprueba lo que entendiste

1. ¿Qué te conviene más: ceder tus derechos o dar una licencia limitada?
*Respuesta:* Una licencia limitada, con tiempo, medio y lugar definidos.

2. ¿Qué pides sobre inteligencia artificial?
*Respuesta:* Que se prohíba o que requiera tu autorización por escrito y un pago aparte.


#### Para recordar

- Tu imagen y tu voz son tuyas.
- Prefiere licencias limitadas.
- Pon límites al uso con inteligencia artificial.



### Profundiza (5 minutos más)

#### Palabras que abren la puerta a todo

"En cualquier forma", "por cualquier medio", "para cualquier fin" y "sin limitación alguna" permiten casi cualquier uso. Pide que se reemplacen por una lista cerrada.



#### Ejemplo de licencia limitada

| Punto | Ejemplo |
|---|---|
| Qué se usa | Mi imagen en las fotos de la campaña |
| Dónde | Redes sociales de la marca, en México |
| Cuánto tiempo | 12 meses desde la publicación |
| Qué no se permite | Alterar mi imagen o crear contenido nuevo con inteligencia artificial |
| Renovación | Con nuevo pago |



#### Doblaje y locución

En doblaje y locución, tu voz es tu herramienta principal. Revisa también si pueden reutilizar tus grabaciones en otros proyectos, idiomas o productos.

Tu sindicato o asociación puede orientarte sobre condiciones del gremio (M3 U04).



#### Si usan tu imagen sin permiso

Guarda pruebas: capturas con fecha, enlaces y el contrato. Escribe a la marca para pedir que retire el material. Si no responde, busca orientación en INDAUTOR o con un abogado.

> **Antes de actuar, verifica:** las reglas sobre imagen, voz e inteligencia artificial cambian rápido. Para tu caso, consulta a un abogado especialista y la orientación de INDAUTOR.



#### Casos


**Caso 1. La voz de Gael**

Gael escucha su voz en frases que nunca grabó. Su contrato decía "en cualquier forma".
- *¿Qué hace ahora y qué cambia para el futuro?* Guarda pruebas y busca orientación legal. En sus nuevos contratos pide una cláusula que limite el uso con inteligencia artificial.


**Caso 2. Las fotos de Valeria**

Una marca sigue usando fotos de Valeria un año después de terminar su licencia.
- *¿Qué hace?* Guarda capturas con fecha y pide por escrito que las retiren o que paguen la renovación.


**Caso 3. La cesión de Renata**

Le piden a Renata "cesión total" de su coreografía por 5,000.
- *¿Qué propone?* Una licencia limitada en tiempo y medios, y un pago mayor si quieren la cesión.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar "en cualquier forma" | Pueden usar tu imagen como quieran | Pide una lista cerrada |
| Ceder por poco dinero | Pierdes control para siempre | Prefiere licencias |
| No hablar de inteligencia artificial | Pueden clonar tu voz | Agrega una cláusula |
| No guardar pruebas | No puedes reclamar | Captura con fecha |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué forma de permiso te deja más control? a) Cesión total · b) Licencia limitada · c) Uso en cualquier forma
2. ¿Qué frase conviene cambiar? a) "Redes sociales en México por 12 meses" · b) "Por cualquier medio y para cualquier fin" · c) "Con pago por renovación"
3. Una marca usa tus fotos después de que venció la licencia. ¿Qué haces primero? a) Publicas un reclamo en redes y etiquetas a la marca para que lo vean · b) Guardas pruebas y pides por escrito que las retiren · c) No haces nada
**Respuestas:** 1-b: pones límites. 2-b: permite casi cualquier uso. 3-b: las pruebas y el escrito son la base.



#### Ponlo en práctica

Escribe una cláusula corta que limite el uso de tu voz o tu imagen con inteligencia artificial.
**Respuesta:** Por ejemplo: "La empresa no podrá usar la voz ni la imagen del artista para generar contenido nuevo con inteligencia artificial sin su autorización por escrito y un pago adicional".



#### A tu plan

Revisa tus contratos vigentes y marca los que dicen "en cualquier forma" o "cesión total".



### Para saber más

- **INDAUTOR** (Secretaría de Cultura · español): https://www.indautor.gob.mx — **Qué buscar:** orientación sobre derechos de intérpretes y cómo presentar una queja.
- **Ley Federal del Derecho de Autor** (Cámara de Diputados · español): https://www.diputados.gob.mx/LeyesBiblio/ — **Qué buscar:** los artículos sobre el retrato de una persona y los derechos de los artistas intérpretes.

### Palabras clave

- *Cesión:* transferir tus derechos a otra persona.
- *Licencia:* permiso de uso con límites.
- *Derechos de imagen:* control sobre el uso de tu retrato.

### Fuentes

Ley Federal del Derecho de Autor · INDAUTOR, consultados el 29 de septiembre de 2026.

---

## M3 U03. Mánagers y agencias: comisiones y cuentas claras

**Lo que lograrás:** Pactar por escrito la comisión, sobre qué monto se cobra, qué gastos se descuentan y cómo te rinden cuentas.

**Para empezar:** El mánager de Valeria cobra 20% sobre el pago con IVA incluido. Además le descuenta "gastos de representación" sin comprobantes y recibe los pagos de las marcas en su cuenta. Valeria nunca sabe cuánto cobró realmente por cada trabajo. En esta lección aprenderás a poner cuentas claras.

### Lo esencial (5 minutos)

#### Una buena representación vale su comisión

Un buen mánager o agencia te consigue trabajo, negocia mejor y te ahorra tiempo. Por eso cobra una comisión, que en el medio suele estar entre 10% y 20%.

El problema no es la comisión: es no saber sobre qué se cobra ni qué más te descuentan.



#### Lo que debe decir tu contrato de representación

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión | Porcentaje y sobre qué monto: tu honorario sin IVA. | Por escrito. |
| Gastos | Qué gastos te puede cobrar y con qué comprobante. | Solo los que autorices. |
| Pagos | Quién recibe el dinero y en cuántos días te lo entrega. | Con estado de cuenta. |
| Duración y salida | Cuánto dura y cómo terminarlo. | Evita plazos largos sin salida. |

#### Comisión sobre el precio sin IVA

Una campaña de 40,000 más IVA con comisión de 20%.
- Tu honorario sin IVA: **40,000**
- Comisión de 20%: **8,000**
- Lo que te queda antes de impuestos: **32,000**
Si la comisión se calcula sobre 46,400 (con IVA), pagarías 9,280: 1,280 de más.


#### Un caso en un minuto

Valeria habló con su mánager y firmaron un contrato nuevo: comisión de 20% sobre el honorario sin IVA, gastos solo con autorización y factura, y pagos directos a Valeria. El mánager le factura su comisión.

Ahora sabe exactamente cuánto cobra por cada campaña.

> **Idea clave:** si tu mánager recibe tu dinero, debe darte un estado de cuenta de cada pago.



#### Comprueba lo que entendiste

1. ¿Sobre qué monto conviene calcular la comisión?
*Respuesta:* Sobre tu honorario sin IVA.

2. ¿Qué pides si tu mánager recibe tus pagos?
*Respuesta:* Un estado de cuenta de cada pago y un plazo para entregarte tu parte.


#### Para recordar

- La comisión va sobre tu honorario sin IVA.
- Los gastos, solo autorizados y con comprobante.
- Pide que te paguen directo o con estado de cuenta.



### Profundiza (5 minutos más)

#### Pide factura de la comisión

Tu mánager debe facturarte su comisión. Esa factura te sirve para saber cuánto pagaste y, si estás en Actividad Empresarial, para deducirla (M2 U03).



#### Estado de cuenta de un proyecto

| Concepto | Monto |
|---|---|
| Honorario pactado (sin IVA) | 40,000 |
| Comisión 20% | −8,000 |
| Gastos autorizados con factura | −1,200 |
| Retenciones de la marca | Las que marque la factura |
| **Te entregan** | **30,800 más IVA, menos retenciones** |



#### Cómo terminar la relación

Revisa si el contrato tiene plazo, aviso previo y qué pasa con los trabajos que el mánager consiguió antes de terminar. Es normal que cobre comisión de esos trabajos por un tiempo. Que no sea para siempre.



#### Señales de alerta

- Te cobra por inscribirte o por "estar en su catálogo".
- No te deja ver los contratos que firma a tu nombre.
- Recibe tus pagos y tarda meses en entregártelos.
- No te da comprobantes de los gastos.

> **Antes de actuar, verifica:** si vas a firmar un contrato de representación por varios años o con exclusividad, pide que lo revise un abogado.



#### Casos


**Caso 1. La comisión de Valeria**

El mánager de Valeria calcula su 20% sobre 46,400, con IVA.
- *¿Qué pide Valeria?* Que la comisión se calcule sobre el honorario sin IVA y que quede por escrito.


**Caso 2. Los gastos de Gael**

A Gael le descuentan 3,000 de "gastos de representación" sin comprobante.
- *¿Qué hace?* Pide el comprobante y acuerda por escrito que solo se descuenten gastos autorizados con factura.


**Caso 3. Los pagos de Renata**

La agencia de Renata recibe sus pagos y tarda tres meses en entregárselos.
- *¿Qué negocia?* Un plazo máximo para entregarle su parte y un estado de cuenta de cada pago, o que le paguen directo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No firmar contrato de representación | No hay reglas claras | Ponlo por escrito |
| Comisión sobre el pago con IVA | Pagas de más | Sobre el honorario sin IVA |
| Gastos sin comprobante | No sabes qué pagas | Solo gastos autorizados |
| Contrato sin salida | Quedas atado años | Pide plazo y aviso de terminación |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Honorario de 30,000 más IVA y comisión de 15%. ¿Cuánto es la comisión? a) 5,220 · b) 3,000 · c) 4,500
2. ¿Qué es una señal de alerta en una agencia? a) Que te facture su comisión · b) Que te dé un estado de cuenta de cada pago que recibe por ti · c) Que te cobre por estar en su catálogo
3. ¿Qué gastos te puede descontar tu mánager? a) Los autorizados por ti y con comprobante · b) Los que él decida, porque es parte de su trabajo de representación · c) Ninguno, nunca
**Respuestas:** 1-c: 15% de 30,000, sin IVA. 2-c: cobrar por inscribirte es alerta. 3-a: solo los autorizados.



#### Ponlo en práctica

Revisa tu último pago a través de tu mánager. ¿Sobre qué monto te cobró la comisión y qué gastos te descontó?
**Respuesta:** Por ejemplo: honorario 25,000; comisión 20% sobre 29,000 con IVA = 5,800. Debió ser 5,000. Pediré que se corrija y que quede por escrito.



#### A tu plan

Escribe los cuatro puntos que debe tener tu contrato de representación y compáralos con el que tienes.



### Para saber más

- **Profeco** (Gobierno de México · español): https://www.gob.mx/profeco — **Qué buscar:** orientación si una agencia te vende servicios que no cumple.
- **Verifica facturas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** "Verificación de comprobantes fiscales" para revisar las facturas de tu mánager.

### Palabras clave

- *Comisión:* porcentaje que cobra tu representante.
- *Gastos de representación:* gastos que tu mánager hace por ti.
- *Estado de cuenta:* detalle de lo que cobró y te entrega.

### Fuentes

Profeco · SAT · Prácticas del medio artístico.

---

## M3 U04. ANDA, ANDI y las organizaciones del medio: ¿quién hace qué?

**Lo que lograrás:** Saber a qué organización mexicana acudir según lo que necesitas: tu actividad laboral, tus regalías como intérprete, como autor, como músico o como productor.

**Para empezar:** Gael es agremiado de la ANDA desde hace años. Una telenovela en la que actuó se retransmite en Sudamérica y él cree que sus regalías le llegan por la ANDA. Nunca le ha llegado nada. En esta lección conocerás qué hace cada organización del medio en México.

### Lo esencial (5 minutos)

#### Sindicato y sociedades de gestión no son lo mismo

Un **sindicato** defiende tus condiciones de trabajo. Una **sociedad de gestión colectiva** cobra y reparte regalías por el uso de obras e interpretaciones.

Puedes pertenecer a los dos. Cada uno hace cosas distintas.



#### Las organizaciones mexicanas del medio

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ANDA | Sindicato de actrices y actores de cine, teatro, radio, TV, doblaje y más. | Tu actividad laboral. |
| ANDI | Sociedad de gestión de intérpretes. | Tus regalías por retransmisiones. |
| SACM | Sociedad de autores y compositores de música. | Regalías de tus canciones. |
| EJE | Sociedad de músicos ejecutantes y cantantes de agrupaciones. | Regalías como músico. |
| SOMEXFON | Sociedad de productores de fonogramas. | Si produces tus grabaciones. |

#### ¿A cuál acudes?

- ¿Te pagaron menos del tabulador o no respetaron tu jornada en una producción con la ANDA? **ANDA.**
- ¿Retransmiten una serie, telenovela o película donde actuaste? **ANDI.**
- ¿Compusiste una canción? **SACM.**
- ¿Tocaste o cantaste en una grabación de un grupo? **EJE.**
- ¿Tú produjiste y eres dueño de la grabación? **SOMEXFON.**



#### Un caso en un minuto

Gael se afilió a la ANDI y registró las producciones en las que actuó. Meses después recibió su primera liquidación de regalías por la telenovela que se retransmite en Sudamérica.

Sigue en la ANDA para sus condiciones de trabajo.

> **Idea clave:** la ANDA regula tu actividad laboral y la ANDI administra tus regalías como intérprete.



#### Comprueba lo que entendiste

1. ¿La ANDA cobra tus regalías por retransmisiones?
*Respuesta:* No. Eso lo hace la ANDI.

2. Compusiste una canción. ¿A qué sociedad acudes?
*Respuesta:* A la SACM.


#### Para recordar

- ANDA: tu actividad laboral.
- ANDI: tus regalías como intérprete.
- SACM, EJE y SOMEXFON: música, según tu papel.



### Profundiza (5 minutos más)

#### Qué hace cada una

| Organización | Qué es | Te sirve para |
|---|---|---|
| ANDA (Asociación Nacional de Actores) | Sindicato | Agremiación, contratos, tabuladores, condiciones de trabajo y servicios para sus agremiados |
| ANDI (Asociación Nacional de Intérpretes) | Sociedad de gestión colectiva | Regalías de intérpretes por retransmisiones en TV, cine, plataformas y otros espacios, en México y el extranjero |
| SACM (Sociedad de Autores y Compositores de México) | Sociedad de gestión colectiva | Regalías de autores y compositores de música |
| EJE (Ejecutantes) | Sociedad de gestión colectiva | Regalías de músicos ejecutantes y cantantes de agrupaciones |
| SOMEXFON | Sociedad de gestión colectiva | Derechos de productores de fonogramas |

> **Dato vigente:** sociedades de gestión colectiva autorizadas por INDAUTOR y funciones de ANDA y ANDI. Consultado el 29 de septiembre de 2026 a través de INDAUTOR y los sitios oficiales de cada organización.



#### Servicios para agremiados de la ANDA

La ANDA tiene clínicas con consulta de medicina general para sus agremiados, con una cuota de recuperación, y el servicio médico completo aplica a miembros activos al corriente en sus cuotas y a miembros honorarios. En años recientes suspendió servicios a beneficiarios por problemas económicos.

En septiembre de 2026, el IMSS y la ANDA firmaron un convenio para que trabajadores independientes de actuación, doblaje, canto, danza, música, conducción y modelaje se incorporen voluntariamente al Seguro Social, con sus beneficiarios (M10 U02).

> **Dato vigente:** servicios médicos de la ANDA (cuota de consulta de 250 pesos para agremiados, según medios) y convenio IMSS-ANDA publicado el 20 de septiembre de 2026. Consultado el 29 de septiembre de 2026 a través de la ANDA, el IMSS y medios informativos. Confirma requisitos y costos directamente con la ANDA.



#### Todas se pueden verificar

Las sociedades de gestión colectiva están autorizadas por INDAUTOR. Si alguien te ofrece "cobrar tus regalías" y no es una de ellas ni un representante con poder legal, desconfía (M3 U05).



#### Si haces varias cosas

Muchas personas del medio actúan, cantan y componen. En ese caso puedes pertenecer a varias: ANDI por tus actuaciones, SACM por tus canciones y EJE si tocas en un grupo.



#### Casos


**Caso 1. Las regalías de Gael**

Gael es agremiado de la ANDA y espera sus regalías de una telenovela.
- *¿Qué hace?* Se afilia a la ANDI y registra sus actuaciones. La ANDA no cobra regalías.


**Caso 2. Las canciones de Valeria**

Valeria compuso tres canciones que suenan en la radio.
- *¿Dónde cobra sus regalías como autora?* En la SACM, registrando sus obras.


**Caso 3. La grabación de Toño**

Toño tocó el bajo en el disco de una banda y también produjo su propio EP.
- *¿A qué sociedades acude?* A la EJE como músico ejecutante y a SOMEXFON como productor de su grabación.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que la ANDA cobra regalías | Nunca las recibes | Afíliate a la ANDI |
| No registrar tus obras o actuaciones | No te pueden pagar | Registra todo |
| Pertenecer solo a una si haces varias cosas | Pierdes regalías | Afíliate según cada papel |
| Confiar en gestores no autorizados | Te cobran por nada | Verifica en INDAUTOR |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién cobra tus regalías como actor por retransmisiones? a) ANDA · b) ANDI · c) SAT
2. ¿Qué es la ANDA? a) Una sociedad de autores de música · b) Un banco del gremio · c) Un sindicato de actores
3. Tocaste la batería en la grabación de una banda. ¿A qué sociedad acudes? a) EJE · b) SACM · c) ANDA
**Respuestas:** 1-b: la ANDI gestiona las regalías de intérpretes. 2-c: regula la actividad laboral. 3-a: la EJE representa a músicos ejecutantes.



#### Ponlo en práctica

Escribe qué haces en el medio (actúas, cantas, compones, tocas, produces) y a qué organización corresponde cada actividad.
**Respuesta:** Por ejemplo: actúo en TV (ANDA y ANDI), compongo canciones (SACM) y toco en una banda (EJE).



#### A tu plan

Revisa si estás afiliado a todas las organizaciones que te corresponden y anota qué trámite te falta.



### Para saber más

- **ANDA** (Asociación Nacional de Actores · español): https://laanda.org.mx — **Qué buscar:** agremiación y servicios para actores.
- **ANDI** (Asociación Nacional de Intérpretes · español): https://andi.org.mx — **Qué buscar:** afiliación y pago de regalías.
- **Sociedades de gestión colectiva** (INDAUTOR · español): https://www.indautor.gob.mx/sociedades-de-gestion-colectiva.php — **Qué buscar:** la lista de sociedades autorizadas.
- **SACM, EJE y SOMEXFON** (sitios oficiales · español): https://www.sacm.org.mx — **Qué buscar:** registro de obras; para EJE visita ejecutantes.com y para SOMEXFON somexfon.com.

### Palabras clave

- *Sindicato:* organización que defiende tus condiciones de trabajo.
- *Sociedad de gestión colectiva:* cobra y reparte regalías.
- *Regalías:* pagos por el uso de tus obras o interpretaciones.

### Fuentes

INDAUTOR, sociedades de gestión colectiva · ANDA, "Regalías y su relación con la ANDA" · ANDI · EJE · SOMEXFON, consultados el 29 de septiembre de 2026.

---

## M3 U05. Cómo cobro mis regalías y reviso mis pagos

**Lo que lograrás:** Afiliarte a la sociedad que te corresponde, registrar tus obras o interpretaciones, revisar tus liquidaciones y declarar esos ingresos.

**Para empezar:** A Renata le escribe un "gestor" que promete recuperar regalías atrasadas de un video musical en el que bailó, a cambio de 30% y copia de su INE. Ella no sabe si le toca algo ni cómo se cobra. En esta lección aprenderás el camino oficial.

### Lo esencial (5 minutos)

#### El camino para cobrar

1. **Identifica tu papel:** intérprete, autor, músico o productor (M3 U04).
2. **Afíliate** a la sociedad de gestión colectiva que corresponde.
3. **Registra** tus obras o las producciones donde participaste, con los datos que te pidan.
4. **Revisa tus liquidaciones:** qué se pagó, por qué uso y de qué periodo.



#### ¿Me toca algo?

No todo trabajo genera regalías. Depende de tu papel, del tipo de uso (retransmisión, comunicación pública) y de lo que diga tu contrato.

La sociedad que te corresponde puede decirte si tienes pagos pendientes. Pregunta directamente ahí.



#### Desconfía de gestores que cobran por adelantado

Las sociedades de gestión colectiva son la vía oficial. Si alguien te pide dinero, un porcentaje alto o tus documentos para "recuperar regalías", verifica primero con la sociedad.



#### Un caso en un minuto

Renata no le mandó su INE al gestor. Llamó a la ANDI, le explicaron que como bailarina en un video su caso dependía de su participación y de su contrato, y le dijeron qué documentos necesitaba para revisarlo.

No pagó nada a nadie.

> **Idea clave:** pregunta primero en la sociedad de gestión colectiva. No necesitas intermediarios que te cobren por adelantado.



#### Comprueba lo que entendiste

1. ¿A quién preguntas si tienes regalías pendientes?
*Respuesta:* A la sociedad de gestión colectiva que te corresponde.

2. Un gestor te pide 30% y tu INE. ¿Qué haces?
*Respuesta:* Verificas con la sociedad antes de dar dinero o documentos.


#### Para recordar

- Afíliate y registra tu trabajo.
- Revisa tus liquidaciones.
- Nada de gestores que cobran por adelantado.



### Profundiza (5 minutos más)

#### Tu liquidación

Una liquidación de regalías debe decir qué obra o producción generó el pago, qué uso se hizo, de qué periodo es y cuánto se descontó por administración.

Guarda todas. Te sirven para tus impuestos y para detectar errores.



#### Regalías del extranjero

Si tu trabajo se transmite en otros países, las sociedades mexicanas suelen tener acuerdos con sociedades de esos países para cobrar y enviar tus regalías. Pregunta en la tuya qué acuerdos tiene.



#### Las regalías también se declaran

Las regalías son ingresos y se declaran. Para **autores** (por ejemplo, compositores) hay dos beneficios con reglas:

- **ISR:** exención de hasta 20 UMA anuales por ciertos ingresos, como la reproducción en serie de grabaciones de sus obras musicales o la publicación de obras escritas, si se cumplen los requisitos (artículo 93, fracción XXIX, de la LISR).
- **IVA:** exención cuando el autor transmite temporalmente sus derechos patrimoniales u otorga licencias sobre obras inscritas en el Registro Público del Derecho de Autor (artículo 15, fracción XVI, de la Ley del IVA).

Para **intérpretes** (actores, músicos ejecutantes), estos beneficios no aplican de la misma forma. Lleva tus liquidaciones a tu contador.

> **Dato vigente:** artículo 93, fracción XXIX, de la LISR y artículo 15, fracción XVI, de la Ley del IVA. Consultado el 29 de septiembre de 2026 a través del SAT y publicaciones fiscales especializadas. El tratamiento de las regalías de intérpretes confírmalo con tu contador.



#### Lo que guardas

| Documento | Para qué |
|---|---|
| Constancia de afiliación | Probar que eres socio |
| Registro de obras o producciones | Que te puedan pagar |
| Liquidaciones | Revisar pagos e impuestos |
| Contratos de cada trabajo | Saber qué derechos conservas |



#### Casos


**Caso 1. El gestor de Renata**

Un gestor le promete a Renata recuperar regalías por 30% y copia de su INE.
- *¿Qué hace?* No le manda nada y pregunta directamente en la sociedad que le corresponde.


**Caso 2. La liquidación de Gael**

A Gael le llega una liquidación de la ANDI que no dice de qué producción es un pago.
- *¿Qué hace?* Pide a la ANDI el detalle de la obra, el uso y el periodo.


**Caso 3. Las regalías de Valeria**

Valeria recibió 12,000 de regalías como autora y no sabe si declararlas.
- *¿Qué hace?* Las declara: lleva la liquidación a su contador para saber cómo según su régimen.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No afiliarte | Nadie cobra por ti | Afíliate |
| Dar tu INE a gestores | Riesgo de robo de identidad | Verifica con la sociedad |
| No guardar liquidaciones | No detectas errores | Guárdalas |
| No declarar regalías | Problemas con el SAT | Llévalas a tu contador |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es lo primero para cobrar regalías? a) Pagar a un gestor · b) Afiliarte a la sociedad que te corresponde · c) Subir tu trabajo a redes para que las regalías lleguen solas
2. ¿Qué debe decir una liquidación? a) Solo el monto · b) Nada: basta con el depósito en tu cuenta · c) Obra, uso, periodo y descuentos
3. ¿Las regalías se declaran? a) No · b) Solo las del extranjero · c) Sí
**Respuestas:** 1-b: la sociedad cobra por ti. 2-c: así detectas errores. 3-c: son ingresos.



#### Ponlo en práctica

Haz tu lista de obras o producciones que podrían generar regalías y escribe a qué sociedad corresponde cada una.
**Respuesta:** Por ejemplo: telenovela 2021 (ANDI), serie 2023 (ANDI), dos canciones propias (SACM).



#### A tu plan

Llama o escribe a tu sociedad de gestión colectiva y pregunta si tienes pagos pendientes.



### Para saber más

- **ANDI: afiliación** (ANDI · español): https://andi.org.mx — **Qué buscar:** requisitos para afiliarte y registrar tus actuaciones.
- **SACM: registro de obras** (SACM · español): https://www.sacm.org.mx — **Qué buscar:** cómo registrar tus canciones.
- **Sociedades autorizadas** (INDAUTOR · español): https://www.indautor.gob.mx/sociedades-de-gestion-colectiva.php — **Qué buscar:** confirma que la sociedad está autorizada.

### Palabras clave

- *Liquidación:* detalle de las regalías que te pagan.
- *Afiliación:* inscribirte como socio de una sociedad.
- *Comunicación pública:* uso de una obra en radio, TV o lugares públicos.

### Fuentes

INDAUTOR · ANDI · SACM · LISR y Ley del IVA, consultados el 29 de septiembre de 2026.

---

## M3 U06. Cuando la productora no paga

**Lo que lograrás:** Documentar, reclamar por escrito, conocer las penalizaciones pactadas y saber a quién acudir si no te pagan.

**Para empezar:** Toño grabó para una serie hace cinco meses. La productora le dice "la próxima semana" cada vez que pregunta. No tiene contrato firmado, solo mensajes de WhatsApp. En esta lección aprenderás qué hacer para cobrar y cómo prevenirlo.

### Lo esencial (5 minutos)

#### Si no te pagan

1. **Junta pruebas:** contrato, factura, mensajes, correos, llamados, fotos del set.
2. **Reclama por escrito,** con monto, fecha pactada y un plazo para pagar.
3. **Revisa el contrato:** ¿dice algo sobre penalización o intereses por atraso?
4. **Pide orientación:** a tu sindicato si aplica, a PROFEDET si hay relación laboral o a un abogado.



#### ¿A quién acudes?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ANDA | Si eres agremiado y la producción tiene contrato con el sindicato. | Pregunta en tu sindicato. |
| PROFEDET | Orientación gratuita si hay relación laboral. | Defensa del trabajo. |
| Abogado | Si es un contrato de servicios y no pagan. | Para cobrar por la vía legal. |

#### Los mensajes también son prueba

Aunque no tengas contrato firmado, los mensajes, correos y llamados que muestran que te contrataron y cuánto te iban a pagar sirven como prueba. Guárdalos con fecha.



#### Un caso en un minuto

Toño juntó sus mensajes y fotos del set. Envió un correo formal con el monto, la fecha pactada y un plazo de diez días para pagar.

La productora le pagó la mitad y firmó un compromiso por el resto. Desde entonces, Toño no graba sin un acuerdo por escrito.

> **Idea clave:** reclama por escrito y con plazo. Un "la próxima semana" no es un compromiso.



#### Comprueba lo que entendiste

1. No tienes contrato firmado. ¿Tus mensajes sirven?
*Respuesta:* Sí. Muestran el acuerdo y el monto.

2. ¿Cómo reclamas?
*Respuesta:* Por escrito, con monto, fecha pactada y un plazo para pagar.


#### Para recordar

- Guarda todo con fecha.
- Reclama por escrito con plazo.
- Busca orientación según tu caso.



### Profundiza (5 minutos más)

#### Un correo de reclamo

Incluye: tu nombre, el proyecto, las fechas en que trabajaste, el monto, la fecha en que debían pagar, tu factura si la entregaste y un plazo para pagar (por ejemplo, 10 días hábiles).

Escribe con respeto. Tu objetivo es cobrar, no pelear.



#### Relación laboral o contrato de servicios

Si te dan órdenes, horario y te pagan de forma periódica, puede haber relación laboral, aunque te digan que es "por honorarios". En ese caso, PROFEDET te orienta gratis.

Si es un contrato de servicios, cobras por la vía civil o mercantil con un abogado.

> **Antes de actuar, verifica:** si hay relación laboral depende de los hechos. Pide orientación gratuita en PROFEDET antes de decidir.



#### Prevenir es más fácil

- Pide contrato o, al menos, un correo con monto, fechas y forma de pago antes de trabajar.
- Pide anticipo en proyectos largos o con productoras nuevas.
- Investiga a la productora: pregunta a colegas y revisa si ha tenido problemas de pago.



#### Mientras cobras

No gastes ese dinero antes de que llegue (M1 U06). Usa tu fondo de sequía y avisa a tus acreedores si te vas a atrasar.



#### Casos


**Caso 1. La serie de Toño**

Toño lleva cinco meses sin cobrar y solo tiene mensajes.
- *¿Qué hace?* Junta sus pruebas y envía un reclamo por escrito con monto, fecha pactada y plazo.


**Caso 2. El horario de Gael**

Gael trabaja cada día en una productora con horario fijo, pero le pagan "por honorarios" y tres meses tarde.
- *¿A quién acude para orientarse?* A PROFEDET, porque podría haber relación laboral.


**Caso 3. La productora nueva de Valeria**

Una productora nueva le ofrece a Valeria un proyecto de tres meses sin contrato.
- *¿Qué pide?* Un acuerdo por escrito con monto y fechas, y un anticipo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Trabajar sin nada por escrito | Difícil probar el acuerdo | Pide al menos un correo |
| Reclamar solo por teléfono | No queda registro | Reclama por escrito |
| Borrar mensajes | Pierdes pruebas | Guárdalos con fecha |
| Gastar el dinero antes de cobrarlo | Te endeudas | Usa tu fondo de sequía |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué sirve como prueba si no hay contrato? a) Nada · b) Mensajes y correos con fecha · c) Solo la palabra de un testigo que estuvo en el set
2. ¿Qué institución orienta gratis si hay relación laboral? a) PROFEDET · b) CONDUSEF · c) Profeco
3. ¿Qué pides a una productora nueva en un proyecto largo? a) Nada, para no parecer desconfiado · b) Acuerdo por escrito y anticipo · c) Que te pague en efectivo sin factura
**Respuestas:** 1-b: muestran el acuerdo. 2-a: defiende a las personas trabajadoras. 3-b: reduce el riesgo de no cobrar.



#### Ponlo en práctica

Escribe el correo de reclamo para un pago atrasado, con todos los datos.
**Respuesta:** Por ejemplo: "Hola, soy Toño. Grabé para la serie X del 3 al 7 de mayo por 18,000, con pago al 30 de junio. Envié mi factura el 10 de mayo. Les pido realizar el pago a más tardar el 15 de octubre. Gracias."



#### A tu plan

Crea una carpeta por proyecto donde guardes contrato, factura, mensajes y llamados.



### Para saber más

- **PROFEDET** (Gobierno de México · español): https://www.gob.mx/profedet — **Qué buscar:** "Asesoría" para saber si tu caso es laboral y cómo te pueden ayudar.
- **ANDA** (Asociación Nacional de Actores · español): https://laanda.org.mx — **Qué buscar:** cómo presentar una queja como agremiado.

### Palabras clave

- *PROFEDET:* defensoría gratuita de las personas trabajadoras.
- *Relación laboral:* trabajo con órdenes, horario y pago periódico.
- *Anticipo:* parte del pago antes de empezar.

### Fuentes

PROFEDET · ANDA · Ley Federal del Trabajo, consultados el 29 de septiembre de 2026.

---


---

# Módulo 4. Conoce el sistema financiero mexicano

## M4 U01. ¿Quién es quién en el sistema financiero?

**Lo que lograrás:** Distinguir a las autoridades que regulan y protegen de las instituciones que te venden productos.

**Para empezar:** Renata recibió una llamada de "CONDUSEF" ofreciéndole un préstamo con descuento. Casi da sus datos. Después supo que CONDUSEF no presta dinero: la llamada era un fraude. En esta lección conocerás quién hace qué en el sistema financiero mexicano.

### Lo esencial (5 minutos)

#### Dos grupos: quienes cuidan y quienes venden

En el **sistema financiero** hay autoridades que ponen reglas y te protegen, e instituciones que te ofrecen cuentas, créditos, seguros e inversiones.

Las autoridades no te venden nada ni te ofrecen préstamos por teléfono.



#### Las autoridades que debes conocer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Banco de México | Cuida el valor del peso y el sistema de pagos. | Publica comparativos de tarjetas. |
| CNBV | Autoriza y supervisa a bancos y otras entidades. | Aquí verificas si es banco. |
| CONDUSEF | Te orienta y atiende tus reclamaciones. | Defiende a los usuarios. |
| IPAB | Protege tus depósitos en bancos. | Hasta 400,000 UDIS. |

#### Otras autoridades según el producto

- **CNSF:** supervisa aseguradoras.
- **CONSAR:** supervisa las AFORE.
- **SHCP:** define las políticas del sistema.
- **Profeco:** atiende casas de empeño y créditos que dan tiendas con recursos propios.



#### Un caso en un minuto

Renata colgó y buscó el sitio oficial de CONDUSEF. Leyó que CONDUSEF no ofrece préstamos y que existen fraudes que usan su nombre.

Reportó el número en el portal de fraudes de CONDUSEF.

> **Idea clave:** ninguna autoridad te llama para venderte un crédito.



#### Comprueba lo que entendiste

1. ¿CONDUSEF presta dinero?
*Respuesta:* No. Orienta y atiende reclamaciones de usuarios.

2. ¿Dónde verificas si una institución es banco?
*Respuesta:* En la CNBV.


#### Para recordar

- Las autoridades cuidan; las instituciones venden.
- CONDUSEF defiende; la CNBV supervisa.
- Ninguna autoridad te llama para venderte.



### Profundiza (5 minutos más)

#### Qué hace cada autoridad por ti

| Autoridad | Te sirve para |
|---|---|
| Banco de México | Comparar tarjetas, conocer el CAT y la portabilidad de nómina |
| CNBV | Confirmar que una entidad está autorizada; ver advertencias sobre entidades no autorizadas |
| CONDUSEF | Reclamar, verificar instituciones (SIPRES, Buró de Entidades Financieras), revisar contratos (RECA) |
| IPAB | Saber qué depósitos están protegidos |
| CNSF | Verificar aseguradoras |
| CONSAR | Información sobre AFORE |
| Profeco | Casas de empeño y crédito de tiendas con recursos propios |



#### Cómo reconocer una llamada falsa

Una llamada "de CONDUSEF", "del SAT" o "del Banco de México" que te ofrece un préstamo, te pide datos o te pide depositar es un fraude.

Cuelga y busca tú el teléfono oficial en el sitio de la institución (M9 U03).



#### Los sitios oficiales

Los sitios del gobierno federal terminan en **gob.mx** o tienen dominios oficiales conocidos (como banxico.org.mx o condusef.gob.mx). Escribe tú la dirección, no uses enlaces de mensajes.

> **Dato vigente:** funciones de Banco de México, CNBV, CONDUSEF, IPAB, CNSF, CONSAR y Profeco. Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales.



#### Casos


**Caso 1. La llamada de Renata**

Una persona que dice ser de CONDUSEF le ofrece a Renata un préstamo con descuento.
- *¿Qué hace?* Cuelga: CONDUSEF no presta. Reporta el número a CONDUSEF.


**Caso 2. El banco de Gael**

Gael quiere saber si un banco digital está autorizado.
- *¿Dónde revisa?* En el padrón de entidades supervisadas de la CNBV.


**Caso 3. La casa de empeño de Toño**

Toño tuvo un problema con una casa de empeño.
- *¿A quién acude?* A Profeco, que atiende a las casas de empeño.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que una autoridad te ofrece créditos | Caes en fraude | Cuelga y verifica |
| Usar enlaces de mensajes | Te llevan a páginas falsas | Escribe tú la dirección |
| No saber a quién reclamar | Te quedas sin ayuda | Identifica la autoridad según el producto |
| Confundir CONDUSEF con la CNBV | Pierdes tiempo | CONDUSEF reclama; la CNBV autoriza |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué autoridad protege tus depósitos en bancos? a) Profeco · b) IPAB · c) CONSAR
2. ¿A quién presentas una reclamación contra tu banco si no te resuelven? a) CONDUSEF · b) SAT · c) El IMSS, porque es una institución pública
3. Te llaman "del Banco de México" para ofrecerte un crédito. ¿Qué es? a) Un fraude · b) Una oferta oficial · c) Un programa nuevo
**Respuestas:** 1-b: el IPAB protege depósitos bancarios. 2-a: CONDUSEF atiende reclamaciones. 3-a: Banxico no presta a personas.



#### Ponlo en práctica

Escribe qué autoridad te sirve para cada producto que tienes: cuenta, tarjeta, seguro, AFORE.
**Respuesta:** Por ejemplo: cuenta y tarjeta (CNBV y CONDUSEF), seguro de auto (CNSF y CONDUSEF), AFORE (CONSAR).



#### A tu plan

Guarda en tu celular los sitios oficiales de CONDUSEF, CNBV, Banco de México e IPAB.



### Para saber más

- **CONDUSEF** (Gobierno de México · español): https://www.condusef.gob.mx — **Qué buscar:** "Portal de Fraudes Financieros" y cómo reportar un número.
- **CNBV** (Gobierno de México · español): https://www.gob.mx/cnbv — **Qué buscar:** "Padrón de entidades supervisadas" y "Advertencias".
- **Banco de México** (Banxico · español): https://www.banxico.org.mx — **Qué buscar:** "Educación financiera" y los comparativos de tarjetas.

### Palabras clave

- *Sistema financiero:* autoridades e instituciones que manejan dinero, crédito y seguros.
- *CNBV:* autoriza y supervisa a bancos y otras entidades.
- *CONDUSEF:* orienta y defiende a los usuarios.

### Fuentes

Sitios oficiales de Banco de México, CNBV, CONDUSEF, IPAB, CNSF, CONSAR y Profeco, consultados el 29 de septiembre de 2026.

---

## M4 U02. Bancos, bancos digitales y otras entidades: ¿cuál es cuál?

**Lo que lograrás:** Diferenciar un banco, protegido por el IPAB, de otras entidades que también prestan o captan dinero, para saber qué estás contratando.

**Para empezar:** Renata dice que tiene "cinco tarjetas de banco". Al revisar los contratos descubre que solo dos son de bancos: las otras son de una tienda departamental, una SOFOM y una app. Cada una tiene reglas, costos y protecciones distintas. En esta lección aprenderás a distinguirlas.

### Lo esencial (5 minutos)

#### No todo el que presta es banco

Muchas empresas prestan dinero o guardan tu dinero, pero no todas son bancos. Lo que diga su publicidad no importa: importa su nombre legal y quién la autorizó.

Saberlo te dice dónde reclamar y si tu dinero está protegido.



#### Quién es quién

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Banco | Capta depósitos y presta. Autorizado por la CNBV. | Depósitos protegidos por el IPAB. |
| Banco digital | Es banco, pero sin sucursales. | Verifica que sea banco en la CNBV. |
| SOFOM | Solo presta; no capta ahorro. | No hay depósitos que proteger. |
| Tienda departamental | Da crédito propio o a través de un banco o SOFOM. | Revisa quién es el acreedor. |
| App o fintech | Puede ser banco, fintech autorizada, SOFOM o nada. | Verifica siempre. |

#### Hay más tipos de entidades

También existen SOFIPO, cooperativas de ahorro y préstamo (SOCAP), casas de empeño e instituciones de tecnología financiera. Funcionan con reglas y protecciones distintas a las de un banco.

En este curso las explicamos para que sepas qué contratas, pero no las recomendamos para tu ahorro.



#### Un caso en un minuto

Renata revisó el nombre legal en cada contrato. Anotó en una tabla: "Banco", "Banco", "Tienda", "SOFOM", "App sin registro".

La app no aparecía en ningún registro oficial. Decidió pagarla y no volver a usarla (M9 U06).

> **Idea clave:** busca el nombre legal en tu contrato, no el nombre comercial.



#### Comprueba lo que entendiste

1. ¿Una SOFOM puede guardar tu ahorro?
*Respuesta:* No. Solo presta dinero.

2. ¿Qué te dice si una app es banco?
*Respuesta:* Su nombre legal y su registro en la CNBV.


#### Para recordar

- No todo el que presta es banco.
- Busca el nombre legal en tu contrato.
- El IPAB protege solo depósitos en bancos.



### Profundiza (5 minutos más)

#### Entidades y protección

| Entidad | ¿Capta tu ahorro? | Protección de depósitos | ¿Dónde reclamas? |
|---|---|---|---|
| Banco (incluido el digital) | Sí | IPAB | CONDUSEF |
| SOFOM | No | No aplica | CONDUSEF |
| SOFIPO | Sí | Fondo de protección propio, con reglas distintas | CONDUSEF |
| Cooperativa (SOCAP) | Sí | Fondo de protección propio, con reglas distintas | CONDUSEF |
| Institución de fondos de pago electrónico | Guarda saldo para pagos | No es depósito bancario | CONDUSEF |
| Tienda con crédito propio | No | No aplica | Profeco |
| Casa de empeño | No | No aplica | Profeco |

> **Dato vigente:** tipos de entidades y protección de depósitos. Consultado el 29 de septiembre de 2026 a través de la CNBV, el IPAB y CONDUSEF.



#### Dónde está el nombre legal

En el contrato, la carátula, el estado de cuenta o el aviso de privacidad. Busca frases como "Institución de Banca Múltiple", "Sociedad Financiera de Objeto Múltiple" o "Institución de Fondos de Pago Electrónico".



#### Los bancos digitales

Un banco digital es un banco igual que uno con sucursales, si está autorizado como tal. Algunas empresas conocidas empezaron como otro tipo de entidad y después obtuvieron licencia de banco.

> **Dato vigente:** al 29 de septiembre de 2026, Nu México y Revolut cuentan con autorización de la CNBV como bancos, según la CNBV y los comunicados de cada institución. Antes de decidir, confírmalo en el padrón de la CNBV y en el sitio oficial de la institución.



#### Apps sin registro

Si una app de préstamos no aparece en la CNBV ni en el SIPRES de CONDUSEF, no está autorizada. Muchas cobran intereses abusivos y extorsionan (M9 U06).



#### Casos


**Caso 1. Las cinco tarjetas de Renata**

Renata cree que sus cinco tarjetas son de bancos.
- *¿Qué revisa?* El nombre legal en cada contrato para saber qué entidad es y dónde reclamar.


**Caso 2. El ahorro de Gael**

Una SOFOM le ofrece a Gael "guardar su dinero" con buen rendimiento.
- *¿Qué hace?* Desconfía: una SOFOM no puede captar ahorro. Guarda su dinero en un banco o en Cetes.


**Caso 3. La tarjeta de la tienda de Valeria**

Valeria tiene una tarjeta de una tienda departamental y no sabe quién es el acreedor.
- *¿Dónde lo busca?* En su contrato o estado de cuenta: puede ser la tienda, un banco o una SOFOM.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guiarte por el nombre comercial | No sabes qué contratas | Busca el nombre legal |
| Creer que todo está protegido por el IPAB | Arriesgas tu ahorro | Solo depósitos en bancos |
| Dar ahorro a quien solo puede prestar | Riesgo de fraude | Verifica qué entidad es |
| Usar apps sin registro | Abusos y extorsión | Verifica en CNBV y SIPRES |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué entidad solo presta y no puede captar ahorro? a) Banco · b) SOFOM · c) Banco digital
2. ¿Qué protege el IPAB? a) Cualquier app · b) Créditos de tienda · c) Depósitos en bancos
3. ¿Dónde encuentras el nombre legal de tu tarjeta? a) En la publicidad · b) En el contrato o estado de cuenta · c) En las redes sociales de la marca de la tarjeta
**Respuestas:** 1-b: la SOFOM solo otorga crédito. 2-c: solo depósitos bancarios. 3-b: ahí aparece la entidad responsable.



#### Ponlo en práctica

Haz una tabla con tus tarjetas, créditos y cuentas: nombre comercial, nombre legal y tipo de entidad.
**Respuesta:** Por ejemplo: "Tarjeta Oro" — Banco X, Institución de Banca Múltiple — banco. "Crédito Tienda" — Y, SOFOM — SOFOM. "App Z" — no aparece en registros.



#### A tu plan

Revisa el nombre legal de cada producto financiero que tienes y marca cuáles son bancos.



### Para saber más

- **Padrón de entidades supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** el nombre legal de cada institución.
- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "SIPRES" para ver si una empresa está registrada como prestador de servicios financieros.

### Palabras clave

- *Banco:* capta depósitos y presta; autorizado por la CNBV.
- *SOFOM:* entidad que solo otorga crédito.
- *Nombre legal:* el nombre oficial de la entidad, distinto del comercial.

### Fuentes

CNBV · IPAB · CONDUSEF · Comunicados de Nu México y Revolut, consultados el 29 de septiembre de 2026.

---

## M4 U03. ¿Cómo verifico una institución antes de contratar?

**Lo que lograrás:** Usar el SIPRES, el Buró de Entidades Financieras y el padrón de la CNBV para verificar a cualquier institución.

**Para empezar:** A Toño le ofrecen un crédito para su estudio con aprobación "en 24 horas y sin Buró". La empresa tiene una página bonita y muchas reseñas. Antes de firmar, quiere saber si es real. En esta lección aprenderás a verificar en diez minutos.

### Lo esencial (5 minutos)

#### Tres consultas antes de contratar

1. **SIPRES (CONDUSEF):** ¿está registrada como prestador de servicios financieros?
2. **Padrón y advertencias de la CNBV:** ¿está autorizada o hay alertas sobre ella?
3. **Buró de Entidades Financieras (CONDUSEF):** ¿cuántas quejas tiene, cómo las resuelve y qué sanciones ha recibido?



#### Lo que te dice cada consulta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| SIPRES | Si existe como entidad financiera y qué tipo es. | Si no aparece, no contrates. |
| Advertencias de la CNBV | Si alguien usa nombres parecidos sin autorización. | Revisa que no esté ahí. |
| Buró de Entidades Financieras | Quejas, sanciones y calificación. | Compara entre opciones. |

#### Las reseñas no son verificación

Las reseñas en redes o en tiendas de apps se pueden comprar. Una página bonita no prueba nada.

Verifica siempre en fuentes oficiales.



#### Un caso en un minuto

Toño buscó la empresa en el SIPRES y no apareció. En las advertencias de la CNBV encontró un nombre muy parecido.

No firmó. Pidió cotización en dos bancos y en una SOFOM registrada, y comparó (M5 U05).

> **Idea clave:** si no aparece en el SIPRES, no contrates.



#### Comprueba lo que entendiste

1. ¿Qué te dice el SIPRES?
*Respuesta:* Si la empresa está registrada como prestador de servicios financieros.

2. ¿Las reseñas en la tienda de apps prueban que es confiable?
*Respuesta:* No. Verifica en fuentes oficiales.


#### Para recordar

- SIPRES, CNBV y Buró de Entidades Financieras.
- Las reseñas no son verificación.
- Si no aparece, no contrates.



### Profundiza (5 minutos más)

#### El Buró de Entidades Financieras

Es una herramienta de CONDUSEF que muestra, por institución, cuántas reclamaciones recibió, cuántas resolvió a favor del usuario, sanciones y evaluación de sus productos.

Úsalo para comparar instituciones del mismo tipo antes de elegir (M5 U01).



#### La verificación de Toño

| Pregunta | Resultado |
|---|---|
| ¿Aparece en el SIPRES? | No |
| ¿Hay advertencia en la CNBV? | Sí, un nombre parecido |
| ¿Buró de Entidades Financieras? | No aparece |
| Decisión | No contratar |



#### Nombres parecidos

Los fraudes usan nombres parecidos a los de instituciones reales: una letra distinta, "México" al final, un logotipo casi igual. Compara el nombre exacto y el sitio oficial.



#### Protege tus datos al verificar

No necesitas dar tus datos para verificar a una institución. Si una página te pide tu INE o tu CURP para "ver si calificas" antes de mostrarte quién es, desconfía.

> **Dato vigente:** SIPRES, Buró de Entidades Financieras (CONDUSEF) y advertencias de la CNBV. Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales.



#### Casos


**Caso 1. El crédito de Toño**

La empresa no aparece en el SIPRES y hay una advertencia de la CNBV con un nombre parecido.
- *¿Qué hace Toño?* No contrata y compara opciones registradas.


**Caso 2. Las reseñas de Renata**

Una app de préstamos tiene 4.8 estrellas y miles de reseñas.
- *¿Basta para confiar?* No. Renata la busca en el SIPRES y en la CNBV.


**Caso 3. Las dos opciones de Gael**

Gael duda entre dos bancos para abrir su cuenta concentradora.
- *¿Qué usa para comparar?* El Buró de Entidades Financieras: quejas, sanciones y evaluación de productos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confiar en reseñas | Pueden ser falsas | Verifica en fuentes oficiales |
| No revisar nombres parecidos | Caes en imitaciones | Compara el nombre exacto |
| Dar tus datos para "ver si calificas" | Riesgo de robo de identidad | Verifica antes |
| Contratar sin verificar | Fraude o abusos | Diez minutos de consulta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde confirmas que una empresa es prestador de servicios financieros registrado? a) Google Maps · b) Sus redes sociales · c) SIPRES
2. ¿Qué herramienta muestra quejas y sanciones de una institución? a) Buró de Crédito · b) Buró de Entidades Financieras · c) El SAT, que revisa a todas las empresas del país
3. Una app no aparece en el SIPRES. ¿Qué haces? a) La uso con poco dinero · b) No contrato · c) Le pregunto al asesor de la app
**Respuestas:** 1-c: el SIPRES es el registro de CONDUSEF. 2-b: el Buró de Entidades Financieras evalúa instituciones. 3-b: no está registrada.



#### Ponlo en práctica

Elige una institución con la que tengas un producto y haz las tres consultas. Anota qué encontraste.
**Respuesta:** Por ejemplo: aparece en el SIPRES como banco; no hay advertencias; en el Buró de Entidades Financieras tiene un nivel medio de quejas.



#### A tu plan

Guarda en tu celular los enlaces del SIPRES, del Buró de Entidades Financieras y de las advertencias de la CNBV.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "SIPRES" y escribe el nombre de la institución.
- **Buró de Entidades Financieras** (CONDUSEF · español): https://www.buro.gob.mx — **Qué buscar:** la institución y su historial de reclamaciones y sanciones.
- **Advertencias** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** "Advertencias" sobre entidades no autorizadas.

### Palabras clave

- *SIPRES:* registro de prestadores de servicios financieros de CONDUSEF.
- *Buró de Entidades Financieras:* herramienta que evalúa a las instituciones.
- *Advertencia:* aviso de la CNBV sobre entidades no autorizadas.

### Fuentes

CONDUSEF, SIPRES y Buró de Entidades Financieras · CNBV, advertencias, consultados el 29 de septiembre de 2026.

---

## M4 U04. Tus derechos como usuario

**Lo que lograrás:** Conocer tus derechos frente a una institución financiera y los pasos para reclamar: primero a la institución y luego a CONDUSEF.

**Para empezar:** A Valeria le cobraron un seguro en su tarjeta que nunca pidió. El ejecutivo le dijo por teléfono que "no se puede quitar". Ella pagó tres meses sin saber que podía reclamar. En esta lección conocerás tus derechos y cómo defenderlos.

### Lo esencial (5 minutos)

#### Tus derechos básicos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Información clara | Te deben explicar costos, CAT, comisiones y condiciones antes de firmar. | Pide la carátula. |
| Contrato | Te deben entregar copia de tu contrato. | Debe estar registrado ante CONDUSEF. |
| Cancelar | Puedes cancelar productos, con los pasos que marca la ley y el contrato. | Pide acuse. |
| Reclamar | Puedes reclamar cargos que no reconoces o cobros indebidos. | Gratis. |

#### Cómo reclamar

1. **Reclama a la institución** en su Unidad Especializada de Atención a Usuarios (UNE), por escrito. Pide folio.
2. **Guarda tu folio** y la respuesta.
3. **Si no te resuelven**, acude a CONDUSEF con tu folio, estado de cuenta y pruebas.



#### Lo que no te pueden imponer

Productos que no pediste, como seguros o membresías agregados sin tu autorización, se pueden reclamar. También puedes pedir no recibir publicidad financiera inscribiéndote en el REUS.



#### Un caso en un minuto

Valeria escribió a la UNE de su banco: "No contraté este seguro; pido cancelarlo y la devolución de los cobros". Le dieron folio.

Como no le respondieron en el plazo, fue a CONDUSEF. El banco canceló el seguro y le devolvió los tres meses.

> **Idea clave:** reclama por escrito y con folio. Si no te resuelven, CONDUSEF te ayuda gratis.



#### Comprueba lo que entendiste

1. ¿A quién reclamas primero?
*Respuesta:* A la UNE de la institución, por escrito y con folio.

2. ¿Qué haces si no te resuelven?
*Respuesta:* Acudes a CONDUSEF con tu folio y tus pruebas.


#### Para recordar

- Tienes derecho a información, contrato, cancelar y reclamar.
- Reclama por escrito y pide folio.
- CONDUSEF es gratis.



### Profundiza (5 minutos más)

#### La carátula y el RECA

La **carátula** resume lo más importante de tu contrato. Pídela siempre.

El contrato debe estar inscrito en el Registro de Contratos de Adhesión (**RECA**) de CONDUSEF. Ahí puedes consultar el contrato de cualquier producto antes de firmar.



#### Arrepentirte después de firmar

Tienes 10 días hábiles después de firmar un contrato de adhesión para cancelarlo sin costo ni responsabilidad, siempre que no hayas usado el producto. No aplica a créditos con garantía hipotecaria. La cancelación surte efecto a más tardar el segundo día hábil después de que la reciben.

> **Dato vigente:** artículo 11 Bis 1 de la Ley para la Transparencia y Ordenamiento de los Servicios Financieros. Consultado el 29 de septiembre de 2026 a través de CONDUSEF. Antes de decidir, confirma las condiciones de tu producto en CONDUSEF o en el sitio oficial de la institución.



#### Tu expediente de reclamación

| Documento | Para qué |
|---|---|
| Estado de cuenta con el cargo | Muestra el cobro |
| Escrito a la UNE con folio | Prueba que reclamaste |
| Respuesta de la institución | Lo que dijeron |
| Contrato o carátula | Lo que aceptaste |



#### REUS: menos llamadas de venta

Si te inscribes en el Registro Público de Usuarios (REUS) de CONDUSEF, las instituciones no deben usar tu información para ofrecerte productos por teléfono o mensaje.

> **Dato vigente:** UNE, RECA y REUS de CONDUSEF. Consultado el 29 de septiembre de 2026 a través de su sitio oficial.



#### Casos


**Caso 1. El seguro de Valeria**

A Valeria le cobran un seguro que no pidió y le dicen que "no se puede quitar".
- *¿Qué hace?* Reclama por escrito en la UNE, pide folio y, si no le resuelven, acude a CONDUSEF.


**Caso 2. El contrato de Gael**

Gael quiere leer el contrato de una tarjeta antes de pedirla.
- *¿Dónde lo consulta?* En el RECA de CONDUSEF o pidiendo la carátula y el contrato al banco.


**Caso 3. Las llamadas de Renata**

Renata recibe llamadas diarias ofreciéndole créditos.
- *¿Qué puede hacer?* Inscribirse en el REUS de CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Reclamar solo por teléfono | No hay prueba | Reclama por escrito con folio |
| Pagar cargos que no reconoces | Pierdes dinero | Reclama cuanto antes |
| Firmar sin la carátula | No conoces los costos | Pide la carátula |
| Creer que no se puede cancelar | Pagas de más | Pide la cancelación con acuse |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde reclamas primero un cargo que no reconoces? a) En la UNE de la institución · b) En redes sociales, etiquetando a la institución · c) En el SAT
2. ¿Qué es el RECA? a) Un registro de contratos de productos financieros · b) Un tipo de crédito rápido para personas sin historial · c) Una tarjeta
3. ¿Para qué sirve el REUS? a) Para no recibir publicidad financiera · b) Para pedir créditos · c) Para ver tu Buró de Crédito gratis cuando quieras
**Respuestas:** 1-a: la UNE atiende reclamaciones. 2-a: ahí consultas contratos. 3-a: limita las ofertas por teléfono y mensaje.



#### Ponlo en práctica

Escribe una reclamación corta para un cargo que no reconoces.
**Respuesta:** Por ejemplo: "Reclamo el cargo de 349 del 5 de septiembre en mi tarjeta terminación 1234. No contraté ese servicio. Pido cancelarlo y la devolución. Solicito folio."



#### A tu plan

Inscríbete en el REUS y revisa tu último estado de cuenta en busca de cargos que no reconozcas.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Presenta tu reclamación" y los requisitos.
- **RECA** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Registro de Contratos de Adhesión" para leer contratos.
- **REUS** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "REUS" para inscribirte.

### Palabras clave

- *UNE:* unidad de la institución que atiende reclamaciones.
- *Carátula:* resumen de tu contrato.
- *RECA:* registro de contratos de CONDUSEF.
- *REUS:* registro para no recibir publicidad financiera.

### Fuentes

CONDUSEF · Ley de Protección y Defensa al Usuario de Servicios Financieros · Ley para la Transparencia y Ordenamiento de los Servicios Financieros, consultados el 29 de septiembre de 2026.

---


---

# Módulo 5. Compara y elige: instituciones y productos

## M5 U01. Primero elige la institución

**Lo que lograrás:** Comparar instituciones por autorización, protección, quejas, atención y canales antes de elegir cualquier producto.

**Para empezar:** Gael abrió una cuenta en el primer banco que le ofreció una promoción en un centro comercial. Meses después, cada aclaración le toma semanas y le cobran comisiones que nadie le explicó. En esta lección aprenderás a elegir primero la institución y después el producto.

### Lo esencial (5 minutos)

#### La institución importa tanto como el producto

Un producto con buena tasa en una institución que no resuelve tus quejas, que cobra comisiones escondidas o que no está autorizada te sale caro.

Antes de comparar cuentas, tarjetas o créditos, elige con quién.



#### Cinco cosas que comparas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Autorización | Que aparezca en la CNBV y en el SIPRES. | Sin esto, no sigas. |
| Protección | Si es banco, tus depósitos los protege el IPAB. | Importa para ahorrar. |
| Quejas y sanciones | Buró de Entidades Financieras de CONDUSEF. | Menos quejas por cliente es mejor. |
| Atención | Canales, horarios, tiempo de respuesta. | Pregunta y prueba. |
| Canales | App, sucursales, cajeros, depósitos en efectivo. | Según cómo cobras. |

#### Tu forma de trabajar decide

Si te pagan en efectivo en eventos, necesitas dónde depositarlo sin comisión. Si viajas por giras, necesitas buena app y cajeros en otras ciudades. Si te pagan del extranjero, revisa cómo recibe transferencias internacionales.



#### Un caso en un minuto

Gael comparó tres bancos en el Buró de Entidades Financieras, revisó sus apps y preguntó cuánto cuesta depositar efectivo.

Eligió uno con menos quejas y sin comisión por depósitos en tiendas. Después eligió la cuenta dentro de ese banco.

> **Idea clave:** primero con quién, después qué producto.



#### Comprueba lo que entendiste

1. ¿Qué revisas primero de una institución?
*Respuesta:* Que esté autorizada: CNBV y SIPRES.

2. ¿Dónde ves quejas y sanciones?
*Respuesta:* En el Buró de Entidades Financieras de CONDUSEF.


#### Para recordar

- Primero la institución, luego el producto.
- Autorización, protección y quejas.
- Elige según cómo trabajas.



### Profundiza (5 minutos más)

#### La comparación de Gael

| | Banco A | Banco B | Banco C |
|---|---|---|---|
| Autorizado (CNBV) | Sí | Sí | Sí |
| Quejas en el Buró de Entidades Financieras | Altas | Medias | Bajas |
| Depósito de efectivo en tiendas | Con comisión | Sin comisión | Con comisión |
| App con buenas funciones | Sí | Sí | Regular |
| Decisión | | **Elegido** | |



#### Cómo probar la atención

Antes de contratar, llama o escribe con una pregunta concreta: "¿cuánto cuesta un retiro en cajero de otro banco?". Mide cuánto tardan y si la respuesta es clara.



#### No tienes que tener todo en un solo lugar

Puedes tener tu cuenta en un banco, tu fondo de sequía en Cetesdirecto y tu tarjeta de crédito en otro banco. Elige lo mejor de cada uno.

Pero no abras productos de más: cada uno es algo más que revisar.

> **Dato vigente:** Buró de Entidades Financieras, SIPRES y padrón de la CNBV. Consultado el 29 de septiembre de 2026 a través de CONDUSEF y la CNBV.



#### Casos


**Caso 1. La promoción de Gael**

A Gael le ofrecen una cuenta con regalo en un centro comercial.
- *¿Qué revisa antes de firmar?* La autorización de la institución, sus quejas en el Buró de Entidades Financieras y las comisiones.


**Caso 2. El efectivo de Renata**

A Renata le pagan en efectivo en muchos eventos.
- *¿Qué pregunta al elegir banco?* Dónde puede depositar efectivo y cuánto le cobran.


**Caso 3. Las giras de Toño**

Toño viaja por giras y necesita sacar dinero en muchas ciudades.
- *¿Qué compara?* La red de cajeros sin comisión, la app y las comisiones por retiro en otros bancos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Elegir por un regalo | Pagas comisiones después | Compara la institución |
| No revisar quejas | Aclaraciones eternas | Usa el Buró de Entidades Financieras |
| Ignorar cómo cobras | Comisiones por depositar | Elige según tu forma de trabajo |
| Abrir productos de más | Pierdes control | Solo lo que necesitas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué eliges primero? a) La institución · b) El regalo de la promoción · c) El color de la tarjeta
2. Cobras mucho en efectivo. ¿Qué preguntas? a) Cuánto cuesta depositar efectivo y dónde · b) Si la tarjeta es de metal · c) Si tienen puntos para viajes y descuentos en conciertos
3. ¿Qué herramienta muestra quejas por institución? a) Buró de Entidades Financieras · b) Buró de Crédito · c) Las reseñas de la app en la tienda del celular
**Respuestas:** 1-a: primero con quién. 2-a: según cómo cobras. 3-a: es la herramienta de CONDUSEF.



#### Ponlo en práctica

Compara dos instituciones con los cinco puntos de esta lección y elige una.
**Respuesta:** Por ejemplo: A autorizada, quejas altas, depósito con comisión; B autorizada, quejas bajas, depósito sin comisión. Elijo B.



#### A tu plan

Anota tus tres necesidades principales (efectivo, viajes, pagos del extranjero) y úsalas para elegir institución.



### Para saber más

- **Buró de Entidades Financieras** (CONDUSEF · español): https://www.buro.gob.mx — **Qué buscar:** compara instituciones del mismo tipo por quejas y sanciones.
- **Padrón de entidades supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** confirma que la institución está autorizada.

### Palabras clave

- *Comisión:* cobro por un servicio financiero.
- *Canales:* formas de atenderte: app, sucursal, cajero, teléfono.
- *Autorización:* permiso oficial para operar.

### Fuentes

CONDUSEF · CNBV, consultados el 29 de septiembre de 2026.

---

## M5 U02. Elige tu cuenta

**Lo que lograrás:** Comparar cuentas por comisiones, saldo mínimo, retiros, transferencias y depósitos en efectivo, y usar la portabilidad de nómina si cobras por nómina.

**Para empezar:** Valeria paga 250 al mes de comisión por no mantener un saldo mínimo en una cuenta que casi no usa. Además, su pago como asimilada le llega a un banco que no eligió. En esta lección aprenderás a elegir la cuenta que te conviene.

### Lo esencial (5 minutos)

#### Lo que comparas en una cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión de manejo | Lo que te cobran cada mes. | Busca que sea cero o baja. |
| Saldo mínimo | Lo que debes mantener para no pagar comisión. | Que sea realista para ti. |
| Transferencias y retiros | Costos por SPEI, cajeros propios y de otros bancos. | Según cómo usas tu dinero. |
| Depósitos en efectivo | Dónde y cuánto cuesta. | Clave si te pagan en efectivo. |

#### Tipos de cuenta

- **Cuentas básicas o de nivel bajo:** sin comisión, con límites de depósito al mes. Útiles para empezar.
- **Cuentas tradicionales:** sin límites bajos, pero a veces con saldo mínimo o comisión.
- **Cuentas con rendimiento:** pagan una tasa por tu saldo. Revisa si tiene tope.



#### Portabilidad de nómina

Si te pagan por nómina, incluidos los pagos como asimilado a salarios, tienes derecho a recibirla en el banco que elijas, sin costo. Lo pides en el banco nuevo con tus datos.



#### Un caso en un minuto

Valeria cerró la cuenta con saldo mínimo y abrió una sin comisión de manejo en el banco que ya usaba para su concentradora. Pidió la portabilidad de nómina.

Se ahorra 3,000 al año y tiene todo en un solo lugar.

> **Idea clave:** una comisión de 250 al mes son 3,000 al año por nada.



#### Comprueba lo que entendiste

1. ¿Qué es la portabilidad de nómina?
*Respuesta:* Tu derecho a recibir tu nómina en el banco que elijas, sin costo.

2. Una cuenta cobra 180 al mes si no mantienes 5,000. ¿Cuánto pagas al año si no llegas?
*Respuesta:* 2,160.


#### Para recordar

- Compara comisiones, saldo mínimo y costos de uso.
- Elige según cómo cobras y gastas.
- Pide la portabilidad de nómina si te conviene.



### Profundiza (5 minutos más)

#### Comparación de cuentas

| | Cuenta A | Cuenta B | Cuenta C |
|---|---|---|---|
| Comisión de manejo | 0 | 180 si saldo menor a 5,000 | 0 |
| Límite de depósitos al mes | Bajo | Sin límite | Sin límite |
| Depósito de efectivo en tiendas | Con comisión | Con comisión | Sin comisión |
| Rendimiento | No | No | Sí, con tope |

Para alguien que cobra en efectivo y mueve más dinero que el límite de la A, la C suele convenir.



#### Protege tu cuenta

Activa notificaciones de cada movimiento, usa contraseñas distintas y no compartas tus códigos (M9 U03). Si hay un cargo que no reconoces, repórtalo de inmediato.



#### Beneficiarios

Al abrir tu cuenta, designa beneficiarios. Si algo te pasa, tu familia puede recibir el dinero sin un juicio largo (M10 U04).

> **Dato vigente:** portabilidad de nómina sin costo y designación de beneficiarios en cuentas bancarias. Consultado el 29 de septiembre de 2026 a través del Banco de México y CONDUSEF.



#### Casos


**Caso 1. La comisión de Valeria**

Valeria paga 250 al mes por no mantener el saldo mínimo.
- *¿Qué hace?* Cambia a una cuenta sin comisión de manejo que se ajuste a su uso.


**Caso 2. La nómina de Gael**

A Gael le pagan como asimilado en un banco que no le gusta.
- *¿Qué puede pedir?* La portabilidad de nómina al banco que elija, sin costo.


**Caso 3. La cuenta básica de Renata**

Renata tiene una cuenta básica y le rechazan un depósito grande por el límite.
- *¿Qué hace?* Cambia a una cuenta con un límite acorde a lo que cobra.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar comisión por saldo mínimo | Pierdes dinero cada mes | Cambia de cuenta |
| No revisar límites de depósito | Te rechazan pagos | Elige según tus montos |
| Olvidar a los beneficiarios | Trámites largos para tu familia | Desígnalos |
| No activar notificaciones | Tardas en ver fraudes | Actívalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Una cuenta cobra 200 al mes de manejo. ¿Cuánto pagas al año? a) 2,400 · b) 200 · c) 1,200
2. ¿Tienes derecho a elegir en qué banco recibir tu nómina? a) No · b) Sí, con la portabilidad de nómina · c) Solo si tu patrón acepta cambiar de banco
3. Cobras en efectivo en eventos. ¿Qué revisas? a) El diseño de la tarjeta y si tiene tu nombre grabado · b) Dónde y cuánto cuesta depositar · c) Si la app tiene juegos
**Respuestas:** 1-a: 200 × 12. 2-b: es un derecho sin costo. 3-b: según cómo cobras.



#### Ponlo en práctica

Revisa tu estado de cuenta: ¿cuánto pagaste de comisiones en los últimos tres meses?
**Respuesta:** Por ejemplo: 180 de manejo cada mes y 30 por retiro en otro banco: 630 en tres meses. Voy a cambiar de cuenta y usar cajeros de mi banco.



#### A tu plan

Designa beneficiarios en tu cuenta y activa las notificaciones de movimientos.



### Para saber más

- **Portabilidad de nómina** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "Portabilidad de nómina" y cómo solicitarla.
- **Comisiones bancarias** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "Comisiones" para comparar lo que cobra cada banco.

### Palabras clave

- *Comisión de manejo:* cobro mensual por tener la cuenta.
- *Saldo mínimo:* lo que debes mantener para no pagar comisión.
- *Portabilidad de nómina:* recibir tu nómina en el banco que elijas.

### Fuentes

Banco de México · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M5 U03. Elige dónde ahorrar e invertir

**Lo que lograrás:** Comparar opciones de ahorro e inversión por rendimiento real, plazo, liquidez y protección.

**Para empezar:** Toño tiene 80,000 guardados en su cuenta de cheques y no le pagan nada. Un conocido le dice que lo meta a "un negocio de reventa de boletos" que da 10% al mes. En esta lección aprenderás a comparar opciones seguras y a reconocer las que no lo son.

### Lo esencial (5 minutos)

#### Cuatro preguntas para comparar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cuánto me paga? | GAT nominal y GAT real. | La real descuenta la inflación. |
| ¿A qué plazo? | Cuándo puedo sacar mi dinero. | Según tu meta. |
| ¿Quién lo respalda? | Gobierno, banco con IPAB u otro. | Primero la seguridad. |
| ¿Qué me cobra? | Comisiones y penalizaciones por retiro anticipado. | Réstalas. |

#### Opciones seguras y sencillas

- **Cetes en Cetesdirecto:** gobierno federal, desde 100 pesos, plazos de 28 días a varios años y BONDDIA para liquidez diaria.
- **Pagarés o depósitos a plazo en bancos:** tasa fija por un plazo; protegidos por el IPAB.
- **Cuentas a la vista con rendimiento en bancos:** liquidez inmediata; protegidas por el IPAB.



#### Si promete demasiado, desconfía

Un "negocio" que paga 10% al mes pagaría más de 200% al año. Nadie puede prometer eso sin riesgo enorme. Casi siempre es fraude (M9 U07).



#### Un caso en un minuto

Toño separó su dinero por metas: 40,000 para su fondo de sequía en BONDDIA, 30,000 en Cetes a 6 meses para comprar un equipo y 10,000 en su cuenta para el mes.

No entró al negocio de boletos. Meses después, supo que varios perdieron su dinero.

> **Idea clave:** cada meta tiene su plazo. Elige la inversión según cuándo necesitarás el dinero.



#### Comprueba lo que entendiste

1. ¿Qué es la GAT real?
*Respuesta:* Lo que te paga una inversión después de descontar la inflación.

2. ¿Dónde pones dinero que necesitas en seis meses?
*Respuesta:* En algo seguro con plazo de seis meses o menos, como Cetes.


#### Para recordar

- Compara GAT real, plazo, respaldo y costos.
- Cada meta con su plazo.
- Promesas altas, riesgo alto o fraude.



### Profundiza (5 minutos más)

#### Plazo según la meta

| Meta | Cuándo la necesitas | Opción |
|---|---|---|
| Fondo de sequía | En cualquier momento | BONDDIA o cuenta a la vista en banco |
| Equipo, curso o viaje | En 3 a 12 meses | Cetes o pagaré bancario al plazo de tu meta |
| Retiro | En muchos años | AFORE, PPR u otras inversiones de largo plazo (M11) |



#### Cómo leer la GAT

Si la GAT nominal es 9% y la inflación 4%, tu ganancia real es cercana a 5%. Si la GAT real es negativa, tu dinero pierde poder de compra.

Compara siempre la GAT, no solo la "tasa" que anuncian.



#### Penalizaciones por sacar antes

Algunos plazos no te dejan sacar el dinero antes, o te cobran por hacerlo. Si puedes necesitar el dinero, elige un plazo más corto o una opción con liquidez diaria.

> **Dato vigente:** opciones de Cetesdirecto (Cetes y BONDDIA, desde 100 pesos) y protección del IPAB para depósitos bancarios. Consultado el 29 de septiembre de 2026 a través de Cetesdirecto y el IPAB. Las tasas cambian: revisa la tasa del día en el sitio oficial.



#### ¿Y la bolsa?

Invertir en acciones o fondos puede tener sentido para metas de largo plazo, con dinero que no necesitarás pronto y a través de intermediarios autorizados por la CNBV (M11 U05). No es para tu fondo de sequía.



#### Casos


**Caso 1. El negocio de boletos de Toño**

Un conocido le ofrece a Toño 10% al mes en un negocio de reventa.
- *¿Qué hace?* No invierte: es una promesa imposible y sin respaldo. Usa opciones seguras según sus metas.


**Caso 2. El curso de Valeria**

Valeria quiere pagar un curso en 8 meses.
- *¿Dónde guarda ese dinero?* En Cetes o un pagaré bancario a un plazo que termine antes de la fecha del curso.


**Caso 3. La GAT de Gael**

Un banco anuncia a Gael una "tasa de 12%", pero su GAT real es 1%.
- *¿Qué entiende?* Que después de inflación y costos, su dinero crece poco. Compara la GAT real con otras opciones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar todo en la cuenta de cheques | Pierdes contra la inflación | Separa por metas |
| Invertir sin saber el plazo | No puedes sacar tu dinero a tiempo | Elige según tu meta |
| Comparar solo la tasa anunciada | No ves los costos | Compara la GAT |
| Creer en rendimientos altísimos | Pierdes todo | Verifica en CNBV y CONDUSEF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Necesitas el dinero en 3 meses. ¿Qué opción es más adecuada? a) Cetes a 3 meses o menos · b) Acciones · c) Un plazo fijo de 2 años con mejor tasa
2. ¿Qué indicador descuenta la inflación? a) GAT real · b) GAT nominal · c) Tasa anunciada
3. Te ofrecen 10% mensual garantizado. ¿Qué es? a) Una gran oportunidad · b) Señal de fraude · c) Una inversión segura del gobierno
**Respuestas:** 1-a: el plazo coincide con tu meta. 2-a: muestra la ganancia real. 3-b: nadie garantiza eso sin riesgo.



#### Ponlo en práctica

Escribe tus metas de ahorro con monto y fecha, y elige una opción para cada una.
**Respuesta:** Por ejemplo: fondo de sequía 60,000, siempre disponible: BONDDIA. Laptop 25,000 en 6 meses: Cetes a 6 meses. Retiro: AFORE.



#### A tu plan

Separa tu dinero por metas y abre tu cuenta de Cetesdirecto si aún no la tienes.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com — **Qué buscar:** tasas del día, plazos y BONDDIA.
- **Calculadora de ahorro e inversión** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" para comparar opciones.

### Palabras clave

- *GAT real:* ganancia después de descontar la inflación.
- *Pagaré bancario:* depósito a plazo fijo en un banco.
- *Liquidez:* qué tan rápido puedes usar tu dinero.

### Fuentes

Cetesdirecto · IPAB · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M5 U04. Elige un seguro

**Lo que lograrás:** Comparar seguros por suma asegurada, deducible, coaseguro, exclusiones y prima, y verificar a la aseguradora y al agente.

**Para empezar:** Renata contrató un seguro de accidentes porque "era el más barato". Se lastimó un tobillo en un ensayo y descubrió que su póliza excluía lesiones "por actividades deportivas o artísticas". Pagó todo de su bolsa. En esta lección aprenderás a comparar seguros de verdad.

### Lo esencial (5 minutos)

#### Cinco palabras que debes entender

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Suma asegurada | Lo máximo que paga el seguro. | Que alcance para lo que te preocupa. |
| Prima | Lo que tú pagas por el seguro. | Mensual o anual. |
| Deducible | Lo que pagas tú antes de que pague el seguro. | Más alto, prima más baja. |
| Coaseguro | El porcentaje que pagas tú después del deducible. | Revisa si tiene tope. |
| Exclusiones | Lo que el seguro no cubre. | Léelas primero. |

#### Lee las exclusiones primero

Un seguro barato que excluye justo lo que te puede pasar no sirve. En el medio, revisa si excluye lesiones por actividades artísticas, deportivas o acrobáticas, o si cubre giras y viajes.



#### Verifica aseguradora y agente

La aseguradora debe estar autorizada y supervisada por la CNSF. El agente debe tener cédula vigente. Pídesela y verifícala.



#### Un caso en un minuto

Renata comparó tres pólizas leyendo primero las exclusiones. Eligió una que cubre lesiones en ensayos y funciones, aunque era un poco más cara.

Verificó la cédula del agente y guardó la póliza completa en su carpeta.

> **Idea clave:** el seguro más barato es el que paga cuando lo necesitas.



#### Comprueba lo que entendiste

1. ¿Qué es el deducible?
*Respuesta:* Lo que pagas tú antes de que pague el seguro.

2. ¿Qué lees primero de una póliza?
*Respuesta:* Las exclusiones.


#### Para recordar

- Suma asegurada, prima, deducible, coaseguro y exclusiones.
- Lee las exclusiones primero.
- Verifica aseguradora y agente.



### Profundiza (5 minutos más)

#### Cuánto pagas tú en un accidente

Un gasto de 60,000 con deducible de 10,000 y coaseguro de 10%.
- Deducible: **10,000**
- Coaseguro: 10% de 50,000: **5,000**
- Lo que pagas tú: **15,000**
El seguro paga los otros 45,000.


#### Comparación de Renata

| | Póliza A | Póliza B | Póliza C |
|---|---|---|---|
| Prima anual | 3,200 | 4,500 | 4,100 |
| Deducible | 5,000 | 3,000 | 5,000 |
| Coaseguro | 10% | 10% | 10% |
| ¿Cubre lesiones en ensayos? | No | Sí | Sí |
| ¿Cubre giras? | No | Sí | No |

Para Renata, que hace giras, la B es la que realmente la protege.



#### Usa los simuladores

CONDUSEF tiene simuladores y comparativos de seguros. Úsalos para comparar primas y coberturas antes de hablar con un agente.



#### Seguros que te agregan sin pedir

A veces un crédito o una tarjeta incluye un seguro que no pediste. Revisa si es obligatorio, cuánto cuesta y si puedes elegir tu propia aseguradora.

> **Dato vigente:** supervisión de aseguradoras por la CNSF y verificación de agentes con cédula. Consultado el 29 de septiembre de 2026 a través de la CNSF y CONDUSEF.



#### Casos


**Caso 1. La póliza de Renata**

La póliza más barata excluye lesiones por actividades artísticas.
- *¿Le sirve?* No: excluye justo su riesgo. Elige una que cubra ensayos y funciones.


**Caso 2. El agente de Gael**

Un agente le ofrece a Gael un seguro de gastos médicos, pero no le muestra su cédula.
- *¿Qué hace Gael?* Pide la cédula y la verifica antes de firmar o pagar.


**Caso 3. El seguro de la tarjeta de Valeria**

La tarjeta de Valeria incluye un seguro de 149 al mes que no pidió.
- *¿Qué hace?* Revisa si es opcional y, si lo es, pide cancelarlo por escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Elegir solo por precio | No te cubre cuando lo necesitas | Lee las exclusiones |
| No verificar al agente | Riesgo de fraude | Pide y verifica su cédula |
| No calcular deducible y coaseguro | Te sorprende lo que pagas | Haz la cuenta |
| Aceptar seguros agregados | Pagas de más | Revisa si son opcionales |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gasto de 40,000, deducible de 5,000 y coaseguro de 10%. ¿Cuánto pagas tú? a) 5,000 · b) 8,500 · c) 4,000
2. ¿Qué parte de la póliza dice lo que NO cubre? a) La prima · b) Las exclusiones · c) La suma asegurada
3. ¿Quién supervisa a las aseguradoras? a) SAT · b) IMSS · c) CNSF
**Respuestas:** 1-b: 5,000 + 10% de 35,000 = 8,500. 2-b: por eso se leen primero. 3-c: la CNSF supervisa seguros.



#### Ponlo en práctica

Toma un seguro que tengas y anota su suma asegurada, prima, deducible, coaseguro y tres exclusiones.
**Respuesta:** Por ejemplo: suma 500,000; prima 6,000 al año; deducible 8,000; coaseguro 10%; excluye deportes extremos, padecimientos previos y cirugía estética.



#### A tu plan

Guarda tus pólizas completas en tu carpeta y marca con color las exclusiones.



### Para saber más

- **Simuladores de seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" y "Comparativos" de seguros.
- **CNSF** (Gobierno de México · español): https://www.gob.mx/cnsf — **Qué buscar:** aseguradoras autorizadas y consulta de agentes.

### Palabras clave

- *Prima:* lo que pagas por el seguro.
- *Deducible:* lo que pagas tú antes de que pague el seguro.
- *Coaseguro:* porcentaje que pagas después del deducible.
- *Exclusión:* lo que el seguro no cubre.

### Fuentes

CNSF · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M5 U05. Elige un crédito: los números

**Lo que lograrás:** Comparar créditos por CAT, tasa, comisiones, pago total y plazo, y no solo por el pago mensual.

**Para empezar:** A Toño le ofrecen dos créditos de 100,000 para equipar su estudio. El primero pide 24 pagos de 5,100; el segundo, 36 pagos de 3,900. El segundo "se siente más barato". En realidad le cuesta 18,000 más. En esta lección aprenderás a comparar créditos con números.

### Lo esencial (5 minutos)

#### El pago mensual engaña

Un pago mensual bajo puede esconder un crédito caro: más plazo, más intereses, más comisiones.

Para comparar, mira siempre el **CAT** y el total que pagarás.



#### Los dos créditos de Toño

Ambos por 100,000.
- Crédito A: 24 pagos de 5,100: **122,400**
- Crédito B: 36 pagos de 3,900: **140,400**
- El B cuesta 18,000 más: **-18,000**
El pago más bajo sale más caro en total.


#### Lo que comparas en un crédito

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| CAT | El costo total en un número. | Compara créditos del mismo tipo y plazo. |
| Pago total | Todo lo que pagarás al final. | Multiplica pagos por plazo y suma comisiones. |
| Plazo | Cuánto tiempo pagarás. | Más plazo, más intereses. |
| Comisiones y seguros | Apertura, pago tardío, seguros incluidos. | Réstalos del dinero que recibes. |

#### Un caso en un minuto

Toño comparó el CAT y el pago total. Eligió el crédito A: pagos más altos, pero 18,000 menos al final. Revisó que el pago de 5,100 cupiera en su mes bajo (M6 U05).

Como no cabía cómodo, pidió 70,000 en lugar de 100,000 y compró el equipo por partes.

> **Idea clave:** compara el CAT y el total, no el pago mensual.



#### Comprueba lo que entendiste

1. ¿Qué indicador usas para comparar el costo de dos créditos?
*Respuesta:* El CAT, además del pago total.

2. ¿Un plazo más largo abarata el crédito?
*Respuesta:* No. Baja el pago, pero sube el total.


#### Para recordar

- El pago mensual engaña.
- Compara CAT y pago total.
- Que el pago quepa en tu mes bajo.



### Profundiza (5 minutos más)

#### Qué incluye el CAT

El CAT incluye intereses, comisiones y otros costos del crédito, expresado como porcentaje anual y sin IVA. Sirve para comparar créditos del mismo tipo y plazo.

No es la tasa de interés: el CAT suele ser más alto porque suma todo.



#### Comparación completa

| | Crédito A | Crédito B |
|---|---|---|
| Monto | 100,000 | 100,000 |
| Pagos | 24 de 5,100 | 36 de 3,900 |
| Comisión por apertura | 2,000 | 0 |
| Pago total | 124,400 | 140,400 |
| Diferencia | | 16,000 más caro |

Con la comisión de apertura, la diferencia baja a 16,000, pero A sigue siendo más barato.



#### Usa los simuladores

CONDUSEF y el Banco de México tienen simuladores y calculadoras del CAT. Pide al menos tres cotizaciones por escrito y compáralas con esas herramientas.

> **Dato vigente:** el CAT incluye intereses, comisiones y otros costos, sin IVA, y se usa para comparar. Consultado el 29 de septiembre de 2026 a través del Banco de México y CONDUSEF.



#### Pide la carátula

Antes de firmar, pide la carátula: dice el CAT, la tasa, las comisiones, el plazo y el monto total a pagar. Si no te la dan, no firmes (M5 U07).



#### Casos


**Caso 1. Los dos créditos de Toño**

El crédito B tiene pagos más bajos, pero cuesta 18,000 más.
- *¿Cuál elige y qué revisa?* El A, más barato en total, siempre que el pago quepa en su mes bajo. Si no cabe, pide menos.


**Caso 2. El préstamo de Renata**

A Renata le ofrecen un préstamo "con tasa de 3% mensual".
- *¿Qué pide para comparar?* El CAT y el pago total, y compara con otras dos opciones.


**Caso 3. La comisión de Gael**

Un crédito de 50,000 cobra 5% de apertura.
- *¿Cuánto dinero recibe realmente Gael?* 47,500, aunque pagará intereses sobre 50,000.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Elegir por el pago mensual | Pagas más al final | Compara el total |
| Ignorar comisiones de apertura | Recibes menos de lo que crees | Réstalas |
| Comparar créditos de distinto plazo sin ajustar | Comparación falsa | Compara mismo plazo |
| No pedir la carátula | No conoces el costo | Pídela siempre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Crédito de 12 pagos de 2,000 y otro de 18 pagos de 1,500, ambos por 20,000. ¿Cuál cuesta menos en total? a) El de 12 pagos (24,000) · b) El de 18 pagos (27,000) · c) Cuestan igual
2. ¿Qué indicador suma intereses y comisiones? a) GAT · b) CAT · c) UDI
3. Te cobran 4% de apertura en 30,000. ¿Cuánto recibes? a) 30,000 · b) 31,200 · c) 28,800
**Respuestas:** 1-a: 24,000 contra 27,000. 2-b: el CAT es el costo total. 3-c: 30,000 menos 1,200.



#### Ponlo en práctica

Pide o simula dos cotizaciones de crédito y calcula el pago total de cada una.
**Respuesta:** Por ejemplo: A, 12 pagos de 4,700 = 56,400; B, 24 pagos de 2,700 = 64,800. A cuesta 8,400 menos, si el pago cabe en mi mes bajo.



#### A tu plan

Antes de pedir cualquier crédito, consigue tres cotizaciones por escrito con CAT y pago total.



### Para saber más

- **Calculadora del CAT** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "Calculadora del CAT" para comparar créditos.
- **Simuladores de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simulador de crédito personal y de nómina".

### Palabras clave

- *CAT:* costo anual total de un crédito.
- *Pago total:* todo lo que pagas al final.
- *Comisión por apertura:* cobro al otorgarte el crédito.

### Fuentes

Banco de México, CAT · CONDUSEF, simuladores, consultados el 29 de septiembre de 2026.

---

## M5 U06. Elige un crédito: el tipo correcto para cada uso

**Lo que lograrás:** Relacionar cada necesidad con el tipo de crédito adecuado y reconocer cuándo no conviene pedir crédito.

**Para empezar:** Renata usó su tarjeta de crédito para pagar un curso de un año, la renta de dos meses y un celular a meses. Luego pidió un préstamo por app para pagar la tarjeta. Cada deuda era del tipo equivocado para lo que necesitaba. En esta lección aprenderás qué crédito sirve para qué.

### Lo esencial (5 minutos)

#### Dos grandes tipos de crédito

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Revolvente | Una línea que usas, pagas y vuelves a usar. Por ejemplo, la tarjeta. | Para gastos cortos que pagas completo. |
| Simple | Un monto que pagas en pagos fijos hasta terminar. | Para compras planeadas grandes. |

#### Qué crédito para qué uso

| Necesidad | Crédito que suele convenir | Lo que no conviene |
|---|---|---|
| Compras del mes que pagas completo | Tarjeta, pagando el total | Pagar solo el mínimo |
| Equipo de trabajo | Crédito simple o MSI que ya planeaste | Préstamo por app |
| Auto | Crédito automotriz | Tarjeta de crédito |
| Vivienda | Crédito hipotecario | Préstamos personales |
| Renta o comida | Tu fondo de sequía | Cualquier crédito |



#### Cuándo no pedir crédito

Si vas a pagar gastos del día a día (renta, comida, servicios) con crédito porque no te alcanza, el crédito no resuelve el problema: lo hace más grande.

En ese caso, usa tu fondo de sequía, recorta gastos o habla con tus acreedores (M8).



#### Un caso en un minuto

Renata dejó de usar la tarjeta para la renta. Pagó el celular a MSI que ya tenía y, para el curso, esperó a juntar la mitad y pidió un crédito simple pequeño con CAT más bajo que el de su tarjeta.

> **Idea clave:** el tipo de crédito debe corresponder al uso y al tiempo en que lo pagarás.



#### Comprueba lo que entendiste

1. ¿Qué crédito conviene para comprar un auto?
*Respuesta:* Un crédito automotriz, no la tarjeta.

2. ¿Conviene pagar la renta con crédito?
*Respuesta:* No. Usa tu fondo de sequía o ajusta gastos.


#### Para recordar

- Revolvente para lo corto; simple para lo planeado.
- Nunca pagues el día a día con crédito.
- Un crédito para pagar otro es señal de alerta.



### Profundiza (5 minutos más)

#### Un crédito para pagar otro

Pedir un préstamo para pagar tu tarjeta solo mueve la deuda. Solo tiene sentido si el nuevo crédito es mucho más barato, si cierras o dejas de usar la tarjeta y si el pago cabe en tu mes bajo (M8 U03).



#### Casas de empeño

Empeñar puede darte dinero rápido sin revisar tu historial, pero el costo suele ser alto y puedes perder tu prenda. Compara el costo y verifica que la casa esté registrada ante Profeco.



#### Préstamos por app

Algunos están autorizados y otros no. Aun los autorizados suelen ser caros. Verifícalos siempre en el SIPRES y en la CNBV, y compara el CAT (M9 U06).



#### Crédito de tiendas y "compra ahora, paga después"

Son fáciles de obtener y parecen pagos pequeños. Suma todos tus pagos a plazos antes de agregar otro: muchos pagos pequeños forman una deuda grande (M6 U03).

> **Dato vigente:** registro de casas de empeño ante Profeco y verificación de prestadores en el SIPRES. Consultado el 29 de septiembre de 2026 a través de Profeco y CONDUSEF.



#### Casos


**Caso 1. La renta de Renata**

Renata quiere pagar dos meses de renta con la tarjeta.
- *¿Qué le conviene?* Usar su fondo de sequía o ajustar gastos; el crédito no resuelve un faltante recurrente.


**Caso 2. El equipo de Toño**

Toño necesita una consola de audio de 60,000.
- *¿Qué tipo de crédito revisa?* Un crédito simple con CAT bajo, o MSI si el pago cabe en su mes bajo.


**Caso 3. El préstamo para la tarjeta de Gael**

Gael quiere pedir un préstamo por app para pagar su tarjeta.
- *¿Qué revisa?* Si es más barato, si está registrado y si dejará de usar la tarjeta. Si no, no lo pide.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar el día a día con crédito | La deuda crece cada mes | Usa tu fondo de sequía |
| Comprar auto con tarjeta | Intereses muy altos | Usa un crédito automotriz |
| Pedir un crédito para pagar otro | Mueves la deuda | Solo si es más barato y dejas de usar el anterior |
| Acumular pagos pequeños | Deuda grande sin darte cuenta | Suma tus pagos a plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué crédito es revolvente? a) El hipotecario · b) La tarjeta de crédito · c) El automotriz para comprar un auto
2. ¿Qué conviene para comprar equipo de trabajo planeado? a) Préstamo por app · b) Pagar solo el mínimo de la tarjeta de crédito hasta que alcance para todo · c) Crédito simple con CAT bajo o MSI que quepan en tu presupuesto
3. No te alcanza para la renta este mes. ¿Qué haces primero? a) Usar tu fondo de sequía · b) Pedir un préstamo por app · c) Empeñar tu equipo de trabajo
**Respuestas:** 1-b: la línea se usa y se vuelve a usar. 2-c: pagos fijos y costo menor. 3-a: el crédito no resuelve un faltante del día a día.



#### Ponlo en práctica

Lista tus créditos actuales y escribe para qué los usaste. ¿Alguno es del tipo equivocado?
**Respuesta:** Por ejemplo: tarjeta usada para renta (equivocado), crédito simple para cámara (correcto), MSI de celular (correcto). Voy a dejar de pagar renta con tarjeta.



#### A tu plan

Escribe tu regla personal: "Nunca uso crédito para…" y pégala en tu cartera.



### Para saber más

- **Comparativos de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** comparativos de crédito personal, automotriz e hipotecario.
- **Casas de empeño** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** "Registro Público de Casas de Empeño".

### Palabras clave

- *Crédito revolvente:* línea que usas y vuelves a usar.
- *Crédito simple:* monto con pagos fijos hasta terminar.
- *Empeño:* préstamo con una prenda como garantía.

### Fuentes

CONDUSEF · Profeco, consultados el 29 de septiembre de 2026.

---

## M5 U07. Lee el contrato antes de firmar

**Lo que lograrás:** Revisar la carátula, el CAT, las comisiones, los seguros incluidos, las penalizaciones y el registro del contrato en el RECA.

**Para empezar:** Gael firmó un crédito en una tableta, en dos minutos, sin leer. Luego descubrió un seguro de vida obligatorio de 450 al mes y una comisión por pago anticipado. Nadie se lo explicó, pero estaba en el contrato. En esta lección aprenderás qué leer antes de firmar.

### Lo esencial (5 minutos)

#### Cinco cosas que lees siempre

1. **La carátula:** monto, plazo, CAT, tasa, pago y total a pagar.
2. **Las comisiones:** apertura, pago tardío, pago anticipado, cobranza.
3. **Los seguros incluidos:** si son obligatorios y si puedes elegir tu aseguradora.
4. **Qué pasa si te atrasas:** intereses moratorios, cobranza, reporte a Buró.
5. **Cómo cancelar o pagar antes:** si hay penalización.



#### Tómate tu tiempo

Nadie te puede obligar a firmar en ese momento. Pide la carátula y el contrato, llévatelos, léelos en casa o compáralos en el RECA de CONDUSEF.

Si te presionan con "la oferta es solo hoy", es señal de alerta.



#### Pregunta y pide por escrito

Si algo no está claro, pregunta. Si te prometen algo que no está escrito ("ese seguro lo quitamos después"), pide que lo pongan por escrito.



#### Un caso en un minuto

En su siguiente crédito, Gael pidió la carátula antes de firmar. Vio el seguro obligatorio y preguntó si podía usar el suyo. Le dijeron que sí, presentando la póliza. Se ahorró 450 al mes.

> **Idea clave:** lo que firmas es lo que vale. Lo que te prometen de palabra, no.



#### Comprueba lo que entendiste

1. ¿Qué documento resume lo más importante de un crédito?
*Respuesta:* La carátula.

2. Te dicen "firma ya, la oferta es solo hoy". ¿Qué haces?
*Respuesta:* Pides tiempo para leer; la presión es señal de alerta.


#### Para recordar

- Lee carátula, comisiones, seguros, atrasos y cancelación.
- Pide tiempo y documentos.
- Lo prometido, por escrito.



### Profundiza (5 minutos más)

#### Carátula de ejemplo

| Dato | Crédito de Gael |
|---|---|
| Monto | 40,000 |
| Plazo | 18 meses |
| CAT | Anotado en la carátula, sin IVA |
| Pago mensual | 2,950 |
| Total a pagar | 53,100 |
| Comisión por apertura | 1,200 |
| Seguro | Vida, 450 al mes, obligatorio, puede ser externo |



#### El RECA

En el Registro de Contratos de Adhesión de CONDUSEF puedes leer el contrato de muchos productos antes de ir a la institución. Compara lo que te dan con lo registrado.



#### Contratos en tableta o app

Firmar en pantalla vale igual que en papel. Pide que te envíen copia del contrato y la carátula a tu correo antes de aceptar, y guárdalos.



#### Pagar antes

Tienes derecho a hacer pagos anticipados, y la institución debe informarte si los aplica a reducir el plazo o el monto de los pagos; muchas veces puedes elegir.

Una comisión por pago anticipado solo se puede cobrar si está pactada en tu contrato y registrada ante las autoridades. En créditos hipotecarios para vivienda está prohibida, salvo que al contratar te hayan dado a elegir entre un producto con esa comisión y otro sin ella.

> **Dato vigente:** Ley para la Transparencia y Ordenamiento de los Servicios Financieros, Circular 22/2010 del Banco de México (modificada por la Circular 8/2016) y Registro de Comisiones de CONDUSEF. Consultado el 29 de septiembre de 2026 a través del Banco de México y CONDUSEF. Revisa en tu carátula si tu crédito tiene comisión por pago anticipado.



#### Casos


**Caso 1. El seguro de Gael**

El crédito de Gael incluye un seguro de vida obligatorio de 450 al mes.
- *¿Qué pregunta?* Si puede usar una póliza propia más barata que cumpla los requisitos.


**Caso 2. La presión a Renata**

A Renata le dicen que firme en ese momento porque "la tasa sube mañana".
- *¿Qué hace?* Pide la carátula y el contrato, y se toma el tiempo para leerlos y comparar.


**Caso 3. La promesa a Toño**

Un ejecutivo le promete a Toño que "después le bajan la tasa".
- *¿Qué hace?* Pide que esa promesa quede por escrito en el contrato; si no, no cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin leer | Sorpresas caras | Lee la carátula y el contrato |
| Aceptar promesas de palabra | No valen | Pide todo por escrito |
| Firmar por presión | Decides mal | Pide tiempo |
| No guardar copia | No puedes reclamar | Guarda contrato y carátula |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué dato de la carátula te dice todo lo que pagarás? a) El logotipo · b) El total a pagar · c) La sucursal donde firmas
2. Te prometen de palabra que quitan un seguro. ¿Qué haces? a) Confías · b) Pides que quede por escrito · c) Firmas y reclamas después
3. ¿Dónde puedes leer contratos registrados de productos financieros? a) En el SAT · b) En las redes del banco · c) En el RECA de CONDUSEF
**Respuestas:** 1-b: incluye pagos y costos. 2-b: lo escrito es lo que vale. 3-c: es el registro oficial.



#### Ponlo en práctica

Toma el contrato o la carátula de un crédito que tengas y encuentra: CAT, total a pagar, comisiones y seguros incluidos.
**Respuesta:** Por ejemplo: CAT anotado en la carátula; total 53,100; apertura 1,200 y pago tardío 350; seguro de vida obligatorio que puedo sustituir.



#### A tu plan

Guarda en una carpeta la carátula y el contrato de cada crédito que tienes.



### Para saber más

- **RECA** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Registro de Contratos de Adhesión" y el producto que quieres revisar.
- **Tus derechos al contratar** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre crédito y lo que te deben informar.

### Palabras clave

- *Carátula:* resumen de las condiciones del crédito.
- *Pago anticipado:* pagar antes de lo pactado.
- *Interés moratorio:* interés extra por pagar tarde.

### Fuentes

CONDUSEF · Ley para la Transparencia y Ordenamiento de los Servicios Financieros, consultados el 29 de septiembre de 2026.

---


---

# Módulo 6. El crédito es deuda

## M6 U01. Tu línea de crédito no es tu ingreso

**Lo que lograrás:** Entender que tu línea de crédito es dinero prestado que pagarás con tus ingresos futuros, y que un aumento de línea no es un aumento de sueldo.

**Para empezar:** Renata suma las líneas de sus seis tarjetas y dice: "Tengo 180,000 disponibles". Cuando le suben la línea, lo celebra como si le hubieran pagado un evento. Hoy debe 95,000 y no sabe cómo llegó ahí. En esta lección aprenderás a ver el crédito como lo que es: deuda.

### Lo esencial (5 minutos)

#### Disponible no es tuyo

La **línea de crédito** es el máximo que te prestan. El "disponible" es cuánto más te pueden prestar hoy.

Nada de eso es tu dinero. Cada peso que usas lo pagarás después, con intereses si no liquidas a tiempo.



#### Tu dinero y el dinero prestado

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu ingreso | Lo que cobras por tu trabajo. | Es tuyo. |
| Tu ahorro | Lo que ya juntaste. | Es tuyo. |
| Tu línea de crédito | Lo que te prestan. | Es deuda. |
| Un aumento de línea | Te prestan más. | No te pagan más. |

#### La pregunta antes de pasar la tarjeta

Antes de usar crédito, pregunta: **¿con qué ingreso lo voy a pagar y cuándo?**

Si no tienes la respuesta, no lo uses.



#### Un caso en un minuto

Renata dejó de decir "tengo 180,000" y empezó a decir "debo 95,000". Guardó cuatro tarjetas en un cajón y se quedó con dos.

Antes de cada compra se pregunta con qué pago la va a cubrir.

> **Idea clave:** el crédito no es dinero extra. Es un adelanto de tus ingresos futuros.



#### Comprueba lo que entendiste

1. Tu tarjeta tiene 30,000 disponibles. ¿Cuánto dinero tuyo es?
*Respuesta:* Nada. Es lo que te pueden prestar.

2. Te suben la línea. ¿Ganas más?
*Respuesta:* No. Solo te pueden prestar más.


#### Para recordar

- La línea es deuda posible.
- El disponible no es tuyo.
- Pregunta con qué ingreso lo pagarás.



### Profundiza (5 minutos más)

#### Aumentos de línea que no pediste

Los bancos ofrecen aumentos de línea como algo bueno. Puedes rechazarlos. Si te cuesta controlar tu gasto, una línea más baja te protege.



#### Las tarjetas de Renata

| Tarjeta | Línea | Deuda |
|---|---|---|
| Banco 1 | 50,000 | 32,000 |
| Banco 2 | 40,000 | 28,000 |
| Tienda | 25,000 | 15,000 |
| SOFOM | 30,000 | 12,000 |
| Otras dos | 35,000 | 8,000 |
| **Total** | **180,000** | **95,000** |

Renata "tenía 85,000 disponibles", pero en realidad debía 95,000.



#### No es un tema de culpa

Muchas personas del medio usan crédito porque sus ingresos son irregulares y nadie les explicó cómo funciona. Lo importante es cambiar la forma de verlo desde hoy.



#### Una regla sencilla

Usa la tarjeta solo para compras que puedas pagar completas en la fecha límite con dinero que ya tienes en tu cuenta de gastos.

> **Dato adicional:** CONDUSEF recomienda no usar más de una parte de tu línea y pagar el total cada mes para no generar intereses. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. El disponible de Renata**

Renata dice que tiene 180,000 disponibles.
- *¿Qué debería decir?* Que debe 95,000 y que le pueden prestar más, no que tiene ese dinero.


**Caso 2. El aumento de Gael**

El banco le ofrece a Gael subir su línea de 30,000 a 60,000.
- *¿Qué considera?* Que no es más dinero, sino más deuda posible. Puede rechazarlo si le cuesta controlarse.


**Caso 3. La cena de Valeria**

Valeria quiere pagar una cena de 4,000 con tarjeta y no tiene pagos por cobrar este mes.
- *¿Qué se pregunta?* Con qué ingreso la va a pagar y cuándo. Si no lo sabe, no la paga con crédito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sumar líneas como si fueran dinero | Gastas lo que no tienes | Suma tus deudas |
| Celebrar aumentos de línea | Más deuda posible | Recházalos si no los necesitas |
| Usar crédito sin plan de pago | Intereses y atrasos | Pregunta con qué pagarás |
| Tener muchas tarjetas | Pierdes control | Quédate con pocas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu línea es 40,000 y debes 15,000. ¿Cuánto dinero tuyo hay ahí? a) 25,000 · b) 40,000 · c) Nada
2. Te suben la línea. ¿Qué significa? a) Te pueden prestar más · b) Te pagan más · c) Ya no tienes deuda
3. ¿Qué pregunta haces antes de usar crédito? a) ¿Cuántos puntos gano? · b) ¿Cuánto disponible me queda después de esta compra? · c) ¿Con qué ingreso lo pagaré y cuándo?
**Respuestas:** 1-c: el disponible es crédito, no dinero tuyo. 2-a: es más deuda posible. 3-c: sin plan de pago no conviene.



#### Ponlo en práctica

Suma las líneas y las deudas de todas tus tarjetas y créditos. ¿Cuánto debes en total?
**Respuesta:** Por ejemplo: líneas 120,000; deudas 48,000. No "tengo 72,000 disponibles": debo 48,000.



#### A tu plan

Guarda las tarjetas que no necesitas y escribe tu regla para usar crédito.



### Para saber más

- **Tarjetas de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para el uso responsable de la tarjeta de crédito.
- **Comparativo de tarjetas** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** indicadores de tarjetas de crédito.

### Palabras clave

- *Línea de crédito:* máximo que te pueden prestar.
- *Disponible:* cuánto más te pueden prestar hoy.
- *Deuda:* dinero que debes pagar.

### Fuentes

CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M6 U02. Pago mínimo, pago para no generar intereses y fechas clave

**Lo que lograrás:** Leer tu estado de cuenta, conocer las fechas y los tipos de pago, y ver cuánto cuesta pagar solo el mínimo.

**Para empezar:** Gael debe 20,000 en su tarjeta y paga cada mes "lo que le piden", alrededor de 1,000. Lleva dos años y la deuda casi no baja. En esta lección aprenderás qué significa cada número de tu estado de cuenta y por qué el mínimo te atrapa.

### Lo esencial (5 minutos)

#### Tres pagos en tu estado de cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pago mínimo | Lo menos que puedes pagar para no atrasarte. | La deuda casi no baja. |
| Pago para no generar intereses | Lo que pagas para no pagar intereses ese mes. | La mejor opción. |
| Saldo total | Todo lo que debes, incluidas mensualidades futuras. | Para liquidar. |

#### Dos fechas clave

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fecha de corte | Día en que cierra tu periodo y se calcula lo que debes. | Compras después entran al siguiente. |
| Fecha límite de pago | Último día para pagar sin atraso. | Pon recordatorio. |

#### Lo que cuesta pagar poco

Deuda de 20,000 con interés de 4% mensual más IVA, sin nuevas compras.

| Pago cada mes | Meses para terminar | Total que pagas |
|---|---|---|
| 1,000 | 59 | 58,010 |
| 2,000 | 14 | 27,508 |

Pagar el doble cada mes te ahorra más de 30,000 y cuatro años.



#### Un caso en un minuto

Gael vio la tabla y subió su pago a 2,000 al mes, recortando otros gastos. Dejó de usar la tarjeta mientras la paga.

En catorce meses terminará, en lugar de casi cinco años.

> **Idea clave:** pagar solo el mínimo te mantiene al corriente, pero te hace pagar mucho más.



#### Comprueba lo que entendiste

1. ¿Qué pago evita los intereses del mes?
*Respuesta:* El pago para no generar intereses.

2. ¿Qué pasa si pagas solo el mínimo?
*Respuesta:* No te atrasas, pero la deuda baja muy lento y pagas muchos intereses.


#### Para recordar

- Mínimo: evita atraso, no intereses.
- Pago para no generar intereses: el ideal.
- Conoce tu fecha de corte y tu fecha límite.



### Profundiza (5 minutos más)

#### Cómo se calcula el pago mínimo

El Banco de México fija la regla: el pago mínimo es la cantidad mayor entre (a) 1.5% del saldo más los intereses del periodo y su IVA, y (b) 1.25% de tu línea de crédito. Así cubres los intereses y un poco de la deuda, pero muy poco.

> **Dato vigente:** reglas de tarjetas de crédito del Banco de México sobre el pago mínimo. Consultado el 29 de septiembre de 2026 a través del Banco de México. Tu estado de cuenta muestra el cálculo de tu pago mínimo.



#### Tu estado de cuenta dice cuánto tardarás

Muchos estados de cuenta muestran cuánto tiempo tardarías en pagar si solo cubres el mínimo. Búscalo: es la mejor motivación para pagar más.



#### Cómo usar la fecha de corte

Si compras justo después de tu fecha de corte, esa compra entra en el siguiente periodo y tienes más días para pagarla. Si compras justo antes, la pagas pronto.

No es una forma de gastar más: solo de organizar tus pagos.



#### Evita atrasos

Pon recordatorios unos días antes de la fecha límite. Programa el pago automático al menos del mínimo, y paga más manualmente cuando puedas.

Un atraso genera intereses moratorios, comisiones y se reporta a Buró y Círculo de Crédito (M7).



#### Casos


**Caso 1. Los dos años de Gael**

Gael paga 1,000 al mes de una deuda de 20,000 y casi no baja.
- *¿Qué hace?* Sube su pago a 2,000 si cabe en su presupuesto y deja de usar la tarjeta mientras la paga.


**Caso 2. El estado de cuenta de Valeria**

Valeria ve tres cantidades y no sabe cuál pagar.
- *¿Cuál conviene?* El pago para no generar intereses. Si no puede, al menos el mínimo y lo más posible por encima.


**Caso 3. La fecha límite de Toño**

Toño olvida la fecha límite y se atrasa dos días.
- *¿Qué pasa y qué hace?* Le cobran intereses y comisión, y puede reportarse. Paga de inmediato y programa recordatorios.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar solo el mínimo | Pagas el triple | Paga lo más posible |
| No conocer la fecha límite | Atrasos | Pon recordatorios |
| Seguir comprando mientras pagas | La deuda no baja | Pausa la tarjeta |
| Ignorar el estado de cuenta | No ves el costo | Léelo cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pago te evita pagar intereses ese mes? a) Pago mínimo · b) Cualquier pago, aunque sea menor al mínimo · c) Pago para no generar intereses
2. ¿Qué fecha marca el último día para pagar sin atraso? a) Fecha de corte · b) Fecha límite de pago · c) Fecha de emisión
3. Deuda de 20,000 al 4% mensual más IVA. Pagando 1,000 al mes, ¿cuánto pagas en total? a) Unos 58,000 · b) Unos 20,000 · c) Unos 24,000
**Respuestas:** 1-c: cubre las compras del periodo. 2-b: después hay atraso. 3-a: casi el triple por pagar poco.



#### Ponlo en práctica

Toma tu último estado de cuenta y anota: fecha de corte, fecha límite, pago mínimo, pago para no generar intereses y saldo total.
**Respuesta:** Por ejemplo: corte día 5, límite día 25, mínimo 850, para no generar intereses 6,200, saldo total 18,400.



#### A tu plan

Programa recordatorios cinco días antes de cada fecha límite y decide cuánto pagarás por encima del mínimo.



### Para saber más

- **Cómo leer tu estado de cuenta** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre el estado de cuenta de la tarjeta de crédito.
- **Tarjetas de crédito** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "Pago mínimo" y cómo funciona.

### Palabras clave

- *Pago mínimo:* lo menos que puedes pagar para no atrasarte.
- *Pago para no generar intereses:* lo que evita intereses del periodo.
- *Fecha de corte:* cierre del periodo de tu tarjeta.
- *Fecha límite de pago:* último día para pagar sin atraso.

### Fuentes

Banco de México · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M6 U03. Meses sin intereses: cuándo ayudan y cuándo te atrapan

**Lo que lograrás:** Usar los meses sin intereses solo en compras planeadas y sumar todas tus mensualidades antes de agregar otra.

**Para empezar:** Valeria tiene siete compras a meses sin intereses: celular, laptop, aro de luz, ropa, un viaje, unos audífonos y un sillón. Cada una "es poquito". Juntas suman 9,800 al mes, y en los meses sin campañas no le alcanza. En esta lección aprenderás a usarlos sin que te atrapen.

### Lo esencial (5 minutos)

#### Sin intereses no es sin deuda

Los **meses sin intereses** (MSI) reparten una compra en pagos iguales. No pagas intereses si cumples, pero sí es deuda: te comprometes a pagar cada mes.



#### Las mensualidades de Valeria

Lo que paga Valeria cada mes por sus MSI.
- Laptop y celular: **3,200**
- Viaje y sillón: **2,400**
- Ropa, aro de luz y audífonos: **4,200**
- Lo que ya debe pagar cada mes: **9,800**
Eso, antes de su renta y su comida.


#### Cuándo sí y cuándo no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sí | Equipo de trabajo que ya planeabas y cuyo pago cabe en tu mes bajo. | Buena herramienta. |
| No | Gastos que se acaban antes que los pagos: ropa, salidas, viajes. | Deuda sin beneficio. |
| No | Cuando ya tienes varias mensualidades. | Suma antes. |

#### Un caso en un minuto

Valeria hizo la suma y se asustó. Decidió no agregar ninguna compra a MSI hasta terminar tres de las que tiene.

Para su siguiente equipo, esperó a tener la mitad ahorrada y solo difirió el resto.

> **Idea clave:** antes de una compra a MSI, suma todas tus mensualidades y compáralas con tu mes bajo.



#### Comprueba lo que entendiste

1. ¿Los MSI son deuda?
*Respuesta:* Sí. No generan intereses si pagas a tiempo, pero te comprometen cada mes.

2. ¿Qué compras no conviene diferir?
*Respuesta:* Las que se acaban antes que los pagos, como ropa, salidas o viajes.


#### Para recordar

- Sin intereses no es sin deuda.
- Suma tus mensualidades.
- Solo compras planeadas que caben en tu mes bajo.



### Profundiza (5 minutos más)

#### Lo que pasa si te atrasas

Si no pagas a tiempo, puedes perder el beneficio o pagar intereses y comisiones, según tu contrato. Además, las mensualidades pendientes reducen tu línea disponible.

> **Antes de actuar, verifica:** en tu contrato qué pasa con tus compras a MSI si te atrasas o pagas menos del pago para no generar intereses. Cada banco tiene sus reglas.



#### "Compra ahora, paga después"

Algunas apps y tiendas te dejan pagar en quincenas "sin tarjeta". Funcionan parecido: son deuda. Suma esos pagos con tus MSI.



#### Calendario de mensualidades de Valeria

| Compra | Pago | Termina en |
|---|---|---|
| Celular | 1,200 | 4 meses |
| Laptop | 2,000 | 10 meses |
| Viaje | 1,500 | 5 meses |
| Sillón | 900 | 8 meses |
| Ropa, aro de luz y audífonos | 4,200 | 3 a 6 meses |

Saber cuándo termina cada una te ayuda a planear y a no agregar nuevas antes de tiempo.



#### El precio de contado

A veces el precio a MSI es más alto que el de contado. Pregunta siempre el precio de contado y compara.



#### Casos


**Caso 1. Las siete compras de Valeria**

Valeria paga 9,800 al mes de MSI y quiere agregar una cámara.
- *¿Qué hace?* No la agrega hasta terminar algunas mensualidades o juntar parte del dinero.


**Caso 2. El viaje de Renata**

Renata quiere pagar un viaje de fin de semana a 12 MSI.
- *¿Le conviene?* No: el viaje termina mucho antes que los pagos.


**Caso 3. El micrófono de Toño**

Toño necesita un micrófono de 12,000 para trabajar y no tiene otras mensualidades.
- *¿Puede usar MSI?* Sí, si el pago cabe en su mes bajo y el precio es igual al de contado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Diferir todo | Mensualidades que no caben | Suma antes de comprar |
| Diferir lo que se acaba pronto | Pagas algo que ya no tienes | Solo compras duraderas |
| No preguntar el precio de contado | Pagas más | Compara |
| Atrasarte en un MSI | Pierdes el beneficio | Paga a tiempo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué compra conviene más a MSI? a) Una cena · b) Equipo de trabajo planeado · c) Un viaje de fin de semana
2. Tienes mensualidades de 1,500, 2,000 y 800. ¿Cuánto pagas al mes? a) 2,000 · b) 4,300 · c) 3,500
3. ¿Qué preguntas antes de comprar a MSI? a) El color de la caja · b) El precio de contado · c) Cuántos puntos te dan
**Respuestas:** 1-b: dura más que los pagos y te genera ingreso. 2-b: 1,500 + 2,000 + 800. 3-b: a veces el precio a MSI es más alto.



#### Ponlo en práctica

Lista todas tus compras a MSI y "compra ahora, paga después": pago mensual y mes en que terminan. ¿Cuánto suman?
**Respuesta:** Por ejemplo: celular 900 (5 meses), laptop 1,800 (9 meses), tenis 400 (2 meses). Total 3,100 al mes. No agrego otra hasta que terminen los tenis y el celular.



#### A tu plan

Haz tu calendario de mensualidades y pégalo junto a tu presupuesto.



### Para saber más

- **Meses sin intereses** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre compras a meses y cómo afectan tu línea.
- **Profeco** (Gobierno de México · español): https://www.gob.mx/profeco — **Qué buscar:** tus derechos en compras a plazos en tiendas.

### Palabras clave

- *Meses sin intereses:* compra en pagos iguales sin intereses si pagas a tiempo.
- *Mensualidad:* pago fijo de cada mes.
- *Precio de contado:* precio pagando todo de una vez.

### Fuentes

CONDUSEF · Profeco, consultados el 29 de septiembre de 2026.

---

## M6 U04. Tu inventario de deudas

**Lo que lograrás:** Listar cada deuda con institución, tipo, saldo, costo, pago, fecha y atraso para saber exactamente cuánto debes.

**Para empezar:** Toño no sabe cuánto debe. Tiene una tarjeta, un préstamo de nómina de cuando trabajaba en la disquera, un crédito de una tienda de música y un préstamo que le hizo su hermano. Cada vez que le preguntan dice "como 80,000". En esta lección harás tu inventario de deudas.

### Lo esencial (5 minutos)

#### No puedes resolver lo que no ves

El primer paso para salir de deudas es verlas todas juntas en una lista. Muchas personas se sorprenden: a veces deben más de lo que creían, y a veces menos.



#### Qué anotas de cada deuda

| Dato | Dónde lo encuentras |
|---|---|
| Institución y tipo de entidad | Contrato o estado de cuenta |
| Tipo de crédito | Tarjeta, personal, tienda, app, familiar |
| Saldo | Estado de cuenta o app |
| CAT o tasa | Carátula o estado de cuenta |
| Pago mensual | Estado de cuenta |
| Fecha límite | Estado de cuenta |
| ¿Hay atraso? | Estado de cuenta o reporte de crédito |



#### Usa tus reportes de crédito

Tus reportes de Buró y Círculo de Crédito muestran las deudas reportadas a tu nombre. Úsalos para no olvidar ninguna y para detectar créditos que no reconoces (M7 U03).



#### Un caso en un minuto

Toño juntó sus estados de cuenta y pidió sus reportes gratis. Su lista sumó 92,000, no 80,000. También encontró un crédito de tienda que creía liquidado y seguía con saldo.

Con la lista, por fin pudo hacer un plan (M8).

> **Idea clave:** tu inventario convierte el miedo en números con los que puedes trabajar.



#### Comprueba lo que entendiste

1. ¿Para qué sirve tu inventario de deudas?
*Respuesta:* Para ver todas tus deudas juntas y hacer un plan.

2. ¿Dónde confirmas las deudas reportadas a tu nombre?
*Respuesta:* En tus reportes de Buró y Círculo de Crédito.


#### Para recordar

- Anota todas, incluidas las familiares.
- Saldo, costo, pago, fecha y atraso.
- Confirma con tus reportes de crédito.



### Profundiza (5 minutos más)

#### El inventario de Toño

| Deuda | Tipo | Saldo | Costo | Pago | Atraso |
|---|---|---|---|---|---|
| Banco A | Tarjeta | 38,000 | Alto | 1,900 | No |
| Banco B | Préstamo de nómina | 24,000 | Medio | 1,600 | No |
| Tienda de música | Crédito de tienda | 12,000 | Alto | 900 | 2 meses |
| Hermano | Familiar | 18,000 | Sin interés | Sin fecha | No |
| **Total** | | **92,000** | | **4,400** | |



#### Las deudas con familia y amigos también cuentan

Aunque no cobren intereses ni aparezcan en tu reporte, son compromisos. Inclúyelas y acuerda un plan por escrito para cuidar la relación.



#### Actualízalo cada mes

Una hoja en tu celular o en papel basta. Actualiza los saldos cada mes. Ver cómo bajan te motiva a seguir.



#### Si encuentras algo que no reconoces

Si en tu reporte aparece un crédito que no pediste, puede ser robo de identidad. Reclama y protege tu historial (M7 U07 y M9 U04).

> **Dato vigente:** reporte de crédito especial gratuito una vez cada 12 meses en Buró de Crédito y en Círculo de Crédito. Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales y CONDUSEF.



#### Casos


**Caso 1. Los 80,000 de Toño**

Toño cree que debe "como 80,000".
- *¿Qué hace para saberlo?* Junta sus estados de cuenta, pide sus reportes de crédito y arma su inventario.


**Caso 2. La deuda familiar de Gael**

Gael le debe 15,000 a su tía y no lo anotó porque "no cobra intereses".
- *¿La incluye?* Sí. Es un compromiso y acuerda un plan por escrito.


**Caso 3. El crédito olvidado de Renata**

En su reporte aparece un crédito de tienda que Renata creía liquidado.
- *¿Qué hace?* Revisa con la tienda y, si ya lo pagó, reclama con su comprobante.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Calcular "más o menos" | No puedes planear | Haz la lista exacta |
| Olvidar deudas familiares | Rompes relaciones | Inclúyelas |
| No revisar tus reportes | Olvidas créditos | Pide tus reportes gratis |
| Hacer la lista una sola vez | Pierdes el avance | Actualízala cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué dato NO necesitas en tu inventario? a) Color de la tarjeta · b) Saldo · c) Fecha límite de pago de cada tarjeta
2. ¿Incluyes la deuda con tu hermano? a) Sí · b) No, porque no cobra intereses · c) Solo si te la cobra
3. ¿Dónde confirmas tus deudas reportadas? a) En redes sociales · b) En tus reportes de Buró y Círculo · c) En tu declaración anual, en la parte de deudas
**Respuestas:** 1-a: no ayuda al plan. 2-a: también es un compromiso. 3-b: ahí aparecen los créditos a tu nombre.



#### Ponlo en práctica

Haz tu inventario con todas tus deudas: institución, tipo, saldo, costo, pago, fecha y atraso. Suma el total.
**Respuesta:** Por ejemplo: tarjeta 25,000; app 6,000; tienda 8,000; amiga 5,000. Total 44,000 y pagos de 3,100 al mes.



#### A tu plan

Pide tus reportes gratis en Buró y Círculo y compáralos con tu inventario.



### Para saber más

- **Reporte de Crédito Especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** "Reporte de Crédito Especial" gratis.
- **Reporte de crédito** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** tu reporte gratis.

### Palabras clave

- *Inventario de deudas:* lista de todo lo que debes.
- *Saldo:* lo que debes hoy.
- *Atraso:* pago que no hiciste a tiempo.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M6 U05. ¿Cuánta deuda aguanta un ingreso variable?

**Lo que lograrás:** Medir tus pagos de deuda contra tu mes bajo, no contra tu mejor mes, y fijar tu límite personal de endeudamiento.

**Para empezar:** Valeria sacó un crédito de auto en un mes en que cobró 90,000. El pago de 8,500 le parecía fácil. En los meses sin campañas, cuando gana 20,000, el auto se come casi la mitad. En esta lección aprenderás a calcular cuánta deuda aguanta tu ingreso real.

### Lo esencial (5 minutos)

#### Mide con tu mes bajo

Tu mes bajo es un mes normal de poco trabajo, no el peor de tu vida ni el mejor. Revisa tus últimos 12 meses y elige uno de los más bajos que se repiten.

Todas tus decisiones de deuda se miden contra ese mes.



#### La cuenta de Valeria

Su mes bajo es de 20,000 de ganancia real.
- Pago del auto: **8,500**
- Otras mensualidades: **3,200**
- Sus pagos de deuda: **11,700**
11,700 ÷ 20,000 = 58% de su mes bajo en deuda.


#### Una guía práctica

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Hasta 20% del mes bajo | Margen cómodo para ingresos variables. | Zona verde. |
| De 20% a 35% | Aguantas, pero sin margen para imprevistos. | Zona amarilla. |
| Más de 35% | Un mes sin trabajo te pone en riesgo. | Zona roja. |

#### Un caso en un minuto

Valeria estaba en zona roja. Vendió el auto, compró uno más barato de contado con la diferencia y liquidó dos mensualidades.

Sus pagos bajaron a 3,000: 15% de su mes bajo.

> **Idea clave:** si la deuda solo cabe en tus meses buenos, no cabe.



#### Comprueba lo que entendiste

1. ¿Con qué mes mides tu capacidad de pago?
*Respuesta:* Con tu mes bajo.

2. Mes bajo de 25,000 y pagos de deuda de 10,000. ¿Qué porcentaje es?
*Respuesta:* 40%: zona roja.


#### Para recordar

- Mide contra tu mes bajo.
- Hasta 20% es cómodo.
- Más de 35% te pone en riesgo.



### Profundiza (5 minutos más)

#### Por qué no el promedio

El promedio mezcla meses buenos y malos. Si pagas deudas con el promedio, en los meses bajos te faltará dinero y usarás más crédito.



#### Antes de pedir un crédito nuevo

| Pregunta | Tu respuesta |
|---|---|
| ¿Cuál es mi mes bajo? | |
| ¿Cuánto pago hoy de deudas? | |
| ¿Cuánto sería el pago nuevo? | |
| ¿Qué porcentaje del mes bajo sumaría? | |
| ¿Tengo fondo de sequía para tres meses? | |

Si el porcentaje pasa de 35% o no tienes fondo, no es buen momento.



#### Lo que ven los bancos

Los bancos revisan tus ingresos y tus deudas, pero muchas veces con tus mejores meses o con lo que declaras. Que te aprueben no significa que te convenga.

> **Dato adicional:** los porcentajes de esta lección son una guía práctica para ingresos variables, no una regla oficial. Úsalos para decidir con prudencia.



#### Si ya estás en zona roja

No pidas más crédito. Revisa qué deuda puedes liquidar o vender, negocia con tus acreedores y arma tu plan de salida (M8).



#### Casos


**Caso 1. El auto de Valeria**

Los pagos de Valeria son 58% de su mes bajo.
- *¿Qué hace?* Reduce su deuda: vende o cambia el auto y liquida mensualidades hasta bajar de 35%.


**Caso 2. El crédito aprobado de Gael**

El banco le aprobó a Gael un crédito con pago de 6,000. Su mes bajo es de 18,000 y ya paga 3,000 de otras deudas.
- *¿Le conviene?* No: sumaría 50% de su mes bajo, aunque el banco lo haya aprobado.


**Caso 3. El promedio de Renata**

Renata calcula su capacidad con su promedio de 35,000, pero su mes bajo es de 15,000.
- *¿Qué cambia?* Debe calcular con 15,000; con el promedio se sobreestima.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Medir con el mejor mes | La deuda no cabe después | Usa tu mes bajo |
| Creer que aprobado es conveniente | Te endeudas de más | Haz tu propia cuenta |
| Pedir crédito sin fondo de sequía | Un mes malo te hunde | Primero el fondo |
| Seguir pidiendo en zona roja | La deuda crece | Arma tu plan de salida |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Mes bajo de 30,000 y pagos de deuda de 6,000. ¿En qué zona estás? a) Amarilla · b) Roja · c) Verde (20%)
2. ¿Con qué mes decides cuánta deuda puedes tener? a) Tu mes bajo · b) El mejor · c) El promedio
3. Te aprueban un crédito que te llevaría a 45% de tu mes bajo. ¿Qué haces? a) Lo aceptas · b) Pides otro crédito más para tener margen · c) No lo tomas o pides menos
**Respuestas:** 1-c: 6,000 es 20% de 30,000. 2-a: así aguantas los meses sin trabajo. 3-c: estarías en zona roja.



#### Ponlo en práctica

Calcula qué porcentaje de tu mes bajo se va en pagos de deuda.
**Respuesta:** Por ejemplo: mes bajo 22,000; pagos 5,500. 25%: zona amarilla. No pediré más crédito hasta bajar de 20%.



#### A tu plan

Escribe tu límite personal de pagos de deuda en pesos, con base en tu mes bajo.



### Para saber más

- **Simuladores de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** calcula el pago antes de pedir un crédito.
- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre endeudamiento responsable.

### Palabras clave

- *Mes bajo:* un mes normal de poco trabajo.
- *Capacidad de pago:* lo que puedes pagar sin ponerte en riesgo.
- *Endeudamiento:* qué parte de tu ingreso se va en deudas.

### Fuentes

CONDUSEF · Guía práctica del programa para ingresos variables.

---

## M6 U06. No uses la tarjeta para vivir la sequía

**Lo que lograrás:** Diferenciar una emergencia de un faltante recurrente y usar primero el fondo de sequía, no el crédito.

**Para empezar:** Gael pagó la renta y el súper de cuatro meses sin llamados con la tarjeta. Pensaba que al llegar la siguiente serie lo pagaría todo. La serie llegó tarde y pagó menos de lo esperado. Hoy debe 60,000. En esta lección aprenderás qué hacer en lugar de financiar la sequía con crédito.

### Lo esencial (5 minutos)

#### La sequía se repite; la emergencia no

Una **emergencia** es algo que no esperabas: un accidente, una reparación urgente. Un **faltante recurrente** es no tener dinero para tu vida diaria en los meses sin trabajo.

Financiar un faltante recurrente con crédito no lo resuelve: lo convierte en deuda con intereses.



#### Qué usar primero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fondo de sequía | Para tus gastos básicos sin trabajo. | Primera opción. |
| Recorte de gastos | Pausa lo que no es básico. | Segunda opción. |
| Ingreso puente | Clases, doblaje, eventos, talleres. | Tercera opción. |
| Crédito | Solo emergencias reales y con plan de pago. | Último recurso. |

#### Lo que le costó a Gael

Cuatro meses de gastos con tarjeta.
- Gastos por mes: **18,000**
- Meses sin trabajo: **4**
- Lo que puso en la tarjeta: **72,000**
Con intereses y lo que ya pagó, hoy debe 60,000 y seguirá pagando por meses.


#### Un caso en un minuto

En la siguiente sequía, Gael tenía 30,000 de fondo, pausó salidas y suscripciones, y dio clases de actuación los sábados.

Aguantó tres meses sin usar la tarjeta. Mientras tanto, siguió pagando su deuda anterior.

> **Idea clave:** en la sequía, primero tu fondo, luego recortes e ingresos puente. El crédito es el último recurso.



#### Comprueba lo que entendiste

1. ¿Pagar la renta con tarjeta en los meses sin trabajo es una emergencia?
*Respuesta:* No. Es un faltante recurrente que se prepara con el fondo de sequía.

2. ¿Qué usas primero en la sequía?
*Respuesta:* Tu fondo de sequía.


#### Para recordar

- La sequía se prepara, no se financia.
- Fondo, recortes, ingreso puente.
- Crédito solo para emergencias reales.



### Profundiza (5 minutos más)

#### Ideas de ingreso puente

Clases particulares, talleres, doblaje, locución, eventos privados, coros, maquillaje, fotografía, edición de video, trabajo técnico en otras producciones.

Tu talento sirve para más de una cosa. Un ingreso puente pequeño reduce mucho lo que sacas del fondo.



#### Recortes de temporada baja

| Gasto | Temporada alta | Temporada baja |
|---|---|---|
| Salidas | 3,000 | 800 |
| Suscripciones | 900 | 300 |
| Ropa | 2,000 | 0 |
| Gimnasio | 900 | 400 (plan básico) |
| **Ahorro al mes** | | **5,300** |



#### Si ya no alcanza

Si se acaba tu fondo y aún no hay trabajo, habla con tus acreedores antes de atrasarte: pregunta por reestructuras o convenios (M8 U02). Es mejor negociar antes que caer en atraso.



#### Evita las soluciones rápidas caras

Préstamos por app sin registro, empeñar tu equipo de trabajo o pedir a prestamistas informales pueden salir mucho más caros que el problema (M9 U06).

> **Dato adicional:** CONDUSEF recomienda no usar la tarjeta de crédito para gastos corrientes cuando no tienes con qué pagarla. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. La siguiente sequía de Gael**

Gael entra a tres meses sin llamados con 30,000 de fondo.
- *¿Qué hace primero?* Usa su fondo, recorta gastos no básicos y busca un ingreso puente, sin usar la tarjeta.


**Caso 2. La cámara de Toño**

A Toño se le descompone la cámara con la que trabaja y no tiene fondo suficiente.
- *¿Es una emergencia?* Sí: puede usar crédito con un plan de pago claro, después de comparar opciones.


**Caso 3. La app de Renata**

Renata no tiene para la renta y piensa en un préstamo por app.
- *¿Qué hace antes?* Habla con su casero, recorta gastos y busca ingreso puente; si pide crédito, lo verifica y compara.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Financiar la sequía con tarjeta | Deuda que crece cada mes | Usa tu fondo |
| No recortar en temporada baja | El fondo se acaba rápido | Ajusta gastos |
| Esperar sin buscar ingreso puente | Más meses sin dinero | Usa tu talento de otras formas |
| Recurrir a prestamistas informales | Costos y riesgos altos | Negocia primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es un faltante recurrente? a) Un accidente · b) No tener para tu vida diaria en los meses sin trabajo · c) Una reparación urgente del auto que usas para ir a tus llamados
2. ¿Qué usas primero en la sequía? a) La tarjeta · b) Tu fondo de sequía · c) Un préstamo por app
3. Se acaba tu fondo y no hay trabajo. ¿Qué haces antes de atrasarte? a) Dejas de pagar sin avisar · b) Pides a un prestamista informal · c) Hablas con tus acreedores
**Respuestas:** 1-b: se repite y se prepara. 2-b: para eso existe. 3-c: negociar antes evita atrasos.



#### Ponlo en práctica

Escribe tu plan de sequía: cuánto tienes de fondo, qué recortas y qué ingreso puente puedes buscar.
**Respuesta:** Por ejemplo: fondo 36,000 (2 meses); recorto salidas y ropa, 4,000 al mes; doy clases de canto los sábados, 3,000 al mes. Aguanto casi 3 meses sin crédito.



#### A tu plan

Escribe tres ideas de ingreso puente que puedas activar en tu próxima temporada baja.



### Para saber más

- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre uso responsable de la tarjeta.
- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo evitar préstamos fraudulentos en temporadas difíciles.

### Palabras clave

- *Faltante recurrente:* no tener dinero para tu vida diaria en meses sin trabajo.
- *Ingreso puente:* trabajo temporal mientras llega tu siguiente proyecto.
- *Emergencia:* gasto urgente que no esperabas.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


---

# Módulo 7. Buró y Círculo de Crédito

## M7 U01. ¿Qué son el Buró y el Círculo de Crédito?

**Lo que lograrás:** Entender que son sociedades de información crediticia que guardan tu historial, no una "lista negra" ni quienes deciden si te prestan.

**Para empezar:** Toño dice que está "boletinado en Buró" y que por eso nunca le van a prestar. Cree que el Buró es una lista de personas castigadas. En realidad, el Buró guarda su historial, bueno y malo, y quien decide si le presta es cada institución. En esta lección entenderás qué es y qué no es.

### Lo esencial (5 minutos)

#### Guardan tu historial, no te castigan

El Buró de Crédito y el Círculo de Crédito son **sociedades de información crediticia**. Reciben de bancos, tiendas y otras instituciones la información de tus créditos: cuánto debes y cómo pagas.

Todas las personas con algún crédito tienen historial. Estar en Buró no es malo por sí mismo.



#### Lo que son y lo que no son

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sí son | Bases de datos con tu historial de crédito. | Lo bueno y lo malo. |
| No son | Una lista negra de personas castigadas. | No existe tal lista. |
| No hacen | No prestan dinero ni aprueban o rechazan créditos. | Decide cada institución. |
| Sí dan | Tu reporte y la posibilidad de reclamar errores. | Gratis una vez al año. |

#### Solo con tu autorización

Una institución solo puede consultar tu historial si tú lo autorizas, normalmente al pedir un crédito. Cada consulta queda registrada en tu reporte.



#### Un caso en un minuto

Toño pidió su reporte. Vio que tenía un atraso de hace años, pero también dos créditos pagados puntualmente.

Entendió que no estaba "boletinado": tenía un historial con cosas buenas y malas, y podía mejorarlo.

> **Idea clave:** un buen historial abre puertas; uno malo se puede mejorar con el tiempo.



#### Comprueba lo que entendiste

1. ¿El Buró de Crédito presta dinero?
*Respuesta:* No. Guarda tu historial; decide cada institución.

2. ¿Estar en Buró es malo?
*Respuesta:* No por sí mismo. Depende de cómo pagas.


#### Para recordar

- Guardan tu historial, bueno y malo.
- No existe una lista negra.
- Decide cada institución.



### Profundiza (5 minutos más)

#### Quién las regula

Las sociedades de información crediticia operan con autorización de la Secretaría de Hacienda, siguen las reglas del Banco de México y las supervisa la CNBV. Su marco es la Ley para Regular las Sociedades de Información Crediticia.

> **Dato vigente:** marco legal de las sociedades de información crediticia (Ley para Regular las Sociedades de Información Crediticia y Circular 27/2008 del Banco de México). Consultado el 29 de septiembre de 2026 a través del Banco de México, la CNBV y CONDUSEF.



#### Un historial bueno también existe

Pagar a tiempo tarjetas, créditos de nómina, de tienda o hasta algunos servicios puede construir un historial positivo. Ese historial te ayuda a conseguir mejores condiciones.



#### Si no tienes historial

No tener historial no es malo, pero dificulta obtener crédito. Si lo necesitas, empieza con un producto pequeño que puedas pagar completo cada mes.



#### Mitos comunes

- "Me borran si pago": no, el registro se queda un tiempo (M7 U06).
- "Hay despachos que me sacan": no, es fraude (M7 U09).
- "Consultar mi reporte me baja el score": pedir tu propio reporte no afecta.



#### Casos


**Caso 1. El "boletín" de Toño**

Toño cree que está boletinado y que nunca le prestarán.
- *¿Qué le explicas?* Que el Buró guarda su historial, no castiga, y que puede mejorarlo pagando a tiempo.


**Caso 2. El primer crédito de Valeria**

Valeria nunca ha tenido crédito y le niegan una tarjeta.
- *¿Por qué pasa?* No tiene historial. Puede empezar con un producto pequeño que pague completo cada mes.


**Caso 3. La consulta de Renata**

Renata teme pedir su reporte porque "le baja el score".
- *¿Es cierto?* No. Consultar tu propio reporte no afecta tu historial.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer en la lista negra | No intentas mejorar | Pide tu reporte |
| Pensar que el Buró decide | Culpas al lugar equivocado | Decide cada institución |
| No pedir tu reporte por miedo | No sabes qué hay | Pídelo gratis |
| Creer que pagar borra todo | Te frustras | Conoce los plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué hace el Buró de Crédito? a) Presta dinero · b) Castiga a quien no paga sus créditos · c) Guarda tu historial de crédito
2. ¿Quién decide si te dan un crédito? a) El Buró · b) La institución a la que se lo pides · c) CONDUSEF, después de revisar tu historial completo
3. ¿Consultar tu propio reporte baja tu score? a) Sí · b) No · c) Solo la primera vez
**Respuestas:** 1-c: es una base de datos. 2-b: cada institución decide. 3-b: tu propia consulta no te afecta.



#### Ponlo en práctica

Escribe lo que creías del Buró antes de esta lección y lo que sabes ahora.
**Respuesta:** Por ejemplo: "Creía que era una lista negra. Ahora sé que es mi historial y que puedo pedirlo gratis y mejorarlo."



#### A tu plan

Anota la fecha en que pedirás tus reportes gratis de Buró y Círculo (M7 U03).



### Para saber más

- **¿Qué es el Buró de Crédito?** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre sociedades de información crediticia.
- **Buró de Crédito** (sitio oficial · español): https://www.burodecredito.com.mx — **Qué buscar:** "Personas" y cómo funciona tu historial.

### Palabras clave

- *Sociedad de información crediticia:* guarda tu historial de crédito.
- *Historial crediticio:* registro de cómo pagas tus créditos.
- *Consulta:* cuando una institución revisa tu historial con tu autorización.

### Fuentes

Ley para Regular las Sociedades de Información Crediticia · Banco de México, Circular 27/2008 · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U02. Buró y Círculo: ¿en qué se parecen y en qué no?

**Lo que lograrás:** Saber que existen dos sociedades con la misma función, que cada institución reporta a una, a otra o a ambas, y que por eso conviene revisar las dos.

**Para empezar:** Toño revisó su Buró de Crédito y todo estaba en orden. Aun así le negaron un crédito por un atraso que solo aparece en Círculo de Crédito. No sabía que existía otro. En esta lección aprenderás por qué debes revisar los dos.

### Lo esencial (5 minutos)

#### Dos sociedades, la misma función

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Buró de Crédito | Guarda historiales de personas y empresas. | Reporte gratis cada 12 meses. |
| Círculo de Crédito | Hace lo mismo, con su propia base de datos. | Reporte gratis cada 12 meses. |

#### Tu información puede ser distinta en cada una

Cada banco, tienda o financiera decide a cuál reporta: a Buró, a Círculo o a las dos. Por eso un crédito puede aparecer en una y no en la otra.

Y las instituciones consultan una, otra o ambas antes de prestarte.



#### Revisa las dos

Pide tu reporte en Buró y en Círculo. Compara: ¿aparecen los mismos créditos? ¿Hay algo en una que no está en la otra?

Si hay un error, reclamas en la sociedad donde aparece.



#### Un caso en un minuto

Toño pidió su reporte en Círculo y encontró el crédito de la tienda de música con dos meses de atraso. Lo negoció, lo pagó y guardó el comprobante.

Ahora revisa sus dos reportes cada año.

> **Idea clave:** revisar solo uno es ver la mitad de tu historial.



#### Comprueba lo que entendiste

1. ¿Por qué revisar Buró y Círculo?
*Respuesta:* Porque cada institución reporta a una, a otra o a ambas.

2. ¿Dónde reclamas un error que aparece solo en Círculo?
*Respuesta:* En Círculo de Crédito.


#### Para recordar

- Hay dos sociedades.
- Tu historial puede ser distinto en cada una.
- Revisa las dos cada año.



### Profundiza (5 minutos más)

#### Buró y Círculo lado a lado

| | Buró de Crédito | Círculo de Crédito |
|---|---|---|
| Qué es | Sociedad de información crediticia | Sociedad de información crediticia |
| Reporte gratis | Cada 12 meses | Cada 12 meses |
| Reclamaciones | Sí | Sí |
| Servicios extra | Score, alertas, bloqueo y otros, con o sin costo | Score y otros servicios |
| Quién reporta | Las instituciones que tienen contrato con ella | Las instituciones que tienen contrato con ella |

> **Dato vigente:** existen dos sociedades de información crediticia para personas, y el reporte especial es gratuito una vez cada 12 meses en cada una. Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales y CONDUSEF.



#### Qué comparar entre tus dos reportes

- Que aparezcan todos tus créditos.
- Que los saldos coincidan con tus estados de cuenta.
- Que los créditos pagados aparezcan como liquidados.
- Que no haya créditos ni consultas que no reconozcas.



#### Un crédito que no reconoces

Si en cualquiera de los dos aparece un crédito que no pediste, puede ser robo de identidad. Reclama en esa sociedad y a la institución, y protege tu historial (M7 U07, M7 U08 y M9 U04).



#### Casos


**Caso 1. El crédito negado de Toño**

Toño revisó Buró, pero le negaron un crédito por algo que está en Círculo.
- *¿Qué hace?* Pide su reporte en Círculo, revisa el registro y lo resuelve con la institución.


**Caso 2. La tarjeta de Valeria**

La tarjeta de Valeria aparece en Buró pero no en Círculo.
- *¿Es un error?* No necesariamente: su banco puede reportar solo a una sociedad.


**Caso 3. La consulta rara de Gael**

En el reporte de Círculo de Gael aparece una consulta de una financiera que no conoce.
- *¿Qué hace?* Investiga si autorizó esa consulta y, si no, reclama y revisa si hay intentos de robo de identidad.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Revisar solo uno | Ves la mitad | Pide los dos |
| Creer que un crédito ausente es error | Reclamas sin razón | Pregunta a qué sociedad reporta |
| Ignorar consultas desconocidas | Robo de identidad | Investiga |
| Reclamar en la sociedad equivocada | Pierdes tiempo | Reclama donde aparece |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuántas sociedades de información crediticia para personas debes revisar? a) Dos: Buró y Círculo · b) Una · c) Ninguna, si nunca has pedido un crédito
2. Un crédito aparece solo en Buró. ¿Qué significa? a) Que es un error seguro · b) Que es un fraude de la institución que reportó · c) Que esa institución reporta a Buró
3. ¿Cada cuánto tienes un reporte gratis en cada una? a) Cada 5 años · b) Nunca · c) Cada 12 meses
**Respuestas:** 1-a: cada institución reporta a una u otra. 2-c: no todas reportan a las dos. 3-c: es tu derecho por ley.



#### Ponlo en práctica

Pide tus dos reportes y compara la lista de créditos. ¿Hay diferencias?
**Respuesta:** Por ejemplo: en Buró aparecen mi tarjeta y mi crédito de nómina; en Círculo, la tarjeta y un crédito de tienda. No hay errores, solo reportan distinto.



#### A tu plan

Pon un recordatorio anual para pedir tus dos reportes gratis.



### Para saber más

- **Buró de Crédito** (sitio oficial · español): https://www.burodecredito.com.mx — **Qué buscar:** "Reporte de Crédito Especial".
- **Círculo de Crédito** (sitio oficial · español): https://www.circulodecredito.com.mx — **Qué buscar:** tu reporte de crédito gratis.

### Palabras clave

- *Buró de Crédito:* una de las dos sociedades de información crediticia.
- *Círculo de Crédito:* la otra sociedad, con su propia base de datos.
- *Reporte especial:* tu reporte gratuito cada 12 meses.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U03. Pide tus reportes gratis: dos al año

**Lo que lograrás:** Obtener tu Reporte de Crédito Especial gratis cada 12 meses en Buró y en Círculo, solo en los sitios oficiales.

**Para empezar:** Renata vio en redes un anuncio: "Consulta tu Buró gratis aquí". Metió su CURP, su RFC y su INE en esa página. Días después empezó a recibir mensajes de préstamos y un cargo en su tarjeta. La página no era oficial. En esta lección aprenderás a pedir tu reporte de forma segura.

### Lo esencial (5 minutos)

#### Tienes derecho a dos reportes gratis al año

Por ley, puedes pedir tu **Reporte de Crédito Especial** gratis una vez cada 12 meses en cada sociedad: uno en Buró y otro en Círculo. En total, dos al año.

Si quieres más durante el año, tienen costo.



#### Cómo pedirlo

1. **Entra tú** al sitio oficial: burodecredito.com.mx o circulodecredito.com.mx. Escribe la dirección; no uses enlaces de anuncios.
2. **Elige** "Reporte de Crédito Especial".
3. **Ten a la mano** tu RFC, tu CURP y datos de tus créditos para responder preguntas de seguridad.
4. **Descarga y guarda** tu reporte.



#### Solo en sitios oficiales

Páginas, apps o personas que "te consultan tu Buró gratis" a cambio de tus datos pueden robar tu identidad. No las necesitas.



#### Un caso en un minuto

Renata reportó el cargo a su banco y pidió sus reportes en los sitios oficiales. Revisó que no hubiera créditos a su nombre que no pidió y activó el bloqueo de Buró (M7 U08).

> **Idea clave:** tu reporte gratis lo pides tú, en el sitio oficial. Nadie más lo necesita hacer por ti.



#### Comprueba lo que entendiste

1. ¿Cuántos reportes gratis tienes al año?
*Respuesta:* Dos: uno en Buró y otro en Círculo, cada 12 meses.

2. ¿Dónde los pides?
*Respuesta:* Solo en los sitios oficiales de cada sociedad.


#### Para recordar

- Uno gratis cada 12 meses en cada sociedad.
- Solo en los sitios oficiales.
- Guarda tus reportes.



### Profundiza (5 minutos más)

#### Si pides más de uno al año

Después de tu reporte gratuito del periodo, los siguientes tienen costo.

> **Dato vigente:** reporte adicional por internet: 47 pesos en Buró de Crédito y desde 34.50 pesos en Círculo de Crédito. Consultado el 29 de septiembre de 2026 a través de los sitios oficiales de Buró de Crédito y Círculo de Crédito y medios informativos. Los precios cambian: revisa el sitio oficial.



#### Cuándo pedirlo

- Una vez al año, para revisar que todo esté bien.
- Antes de pedir un crédito importante.
- Si sospechas robo de identidad.
- Después de liquidar una deuda, para confirmar que se reporte como pagada.

Puedes alternar: Buró en enero y Círculo en julio, para revisar tu historial cada seis meses sin pagar.



#### Lo que necesitas a la mano

| Dato | Para qué |
|---|---|
| RFC con homoclave | Identificarte |
| CURP | Identificarte |
| Datos de un crédito (por ejemplo, últimos dígitos de tu tarjeta) | Preguntas de seguridad |
| Correo electrónico | Recibir tu reporte |

> **Dato vigente:** reporte de crédito especial gratuito una vez cada 12 meses en cada sociedad (Ley para Regular las Sociedades de Información Crediticia, artículo 40). Consultado el 29 de septiembre de 2026 a través de Buró de Crédito, Círculo de Crédito y CONDUSEF.



#### Protege tu reporte

Tu reporte tiene datos personales. No lo mandes por redes ni lo subas a sitios que no conoces. Si una institución te lo pide, pregunta para qué.



#### Casos


**Caso 1. La página de Renata**

Renata dio sus datos en una página no oficial que ofrecía "consultar su Buró gratis".
- *¿Qué hace ahora?* Reporta cualquier cargo, pide sus reportes en los sitios oficiales, revisa si hay créditos que no pidió y activa el bloqueo.


**Caso 2. El crédito de Gael**

Gael va a pedir un crédito para un auto en dos meses.
- *¿Qué hace antes?* Pide sus reportes en Buró y Círculo para revisar y corregir errores a tiempo.


**Caso 3. La estrategia de Valeria**

Valeria quiere revisar su historial cada seis meses sin pagar.
- *¿Cómo lo hace?* Alterna: Buró en enero y Círculo en julio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Usar páginas no oficiales | Robo de identidad | Entra tú al sitio oficial |
| No pedir tu reporte nunca | No ves errores | Pídelo cada año |
| Mandar tu reporte por redes | Expones tus datos | Guárdalo en privado |
| Pedirlo solo cuando te niegan un crédito | Tarde para corregir | Revísalo antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde pides tu reporte gratis? a) En un anuncio de redes · b) Con un gestor que te lo consigue más rápido · c) En el sitio oficial de cada sociedad
2. ¿Cada cuánto es gratis en cada sociedad? a) Cada mes · b) Cada 5 años · c) Cada 12 meses
3. ¿Cómo revisas tu historial cada seis meses sin pagar? a) Pidiendo dos veces en Buró · b) Alternando Buró y Círculo · c) No se puede
**Respuestas:** 1-c: evita robo de identidad. 2-c: es tu derecho por ley. 3-b: cada sociedad te da uno gratis al año.



#### Ponlo en práctica

Pide hoy tu reporte gratis en una de las dos sociedades. Anota la fecha y cuándo pedirás el de la otra.
**Respuesta:** Por ejemplo: pedí mi reporte de Buró el 29 de septiembre; pediré el de Círculo el 29 de marzo.



#### A tu plan

Pide tu primer reporte y guárdalo en una carpeta privada.



### Para saber más

- **Reporte de Crédito Especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** "Reporte de Crédito Especial" gratis.
- **Reporte de crédito** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** tu reporte gratis.
- **Tu reporte de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre cómo pedir y leer tu reporte.

### Palabras clave

- *Reporte de Crédito Especial:* tu reporte gratis cada 12 meses.
- *RFC:* tu Registro Federal de Contribuyentes.
- *Homoclave:* los tres últimos caracteres de tu RFC.

### Fuentes

Ley para Regular las Sociedades de Información Crediticia, artículo 40 · Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U04. Lee tu reporte

**Lo que lograrás:** Identificar en tu reporte las cuentas, el otorgante, el saldo, el límite, la forma de pago, las claves de observación y las consultas.

**Para empezar:** Gael tiene su reporte en la mano y no entiende nada: claves, números, siglas. Ve un "LC" en una cuenta y una lista larga de consultas. En esta lección aprenderás a leer lo importante.

### Lo esencial (5 minutos)

#### Las partes de tu reporte

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Datos personales | Nombre, RFC, domicilios. | Revisa que sean tuyos. |
| Cuentas | Cada crédito con otorgante, saldo, límite y pagos. | Compara con tus estados de cuenta. |
| Forma de pago | Si pagaste a tiempo o con cuántos días de atraso. | Lo que más importa. |
| Consultas | Quién revisó tu historial. | Deben ser con tu autorización. |

#### La forma de pago mes a mes

Tu reporte muestra, por cada cuenta, cómo pagaste en cada periodo: al corriente o con atraso de ciertos días. Es lo que más revisan las instituciones.



#### Las claves de observación

Algunas cuentas tienen una **clave de observación**: explican una situación especial, por ejemplo que la cuenta se liquidó con un descuento (quita), que está en litigio o que se reportó un robo de identidad.

El reporte trae una tabla que explica cada clave.



#### Un caso en un minuto

Gael buscó la clave de su cuenta en la tabla del reporte: significaba que liquidó con quita, pagando menos de lo que debía. Entendió por qué un banco le ofreció condiciones menos favorables (M8 U02).

> **Idea clave:** revisa datos, cuentas, forma de pago, claves y consultas.



#### Comprueba lo que entendiste

1. ¿Qué revisas primero de cada cuenta?
*Respuesta:* La forma de pago: si pagaste a tiempo o con atraso.

2. ¿Qué es una clave de observación?
*Respuesta:* Un código que explica una situación especial de una cuenta.


#### Para recordar

- Revisa que tus datos sean tuyos.
- Compara saldos con tus estados de cuenta.
- Busca claves y consultas que no reconozcas.



### Profundiza (5 minutos más)

#### Lista de revisión

| Pregunta | Si la respuesta es no |
|---|---|
| ¿Mis datos personales son correctos? | Reclama la corrección |
| ¿Reconozco todas las cuentas? | Posible robo de identidad: reclama |
| ¿Los saldos coinciden con mis estados de cuenta? | Reclama con tu comprobante |
| ¿Las cuentas pagadas dicen liquidadas? | Reclama con tu carta de liquidación |
| ¿Reconozco todas las consultas? | Investiga y reclama |



#### Las consultas

Tu reporte muestra qué instituciones consultaron tu historial en los últimos 24 meses. Muchas consultas en poco tiempo pueden hacer pensar a los bancos que estás pidiendo crédito desesperadamente.

> **Dato vigente:** el reporte especial incluye a quienes consultaron tu información en los últimos 24 meses (Circular 27/2008 del Banco de México). Consultado el 29 de septiembre de 2026 a través del Banco de México.



#### Las claves cambian

Las claves y códigos pueden cambiar con el tiempo y ser distintas entre Buró y Círculo. Usa siempre la tabla de claves que viene en tu propio reporte.



#### Guarda tus comprobantes

Carta de liquidación, recibos de pago y estados de cuenta te sirven para reclamar errores. Guárdalos al menos seis años.



#### Casos


**Caso 1. La clave de Gael**

En el reporte de Gael aparece una clave en una cuenta que ya pagó.
- *¿Qué hace?* Busca su significado en la tabla del reporte; si es un error, reclama con su comprobante.


**Caso 2. El saldo de Valeria**

Una cuenta de Valeria aparece con saldo de 8,000, pero ella ya la liquidó.
- *¿Qué hace?* Reclama con su carta de liquidación.


**Caso 3. Las consultas de Renata**

Renata ve siete consultas de financieras en dos meses; solo pidió dos créditos.
- *¿Qué hace?* Investiga las que no reconoce y reclama; puede ser un intento de robo de identidad.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No leer tu reporte | No ves errores | Usa la lista de revisión |
| Ignorar las claves | No entiendes tu historial | Usa la tabla del reporte |
| Pedir muchos créditos seguidos | Muchas consultas | Pide solo lo necesario |
| Tirar comprobantes | No puedes reclamar | Guárdalos seis años |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué parte del reporte muestra si pagaste a tiempo? a) Los domicilios · b) El RFC · c) La forma de pago
2. ¿Qué explica una clave de observación? a) Tu edad · b) Tu régimen fiscal ante el SAT · c) Una situación especial de una cuenta
3. Una cuenta que liquidaste aparece con saldo. ¿Qué haces? a) Reclamas con tu carta de liquidación · b) La pagas otra vez para que ya no aparezca · c) Nada
**Respuestas:** 1-c: muestra puntualidad o atraso. 2-c: por ejemplo, una quita. 3-a: con tu comprobante se corrige.



#### Ponlo en práctica

Usa la lista de revisión con tu reporte. Anota si encontraste algo que reclamar.
**Respuesta:** Por ejemplo: mis datos están bien; reconozco todas las cuentas; una tarjeta pagada aparece con saldo; reclamaré con mi carta de liquidación.



#### A tu plan

Guarda en una carpeta tus cartas de liquidación y comprobantes de pago.



### Para saber más

- **Cómo leer tu reporte** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** la guía para entender tu Reporte de Crédito Especial.
- **Tu reporte de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre claves y cómo reclamar.

### Palabras clave

- *Forma de pago:* registro de puntualidad o atraso de cada periodo.
- *Clave de observación:* código que explica una situación especial.
- *Otorgante:* la institución que te dio el crédito.

### Fuentes

Banco de México, Circular 27/2008 · Buró de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U05. Tu score: qué lo sube y qué lo baja

**Lo que lograrás:** Saber que el score es un producto distinto del reporte gratuito, y conocer lo que lo mueve.

**Para empezar:** Valeria pagó 400 por "conocer su score" en una app y luego descubrió que el reporte gratuito no incluía ese número. Quiere saber si lo necesita y cómo subirlo. En esta lección aprenderás qué es el score y cómo mejorarlo.

### Lo esencial (5 minutos)

#### Un número que resume tu historial

El **score crediticio** es un número calculado con tu historial. Las instituciones lo usan para decidir y fijar condiciones.

No viene en el reporte gratuito: es un producto aparte, en general con costo.



#### Lo que mueve tu score

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pagos a tiempo | Lo más importante. | Nunca te atrases. |
| Uso de tu línea | Usar poco de tu línea ayuda. | Mantén saldos bajos. |
| Antigüedad | Cuentas viejas bien pagadas ayudan. | No cierres todas. |
| Consultas | Muchas solicitudes seguidas bajan. | Pide solo lo necesario. |

#### ¿Lo necesitas?

Para revisar tu historial, basta el reporte gratuito. El score puede ser útil antes de pedir un crédito grande, pero no lo necesitas cada mes.



#### Un caso en un minuto

Valeria dejó de pagar la app. Revisa su reporte gratuito cada seis meses y paga su tarjeta completa. Bajó el uso de su línea de 80% a 30%.

Un año después, le ofrecieron una tarjeta con mejor tasa.

> **Idea clave:** el score sube con pagos puntuales y saldos bajos, no con trucos.



#### Comprueba lo que entendiste

1. ¿El reporte gratuito incluye tu score?
*Respuesta:* No. El score es un producto aparte.

2. ¿Qué es lo que más ayuda a tu score?
*Respuesta:* Pagar a tiempo.


#### Para recordar

- El score resume tu historial.
- Pagos a tiempo y saldos bajos lo suben.
- El reporte gratis basta para revisar.



### Profundiza (5 minutos más)

#### Uso de tu línea

Cuánto usas de tu línea de crédito.
- Saldo de tus tarjetas: **24,000**
- Tus líneas juntas: **30,000**
- Uso de tu línea: 24,000 ÷ 30,000: **80%**
Bajarlo a 30% o menos suele ayudar.


#### Cuánto cuesta el score

Buró de Crédito ofrece **Mi Score** (unos 58 pesos si lo pides al descargar tu reporte) y Círculo de Crédito su **Score Crediticio** (50 pesos la primera consulta y 97 pesos las siguientes). El servicio Alertas Buró incluye 4 Mi Score al año.

> **Dato vigente:** precios de Mi Score (Buró de Crédito) y Score Crediticio (Círculo de Crédito). Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales y medios informativos. Los precios cambian: revisa el sitio oficial.



#### Lo que no funciona

- Pagar a alguien para "subir tu score": es fraude.
- Cerrar todas tus tarjetas de golpe: puede bajar tu antigüedad y subir tu uso de línea.
- Pedir muchas tarjetas nuevas: aumenta las consultas.



#### El tiempo ayuda

Un atraso pesa menos con el tiempo si después pagas puntualmente. La constancia de 6 a 12 meses se nota.



#### Casos


**Caso 1. La app de Valeria**

Valeria paga 400 al mes para ver su score en una app.
- *¿Lo necesita?* No cada mes. Con su reporte gratuito revisa su historial; el score lo consulta solo antes de un crédito grande.


**Caso 2. Las tarjetas de Gael**

Gael quiere cerrar sus cinco tarjetas para "limpiar su score".
- *¿Qué le conviene?* Pagarlas y cerrar las que no usa poco a poco, conservando alguna antigua bien pagada.


**Caso 3. El "servicio" de Toño**

A Toño le ofrecen subir su score 150 puntos por 3,000.
- *¿Qué hace?* No paga: nadie puede cambiar tu historial por dinero. Es fraude.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar cada mes por ver el score | Gasto innecesario | Usa tu reporte gratis |
| Usar casi toda tu línea | Tu score baja | Mantén saldos bajos |
| Cerrar todas las tarjetas | Pierdes antigüedad | Cierra con estrategia |
| Pagar por "subir el score" | Fraude | Solo pagos puntuales |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Saldo de 9,000 en una línea de 30,000. ¿Qué uso de línea tienes? a) 9% · b) 70% · c) 30%
2. ¿Qué acción ayuda más a tu score? a) Pedir muchas tarjetas · b) Pagar a tiempo · c) Pagar por subirlo
3. ¿El score viene en tu reporte gratuito? a) No, es un producto aparte · b) Sí, siempre · c) Solo en Círculo de Crédito, no en Buró
**Respuestas:** 1-c: 9,000 ÷ 30,000. 2-b: la puntualidad es lo más importante. 3-a: en general tiene costo.



#### Ponlo en práctica

Calcula tu uso de línea: suma tus saldos de tarjetas y divídelos entre la suma de tus líneas.
**Respuesta:** Por ejemplo: saldos 18,000; líneas 40,000. Uso 45%. Mi meta es bajar a 30%: 12,000 de saldo.



#### A tu plan

Escribe tu meta de uso de línea y cuánto necesitas pagar para llegar.



### Para saber más

- **Buró de Crédito** (sitio oficial · español): https://www.burodecredito.com.mx — **Qué buscar:** "Mi Score" y sus condiciones.
- **Círculo de Crédito** (sitio oficial · español): https://www.circulodecredito.com.mx — **Qué buscar:** servicio de score y su costo.

### Palabras clave

- *Score crediticio:* número que resume tu historial.
- *Uso de línea:* saldo dividido entre tu línea de crédito.
- *Antigüedad:* tiempo que llevas con tus créditos.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U06. ¿Cuánto tiempo se queda un atraso?

**Lo que lograrás:** Conocer los plazos para que se elimine una deuda de tu historial según su monto en UDIS, y qué deudas no se eliminan por plazo.

**Para empezar:** Toño cree que un atraso de hace siete años "lo tiene marcado de por vida". Nunca revisó cuánto era ni cuándo se reportó. En esta lección conocerás los plazos que marca la ley.

### Lo esencial (5 minutos)

#### Los atrasos no son para siempre

La ley marca plazos para que las sociedades eliminen del historial las deudas atrasadas. El plazo depende del monto, medido en **UDIS**.



#### Plazos de eliminación según el monto

| Monto de la deuda | Se elimina después de |
|---|---|
| Hasta 25 UDIS | 1 año |
| Más de 25 y hasta 500 UDIS | 2 años |
| Más de 500 y hasta 1,000 UDIS | 4 años |
| Más de 1,000 UDIS | 6 años |

> **Dato vigente:** plazos del artículo 23 de la Ley para Regular las Sociedades de Información Crediticia, según CONDUSEF. Consultado el 29 de septiembre de 2026 a través de CONDUSEF. El valor de la UDI cambia cada día: consúltalo en el Banco de México.



#### No se eliminan por plazo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Más de 400,000 UDIS | Deudas muy grandes. | No aplica el plazo. |
| En juicio | Si hay un proceso judicial. | Se queda mientras dure. |
| Con fraude | Si hubo fraude comprobado. | No aplica el plazo. |

#### Eliminar el registro no borra la deuda

Que un atraso desaparezca de tu historial no significa que ya no debas. El acreedor puede seguir cobrando por las vías legales.



#### Un caso en un minuto

La deuda de Toño era de unas 800 UDIS y se había reportado hace siete años. Pidió sus reportes y ya no aparecía.

Aun así, habló con el acreedor para saber si seguía debiendo algo y cerrar el tema en paz.

> **Idea clave:** los atrasos tienen fecha de caducidad en tu historial, pero la deuda puede seguir existiendo.



#### Comprueba lo que entendiste

1. Una deuda de 300 UDIS, ¿cuánto tiempo se queda?
*Respuesta:* 2 años.

2. ¿Eliminarla del historial borra la deuda?
*Respuesta:* No. El acreedor puede seguir cobrando.


#### Para recordar

- El plazo depende del monto en UDIS.
- Deudas muy grandes, en juicio o con fraude no se eliminan por plazo.
- La deuda puede seguir existiendo.



### Profundiza (5 minutos más)

#### Cómo convertir a pesos

Multiplica las UDIS por el valor de la UDI del día. Por ejemplo, si la UDI vale 8.5 pesos, 500 UDIS son unos 4,250 pesos y 1,000 UDIS unos 8,500 pesos.



#### Desde cuándo se cuenta

El plazo se cuenta desde que el incumplimiento se incorporó por primera vez a tu historial, no desde que pagaste. Por eso, pagar una deuda vieja no reinicia el plazo: la cuenta aparece como pagada y el registro del atraso sale cuando se cumple su tiempo.

Las sociedades deben conservar los historiales al menos 72 meses (6 años).

> **Dato vigente:** artículo 23 de la Ley para Regular las Sociedades de Información Crediticia y guía de CONDUSEF sobre plazos de eliminación. Consultado el 29 de septiembre de 2026 a través de CONDUSEF y el texto de la ley.



#### Mejor pagar que esperar

Esperar a que se elimine un atraso puede tardar años, y mientras tanto el acreedor puede cobrarte. Pagar o negociar te permite empezar antes a construir un historial positivo (M8).



#### Cuidado con quien promete borrarlo antes

Nadie puede eliminar información correcta antes del plazo legal. Quien lo promete a cambio de dinero comete fraude (M7 U09).



#### Casos


**Caso 1. El atraso de Toño**

Toño tenía una deuda de unas 800 UDIS reportada hace siete años.
- *¿Sigue en su historial?* No debería: el plazo para ese monto es de 4 años. Lo confirma pidiendo sus reportes.


**Caso 2. La tarjeta de Renata**

Renata dejó de pagar una tarjeta de 60,000 pesos.
- *¿Cuánto tiempo puede quedarse el registro?* Hasta 6 años, porque pasa de 1,000 UDIS.


**Caso 3. La espera de Gael**

Gael piensa no pagar una deuda y esperar a que se elimine.
- *¿Es buena idea?* No: la deuda sigue y lo pueden cobrar. Negociar le permite reconstruir su historial antes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que el atraso es de por vida | No intentas mejorar | Conoce los plazos |
| Creer que eliminar es liquidar | Te siguen cobrando | La deuda existe |
| Esperar años sin pagar | Cobranza y juicios | Negocia |
| Pagar a quien promete borrar | Fraude | Nadie puede hacerlo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Deuda de 20 UDIS. ¿Después de cuánto se elimina? a) 6 años · b) Nunca · c) 1 año
2. Deuda de 2,000 UDIS sin juicio ni fraude. ¿Plazo? a) 6 años · b) 2 años · c) 10 años
3. ¿Qué deudas no se eliminan por plazo? a) Todas las de tarjeta de crédito, sin importar el monto · b) Las de más de 400,000 UDIS, en juicio o con fraude · c) Las de tienda
**Respuestas:** 1-c: hasta 25 UDIS es 1 año. 2-a: más de 1,000 UDIS es 6 años. 3-b: son las excepciones de la ley.



#### Ponlo en práctica

Toma una deuda atrasada que tengas o hayas tenido. Conviértela a UDIS y calcula su plazo.
**Respuesta:** Por ejemplo: 6,000 pesos ÷ 8.5 = unas 706 UDIS. Plazo: 4 años desde que se reportó el atraso.



#### A tu plan

Consulta el valor de la UDI del día en el Banco de México y calcula el plazo de tus atrasos.



### Para saber más

- **¿En cuánto tiempo me borran del Buró?** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** la guía con los plazos según el monto.
- **Valor de la UDI** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** "UDIS" y el valor del día.

### Palabras clave

- *UDIS:* unidad que sube con la inflación.
- *Eliminación:* cuando un registro sale de tu historial.
- *Incumplimiento:* no pagar lo pactado.

### Fuentes

Ley para Regular las Sociedades de Información Crediticia, artículo 23 · CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M7 U07. Si hay un error: reclama paso a paso

**Lo que lograrás:** Presentar una reclamación ante Buró o Círculo con tus pruebas, entender qué pasa después y acudir a CONDUSEF si no se resuelve.

**Para empezar:** Valeria liquidó una tarjeta hace un año y guardó su carta de liquidación. En su reporte aparece con saldo de 8,000 y atraso. Por eso le negaron un crédito. En esta lección aprenderás a reclamar paso a paso.

### Lo esencial (5 minutos)

#### Puedes reclamar errores

Si tu reporte tiene información incorrecta (un saldo pagado, un crédito que no es tuyo, un atraso que no existió), puedes presentar una **reclamación** ante la sociedad donde aparece.



#### Cómo reclamar

1. **Pide tu reporte** y marca el registro incorrecto.
2. **Junta tus pruebas:** carta de liquidación, recibos, estados de cuenta.
3. **Presenta la reclamación** en la unidad especializada de la sociedad, en línea o por escrito, con copia de tu reporte y tus pruebas.
4. **Guarda tu folio** y espera la respuesta.
5. **Si no se resuelve,** acude a CONDUSEF.



#### Qué pasa después

La sociedad pide a la institución que confirme la información. Si la institución no la sustenta, el registro se corrige o se elimina.



#### Un caso en un minuto

Valeria presentó su reclamación en línea con su carta de liquidación. La institución no pudo sostener el saldo y el registro se corrigió.

Con su reporte correcto, volvió a pedir el crédito.

> **Idea clave:** reclamar es tu derecho y puedes hacerlo tú, sin intermediarios.



#### Comprueba lo que entendiste

1. ¿Qué necesitas para reclamar?
*Respuesta:* Tu reporte, el registro incorrecto marcado y tus pruebas.

2. ¿Qué haces si no se resuelve?
*Respuesta:* Acudes a CONDUSEF con tu folio y tus pruebas.


#### Para recordar

- Reclama donde aparece el error.
- Con reporte, pruebas y folio.
- CONDUSEF si no se resuelve.



### Profundiza (5 minutos más)

#### ¿Cuesta reclamar?

Plazos que marca la ley:

- La sociedad envía tu reclamación a la institución en un máximo de **5 días hábiles**.
- La institución tiene **30 días naturales** para responder. Si no responde, la sociedad debe modificar o eliminar el registro como lo pediste.
- La sociedad te envía la respuesta en los **5 días hábiles** siguientes.

Costo: en Círculo de Crédito tienes **2 reclamaciones gratis al año** y las siguientes cuestan 80 pesos. En Buró de Crédito, revisa las condiciones en su sitio oficial.

> **Dato vigente:** artículos 42 a 44 de la Ley para Regular las Sociedades de Información Crediticia y costos de Círculo de Crédito. Consultado el 29 de septiembre de 2026 a través del texto de la ley, Círculo de Crédito y medios informativos.



#### Tu expediente de reclamación

| Documento | Para qué |
|---|---|
| Reporte con el registro marcado | Muestra el error |
| Carta de liquidación o recibos | Prueba que pagaste |
| Estado de cuenta | Muestra el saldo real |
| Identificación | Para identificarte |
| Folio de la reclamación | Para dar seguimiento |



#### Reclama también a la institución

Puedes presentar la reclamación a la institución que reportó mal, en su Unidad Especializada (UNE), al mismo tiempo. A veces se corrige más rápido.



#### Si el crédito no es tuyo

Si aparece un crédito que no pediste, indícalo como posible robo de identidad y reclama tanto en la sociedad como a la institución. Presenta también una denuncia (M9 U04).



#### Casos


**Caso 1. La tarjeta pagada de Valeria**

Una tarjeta que Valeria liquidó aparece con saldo y atraso.
- *¿Qué hace?* Reclama en la sociedad donde aparece, con su carta de liquidación, y guarda el folio.


**Caso 2. El crédito ajeno de Toño**

En el reporte de Toño hay un crédito de una financiera que nunca usó.
- *¿Qué hace?* Reclama como posible robo de identidad en la sociedad y en la institución, y presenta denuncia.


**Caso 3. Sin respuesta para Gael**

Gael reclamó hace meses y no le han resuelto.
- *¿Qué hace?* Acude a CONDUSEF con su folio y sus pruebas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar a un despacho para reclamar | Gastas en algo que haces tú | Reclama tú |
| Reclamar sin pruebas | Difícil que proceda | Junta tus comprobantes |
| No guardar el folio | No puedes dar seguimiento | Guárdalo |
| Rendirte si no responden | El error sigue | Acude a CONDUSEF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde reclamas un error de tu reporte? a) En la sociedad donde aparece · b) En el SAT · c) En redes sociales, para que la institución responda
2. ¿Qué prueba sirve si ya pagaste? a) Un mensaje a un amigo · b) Nada · c) Tu carta de liquidación
3. Tu reclamación no se resolvió. ¿A quién acudes? a) Profeco · b) Un despacho que limpia el Buró · c) CONDUSEF
**Respuestas:** 1-a: ahí se corrige. 2-c: prueba que liquidaste. 3-c: CONDUSEF atiende a usuarios.



#### Ponlo en práctica

Escribe una reclamación corta para un registro incorrecto.
**Respuesta:** Por ejemplo: "La cuenta de tarjeta del Banco X aparece con saldo de 8,000 y atraso. La liquidé el 10 de agosto de 2025; anexo mi carta de liquidación. Solicito corregir el registro."



#### A tu plan

Arma tu carpeta de pruebas con cartas de liquidación y recibos de tus créditos pagados.



### Para saber más

- **Reclamaciones** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** "Reclamaciones" y cómo presentarlas en línea.
- **Reclamación** (Círculo de Crédito · español): https://www.circulodecredito.com.mx/reclamacion — **Qué buscar:** requisitos y reclamaciones gratuitas.
- **CONDUSEF** (Gobierno de México · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una reclamación si no te resuelven.

### Palabras clave

- *Reclamación:* solicitud para corregir un registro.
- *Carta de liquidación:* documento que prueba que pagaste un crédito.
- *Folio:* número para dar seguimiento a tu trámite.

### Fuentes

Ley para Regular las Sociedades de Información Crediticia, artículos 42 a 45 · Banco de México, Circular 27/2008 · Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U08. Protege tu historial: bloqueo y alertas

**Lo que lograrás:** Conocer los servicios de bloqueo y alertas para evitar que alguien abra créditos a tu nombre.

**Para empezar:** Renata dio sus datos en una página falsa. Teme que alguien pida un crédito a su nombre y no se entere hasta que le llamen de cobranza. En esta lección conocerás dos herramientas para proteger tu historial.

### Lo esencial (5 minutos)

#### Dos herramientas de protección

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bloqueo | Mientras está activo, nadie puede consultar tu historial, así que no pueden aprobar créditos a tu nombre. | Prevención. |
| Alertas | Te avisan cuando alguien consulta tu historial o se abre un crédito a tu nombre. | Te enteras rápido. |

#### Cómo funciona el bloqueo

Activas el bloqueo en el sitio de Buró de Crédito. Cuando tú vas a pedir un crédito, lo desbloqueas; cuando terminas, lo vuelves a bloquear.

Si alguien intenta pedir un crédito con tus datos, la institución no podrá consultar tu historial y el crédito no avanzará.



#### Cómo funcionan las alertas

Recibes un aviso cada vez que alguien consulta tu historial o se registra un crédito nuevo. Si no fuiste tú, actúas de inmediato.



#### Un caso en un minuto

Renata activó el bloqueo y contrató las alertas. Un mes después recibió una alerta: una financiera intentó consultar su historial. El bloqueo impidió el crédito y ella reportó el intento.

> **Idea clave:** el bloqueo previene; las alertas te avisan.



#### Comprueba lo que entendiste

1. ¿Qué hace el bloqueo?
*Respuesta:* Impide que consulten tu historial, así que no pueden aprobar créditos a tu nombre.

2. ¿Qué haces cuando tú vas a pedir un crédito?
*Respuesta:* Desbloqueas y, al terminar, vuelves a bloquear.


#### Para recordar

- Bloqueo: nadie consulta tu historial.
- Alertas: te enteras de consultas y créditos nuevos.
- Úsalos si tus datos se expusieron.



### Profundiza (5 minutos más)

#### Costos y condiciones

- **Bloqueo de Buró de Crédito:** 58 pesos por tres meses. En ese tiempo bloqueas y desbloqueas las veces que quieras. No se renueva solo: vuelve a contratarlo al vencer.
- **Alertas Buró:** 232 pesos al año; incluye 4 Mi Score.
- **Bloqueo de Círculo de Crédito:** bloqueo temporal por tres meses; puedes activarlo o quitarlo cada 24 horas.
- **Alertas de Círculo de Crédito:** "Avísame" es gratuito; "Avísame Mucho Más" cuesta 250 pesos al año.

El bloqueo solo limita quién consulta tu historial: no cambia ni borra lo que hay en él.

> **Dato vigente:** costos y condiciones de Bloqueo y Alertas Buró (Buró de Crédito) y de bloqueo y Avísame (Círculo de Crédito). Consultado el 29 de septiembre de 2026 a través de sus sitios oficiales y medios informativos. Los precios cambian: revisa el sitio oficial antes de contratar.



#### ¿Y Círculo de Crédito?

Como algunas instituciones solo consultan Círculo, pregunta en Círculo qué servicios de protección ofrece. Si tus datos se expusieron, protege tu historial en las dos.



#### Si tus datos se expusieron

1. Cambia contraseñas y activa la verificación en dos pasos.
2. Activa bloqueo y alertas.
3. Pide tus reportes y revisa créditos y consultas.
4. Avisa a tu banco.
5. Si hay un crédito que no pediste, reclama y denuncia (M9 U04).



#### No olvides desbloquear

Si vas a pedir un crédito legítimo y tu historial está bloqueado, la institución no podrá consultarlo. Desbloquea antes de tu solicitud y vuelve a bloquear después.



#### Casos


**Caso 1. Los datos de Renata**

Renata dio sus datos en una página falsa.
- *¿Qué hace para proteger su historial?* Activa bloqueo y alertas, pide sus reportes y avisa a su banco.


**Caso 2. El crédito de Gael**

Gael tiene su historial bloqueado y va a pedir un crédito de auto.
- *¿Qué hace?* Desbloquea antes de la solicitud y vuelve a bloquear al terminar.


**Caso 3. La alerta de Valeria**

A Valeria le llega una alerta de una consulta que no hizo.
- *¿Qué hace?* Revisa su reporte, contacta a la institución y reclama si no la autorizó.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No proteger tu historial tras exponer tus datos | Créditos a tu nombre | Activa bloqueo y alertas |
| Olvidar desbloquear | Te rechazan un crédito legítimo | Desbloquea antes |
| Ignorar una alerta | Pierdes tiempo valioso | Actúa de inmediato |
| Proteger solo una sociedad | Te pueden abrir crédito por la otra | Revisa las dos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué servicio impide que consulten tu historial? a) Bloqueo · b) Score · c) Reporte especial
2. ¿Qué servicio te avisa de consultas y créditos nuevos? a) Alertas · b) Bloqueo · c) RECA
3. Vas a pedir un crédito y tu historial está bloqueado. ¿Qué haces? a) Pides el crédito así · b) Desbloqueas antes y vuelves a bloquear después · c) Cancelas el bloqueo para siempre y ya no lo usas
**Respuestas:** 1-a: el bloqueo previene. 2-a: las alertas avisan. 3-b: así no te rechazan un crédito legítimo.



#### Ponlo en práctica

Escribe tu plan si mañana te enteras de que tus datos se expusieron.
**Respuesta:** Por ejemplo: cambio contraseñas, activo bloqueo y alertas, pido mis reportes, aviso a mi banco y, si hay algo raro, reclamo y denuncio.



#### A tu plan

Revisa en el sitio oficial de Buró de Crédito las condiciones actuales del bloqueo y decide si lo activas.



### Para saber más

- **Bloqueo** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** "Bloqueo" y cómo activarlo.
- **Alertas Buró** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** "Alertas Buró", costo y cómo contratarlo.
- **Robo de identidad** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para prevenir y actuar ante robo de identidad.

### Palabras clave

- *Bloqueo:* impide que consulten tu historial.
- *Alerta:* aviso de consultas o créditos nuevos a tu nombre.
- *Robo de identidad:* uso de tus datos para hacerse pasar por ti.

### Fuentes

Buró de Crédito, Bloqueo y Alertas Buró · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U09. Despachos que "limpian tu Buró": fraude

**Lo que lograrás:** Reconocer que nadie puede borrar información correcta de tu historial, que las reclamaciones las haces tú y que esos cobros son fraude.

**Para empezar:** A Toño le escribe un despacho: "Te sacamos del Buró en 30 días por 4,500. Garantizado". Toño está desesperado por su crédito para el estudio y casi paga. En esta lección aprenderás a reconocer este fraude.

### Lo esencial (5 minutos)

#### Nadie puede borrar información correcta

Si la información de tu historial es correcta, solo desaparece cuando se cumple el plazo de la ley (M7 U06). Ningún despacho, abogado ni "contacto" puede borrarla antes.



#### Señales de fraude

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobro por adelantado | Te piden pagar antes de hacer nada. | Alerta. |
| "Garantizado" | Prometen resultados que nadie puede asegurar. | Alerta. |
| "Tenemos contactos" | Dicen conocer a gente dentro de las sociedades. | Alerta. |
| Piden tus documentos | INE, CURP, contraseñas. | Riesgo de robo de identidad. |

#### Lo que sí puedes hacer tú, gratis

- Pedir tus reportes gratis (M7 U03).
- Reclamar errores (M7 U07).
- Pagar o negociar tus deudas (M8).
- Esperar el plazo legal mientras construyes un buen historial.



#### Un caso en un minuto

Toño buscó el despacho en CONDUSEF y encontró alertas sobre ese tipo de servicios. No pagó.

Con el dinero que iba a darles, abonó a su deuda y empezó su plan de salida.

> **Idea clave:** si alguien te cobra por "limpiar tu Buró", es fraude.



#### Comprueba lo que entendiste

1. ¿Un despacho puede borrar un atraso real antes del plazo?
*Respuesta:* No. Solo desaparece con el plazo legal.

2. ¿Quién puede reclamar un error en tu reporte?
*Respuesta:* Tú, gratis, en la sociedad donde aparece.


#### Para recordar

- Nadie borra información correcta.
- Las reclamaciones las haces tú.
- Cobro por adelantado y "garantizado": fraude.



### Profundiza (5 minutos más)

#### Por qué funciona este fraude

Llega cuando más necesitas crédito y te sientes sin salida. Usa palabras legales, logotipos parecidos y testimonios falsos.

Tomarte diez minutos para verificar te protege.



#### Verifica antes de pagar

Busca el nombre en el Portal de Fraudes Financieros de CONDUSEF y en el SIPRES. Si alguien ofrece servicios de "reparación de crédito", pregunta a CONDUSEF antes.

> **Dato vigente:** CONDUSEF advierte que nadie puede eliminar información correcta del historial crediticio antes de los plazos legales. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Si ya pagaste

Guarda pruebas del pago y las conversaciones. Pide a tu banco revisar el cargo si pagaste con tarjeta, denuncia ante el Ministerio Público y repórtalo a CONDUSEF. Si diste tus documentos, protege tu historial (M7 U08).



#### Asesoría legítima

Si tienes varias deudas, busca orientación en CONDUSEF (gratis). Un abogado legítimo te explica lo que puede y no puede hacer, y no promete borrar tu historial.



#### Casos


**Caso 1. El despacho de Toño**

Un despacho le promete a Toño sacarlo del Buró en 30 días por 4,500.
- *¿Qué hace?* No paga: verifica en CONDUSEF y usa ese dinero para abonar a su deuda.


**Caso 2. El pago de Renata**

Renata ya pagó 3,000 a un despacho que no hizo nada.
- *¿Qué hace?* Guarda pruebas, pide a su banco revisar el cargo, denuncia y reporta a CONDUSEF.


**Caso 3. El contacto de Gael**

Un conocido le dice a Gael que tiene "un contacto en el Buró".
- *¿Qué hace?* No le da dinero ni datos. Reclama él mismo si hay errores.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por limpiar tu historial | Pierdes dinero | Es fraude |
| Dar tu INE a despachos | Robo de identidad | No la compartas |
| Creer en garantías | Promesas falsas | Nadie puede garantizarlo |
| No reportar el fraude | Otras personas caen | Reporta a CONDUSEF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prometen sacarte del Buró en 30 días por un pago. ¿Qué es? a) Fraude · b) Un servicio oficial · c) Una reclamación legal
2. ¿Quién puede eliminar información correcta antes del plazo? a) Un despacho con contactos · b) Nadie · c) Un abogado caro
3. Ya pagaste a un despacho falso. ¿Qué haces? a) Pagas un poco más para que terminen el trámite · b) Nada · c) Guardas pruebas, denuncias y reportas
**Respuestas:** 1-a: nadie puede borrar información correcta. 2-b: solo el plazo legal. 3-c: así proteges tu dinero y a otras personas.



#### Ponlo en práctica

Escribe tres señales que te harían sospechar de un servicio para "limpiar tu Buró".
**Respuesta:** Por ejemplo: cobro por adelantado, resultados garantizados y que pidan mi INE y contraseñas.



#### A tu plan

Guarda el enlace del Portal de Fraudes Financieros de CONDUSEF para verificar cualquier oferta.



### Para saber más

- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** fraudes de "limpieza de Buró" y cómo reportarlos.
- **¿Cómo salir del Buró de Crédito?** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** la guía oficial sobre plazos y opciones.

### Palabras clave

- *Despacho de limpieza:* empresa que promete borrar tu historial, casi siempre fraude.
- *Denuncia:* aviso formal de un delito ante el Ministerio Público.
- *Portal de Fraudes Financieros:* sitio de CONDUSEF con alertas de fraude.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M7 U10. Cómo mejorar tu historial paso a paso

**Lo que lograrás:** Seguir un plan de 6 a 12 meses: pagar a tiempo, bajar el uso de tus tarjetas, no pedir créditos seguidos, regularizar atrasos y revisar tus reportes.

**Para empezar:** Gael quiere un crédito para un auto en un año. Su historial tiene un atraso reciente, tarjetas casi al tope y muchas consultas. No sabe por dónde empezar. En esta lección armarás tu plan para mejorar tu historial.

### Lo esencial (5 minutos)

#### Tu plan de 12 meses

1. **Pide tus dos reportes** y corrige errores.
2. **Ponte al corriente** en los atrasos, o negocia (M8).
3. **Paga a tiempo** todo, todos los meses. Programa recordatorios.
4. **Baja el uso de tus tarjetas** a 30% de tu línea o menos.
5. **No pidas créditos nuevos** mientras mejoras.
6. **Revisa tus reportes** cada seis meses.



#### Lo que ayuda y lo que no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ayuda | Pagos puntuales, saldos bajos, cuentas antiguas bien pagadas. | Constancia. |
| No ayuda | Muchas solicitudes, atrasos nuevos, tarjetas al tope. | Evítalo. |
| No existe | Trucos rápidos o pagar para borrar. | Fraude. |

#### Si no tienes historial

Empieza con un producto pequeño: una tarjeta con línea baja o una tarjeta garantizada. Úsala para un gasto fijo que ya pagas (por ejemplo, tu plan de celular) y págala completa cada mes.



#### Un caso en un minuto

Gael se puso al corriente, bajó sus tarjetas de 85% a 30% y no pidió nada nuevo. Revisó sus reportes a los seis meses: ya no había atrasos nuevos.

Al año, el banco le ofreció un crédito de auto con mejor tasa que la primera cotización.

> **Idea clave:** tu historial mejora con constancia, no con trucos.



#### Comprueba lo que entendiste

1. ¿Qué es lo más importante para mejorar tu historial?
*Respuesta:* Pagar a tiempo todos los meses.

2. ¿Conviene pedir varios créditos mientras mejoras?
*Respuesta:* No. Muchas solicitudes te afectan.


#### Para recordar

- Pagos puntuales y saldos bajos.
- Nada de solicitudes seguidas.
- Revisa tus reportes cada seis meses.



### Profundiza (5 minutos más)

#### El año de Gael

| Mes | Acción |
|---|---|
| 1 | Pide reportes; corrige un error |
| 2 | Negocia y paga su atraso |
| 3 a 6 | Paga a tiempo; baja tarjetas a 50% |
| 6 | Revisa reportes |
| 7 a 12 | Baja tarjetas a 30%; cero solicitudes |
| 12 | Revisa reportes y compara ofertas de crédito |



#### Tarjeta garantizada

Es una tarjeta en la que dejas un depósito como garantía y te dan una línea igual o parecida. Sirve para construir historial si la usas poco y la pagas completa.

Compara comisiones y verifica que la institución reporte a Buró o Círculo.



#### Automatiza tus pagos

Programa al menos el pago mínimo automático para nunca atrasarte, y paga el resto de forma manual. Un solo atraso puede afectar tu historial por años.



#### Paciencia

Los atrasos pesan menos con el tiempo si ya no hay nuevos. No te desanimes si no ves cambios en un mes: la mejora se nota en meses.

> **Dato adicional:** CONDUSEF recomienda pagar puntualmente, no usar toda tu línea y no pedir más créditos de los que puedes pagar para construir un buen historial. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. El plan de Gael**

Gael tiene un atraso, tarjetas casi al tope y muchas consultas.
- *¿Por dónde empieza?* Pide sus reportes, se pone al corriente y baja el uso de sus tarjetas sin pedir créditos nuevos.


**Caso 2. Sin historial, Valeria**

Valeria no tiene historial y quiere construirlo.
- *¿Qué hace?* Usa una tarjeta pequeña o garantizada para un gasto fijo y la paga completa cada mes.


**Caso 3. Las solicitudes de Renata**

Renata pide tarjetas en tres bancos el mismo mes "para ver cuál la aprueba".
- *¿Le conviene?* No: muchas solicitudes seguidas afectan su historial. Mejor compara antes y pide solo una.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Buscar trucos rápidos | No funcionan o son fraude | Constancia |
| Pedir muchos créditos | Muchas consultas | Pide solo lo necesario |
| Atrasarte "solo un poco" | Afecta por años | Automatiza pagos |
| Rendirte al primer mes | No ves el avance | Revisa cada seis meses |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué ayuda a tu historial? a) Pedir muchas tarjetas · b) Pagar a un despacho que mejore tu historial · c) Pagar a tiempo y mantener saldos bajos
2. No tienes historial. ¿Cómo empiezas? a) Con un crédito grande · b) Con un préstamo por app que no revisa tu historial · c) Con un producto pequeño que pagas completo
3. ¿Cada cuánto revisas tus reportes mientras mejoras? a) Cada cinco años · b) Nunca · c) Cada seis meses
**Respuestas:** 1-c: constancia y saldos bajos. 2-c: construyes historial sin riesgo grande. 3-c: alternando Buró y Círculo, sin costo.



#### Ponlo en práctica

Escribe tu plan de 12 meses para mejorar tu historial.
**Respuesta:** Por ejemplo: mes 1, pido reportes; mes 2, me pongo al corriente; meses 3 a 12, pago a tiempo y bajo tarjetas a 30%; mes 6 y 12, reviso reportes.



#### A tu plan

Programa el pago automático del mínimo de tus tarjetas y escribe tu meta de uso de línea.



### Para saber más

- **Construye tu historial** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para mejorar tu historial crediticio.
- **Reporte de crédito** (Buró de Crédito y Círculo de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** tu reporte gratis; el de Círculo está en circulodecredito.com.mx.

### Palabras clave

- *Tarjeta garantizada:* tarjeta respaldada por un depósito tuyo.
- *Pago automático:* cargo programado para pagar a tiempo.
- *Constancia:* pagar bien mes tras mes.

### Fuentes

CONDUSEF · Buró de Crédito · Círculo de Crédito, consultados el 29 de septiembre de 2026.

---


---

# Módulo 8. Sal de deudas

## M8 U01. Elige tu método: avalancha o bola de nieve

**Lo que lograrás:** Ordenar tus deudas por costo (avalancha) o por saldo (bola de nieve) y sostener el plan con tu mes bajo.

**Para empezar:** Toño ya tiene su inventario: 92,000 en cuatro deudas. Paga un poco de todo, sin orden, y siente que no avanza. En esta lección elegirá un método para salir de deudas más rápido.

### Lo esencial (5 minutos)

#### Paga todos los mínimos y enfoca lo extra

Cualquier método empieza igual: pagas **al menos el mínimo de todas** tus deudas para no atrasarte. Todo el dinero extra lo mandas a **una sola** deuda a la vez.

Cuando la terminas, lo que pagabas a esa deuda se suma a la siguiente.



#### Dos métodos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Avalancha | Primero la deuda más cara (CAT o tasa más alta). | Pagas menos intereses en total. |
| Bola de nieve | Primero la deuda más pequeña. | Ves avances rápido y te motiva. |

#### Antes que todo: los atrasos

Si una deuda está atrasada, ponte al corriente o negocia primero (M8 U02). Un atraso genera intereses moratorios, cobranza y afecta tu historial.



#### Un caso en un minuto

Toño se puso al corriente con la tienda de música. Eligió la avalancha: su tarjeta era la más cara. Paga los mínimos de todo y le pone 2,000 extra a la tarjeta cada mes.

Con su hermano acordó pagos pequeños por escrito, sin intereses.

> **Idea clave:** el mejor método es el que sí vas a sostener.



#### Comprueba lo que entendiste

1. ¿Qué pagas en todas tus deudas?
*Respuesta:* Al menos el mínimo, para no atrasarte.

2. ¿Qué deuda atacas primero con la avalancha?
*Respuesta:* La más cara.


#### Para recordar

- Mínimos en todas; extra a una.
- Avalancha: la más cara primero.
- Bola de nieve: la más pequeña primero.



### Profundiza (5 minutos más)

#### El plan de Toño con la avalancha

| Orden | Deuda | Saldo | Por qué |
|---|---|---|---|
| 0 | Tienda de música | 12,000 | Tenía atraso: primero ponerse al corriente |
| 1 | Tarjeta del Banco A | 38,000 | La más cara |
| 2 | Tienda de música | Resto | Costo alto |
| 3 | Préstamo de nómina | 24,000 | Costo medio |
| 4 | Hermano | 18,000 | Sin intereses, con acuerdo por escrito |



#### ¿Cuánto extra puedes poner?

Usa tu mes bajo: tu sueldo fijo menos tus gastos básicos y los mínimos. Lo que queda, o una parte, es tu extra. En meses buenos, abona más, pero sin descuidar tu fondo de sequía.



#### ¿Cuál elegir?

Si te motiva ver deudas terminadas, empieza con la bola de nieve. Si te importa pagar menos en total, usa la avalancha. También puedes empezar con una deuda pequeña para agarrar impulso y luego pasar a la avalancha.



#### Mientras pagas, no generes deuda nueva

Guarda las tarjetas que estás pagando o úsalas solo para gastos que pagues completos. Si sigues comprando, el plan no avanza.

> **Dato adicional:** CONDUSEF recomienda hacer una lista de tus deudas, priorizar las de mayor costo y no contratar nuevas mientras las liquidas. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. El orden de Toño**

Toño tiene cuatro deudas y una está atrasada.
- *¿Por dónde empieza?* Se pone al corriente con la atrasada y luego ataca la más cara con su extra.


**Caso 2. La motivación de Renata**

Renata se desanima porque su deuda más cara es enorme.
- *¿Qué método le puede servir?* La bola de nieve: terminar primero una deuda pequeña para ver avances.


**Caso 3. El mes bueno de Gael**

Gael cobró un pago grande y tiene su fondo de sequía completo.
- *¿Qué hace con una parte?* Abona extra a la deuda que está atacando en su plan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar un poco de todo sin orden | No terminas ninguna | Enfoca el extra en una |
| Dejar de pagar mínimos | Atrasos | Paga todos los mínimos |
| Seguir usando las tarjetas | La deuda no baja | Pausa las tarjetas |
| Usar todo el fondo de sequía para pagar | Te quedas sin colchón | Conserva tu fondo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Con la avalancha, ¿qué deuda pagas primero? a) La de mayor costo · b) La más pequeña · c) La más antigua
2. ¿Qué haces con las demás deudas mientras atacas una? a) Dejas de pagarlas · b) Pagas al menos el mínimo · c) Pagas la mitad del mínimo
3. Terminas una deuda. ¿Qué haces con lo que le pagabas? a) Lo gastas · b) Pides otro crédito para seguir avanzando · c) Lo sumas a la siguiente deuda
**Respuestas:** 1-a: pagas menos intereses. 2-b: así no te atrasas. 3-c: el efecto se acelera.



#### Ponlo en práctica

Ordena tus deudas con el método que elijas y escribe cuánto extra pondrás cada mes.
**Respuesta:** Por ejemplo: avalancha. 1) Tarjeta A, 25,000; 2) App, 6,000; 3) Tienda, 8,000. Pago mínimos y 1,500 extra a la tarjeta A.



#### A tu plan

Escribe tu orden de pago y programa tu pago extra mensual.



### Para saber más

- **Salir de deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para organizar y pagar tus deudas.
- **Simuladores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** calcula cuánto tardas en pagar con distintos montos.

### Palabras clave

- *Avalancha:* pagar primero la deuda más cara.
- *Bola de nieve:* pagar primero la deuda más pequeña.
- *Pago extra:* lo que abonas por encima del mínimo.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M8 U02. Negociar con el banco: reestructura, convenio o quita

**Lo que lograrás:** Entender cada opción de negociación, qué pedir por escrito y cómo aparece cada una en tu historial.

**Para empezar:** A Toño le llaman para ofrecerle "liquidar su deuda con 40%". Suena a oferta increíble. No sabe si le conviene ni qué pasará con su historial. En esta lección aprenderás a negociar con la información completa.

### Lo esencial (5 minutos)

#### Tres formas de negociar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Reestructura | Cambian las condiciones: más plazo, pago menor, a veces otra tasa. | Pagas todo, con más tiempo. |
| Convenio de pago | Acuerdo para ponerte al corriente en pagos. | Pagas todo, ordenado. |
| Quita | Pagas menos de lo que debes para terminar. | Queda registrado en tu historial. |

#### La quita tiene consecuencias

Con una quita la deuda se cierra, pero tu historial muestra que no pagaste completo, con una clave de observación. Otras instituciones pueden tomarlo en cuenta al prestarte.

Aun así, a veces es la mejor salida. Decide sabiéndolo.



#### Antes de aceptar cualquier acuerdo

1. **Verifica** que quien te llama es la institución o un despacho registrado (M8 U04).
2. **Pide todo por escrito:** monto, plazo, pagos, y qué dirá tu historial.
3. **Paga solo a cuentas de la institución,** nunca a cuentas personales.
4. **Al terminar,** pide tu carta de liquidación o finiquito.



#### Un caso en un minuto

Toño verificó la oferta con su banco. Pidió por escrito la quita de 40% y preguntó cómo se reportaría. Comparó con una reestructura a 24 meses.

Como quería pedir un crédito para su estudio pronto, eligió la reestructura: pagará todo, pero sin quita en su historial.

> **Idea clave:** negocia con todo por escrito y paga solo a la institución.



#### Comprueba lo que entendiste

1. ¿Qué pasa con tu historial si liquidas con quita?
*Respuesta:* Queda registrado con una clave de observación.

2. ¿A qué cuenta pagas un acuerdo?
*Respuesta:* Solo a cuentas de la institución.


#### Para recordar

- Reestructura y convenio: pagas todo.
- Quita: pagas menos, queda registrado.
- Todo por escrito; carta de liquidación al final.



### Profundiza (5 minutos más)

#### Comparación para Toño

| | Reestructura a 24 meses | Quita de 40% |
|---|---|---|
| Pago total | Deuda completa más intereses pactados | 40% de la deuda |
| Pago mensual | Bajo | Uno o pocos pagos |
| Historial | Cuenta pagada completa | Liquidada con quita |
| Conviene si | Quieres crédito pronto | No puedes pagar y necesitas cerrar |



#### Cómo pedir una negociación

Llama tú al número oficial de la institución o ve a sucursal. Explica tu situación con números: cuánto ganas en tu mes bajo y cuánto puedes pagar. Pide opciones y compáralas.

Hazlo antes de atrasarte: tienes más opciones cuando aún estás al corriente.



#### La carta de liquidación

Es tu prueba de que la deuda terminó. Guárdala por años. Si tu reporte sigue mostrando saldo, la usas para reclamar (M7 U07).

> **Dato vigente:** CONDUSEF recomienda formalizar por escrito cualquier acuerdo de pago y obtener la carta de liquidación. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Si no puedes pagar nada

Si hoy no puedes pagar, dilo con claridad y pide un plan. Si tienes varias deudas, busca orientación gratuita en CONDUSEF antes de aceptar cualquier propuesta.



#### Casos


**Caso 1. La oferta de Toño**

A Toño le ofrecen liquidar con 40% por teléfono.
- *¿Qué hace antes de aceptar?* Verifica con el banco, pide la oferta por escrito, pregunta cómo se reportará y compara con una reestructura.


**Caso 2. La cuenta personal de Renata**

Un supuesto gestor le pide a Renata depositar su acuerdo en una cuenta personal.
- *¿Qué hace?* No deposita: paga solo a cuentas de la institución y verifica al gestor.


**Caso 3. El aviso de Gael**

Gael sabe que el próximo mes no podrá pagar su crédito.
- *¿Cuándo negocia?* Antes de atrasarse: llama al banco y pide opciones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar acuerdos por teléfono | Sin prueba | Pide todo por escrito |
| Pagar a cuentas personales | Fraude | Solo a la institución |
| No preguntar por el historial | Sorpresas después | Pregunta cómo se reporta |
| No pedir carta de liquidación | No puedes probar que pagaste | Pídela siempre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué opción deja una clave de observación por pagar menos? a) Reestructura · b) Quita · c) Pago puntual
2. ¿Qué pides al terminar de pagar un acuerdo? a) Carta de liquidación · b) Un regalo · c) Otra tarjeta con mejor línea de crédito
3. ¿Cuándo tienes más opciones para negociar? a) Después de un año de atraso · b) Antes de atrasarte · c) Cuando te demandan
**Respuestas:** 1-b: pagas menos de lo que debías. 2-a: prueba que terminaste. 3-b: estando al corriente hay más opciones.



#### Ponlo en práctica

Escribe lo que dirías al banco para negociar una deuda: tu situación, cuánto puedes pagar y qué pides.
**Respuesta:** Por ejemplo: "Soy músico con ingresos variables; mi mes bajo es 16,000. Puedo pagar 2,000 al mes. Pido una reestructura a 24 meses y la propuesta por escrito."



#### A tu plan

Identifica qué deuda necesitas negociar y llama al número oficial de la institución esta semana.



### Para saber más

- **Reestructuras y convenios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre reestructura, convenios y quitas.
- **Asesoría** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo pedir orientación gratuita sobre tus deudas.

### Palabras clave

- *Reestructura:* cambio de condiciones de un crédito.
- *Convenio de pago:* acuerdo para ponerte al corriente.
- *Quita:* descuento sobre lo que debes para liquidar.
- *Carta de liquidación:* prueba de que terminaste de pagar.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M8 U03. ¿Consolidar deudas me conviene?

**Lo que lograrás:** Comparar el costo total de consolidar contra seguir pagando, y evitar volver a usar las tarjetas liberadas.

**Para empezar:** A Renata le ofrecen "juntar todas sus deudas en un solo pago más bajo". Suena a alivio. Pero si el plazo es más largo o vuelve a usar sus tarjetas, podría terminar debiendo más. En esta lección aprenderás cuándo consolidar sí conviene.

### Lo esencial (5 minutos)

#### Qué es consolidar

**Consolidar** es pedir un crédito nuevo para pagar varias deudas y quedarte con un solo pago.

Puede ayudarte si el crédito nuevo es más barato. Puede perjudicarte si es más caro, más largo o si vuelves a endeudarte.



#### Tres condiciones para que convenga

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Más barato | Su CAT es menor que el de tus deudas actuales. | Compara. |
| Menos pago total | El total a pagar es menor que seguir como estás. | Haz la cuenta. |
| No vuelves a usar las tarjetas | Las cierras o las guardas. | Lo más difícil. |

#### La cuenta de Renata

Lo que pagaría con el crédito de consolidación.
- Pagos: **48**
- Cada pago: **2,900**
- Total a pagar: **139,200**
Hoy debe 95,000. Si siguiendo su plan actual pagaría menos de 139,200, no le conviene.


#### Un caso en un minuto

Renata comparó: con su plan de avalancha pagaría unos 125,000 en 30 meses. La consolidación costaba 139,200 en 48 meses. No le convenía.

Siguió con su plan y cerró dos tarjetas de tienda.

> **Idea clave:** un pago más bajo no significa pagar menos. Compara el total.



#### Comprueba lo que entendiste

1. ¿Cuándo conviene consolidar?
*Respuesta:* Si el crédito nuevo es más barato, el total es menor y no vuelves a usar las tarjetas.

2. ¿Qué pasa si consolidas y sigues usando las tarjetas?
*Respuesta:* Terminas con más deuda que antes.


#### Para recordar

- Compara CAT y total.
- Un pago menor puede costar más.
- No vuelvas a usar las tarjetas liberadas.



### Profundiza (5 minutos más)

#### La trampa más común

Muchas personas consolidan, sienten alivio y vuelven a usar las tarjetas que quedaron en cero. Un año después tienen el crédito de consolidación y las tarjetas llenas otra vez.

Si consolidas, decide antes qué harás con cada tarjeta.



#### Antes de consolidar, pregunta

| Pregunta | Respuesta que buscas |
|---|---|
| ¿Cuál es el CAT? | Menor que el de tus deudas |
| ¿Cuál es el total a pagar? | Menor que seguir como estás |
| ¿Hay comisión por apertura? | Baja o ninguna |
| ¿Hay seguros obligatorios? | Que puedas elegir |
| ¿El pago cabe en tu mes bajo? | Sí, con margen |



#### Verifica a quién te ofrece consolidar

Hay ofertas de consolidación que son fraudes o créditos muy caros. Verifica en el SIPRES y en la CNBV, pide la carátula y no pagues nada por adelantado.

> **Dato adicional:** CONDUSEF advierte que consolidar solo conviene si el nuevo crédito tiene mejores condiciones y no se generan nuevas deudas. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Opciones que puedes revisar

Crédito personal de tu banco, crédito de nómina si cobras por nómina, o transferencia de saldo a una tarjeta con tasa más baja. Compara siempre el total.



#### Casos


**Caso 1. La consolidación de Renata**

La consolidación le costaría 139,200 y su plan actual unos 125,000.
- *¿Le conviene?* No. Sigue con su plan, que cuesta menos en total.


**Caso 2. La transferencia de Gael**

A Gael le ofrecen pasar su deuda a una tarjeta con tasa menor por 12 meses y sin comisión.
- *¿Qué revisa?* La tasa después de los 12 meses, el total a pagar y que no volverá a usar la tarjeta anterior.


**Caso 3. Las tarjetas liberadas de Valeria**

Valeria consolidó sus deudas y sus tarjetas quedaron en cero.
- *¿Qué hace con ellas?* Cierra o guarda las que no necesita y no las vuelve a usar para gastos que no puede pagar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Consolidar por el pago más bajo | Pagas más en total | Compara el total |
| Volver a usar las tarjetas | Doble deuda | Ciérralas o guárdalas |
| No revisar comisiones y seguros | Costo oculto | Pide la carátula |
| Pagar por adelantado para consolidar | Fraude | Nunca pagues antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué debe cumplir una consolidación para convenir? a) Solo que el pago mensual sea menor al que tienes hoy · b) CAT y total menores, y no volver a usar las tarjetas · c) Plazo más largo
2. 36 pagos de 3,500. ¿Cuál es el total? a) 126,000 · b) 3,500 · c) 105,000
3. Te piden un pago por adelantado para consolidar. ¿Qué es? a) Normal · b) Señal de fraude · c) Un seguro que protege tu consolidación
**Respuestas:** 1-b: así realmente pagas menos. 2-a: 36 × 3,500. 3-b: nadie legítimo cobra antes.



#### Ponlo en práctica

Si tienes una oferta de consolidación, calcula su total y compáralo con lo que pagarías siguiendo tu plan.
**Respuesta:** Por ejemplo: consolidación 42 pagos de 2,500 = 105,000. Mi plan actual: unos 98,000 en 28 meses. No me conviene.



#### A tu plan

Si consolidas, escribe qué harás con cada tarjeta liberada antes de firmar.



### Para saber más

- **Consolidación de deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre consolidar deudas.
- **Calculadora del CAT** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** compara el costo de la consolidación.

### Palabras clave

- *Consolidar:* juntar varias deudas en un crédito nuevo.
- *Transferencia de saldo:* pasar deuda de una tarjeta a otra.
- *Tarjeta liberada:* tarjeta que quedó en cero tras consolidar.

### Fuentes

CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M8 U04. Cobranza: tus derechos

**Lo que lograrás:** Conocer lo que un despacho de cobranza puede y no puede hacer, verificarlo en el REDECO y presentar una queja si hay abuso.

**Para empezar:** A Renata le llaman de cobranza a las once de la noche, le gritan y amenazan con "ir a su casa con la policía". También llamaron a su mamá. Renata tiene miedo y quiere pagar lo que sea para que paren. En esta lección conocerás tus derechos frente a la cobranza.

### Lo esencial (5 minutos)

#### Deber no te quita tus derechos

Aunque debas, la cobranza debe ser respetuosa. Un despacho de cobranza puede recordarte tu deuda y ofrecerte opciones, pero no puede amenazarte, intimidarte ni ofenderte.



#### Lo que no pueden hacer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Amenazar o intimidar | A ti, a tu familia o a personas ajenas a la deuda. | Prohibido. |
| Llamar a cualquier hora | Solo en el horario permitido. | Por la noche, no. |
| Hacerse pasar por autoridad | No son policía, juzgado ni gobierno. | Prohibido. |
| Cobrar a cuentas personales | Los pagos van a la institución. | Prohibido. |

#### Verifica al despacho en el REDECO

El **REDECO** de CONDUSEF es el registro de despachos de cobranza. Ahí verificas si el despacho está registrado y presentas una queja si te trata mal.



#### Un caso en un minuto

Renata pidió al despacho su nombre, el de la institución y el monto. Lo buscó en el REDECO y presentó una queja por las amenazas y la hora de la llamada.

Después llamó directamente a la institución para negociar un convenio (M8 U02).

> **Idea clave:** deber no le da derecho a nadie a amenazarte.



#### Comprueba lo que entendiste

1. ¿Pueden amenazarte con la policía por una deuda?
*Respuesta:* No. Es una práctica prohibida.

2. ¿Dónde presentas una queja contra un despacho de cobranza?
*Respuesta:* En el REDECO de CONDUSEF.


#### Para recordar

- La cobranza debe ser respetuosa.
- Verifica al despacho en el REDECO.
- Paga solo a la institución.



### Profundiza (5 minutos más)

#### Horario permitido

Los despachos solo pueden contactarte o presentarse de **7:00 a 22:00 horas**, según el huso horario de tu domicilio.

> **Dato vigente:** Disposiciones de carácter general de CONDUSEF en materia de despachos de cobranza (DOF 7 de octubre de 2014). Consultado el 29 de septiembre de 2026 a través del DOF y CONDUSEF.



#### Lo que puedes pedir en cada llamada

| Pregunta | Para qué |
|---|---|
| ¿Cuál es el nombre del despacho? | Verificarlo en el REDECO |
| ¿Qué institución los contrató? | Confirmar con la institución |
| ¿Cuál es el monto y de qué crédito? | Saber si es tuya y correcta |
| ¿A qué cuenta se paga? | Asegurar que es de la institución |



#### Deuda no es cárcel

En México no hay prisión por deudas de carácter civil. Una amenaza de cárcel por no pagar una tarjeta es falsa. Solo un juez puede ordenar un embargo, después de un juicio.



#### Guarda evidencia

Anota fecha, hora, número y lo que te dijeron. Guarda mensajes y grabaciones si las tienes. Te sirven para tu queja.

> **Dato vigente:** CONDUSEF prohíbe a los despachos de cobranza amenazar, ofender o intimidar al deudor, a su familia o a personas ajenas a la deuda, y opera el REDECO para recibir quejas. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. La llamada nocturna de Renata**

A Renata le llaman a las 11 de la noche y la amenazan con la policía.
- *¿Qué hace?* Pide los datos del despacho, lo verifica en el REDECO y presenta una queja.


**Caso 2. La cuenta de Gael**

Un despacho le pide a Gael depositar en una cuenta personal "para agilizar".
- *¿Qué hace?* No deposita: paga solo a cuentas de la institución y lo confirma con ella.


**Caso 3. La mamá de Toño**

Un despacho llama a la mamá de Toño y la presiona para que pague.
- *¿Qué puede hacer Toño?* Presentar una queja en el REDECO: no pueden intimidar a personas ajenas a la deuda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por miedo sin verificar | Puedes pagar a un fraude | Verifica primero |
| Depositar a cuentas personales | Pierdes el dinero | Solo a la institución |
| Creer las amenazas de cárcel | Te paralizan | No hay cárcel por deudas civiles |
| No guardar evidencia | Tu queja pierde fuerza | Anota todo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué registro de CONDUSEF sirve para verificar despachos de cobranza? a) RECA · b) SIPRES · c) REDECO
2. ¿Pueden amenazar a tu familia por tu deuda? a) No · b) Sí · c) Solo si viven contigo
3. Te piden pagar a una cuenta personal. ¿Qué haces? a) Pagas para que dejen de llamar · b) Pagas solo a la institución · c) Pagas la mitad
**Respuestas:** 1-c: es el registro de despachos. 2-a: está prohibido. 3-b: evita fraudes.



#### Ponlo en práctica

Escribe las cuatro preguntas que harás la próxima vez que te llamen de cobranza.
**Respuesta:** Por ejemplo: ¿nombre del despacho?, ¿qué institución los contrató?, ¿monto y crédito?, ¿a qué cuenta de la institución se paga?



#### A tu plan

Guarda el enlace del REDECO y anota cada llamada de cobranza con fecha y hora.



### Para saber más

- **REDECO** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "REDECO" para verificar despachos y presentar quejas.
- **¿Un despacho de cobranza viola tus derechos?** (CONDUSEF · español): https://revista.condusef.gob.mx — **Qué buscar:** la guía de prácticas prohibidas.

### Palabras clave

- *Despacho de cobranza:* empresa que cobra deudas por encargo de una institución.
- *REDECO:* registro y buzón de quejas de despachos de cobranza.
- *Embargo:* medida que solo un juez puede ordenar.

### Fuentes

CONDUSEF, REDECO y disposiciones sobre despachos de cobranza, consultados el 29 de septiembre de 2026.

---

## M8 U05. Tu plan de salida con ingreso variable

**Lo que lograrás:** Definir un pago base con tu mes bajo, abonar extra en meses buenos y fijar fechas de revisión hasta salir de deudas.

**Para empezar:** Valeria quiere salir de deudas en un año. Cuando le va bien paga mucho; cuando no, deja de pagar. Así su plan nunca avanza. En esta lección armarás un plan que funciona con ingresos que suben y bajan.

### Lo esencial (5 minutos)

#### Tu plan en tres piezas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pago base | Lo que pagas siempre, aun en tu mes bajo. | Nunca falla. |
| Pago extra | Un porcentaje de lo que cobres por encima de tu sueldo. | En meses buenos. |
| Revisión | Cada tres meses revisas y ajustas. | Te mantiene en ruta. |

#### El pago base de Valeria

Con su mes bajo de 20,000.
- Mes bajo: **20,000**
- Gastos básicos: **16,000**
- Su pago base a deudas: **4,000**
En meses buenos, además, manda 30% de lo que cobre por encima de su sueldo.


#### Primero tu fondo, luego lo extra

Si tu fondo de sequía está vacío, llena al menos un mes de gastos antes de hacer pagos extra grandes. Si no, en la siguiente sequía volverás a usar la tarjeta.



#### Un caso en un minuto

Valeria paga 4,000 cada mes pase lo que pase. En abril cobró 60,000: apartó impuestos, completó un mes de fondo y mandó 9,000 extra a su deuda más cara.

Cada tres meses revisa su inventario. En un año bajó su deuda de 70,000 a 11,000.

> **Idea clave:** un pago base fijo y extras en meses buenos te sacan de deudas aunque tu ingreso cambie.



#### Comprueba lo que entendiste

1. ¿Con qué mes calculas tu pago base?
*Respuesta:* Con tu mes bajo.

2. Cobras un pago grande y tu fondo está vacío. ¿Qué haces primero?
*Respuesta:* Apartas impuestos y llenas al menos un mes de fondo antes de pagos extra grandes.


#### Para recordar

- Pago base que nunca falla.
- Extras en meses buenos.
- Revisa cada tres meses.



### Profundiza (5 minutos más)

#### Un año del plan de Valeria

| Trimestre | Pago base | Extras | Deuda al final |
|---|---|---|---|
| 1 | 12,000 | 9,000 | 52,000 |
| 2 | 12,000 | 4,000 | 38,000 |
| 3 | 12,000 | 6,000 | 22,000 |
| 4 | 12,000 | 0 | 11,000 |



#### Celebra sin endeudarte

Cuando termines una deuda, celebra con algo que puedas pagar de contado. Reconocer tus avances te ayuda a seguir.



#### Si un mes no puedes con el pago base

Habla con tus acreedores antes de la fecha límite. Usa tu fondo de sequía para cubrir el pago base. Ajusta tu plan en la siguiente revisión.



#### No lo hagas en soledad

Comparte tu plan con alguien de confianza o con la comunidad del programa. Pedir orientación gratuita en CONDUSEF también es parte del plan.

> **Dato adicional:** CONDUSEF ofrece asesoría gratuita para organizar deudas y negociar con instituciones. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Casos


**Caso 1. El pago base de Valeria**

Mes bajo de 20,000 y gastos básicos de 16,000.
- *¿Cuál es su pago base a deudas?* 4,000 al mes, pase lo que pase.


**Caso 2. El pago grande de Gael**

Gael cobra 80,000 y su fondo de sequía está vacío.
- *¿En qué orden reparte?* Impuestos, luego un mes de fondo, luego un pago extra a su deuda y una parte para vivir.


**Caso 3. El mes difícil de Toño**

Toño no puede cubrir su pago base este mes.
- *¿Qué hace?* Usa su fondo para el pago base, habla con sus acreedores antes de la fecha y ajusta su plan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar solo cuando te va bien | El plan no avanza | Pago base siempre |
| Mandar todo a deudas sin fondo | Vuelves a la tarjeta | Primero un mes de fondo |
| No revisar | Pierdes el rumbo | Revisa cada tres meses |
| Celebrar con crédito | Nueva deuda | Celebra de contado |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Mes bajo de 18,000 y gastos básicos de 15,000. ¿Pago base a deudas? a) 18,000 · b) 15,000 · c) 3,000
2. ¿Cada cuánto revisas tu plan? a) Cada cinco años · b) Cada tres meses · c) Nunca
3. Cobraste mucho y tu fondo está vacío. ¿Qué haces primero? a) Todo a deudas · b) Impuestos y un mes de fondo · c) Todo a gastos, porque te lo mereces
**Respuestas:** 1-c: 18,000 − 15,000. 2-b: así ajustas a tiempo. 3-b: así evitas volver a endeudarte.



#### Ponlo en práctica

Calcula tu pago base y decide qué porcentaje de tus meses buenos irá a deudas.
**Respuesta:** Por ejemplo: mes bajo 22,000, gastos básicos 18,000: pago base 4,000. En meses buenos, 30% de lo que cobre arriba de mi sueldo.



#### A tu plan

Escribe tu plan de salida con pago base, porcentaje extra y tus fechas de revisión.



### Para saber más

- **Asesoría para tus deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** orientación gratuita y guías para salir de deudas.
- **Calculadora de pagos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" para ver en cuánto tiempo terminas.

### Palabras clave

- *Pago base:* lo que pagas a deudas cada mes, pase lo que pase.
- *Pago extra:* abono adicional en meses buenos.
- *Revisión:* momento para ajustar tu plan.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


---

# Módulo 9. No caigas: fraudes y robo de identidad

## M9 U01. Cómo piensa quien te quiere estafar

**Lo que lograrás:** Reconocer los cuatro ganchos de casi todo fraude (urgencia, autoridad, premio y miedo) y aplicar la regla de oro: cuelga y verifica por tu cuenta.

**Para empezar:** A Valeria le llama "el área de seguridad de su banco". Le dicen que hay un cargo sospechoso y que, para cancelarlo, necesitan el código que le acaba de llegar por mensaje. Suena urgente y profesional. En esta lección aprenderás a reconocer cómo funcionan los fraudes.

### Lo esencial (5 minutos)

#### Los cuatro ganchos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Urgencia | "Tienes que hacerlo ahora". | Te quita tiempo para pensar. |
| Autoridad | "Te hablamos del banco, del SAT, de CONDUSEF". | Te hace confiar. |
| Premio | "Ganaste", "casting exclusivo", "rendimiento garantizado". | Te emociona. |
| Miedo | "Te van a bloquear", "hay una denuncia". | Te paraliza. |

#### La regla de oro: cuelga y verifica

Si alguien te contacta y te pide datos, dinero o códigos, **cuelga**. Busca tú el teléfono oficial (en tu tarjeta o en el sitio oficial) y llama.

Si era real, te lo confirmarán. Si era fraude, te salvaste.



#### Lo que nunca compartes

NIP, contraseñas, códigos que te llegan por mensaje, el código de seguridad de tu tarjeta (CVV) y tu e.firma. Ningún banco ni autoridad te los pide por teléfono, mensaje o correo.



#### Un caso en un minuto

Valeria reconoció la urgencia y el miedo. Colgó, llamó al número de su tarjeta y el banco le confirmó que no había ningún cargo sospechoso.

El código que le pedían servía para autorizar una transferencia desde su cuenta.

> **Idea clave:** urgencia + petición de datos o dinero = cuelga y verifica.



#### Comprueba lo que entendiste

1. ¿Qué haces si te llaman del banco y te piden un código?
*Respuesta:* Cuelgas y llamas tú al número oficial.

2. ¿Cuáles son los cuatro ganchos del fraude?
*Respuesta:* Urgencia, autoridad, premio y miedo.


#### Para recordar

- Urgencia, autoridad, premio y miedo.
- Cuelga y verifica tú.
- Nunca compartas códigos ni contraseñas.



### Profundiza (5 minutos más)

#### Por qué la gente del medio es blanco

Tu nombre, tu cara y tu trabajo son públicos. Los estafadores saben con quién trabajas, qué proyectos tienes y qué te emociona. Usan esa información para sonar creíbles.

Cuida lo que publicas: fechas de pago, nombres de tu banco, tu agenda de viajes.



#### Frases que encienden la alarma

| Frase | Gancho |
|---|---|
| "Es urgente, si no se bloquea tu cuenta" | Miedo y urgencia |
| "Te llamamos de la CONDUSEF para un préstamo" | Autoridad falsa |
| "Quedaste en el casting, solo paga el book" | Premio |
| "Dame el código para cancelar el cargo" | Petición de datos |



#### Habla antes de actuar

Si dudas, cuéntaselo a alguien de confianza antes de hacer cualquier pago. Muchas personas se salvan solo por comentarlo.

> **Dato vigente:** CONDUSEF y los bancos advierten que nunca te pedirán NIP, contraseñas ni códigos por teléfono o mensaje. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Reporta

Reporta números y cuentas sospechosas a tu banco y a CONDUSEF. Si fuiste víctima de un delito en línea, llama al 088 (M9 U08).



#### Casos


**Caso 1. El "área de seguridad" de Valeria**

Le piden a Valeria el código que le llegó por mensaje para "cancelar un cargo".
- *¿Qué hace?* Cuelga, llama al número de su tarjeta y no comparte el código.


**Caso 2. El premio de Gael**

Le escriben a Gael: "Ganaste un auto en la rifa del medio; paga 2,500 del trámite".
- *¿Qué hace?* No paga: es el gancho del premio. Verifica por su cuenta y lo reporta.


**Caso 3. La denuncia falsa de Toño**

Le llaman a Toño diciendo que hay una denuncia en su contra y que pague para "arreglarlo".
- *¿Qué hace?* Cuelga: es el gancho del miedo. Ninguna autoridad cobra por teléfono.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Actuar con prisa | Caes en el gancho de urgencia | Cuelga y respira |
| Confiar en el identificador de llamadas | Se puede falsificar | Llama tú al número oficial |
| Compartir códigos | Autorizas operaciones | Nunca lo hagas |
| Publicar tus datos | Les das información | Cuida lo que compartes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden el código que te llegó por mensaje "para cancelar un cargo". ¿Qué haces? a) Lo das para cancelar rápido · b) Lo mandas por WhatsApp al número que te llamó · c) Cuelgas y llamas al número oficial
2. ¿Qué gancho usa "si no pagas hoy, te bloqueamos"? a) Premio, porque te ofrecen algo · b) Ninguno · c) Urgencia y miedo
3. ¿Quién te puede pedir tu NIP por teléfono? a) Tu banco · b) CONDUSEF · c) Nadie
**Respuestas:** 1-c: la regla de oro. 2-c: te presiona para no pensar. 3-c: ninguna institución lo pide.



#### Ponlo en práctica

Recuerda un mensaje o llamada sospechosa que hayas recibido. ¿Qué gancho usaba?
**Respuesta:** Por ejemplo: "Tu paquete está retenido, paga 49 pesos". Usaba urgencia y un enlace falso. Lo borré y lo reporté.



#### A tu plan

Guarda en tu celular los números oficiales de tu banco y escribe tu regla: "Cuelgo y verifico".



### Para saber más

- **Portal de Fraudes Financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** tipos de fraude y cómo reportarlos.
- **Ciberseguridad ciudadana** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** recomendaciones y cómo reportar al 088.

### Palabras clave

- *Fraude:* engaño para quitarte dinero o datos.
- *Ingeniería social:* manipular a las personas para que den información.
- *CVV:* código de seguridad de tu tarjeta.

### Fuentes

CONDUSEF · Guardia Nacional CERT-MX, consultados el 29 de septiembre de 2026.

---

## M9 U02. Falsos castings, productoras y agencias que cobran

**Lo que lograrás:** Reconocer convocatorias que cobran por audicionar, exigen un book con un proveedor único, suplantan productoras reales o piden datos de más, y verificarlas antes de ir o pagar.

**Para empezar:** Gael recibe por Instagram una invitación a un "casting para una serie de plataforma". Le piden 3,500 para el "material fotográfico obligatorio" y copia de su INE para "registrarlo". La cuenta usa el logotipo de una productora real. En esta lección aprenderás a detectar falsos castings.

### Lo esencial (5 minutos)

#### Señales de un falso casting

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te cobran | Por audicionar, inscribirte o "quedar en el catálogo". | Alerta. |
| Book obligatorio | Con su fotógrafo, a un precio fijo. | Alerta. |
| Piden datos de más | INE, CURP, datos bancarios antes de contratarte. | Alerta. |
| Contacto informal | Solo por redes o WhatsApp, sin correo ni sitio oficial. | Verifica. |

#### Verifica la convocatoria

- Busca la convocatoria en el sitio o las redes **oficiales** de la productora o agencia.
- Llama o escribe tú al contacto oficial para confirmar.
- Pregunta a colegas, a tu sindicato o a la comunidad del programa.
- Revisa que el lugar del casting exista y sea profesional.



#### Nunca pagues por audicionar

Una producción real no te cobra por una audición. Te paga cuando te contrata. Las agencias legítimas cobran comisión sobre tu trabajo (M3 U03), no inscripciones.



#### Un caso en un minuto

Gael buscó a la productora en su sitio oficial. No había convocatoria. Escribió al correo oficial y le confirmaron que era un fraude que usaba su nombre.

No pagó, no mandó su INE y reportó la cuenta.

> **Idea clave:** si te cobran por audicionar, no es un casting: es un negocio a tu costa.



#### Comprueba lo que entendiste

1. ¿Una producción real te cobra por audicionar?
*Respuesta:* No. Te paga cuando te contrata.

2. ¿Qué haces con una convocatoria por redes?
*Respuesta:* La verificas en el sitio oficial y con el contacto oficial de la productora.


#### Para recordar

- Nunca pagues por audicionar.
- Book con proveedor único: alerta.
- Verifica en canales oficiales.



### Profundiza (5 minutos más)

#### Tus datos también valen

Aunque no pagues, dar tu INE, CURP o datos bancarios a un falso casting permite abrir créditos a tu nombre (M9 U04). Solo entrégalos cuando ya firmaste con una empresa verificada.



#### Real o falso

| | Casting real | Falso casting |
|---|---|---|
| Costo para ti | Ninguno | Inscripción, book, "material" |
| Contacto | Oficial y verificable | Solo redes o WhatsApp |
| Datos que piden | Perfil y material de trabajo | INE, CURP, cuenta bancaria desde el inicio |
| Lugar | Oficinas o foros conocidos | Casas, hoteles, lugares cambiantes |
| Presión | Tiempos normales | "Solo hoy", "cupo limitado" |



#### Seguridad personal

Nunca vayas sola o solo a un casting en un lugar desconocido. Avisa a alguien dónde estarás. Si algo te hace sentir incómodo, vete.



#### Si ya pagaste

Guarda pruebas, pide a tu banco revisar el cargo si pagaste con tarjeta, denuncia ante la fiscalía o al 088 y avisa en tu comunidad sin exponer tus datos. Si diste tu INE, protege tu historial (M7 U08).

> **Dato vigente:** el 088 recibe reportes de fraudes y delitos en línea las 24 horas. Consultado el 29 de septiembre de 2026 a través de la Guardia Nacional.



#### Casos


**Caso 1. El casting de Gael**

Le piden a Gael 3,500 por "material fotográfico obligatorio" y su INE.
- *¿Qué hace?* Verifica con la productora por su canal oficial, no paga ni manda su INE y reporta la cuenta.


**Caso 2. La agencia de Renata**

Una agencia le pide a Renata 1,800 para "estar en su catálogo".
- *¿Qué hace?* No paga: las agencias legítimas cobran comisión cuando trabajas, no inscripción.


**Caso 3. El lugar de Valeria**

El casting de Valeria es en una casa particular y le piden ir sola.
- *¿Qué hace?* Verifica la convocatoria, no va sola, avisa a alguien o no asiste.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por audicionar | Pierdes dinero | Nunca pagues |
| Mandar tu INE desde el inicio | Robo de identidad | Solo al firmar con empresa verificada |
| Confiar en logotipos | Se copian fácil | Verifica en canales oficiales |
| Ir sola o solo a lugares desconocidos | Riesgo personal | Avisa y acompáñate |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden pagar por audicionar. ¿Qué es? a) Algo normal · b) Un seguro para tu audición · c) Señal de falso casting
2. ¿Cuándo entregas tu INE a una productora? a) Cuando ya firmaste con una empresa verificada · b) Desde el primer mensaje · c) Por Instagram, cuando te lo pidan por mensaje directo
3. ¿Cómo verificas una convocatoria? a) Por el logotipo · b) Por los "me gusta" y seguidores de la cuenta que publica · c) En el sitio y contacto oficial de la productora
**Respuestas:** 1-c: las producciones reales no cobran. 2-a: tus datos valen. 3-c: los logotipos se copian.



#### Ponlo en práctica

Escribe tu lista de verificación de castings con cinco preguntas.
**Respuesta:** Por ejemplo: ¿me cobran? ¿está en el sitio oficial? ¿confirmé por el contacto oficial? ¿qué datos piden? ¿dónde es y quién me acompaña?



#### A tu plan

Guarda los contactos oficiales de las productoras y agencias con las que trabajas.



### Para saber más

- **Fraudes en línea** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** cómo reportar al 088 y recomendaciones.
- **Profeco** (Gobierno de México · español): https://www.gob.mx/profeco — **Qué buscar:** orientación si una agencia te vendió un servicio que no cumple.

### Palabras clave

- *Falso casting:* convocatoria que busca tu dinero o tus datos.
- *Suplantación:* usar el nombre de otra empresa para engañar.
- *Book:* portafolio de fotos profesionales.

### Fuentes

Guardia Nacional CERT-MX · Profeco, consultados el 29 de septiembre de 2026.

---

## M9 U03. Llamadas, mensajes y páginas falsas

**Lo que lograrás:** Identificar mensajes, correos y páginas que imitan a tu banco, al SAT, a paqueterías o a plataformas, y proteger tus datos.

**Para empezar:** Renata recibió un mensaje: "Tu cuenta de Banco X fue bloqueada. Entra aquí para reactivarla". La página se veía igual a la de su banco. Puso su usuario y contraseña. Una hora después le vaciaron la cuenta. En esta lección aprenderás a reconocer el **phishing**.

### Lo esencial (5 minutos)

#### Qué es el phishing

El **phishing** usa mensajes, correos o páginas que imitan a una empresa real para que escribas tus datos. Llega por SMS, WhatsApp, correo o redes.



#### Señales de un mensaje falso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Un enlace | Te piden entrar desde el mensaje. | No lo abras. |
| Urgencia | "Bloqueo", "cargo", "último aviso". | Alerta. |
| Errores | Faltas de ortografía, direcciones raras. | Alerta. |
| Te piden datos | Usuario, contraseña, NIP, códigos. | Nunca. |

#### Escribe tú la dirección

Nunca entres a tu banco, al SAT o a una plataforma desde un enlace de un mensaje. Abre la app oficial o escribe tú la dirección en el navegador.



#### Un caso en un minuto

Renata llamó a su banco al número de su tarjeta, bloqueó su cuenta y presentó una reclamación. Cambió sus contraseñas y activó la verificación en dos pasos.

Desde entonces, entra a su banco solo desde la app oficial.

> **Idea clave:** los enlaces de mensajes no se abren. Entra tú por la app o el sitio oficial.



#### Comprueba lo que entendiste

1. Te llega un mensaje de tu banco con un enlace para "reactivar tu cuenta". ¿Qué haces?
*Respuesta:* No lo abres; entras por la app oficial o llamas al banco.

2. ¿Qué datos no escribes nunca en una página que llegó por mensaje?
*Respuesta:* Usuario, contraseña, NIP y códigos.


#### Para recordar

- No abras enlaces de mensajes.
- Entra por la app o el sitio oficial.
- Si ya caíste, llama a tu banco de inmediato.



### Profundiza (5 minutos más)

#### Fraudes comunes por mensaje

| Mensaje | Qué buscan |
|---|---|
| "Tu cuenta fue bloqueada" | Tus claves del banco |
| "Tu paquete está retenido, paga 49 pesos" | Los datos de tu tarjeta |
| "Tienes un reembolso del SAT" | Tus datos fiscales y bancarios |
| "Ganaste un premio" | Datos y pagos por "trámite" |
| "Te etiquetaron en un video" | Tu cuenta de redes |



#### Protege tus cuentas

- Usa contraseñas distintas para tu banco, tu correo y tus redes.
- Activa la verificación en dos pasos.
- Activa las notificaciones de movimientos de tu banco.
- Actualiza tu celular y tus apps.



#### Si ya caíste

Llama a tu banco al número oficial y pide bloquear tus cuentas y tarjetas. Cambia tus contraseñas desde otro dispositivo. Presenta una reclamación por escrito y guarda tu folio (M9 U08).

> **Dato vigente:** CONDUSEF recomienda no abrir enlaces de mensajes y reclamar de inmediato cargos no reconocidos. Consultado el 29 de septiembre de 2026 a través de CONDUSEF.



#### Avisa a los demás

Si te llega un fraude que suplanta a una institución, repórtalo a esa institución y a CONDUSEF. Avisa en tu comunidad para que nadie más caiga.



#### Casos


**Caso 1. El mensaje de Renata**

Renata recibe un mensaje de "su banco" con un enlace para reactivar su cuenta.
- *¿Qué debió hacer?* No abrir el enlace y entrar por la app oficial o llamar al banco.


**Caso 2. El paquete de Valeria**

A Valeria le llega un mensaje: "Tu paquete está retenido, paga 49 pesos aquí".
- *¿Qué hace?* No paga ni abre el enlace. Verifica con la paquetería por su sitio oficial.


**Caso 3. El reembolso de Gael**

Un correo le dice a Gael que tiene un reembolso del SAT y le pide su cuenta y su contraseña.
- *¿Qué hace?* No responde: revisa su situación entrando él mismo al portal oficial del SAT.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Abrir enlaces de mensajes | Páginas falsas | Entra tú |
| Usar la misma contraseña | Te roban todo | Contraseñas distintas |
| No activar la verificación en dos pasos | Cuentas vulnerables | Actívala |
| Tardar en llamar al banco | Pierdes más dinero | Llama de inmediato |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cómo entras a tu banco de forma segura? a) Desde la app oficial o escribiendo la dirección · b) Desde el enlace del mensaje · c) Desde un anuncio patrocinado en tus redes sociales
2. ¿Qué ayuda a proteger tus cuentas? a) Usar la misma contraseña · b) Compartir tu código · c) Verificación en dos pasos
3. Ya escribiste tus claves en una página falsa. ¿Qué haces primero? a) Llamas a tu banco para bloquear · b) Esperas · c) Borras el mensaje y sigues con tu día
**Respuestas:** 1-a: evitas páginas falsas. 2-c: agrega una capa de seguridad. 3-a: cada minuto cuenta.



#### Ponlo en práctica

Revisa tus cuentas más importantes y anota cuáles tienen verificación en dos pasos.
**Respuesta:** Por ejemplo: correo sí; banco sí; Instagram no; TikTok no. Esta semana la activo en mis redes.



#### A tu plan

Activa la verificación en dos pasos en tu correo, tu banco y tus redes.



### Para saber más

- **Fraudes financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "phishing" y cómo reportar.
- **Ciberseguridad** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** recomendaciones para proteger tus cuentas.

### Palabras clave

- *Phishing:* mensajes o páginas falsas para robar tus datos.
- *Verificación en dos pasos:* segunda comprobación además de la contraseña.
- *Enlace:* dirección que te lleva a una página.

### Fuentes

CONDUSEF · Guardia Nacional CERT-MX, consultados el 29 de septiembre de 2026.

---

## M9 U04. Robo de identidad: cuando usan tu nombre

**Lo que lograrás:** Reconocer las señales del robo de identidad, cuidar tus documentos y saber qué hacer: bloqueo, reclamaciones, CONDUSEF y denuncia.

**Para empezar:** A Toño le llega una cobranza por un préstamo que nunca pidió. Alguien lo abrió con una copia de su INE que dejó en un casting hace un año. Toño no sabe cómo probar que no fue él. En esta lección aprenderás a prevenir y actuar ante el robo de identidad.

### Lo esencial (5 minutos)

#### Qué es el robo de identidad

Es cuando alguien usa tus datos o documentos para hacerse pasar por ti: abrir créditos, contratar servicios o hacer compras a tu nombre.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobranza de deudas que no conoces | Te llaman por créditos que no pediste. | Revisa tus reportes. |
| Créditos o consultas desconocidas | Aparecen en tu Buró o Círculo. | Reclama. |
| Tarjetas o estados de cuenta que no pediste | Llegan a tu domicilio o correo. | Investiga. |
| Te niegan un crédito sin razón | Puede haber algo a tu nombre. | Revisa. |

#### Si te pasa

1. **Pide tus reportes** en Buró y Círculo e identifica lo que no reconoces.
2. **Activa el bloqueo y las alertas** (M7 U08).
3. **Reclama a la institución** en su UNE, indicando posible robo de identidad.
4. **Reclama en la sociedad** donde aparece el crédito (M7 U07).
5. **Presenta tu denuncia** ante la fiscalía o reporta al 088, y acude a CONDUSEF.



#### Un caso en un minuto

Toño siguió los pasos: pidió sus reportes, activó el bloqueo, reclamó a la financiera y en la sociedad, y presentó su denuncia.

Con la denuncia y su reclamación, la financiera investigó y el crédito se canceló.

> **Idea clave:** actúa rápido y deja todo por escrito: reclamaciones, folios y denuncia.



#### Comprueba lo que entendiste

1. ¿Qué señal puede indicar robo de identidad?
*Respuesta:* Una cobranza por un crédito que no pediste.

2. ¿Qué documento te ayuda a probar que no fuiste tú?
*Respuesta:* Tu denuncia, junto con tus reclamaciones y folios.


#### Para recordar

- Revisa tus reportes.
- Bloqueo, reclamaciones y denuncia.
- Todo por escrito, con folio.



### Profundiza (5 minutos más)

#### Cuida tus documentos

- Cuando entregues una copia de tu INE, escribe encima para qué es y la fecha: "Solo para contrato con X, 29/09/2026".
- No mandes fotos de tu INE por redes ni a desconocidos.
- Guarda tu INE, CURP, RFC y e.firma en un lugar seguro.
- Destruye documentos con datos antes de tirarlos.



#### Tu expediente de robo de identidad

| Documento | Para qué |
|---|---|
| Reportes de crédito con lo que no reconoces | Mostrar el problema |
| Reclamaciones con folio | Probar que avisaste |
| Denuncia | Probar el delito |
| Identificación | Demostrar quién eres |



#### CONDUSEF te orienta

Si la institución no resuelve tu reclamación, acude a CONDUSEF con tus folios y tu denuncia. CONDUSEF tiene guías y te ayuda a presentar tu caso.

> **Dato vigente:** servicios de Bloqueo y Alertas de Buró de Crédito, reclamaciones ante sociedades de información crediticia y reporte al 088. Consultado el 29 de septiembre de 2026 a través de Buró de Crédito, CONDUSEF y la Guardia Nacional.



#### Revisa con frecuencia

Si tus datos se expusieron, revisa tus reportes con más frecuencia durante un año, alternando Buró y Círculo (M7 U03).



#### Casos


**Caso 1. El préstamo de Toño**

A Toño le cobran un préstamo que abrieron con su INE.
- *¿Qué hace?* Pide sus reportes, activa el bloqueo, reclama a la financiera y en la sociedad, y presenta denuncia.


**Caso 2. La copia de Valeria**

Una agencia le pide a Valeria copia de su INE.
- *¿Cómo la protege?* Escribe encima para qué es y la fecha, y solo la entrega a una empresa verificada.


**Caso 3. La tarjeta de Renata**

A Renata le llega una tarjeta de crédito que nunca pidió.
- *¿Qué hace?* No la activa, llama a la institución, revisa sus reportes y reclama si hay algo más.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ignorar cobranzas desconocidas | La deuda crece a tu nombre | Investiga de inmediato |
| No denunciar | Te cuesta probar que no fuiste tú | Presenta tu denuncia |
| Dar copias de tu INE sin marcar | Pueden usarlas | Escribe para qué es |
| Reclamar solo por teléfono | Sin prueba | Por escrito con folio |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es una señal de robo de identidad? a) Tu estado de cuenta mensual · b) Una promoción nueva de tu banco por correo · c) Un crédito en tu reporte que no pediste
2. ¿Qué escribes en una copia de tu INE? a) Tu contraseña · b) Nada, así sirve para cualquier trámite · c) Para qué es y la fecha
3. ¿Qué te ayuda a probar que no pediste un crédito? a) Un mensaje en redes · b) Pagarlo para demostrar tu buena fe · c) Denuncia, reclamaciones y folios
**Respuestas:** 1-c: alguien usó tus datos. 2-c: limita su uso. 3-c: son tus pruebas.



#### Ponlo en práctica

Escribe tu plan de acción si mañana te cobran un crédito que no pediste.
**Respuesta:** Por ejemplo: pido reportes, activo bloqueo y alertas, reclamo a la institución y en la sociedad por escrito, denuncio y guardo todos los folios.



#### A tu plan

Revisa dónde guardas tus documentos y marca las copias de INE que entregues a partir de hoy.



### Para saber más

- **Robo de identidad** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guía de robo de identidad y qué hacer.
- **Bloqueo** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** cómo bloquear tu historial.
- **088** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** cómo reportar delitos en línea.

### Palabras clave

- *Robo de identidad:* uso de tus datos para hacerse pasar por ti.
- *Denuncia:* aviso formal de un delito.
- *Folio:* número de seguimiento de tu trámite.

### Fuentes

CONDUSEF · Buró de Crédito · Guardia Nacional CERT-MX, consultados el 29 de septiembre de 2026.

---

## M9 U05. Tus redes y tu teléfono: robo de cuentas y de línea

**Lo que lograrás:** Proteger tus cuentas de redes, que son tu vitrina de trabajo, y tu línea de celular, y saber qué hacer si te las roban.

**Para empezar:** A Valeria le roban su Instagram de 80,000 seguidores. Los ladrones escriben a sus contactos pidiendo dinero "para una emergencia" y a ella le piden un "rescate" para devolverle la cuenta. Sus campañas dependen de esa cuenta. En esta lección aprenderás a protegerla.

### Lo esencial (5 minutos)

#### Tu cuenta es tu vitrina

Para mucha gente del medio, las redes son su portafolio, su contacto con marcas y parte de su ingreso. Perderlas cuesta dinero.

Protégelas como protegerías tu cuenta del banco.



#### Cuatro protecciones básicas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Verificación en dos pasos | Con app de autenticación, mejor que SMS. | Actívala hoy. |
| Correo seguro | El correo de tus redes con su propia verificación. | Es la llave de todo. |
| Códigos de respaldo | Guárdalos fuera del celular. | Para recuperar tu cuenta. |
| Accesos compartidos | Da acceso a tu equipo con roles, no tu contraseña. | Revisa quién entra. |

#### Tu línea también se puede robar

Si alguien se queda con tu número (por ejemplo, con un cambio de chip o portabilidad sin tu permiso), puede recibir tus códigos por mensaje. Por eso conviene usar una app de autenticación en lugar de SMS cuando sea posible.

Si de pronto tu celular se queda sin señal sin razón, llama a tu compañía telefónica desde otro teléfono.



#### Un caso en un minuto

Valeria no pagó el rescate. Siguió el proceso oficial de recuperación de Instagram, avisó a sus contactos desde otras redes y cambió la contraseña de su correo.

Recuperó la cuenta en unos días. Ahora usa una app de autenticación y guarda sus códigos de respaldo en papel.

> **Idea clave:** protege primero tu correo; es la llave de todas tus cuentas.



#### Comprueba lo que entendiste

1. ¿Qué es mejor para la verificación en dos pasos?
*Respuesta:* Una app de autenticación, mejor que SMS.

2. ¿Pagas un "rescate" por tu cuenta robada?
*Respuesta:* No. Usa el proceso oficial de recuperación de la plataforma.


#### Para recordar

- Verificación en dos pasos con app.
- Correo seguro y códigos de respaldo.
- Nunca pagues rescates.



### Profundiza (5 minutos más)

#### Si te roban la cuenta

1. Usa el proceso oficial de recuperación de la plataforma.
2. Cambia la contraseña de tu correo y revisa sus accesos.
3. Avisa a tus contactos por otros medios que no respondan mensajes pidiendo dinero.
4. Reporta al 088 si hay extorsión.



#### Revisión de seguridad de tus redes

| Revisión | Hecho |
|---|---|
| Verificación en dos pasos con app | |
| Correo de recuperación actualizado | |
| Códigos de respaldo guardados | |
| Sesiones abiertas revisadas | |
| Accesos de tu equipo con roles | |



#### Mensajes de "soporte" falsos

Te pueden escribir haciéndose pasar por la plataforma: "Tu cuenta infringe derechos de autor, verifica aquí". Es phishing. Las plataformas avisan dentro de la app, no por mensajes directos con enlaces.

> **Dato vigente:** el 088 recibe reportes de delitos en línea, incluida la extorsión. Consultado el 29 de septiembre de 2026 a través de la Guardia Nacional.



#### Tu equipo y tus cuentas

Si tu mánager o tu equipo manejan tus redes, dales acceso con las herramientas de la plataforma, no tu contraseña. Cuando termine la relación, retira sus accesos.



#### Casos


**Caso 1. El Instagram de Valeria**

Le roban la cuenta a Valeria y le piden un rescate.
- *¿Qué hace?* No paga: usa la recuperación oficial, asegura su correo y avisa a sus contactos.


**Caso 2. La señal de Gael**

El celular de Gael se queda sin señal de repente y empiezan a llegarle correos de cambio de contraseña.
- *¿Qué hace?* Llama a su compañía desde otro teléfono, cambia contraseñas y avisa a su banco.


**Caso 3. El exmánager de Renata**

Renata dejó de trabajar con su mánager, que aún tiene su contraseña.
- *¿Qué hace?* Cambia su contraseña y retira sus accesos; en adelante da acceso con roles.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Usar solo SMS para verificar | Te pueden robar la línea | Usa app de autenticación |
| Descuidar tu correo | Pierdes todas tus cuentas | Protégelo primero |
| Pagar rescates | Te vuelven a extorsionar | Recupera por la vía oficial |
| Dar tu contraseña al equipo | Pierdes control | Da accesos con roles |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué cuenta proteges primero? a) Tu juego favorito · b) Ninguna · c) Tu correo
2. Te roban tu cuenta y piden rescate. ¿Qué haces? a) Pagas para recuperarla rápido · b) Recuperas por la vía oficial y no pagas · c) Abres otra cuenta y olvidas la anterior
3. ¿Cómo das acceso a tu equipo a tus redes? a) Con roles de la plataforma · b) Con tu contraseña · c) Con tu celular, prestándolo cuando haga falta
**Respuestas:** 1-c: es la llave de todo. 2-b: pagar alimenta la extorsión. 3-a: así controlas y retiras accesos.



#### Ponlo en práctica

Llena la tabla de revisión de seguridad de tu red más importante.
**Respuesta:** Por ejemplo: dos pasos con SMS (cambiaré a app), correo actualizado, códigos no guardados (los guardo hoy), dos sesiones que no reconozco (las cierro).



#### A tu plan

Activa la verificación en dos pasos con app en tu correo y en tu red más importante, y guarda tus códigos de respaldo en papel.



### Para saber más

- **Ciberseguridad** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** recomendaciones para proteger tus cuentas y reportar al 088.
- **Fraudes financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** fraudes por redes sociales.

### Palabras clave

- *App de autenticación:* genera códigos para entrar a tus cuentas.
- *Códigos de respaldo:* códigos para recuperar tu cuenta.
- *Extorsión:* exigir dinero con amenazas.

### Fuentes

Guardia Nacional CERT-MX · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M9 U06. Apps de préstamo "montadeudas" y préstamos con depósito previo

**Lo que lograrás:** Reconocer apps no registradas, que piden acceso a tus contactos o fotos, o que cobran antes de prestar, y saber qué hacer si ya caíste.

**Para empezar:** Renata pidió 3,000 en una app que prometía "préstamo inmediato sin Buró". Le depositaron 2,100 y ahora le exigen 7,000 en una semana. Le mandan mensajes a sus contactos llamándola ladrona y amenazan con publicar sus fotos. En esta lección aprenderás qué son las "montadeudas" y qué hacer.

### Lo esencial (5 minutos)

#### Qué son las "montadeudas"

Son apps o grupos que simulan ser financieras. Prometen préstamos rápidos "sin revisar tu historial", te piden acceso a tus contactos, fotos y archivos, cambian las condiciones y luego te extorsionan.



#### Señales de una "montadeudas"

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Piden acceso a contactos y fotos | Para presionarte después. | Alerta. |
| "Sin Buró, inmediato" | Promesa para atraerte. | Alerta. |
| Te cobran antes de prestar | "Gastos de gestión" o "depósito de garantía". | Fraude. |
| No aparece en el SIPRES | No está registrada. | No la uses. |

#### Si te extorsionan: no pagues

Las autoridades recomiendan **no pagar** extorsiones. Pagar no las detiene: te piden más.

Guarda evidencia, repórtalo al 088 y a CONDUSEF, y avisa a tus contactos que no respondan.



#### Un caso en un minuto

Renata dejó de responder a los extorsionadores. Guardó capturas, reportó al 088 y a CONDUSEF, y avisó a sus contactos por un mensaje sencillo.

Quitó a la app los permisos de su celular y la desinstaló. Los mensajes bajaron hasta detenerse.

> **Idea clave:** antes de cualquier préstamo, busca la empresa en el SIPRES. Si te extorsionan, no pagues y denuncia.



#### Comprueba lo que entendiste

1. ¿Qué haces si una app te extorsiona?
*Respuesta:* No pagas, guardas evidencia y reportas al 088 y a CONDUSEF.

2. ¿Una financiera legítima te cobra antes de prestarte?
*Respuesta:* No. Cobrar por adelantado es señal de fraude.


#### Para recordar

- Verifica en el SIPRES antes de pedir.
- Nunca des acceso a tus contactos y fotos.
- No pagues extorsiones; denuncia.



### Profundiza (5 minutos más)

#### Qué decir a tus contactos

Un mensaje corto basta: "Una app fraudulenta está usando mi nombre para enviar mensajes. Por favor no respondas ni compartas nada. Ya lo denuncié."



#### Préstamo legítimo o montadeudas

| | Legítimo | Montadeudas |
|---|---|---|
| Registro | Aparece en el SIPRES | No aparece |
| Permisos | Solo los necesarios | Contactos, fotos, archivos |
| Costo | CAT y contrato claros | Condiciones que cambian |
| Cobro anticipado | Nunca | "Gastos de gestión" |
| Cobranza | Regulada (REDECO) | Amenazas y exhibición |



#### Revisa los permisos de tus apps

En la configuración de tu celular revisa qué apps tienen acceso a tus contactos, fotos y archivos. Quita los permisos que no tienen sentido.



#### Si de verdad necesitas dinero

Antes de una app, revisa tu fondo de sequía, habla con tus acreedores, pide un adelanto por escrito a un cliente o compara créditos registrados (M5 U05 y M6 U06).

> **Dato vigente:** CONDUSEF y las autoridades recomiendan verificar en el SIPRES, no pagar extorsiones y reportar al 088; teléfono de CONDUSEF 55 5340 0999. Consultado el 29 de septiembre de 2026 a través de CONDUSEF, la Guardia Nacional y medios informativos.



#### Casos


**Caso 1. La app de Renata**

Una app le exige a Renata 7,000 por un préstamo de 3,000 y amenaza a sus contactos.
- *¿Qué hace?* No paga, guarda evidencia, reporta al 088 y a CONDUSEF, y avisa a sus contactos.


**Caso 2. El depósito de Gael**

Una "financiera" le pide a Gael 1,500 de "garantía" antes de prestarle 30,000.
- *¿Qué hace?* No paga: cobrar por adelantado es fraude. La busca en el SIPRES.


**Caso 3. Los permisos de Toño**

Una app de préstamos le pide a Toño acceso a sus contactos y a su galería.
- *¿Qué hace?* No acepta, no la usa y busca opciones registradas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir préstamos sin verificar | Caes en montadeudas | Busca en el SIPRES |
| Dar acceso a contactos y fotos | Te extorsionan con ellos | Niégalo |
| Pagar la extorsión | Te piden más | No pagues y denuncia |
| Callarlo por vergüenza | Siguen con otras personas | Denuncia y avisa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde verificas si una financiera está registrada? a) SIPRES de CONDUSEF · b) Tienda de apps · c) Sus redes
2. Una app te amenaza con publicar tus fotos si no pagas. ¿Qué haces? a) Pagas para que pare · b) No pagas y denuncias al 088 · c) Pides otro préstamo para pagar
3. Te piden un pago antes de prestarte. ¿Qué es? a) Normal · b) Una comisión legal · c) Señal de fraude
**Respuestas:** 1-a: es el registro oficial. 2-b: pagar no detiene la extorsión. 3-c: nadie legítimo cobra antes.



#### Ponlo en práctica

Revisa los permisos de las apps de tu celular. ¿Alguna app de préstamos o desconocida tiene acceso a tus contactos o fotos?
**Respuesta:** Por ejemplo: una app de préstamos que ya no uso tenía acceso a contactos y fotos. Quité los permisos y la desinstalé.



#### A tu plan

Guarda en tu celular el número 088 y el teléfono de CONDUSEF.



### Para saber más

- **Montadeudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "montadeudas" y cómo denunciar.
- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** verifica a la empresa antes de pedir un préstamo.
- **088** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** cómo reportar extorsión en línea.

### Palabras clave

- *Montadeudas:* apps o grupos que prestan y extorsionan.
- *SIPRES:* registro de prestadores de servicios financieros.
- *Permisos:* accesos que das a una app en tu celular.

### Fuentes

CONDUSEF · Guardia Nacional CERT-MX, consultados el 29 de septiembre de 2026.

---

## M9 U07. Inversiones milagro y "yo te manejo tu dinero"

**Lo que lograrás:** Reconocer pirámides, esquemas de referidos, criptomonedas con rendimiento garantizado y personas no autorizadas que ofrecen manejar tu dinero, y verificar antes de invertir.

**Para empezar:** Un productor conocido le ofrece a Gael 10% mensual por "invertir en su siguiente película". Muestra fotos del set, capturas de pagos a otros actores y la foto de un famoso que "ya invirtió". Gael tiene 150,000 ahorrados. En esta lección aprenderás a reconocer una inversión milagro.

### Lo esencial (5 minutos)

#### Señales de una inversión milagro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Rendimiento garantizado y alto | "10% al mes", "duplica tu dinero". | Nadie garantiza eso. |
| Ganas por invitar | Bonos por traer a más personas. | Pirámide. |
| Famosos y lujos | Fotos, autos, testimonios. | Se usan para convencer. |
| No está autorizado | No aparece en la CNBV. | No inviertas. |

#### Haz la cuenta

10% al mes significa que tu dinero se multiplica por más de tres en un año. Ningún negocio real puede prometer eso sin un riesgo enorme.

Si parece demasiado bueno para ser verdad, casi siempre lo es.



#### Verifica antes de invertir

Quien maneja dinero de otras personas o vende inversiones debe estar autorizado. Busca a la persona o empresa en la CNBV y revisa las advertencias de entidades no autorizadas.



#### Un caso en un minuto

Gael preguntó por el contrato, la empresa y la autorización. El productor le dijo que "era entre amigos, sin papeles". Gael no invirtió.

Seis meses después, varios colegas reclamaban su dinero.

> **Idea clave:** rendimiento alto garantizado + sin autorización = no inviertas.



#### Comprueba lo que entendiste

1. ¿Qué es una pirámide?
*Respuesta:* Un esquema donde se gana por traer a más personas; se cae cuando dejan de entrar.

2. ¿Dónde verificas si alguien puede manejar tu dinero?
*Respuesta:* En la CNBV y sus advertencias.


#### Para recordar

- Nadie garantiza rendimientos altos.
- Ganar por invitar es pirámide.
- Verifica en la CNBV.



### Profundiza (5 minutos más)

#### Criptomonedas

Las criptomonedas son activos muy volátiles: pueden subir o bajar mucho en poco tiempo. Muchos fraudes usan su nombre para prometer rendimientos "garantizados".

Si te interesa, infórmate en fuentes oficiales y nunca uses tu fondo de sequía ni dinero que necesitarás pronto.



#### Inversión real o fraude

| | Inversión real | Fraude |
|---|---|---|
| Rendimiento | Variable, con riesgo explicado | Alto y garantizado |
| Autorización | Intermediario autorizado | Sin registro o "entre amigos" |
| Contrato | Claro, con información | Sin papeles o confuso |
| Ganancias por invitar | No | Sí |
| Presión | Tiempo para decidir | "Últimos lugares" |



#### Invertir en proyectos del medio

Invertir en una película, una obra o un disco puede ser legítimo, pero es un negocio de riesgo, no una inversión con rendimiento garantizado. Exige contrato, información del proyecto y asesoría legal, y solo arriesga lo que puedes perder.

> **Dato vigente:** CNBV publica advertencias sobre entidades no autorizadas y CONDUSEF alerta sobre esquemas piramidales. Consultado el 29 de septiembre de 2026 a través de la CNBV y CONDUSEF.



#### La presión de la confianza

Muchos fraudes llegan a través de amigos, familia o colegas que ya invirtieron y todavía no saben que es un fraude. No es una falta de respeto preguntar y verificar.



#### Casos


**Caso 1. La película de Gael**

Un productor le ofrece a Gael 10% mensual "entre amigos, sin papeles".
- *¿Qué hace?* No invierte: rendimiento garantizado y sin autorización son señales de fraude.


**Caso 2. El grupo de Valeria**

Una amiga invita a Valeria a un grupo que paga bonos por cada persona que traiga.
- *¿Qué es?* Un esquema piramidal: no entra y verifica en CONDUSEF.


**Caso 3. La cripto de Toño**

Un anuncio con un famoso promete a Toño duplicar su dinero en criptomonedas en un mes.
- *¿Qué hace?* No invierte: es una promesa imposible y el uso del famoso suele ser falso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer en garantías | Pierdes todo | Nadie garantiza rendimientos altos |
| Invertir "entre amigos" sin papeles | Sin forma de reclamar | Exige contrato y autorización |
| Traer a más gente | Arrastras a otros | No participes en pirámides |
| Invertir tu fondo de sequía | Te quedas sin colchón | Solo dinero que puedes perder |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prometen 10% mensual garantizado. ¿Qué es? a) Una buena inversión · b) Un Cete · c) Señal de fraude
2. Te pagan bonos por invitar gente. ¿Qué es? a) Inversión regulada · b) Ahorro · c) Esquema piramidal
3. ¿Dónde revisas advertencias sobre entidades no autorizadas? a) Redes sociales · b) CNBV · c) El grupo de inversión
**Respuestas:** 1-c: nadie garantiza eso. 2-c: depende de que entren más personas. 3-b: la CNBV publica advertencias.



#### Ponlo en práctica

Escribe tres preguntas que harás antes de invertir en cualquier cosa.
**Respuesta:** Por ejemplo: ¿está autorizada por la CNBV? ¿hay contrato con riesgos explicados? ¿puedo perder este dinero sin afectar mi vida?



#### A tu plan

Guarda el enlace de las advertencias de la CNBV para revisar cualquier oferta de inversión.



### Para saber más

- **Advertencias** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** "Advertencias" sobre entidades no autorizadas.
- **Fraudes financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** esquemas piramidales e inversiones fraudulentas.

### Palabras clave

- *Pirámide:* esquema que paga con el dinero de nuevos participantes.
- *Volatilidad:* qué tanto sube y baja el valor de algo.
- *Inversión milagro:* oferta con rendimientos imposibles.

### Fuentes

CNBV · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M9 U08. Si ya te pasó: tu plan de respuesta

**Lo que lograrás:** Seguir en orden los pasos para responder a un fraude: bloquear, llamar al número oficial, reclamar por escrito, reportar a CONDUSEF, denunciar y avisar sin exponer tus datos.

**Para empezar:** Toño se dio cuenta a las once de la noche de que le hicieron tres cargos que no reconoce. Está nervioso y no sabe por dónde empezar. Cada minuto cuenta. En esta lección tendrás tu plan de respuesta listo.

### Lo esencial (5 minutos)

#### Tu plan en orden

1. **Bloquea** tus tarjetas y tu acceso desde la app o llamando al número oficial de tu banco.
2. **Cambia tus contraseñas** desde un dispositivo seguro.
3. **Reclama por escrito** los cargos en la UNE de tu banco y guarda el folio.
4. **Reporta** a CONDUSEF si no te resuelven.
5. **Denuncia** ante la fiscalía o reporta al 088.
6. **Protege tu historial** con bloqueo y alertas si expusiste tus datos (M7 U08).



#### Guarda evidencia

Capturas de mensajes, números, correos, páginas, estados de cuenta y folios. Anota la fecha y la hora de cada cosa. Sin evidencia, tu reclamación pierde fuerza.



#### Rápido pero en orden

Actuar rápido limita el daño. Pero no te saltes pasos: bloquear primero evita más cargos; reclamar por escrito te da derechos.



#### Un caso en un minuto

Toño bloqueó su tarjeta desde la app en dos minutos. Llamó al número oficial, reclamó los tres cargos y pidió folio. Al día siguiente presentó su reclamación por escrito y reportó al 088.

El banco revisó y le devolvió los cargos.

> **Idea clave:** bloquear, reclamar por escrito, reportar y denunciar. Guarda todo.



#### Comprueba lo que entendiste

1. ¿Qué haces primero si ves cargos que no reconoces?
*Respuesta:* Bloquear tus tarjetas y tu acceso.

2. ¿Por qué reclamar por escrito?
*Respuesta:* Porque te da un folio y una prueba para dar seguimiento.


#### Para recordar

- Bloquea primero.
- Reclama por escrito con folio.
- Denuncia y guarda evidencia.



### Profundiza (5 minutos más)

#### Contactos para tener a la mano

| Contacto | Para qué |
|---|---|
| Número oficial de tu banco | Bloquear y reclamar |
| CONDUSEF (55 5340 0999) | Orientación y reclamaciones |
| 088 (Guardia Nacional) | Reportar delitos en línea |
| Buró de Crédito y Círculo de Crédito | Bloqueo, alertas y reclamaciones |
| Fiscalía de tu estado | Presentar denuncia |

> **Dato vigente:** 088 de la Guardia Nacional para delitos en línea y teléfono de CONDUSEF. Consultado el 29 de septiembre de 2026 a través de la Guardia Nacional y CONDUSEF. Confirma los contactos en sus sitios oficiales.



#### Avisa sin exponerte

Si el fraude usó tu nombre o tus redes, avisa a tus contactos y a tu comunidad, pero sin publicar tus datos, números de cuenta ni capturas con información personal.



#### No es tu culpa

Los fraudes están diseñados para engañar a cualquiera. Sentir vergüenza hace que muchas personas no denuncien. Denunciar protege a otros y aumenta tus posibilidades de recuperar tu dinero.



#### Después del fraude

Revisa tus estados de cuenta y reportes de crédito durante varios meses. Revisa qué falló (una contraseña repetida, un enlace) y refuerza tu seguridad (M9 U03 y M9 U05).



#### Casos


**Caso 1. Los cargos de Toño**

Toño ve tres cargos que no reconoce a las once de la noche.
- *¿Qué hace primero?* Bloquea su tarjeta y su acceso desde la app o llamando al número oficial.


**Caso 2. La vergüenza de Renata**

Renata cayó en un fraude y no quiere denunciar por vergüenza.
- *¿Qué le recomiendas?* Denunciar: los fraudes engañan a cualquiera y denunciar ayuda a recuperar y a proteger a otros.


**Caso 3. El aviso de Valeria**

Usaron el nombre de Valeria para pedir dinero a sus seguidores.
- *¿Cómo avisa?* Publica un aviso sencillo sin datos personales ni capturas con información privada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar al día siguiente | Más cargos | Bloquea de inmediato |
| Reclamar solo por teléfono | Sin folio ni prueba | Reclama por escrito |
| Borrar mensajes | Pierdes evidencia | Guarda todo |
| No denunciar por vergüenza | Menos posibilidades de recuperar | Denuncia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces primero ante cargos que no reconoces? a) Esperar al estado de cuenta · b) Publicarlo en redes · c) Bloquear tus tarjetas
2. ¿A qué número reportas delitos en línea? a) 088 · b) 911 para todo · c) Al número del mensaje
3. ¿Qué guardas como evidencia? a) Nada · b) Solo tu contraseña, para que la revisen · c) Capturas, números, estados de cuenta y folios
**Respuestas:** 1-c: evita más cargos. 2-a: es la línea de la Guardia Nacional para delitos en línea. 3-c: sin evidencia es difícil reclamar.



#### Ponlo en práctica

Escribe tu plan de respuesta con los contactos que usarías.
**Respuesta:** Por ejemplo: bloqueo desde la app; llamo al banco al número de mi tarjeta; reclamo por escrito en la UNE; CONDUSEF 55 5340 0999; 088; bloqueo en Buró.



#### A tu plan

Guarda tu plan de respuesta y tus contactos en una nota fija de tu celular.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una reclamación por cargos no reconocidos.
- **088** (Guardia Nacional · español): https://www.gob.mx/gncertmx — **Qué buscar:** cómo reportar y qué información llevar.

### Palabras clave

- *Cargo no reconocido:* cobro en tu cuenta que no hiciste.
- *Evidencia:* pruebas de lo que pasó.
- *Plan de respuesta:* pasos a seguir ante un fraude.

### Fuentes

CONDUSEF · Guardia Nacional CERT-MX, consultados el 29 de septiembre de 2026.

---


---

# Módulo 10. Protección y prevención

## M10 U01. Sin seguro de empresa: el Seguro de Gastos Médicos Mayores

**Lo que lograrás:** Comparar pólizas de gastos médicos por suma asegurada, deducible, coaseguro, tope de coaseguro, red de hospitales, periodos de espera y exclusiones.

**Para empezar:** Gael se rompió un ligamento en un ensayo. Sin seguro, la cirugía y la rehabilitación costaron 180,000. Usó su fondo de sequía completo y una tarjeta. Nunca había comprado un seguro porque "es caro y a mí no me pasa nada". En esta lección aprenderás a elegir un seguro de gastos médicos.

### Lo esencial (5 minutos)

#### Tu cuerpo es tu herramienta

Si trabajas por tu cuenta, nadie te da seguro médico. Una lesión o una enfermedad puede costar más que todo tu fondo de sequía.

El **Seguro de Gastos Médicos Mayores** (SGMM) protege tu dinero ante gastos médicos grandes.



#### Lo que comparas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Suma asegurada | Lo máximo que paga por enfermedad o accidente. | Que alcance para una cirugía mayor. |
| Deducible | Lo que pagas tú primero. | Más alto, prima más baja. |
| Coaseguro y su tope | El porcentaje que pagas tú y el máximo. | Busca que tenga tope. |
| Red de hospitales | Dónde te atienden. | Que incluya hospitales cerca de ti. |
| Periodos de espera | Tiempo antes de cubrir ciertos padecimientos. | Léelos. |

#### La cirugía de Gael, con seguro

Gasto de 180,000 con deducible de 15,000 y coaseguro de 10% con tope de 30,000.
- Deducible: **15,000**
- Coaseguro: 10% de 165,000: **16,500**
- Lo que pagaría Gael: **31,500**
El seguro pagaría 148,500.


#### Un caso en un minuto

Gael comparó tres pólizas con el simulador de CONDUSEF. Eligió una con deducible medio, tope de coaseguro y hospitales cerca de casa. Paga su prima en mensualidades.

Revisó que cubriera lesiones deportivas y artísticas.

> **Idea clave:** el seguro no es un gasto de lujo: protege tu fondo de sequía y tu carrera.



#### Comprueba lo que entendiste

1. ¿Qué es el tope de coaseguro?
*Respuesta:* Lo máximo que pagas tú por coaseguro en un evento.

2. ¿Por qué revisar la red de hospitales?
*Respuesta:* Para saber dónde te atienden con el seguro.


#### Para recordar

- Suma asegurada, deducible y coaseguro con tope.
- Red de hospitales y periodos de espera.
- Lee las exclusiones.



### Profundiza (5 minutos más)

#### Mientras más joven, mejor

La prima sube con la edad y con los padecimientos que ya tienes. Contratar joven y sin enfermedades te da mejor precio y menos exclusiones.



#### Comparación de Gael

| | Póliza A | Póliza B | Póliza C |
|---|---|---|---|
| Prima anual | 14,000 | 19,000 | 16,500 |
| Deducible | 25,000 | 10,000 | 15,000 |
| Coaseguro | 10% sin tope | 10% con tope 30,000 | 10% con tope 30,000 |
| Lesiones artísticas o deportivas | Excluidas | Cubiertas | Cubiertas |
| **Elegida** | | | **Sí** |



#### Exclusiones frecuentes

Padecimientos que ya tenías antes de contratar, ciertos deportes o actividades de riesgo, tratamientos estéticos y algunos padecimientos en su primer año o dos (periodos de espera).

Para el medio artístico, revisa en especial lesiones en ensayos, funciones, acrobacias y giras.



#### Combínalo con el IMSS

El IMSS (M10 U02) te da atención médica, incapacidades y más. El SGMM te da acceso a hospitales privados y protege tu dinero en eventos grandes. Muchas personas combinan los dos.

> **Dato vigente:** simuladores y comparativos de seguros de gastos médicos de CONDUSEF y supervisión de aseguradoras por la CNSF. Consultado el 29 de septiembre de 2026 a través de CONDUSEF y la CNSF. Las primas cambian por edad y aseguradora: cotiza directamente.



#### Casos


**Caso 1. La lesión de Gael**

Gael se lesiona en un ensayo sin seguro y gasta 180,000.
- *¿Qué hace para la próxima?* Contrata un SGMM que cubra lesiones artísticas, con deducible adecuado y tope de coaseguro.


**Caso 2. La póliza barata de Renata**

La póliza más barata de Renata no tiene tope de coaseguro.
- *¿Qué riesgo corre?* En un gasto grande, su 10% podría ser muy alto. Busca una con tope.


**Caso 3. La edad de Toño**

Toño tiene 41 años y piensa esperar a los 50 para contratar.
- *¿Le conviene esperar?* No: la prima sube con la edad y pueden excluirle padecimientos que aparezcan antes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener ningún seguro | Un evento acaba con tu fondo | Contrata un SGMM |
| Elegir sin tope de coaseguro | Pagas mucho en eventos grandes | Busca tope |
| No revisar exclusiones | No te cubre tu actividad | Lee las exclusiones |
| Esperar a ser mayor | Prima más alta | Contrata joven |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gasto de 100,000, deducible de 10,000 y coaseguro de 10%. ¿Cuánto pagas tú? a) 19,000 · b) 10,000 · c) 1,000
2. ¿Qué protege el tope de coaseguro? a) Sube la prima · b) Limita lo que pagas en coaseguro · c) Elimina el deducible de tu póliza
3. ¿Cuándo conviene contratar un SGMM? a) Cuando ya estás enfermo · b) Joven y sano · c) Después de los 60
**Respuestas:** 1-a: 10,000 + 10% de 90,000. 2-b: pone un máximo. 3-b: prima menor y menos exclusiones.



#### Ponlo en práctica

Cotiza dos pólizas y compara suma asegurada, deducible, coaseguro con tope, red y exclusiones de tu actividad.
**Respuesta:** Por ejemplo: A, deducible 20,000, sin tope, excluye acrobacias; B, deducible 15,000, tope 30,000, cubre lesiones artísticas. Elijo B.



#### A tu plan

Cotiza un SGMM esta semana con el simulador de CONDUSEF.



### Para saber más

- **Simulador de gastos médicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" de seguros de gastos médicos mayores.
- **CNSF** (Gobierno de México · español): https://www.gob.mx/cnsf — **Qué buscar:** aseguradoras autorizadas.

### Palabras clave

- *SGMM:* seguro de gastos médicos mayores.
- *Tope de coaseguro:* máximo que pagas por coaseguro.
- *Periodo de espera:* tiempo antes de cubrir ciertos padecimientos.
- *Red de hospitales:* hospitales donde te atiende tu seguro.

### Fuentes

CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M10 U02. IMSS Modalidad 10: seguridad social para independientes

**Lo que lograrás:** Conocer la Modalidad 10 del IMSS para personas trabajadoras independientes, qué cubre, cuánto cuesta y cómo inscribirte.

**Para empezar:** Gael lleva seis años sin IMSS desde su último contrato de nómina. No tiene servicio médico, no cotiza para su pensión y no genera ahorro para vivienda. Un colega le cuenta que se dio de alta como independiente. En esta lección conocerás la Modalidad 10.

### Lo esencial (5 minutos)

#### Seguridad social aunque trabajes por tu cuenta

La **Modalidad 10** del IMSS permite que las personas trabajadoras independientes se incorporen al régimen obligatorio, con derechos parecidos a los de un empleo formal.

Desde la reforma de diciembre de 2023, es un derecho permanente, no un programa piloto.



#### Lo que te da

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Atención médica | Consultas, hospital y medicinas en el IMSS. | Para ti y beneficiarios. |
| Incapacidades | Pago si no puedes trabajar por enfermedad o accidente. | Según las reglas. |
| Retiro | Semanas cotizadas y ahorro en tu AFORE. | Hacia tu pensión. |
| Vivienda | Aportaciones a Infonavit. | Para un crédito futuro. |

#### Cuánto cuesta

La cuota depende del ingreso que registres, dentro de los límites del IMSS. El IMSS tiene una calculadora en su sitio de personas trabajadoras independientes.

Registrar un ingreso muy bajo cuesta menos, pero también te da incapacidades y pensión más bajas.



#### Un caso en un minuto

Gael usó la calculadora del IMSS, eligió un ingreso a registrar cercano a su sueldo fijo y se dio de alta en línea.

Ahora tiene servicio médico, suma semanas para su pensión y aportaciones a su AFORE y a Infonavit. Mantiene también su SGMM para hospitales privados.

> **Idea clave:** trabajar por tu cuenta no significa quedarte sin seguridad social.



#### Comprueba lo que entendiste

1. ¿Qué es la Modalidad 10?
*Respuesta:* La incorporación voluntaria de personas independientes al régimen obligatorio del IMSS.

2. ¿De qué depende la cuota?
*Respuesta:* Del ingreso que registres.


#### Para recordar

- Atención médica, incapacidades, retiro y vivienda.
- La cuota depende del ingreso registrado.
- Usa la calculadora del IMSS.



### Profundiza (5 minutos más)

#### El ingreso que registras importa

Tus incapacidades y tu futura pensión se calculan con el ingreso registrado. Registrar un ingreso cercano a lo que realmente ganas te protege mejor, aunque cueste más.



#### Modalidad 10 y SGMM

| | IMSS Modalidad 10 | SGMM privado |
|---|---|---|
| Atención | Clínicas y hospitales del IMSS | Hospitales privados de la red |
| Incapacidades | Sí | No |
| Retiro y AFORE | Sí | No |
| Vivienda (Infonavit) | Sí | No |
| Costo | Según ingreso registrado | Según edad y póliza |



#### Servicios de la ANDA para agremiados

**Convenio IMSS-ANDA (septiembre de 2026):** trabajadores independientes de actuación, doblaje, canto, danza, música, conducción y modelaje pueden incorporarse voluntariamente al Seguro Social a través de la ANDA, con los cinco seguros del régimen obligatorio y cobertura para cónyuge o concubino e hijos menores de 16 años. Si eres agremiado, pregunta en la ANDA cómo inscribirte.

**Cuánto cuesta la Modalidad 10 en 2026:** eliges el salario con que cotizas, entre un salario mínimo (9,582.47 pesos al mes) y 25 UMA (89,155.50 pesos al mes). Con el mínimo, la cuota ronda los 2,500 pesos al mes. Paga antes del día 20 para tener cobertura el mes siguiente. Si quieres aportar a Infonavit, se agrega 5% de tu salario registrado.

> **Dato vigente:** convenio IMSS-ANDA publicado el 20 de septiembre de 2026; rangos de salario de la Modalidad 10 con UMA 2026 y salario mínimo 2026; cuotas estimadas por medios informativos. Consultado el 29 de septiembre de 2026 a través del IMSS y medios informativos. Calcula tu cuota exacta en la calculadora oficial del IMSS.



#### ¿Y la Modalidad 33?

Existe también un seguro de salud para la familia (Modalidad 33) que da atención médica, pero no incapacidades, pensión ni vivienda. Compara con la Modalidad 10 según lo que necesites.



#### Casos


**Caso 1. Los seis años de Gael**

Gael lleva seis años sin IMSS y trabaja por su cuenta.
- *¿Qué puede hacer?* Inscribirse en la Modalidad 10 como persona trabajadora independiente.


**Caso 2. El ingreso de Valeria**

Valeria quiere registrar el ingreso más bajo posible para pagar menos.
- *¿Qué debe considerar?* Que sus incapacidades y su pensión se calcularán con ese ingreso.


**Caso 3. El agremiado Toño**

Toño es agremiado de la ANDA y no sabe si necesita el IMSS.
- *¿Qué hace?* Pregunta a la ANDA qué servicios de salud tiene y compara con lo que da la Modalidad 10: incapacidades, retiro y vivienda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que sin patrón no hay IMSS | Te quedas sin seguridad social | Revisa la Modalidad 10 |
| Registrar un ingreso muy bajo | Incapacidades y pensión bajas | Elige con cuidado |
| Confiar solo en un seguro privado | Sin retiro ni vivienda | Combina |
| No usar la calculadora | Te sorprende la cuota | Calcula antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué modalidad del IMSS es para personas trabajadoras independientes? a) Modalidad 40 · b) Modalidad 10 · c) Ninguna
2. ¿Qué te da la Modalidad 10 que un SGMM no? a) Incapacidades, retiro y vivienda · b) Hospitales privados de la red de tu aseguradora · c) Nada
3. Registras un ingreso muy bajo. ¿Qué pasa? a) Nada cambia · b) Te dan más beneficios porque pagas menos cuota · c) Pagas menos, pero tus incapacidades y pensión son menores
**Respuestas:** 1-b: es la incorporación voluntaria de independientes. 2-a: el SGMM solo cubre gastos médicos. 3-c: se calculan con el ingreso registrado.



#### Ponlo en práctica

Entra a la calculadora del IMSS y calcula la cuota con dos ingresos distintos. ¿Cuál eliges y por qué?
**Respuesta:** Por ejemplo: con un ingreso bajo pago menos, pero mis incapacidades serían bajas. Elijo uno cercano a mi sueldo fijo para estar mejor protegido.



#### A tu plan

Calcula tu cuota de Modalidad 10 y decide si te das de alta este mes.



### Para saber más

- **Personas trabajadoras independientes** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-independientes — **Qué buscar:** requisitos, calculadora e inscripción en línea.
- **Calculadora** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-independientes/calculadora — **Qué buscar:** calcula tu cuota según tu ingreso.
- **ANDA** (Asociación Nacional de Actores · español): https://laanda.org.mx — **Qué buscar:** servicios para agremiados.

### Palabras clave

- *Modalidad 10:* incorporación de independientes al IMSS.
- *Ingreso registrado:* el ingreso con que cotizas.
- *Incapacidad:* pago cuando no puedes trabajar por salud.

### Fuentes

IMSS, personas trabajadoras independientes · Ley del Seguro Social · ANDA, consultados el 29 de septiembre de 2026.

---

## M10 U03. Si no puedes trabajar: incapacidad, invalidez y accidentes

**Lo que lograrás:** Proteger tu ingreso si una lesión o enfermedad te impide grabar, cantar o bailar, y conocer qué preguntar sobre coberturas especiales.

**Para empezar:** Renata se lastimó la rodilla y no puede bailar en tres meses. Tiene su fondo de sequía, pero no alcanza para cubrir un periodo largo. Sus gastos siguen y no hay ingresos. En esta lección aprenderás a proteger tu ingreso, no solo tus gastos médicos.

### Lo esencial (5 minutos)

#### El riesgo que casi nadie cubre

El seguro de gastos médicos paga el hospital. Pero ¿quién paga tu renta si no puedes trabajar tres meses?

Protegerte contra la pérdida de ingreso es tan importante como pagar el médico.



#### Opciones para proteger tu ingreso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IMSS (Modalidad 10) | Incapacidades según el ingreso registrado. | La base. |
| Seguro de accidentes personales | Paga por lesiones, incapacidad o pérdida de partes del cuerpo. | Revisa si cubre tu actividad. |
| Fondo de sequía | Cubre los meses sin ingreso. | Tu primera línea. |
| Coberturas especiales | Para voz, manos o cuerpo, en ciertos casos. | Pregunta y compara. |

#### Lee cómo definen "incapacidad"

Algunas pólizas pagan solo si no puedes hacer **ningún** trabajo; otras, si no puedes hacer **tu** trabajo. Para ti, la diferencia es enorme: una bailarina con una lesión de rodilla podría hacer otro trabajo, pero no bailar.



#### Un caso en un minuto

Renata tenía Modalidad 10 y recibió incapacidad del IMSS. Con su fondo cubrió el resto. Contrató después un seguro de accidentes personales que cubre lesiones en ensayos y funciones.

> **Idea clave:** protege tu capacidad de ganar dinero, no solo tus gastos médicos.



#### Comprueba lo que entendiste

1. ¿El seguro de gastos médicos paga tu renta si no puedes trabajar?
*Respuesta:* No. Paga gastos médicos, no tu ingreso.

2. ¿Qué revisas en la definición de incapacidad?
*Respuesta:* Si paga cuando no puedes hacer tu trabajo o solo cuando no puedes hacer ningún trabajo.


#### Para recordar

- IMSS, seguro de accidentes y fondo de sequía.
- Revisa cómo definen la incapacidad.
- Pregunta por coberturas especiales.



### Profundiza (5 minutos más)

#### Cómo cubre Renata tres meses sin bailar

| Fuente | Cubre |
|---|---|
| Incapacidad del IMSS | Una parte de su ingreso registrado |
| Fondo de sequía | La diferencia de sus gastos básicos |
| Seguro de accidentes | Pago por la lesión, según la póliza |
| Ingreso puente | Clases teóricas o coreografía sin esfuerzo físico |



#### Seguros para voz, manos o cuerpo

En otros países existen seguros de incapacidad para artistas con coberturas reforzadas de voz, oído, vista o manos. En México no encontramos un producto estándar de "seguro de voz" para personas: lo más común es combinar un **seguro de accidentes personales**, un **seguro de gastos médicos** y las **incapacidades del IMSS**. Las pólizas a la medida existen para producciones y giras, y se cotizan con aseguradoras o agentes autorizados.

> **Dato vigente:** búsqueda de productos de seguros para artistas en México y el extranjero. Consultado el 29 de septiembre de 2026 a través de CONDUSEF, la CNSF y aseguradoras. Si te ofrecen una póliza especial, verifica a la aseguradora en la CNSF y lee la definición de incapacidad.



#### Prevención

Calentamiento, técnica vocal, descanso, revisiones médicas y equipo de protección reducen el riesgo. Presupuéstalos como parte de tu mantenimiento de imagen y salud (M1 U05).



#### Invalidez

Si una enfermedad o accidente te impide trabajar de forma permanente, el seguro de invalidez del IMSS (si cotizas) puede darte una pensión, según las semanas cotizadas y las reglas vigentes.



#### Casos


**Caso 1. La rodilla de Renata**

Renata no puede bailar en tres meses.
- *¿Cómo cubre ese tiempo?* Con la incapacidad del IMSS, su fondo de sequía, su seguro de accidentes y un ingreso puente sin esfuerzo físico.


**Caso 2. La voz de Valeria**

A Valeria le ofrecen un "seguro de voz" muy caro.
- *¿Qué revisa?* Que la aseguradora esté autorizada, qué cuenta como incapacidad, exclusiones y si el costo tiene sentido para su ingreso.


**Caso 3. La definición de Gael**

La póliza de Gael paga solo si "no puede desempeñar ningún trabajo".
- *¿Le protege bien?* Poco: si no puede actuar pero sí hacer otra cosa, no le pagaría. Busca una definición ligada a su ocupación.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Proteger solo gastos médicos | Sin ingreso en la recuperación | Protege tu ingreso |
| No leer la definición de incapacidad | No te paga cuando lo necesitas | Revísala |
| Contratar seguros especiales sin verificar | Fraude o mala cobertura | Verifica en la CNSF |
| Descuidar la prevención | Más lesiones | Presupuesta tu cuidado |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué cubre la pérdida de ingreso por no poder trabajar? a) Incapacidad del IMSS y seguros de accidentes · b) Solo el SGMM · c) Nada: si no trabajas, nadie te paga
2. ¿Qué definición de incapacidad te conviene? a) No poder hacer tu trabajo · b) No poder hacer ningún trabajo · c) Ninguna
3. ¿Dónde verificas a una aseguradora? a) SAT · b) INDAUTOR · c) CNSF
**Respuestas:** 1-a: protegen tu ingreso. 2-a: se ajusta a tu ocupación. 3-c: la CNSF supervisa seguros.



#### Ponlo en práctica

Escribe cómo cubrirías tres meses sin poder trabajar: con qué ingresos y protecciones.
**Respuesta:** Por ejemplo: incapacidad del IMSS, dos meses de fondo de sequía y clases de teoría musical como ingreso puente.



#### A tu plan

Revisa si tu seguro actual cubre lesiones de tu actividad y cómo define la incapacidad.



### Para saber más

- **Seguros de accidentes personales** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías y comparativos de seguros de accidentes.
- **Incapacidades** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** cómo funcionan las incapacidades y la invalidez.

### Palabras clave

- *Incapacidad:* periodo en que no puedes trabajar por salud.
- *Seguro de accidentes personales:* paga por lesiones y sus consecuencias.
- *Invalidez:* imposibilidad permanente de trabajar.

### Fuentes

IMSS · CONDUSEF · CNSF, consultados el 29 de septiembre de 2026.

---

## M10 U04. Seguro de vida y beneficiarios

**Lo que lograrás:** Decidir si necesitas un seguro de vida, por cuánto, y nombrar y actualizar beneficiarios en tu cuenta, tu AFORE y tus seguros.

**Para empezar:** Toño tiene una hija de diez años. Si algo le pasa, ella se quedaría sin su ingreso. Nunca ha pensado en un seguro de vida y en su cuenta de banco no tiene beneficiarios. En esta lección aprenderás a proteger a quienes dependen de ti.

### Lo esencial (5 minutos)

#### ¿Quién depende de ti?

Un seguro de vida protege a quienes dependen de tu ingreso: hijos, pareja, padres. Si nadie depende de ti, quizá no lo necesitas todavía.



#### Dos tipos de seguro de vida

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Temporal | Protege por un plazo, por ejemplo 20 años. | Más barato. |
| Con ahorro (dotal o similar) | Protege y además junta dinero. | Más caro; compara costos. |

#### Beneficiarios: el paso más olvidado

Cada cuenta, seguro y AFORE tiene su propia designación de beneficiarios. Si no los nombras, tu familia puede tardar meses o años en un trámite legal para recibir ese dinero.

Nómbralos y actualízalos cuando cambie tu vida.



#### Un caso en un minuto

Toño calculó cuánto necesitaría su hija hasta terminar la universidad y contrató un seguro temporal a 15 años. Nombró beneficiarios en su cuenta, su AFORE y el seguro.

Como su hija es menor, en su testamento nombró a quien la cuidaría y administraría ese dinero (M10 U06).

> **Idea clave:** un seguro sin beneficiarios actualizados puede no llegar a quien quieres.



#### Comprueba lo que entendiste

1. ¿Quién necesita un seguro de vida?
*Respuesta:* Quien tiene personas que dependen de su ingreso.

2. ¿Dónde nombras beneficiarios?
*Respuesta:* En cada cuenta, seguro y en tu AFORE.


#### Para recordar

- El seguro protege a quien depende de ti.
- Temporal suele ser más barato.
- Nombra y actualiza beneficiarios en todo.



### Profundiza (5 minutos más)

#### ¿Por cuánto?

Una forma sencilla de calcular.
- Gasto mensual de su hija: **12,000**
- Meses hasta que termine sus estudios (12 años): **144**
- Monto aproximado del seguro: **1,728,000**
Se multiplica: 12,000 × 144. Toño resta lo que ya tiene ahorrado.


#### Dónde nombrar beneficiarios

| Producto | Dónde se nombran |
|---|---|
| Cuenta bancaria | En la sucursal o la app |
| AFORE | En tu AFORE o AforeMóvil |
| Seguro de vida | En la póliza |
| Regalías | Pregunta en tu sociedad de gestión colectiva |



#### Si tus beneficiarios son menores

Un menor no puede administrar el dinero directamente. En tu testamento puedes nombrar a quien lo cuide y administre. Pide orientación a un notario.



#### Temporal más ahorro por separado

Muchas personas eligen un seguro temporal (barato) y ahorran o invierten la diferencia por su cuenta. Compara el costo total antes de elegir un seguro con ahorro.

> **Dato vigente:** designación de beneficiarios en cuentas bancarias, AFORE y seguros. Consultado el 29 de septiembre de 2026 a través de CONDUSEF y CONSAR.



#### Casos


**Caso 1. La hija de Toño**

Toño tiene una hija de diez años y no tiene seguro ni beneficiarios.
- *¿Qué hace?* Calcula cuánto necesitaría su hija, contrata un seguro temporal y nombra beneficiarios en todo.


**Caso 2. La cuenta de Renata**

Renata abrió su cuenta hace años y no nombró beneficiarios.
- *¿Qué hace?* Los nombra en su banco, su AFORE y sus seguros.


**Caso 3. El seguro con ahorro de Gael**

A Gael le ofrecen un seguro de vida con ahorro muy caro.
- *¿Qué compara?* El costo contra un seguro temporal más un ahorro o inversión por su cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No nombrar beneficiarios | Trámites largos para tu familia | Nómbralos |
| No actualizarlos | El dinero va a quien no quieres | Revísalos cuando cambie tu vida |
| Contratar sin calcular | Monto que no alcanza | Calcula la necesidad |
| Elegir solo por el ahorro | Pagas de más | Compara con temporal |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué tipo de seguro de vida suele ser más barato? a) Temporal · b) Con ahorro · c) Son iguales
2. ¿Dónde nombras beneficiarios? a) Solo en el testamento · b) En cada cuenta, seguro y AFORE · c) Solo en tu testamento, una sola vez
3. Gasto de 10,000 al mes por 10 años. ¿Monto aproximado de seguro? a) 1,200,000 · b) 120,000 · c) 10,000
**Respuestas:** 1-a: solo protege, sin ahorro. 2-b: cada producto tiene su designación. 3-a: 10,000 × 120 meses.



#### Ponlo en práctica

Haz tu lista de productos y escribe quién es tu beneficiario en cada uno.
**Respuesta:** Por ejemplo: cuenta, mi mamá; AFORE, sin beneficiario (lo actualizo); seguro, no tengo. Esta semana actualizo mi AFORE.



#### A tu plan

Nombra o actualiza beneficiarios en tu cuenta y tu AFORE este mes.



### Para saber más

- **Seguros de vida** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** simuladores y guías de seguros de vida.
- **AforeMóvil** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** cómo actualizar beneficiarios en tu AFORE.

### Palabras clave

- *Seguro de vida temporal:* protege por un plazo definido.
- *Beneficiario:* persona que recibe el dinero si mueres.
- *Suma asegurada:* monto que paga el seguro.

### Fuentes

CONDUSEF · CONSAR, consultados el 29 de septiembre de 2026.

---

## M10 U05. Protege tu nombre y tu marca

**Lo que lograrás:** Conocer la reserva de derechos al uso exclusivo de tu nombre artístico ante INDAUTOR y el registro de marca ante el IMPI.

**Para empezar:** Valeria usa el nombre artístico "Vale Luna" desde hace cinco años. Un día descubre que alguien registró "Vale Luna" como marca para ropa y le pide que deje de usarlo en su mercancía. En esta lección aprenderás a proteger tu nombre.

### Lo esencial (5 minutos)

#### Dos protecciones distintas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Reserva de derechos (INDAUTOR) | Protege el uso exclusivo de tu nombre artístico. | Para tu identidad artística. |
| Registro de marca (IMPI) | Protege un nombre o logotipo para productos y servicios. | Para mercancía y negocios. |

#### Primero busca

Antes de registrar, busca si el nombre ya existe: en el IMPI con su buscador de marcas y en INDAUTOR para reservas de derechos.

Buscar es gratis y te evita problemas.



#### Registra según lo que haces

Si solo actúas o cantas con tu nombre artístico, la reserva de derechos protege tu identidad artística. Si vendes mercancía, das clases o tienes un negocio con ese nombre, considera también el registro de marca en las clases que correspondan.



#### Un caso en un minuto

Valeria buscó asesoría y reunió pruebas de que usaba "Vale Luna" desde antes. Tramitó su reserva de derechos y registró su marca para servicios de entretenimiento y para su línea de ropa.

> **Idea clave:** registra tu nombre antes de que otra persona lo haga.



#### Comprueba lo que entendiste

1. ¿Dónde reservas tu nombre artístico?
*Respuesta:* En INDAUTOR, con la reserva de derechos al uso exclusivo.

2. ¿Dónde registras una marca para tu mercancía?
*Respuesta:* En el IMPI.


#### Para recordar

- INDAUTOR: nombre artístico.
- IMPI: marca para productos y servicios.
- Busca antes de registrar.



### Profundiza (5 minutos más)

#### Reserva de derechos y marca

| | Reserva de derechos (INDAUTOR) | Marca (IMPI) |
|---|---|---|
| Protege | Nombre artístico, nombre de grupo, personajes | Nombre o logotipo en productos y servicios |
| Para qué | Tu identidad artística | Mercancía, escuela, negocio |
| Vigencia | 5 años, renovable | 10 años, renovable |
| Costo 2026 | 5,739 pesos (renovación 2,892) | 2,695.18 pesos más IVA por clase (10% menos en línea) |
| Búsqueda previa | En INDAUTOR | Buscador de marcas del IMPI |

> **Dato vigente:** tarifas 2026 de INDAUTOR (artículo 184 de la Ley Federal de Derechos) y del IMPI. La reserva se renueva desde un mes antes hasta un mes después de su vencimiento. La marca exige declarar su uso a los 3 años o caduca. Consultado el 29 de septiembre de 2026 a través de INDAUTOR, el IMPI y medios especializados.



#### Las clases de marca

Las marcas se registran por clases de productos y servicios. Por ejemplo, servicios de entretenimiento, grabaciones o ropa van en clases distintas. Registra solo las que usarás.



#### Renueva a tiempo

Las reservas y las marcas vencen. Anota las fechas de renovación en tu calendario. Si no renuevas, otra persona podría quedarse con tu nombre.



#### Cuándo pedir ayuda

Si hay un conflicto con otra persona que usa tu nombre, busca un abogado de propiedad intelectual. Guarda pruebas de desde cuándo usas tu nombre: carteles, contratos, publicaciones.



#### Casos


**Caso 1. "Vale Luna"**

Alguien registró el nombre artístico de Valeria como marca de ropa.
- *¿Qué hace?* Busca asesoría, reúne pruebas de uso previo y protege su nombre en INDAUTOR y el IMPI.


**Caso 2. La banda de Toño**

Toño formó una banda y quiere vender playeras con su nombre.
- *¿Qué revisa?* Si el nombre está libre en el IMPI y en INDAUTOR, y registra la marca para ropa y la reserva del nombre del grupo.


**Caso 3. La renovación de Gael**

Gael registró su marca hace casi diez años.
- *¿Qué hace?* Revisa la fecha de vencimiento y renueva a tiempo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No registrar tu nombre | Otra persona puede hacerlo | Registra |
| No buscar antes | Conflictos | Usa los buscadores |
| Registrar clases que no usas | Gastas de más | Solo las necesarias |
| Olvidar renovar | Pierdes la protección | Anota las fechas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué institución protege tu nombre artístico con una reserva de derechos? a) SAT · b) INDAUTOR · c) CONDUSEF
2. ¿Dónde registras una marca para tu línea de ropa? a) IMSS · b) ANDA · c) IMPI
3. ¿Qué haces antes de registrar? a) Imprimir playeras · b) Imprimir playeras y ver si el nombre funciona · c) Buscar si el nombre ya existe
**Respuestas:** 1-b: INDAUTOR otorga reservas de derechos. 2-c: el IMPI registra marcas. 3-c: buscar evita conflictos.



#### Ponlo en práctica

Busca tu nombre artístico en el buscador de marcas del IMPI. ¿Está libre?
**Respuesta:** Por ejemplo: busqué "Vale Luna" y no hay registros en entretenimiento. Voy a tramitar la reserva y la marca.



#### A tu plan

Busca tu nombre en el IMPI y anota qué protección necesitas según lo que haces.



### Para saber más

- **Reserva de derechos** (INDAUTOR · español): https://www.indautor.gob.mx — **Qué buscar:** "Reservas de derechos al uso exclusivo" para nombres artísticos.
- **Buscador de marcas** (IMPI · español): https://www.gob.mx/impi — **Qué buscar:** "MarcaNet" o el buscador de marcas para ver si tu nombre está libre.

### Palabras clave

- *Reserva de derechos:* protección de uso exclusivo de tu nombre artístico.
- *Marca:* nombre o logotipo registrado para productos o servicios.
- *Clase:* categoría de productos o servicios de una marca.

### Fuentes

INDAUTOR · IMPI · Ley Federal del Derecho de Autor · Ley Federal de Protección a la Propiedad Industrial, consultados el 29 de septiembre de 2026.

---

## M10 U06. Testamento y documentos para tu familia

**Lo que lograrás:** Hacer tu testamento, ordenar tus documentos y dejar instrucciones sobre tus cuentas, regalías y derechos.

**Para empezar:** Un colega de Gael murió sin testamento. Su familia tardó dos años en un juicio para acceder a su cuenta, a su auto y a sus regalías. Mientras tanto, sus hijos no recibieron nada. En esta lección prepararás lo necesario para que no le pase a tu familia.

### Lo esencial (5 minutos)

#### El testamento evita juicios largos

Un **testamento** dice quién recibe tus bienes y derechos. Sin él, tu familia puede necesitar un juicio que tarda meses o años y cuesta dinero.

El más común es el testamento público abierto, que se hace ante notario.



#### Lo que incluyes en tu plan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Testamento | Quién recibe tus bienes, regalías y derechos. | Ante notario. |
| Beneficiarios | En cuentas, AFORE y seguros. | M10 U04. |
| Tutor | Quién cuidará a tus hijos menores. | En el testamento. |
| Carpeta familiar | Dónde están tus documentos y cuentas. | Sin contraseñas completas. |

#### Septiembre: Mes del Testamento

Cada septiembre, muchas notarías ofrecen testamentos a menor costo en el Mes del Testamento. Aprovéchalo.



#### Un caso en un minuto

Gael hizo su testamento en septiembre. Incluyó sus regalías y los derechos sobre sus actuaciones. Armó una carpeta con sus cuentas, pólizas, contratos y contactos, y le dijo a su hermana dónde está.

> **Idea clave:** hacer tu testamento es un acto de cuidado, no de pesimismo.



#### Comprueba lo que entendiste

1. ¿Qué pasa si mueres sin testamento?
*Respuesta:* Tu familia puede necesitar un juicio largo y costoso.

2. ¿Cuándo es el Mes del Testamento?
*Respuesta:* En septiembre.


#### Para recordar

- Testamento ante notario.
- Beneficiarios y tutor.
- Carpeta familiar sin contraseñas completas.



### Profundiza (5 minutos más)

#### Tus regalías y derechos se heredan

Tus derechos patrimoniales como autor o intérprete y tus regalías pueden seguir generando ingresos después de ti. Inclúyelos en tu testamento y deja por escrito qué sociedades de gestión colectiva te pagan.



#### Tu carpeta familiar

| Qué incluir | Ejemplo |
|---|---|
| Documentos | Acta, INE, CURP, RFC |
| Cuentas | Banco y tipo de cuenta, sin contraseñas |
| Seguros | Pólizas y aseguradoras |
| Retiro | AFORE y PPR |
| Regalías | ANDI, SACM, EJE u otras |
| Contratos | Representación, marcas, reservas de derechos |
| Contactos | Contador, notario, abogado |



#### Tus cuentas digitales

Tus redes y tu correo tienen valor para tu familia y tu carrera. Revisa las opciones de cada plataforma para designar un contacto de legado y deja instrucciones de qué hacer con ellas.



#### Actualízalo

Revisa tu testamento y tus beneficiarios cuando cambie tu vida: pareja, hijos, un bien importante, nuevos derechos.

> **Dato vigente:** en el Mes del Testamento 2026 (su edición 24) las notarías participantes de las 32 entidades reducen hasta 50% sus honorarios; el precio promedio empieza alrededor de 2,750 pesos, contra 5,000 a 10,000 fuera de la campaña. Necesitas identificación oficial vigente. Consultado el 29 de septiembre de 2026 a través de la Secretaría de Gobernación y medios informativos. Revisa la tarifa de tu estado.



#### Casos


**Caso 1. El colega de Gael**

El colega de Gael murió sin testamento y su familia está en juicio.
- *¿Qué hace Gael?* Hace su testamento ante notario, de preferencia en el Mes del Testamento, y arma su carpeta familiar.


**Caso 2. Las regalías de Valeria**

Valeria cobra regalías de sus canciones en la SACM.
- *¿Cómo las protege para su familia?* Las incluye en su testamento y deja por escrito qué sociedad le paga.


**Caso 3. La carpeta de Renata**

Renata quiere dejar sus contraseñas escritas en su carpeta familiar.
- *¿Es buena idea?* No: deja dónde están sus cuentas y cómo contactar a las instituciones, no contraseñas completas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No hacer testamento | Juicios largos | Hazlo ante notario |
| Olvidar regalías y derechos | Tu familia no los cobra | Inclúyelos |
| Guardar contraseñas en papel | Riesgo de robo | Deja instrucciones, no claves |
| No actualizar | El testamento no refleja tu vida | Revísalo al cambiar algo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Ante quién haces un testamento público abierto? a) El SAT · b) Tu banco · c) Un notario
2. ¿Tus regalías se pueden heredar? a) No · b) Sí · c) Solo las del extranjero
3. ¿Qué NO pones en tu carpeta familiar? a) Pólizas · b) Contraseñas completas · c) Contactos de tu contador y tu notario
**Respuestas:** 1-c: el notario lo formaliza. 2-b: son derechos patrimoniales. 3-b: evita riesgos de robo.



#### Ponlo en práctica

Haz la lista de lo que incluirás en tu carpeta familiar.
**Respuesta:** Por ejemplo: acta e INE, cuenta de banco, póliza de gastos médicos, AFORE, regalías en ANDI y contacto de mi contador.



#### A tu plan

Agenda una cita con un notario y arma tu carpeta familiar este mes.



### Para saber más

- **Mes del Testamento** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** "Mes del Testamento" y las notarías participantes en tu estado.
- **Testamento** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre testamento y beneficiarios.

### Palabras clave

- *Testamento:* documento que dice quién recibe tus bienes.
- *Notario:* profesional que da validez a tu testamento.
- *Carpeta familiar:* lugar con tus documentos e instrucciones.
- *Derechos patrimoniales:* derechos económicos sobre tus obras o interpretaciones.

### Fuentes

Secretaría de Gobernación, Mes del Testamento · CONDUSEF · Ley Federal del Derecho de Autor, consultados el 29 de septiembre de 2026.

---


---

# Módulo 11. Tu futuro

## M11 U01. Llegó un pago gordo: repártelo antes de gastarlo

**Lo que lograrás:** Aplicar un reparto inmediato cuando llega un pago grande: impuestos, deudas caras, fondo de sequía, retiro, carrera y una parte para disfrutar.

**Para empezar:** Valeria cobra 400,000 más IVA por una campaña nacional. Hace un año cobró algo parecido y en tres meses no le quedaba nada: viaje, ropa, un auto a crédito. Esta vez quiere que ese pago le cambie la vida. En esta lección aprenderás a repartirlo antes de gastarlo.

### Lo esencial (5 minutos)

#### Reparte el mismo día

Un pago gordo se evapora si lo dejas en tu cuenta de gastos. Repártelo el mismo día que llega, antes de decidir cualquier compra.



#### El orden del reparto

1. **Impuestos:** el IVA completo y el ISR que te indique tu contador según tu régimen.
2. **Deudas caras:** tarjetas y préstamos con CAT alto.
3. **Fondo de sequía:** hasta llegar a tu meta.
4. **Retiro:** una parte a tu AFORE o PPR.
5. **Tu carrera:** formación, equipo o promoción planeada.
6. **Disfrutar:** una parte para ti, sin culpa.
7. **Tu concentradora:** lo que queda paga tus sueldos futuros.



#### El reparto de Valeria

| Destino | Monto |
|---|---|
| IVA (lo entrega al SAT) | 64,000 |
| ISR según su régimen | Lo que indique su contador |
| Tarjetas caras | 45,000 |
| Completar fondo de sequía | 50,000 |
| Retiro | 60,000 |
| Curso de actuación y promoción | 30,000 |
| Disfrutar | 35,000 |
| Concentradora (sueldos futuros) | El resto |



#### Un caso en un minuto

Valeria repartió el pago el mismo día, antes de ver ofertas. Liquidó sus tarjetas, completó su fondo, abrió su PPR y se fue de viaje con lo que apartó para disfrutar.

Un año después seguía teniendo sueldo cada quincena.

> **Idea clave:** un pago gordo no es un año gordo. Es el sueldo de muchos meses.



#### Comprueba lo que entendiste

1. ¿Qué apartas primero de un pago gordo?
*Respuesta:* Los impuestos: el IVA y el ISR que te corresponda.

2. ¿Por qué no gastarlo todo?
*Respuesta:* Porque es el sueldo de muchos meses, incluidos los de sequía.


#### Para recordar

- Reparte el mismo día.
- Primero impuestos, luego deudas y fondo.
- Una parte para disfrutar, sin culpa.



### Profundiza (5 minutos más)

#### Adapta los porcentajes

El orden importa más que los porcentajes exactos. Si no tienes deudas, más a retiro y concentradora. Si tu fondo está vacío, más al fondo.

Decide tus porcentajes con calma, antes de que llegue el pago.



#### Las compras grandes

Si quieres un auto o un equipo caro, espera al menos un mes después del pago. Si todavía lo quieres, cómpralo con lo que apartaste para tu carrera o para disfrutar, sin crédito, o evalúalo con tu mes bajo (M6 U05).



#### Cuidado con los impuestos del mes

Un cobro muy grande puede subir tu tasa de ISR del mes, sobre todo en RESICO, donde la tasa depende del ingreso mensual (M2 U01). Pregunta a tu contador antes de facturar.

> **Dato vigente:** tasas de RESICO por ingreso mensual (artículo 113-E de la LISR). Consultado el 29 de septiembre de 2026 a través del SAT.



#### Disfrutar también es parte del plan

Si nunca te permites disfrutar un pago, dejarás el plan. Apartar una parte para ti con intención es lo que hace sostenible el resto.



#### Casos


**Caso 1. La campaña de Valeria**

Valeria cobra 400,000 más IVA.
- *¿Qué hace primero?* Aparta el IVA y el ISR, y reparte el resto el mismo día según su orden.


**Caso 2. El auto de Gael**

Gael cobra un pago grande y quiere dar el enganche de un auto de inmediato.
- *¿Qué le recomiendas?* Esperar un mes, revisar su reparto y ver si el pago del auto cabe en su mes bajo.


**Caso 3. Los porcentajes de Toño**

Toño no tiene deudas y su fondo está completo.
- *¿Cómo ajusta su reparto?* Manda más a retiro, a su carrera y a su concentradora.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar el pago en la cuenta de gastos | Se evapora | Reparte el mismo día |
| Olvidar los impuestos | Deuda con el SAT | Apártalos primero |
| Comprar grande de inmediato | Decisiones impulsivas | Espera un mes |
| No apartar para disfrutar | Abandonas el plan | Date un gusto planeado |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué apartas primero de un pago gordo? a) Impuestos · b) Un viaje · c) Un auto
2. Cobras 100,000 más IVA. ¿Cuánto IVA apartas? a) 10,000 · b) 16,000 · c) 0
3. ¿Cuándo repartes el pago? a) El mismo día que llega · b) En tres meses · c) Cuando se acabe lo que tenías en tu cuenta
**Respuestas:** 1-a: el IVA y el ISR no son tuyos. 2-b: 16% de 100,000. 3-a: antes de decidir compras.



#### Ponlo en práctica

Escribe tu reparto para un pago de 150,000 más IVA.
**Respuesta:** Por ejemplo: IVA 24,000; ISR según mi contador; tarjeta 30,000; fondo 30,000; retiro 20,000; carrera 15,000; disfrutar 15,000; concentradora el resto.



#### A tu plan

Escribe tus porcentajes de reparto hoy, antes de tu próximo pago grande.



### Para saber más

- **Declaraciones y pagos** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** cómo calcular tus impuestos del mes.
- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para usar un ingreso extraordinario.

### Palabras clave

- *Pago gordo:* ingreso extraordinario de un proyecto grande.
- *Reparto:* dividir un ingreso en destinos antes de gastarlo.
- *Ingreso extraordinario:* dinero que no llega cada mes.

### Fuentes

SAT · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M11 U02. Tu AFORE: encuéntrala y súmale

**Lo que lograrás:** Localizar tu AFORE con tu CURP, actualizar beneficiarios, comparar tu AFORE y hacer aportaciones voluntarias.

**Para empezar:** Toño trabajó con nómina en una disquera durante años. No sabe en qué AFORE está ni cuánto tiene. Cree que ese dinero "se perdió" cuando dejó de trabajar ahí. En esta lección aprenderás a encontrar tu AFORE y hacerla crecer.

### Lo esencial (5 minutos)

#### Tu AFORE sigue siendo tuya

Si alguna vez tuviste nómina con IMSS o ISSSTE, tienes una **AFORE**. Ese dinero no se pierde cuando dejas un trabajo.

Para encontrarla necesitas tu CURP.



#### Tres formas de consultarla

1. **AforeMóvil:** la app oficial. Te registras con tu CURP y verificas tu identidad.
2. **e-SAR:** en su sitio localizas tu AFORE con tu CURP.
3. **SARTEL:** la línea telefónica de CONSAR.



#### Lo que haces desde AforeMóvil

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ver tu saldo | Cuánto tienes y en qué AFORE. | Revisa cada año. |
| Beneficiarios | Quién recibe tu ahorro. | Actualízalos. |
| Aportar | Aportaciones voluntarias, desde montos pequeños. | Cuando cobres bien. |
| Cambiarte | Si otra AFORE te conviene más. | Compara con datos de CONSAR. |

#### Un caso en un minuto

Toño descargó AforeMóvil, se registró con su CURP y encontró su cuenta con más de lo que imaginaba. Actualizó a su hija como beneficiaria y programó una aportación voluntaria cada vez que cobra una sesión grande.

> **Idea clave:** tu AFORE sigue ahí aunque ya no tengas nómina. Encuéntrala y súmale.



#### Comprueba lo que entendiste

1. ¿Qué necesitas para encontrar tu AFORE?
*Respuesta:* Tu CURP.

2. ¿Puedes aportar a tu AFORE si trabajas por tu cuenta?
*Respuesta:* Sí, con aportaciones voluntarias.


#### Para recordar

- Encuéntrala con tu CURP.
- Actualiza beneficiarios.
- Aporta cuando cobres bien.



### Profundiza (5 minutos más)

#### Compara tu AFORE

Las AFORE cobran comisiones distintas y tienen rendimientos distintos. CONSAR publica comparativos. Si la tuya está entre las de menor rendimiento, puedes cambiarte gratis.

No te cambies por un regalo o la promesa de un agente: compara con los datos oficiales.



#### Tipos de aportación voluntaria

- **De corto plazo o libre disposición:** puedes retirarlas después del plazo mínimo que te indique tu AFORE. No son deducibles.
- **Complementarias de retiro y de largo plazo:** se quedan hasta que cumplas 65 años o tengas una incapacidad o invalidez. Son deducibles si presentas declaración anual y no estás en RESICO (M11 U04).

Para deducir, la factura debe tener el uso D06 (aportaciones voluntarias al SAR) y el pago debe salir de una cuenta a tu nombre.

> **Dato vigente:** tipos de aportación voluntaria y reglas de deducción (artículo 151, fracción V, de la LISR). Consultado el 29 de septiembre de 2026 a través del SAT, CONSAR y AFORE. El plazo mínimo para retirar aportaciones de corto plazo lo fija cada AFORE: consúltalo en la tuya.



#### Cuidado con gestores

Hay personas que ofrecen "recuperar tu AFORE" a cambio de un porcentaje o de tus datos. Los trámites son gratuitos y los puedes hacer tú.



#### Modalidad 10 y tu AFORE

Si te inscribes en la Modalidad 10 del IMSS (M10 U02), también se hacen aportaciones a tu AFORE y sumas semanas para tu pensión.

> **Dato vigente:** AforeMóvil, e-SAR y SARTEL de CONSAR para localizar y administrar tu AFORE. Consultado el 29 de septiembre de 2026 a través de CONSAR.



#### Casos


**Caso 1. La AFORE de Toño**

Toño cree que su AFORE se perdió al dejar la disquera.
- *¿Qué hace?* La busca con su CURP en AforeMóvil o e-SAR y actualiza beneficiarios.


**Caso 2. El gestor de Renata**

Un gestor le ofrece a Renata "liberar su AFORE" por 30% del saldo.
- *¿Qué hace?* No acepta: los trámites son gratuitos y los hace ella con su AFORE o CONSAR.


**Caso 3. La comparación de Gael**

La AFORE de Gael tiene de los rendimientos más bajos.
- *¿Qué puede hacer?* Comparar con los datos de CONSAR y cambiarse gratis si otra le conviene.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que tu AFORE se perdió | No la usas | Búscala con tu CURP |
| No actualizar beneficiarios | Trámite largo para tu familia | Actualízalos |
| Pagar a gestores | Pierdes dinero | Hazlo tú, es gratis |
| Cambiarte por un regalo | Puedes elegir peor | Compara con CONSAR |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué necesitas para localizar tu AFORE? a) Tu RFC con contraseña del SAT · b) Tu número de tarjeta · c) Tu CURP
2. ¿Tu AFORE se pierde al dejar un trabajo? a) Sí · b) Solo después de 5 años · c) No
3. ¿Cuánto cuesta cambiarte de AFORE? a) Es gratis · b) 10% del saldo · c) Depende del gestor
**Respuestas:** 1-c: la CURP identifica tu cuenta. 2-c: sigue siendo tuya. 3-a: el cambio es gratuito.



#### Ponlo en práctica

Localiza tu AFORE y anota: cuánto tienes, quién es tu beneficiario y cómo está su rendimiento comparado.
**Respuesta:** Por ejemplo: tengo 85,000 en la AFORE X; beneficiaria mi mamá (agrego a mi hija); su rendimiento está a la mitad de la tabla de CONSAR.



#### A tu plan

Descarga AforeMóvil o usa e-SAR, localiza tu cuenta y actualiza beneficiarios.



### Para saber más

- **AforeMóvil** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** "AforeMóvil" y los pasos para registrarte.
- **e-SAR** (CONSAR · español): https://www.e-sar.com.mx — **Qué buscar:** "Localiza tu AFORE" con tu CURP.
- **Comparativo de AFORE** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** "Indicador de rendimiento neto" y comisiones.

### Palabras clave

- *AFORE:* administra tu ahorro para el retiro.
- *CURP:* tu clave de registro de población.
- *Aportación voluntaria:* dinero extra que pones en tu AFORE.

### Fuentes

CONSAR, AforeMóvil, e-SAR y SARTEL, consultados el 29 de septiembre de 2026.

---

## M11 U03. Modalidad 40: si cotizaste antes de julio de 1997

**Lo que lograrás:** Conocer la continuación voluntaria del IMSS (Modalidad 40) para personas de la Ley 73, sus requisitos, su costo y cómo se diferencia de la Modalidad 10.

**Para empezar:** Toño trabajó con nómina en una disquera de 1994 a 2021. Hoy trabaja por su cuenta y un colega le dice que con la "Modalidad 40" podría mejorar mucho su pensión. No sabe si aplica para él ni cuánto costaría. En esta lección conocerás la Modalidad 40.

### Lo esencial (5 minutos)

#### Para quién es

La **Modalidad 40** es la continuación voluntaria en el régimen obligatorio del IMSS. Le interesa sobre todo a quienes empezaron a cotizar antes del 1 de julio de 1997 (Ley 73), porque su pensión se calcula con el salario de sus últimos años de cotización.



#### Requisitos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 52 semanas | Cotizadas en los últimos cinco años antes de tu baja. | Revisa tu historial. |
| Plazo | Pedirla dentro de los cinco años siguientes a tu baja. | No esperes. |
| Sin empleo formal | No estar dado de alta como trabajador en ese momento. | Condición. |

#### Cuánto cuesta

Pagas un porcentaje del salario que elijas registrar, con un tope. En 2026 es 14.438% del salario elegido, con tope de 25 UMA diarias.

Registrar un salario más alto cuesta más, pero puede mejorar tu pensión.



#### Un caso en un minuto

Toño revisó su historial en el IMSS: cotizó más de 52 semanas en sus últimos cinco años y se dio de baja hace dos. Cumple los requisitos.

Pidió asesoría gratuita en el IMSS para calcular cuánto mejoraría su pensión con distintos salarios y decidió cuánto podía pagar sin afectar su fondo de sequía.

> **Idea clave:** si cotizaste antes de 1997, la Modalidad 40 puede cambiar mucho tu pensión. Revísala a tiempo.



#### Comprueba lo que entendiste

1. ¿A quién le interesa sobre todo la Modalidad 40?
*Respuesta:* A quienes empezaron a cotizar antes del 1 de julio de 1997 (Ley 73).

2. ¿Cuál es el plazo para pedirla?
*Respuesta:* Dentro de los cinco años siguientes a tu baja.


#### Para recordar

- Ley 73: cotizaste antes de julio de 1997.
- 52 semanas en los últimos cinco años.
- Pídela dentro de los cinco años de tu baja.



### Profundiza (5 minutos más)

#### Modalidad 10 y Modalidad 40

| | Modalidad 10 | Modalidad 40 |
|---|---|---|
| Para quién | Personas que trabajan por su cuenta hoy | Personas que ya no cotizan y quieren mejorar su pensión |
| Servicio médico | Sí | No |
| Incapacidades | Sí | No |
| Semanas para pensión | Sí | Sí |
| Interés principal | Seguridad social completa | Mejorar la pensión (Ley 73) |



#### Cambios y controles en 2026

En 2026 la cuota es de 14.438% del salario que elijas, entre 3 y 25 UMA diarias (con la UMA de 117.31 pesos, el tope es 2,932.75 pesos diarios). El porcentaje sube cada año por la reforma de pensiones de 2020, hasta llegar a 18.8% en 2030.

El IMSS reforzó en 2026 la vigilancia de registros, salarios y semanas para evitar irregularidades.

> **Dato vigente:** artículo 218 de la Ley del Seguro Social, trámite IMSS-02-007, reforma de pensiones (DOF 16 de diciembre de 2020) y UMA 2026. Consultado el 29 de septiembre de 2026 a través del IMSS y medios informativos. Pide al IMSS una proyección de tu pensión antes de decidir.



#### Cuidado con gestores y préstamos

Hay gestores que cobran mucho por tramitar la Modalidad 40 y ofrecen préstamos para pagarla. El trámite puedes hacerlo tú en el IMSS. Desconfía de esquemas de financiamiento complicados.



#### Haz la cuenta completa

Suma lo que pagarías en cuotas durante los años que te faltan y compáralo con cuánto subiría tu pensión al mes. Pide al IMSS una proyección antes de decidir.



#### Casos


**Caso 1. Los años de Toño**

Toño cotizó de 1994 a 2021 y se dio de baja hace dos años.
- *¿Puede revisar la Modalidad 40?* Sí: es de Ley 73 y está dentro del plazo. Pide asesoría en el IMSS.


**Caso 2. Valeria, sin cotizaciones antes de 1997**

Valeria empezó a cotizar en 2018.
- *¿Le conviene la Modalidad 40 como a Toño?* No de la misma forma: no es de Ley 73. Para ella, la Modalidad 10 y su AFORE son más relevantes.


**Caso 3. El gestor de Gael**

Un gestor le ofrece a Gael tramitarle la Modalidad 40 con un préstamo para pagarla.
- *¿Qué hace?* Desconfía: hace el trámite él mismo en el IMSS y no pide préstamos para pagarla.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar pasar el plazo de cinco años | Pierdes la opción | Revísalo a tiempo |
| Confundir Modalidad 10 y 40 | Eliges la que no te sirve | Compara |
| Pagar a gestores | Pierdes dinero | Tramítala tú |
| No calcular | Pagas más de lo que ganas | Pide una proyección |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué requisito de semanas pide la Modalidad 40? a) 1,000 semanas en un año · b) 1,000 semanas cotizadas en un solo año · c) 52 semanas en los últimos cinco años
2. ¿La Modalidad 40 da servicio médico? a) Sí · b) No · c) Solo a los hijos
3. ¿Cuál es la modalidad para quien trabaja por su cuenta hoy y quiere servicio médico? a) Modalidad 40 · b) Ninguna · c) Modalidad 10
**Respuestas:** 1-c: es el requisito de la ley. 2-b: solo suma semanas para la pensión. 3-c: da seguridad social completa.



#### Ponlo en práctica

Revisa tu historial de cotizaciones: ¿cuándo empezaste a cotizar, cuántas semanas tienes y cuándo fue tu baja?
**Respuesta:** Por ejemplo: empecé en 1995, tengo 1,200 semanas y mi baja fue en 2023. Soy de Ley 73 y estoy en plazo: pediré una proyección al IMSS.



#### A tu plan

Consulta tus semanas cotizadas en el IMSS y decide si necesitas asesoría sobre la Modalidad 40.



### Para saber más

- **Modalidad 40** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** "Continuación voluntaria en el régimen obligatorio" y sus requisitos.
- **Semanas cotizadas** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** "Constancia de semanas cotizadas".

### Palabras clave

- *Modalidad 40:* continuación voluntaria para mejorar tu pensión.
- *Ley 73:* régimen de quienes cotizaron antes de julio de 1997.
- *Semanas cotizadas:* semanas registradas en el IMSS.
- *UMA:* Unidad de Medida y Actualización, referencia para cuotas y límites.

### Fuentes

Ley del Seguro Social, artículo 218 · IMSS, trámite IMSS-02-007, consultados el 29 de septiembre de 2026.

---

## M11 U04. Plan Personal de Retiro (PPR) y aportaciones deducibles

**Lo que lograrás:** Conocer el PPR y las aportaciones voluntarias deducibles, sus límites, a quién le sirven y qué comparar.

**Para empezar:** A Gael le ofrecen un PPR "para pagar menos impuestos". Él factura en RESICO. El agente no le explicó que en RESICO no aplican deducciones personales. En esta lección aprenderás cuándo un PPR te conviene y qué comparar.

### Lo esencial (5 minutos)

#### Qué es un PPR

Un **Plan Personal de Retiro** (PPR) es un producto para ahorrar para tu retiro que ofrecen aseguradoras, bancos u operadoras de fondos. Puede darte un beneficio fiscal si cumples las reglas.



#### ¿A quién le sirve la deducción?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sueldos y asimilados | Pueden deducirlo en su declaración anual. | Pueden tener saldo a favor. |
| Actividad Empresarial | Pueden deducirlo en su declaración anual. | Dentro del tope. |
| RESICO | No aplican deducciones personales a esos ingresos. | Sin beneficio fiscal. |

#### Tiene un límite

Las aportaciones deducibles tienen un tope: en general, hasta 10% de tus ingresos del año, sin pasar de 5 UMA anuales.



#### Un caso en un minuto

Gael preguntó a su contador. Como está en RESICO, el PPR no le daría deducción. Decidió aportar voluntariamente a su AFORE, con comisiones más bajas, y revisar el PPR si cambia de régimen.

> **Idea clave:** el PPR conviene si puedes deducirlo y si sus costos son bajos. Si no, compara con tu AFORE.



#### Comprueba lo que entendiste

1. ¿Quién no puede deducir un PPR contra sus ingresos?
*Respuesta:* Quien tiene sus ingresos en RESICO.

2. ¿Qué tope tienen las aportaciones deducibles?
*Respuesta:* En general, 10% de tus ingresos, sin pasar de 5 UMA anuales.


#### Para recordar

- El PPR ahorra para tu retiro.
- La deducción no aplica en RESICO.
- Compara costos con tu AFORE.



### Profundiza (5 minutos más)

#### Es para el retiro

Si retiras antes de la edad que marcan las reglas (en general, 65 años), pierdes el beneficio y te retienen impuestos. Solo pon en un PPR dinero que no necesitarás antes.

> **Dato vigente:** tope de deducción del PPR y aportaciones complementarias: 10% de tus ingresos del año, sin pasar de 5 UMA anuales (213,973.20 pesos en 2026), fuera del tope global de deducciones personales. Si retiras antes de los 65 años (salvo invalidez o incapacidad), te retienen 20% y el retiro se acumula a tus ingresos (artículos 142, fracción XVIII, y 151, fracción V, de la LISR). Consultado el 29 de septiembre de 2026 a través del SAT y la LISR.



#### Qué comparar entre PPR

| Punto | Qué revisar |
|---|---|
| Comisiones | Administración, apertura y salida |
| Rendimiento | En qué se invierte y su historial |
| Flexibilidad | Si puedes cambiar la aportación o pausarla |
| Institución | Autorizada por la CNBV o la CNSF |
| Seguros incluidos | Si los necesitas o encarecen el plan |



#### PPR o AFORE

Las aportaciones voluntarias a tu AFORE también pueden ser deducibles y suelen tener comisiones bajas. Compara las dos opciones con los mismos datos antes de elegir.



#### Cuidado con la venta

El PPR se vende mucho con el argumento de "pagar menos impuestos". Pregunta tu régimen, el costo total y el tope antes de firmar. Nunca firmes solo por el beneficio fiscal.



#### Casos


**Caso 1. El PPR de Gael**

A Gael, que está en RESICO, le ofrecen un PPR "para pagar menos impuestos".
- *¿Le conviene por eso?* No: en RESICO no hay deducción personal. Compara con su AFORE y lo revisa si cambia de régimen.


**Caso 2. La deducción de Valeria**

Valeria cobra por asimilados y quiere aportar 30,000 a un PPR.
- *¿Qué revisa?* Que la aportación esté dentro del tope deducible y los costos del plan.


**Caso 3. La emergencia de Renata**

Renata quiere poner su fondo de sequía en un PPR.
- *¿Le conviene?* No: si lo saca antes de tiempo pierde el beneficio y le retienen impuestos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contratar un PPR en RESICO por la deducción | No hay beneficio | Pregunta tu régimen |
| No comparar comisiones | Pierdes rendimiento | Compara costos |
| Poner dinero que necesitarás pronto | Penalización | Solo dinero de largo plazo |
| Firmar solo por el beneficio fiscal | Mal producto | Revisa todo el plan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿En qué régimen NO aplica la deducción del PPR? a) Asimilados · b) RESICO · c) Actividad Empresarial
2. ¿Qué pasa si retiras tu PPR antes de tiempo? a) Pierdes el beneficio y te retienen impuestos · b) Nada · c) Ganas más porque ya no pagas comisiones
3. ¿Con qué comparas un PPR? a) Con una tarjeta de crédito · b) Con aportaciones voluntarias a tu AFORE · c) Con un préstamo personal a plazo largo
**Respuestas:** 1-b: RESICO no usa deducciones personales. 2-a: es para el retiro. 3-b: ambos son para el retiro.



#### Ponlo en práctica

Escribe tu régimen y decide si un PPR te daría beneficio fiscal. ¿Qué comparas antes de elegir?
**Respuesta:** Por ejemplo: estoy en Actividad Empresarial, así que sí puedo deducir dentro del tope. Compararé comisiones de dos PPR con las aportaciones voluntarias a mi AFORE.



#### A tu plan

Pregunta a tu contador si un PPR te da beneficio fiscal en tu régimen.



### Para saber más

- **Deducciones personales** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** aportaciones complementarias de retiro y PPR.
- **Planes de retiro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías y comparativos de planes personales de retiro.

### Palabras clave

- *PPR:* plan personal de retiro.
- *Aportación deducible:* aportación que puedes restar en tu anual.
- *Retiro anticipado:* sacar tu ahorro antes de la edad pactada.

### Fuentes

LISR, artículo 151 · SAT · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M11 U05. Invertir a largo plazo sin especular

**Lo que lograrás:** Entender riesgo, plazo, diversificación y comisiones, y verificar que el intermediario esté autorizado antes de invertir a largo plazo.

**Para empezar:** Valeria ya tiene su fondo de sequía, su AFORE y cero deudas. Quiere invertir para dentro de 15 años. En redes ve a gente que "hace trading" y promete ganancias rápidas. En esta lección aprenderás la diferencia entre invertir y especular.

### Lo esencial (5 minutos)

#### Antes de invertir

Invierte a largo plazo solo si ya tienes: fondo de sequía completo, deudas caras pagadas y tu retiro en marcha. Invertir no sustituye nada de eso.



#### Invertir o especular

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Invertir | Poner dinero en muchas empresas por años y aguantar las bajas. | Paciencia. |
| Especular | Comprar y vender rápido esperando ganar con los cambios de precio. | Riesgo muy alto. |

#### Diversifica

**Diversificar** es repartir tu dinero en muchas inversiones. Un fondo de inversión o un ETF que agrupa muchas empresas diversifica por ti.

No pongas todo en una sola acción o criptomoneda.



#### Un caso en un minuto

Valeria abrió una cuenta en una casa de bolsa autorizada por la CNBV. Invierte cada mes en un fondo diversificado con comisión baja y no revisa el precio todos los días.

Sabe que en algunos años bajará. Su plazo es de 15 años.

> **Idea clave:** a largo plazo, paciencia y diversificación; nada de promesas rápidas.



#### Comprueba lo que entendiste

1. ¿Qué debes tener antes de invertir a largo plazo?
*Respuesta:* Fondo de sequía, deudas caras pagadas y tu retiro en marcha.

2. ¿Qué es diversificar?
*Respuesta:* Repartir tu dinero en muchas inversiones.


#### Para recordar

- Primero lo básico, luego invertir.
- Diversifica.
- Verifica que el intermediario esté autorizado.



### Profundiza (5 minutos más)

#### Opciones de largo plazo

| Opción | Qué es | Riesgo |
|---|---|---|
| Cetes a plazos largos | Deuda del gobierno | Bajo |
| Fondos de inversión | Canasta manejada por una operadora | Según el fondo |
| ETF | Fondo que se compra en bolsa | Según lo que siga |
| Acciones individuales | Parte de una empresa | Alto |
| Criptomonedas | Activos digitales | Muy alto |



#### Las comisiones importan

Una comisión de 2% al año parece poca, pero en 15 años puede comerse una parte grande de tu ganancia. Compara comisiones antes de elegir.



#### Verifica al intermediario

Casas de bolsa, operadoras de fondos y otras plataformas de inversión deben estar autorizadas. Búscalas en el padrón de la CNBV y revisa las advertencias.

> **Dato vigente:** supervisión de casas de bolsa y operadoras de fondos por la CNBV. Consultado el 29 de septiembre de 2026 a través de la CNBV.



#### Las bajas son normales

Las inversiones de largo plazo suben y bajan. Vender por miedo en una baja convierte una pérdida temporal en pérdida real. Por eso solo inviertes dinero que no necesitarás pronto.



#### Casos


**Caso 1. El trading de Valeria**

En redes le ofrecen a Valeria un curso de trading para "ganar diario".
- *¿Qué hace?* No especula: invierte a largo plazo, diversificado y con un intermediario autorizado.


**Caso 2. La acción de Gael**

Gael quiere poner todo su ahorro en la acción de una sola empresa.
- *¿Qué le recomiendas?* Diversificar: un fondo o ETF que agrupe muchas empresas.


**Caso 3. La baja de Toño**

El fondo de Toño bajó 12% este año y quiere venderlo todo.
- *¿Qué considera?* Que su plazo es largo y las bajas son normales; vender ahora vuelve real la pérdida.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Invertir sin fondo de sequía | Vendes en mal momento | Primero lo básico |
| Poner todo en una sola cosa | Riesgo muy alto | Diversifica |
| Ignorar comisiones | Pierdes rendimiento | Compara |
| Especular con promesas rápidas | Pérdidas o fraude | Invierte a largo plazo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es diversificar? a) Poner todo en una acción · b) Guardar efectivo · c) Repartir en muchas inversiones
2. ¿Dónde verificas una casa de bolsa? a) Redes sociales · b) CNBV · c) Un grupo de chat
3. Tu inversión de largo plazo baja 10%. ¿Qué haces? a) Vendes todo · b) Recuerdas tu plazo y no vendes por miedo · c) Pides prestado para comprar más barato
**Respuestas:** 1-c: reduce el riesgo. 2-b: supervisa a los intermediarios. 3-b: las bajas son normales en el largo plazo.



#### Ponlo en práctica

Escribe si ya cumples lo básico para invertir y qué opción de largo plazo revisarías.
**Respuesta:** Por ejemplo: tengo fondo completo, sin deudas caras y aporto a mi AFORE. Revisaré un fondo diversificado con comisión baja en una casa de bolsa autorizada.



#### A tu plan

Revisa tus tres básicos: fondo de sequía, deudas caras y retiro. Si los tienes, investiga una opción diversificada.



### Para saber más

- **Padrón de entidades supervisadas** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** casas de bolsa y operadoras de fondos autorizadas.
- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías sobre inversión y riesgo.

### Palabras clave

- *Diversificar:* repartir tu dinero en muchas inversiones.
- *ETF:* fondo que se compra y vende en bolsa.
- *Especular:* comprar y vender rápido buscando ganar con los cambios de precio.

### Fuentes

CNBV · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M11 U06. Vivienda: rentar, comprar o esperar

**Lo que lograrás:** Comparar el costo total de comprar contra rentar, y conocer las opciones de crédito para personas independientes.

**Para empezar:** Gael quiere dejar de "tirar dinero en renta" y comprar un departamento. No sabe que, además del enganche, hay gastos notariales, avalúo, seguros y mantenimiento. Tampoco sabe cómo demostrar ingresos siendo independiente. En esta lección aprenderás a decidir con números.

### Lo esencial (5 minutos)

#### Rentar no es tirar el dinero

Rentar paga un lugar para vivir y te da flexibilidad para moverte por proyectos. Comprar te da patrimonio, pero cuesta más de lo que parece y te ata a un lugar.

La decisión depende de tu estabilidad, tus ahorros y tu mes bajo.



#### Lo que cuesta comprar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Enganche | La parte que pagas al inicio. | Suele pedirse de 10% a 20% o más. |
| Gastos notariales y de escrituración | Impuestos, notario, avalúo. | Un porcentaje del valor. |
| Seguros | De vida y daños, ligados al crédito. | Mensuales. |
| Mantenimiento y predial | Cuotas y reparaciones. | Cada año. |

#### Si eres independiente

Los bancos piden demostrar ingresos: estados de cuenta, declaraciones de impuestos y facturas. Tener tus impuestos en orden (M2) y un buen historial (M7) es clave para que te presten.



#### Un caso en un minuto

Gael calculó: enganche, gastos notariales y fondo de sequía intacto. Le faltaban dos años de ahorro y ordenar sus declaraciones.

Decidió seguir rentando, ahorrar para el enganche en Cetes y cotizar créditos en dos años, cuando pueda demostrar ingresos estables.

> **Idea clave:** comprar sin enganche suficiente ni fondo de sequía te pone en riesgo en la primera sequía.



#### Comprueba lo que entendiste

1. ¿Qué costos hay además del enganche?
*Respuesta:* Gastos notariales, avalúo, seguros, mantenimiento y predial.

2. ¿Qué necesitas como independiente para un crédito hipotecario?
*Respuesta:* Demostrar ingresos con estados de cuenta, declaraciones y facturas.


#### Para recordar

- Rentar no es tirar dinero.
- Suma todos los costos de comprar.
- Ordena tus impuestos y tu historial.



### Profundiza (5 minutos más)

#### La cuenta de Gael

| Concepto | Monto |
|---|---|
| Precio del departamento | 2,000,000 |
| Enganche de 15% | 300,000 |
| Gastos notariales y de escrituración (estimado) | 120,000 |
| Fondo de sequía que no debe tocar | 72,000 |
| **Ahorro necesario antes de comprar** | **420,000 más su fondo** |



#### La mensualidad y tu mes bajo

La mensualidad del crédito, más seguros, mantenimiento y predial, debe caber en tu mes bajo (M6 U05). Si solo cabe en tus meses buenos, espera o busca algo más barato.



#### Infonavit y otras opciones

Desde la reforma de diciembre de 2023, en la Modalidad 10 puedes elegir aportar a Infonavit: 5% del salario que registres. Esas aportaciones y tu historial te permiten solicitar un crédito Infonavit como trabajador independiente. El monto depende del ingreso que registres. También hay créditos bancarios y esquemas que combinan ambos.

Gastos de escrituración: en general, entre 4% y 7% del valor de la vivienda (en algunos estados más), y la mayor parte es el impuesto sobre adquisición de inmuebles, no los honorarios del notario.

> **Dato vigente:** aportaciones a Infonavit en la Modalidad 10 y rangos de gastos de escrituración en 2026. Consultado el 29 de septiembre de 2026 a través del IMSS, Infonavit y medios informativos. El impuesto de adquisición cambia por estado: pide cotización a un notario.



#### Compara créditos hipotecarios

Compara el CAT, el enganche, el plazo, los seguros y las comisiones. CONDUSEF tiene simuladores de crédito hipotecario. Pide al menos tres cotizaciones.



#### Casos


**Caso 1. El departamento de Gael**

Gael quiere comprar, pero le faltan dos años de ahorro y ordenar sus declaraciones.
- *¿Qué hace?* Sigue rentando, ahorra para el enganche y ordena sus impuestos antes de pedir el crédito.


**Caso 2. La mensualidad de Valeria**

La mensualidad de un crédito hipotecario le cabe a Valeria en sus meses buenos, pero no en su mes bajo.
- *¿Le conviene?* No por ahora: debe caber en su mes bajo. Espera o busca algo más barato.


**Caso 3. El Infonavit de Toño**

Toño cotizó años en nómina y ahora está en Modalidad 10.
- *¿Qué revisa?* Su saldo en Infonavit y qué opciones de crédito tiene como independiente.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar solo en el enganche | Te faltan miles | Suma todos los costos |
| Usar tu fondo de sequía para el enganche | Quedas sin colchón | Ahorra aparte |
| No ordenar tus impuestos | No te prestan | Declara bien |
| Elegir con el mes bueno | La mensualidad no cabe | Usa tu mes bajo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Departamento de 1,500,000 con enganche de 20%. ¿Cuánto es el enganche? a) 150,000 · b) 20,000 · c) 300,000
2. ¿Con qué mes decides si la mensualidad cabe? a) Tu mejor mes · b) Tu mes bajo · c) El promedio de tus mejores meses
3. ¿Qué te ayuda a obtener un crédito hipotecario como independiente? a) Muchas tarjetas · b) Pagar todo en efectivo para que no te revisen · c) Impuestos en orden y buen historial
**Respuestas:** 1-c: 20% de 1,500,000. 2-b: así aguantas la sequía. 3-c: demuestran tus ingresos y tu forma de pagar.



#### Ponlo en práctica

Calcula cuánto necesitarías ahorrar para comprar una vivienda que te interese: enganche, gastos notariales estimados y tu fondo intacto.
**Respuesta:** Por ejemplo: vivienda de 1,800,000; enganche 15%, 270,000; gastos 108,000. Necesito 378,000 además de mi fondo de 60,000.



#### A tu plan

Si quieres comprar, abre un ahorro separado para el enganche y revisa tu saldo de Infonavit.



### Para saber más

- **Simulador de crédito hipotecario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** "Simuladores" de crédito hipotecario.
- **Infonavit** (Infonavit · español): https://portalmx.infonavit.org.mx — **Qué buscar:** tu saldo y opciones de crédito.

### Palabras clave

- *Enganche:* pago inicial al comprar una vivienda.
- *Gastos notariales:* costos de escrituración de la compra.
- *Predial:* impuesto anual sobre tu vivienda.

### Fuentes

CONDUSEF · Infonavit · IMSS, consultados el 29 de septiembre de 2026.

---

## M11 U07. Ingresos fuera de cámara

**Lo que lograrás:** Diversificar tus ingresos con clases, talleres, producción, marcas propias o consultoría, y calcular si un negocio paralelo realmente te deja ganancia.

**Para empezar:** Renata quiere abrir una academia de baile para no depender solo de los eventos. Su amiga le dice que "eso deja mucho dinero". Renata no ha calculado renta, maestros, permisos ni cuántos alumnos necesita. En esta lección aprenderás a evaluar un ingreso fuera de cámara.

### Lo esencial (5 minutos)

#### No dependas de una sola fuente

Tu talento sirve para más de una cosa. Un ingreso fuera de cámara estabiliza tus meses bajos y te prepara para el futuro.



#### Ideas según tu talento

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Enseñar | Clases, talleres, coaching de voz o actuación. | Poca inversión. |
| Producir | Edición, fotografía, producción técnica. | Usa tu equipo. |
| Marca propia | Ropa, cosméticos, mercancía. | Más inversión y riesgo. |
| Consultoría | Asesoría de imagen, redes, oratoria. | Tu experiencia vale. |

#### ¿Cuánto deja la academia de Renata?

Un mes con 40 alumnos a 900.
- Ingresos: **36,000**
- Renta, maestros, luz, permisos y publicidad: **28,000**
- Ganancia antes de impuestos: **8,000**
Con 30 alumnos, perdería dinero.


#### Un caso en un minuto

Renata hizo la cuenta y vio que la academia necesitaba muchos alumnos para ganar. Empezó con clases en un estudio rentado por hora: menos riesgo y ganancia desde el primer mes.

Cuando tenga lista de espera, pensará en un local propio.

> **Idea clave:** empieza pequeño, con poca inversión, y crece cuando los números lo justifiquen.



#### Comprueba lo que entendiste

1. ¿Por qué tener un ingreso fuera de cámara?
*Respuesta:* Para estabilizar tus meses bajos y prepararte para el futuro.

2. ¿Qué calculas antes de abrir un negocio?
*Respuesta:* Ingresos, todos los costos y cuántos clientes necesitas para ganar.


#### Para recordar

- Diversifica tus ingresos.
- Calcula antes de invertir.
- Empieza pequeño.



### Profundiza (5 minutos más)

#### Punto de equilibrio

Es el número de clientes o ventas que necesitas para cubrir tus costos. Por debajo pierdes; por encima ganas. Calcúlalo antes de firmar una renta o comprar mercancía.



#### Comparación de Renata

| | Estudio por hora | Local propio |
|---|---|---|
| Inversión inicial | Baja | Alta |
| Costo fijo al mes | Bajo | Alto |
| Alumnos para ganar | Pocos | Muchos |
| Riesgo | Bajo | Alto |



#### Formalízalo

Tus ingresos extra también se declaran. Revisa con tu contador si caben en tu régimen actual y qué permisos locales necesitas (M2).

> **Dato adicional:** los ingresos de actividades adicionales se suman a tus ingresos del año y pueden cambiar tu régimen o tu tasa. Confírmalo con tu contador.



#### No uses tu fondo de sequía

Un negocio nuevo necesita su propio capital. Si inviertes tu fondo de sequía y el negocio tarda en arrancar, te quedas sin colchón en tu siguiente temporada baja.



#### Casos


**Caso 1. La academia de Renata**

Renata quiere un local propio sin haber calculado cuántos alumnos necesita.
- *¿Qué hace primero?* Calcula su punto de equilibrio y empieza con un estudio por hora.


**Caso 2. Las clases de Gael**

Gael quiere dar clases de actuación en temporada baja.
- *¿Qué revisa?* Costo del espacio, precio por clase, cuántos alumnos necesita y cómo declarar ese ingreso.


**Caso 3. La marca de Valeria**

Valeria quiere lanzar una línea de ropa usando su fondo de sequía.
- *¿Le conviene?* No: el negocio necesita su propio capital; empieza con un pedido pequeño y registra su marca (M10 U05).


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Abrir sin calcular | Pierdes dinero | Calcula tu punto de equilibrio |
| Empezar en grande | Costos fijos altos | Empieza pequeño |
| Usar tu fondo de sequía | Sin colchón | Capital aparte |
| No declarar | Problemas con el SAT | Formaliza tus ingresos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Renata. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. 20 alumnos a 800 y costos de 14,000. ¿Ganancia antes de impuestos? a) 16,000 · b) 30,000 · c) 2,000
2. ¿Qué es el punto de equilibrio? a) Tu ganancia máxima · b) Lo que necesitas vender para cubrir tus costos · c) Tu precio más alto posible
3. ¿Con qué capital inicias un negocio? a) Tu fondo de sequía · b) Capital aparte, no tu fondo de sequía · c) Un préstamo por app que llega en minutos
**Respuestas:** 1-c: 16,000 − 14,000. 2-b: por debajo pierdes. 3-b: protege tu colchón.



#### Ponlo en práctica

Elige una idea de ingreso fuera de cámara y calcula ingresos, costos y punto de equilibrio.
**Respuesta:** Por ejemplo: taller de canto de 6 personas a 1,200 = 7,200; espacio y materiales 3,000. Gano 4,200. Punto de equilibrio: 3 personas.



#### A tu plan

Escribe tres ideas de ingreso fuera de cámara y calcula la más sencilla de empezar.



### Para saber más

- **Emprendimiento** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para iniciar un negocio y financiarlo.
- **RESICO y otros regímenes** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** cómo declarar ingresos adicionales.

### Palabras clave

- *Punto de equilibrio:* ventas necesarias para cubrir tus costos.
- *Costo fijo:* gasto que pagas aunque no vendas.
- *Capital:* dinero que inviertes en un negocio.

### Fuentes

SAT · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M11 U08. Tu carrera larga

**Lo que lograrás:** Planear las etapas de tu carrera (formación, crecimiento, madurez y transición) y lo que necesitas en cada una.

**Para empezar:** Toño tiene 41 años. Ve que cada año hay menos sesiones de grabación y más músicos jóvenes. Le preocupa qué hará a los 55. Nunca ha planeado su carrera más allá del siguiente proyecto. En esta lección pensarás tu carrera a largo plazo.

### Lo esencial (5 minutos)

#### Las etapas de una carrera

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Formación | Aprendes, construyes tu nombre y tu red. | Invierte en ti. |
| Crecimiento | Más proyectos y mejores pagos. | Ahorra y protege. |
| Madurez | Tu experiencia vale más. | Diversifica. |
| Transición | Enseñas, diriges, produces o te retiras. | Prepárate con tiempo. |

#### Planea la siguiente etapa desde ahora

La transición no llega de golpe. Si empiezas a construir tu siguiente etapa mientras trabajas, el cambio será una elección y no una emergencia.



#### Invierte en seguir aprendiendo

Cursos, nuevas técnicas, herramientas digitales y habilidades de producción o docencia te abren puertas en todas las etapas.



#### Un caso en un minuto

Toño empezó a dar clases de bajo los sábados y tomó un curso de producción musical. En cinco años quiere producir discos de otros artistas.

Mientras tanto, aporta a su AFORE y revisó la Modalidad 40.

> **Idea clave:** tu carrera es larga. Planéala por etapas, no solo por proyectos.



#### Comprueba lo que entendiste

1. ¿Cuándo empiezas a preparar tu transición?
*Respuesta:* Desde ahora, mientras trabajas.

2. ¿Qué te abre puertas en todas las etapas?
*Respuesta:* Seguir aprendiendo.


#### Para recordar

- Formación, crecimiento, madurez y transición.
- Prepara la siguiente etapa desde hoy.
- Sigue aprendiendo.



### Profundiza (5 minutos más)

#### Qué necesitas en cada etapa

| Etapa | Finanzas | Carrera |
|---|---|---|
| Formación | Fondo de sequía pequeño, sin deudas caras | Formación y red |
| Crecimiento | Fondo completo, retiro, seguros | Mejores contratos |
| Madurez | Inversión de largo plazo | Diversificar ingresos |
| Transición | Retiro y patrimonio | Docencia, dirección, producción |



#### Tu red de contactos

Colegas, productores, maestros y alumnos son parte de tu carrera larga. Cuida esas relaciones: muchas oportunidades de la siguiente etapa vienen de ahí.



#### Tu salud es tu carrera

Cuidar tu cuerpo y tu voz, dormir, descansar y atender tu salud mental te permite trabajar más años.



#### Revisa cada año

Una vez al año pregúntate: ¿en qué etapa estoy? ¿Qué tengo que aprender? ¿Cómo va mi fondo, mi retiro y mi protección?

> **Dato adicional:** muchas personas del medio combinan varias actividades a lo largo de su carrera; planear esa combinación reduce la incertidumbre.



#### Casos


**Caso 1. Los 55 de Toño**

Toño teme no tener trabajo a los 55 años.
- *¿Qué hace desde ahora?* Construye su siguiente etapa: clases, un curso de producción y su retiro en marcha.


**Caso 2. El boom de Valeria**

Valeria está en su mejor momento y cree que siempre será así.
- *¿Qué le conviene?* Aprovechar para ahorrar, proteger y diversificar, porque las etapas cambian.


**Caso 3. La formación de Gael**

Gael no ha tomado un curso en cinco años.
- *¿Qué le recomiendas?* Presupuestar formación cada año para abrir puertas en su siguiente etapa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Planear solo el siguiente proyecto | La transición te sorprende | Planea por etapas |
| Creer que el boom es para siempre | No ahorras | Aprovecha los buenos años |
| Dejar de aprender | Menos oportunidades | Formación continua |
| Descuidar tu salud | Carrera más corta | Cuídate |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Valeria y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es la etapa en que enseñas, diriges o produces? a) Formación · b) Ninguna · c) Transición
2. ¿Cuándo preparas tu transición? a) Cuando ya no haya trabajo · b) Nunca · c) Desde ahora
3. ¿Qué haces en tu mejor momento? a) Gastar todo · b) Dejar de aprender y aprovechar el momento · c) Ahorrar, proteger y diversificar
**Respuestas:** 1-c: es la etapa de cambio. 2-c: así es una elección. 3-c: las etapas cambian.



#### Ponlo en práctica

Escribe en qué etapa estás y una acción para prepararte para la siguiente.
**Respuesta:** Por ejemplo: estoy en crecimiento. Tomaré un curso de dirección escénica este año y empezaré a dar un taller.



#### A tu plan

Anota tu etapa actual y agenda tu revisión anual de carrera.



### Para saber más

- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** guías para planear tus finanzas por etapas.
- **Retiro** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** calculadoras de retiro.

### Palabras clave

- *Transición:* cambio a una nueva etapa de tu carrera.
- *Formación continua:* seguir aprendiendo a lo largo de tu carrera.
- *Red de contactos:* personas con quienes trabajas y colaboras.

### Fuentes

CONDUSEF · CONSAR, consultados el 29 de septiembre de 2026.

---

## M11 U09. Tu plan de una página

**Lo que lograrás:** Reunir tus números, tus deudas, tu fondo, tu protección, tus metas y tres acciones con fecha en una sola página.

**Para empezar:** Llegaste al final del programa. Gael, Valeria, Renata y Toño empezaron con deudas, dudas y miedo. Hoy cada uno tiene un plan en una página. En esta lección harás el tuyo.

### Lo esencial (5 minutos)

#### Un plan cabe en una página

Tu plan no tiene que ser perfecto. Tiene que ser claro, posible y tuyo.



#### Las partes de tu plan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mis números | Mes bajo, sueldo fijo, impuestos. | M1 y M2. |
| Mis deudas | Inventario, método y pago base. | M6 a M8. |
| Mi protección | Fondo, seguros, IMSS, testamento, fraudes. | M9 y M10. |
| Mi futuro | Retiro, inversión, carrera. | M11. |

#### Tres acciones con fecha

1. **Esta semana:** algo pequeño, como pedir tus reportes de crédito.
2. **Este mes:** algo que requiere más, como inscribirte en la Modalidad 10.
3. **Este año:** una meta grande, como completar tu fondo de sequía.



#### Un caso en un minuto

Renata escribió su plan: esta semana, pedir sus reportes y activar el bloqueo; este mes, cerrar dos tarjetas de tienda; este año, bajar su deuda de 95,000 a 40,000.

Lo pegó junto a su espejo y lo revisa cada tres meses.

> **Idea clave:** no se trata de hacerlo todo, sino de dar el siguiente paso.



#### Comprueba lo que entendiste

1. ¿Tu plan tiene que ser perfecto?
*Respuesta:* No. Claro y posible es suficiente.

2. ¿Cada cuánto lo revisas?
*Respuesta:* Cada tres meses o cuando algo cambie.


#### Para recordar

- Tu plan cabe en una página.
- Tres acciones con fecha.
- Revísalo cada tres meses.



### Profundiza (5 minutos más)

#### Tu plan de una página

| Parte | Qué escribes |
|---|---|
| Mis números | Mes bajo, sueldo fijo, porcentaje para impuestos |
| Mis deudas | Total, método, pago base y fecha meta |
| Mi fondo de sequía | Cuánto tengo y mi meta |
| Mi protección | Seguro médico, IMSS, seguro de vida, testamento, bloqueo |
| Mi carrera | Contratos, regalías, marca, siguiente etapa |
| Mi futuro | AFORE, PPR o Modalidad 40, inversión |
| Mis tres acciones | Semana, mes y año |
| Mi red de apoyo | Contador, CONDUSEF, PRODECON, ANDA, comunidad |



#### Tu red de apoyo

Guarda los contactos que conociste: CONDUSEF, PRODECON, SAT, IMSS, CONSAR, Buró y Círculo, INDAUTOR, IMPI, tu sociedad de gestión colectiva, el 088 y la comunidad del programa.

No tienes que hacerlo en soledad.



#### Celebra tus avances

Cada paso cuenta: pedir tus reportes, pagar una tarjeta, registrar tu nombre, inscribirte al IMSS. Anota tus logros en tu plan.



#### Tu plan cambia contigo

Un proyecto grande, una sequía, una lesión o un cambio de etapa: cuando algo cambie, vuelve a la lección del tema y actualiza esa parte de tu plan.

> **Dato adicional:** los datos de este programa se consultaron el 29 de septiembre de 2026. Antes de decidir, confirma siempre la información vigente en CONDUSEF, la CNBV, el SAT, el IMSS o el sitio oficial de la institución.



#### Casos


**Caso 1. El plan de Renata**

Renata tiene muchas cosas pendientes y no sabe por dónde empezar.
- *¿Qué hace?* Elige una acción pequeña para esta semana y la escribe con fecha.


**Caso 2. El cambio de Gael**

Gael consiguió un contrato largo como asimilado.
- *¿Qué revisa en su plan?* Su régimen con su contador, su sueldo fijo, su pago base de deudas y sus deducciones personales.


**Caso 3. El tropiezo de Toño**

Toño tuvo que usar su fondo en una sequía larga.
- *¿Fracasó su plan?* No: el fondo cumplió su función. Ahora lo vuelve a llenar poco a poco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar el plan perfecto | Nunca empiezas | Una página basta |
| Metas sin fecha | No avanzan | Pon fecha a cada acción |
| No revisarlo | Se vuelve inútil | Cada tres meses |
| Sentir culpa si algo falla | Abandonas | Ajusta y sigue |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Gael, Renata y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Tu plan tiene que ser perfecto para empezar? a) Sí · b) Solo si tienes contador · c) No
2. Usar tu fondo en una sequía, ¿es un fracaso? a) Sí · b) Solo si fue mucho · c) No, para eso es
3. ¿Cada cuánto revisas tu plan? a) Una vez en la vida, cuando termines el curso · b) Nunca · c) Cada tres meses o cuando algo cambie
**Respuestas:** 1-c: claro y posible basta. 2-c: el fondo cumplió su función. 3-c: así sigue siendo útil.



#### Ponlo en práctica

Escribe tu plan de una página con todas sus partes y tres acciones con fecha.
**Respuesta:** Por ejemplo: mes bajo 18,000, sueldo 20,000, 20% a impuestos; deuda 60,000 con avalancha y pago base 3,000; fondo 20,000 de 72,000; Modalidad 10 pendiente; reportes esta semana, IMSS este mes, fondo completo este año.



#### A tu plan

Escribe tu plan de una página y ponle fecha de revisión. ¡Felicidades por terminar el programa!



### Para saber más

- **Educación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** herramientas para tu plan financiero.
- **PRODECON** (Gobierno de México · español): https://www.gob.mx/prodecon — **Qué buscar:** orientación fiscal gratuita.
- **Comunidad Tu Talento** (Desarrolla Talento · español): https://academia.desarrollatalento.com — **Qué buscar:** el foro de la comunidad y el canal de avisos.

### Palabras clave

- *Plan financiero:* tus números, metas y acciones por escrito.
- *Red de apoyo:* personas e instituciones que te orientan.

### Fuentes

Todas las fuentes del programa, consultadas el 29 de septiembre de 2026.

---
