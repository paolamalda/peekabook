# 7. Datos verificados (29 de septiembre de 2026)

| Clave | Dato | Resultado | Fuente |
|---|---|---|---|
| E01 | Declaración anual de RESICO | No obligatoria si estuvo todo el año en RESICO, presentó todos los pagos mensuales y no tuvo otros ingresos | RMF 2026, regla 3.13.7; LISR 113-G |
| E02 | Tope de deducciones personales | Menor entre 5 UMA anuales (213,973.20 pesos en 2026) y 15% de ingresos | LISR 151; UMA 2026 (DOF 9-ene-2026) |
| E03 | PPR y aportaciones complementarias | 10% de ingresos, máximo 5 UMA anuales, fuera del tope global; retiro antes de 65 con retención de 20% | LISR 142-XVIII y 151-V |
| E04 | Modalidad 10 | De un salario mínimo (9,582.47 al mes) a 25 UMA; cuota mínima cercana a 2,500 al mes; Infonavit opcional (5%) | IMSS; medios |
| E05 | Convenio IMSS-ANDA | Incorporación voluntaria de artistas independientes con beneficiarios, publicado el 20-sep-2026 | IMSS; medios |
| E06 | Modalidad 40 | 14.438% en 2026, de 3 a 25 UMA; sube hasta 18.8% en 2030 | LSS 218; reforma 2020 |
| E07 | Plazo de eliminación en historial | 1, 2, 4 o 6 años según UDIS; se cuenta desde que se incorporó el primer incumplimiento | LRSIC 23; CONDUSEF |
| E08 | Reclamaciones | 5 días hábiles para enviar; 30 días naturales para responder; Círculo: 2 gratis al año, luego 80 pesos | LRSIC 42-44; Círculo de Crédito |
| E09 | Reportes adicionales y score | Buró: reporte 47, Mi Score 58; Círculo: reporte desde 34.50, score 50 y 97 | Sitios oficiales; medios |
| E10 | Bloqueo y alertas | Buró: bloqueo 58 por 3 meses, Alertas 232 al año; Círculo: bloqueo 3 meses, Avísame gratis, Avísame Mucho Más 250 | Sitios oficiales; medios |
| E11 | Horario de cobranza | 7:00 a 22:00 horas del huso horario del deudor | Disposiciones CONDUSEF, DOF 7-oct-2014 |
| E12 | Pago anticipado | Derecho a pagos anticipados; comisión solo si está pactada y registrada; prohibida en hipotecarios salvo opción | LTOSF; Circular 22/2010 y 8/2016 |
| E13 | Regalías | Exenciones para autores: ISR hasta 20 UMA (93-XXIX) e IVA (15-XVI); intérpretes, revisar con contador | LISR; LIVA |
| E14 | ANDA, salud | Clínicas para agremiados con cuota de consulta; servicio completo para activos al corriente | ANDA; medios |
| E15 | Reserva de derechos y marca | INDAUTOR: 5 años, 5,739 (renovación 2,892); IMPI: 10 años, 2,695.18 más IVA por clase, uso a los 3 años | Tarifas 2026 |
| E16 | Mes del Testamento 2026 | Hasta 50% de descuento; desde unos 2,750 pesos | Segob; medios |
| E17 | Infonavit y escrituración | Crédito vía Modalidad 10 con aportación de 5%; escrituración de 4% a 7% | IMSS; Infonavit; medios |
| E18 | Seguro de voz | Sin producto estándar en México; combinar accidentes personales, gastos médicos e IMSS | Búsqueda de mercado |
| E19 | Policía cibernética | 088 de la Guardia Nacional | Guardia Nacional CERT-MX |

**Quedan dos confirmaciones que conviene hacer en el sitio oficial antes de publicar:** que los productos de ahorro de Nu ya estén en el banco (padrón de la CNBV) y los precios de Buró y Círculo del día (los sitios oficiales no fueron accesibles desde el entorno de trabajo; los montos vienen de fuentes que citan esos sitios).
