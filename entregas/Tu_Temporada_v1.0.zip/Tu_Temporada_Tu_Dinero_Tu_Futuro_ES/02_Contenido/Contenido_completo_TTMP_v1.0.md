# Tu Temporada, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Don Efrén | 45 años. De Guanajuato. Lleva ocho temporadas con visa H-2A en el tabaco en Carolina del Norte. |
| Rosaura | 38 años. De Tlaxcala. Va con el PTAT a invernaderos de Ontario, Canadá, desde hace seis temporadas. |
| Juan Carlos | 23 años. De Hidalgo. Va por primera vez a la cosecha de manzana en Washington con visa H-2A. |
| Doña Imelda | 43 años. Esposa de Don Efrén. Se queda a cargo de la casa y de los hijos. |
| Ramiro | 35 años. De Michoacán. Un reclutador le cobró por «asegurar su lugar». |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Antes de firmar: dos caminos y cero fraudes | El camino correcto para ti, tu contrato revisado y ningún pago a reclutadores. | Contrato claro |
| Módulo 2. Antes de irte: la casa en orden | Tu casa en orden: quién maneja el dinero, el presupuesto de la familia y sin deudas para irte. | Casa en orden |
| Módulo 3. Tu pago allá | Tus talones de pago revisados y tu forma segura de cobrar. | Pago revisado |
| Módulo 4. Mandar dinero que rinda | Tus envíos comparados y un plan para la remesa acordado con la familia. | Envío que rinde |
| Módulo 5. Impuestos y papeles en Canadá y Estados Unidos | Tus papeles de impuestos guardados y tu decisión sobre la declaración. | Papeles en regla |
| Módulo 6. Tus derechos y tu seguridad | Tus derechos claros y tu lista de a quién llamar. | Conozco mis derechos |
| Módulo 7. El regreso y los meses sin temporada | Tu presupuesto para los meses entre temporadas. |  |
| Módulo 8. Tu retiro y tu futuro en México | Tus semanas y aportaciones para el retiro (en México y Canadá) y tu proyecto en números. |  |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Contrato sin fraudes, Pago y derechos, Envíos de dinero, Impuestos, Retiro y proyecto.

## 3. Lecciones

# Parte 2. Módulo 1. Antes de firmar: dos caminos y cero fraudes

## M1 U01. Dos caminos: Canadá y Estados Unidos

**Lo que lograrás:** Distinguir cómo funcionan el PTAT a Canadá y la visa H-2A a Estados Unidos, y qué paga el empleador en cada uno. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Juan Carlos quiere ir a trabajar al campo. Su primo le dijo que «hay que pagar como 40 mil para la visa». Su vecina Rosaura, que va a Canadá, le dice que ella nunca ha pagado por su lugar. En esta lección verás por qué.

### Lo esencial (5 minutos)

#### Dos caminos distintos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Canadá · PTAT | Acuerdo entre gobiernos desde 1974. | Te inscribes en el Servicio Nacional de Empleo, sin costo. |
| Estados Unidos · H-2A | Un empleador privado pide permiso para contratarte. | Tramitas la visa en el consulado. |

#### Canadá · PTAT

Te registras en la oficina del Servicio Nacional de Empleo de tu estado, en los periodos de reclutamiento. El servicio es sin costo. El empleador paga tu avión (puede descontarte hasta la mitad) y te da vivienda; solo en Columbia Británica pueden descontar una parte de la vivienda.



#### Estados Unidos · H-2A

El empleador paga el reclutamiento, la vivienda y el traslado diario al campo. El viaje de ida te lo paga o te lo reembolsa al cumplir la mitad del contrato, y el regreso al terminarlo. La cuota de la visa se paga solo en las cuentas oficiales del consulado y te la deben reembolsar.



#### Un caso en un minuto

Juan Carlos preguntó en el Servicio Nacional de Empleo por el PTAT y a un empleador de EE. UU. por escrito. En ninguno de los dos tenía que pagar por su lugar. Eligió la H-2A porque ya tenía una oferta verificada.

> **Idea clave:** al PTAT entras sin costo por el Servicio Nacional de Empleo; en la H-2A el empleador paga el reclutamiento. Nadie debe cobrarte por tu lugar.



#### Comprueba lo que entendiste

1. ¿Dónde te registras para el PTAT a Canadá?
*Respuesta:* En la oficina del Servicio Nacional de Empleo, sin costo.

2. ¿Quién paga el reclutamiento en la H-2A?
*Respuesta:* El empleador.


#### Para recordar

- PTAT: Servicio Nacional de Empleo.
- H-2A: paga el empleador.
- Nadie cobra por tu lugar.



### Profundiza (5 minutos más)

#### Comparo los dos caminos

| Tema | Canadá (PTAT) | Estados Unidos (H-2A) |
|---|---|---|
| Dónde me registro | Servicio Nacional de Empleo | Empleador o agencia, visa en el consulado |
| Viaje | Lo paga el empleador; puede descontar hasta 50% | Lo paga o reembolsa el empleador |
| Vivienda | Sin costo (salvo Columbia Británica) | Sin costo |
| Duración | Hasta 8 meses, regreso antes del 15 de diciembre | Según el contrato |
| Retiro | Cotizas al Plan de Pensiones de Canadá | No cotizas al Seguro Social de EE. UU. |



#### Canadá · PTAT: otros caminos a Canadá

Además del PTAT, hay empleadores canadienses que contratan por otras vías del programa de trabajadores temporales. Las reglas cambian: pregunta siempre en el consulado de Canadá o en el Servicio Nacional de Empleo antes de pagar algo.



#### Casos


**Caso 1. Los 40 mil**

El primo de Juan Carlos dice que hay que pagar 40 mil por la visa.
- *¿Qué hace?* Pregunta en el Servicio Nacional de Empleo y al empleador por escrito.


**Caso 2. El PTAT con cuota**

A Rosaura le ofrecen «meterla al programa de Canadá» por 8,000 pesos.
- *¿Qué hace?* No paga: el PTAT es sin costo en el Servicio Nacional de Empleo.


**Caso 3. La cuota a una cuenta personal**

Le piden a Don Efrén depositar la cuota de la visa a una cuenta personal.
- *¿Qué hace?* Paga solo en las cuentas oficiales del consulado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por el lugar | Fraude | Nadie cobra |
| Creer que el PTAT tiene cuota | Pierdes dinero | Es sin costo |
| Cuota de visa a personas | Fraude | Cuentas oficiales |
| No comparar caminos | Decides mal | Usa la tabla |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Rosaura y Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde te registras para el PTAT a Canadá? a) Con un reclutador privado que cobra cuota · b) En el Servicio Nacional de Empleo · c) En la tienda del pueblo, con un anuncio
2. ¿Cuánto cuesta el servicio del PTAT? a) Nada · b) 8,000 pesos · c) Una parte del primer pago
3. En la H-2A, ¿quién paga el reclutamiento? a) El trabajador · b) La familia · c) El empleador
**Respuestas:** 1-b: SNE. 2-a: sin costo. 3-c: el empleador.



#### Ponlo en práctica

Escribe una diferencia entre el PTAT y la H-2A en el retiro.
**Respuesta:** En Canadá cotizas al Plan de Pensiones de Canadá; con la H-2A no cotizas al Seguro Social de EE. UU.



#### A tu plan

Llena la tabla comparativa y pregunta en el Servicio Nacional de Empleo de tu estado por los periodos de registro.



### Para saber más

- **PTAT** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** «Programa de Trabajadores Agrícolas Temporales México-Canadá».
- **Contrato PTAT 2026** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** «Contrato de trabajo para trabajadores agrícolas temporales mexicanos en Canadá 2026».
- **Ofertas H-2A** (DOL · inglés y español): https://seasonaljobs.dol.gov — **Qué buscar:** las ofertas de trabajo vigentes con salario, horas y vivienda.

### Palabras clave

- *PTAT:* Programa de Trabajadores Agrícolas Temporales México-Canadá.
- *H-2A:* visa de trabajo agrícola temporal en Estados Unidos.
- *Servicio Nacional de Empleo:* oficina pública de empleo.

### Fuentes

STPS, PTAT; Gobierno de Canadá, contrato SAWP-México 2026; DOL, protecciones para trabajadores H-2A; consultados el 5 de octubre de 2026.

---

## M1 U02. Reclutadores falsos

**Lo que lograrás:** Reconocer a los reclutadores que cobran o engañan, y saber cómo verificar una oferta para Canadá o Estados Unidos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Un señor del pueblo vecino le prometió a Ramiro un lugar en la cosecha de fresa si le daba 15,000 pesos para «asegurar el lugar». Ramiro pagó. El señor ya no contesta. En esta lección verás las señales.

### Lo esencial (5 minutos)

#### La alerta es real

En septiembre de 2026 la Secretaría del Trabajo alertó sobre fraudes con visas de trabajo agrícola. Los fraudes buscan a quien más necesita el trabajo.



#### Señales de fraude

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te cobran | Por el lugar, el trámite o el contrato. | Prohibido. |
| Cuenta personal | Depósitos a una persona. | No a cuentas oficiales. |
| No es de campo | Hotel, construcción, fábrica con «visa agrícola». | No cuadra. |
| Prisa y secreto | «Paga hoy», «no le digas a nadie». | Para que no preguntes. |

#### Cómo verificar

**Canadá · PTAT:** pregunta directo en el Servicio Nacional de Empleo de tu estado. **Estados Unidos · H-2A:** busca la oferta en SeasonalJobs.dol.gov y pide el nombre del empleador y el lugar del campo. **En los dos países:** revisa si la agencia está registrada ante la Secretaría del Trabajo y pregunta en el consulado.



#### Un caso en un minuto

Ramiro denunció ante la Fiscalía y avisó a la Secretaría del Trabajo. Al año siguiente se registró en el Servicio Nacional de Empleo y entró al PTAT sin pagar nada.

> **Idea clave:** si te cobran por el lugar o el trámite, es fraude; verifica la oferta antes de dar un peso.



#### Comprueba lo que entendiste

1. ¿Te pueden cobrar por «asegurar tu lugar»?
*Respuesta:* No; es fraude.

2. ¿Dónde verificas una oferta para Canadá con el PTAT?
*Respuesta:* En el Servicio Nacional de Empleo de mi estado.


#### Para recordar

- Nadie cobra por el lugar.
- Verifica la oferta.
- Denuncia si te pasa.



### Profundiza (5 minutos más)

#### Verificación de mi oferta

| Revisar | Sí | No |
|---|---|---|
| La confirmé en el SNE (Canadá) o en SeasonalJobs.dol.gov (EE. UU.) | | |
| Tengo el nombre del empleador | | |
| Es trabajo de campo | | |
| No me han pedido dinero | | |
| La agencia está registrada | | |



#### Si ya pagaste

Junta comprobantes, mensajes y nombres. Denuncia ante la Fiscalía de tu estado y avisa a la Secretaría del Trabajo. Contarlo ayuda a que no les pase a otros.



#### Casos


**Caso 1. Asegurar el lugar**

A Ramiro le piden 15,000 para asegurar su lugar.
- *¿Qué hace?* No paga y verifica la oferta.


**Caso 2. «No le digas a nadie»**

A Juan Carlos le dicen que no comente la oferta con nadie.
- *¿Qué hace?* Desconfía y pregunta en el consulado.


**Caso 3. Ya pagó**

Ramiro ya pagó y el reclutador desapareció.
- *¿Qué hace?* Junta pruebas y denuncia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por el lugar | Pierdes tu dinero | Nadie cobra |
| No verificar | Caes en fraude | SNE o página oficial |
| Guardar el secreto | Te aíslan | Pregunta |
| No denunciar | Le pasa a más gente | Denuncia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te cobran por asegurar tu lugar. ¿Qué es? a) Normal · b) Una cuota oficial · c) Fraude
2. ¿Dónde verificas el PTAT a Canadá? a) En el Servicio Nacional de Empleo · b) En grupos de chat de paisanos · c) Con el reclutador
3. Ya pagaste a un reclutador falso. ¿Qué haces? a) Nada · b) Juntas pruebas y denuncias · c) Pagas más para que te contesten
**Respuestas:** 1-c: es fraude. 2-a: SNE. 3-b: denuncia.



#### Ponlo en práctica

Un reclutador cobra 15,000 a 20 personas. ¿Cuánto se lleva?
**Respuesta:** 300,000 pesos.



#### A tu plan

Llena la tabla de verificación de tu oferta antes de dar cualquier dato o dinero.



### Para saber más

- **Servicio Nacional de Empleo** (STPS · español): https://www.empleo.gob.mx — **Qué buscar:** las vacantes de tu estado y los programas de trabajo temporal en el extranjero.
- **Ofertas H-2A** (DOL · inglés y español): https://seasonaljobs.dol.gov — **Qué buscar:** las ofertas de trabajo vigentes con salario, horas y vivienda.
- **Agencias de colocación registradas** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** si la agencia que te ofrece trabajo está registrada.

### Palabras clave

- *Reclutador:* quien busca trabajadores para un empleador.
- *Agencia de colocación:* empresa que coloca trabajadores.
- *Denuncia:* aviso formal a la autoridad.

### Fuentes

STPS, alerta por fraudes en visas de trabajo agrícola (septiembre de 2026) y PTAT; DOL; consultados el 5 de octubre de 2026.

---

## M1 U03. Lee tu contrato

**Lo que lograrás:** Revisar los puntos clave de tu contrato antes de firmar, sea para Canadá o para Estados Unidos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Don Efrén firmó su primer contrato sin leerlo. Ese año hubo pocas horas por la lluvia y le pagaron muy poco. No sabía que tenía una garantía. Rosaura, en Canadá, tampoco sabía cuántas horas mínimas le tocaban. En esta lección revisarás tu contrato.

### Lo esencial (5 minutos)

#### Lo que debe decir tu contrato

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pago | Por hora o por pieza. | Y cada cuándo. |
| Horas y fechas | Inicio, fin, horas por semana. | Lo que ofrecen. |
| Vivienda y comida | Dónde vives y cómo comes. | Qué se descuenta. |
| Descuentos | Solo los permitidos. | Por escrito. |

#### Las garantías de horas

**Estados Unidos · H-2A:** te garantizan al menos tres cuartas partes de las horas totales del contrato. **Canadá · PTAT:** el contrato es de al menos 240 horas en 6 semanas o menos, y de máximo 8 meses, con regreso a más tardar el 15 de diciembre.



#### En tu idioma

En los dos programas tienes derecho a tu contrato en español. Pide una copia y guárdala.



#### Un caso en un minuto

Ahora Don Efrén anota las horas totales de su contrato y una temporada lluviosa reclamó la garantía. Rosaura revisó su contrato: el avión se lo descuentan hasta la mitad y la vivienda en Ontario no se descuenta.

> **Idea clave:** lee pago, horas, vivienda y descuentos. En la H-2A te garantizan 3/4 de las horas. En el PTAT, al menos 240 horas en 6 semanas.



#### Comprueba lo que entendiste

1. ¿Qué es la garantía H-2A de tres cuartas partes?
*Respuesta:* Que te paguen al menos 3/4 de las horas totales del contrato.

2. ¿Cuál es el mínimo del contrato PTAT?
*Respuesta:* 240 horas en 6 semanas o menos.


#### Para recordar

- Pago, horas, vivienda, descuentos.
- H-2A: 3/4 de las horas.
- PTAT: 240 horas en 6 semanas.



### Profundiza (5 minutos más)

#### La garantía de Don Efrén (H-2A)

- Horas totales del contrato: **960**
- Garantía: **3/4**
- Horas que le deben pagar como mínimo: **720**


#### Guarda tu copia

Toma foto del contrato y mándala a tu familia en México. Si pierdes el original, tienes respaldo.



#### Casos


**Caso 1. Firmar sin leer**

Don Efrén firmó sin leer.
- *¿Qué hace ahora?* Lee pago, horas, vivienda y descuentos antes de firmar.


**Caso 2. Los descuentos de Rosaura**

Rosaura no sabe qué le pueden descontar en Canadá.
- *¿Qué hace?* Revisa en su contrato el avión, la vivienda y las deducciones.


**Caso 3. Solo en inglés**

A Juan Carlos le dan el contrato solo en inglés.
- *¿Qué hace?* Pide una copia en español.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin leer | Sorpresas | Lee lo clave |
| No conocer las garantías | Pierdes pago | 3/4 o 240 horas |
| No guardar copia | Sin pruebas | Foto a tu familia |
| Aceptar idioma que no entiendes | No sabes qué firmas | Pide español |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Rosaura y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Tu contrato H-2A es de 800 horas. ¿Cuántas te garantizan como mínimo? a) 600 · b) 800 · c) 400
2. ¿Hasta cuándo debes regresar de Canadá con el PTAT? a) Al 15 de diciembre · b) Cuando quieras · c) En febrero
3. ¿En qué idioma tienes derecho a tu contrato? a) Solo en inglés · b) En español · c) En ninguno
**Respuestas:** 1-a: 3/4 de 800. 2-a: 15 de diciembre. 3-b: español.



#### Ponlo en práctica

Tu contrato H-2A dice 40 horas por semana durante 20 semanas. ¿Cuántas horas te garantizan?
**Respuesta:** 600 horas (3/4 de 800).



#### A tu plan

Antes de firmar, anota pago, horas, vivienda y descuentos de tu contrato.



### Para saber más

- **Contrato PTAT 2026** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** «Contrato de trabajo para trabajadores agrícolas temporales mexicanos 2026».
- **Protecciones H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** tus derechos de pago, vivienda, transporte y cómo reportar abusos.

### Palabras clave

- *Garantía de horas:* mínimo de horas que te deben pagar.
- *Pago por pieza:* pago por lo que cosechas.
- *Deducción:* lo que te descuentan del pago.

### Fuentes

Gobierno de Canadá, contrato SAWP-México 2026; DOL, Wage and Hour Division; consultados el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Antes de irte: la casa en orden

## M2 U01. No te endeudes para irte

**Lo que lograrás:** Calcular lo que de verdad cuesta irte y evitar deudas caras antes de la temporada. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Juan Carlos pidió 20,000 pesos prestados al 10% mensual «para el viaje y los gastos». Los primeros dos meses de trabajo se le fueron en pagar intereses. En esta lección verás cuánto necesitas de verdad.

### Lo esencial (5 minutos)

#### Lo que sí tienes que cubrir

**Estados Unidos · H-2A:** el empleador paga reclutamiento, vivienda y traslados (o te los reembolsa). **Canadá · PTAT:** el empleador paga el avión y puede descontarte hasta la mitad durante la temporada. **En los dos países** sueles cubrir tú algunos gastos antes de irte.

Son los trámites y el traslado a la ciudad donde se hacen, y tus primeros gastos personales. En la H-2A, también la cuota de la visa, que te reembolsan.



#### Antes de pedir prestado

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Haz la lista | Solo lo que sí pagas tú. | Con cifras. |
| Pregunta qué te reembolsan o descuentan | Visa, avión. | Y cuándo. |
| Usa ahorro primero | Aunque sea una parte. | Sin intereses. |
| Si pides, compara | Costo total. | Nunca al 10% mensual. |

#### El 10% mensual

Un préstamo al 10% mensual cuesta 120% al año. Por 20,000 pagas 2,000 de interés cada mes.



#### Un caso en un minuto

Para su segunda temporada, Juan Carlos hizo la lista: necesitaba 6,000, no 20,000. Juntó 4,000 y pidió 2,000 a su hermano sin intereses.

> **Idea clave:** haz la lista de lo que sí pagas tú, pregunta qué te reembolsan y no pidas de más ni caro.



#### Comprueba lo que entendiste

1. ¿Qué paga el empleador en la H-2A y en el PTAT?
*Respuesta:* En la H-2A, reclutamiento, vivienda y traslados; en el PTAT, el avión (puede descontar hasta la mitad) y la vivienda.

2. ¿Cuánto cuesta al mes un préstamo de 20,000 al 10% mensual?
*Respuesta:* 2,000 pesos de interés al mes.


#### Para recordar

- Solo lo que sí pagas.
- Pregunta reembolsos.
- Nada al 10% mensual.



### Profundiza (5 minutos más)

#### La lista de Juan Carlos

- Cuota de visa (se la reembolsan): **3,500**
- Viaje a la ciudad del consulado: **1,500**
- Gastos personales de inicio: **1,000**
- Lo que necesitaba: **6,000**


#### Préstamos de familia con acuerdo

Si pides a un familiar, escriban cuánto, cuándo lo pagas y sin intereses o con uno bajo. Así no hay malentendidos.



#### Casos


**Caso 1. Los 20,000**

Juan Carlos quiere pedir 20,000 al 10% mensual.
- *¿Qué hace?* Hace su lista y pide solo lo necesario, sin intereses caros.


**Caso 2. El reembolso**

Ramiro no sabe si le reembolsan la visa.
- *¿Qué hace?* Pregunta por escrito al empleador cuándo se la reembolsan.


**Caso 3. El hermano**

El hermano de Juan Carlos le presta sin intereses.
- *¿Qué hacen?* Escriben cuánto y cuándo pagará.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir de más | Deuda innecesaria | Lista exacta |
| Préstamo al 10% mensual | Pagas el doble | Compara |
| No preguntar reembolsos | Pierdes dinero | Pregunta |
| Préstamo de palabra | Pleitos | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Ramiro y su hermano. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Pides 10,000 al 10% mensual. ¿Cuánto pagas de interés al mes? a) 100 · b) 1,000 · c) 10,000
2. ¿Qué haces antes de pedir prestado para irte? a) Pides lo que te ofrezcan, sin hacer cuentas · b) Haces la lista de lo que sí pagas tú · c) Pides el doble por si acaso falta algo
3. ¿Qué te deben reembolsar? a) Nada · b) Tu comida en México · c) La cuota de la visa
**Respuestas:** 1-b: 10% de 10,000. 2-b: la lista. 3-c: la visa.



#### Ponlo en práctica

Necesitas 7,000 y tienes 5,500 ahorrados. ¿Cuánto pides?
**Respuesta:** 1,500 pesos.



#### A tu plan

Haz tu lista de lo que sí pagas tú antes de irte.



### Para saber más

- **Créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «CAT» y «préstamos personales».
- **Protecciones H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** tus derechos de pago, vivienda, transporte y cómo reportar abusos.

### Palabras clave

- *Interés:* lo que pagas por un préstamo.
- *Reembolso:* que te regresen lo que pagaste.
- *Acuerdo escrito:* papel con lo que acordaron.

### Fuentes

DOL, costos a cargo del empleador en el programa H-2A; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M2 U02. Quién maneja el dinero en casa

**Lo que lograrás:** Dejar acordado quién maneja el dinero en México mientras estás fuera y con qué herramientas. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Cuando Don Efrén se fue la primera vez, le mandaba el dinero a su compadre para que se lo diera a Doña Imelda. A veces llegaba incompleto. En esta lección dejarán todo en orden.

### Lo esencial (5 minutos)

#### Lo que dejan acordado

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Quién administra | Normalmente quien se queda con los hijos. | Con su propia cuenta. |
| Una cuenta a su nombre | Para recibir los envíos. | Sin intermediarios. |
| Qué se paga cada mes | Lo básico, escuela, deudas. | Por escrito. |
| Cuándo hablan de dinero | Un día fijo. | Revisan juntos. |

#### Si hacen falta trámites

Alguien puede tener que hacer trámites por ti (banco, escuela, programas). Para eso, es más seguro un poder limitado a esos trámites y con fecha de término que uno amplio.



#### Tus papeles y tus NIP

Cada quien con su tarjeta y su NIP. No se deja la tarjeta del que se va con otra persona.



#### Un caso en un minuto

Doña Imelda abrió una cuenta a su nombre. Don Efrén le manda directo y hablan cada domingo de lo que se pagó. Ya no pierden dinero en el camino.

> **Idea clave:** quien se queda administra con una cuenta a su nombre; acuerden qué se paga y hablen de dinero cada semana.



#### Comprueba lo que entendiste

1. ¿A dónde conviene mandar el dinero?
*Respuesta:* A una cuenta a nombre de quien administra en México.

2. ¿Qué tipo de poder es más seguro para trámites?
*Respuesta:* Uno limitado a esos trámites y con fecha de término.


#### Para recordar

- Cuenta a su nombre.
- Lista de pagos.
- Día fijo para hablar.



### Profundiza (5 minutos más)

#### Nuestro acuerdo

| Tema | Lo que acordamos |
|---|---|
| Quién administra | |
| Cuenta para recibir | |
| Pagos de cada mes | |
| Día para hablar de dinero | |



#### Confianza y números

Hablar de dinero con números no es desconfiar. Les ayuda a los dos a ver el avance de la temporada.



#### Casos


**Caso 1. El compadre**

Don Efrén manda el dinero a través de su compadre.
- *¿Qué hace?* Manda directo a la cuenta de Doña Imelda.


**Caso 2. El poder**

Doña Imelda necesita hacer trámites en el banco por Don Efrén.
- *¿Qué hacen?* Un poder limitado a ese trámite y con fecha.


**Caso 3. La tarjeta**

Juan Carlos quiere dejar su tarjeta y NIP a su primo.
- *¿Qué hace?* No la deja: cada quien con la suya.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mandar con terceros | Llega incompleto | Directo |
| Sin acuerdo de pagos | Pleitos | Por escrito |
| Poder amplio | Riesgo | Limitado |
| Dejar tarjeta y NIP | Te vacían la cuenta | Cada quien la suya |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Doña Imelda y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿A dónde mandas el dinero? a) Con un compadre de confianza del pueblo · b) A la cuenta de quien administra en México · c) En efectivo con un conocido
2. Hace falta un poder para trámites. ¿De qué tipo? a) Uno amplio para todo, sin fecha · b) Uno limitado con fecha · c) Ninguno: le das tu tarjeta y tu NIP
3. ¿Qué dejan acordado? a) Nada · b) Solo cómo van a pintar y arreglar la casa · c) Quién administra, qué se paga y cuándo hablan
**Respuestas:** 1-b: directo. 2-b: limitado. 3-c: el acuerdo.



#### Ponlo en práctica

Escribe los cuatro puntos de su acuerdo.
**Respuesta:** Quién administra, la cuenta para recibir, los pagos de cada mes y el día para hablar de dinero.



#### A tu plan

Llenen juntos la tabla «Nuestro acuerdo» antes de que te vayas.



### Para saber más

- **Cuentas básicas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica».

### Palabras clave

- *Administrar:* decidir y pagar los gastos.
- *Poder limitado:* permiso para un trámite concreto.
- *Intermediario:* persona que se mete entre tú y tu dinero.

### Fuentes

CONDUSEF, cuentas básicas; consultado el 5 de octubre de 2026.

---

## M2 U03. El presupuesto de la familia mientras no estás

**Lo que lograrás:** Hacer el presupuesto de la familia en México para toda la temporada, con ahorro incluido. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Doña Imelda recibe dinero cada semana, pero los primeros meses de la temporada la casa aún no recibe nada. Siempre se endeudan en abril. En esta lección harán el presupuesto completo.

### Lo esencial (5 minutos)

#### La temporada tiene etapas

Al inicio no hay envíos: el trabajador apenas cobra. Luego llegan los envíos más fuertes. Al final hay que pensar en el regreso y los meses sin temporada.



#### El presupuesto por etapas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Antes del primer envío | Ahorro previo para unas semanas. | Sin deudas. |
| Durante la temporada | Lo básico y una parte al ahorro. | Cada envío. |
| Después | Ahorro para los meses sin temporada. | Módulo 7. |

#### Cada envío, en partes

Cada envío se reparte: lo básico de la casa, deudas, ahorro para los meses sin temporada y una meta (módulo 8).



#### Un caso en un minuto

Doña Imelda apartó antes 5,000 para las primeras cuatro semanas. De cada envío, 60% va a la casa, 25% al ahorro y 15% al techo nuevo. Este año no se endeudó en abril.

> **Idea clave:** planeen la temporada por etapas y repartan cada envío entre lo básico, el ahorro y una meta.



#### Comprueba lo que entendiste

1. ¿Qué pasa al inicio de la temporada?
*Respuesta:* Todavía no hay envíos; se necesita ahorro previo.

2. ¿En qué se reparte cada envío?
*Respuesta:* Lo básico, deudas, ahorro para los meses sin temporada y una meta.


#### Para recordar

- Ahorro para el inicio.
- Cada envío en partes.
- Ahorro para después.



### Profundiza (5 minutos más)

#### Un envío de 6,000

- Casa (60%): **3,600**
- Ahorro (25%): **1,500**
- Techo nuevo (15%): **900**
- Total: **6,000**


#### Revisen juntos

Cada domingo, revisen cuánto llegó, cuánto se usó y cuánto se ahorró. Así ajustan a tiempo.



#### Casos


**Caso 1. Abril sin dinero**

La familia se endeuda al inicio de cada temporada.
- *¿Qué hacen?* Apartan antes para las primeras semanas.


**Caso 2. Todo a la casa**

Doña Imelda gasta todo el envío en la casa.
- *¿Qué hace?* Reparte en partes, con ahorro y meta.


**Caso 3. Sin revisar**

Don Efrén no sabe cuánto se ha ahorrado.
- *¿Qué hacen?* Revisan juntos cada domingo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No planear el inicio | Deudas | Ahorro previo |
| Gastar todo cada envío | Nada para después | Repartir |
| No revisar | Sorpresas | Cada semana |
| Olvidar los meses sin temporada | Te quedas corto | Ahorra |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con la familia de Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué se necesita para las primeras semanas de la temporada? a) Un préstamo caro · b) Ahorro previo · c) Nada
2. Llega un envío de 5,000 y ahorran 20%. ¿Cuánto ahorran? a) 1,000 · b) 500 · c) 2,000
3. ¿Cada cuándo revisan juntos? a) Nunca · b) Al terminar la temporada · c) Cada semana
**Respuestas:** 1-b: ahorro previo. 2-a: 20% de 5,000. 3-c: cada semana.



#### Ponlo en práctica

La casa gasta 1,250 por semana. ¿Cuánto apartan para cubrir 4 semanas antes del primer envío?
**Respuesta:** 5,000 pesos.



#### A tu plan

Hagan juntos el presupuesto por etapas y decidan los porcentajes de cada envío.



### Para saber más

- **Presupuesto familiar** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto familiar».

### Palabras clave

- *Etapa:* parte de la temporada.
- *Porcentaje:* parte de cada 100.
- *Ahorro previo:* lo que se aparta antes.

### Fuentes

CONDUSEF, presupuesto familiar; consultado el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Tu pago allá

## M3 U01. Tu talón de pago

**Lo que lograrás:** Leer tu talón de pago para revisar horas, tarifa, pago por pieza y descuentos, en Canadá o en Estados Unidos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Juan Carlos cobra cada semana, pero nunca ha leído el papel que le dan con el pago. Rosaura, en Canadá, ve muchas líneas de descuentos que no entiende. En esta lección aprenderán a leerlo.

### Lo esencial (5 minutos)

#### Te deben dar un talón

Con cada pago, el empleador debe darte un estado de pago con tus horas, lo que ganaste y lo que te descontaron. Es tu prueba.



#### Lo que revisas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Horas | Las que trabajaste. | Compara con tu libreta. |
| Tarifa | Por hora o por pieza. | La del contrato. |
| Piezas | Cajas, cubetas, libras. | Si te pagan así. |
| Descuentos | Solo los permitidos. | Pregunta cualquiera raro. |

#### Los descuentos de cada país

**Canadá · PTAT:** impuesto sobre la renta, Plan de Pensiones de Canadá (CPP) y Seguro de Empleo (EI). También los que permita tu contrato: parte del avión, y vivienda solo en Columbia Británica. **Estados Unidos · H-2A:** normalmente no hay retención de Seguro Social. Otros descuentos deben estar permitidos y en tu contrato.



#### Un caso en un minuto

Juan Carlos anotó una semana: 52 horas. El talón decía 46. Preguntó con su libreta y le corrigieron el pago. Rosaura aprendió que el CPP y el EI no son pérdidas: son cotizaciones (módulos 5 y 8).

> **Idea clave:** compara tu talón con tu propia libreta de horas y piezas, y pregunta cualquier descuento que no entiendas.



#### Comprueba lo que entendiste

1. ¿Qué debe traer tu talón de pago?
*Respuesta:* Mis horas, lo que gané y lo que me descontaron.

2. ¿Qué descuentos son normales en Canadá?
*Respuesta:* Impuesto, CPP, EI y los que permita el contrato.


#### Para recordar

- Lee tu talón.
- Lleva tu libreta.
- Pregunta los descuentos.



### Profundiza (5 minutos más)

#### Mi libreta de la semana

| Día | Entrada | Salida | Horas | Piezas |
|---|---|---|---|---|
| Lunes | | | | |
| Martes | | | | |
| Miércoles | | | | |
| Jueves | | | | |
| Viernes | | | | |
| Sábado | | | | |
| **Total** | | | | |



#### Pago por pieza

Si te pagan por pieza en la H-2A, revisa tu pago de la semana. No debe ser menor que tus horas por el salario por hora del contrato. Revisa en tu contrato cómo aplica en tu caso.



#### Casos


**Caso 1. Seis horas menos**

El talón de Juan Carlos tiene 6 horas menos que su libreta.
- *¿Qué hace?* Pregunta al encargado con su libreta en mano.


**Caso 2. Renta en la H-2A**

A Ramiro le descuentan «renta» de la vivienda en EE. UU.
- *¿Qué hace?* Pregunta: la vivienda H-2A es sin costo para el trabajador.


**Caso 3. Las siglas de Canadá**

Rosaura no entiende «CPP» y «EI» en su talón.
- *¿Qué hace?* Sabe que son cotizaciones y las anota para su declaración.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No leer el talón | No ves errores | Léelo |
| No llevar libreta | Sin pruebas | Anota diario |
| Aceptar descuentos raros | Pierdes dinero | Pregunta |
| Tirar los talones | Sin respaldo | Guárdalos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Ramiro y Rosaura. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué trae tu talón de pago? a) Solo tu nombre, la fecha y el empleador · b) Horas, lo que ganaste y descuentos · c) Las horas que te faltan para el bono
2. Te descuentan renta de la vivienda H-2A. ¿Qué haces? a) Preguntas, porque es sin costo · b) Lo aceptas porque así viene en el talón · c) Pagas y luego lo reclamas en México
3. ¿Qué son el CPP y el EI en tu talón de Canadá? a) Multas por faltas o retrasos en el trabajo · b) Comisiones del banco por el depósito · c) Cotizaciones de pensión y seguro de empleo
**Respuestas:** 1-b: los tres. 2-a: sin costo. 3-c: cotizaciones.



#### Ponlo en práctica

Trabajaste 48 horas a 15 dólares la hora. ¿Cuánto debe decir tu talón antes de descuentos?
**Respuesta:** 720 dólares.



#### A tu plan

Lleva tu libreta toda una semana y compárala con tu talón.



### Para saber más

- **Derechos de pago H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** la garantía de 3/4 de las horas y cómo se calcula tu pago por pieza.
- **Derechos de trabajadores temporales en Canadá** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** «Trabajadores extranjeros temporales: sus derechos están protegidos».

### Palabras clave

- *Talón de pago:* papel con el detalle de tu pago.
- *CPP:* Plan de Pensiones de Canadá.
- *EI:* Seguro de Empleo de Canadá.

### Fuentes

DOL, Wage and Hour Division; Gobierno de Canadá, contrato SAWP-México 2026; consultados el 5 de octubre de 2026.

---

## M3 U02. ¿Te pagan lo correcto?

**Lo que lograrás:** Explicar cómo se fija tu salario en Canadá y en Estados Unidos, y qué hacer si te pagan menos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Don Efrén notó que este año su salario por hora en EE. UU. bajó. Rosaura quiere saber si en Ontario le pagan lo que dice su contrato. En esta lección verán cómo se fija el salario en cada país.

### Lo esencial (5 minutos)

#### Cómo se fija tu salario

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Canadá · PTAT | El más alto entre: el mínimo de la provincia, el salario de referencia del año y lo que se paga a trabajadores canadienses en la misma tarea. | Está en tu contrato. |
| Estados Unidos · H-2A | Desde octubre de 2025, dos niveles por estado según la habilidad del puesto. | En 2026, de unos 8 a 17 dólares por hora. |

#### El contrato manda

**En los dos países:** te deben pagar al menos lo que dice tu contrato. Revisa la tarifa antes de firmar y compárala con tu talón.



#### Si te pagan menos

Habla primero con el encargado con tu libreta y tu talón. Si no se corrige, pide apoyo. En **Canadá · PTAT**, el consulado de México tiene personal de enlace del PTAT. En **Estados Unidos · H-2A**, llama a la División de Horas y Salarios del Departamento del Trabajo (1-866-487-9243) y al consulado.



#### Un caso en un minuto

Don Efrén revisó su contrato: el salario bajó por el nuevo nivel en su estado y estaba escrito. Rosaura vio que le pagaban menos horas extra de las acordadas y lo resolvió con el enlace del consulado.

> **Idea clave:** te deben pagar al menos lo del contrato. Si no, reclama con tu libreta y pide apoyo al consulado o al Departamento del Trabajo.



#### Comprueba lo que entendiste

1. En el PTAT, ¿cómo se fija el salario?
*Respuesta:* El más alto entre el mínimo de la provincia, el salario de referencia y lo que ganan trabajadores canadienses en la misma tarea.

2. En EE. UU., ¿a qué número llamas si no corrigen tu pago?
*Respuesta:* A la División de Horas y Salarios, 1-866-487-9243.


#### Para recordar

- El contrato manda.
- Reclama con tu libreta.
- Consulado y autoridad laboral.



### Profundiza (5 minutos más)

#### Cuánto cambia en una temporada

- Dólares menos por hora: **2**
- Horas de la temporada: **960**
- Dólares menos en la temporada: **1,920**


#### Antes de aceptar otra temporada

Compara lo que ganarías (horas por salario, menos descuentos) con lo que dejas de ganar en México y los meses que estarás fuera. Decide con números.



#### Casos


**Caso 1. Bajó el salario**

El salario H-2A de Don Efrén bajó este año.
- *¿Qué hace?* Revisa su contrato y el nivel de su puesto.


**Caso 2. Menos que el contrato en Canadá**

A Rosaura le pagan menos de lo que dice su contrato.
- *¿Qué hace?* Reclama con su libreta y, si no se corrige, acude al enlace del consulado.


**Caso 3. Menos que el contrato en EE. UU.**

A Juan Carlos le pagan menos que la tarifa del contrato.
- *¿Qué hace?* Reclama y, si no se corrige, llama al 1-866-487-9243.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar la tarifa | Te pagan menos | Contrato |
| Creer que no se puede reclamar | Pierdes | Reclama |
| No calcular la temporada | Decides mal | Números |
| No acudir al consulado | Sin apoyo | Te orientan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Rosaura y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es lo mínimo que te deben pagar? a) Lo que quiera el encargado · b) Lo mismo que en México · c) Lo que diga tu contrato
2. En Canadá con el PTAT, ¿quién te apoya si no corrigen tu pago? a) El enlace del PTAT en el consulado de México · b) El reclutador que te llevó al programa · c) Nadie, lo resuelves tú solo
3. En EE. UU., ¿a quién llamas si no corrigen tu pago? a) Al reclutador que te contrató en México · b) A la División de Horas y Salarios · c) A nadie, para no perder la temporada
**Respuestas:** 1-c: el contrato. 2-a: el consulado. 3-b: Horas y Salarios.



#### Ponlo en práctica

Trabajas 900 horas a 16 dólares. ¿Cuánto ganas en la temporada antes de descuentos?
**Respuesta:** 14,400 dólares.



#### A tu plan

Anota la tarifa de tu contrato y guárdala con tu libreta.



### Para saber más

- **División de Horas y Salarios** (DOL · español): https://www.dol.gov/agencies/whd/contact — **Qué buscar:** cómo poner una queja en español; no te preguntan tu situación migratoria; teléfono 1-866-487-9243.
- **Consulados de México en Canadá** (SRE · español): https://consulmex.sre.gob.mx — **Qué buscar:** «Programa de Trabajadores Agrícolas Temporales».

### Palabras clave

- *Salario de referencia:* salario fijado cada año para la tarea.
- *Nivel del puesto:* categoría según la habilidad que pide.
- *Enlace del consulado:* personal que atiende a trabajadores del PTAT.

### Fuentes

Gobierno de Canadá, contrato SAWP-México 2026; DOL, Federal Register (2 de octubre de 2025); consultados el 5 de octubre de 2026.

---

## M3 U03. Cobrar sin perder en comisiones

**Lo que lograrás:** Cobrar tus pagos sin dejar parte en comisiones caras. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Cada semana, Juan Carlos cambia su cheque en una tienda que cobra 4%. En la temporada se le fueron casi 500 dólares en eso. En esta lección verás opciones.

### Lo esencial (5 minutos)

#### Formas de cobrar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta allá | Depósito directo. | Pregunta requisitos. |
| Tarjeta de nómina | La que da el empleador. | Revisa sus comisiones. |
| Cambio de cheques | En tiendas. | Suele ser caro. |

#### Haz la cuenta

4% de cada cheque parece poco. En una temporada son cientos de dólares. Compara cuánto te cuesta cada opción.



#### Pregunta en tu trabajo

Muchos empleadores, en Canadá y en EE. UU., ofrecen depósito directo o ayudan a abrir una cuenta. Pregunta qué comisiones tiene para sacar dinero y para mandar a México.



#### Un caso en un minuto

Juan Carlos pidió depósito directo a una tarjeta de nómina. Saca su dinero en cajeros sin comisión de la red. Ahorra unos 25 dólares a la semana.

> **Idea clave:** cambiar cheques en tiendas cuesta mucho en la temporada; pregunta por depósito directo o una cuenta.



#### Comprueba lo que entendiste

1. ¿Cuánto pierdes con 4% de 600 dólares cada semana?
*Respuesta:* 24 dólares por semana.

2. ¿Qué preguntas sobre la cuenta o tarjeta?
*Respuesta:* Sus comisiones para sacar dinero y para mandar a México.


#### Para recordar

- Haz la cuenta.
- Depósito directo.
- Pregunta comisiones.



### Profundiza (5 minutos más)

#### Lo que perdía Juan Carlos

- Cheque semanal: **600**
- Comisión: **4%**
- Dólares por semana: **24**
- Semanas: **20**
- Dólares en la temporada: **480**


#### Cuida tu dinero en la vivienda

No guardes mucho efectivo en la vivienda. Mándalo a casa o déjalo en tu cuenta.



#### Casos


**Caso 1. El 4%**

Juan Carlos cambia cheques en una tienda.
- *¿Qué hace?* Pide depósito directo o tarjeta de nómina.


**Caso 2. La cuenta en Canadá**

A Rosaura le ofrecen abrir una cuenta en un banco canadiense.
- *¿Qué hace?* Pregunta sus comisiones y si puede mandar dinero a México desde ahí.


**Caso 3. Efectivo guardado**

Don Efrén guarda 1,500 dólares en su maleta.
- *¿Qué hace?* Lo manda a casa o lo deja en su cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cambiar cheques caro | Pierdes cientos | Depósito directo |
| No preguntar comisiones | Sorpresas | Pregunta |
| Efectivo en la vivienda | Robo | Mándalo |
| No hacer la cuenta | No ves la pérdida | Calcula |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Rosaura y Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Un cheque de 500 con 3% de comisión. ¿Cuánto pierdes? a) 3 · b) 15 · c) 150
2. ¿Qué opción suele ser más barata que cambiar cheques en tiendas? a) Depósito directo · b) Guardar los cheques · c) Cambiar en otra tienda
3. Tienes mucho efectivo en la vivienda. ¿Qué haces? a) Lo mandas a casa o lo dejas en tu cuenta · b) Lo escondes en la maleta de la vivienda · c) Lo prestas a compañeros que te lo pidan
**Respuestas:** 1-b: 3% de 500. 2-a: depósito directo. 3-a: mándalo.



#### Ponlo en práctica

Pierdes 20 dólares por semana durante 24 semanas. ¿Cuánto en la temporada?
**Respuesta:** 480 dólares.



#### A tu plan

Pregunta en tu trabajo por depósito directo o una cuenta y sus comisiones.



### Para saber más

- **Cuentas en EE. UU.** (Consumer Financial Protection Bureau · español): https://www.consumerfinance.gov/es — **Qué buscar:** cómo elegir una cuenta y qué comisiones revisar antes de abrirla.
- **Cuentas en Canadá** (Agencia del Consumidor en Materia Financiera de Canadá · inglés y francés): https://www.canada.ca/en/financial-consumer-agency.html — **Qué buscar:** las cuentas básicas de bajo costo y qué documentos piden.

### Palabras clave

- *Depósito directo:* el pago llega a tu cuenta o tarjeta.
- *Tarjeta de nómina:* tarjeta donde te pagan.
- *Comisión:* cobro por un servicio.

### Fuentes

Consumer Financial Protection Bureau; Agencia del Consumidor en Materia Financiera de Canadá; consultados el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Mandar dinero que rinda

## M4 U01. Compara antes de mandar

**Lo que lograrás:** Comparar comisión y tipo de cambio para que llegue más dinero a tu familia, desde Canadá o desde Estados Unidos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Don Efrén manda dinero cada semana con la misma empresa desde hace ocho años. Nunca ha revisado cuántos pesos llegan. En esta lección compararás.

### Lo esencial (5 minutos)

#### Lo que cuesta un envío

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión | Lo que cobran por enviar. | Por envío. |
| Tipo de cambio | Cuántos pesos dan por dólar. | Varía mucho. |

#### Compara los pesos que llegan

Un envío «sin comisión» puede pagar un tipo de cambio más bajo. Lo que importa es cuántos pesos recibe tu familia por la misma cantidad de dólares.



#### Usa el comparador oficial

**Estados Unidos · H-2A:** PROFECO tiene el programa **Quién es Quién en el Envío de Dinero**, que compara empresas desde ciudades de EE. UU. **Canadá · PTAT:** pide a dos o tres opciones (tu banco, empresas de envío) cuántos pesos llegan por la misma cantidad de dólares canadienses y compara. No te recomendamos ninguna: compara tú.



#### Menos envíos, menos comisiones

Si cada envío cobra una comisión fija, mandar cada dos semanas en lugar de cada semana puede ahorrar comisiones, si a la familia le alcanza.



#### Un caso en un minuto

Don Efrén comparó: con otra opción llegaban unos 250 pesos más por envío. En 24 envíos son 6,000 pesos más para su familia.

> **Idea clave:** compara los pesos que llegan con el comparador de PROFECO; menos envíos pueden ahorrar comisiones.



#### Comprueba lo que entendiste

1. ¿Qué dos cosas cuestan en un envío?
*Respuesta:* La comisión y el tipo de cambio.

2. ¿Cómo comparas?
*Respuesta:* Desde EE. UU., con Quién es Quién en el Envío de Dinero de PROFECO; desde Canadá, preguntando cuántos pesos llegan con dos o tres opciones.


#### Para recordar

- Comisión y tipo de cambio.
- Pesos que llegan.
- PROFECO o compara tú.



### Profundiza (5 minutos más)

#### Lo que gana Don Efrén al comparar

- Pesos más por envío: **250**
- Envíos en la temporada: **24**
- Pesos más: **6,000**


#### Directo a la cuenta

Mandar a la cuenta de quien administra en México es más seguro que cobrar en ventanilla y facilita ahorrar una parte.



#### Casos


**Caso 1. Ocho años igual**

Don Efrén nunca ha comparado.
- *¿Qué hace?* Revisa el comparador de PROFECO.


**Caso 2. Sin comisión**

A Juan Carlos le anuncian envíos sin comisión.
- *¿Qué hace?* Revisa también el tipo de cambio y los pesos que llegan.


**Caso 3. Desde Canadá**

Rosaura manda desde Ontario y nunca ha comparado.
- *¿Qué hace?* Pregunta en dos o tres opciones cuántos pesos llegan y compara.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No comparar | Llegan menos pesos | Compara |
| Ver solo la comisión | Tipo de cambio bajo | Pesos que llegan |
| Muchos envíos pequeños | Más comisiones | Agrupa |
| Cobrar en ventanilla | Riesgo | A la cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Juan Carlos y Ramiro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué comparas entre empresas de envío? a) El color del anuncio · b) Los pesos que llegan · c) La música de la tienda
2. Un envío «sin comisión»… a) puede pagar un tipo de cambio más bajo · b) siempre es el mejor, porque no cobra nada · c) no está permitido por la ley
3. Cada envío cobra 8 dólares. ¿Cuánto ahorras al mandar 12 veces en vez de 24? a) Nada · b) 8 dólares, lo mismo que la comisión · c) 96 dólares
**Respuestas:** 1-b: lo que llega. 2-a: revisa el cambio. 3-c: 12 por 8.



#### Ponlo en práctica

Con una empresa llegan 5,300 pesos y con otra 5,520 por el mismo envío. ¿Cuánto más con la segunda?
**Respuesta:** 220 pesos.



#### A tu plan

Compara cuántos pesos llegan: con PROFECO desde EE. UU. o preguntando a dos o tres opciones desde Canadá.



### Para saber más

- **Quién es Quién en el Envío de Dinero** (PROFECO · español): https://qqed.profeco.gob.mx — **Qué buscar:** compara cuánto recibe tu familia con cada empresa, no solo la comisión.

### Palabras clave

- *Comisión:* cobro por enviar.
- *Tipo de cambio:* pesos por dólar.
- *Remesa:* dinero que mandas a tu familia.

### Fuentes

PROFECO, Quién es Quién en el Envío de Dinero; consultado el 5 de octubre de 2026.

---

## M4 U02. El plan para la remesa

**Lo que lograrás:** Acordar con tu familia en qué se usa cada envío. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Al final de cada temporada, Don Efrén pregunta: «¿Y qué hicimos con todo lo que mandé?». Doña Imelda no sabe responder: se fue en mil cosas. En esta lección harán un plan.

### Lo esencial (5 minutos)

#### Cuatro partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo básico | Comida, casa, escuela, salud. | Primero. |
| Deudas | Si quedó alguna para irte. | Hasta liquidar. |
| Ahorro | Para los meses sin temporada. | Módulo 7. |
| Meta | Casa, tierra, negocio. | Módulo 8. |

#### Acuérdenlo juntos

Quien manda trabaja duro allá; quien recibe administra aquí. Acuerden los porcentajes antes de que empiece la temporada y revísenlos cada mes.



#### Los préstamos a otros

Cuando llegan los envíos, otros piden prestado. Una frase ayuda: «Ese dinero ya tiene destino».



#### Un caso en un minuto

Don Efrén y Doña Imelda acordaron: 55% casa, 10% deudas, 20% ahorro y 15% para el cuarto nuevo. Al final de la temporada, el cuarto estaba terminado y tenían ahorro para el invierno.

> **Idea clave:** acuerden en familia cuánto va a lo básico, deudas, ahorro y una meta, y revisen cada mes.



#### Comprueba lo que entendiste

1. ¿Cuáles son las cuatro partes?
*Respuesta:* Lo básico, deudas, ahorro y meta.

2. ¿Qué frase ayuda cuando te piden prestado?
*Respuesta:* «Ese dinero ya tiene destino».


#### Para recordar

- Cuatro partes.
- Acuerdo antes de irte.
- Revisión mensual.



### Profundiza (5 minutos más)

#### Un envío de 8,000

- Casa (55%): **4,400**
- Deudas (10%): **800**
- Ahorro (20%): **1,600**
- Cuarto nuevo (15%): **1,200**
- Total: **8,000**


#### Al final de la temporada

Sumen cuánto se mandó, cuánto se ahorró y cuánto avanzó la meta. Ver el resultado motiva para la siguiente.



#### Casos


**Caso 1. «¿Qué hicimos?»**

La familia no sabe en qué se fue el dinero.
- *¿Qué hacen?* Acuerdan las cuatro partes antes de la temporada.


**Caso 2. Los préstamos**

A Doña Imelda le piden prestado cuando llega el envío.
- *¿Qué hace?* Dice «ese dinero ya tiene destino».


**Caso 3. La deuda del viaje**

Juan Carlos debe 2,000 a su hermano.
- *¿Qué hace?* Destina una parte de cada envío hasta liquidar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin plan | Se va en todo | Cuatro partes |
| Prestar de la remesa | No alcanza | Ya tiene destino |
| No revisar | Desconfianza | Cada mes |
| Olvidar el ahorro | Invierno sin dinero | 20% |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con la familia de Don Efrén y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuáles son las partes del plan? a) Fiestas, regalos y compras grandes · b) Básico, deudas, ahorro y meta · c) Todo a la casa, sin apartar nada
2. Llega un envío de 6,000 y ahorran 20%. ¿Cuánto es? a) 1,200 · b) 600 · c) 2,000
3. ¿Cuándo acuerdan el plan? a) Nunca: se decide sobre la marcha · b) Al final de la temporada, ya de regreso · c) Antes de la temporada
**Respuestas:** 1-b: cuatro partes. 2-a: 20% de 6,000. 3-c: antes.



#### Ponlo en práctica

Mandas 20 envíos de 7,000 y ahorran 20% de cada uno. ¿Cuánto ahorran en la temporada?
**Respuesta:** 28,000 pesos.



#### A tu plan

Acuerden los porcentajes de su plan antes de que te vayas.



### Para saber más

- **Remesas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «remesas».

### Palabras clave

- *Plan:* acuerdo de en qué se usa el dinero.
- *Meta:* algo que quieren lograr.
- *Liquidar:* terminar de pagar una deuda.

### Fuentes

CONDUSEF, uso de remesas; consultado el 5 de octubre de 2026.

---

## M4 U03. Ahorrar allá o mandar a México

**Lo que lograrás:** Decidir dónde guardar el ahorro de la temporada de forma segura. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Ramiro quiere ahorrar para comprar un terreno. Su compañero le dice que lo guarde en efectivo en la vivienda «para traerlo todo junto». En esta lección verás opciones más seguras.

### Lo esencial (5 minutos)

#### Opciones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Efectivo en la vivienda | Riesgo de robo o pérdida. | No. |
| Tu tarjeta o cuenta allá | Más seguro. | Revisa comisiones. |
| Una cuenta tuya en México | Para tu ahorro. | Separada del gasto de la casa. |

#### Separa el ahorro del gasto

Si mandas todo a la cuenta de la casa, el ahorro se mezcla. Una cuenta o apartado tuyo en México para el ahorro ayuda a no tocarlo.



#### Cruzar con mucho efectivo

**Estados Unidos · H-2A:** hay que declarar el efectivo al salir con más de 10,000 dólares. **Canadá · PTAT:** con 10,000 dólares canadienses o más. Además, viajar con mucho efectivo es un riesgo. Mejor mándalo poco a poco.



#### Un caso en un minuto

Ramiro abrió una cuenta a su nombre en México solo para el terreno. Cada dos semanas manda una parte ahí. Al final de la temporada tenía 40,000 pesos guardados.

> **Idea clave:** no guardes la temporada en efectivo; manda tu ahorro poco a poco a una cuenta tuya, separada del gasto.



#### Comprueba lo que entendiste

1. ¿Por qué no guardar todo en efectivo en la vivienda?
*Respuesta:* Por el riesgo de robo o pérdida.

2. ¿Qué se hace si sales con más de 10,000 dólares en efectivo?
*Respuesta:* Declararlo (en Canadá, desde 10,000 dólares canadienses).


#### Para recordar

- Nada en la maleta.
- Cuenta tuya para el ahorro.
- Poco a poco.



### Profundiza (5 minutos más)

#### El ahorro de Ramiro

- Pesos cada dos semanas: **4,000**
- Envíos de ahorro: **10**
- Pesos para el terreno: **40,000**


#### Verifica dónde ahorras

Revisa en el SIPRES de CONDUSEF que la institución esté autorizada. Desconfía de quien promete rendimientos muy altos.



#### Casos


**Caso 1. Todo en la maleta**

A Ramiro le sugieren guardar todo en efectivo.
- *¿Qué hace?* Manda su ahorro poco a poco a una cuenta suya.


**Caso 2. Ahorro mezclado**

Don Efrén manda todo a la cuenta de la casa.
- *¿Qué hace?* Separa el ahorro en otra cuenta o apartado.


**Caso 3. El rendimiento milagro**

A Juan Carlos le ofrecen duplicar su ahorro en seis meses.
- *¿Qué hace?* Desconfía y verifica en CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Efectivo en la vivienda | Robo | Mándalo |
| Mezclar con el gasto | Se gasta | Separa |
| Cruzar con mucho efectivo | Riesgo | Poco a poco |
| Rendimientos milagro | Fraude | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, Don Efrén y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde es más seguro tu ahorro? a) En la maleta, para traerlo de regreso · b) En una cuenta a tu nombre · c) Con un compañero de la vivienda
2. ¿Por qué separar el ahorro del gasto de la casa? a) Para no tocarlo · b) Por moda · c) Para pagar más comisiones
3. Te prometen duplicar tu ahorro en seis meses. ¿Qué haces? a) Inviertes la mitad para probar · b) Inviertes todo para ganar más rápido · c) Desconfías y verificas
**Respuestas:** 1-b: cuenta tuya. 2-a: no tocarlo. 3-c: desconfía.



#### Ponlo en práctica

Mandas 3,500 cada dos semanas a tu ahorro durante 12 envíos. ¿Cuánto juntas?
**Respuesta:** 42,000 pesos.



#### A tu plan

Abre o define una cuenta tuya en México solo para el ahorro de la temporada.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.
- **Declarar dinero al cruzar** (CBP · español): https://www.cbp.gov — **Qué buscar:** «declarar dinero».
- **Declarar dinero en Canadá** (Agencia de Servicios Fronterizos de Canadá · inglés y francés): https://www.cbsa-asfc.gc.ca — **Qué buscar:** «currency reporting».

### Palabras clave

- *Ahorro:* dinero que guardas para después.
- *Apartado:* espacio separado en tu cuenta.
- *Declarar:* avisar a la autoridad.

### Fuentes

CBP y Agencia de Servicios Fronterizos de Canadá, declaración de efectivo de 10,000 dólares o más; CONDUSEF; consultados el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Impuestos y papeles en Canadá y Estados Unidos

## M5 U01. Impuestos en Estados Unidos con visa H-2A

**Lo que lograrás:** Explicar qué impuestos aplican al salario H-2A y cuándo puede corresponderte una declaración. Aplica solo a Estados Unidos (H-2A). Si vas a Canadá, ve la siguiente lección.

**Para empezar:** Juan Carlos ve que en su talón no le quitan Seguro Social y le preocupa que «luego le cobren todo junto». En esta lección verás cómo funcionan los impuestos con la H-2A.

### Lo esencial (5 minutos)

#### Estados Unidos · H-2A: cómo funciona

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sin Seguro Social ni Medicare | El salario H-2A no paga esas cuotas. | Ni tú ni el empleador. |
| Retención voluntaria | El empleador no está obligado a retener impuesto federal. | Solo si lo acuerdan. |
| Declaración | Si ganas arriba de cierto monto, puede corresponderte presentar la 1040-NR. | Revisa tu caso. |

#### Tu número

Para trabajar te pedirán un número de Seguro Social (SSN). Si tarda, el IRS permite pedir un ITIN para trámites de impuestos.



#### Pide orientación sin costo

Pregunta en el consulado por organizaciones que orientan a trabajadores agrícolas. Desconfía de quien cobra un porcentaje por «sacarte un reembolso».



#### Un caso en un minuto

Juan Carlos supo que no le retienen Seguro Social por ser H-2A. Guardó su W-2 y preguntó en una organización recomendada por el consulado si le correspondía declarar.

> **Idea clave:** con la H-2A no pagas Seguro Social y la retención federal es voluntaria; guarda tu W-2 y revisa si te toca declarar.



#### Comprueba lo que entendiste

1. ¿El salario H-2A paga Seguro Social?
*Respuesta:* No.

2. ¿Qué formulario puede corresponderte?
*Respuesta:* La 1040-NR.


#### Para recordar

- Sin Seguro Social.
- Retención voluntaria.
- Guarda tu W-2.



### Profundiza (5 minutos más)

#### Sin Seguro Social no hay pensión allá

Como no cotizas al Seguro Social de EE. UU., la temporada H-2A no te da pensión allá. Por eso importa ahorrar para tu retiro en México (módulo 8).



#### Fechas

La declaración en EE. UU. se presenta normalmente en abril del año siguiente. Pregunta antes de regresar a México.



#### Casos


**Caso 1. «Te van a cobrar todo junto»**

A Juan Carlos le preocupa que no le retengan Seguro Social.
- *¿Qué hace?* Entiende que la H-2A no paga esa cuota y guarda su W-2.


**Caso 2. El preparador del porcentaje**

A Don Efrén le ofrecen «sacarle un reembolso» por 30%.
- *¿Qué hace?* Busca orientación sin costo en organizaciones que recomienda el consulado.


**Caso 3. Sin número**

A Juan Carlos todavía no le llega su número de Seguro Social.
- *¿Qué hace?* Pregunta por el ITIN para sus trámites de impuestos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que te cobrarán el Seguro Social | Te preocupas sin razón | No aplica a H-2A |
| Pagar porcentajes | Pierdes dinero | Orientación sin costo |
| Tirar el W-2 | No puedes declarar | Guárdalo |
| Olvidar el retiro | Sin pensión | Ahorra en México |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos y Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿El salario H-2A paga Seguro Social de EE. UU.? a) Sí, el doble · b) No · c) Solo el primer mes
2. ¿Está obligado el empleador a retener impuesto federal? a) Solo en los meses de invierno · b) Sí, siempre retiene el 30% · c) No, solo si lo acuerdan
3. ¿Qué papel guardas para tus impuestos? a) El W-2 · b) El boleto de avión · c) Nada
**Respuestas:** 1-b: no. 2-c: voluntario. 3-a: W-2.



#### Ponlo en práctica

Escribe por qué la temporada H-2A no te da pensión en EE. UU.
**Respuesta:** Porque el salario H-2A no paga Seguro Social.



#### A tu plan

Guarda tu W-2 y pregunta en el consulado dónde orientarte sin costo.



### Para saber más

- **Trabajadores agrícolas extranjeros** (IRS · inglés): https://www.irs.gov/individuals/international-taxpayers/foreign-agricultural-workers — **Qué buscar:** qué impuestos te retienen con la visa H-2A y cómo declarar.
- **IRS en español** (IRS · español): https://www.irs.gov/es — **Qué buscar:** las guías en español y cómo pedir una copia de tus declaraciones.

### Palabras clave

- *W-2:* forma con tu salario del año.
- *1040-NR:* declaración para no residentes.
- *ITIN:* número de impuestos del IRS.

### Fuentes

IRS, trabajadores agrícolas extranjeros y Publicación 5144; consultados el 5 de octubre de 2026.

---

## M5 U02. Impuestos en Canadá con el PTAT

**Lo que lograrás:** Explicar las deducciones de Canadá y por qué conviene presentar tu declaración de impuestos. Aplica solo a Canadá (PTAT). Si vas a Estados Unidos, ve la lección anterior.

**Para empezar:** Rosaura ve que cada semana le descuentan impuesto, CPP y EI. Nunca ha presentado su declaración en Canadá porque «ya me lo quitaron». Una compañera recibió un reembolso. En esta lección verás por qué.

### Lo esencial (5 minutos)

#### Canadá · PTAT: lo que te descuentan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Impuesto sobre la renta | Federal y de la provincia. | Puede haber reembolso. |
| CPP | Plan de Pensiones de Canadá. | Cuenta para tu retiro. |
| EI | Seguro de Empleo. | Algunos beneficios. |

#### Presenta tu declaración

Aunque te hayan retenido, presentar la declaración anual en Canadá puede darte un **reembolso** y deja en orden tus aportaciones al CPP. Si ganaste menos de 3,500 dólares canadienses en el año, lo que pagaste de CPP se te devuelve al declarar.



#### Tu SIN y tu T4

Necesitas tu número de seguro social canadiense (SIN) y la forma **T4** que te da el empleador con lo que ganaste y te retuvieron. Guárdalos.



#### Un caso en un minuto

Rosaura pidió ayuda en una organización que le recomendó el consulado. Presentó sus dos últimas declaraciones con sus T4 y le regresaron una parte de lo retenido.

> **Idea clave:** en Canadá te descuentan impuesto, CPP y EI. Presenta tu declaración con tu T4 y tu SIN: puede haber reembolso y cuidas tu pensión.



#### Comprueba lo que entendiste

1. ¿Qué tres descuentos hay en Canadá?
*Respuesta:* Impuesto sobre la renta, CPP y EI.

2. ¿Qué papel te da el empleador para declarar?
*Respuesta:* La forma T4.


#### Para recordar

- Impuesto, CPP, EI.
- Presenta tu declaración.
- Guarda tu T4 y tu SIN.



### Profundiza (5 minutos más)

#### Fecha

La declaración de Canadá se presenta normalmente a más tardar el 30 de abril del año siguiente. Pregunta antes de regresar a México cómo hacerla desde allá.



#### Cuidado con los cobros

Hay preparadores que cobran caro o se quedan con tu reembolso. Busca orientación sin costo con el consulado o con organizaciones de apoyo a trabajadores.



#### Casos


**Caso 1. «Ya me lo quitaron»**

Rosaura nunca ha declarado en Canadá.
- *¿Qué hace?* Presenta su declaración con su T4 y su SIN.


**Caso 2. El T4 perdido**

A una compañera de Rosaura se le perdió su T4.
- *¿Qué hace?* Lo pide al empleador antes de regresar.


**Caso 3. El preparador caro**

Le ofrecen a Rosaura hacer su declaración a cambio de la mitad del reembolso.
- *¿Qué hace?* Busca orientación sin costo con el consulado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No declarar | Pierdes reembolsos | Declara |
| Perder el T4 | Difícil declarar | Guárdalo |
| Dar tu reembolso a un preparador | Pierdes dinero | Ayuda sin costo |
| Ignorar el CPP | Pierdes pensión | Cuídalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosaura y una compañera. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es el CPP? a) Una multa por llegar tarde · b) El Plan de Pensiones de Canadá · c) El pago de la renta de la vivienda
2. ¿Por qué presentar tu declaración en Canadá? a) No sirve, ya te retuvieron todo · b) Para pagar más impuesto del que debes · c) Puede darte reembolso y cuida tu pensión
3. ¿Qué forma te da el empleador? a) La T4 · b) La W-2 · c) Ninguna
**Respuestas:** 1-b: pensión. 2-c: reembolso y CPP. 3-a: T4.



#### Ponlo en práctica

Te retuvieron 2,100 dólares canadienses y tu impuesto final es 1,400. ¿Cuánto sería tu reembolso?
**Respuesta:** 700 dólares canadienses.



#### A tu plan

Guarda tu T4 y tu SIN y pregunta en el consulado dónde declarar sin costo.



### Para saber más

- **Impuestos para trabajadores temporales** (Agencia de Ingresos de Canadá · inglés y francés): https://www.canada.ca/en/revenue-agency.html — **Qué buscar:** «seasonal agricultural workers».
- **Consulados de México en Canadá** (SRE · español): https://consulmex.sre.gob.mx — **Qué buscar:** el consulado de tu provincia y su teléfono de protección.

### Palabras clave

- *T4:* forma con tu salario y retenciones en Canadá.
- *SIN:* número de seguro social de Canadá.
- *Reembolso:* lo que te regresan si pagaste de más.

### Fuentes

Gobierno de Canadá, deducciones de nómina y declaración de impuestos; consulados de México en Canadá; consultados el 5 de octubre de 2026.

---

## M5 U03. Tu carpeta de papeles

**Lo que lograrás:** Guardar en una carpeta los papeles de cada temporada para impuestos, pensión y reclamos. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Don Efrén tiene ocho temporadas, pero solo guarda los papeles de las dos últimas. Rosaura tiene sus T4 en tres lugares distintos. En esta lección armarán su carpeta.

### Lo esencial (5 minutos)

#### Lo que va en la carpeta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Contratos | De cada temporada. | Con fechas. |
| Talones de pago | Y tu libreta. | Prueba de lo trabajado. |
| Formas de impuestos | W-2 (EE. UU.) o T4 (Canadá). | Una por año. |
| Números | EE. UU.: SSN o ITIN. Canadá: SIN. | En lugar seguro. |

#### Copia en el celular y en casa

Toma foto de cada papel y mándala a tu familia en México o a tu correo. Los originales, en una carpeta en casa.



#### Tus números son delicados

No compartas tu SSN, ITIN o SIN con quien no lo necesite. Con ellos pueden usar tu identidad.



#### Un caso en un minuto

Rosaura juntó sus T4 de seis años en una carpeta y les tomó foto. Así pudo pedir que revisaran sus aportaciones al CPP.

> **Idea clave:** guarda contratos, talones y formas de impuestos de cada temporada en una carpeta, con copia en tu correo.



#### Comprueba lo que entendiste

1. ¿Qué formas de impuestos guardas?
*Respuesta:* La W-2 de EE. UU. o la T4 de Canadá, una por año.

2. ¿Dónde guardas las copias?
*Respuesta:* En mi correo o con mi familia en México.


#### Para recordar

- Una carpeta.
- Copia en tu correo.
- Números protegidos.



### Profundiza (5 minutos más)

#### Mi carpeta por temporada

| Año | País | Contrato | Talones | W-2 o T4 |
|---|---|---|---|---|
| | | | | |
| | | | | |



#### Las temporadas viejas también cuentan

Para tu pensión de Canadá (CPP) y para cualquier reclamo, los papeles de años anteriores sirven. Si te faltan, pídelos al empleador o a la autoridad de impuestos.



#### Casos


**Caso 1. Ocho temporadas**

Don Efrén solo tiene papeles de dos temporadas.
- *¿Qué hace?* Arma su carpeta y pide los que le faltan.


**Caso 2. T4 regados**

Rosaura tiene sus T4 en tres lugares.
- *¿Qué hace?* Los junta en una carpeta y les toma foto.


**Caso 3. El número**

Un compañero le pide a Juan Carlos su número de Seguro Social «para un trámite».
- *¿Qué hace?* No se lo da.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No guardar papeles | Pierdes reembolsos y pensión | Carpeta |
| Sin copias | Se pierden | Fotos |
| Compartir tus números | Robo de identidad | Protégelos |
| Olvidar años viejos | Huecos | Pídelos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Rosaura y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué va en tu carpeta? a) Contratos, talones y W-2 o T4 · b) Solo fotos de la cosecha y del grupo · c) Nada
2. ¿Dónde guardas copias? a) Con el reclutador que te contrató · b) Solo en la maleta, todos juntos · c) En tu correo o con tu familia
3. Te piden tu número de Seguro Social para «un trámite». ¿Qué haces? a) Lo das para no quedar mal · b) No lo das si no es necesario · c) Le mandas una foto de tu tarjeta
**Respuestas:** 1-a: los tres. 2-c: respaldo. 3-b: protégelo.



#### Ponlo en práctica

Tienes 6 temporadas en Canadá. ¿Cuántas T4 deberías tener?
**Respuesta:** 6, una por año.



#### A tu plan

Arma tu carpeta y llena la tabla con las temporadas que tienes.



### Para saber más

- **Robo de identidad** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «robo de identidad».

### Palabras clave

- *Carpeta:* lugar donde guardas tus papeles.
- *Copia:* foto o duplicado de un papel.
- *Identidad:* tus datos personales.

### Fuentes

IRS; Agencia de Ingresos de Canadá; consultados el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Tus derechos y tu seguridad

## M6 U01. Tus derechos básicos allá

**Lo que lograrás:** Identificar los derechos básicos de las personas trabajadoras agrícolas temporales en Canadá y en Estados Unidos. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** A un compañero de Juan Carlos el encargado le pidió su pasaporte «para guardarlo». A una compañera de Rosaura le dijeron que si se quejaba no la volverían a pedir. En esta lección verás qué no es legal.

### Lo esencial (5 minutos)

#### En los dos países

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu pasaporte es tuyo | Nadie puede quedárselo. | Ni «para cuidarlo». |
| Pago completo y a tiempo | Con talón. | Según tu contrato. |
| Vivienda digna | Segura, limpia, con agua. | Revisada. |
| Sin represalias | Por quejarte o pedir ayuda. | Es tu derecho. |

#### Herramientas y equipo

Las herramientas y el equipo de protección que pide el trabajo debe darlos el empleador, en los dos programas.



#### Trato digno

Nadie puede amenazarte, golpearte, acosarte ni encerrarte. Si pasa, pide ayuda (U03).



#### Un caso en un minuto

El compañero de Juan Carlos no entregó su pasaporte. La compañera de Rosaura habló con el enlace del consulado sobre la amenaza; el consulado dio seguimiento.

> **Idea clave:** tu pasaporte es tuyo, te deben pagar completo y a tiempo, con vivienda digna, y no pueden castigarte por pedir ayuda.



#### Comprueba lo que entendiste

1. ¿Puede el empleador quedarse con tu pasaporte?
*Respuesta:* No.

2. ¿Te pueden castigar por quejarte?
*Respuesta:* No; es tu derecho pedir ayuda.


#### Para recordar

- Pasaporte contigo.
- Pago completo.
- Sin represalias.



### Profundiza (5 minutos más)

#### Revisión de mi vivienda

| Revisar | Bien | Mal |
|---|---|---|
| Agua potable | | |
| Baños y regaderas | | |
| Camas y espacio | | |
| Cocina o comida | | |
| Seguridad (gas, electricidad) | | |



#### Guarda pruebas

Si algo no está bien en la vivienda o en el trato, toma fotos y anota fechas. Te sirven para reclamar.



#### Casos


**Caso 1. El pasaporte**

Le piden el pasaporte a un compañero de Juan Carlos.
- *¿Qué hace?* No lo entrega.


**Caso 2. «No te vuelven a pedir»**

Amenazan a una compañera de Rosaura si se queja.
- *¿Qué hace?* Habla con el enlace del consulado.


**Caso 3. Sin agua**

En la vivienda de Don Efrén falla el agua potable una semana.
- *¿Qué hace?* Toma fotos, anota fechas y reclama.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Entregar el pasaporte | Pierdes control | Contigo |
| Callar por miedo | Sigue el abuso | Pide ayuda |
| No guardar pruebas | Difícil reclamar | Fotos |
| Pagar tu equipo | No te toca | Lo da el empleador |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Rosaura y Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Quién guarda tu pasaporte? a) El encargado · b) Tú · c) El reclutador
2. Te amenazan si te quejas. ¿Qué es? a) Una represalia que no está permitida · b) Normal en los campos de cultivo · c) Parte de lo que firmaste en el contrato
3. ¿Quién da el equipo de protección? a) Tú lo compras · b) Tus compañeros · c) El empleador
**Respuestas:** 1-b: tú. 2-a: represalia. 3-c: el empleador.



#### Ponlo en práctica

Escribe dos derechos que tienes en los dos países.
**Respuesta:** Por ejemplo: guardar mi pasaporte y recibir mi pago completo y a tiempo.



#### A tu plan

Revisa tu vivienda con la tabla y guarda tu pasaporte contigo.



### Para saber más

- **Protecciones H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** tus derechos de pago, vivienda, transporte y cómo reportar abusos.
- **Derechos de trabajadores temporales en Canadá** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** «Trabajadores extranjeros temporales: sus derechos están protegidos».

### Palabras clave

- *Represalia:* castigo por quejarte.
- *Vivienda digna:* lugar seguro y limpio para vivir.
- *Equipo de protección:* guantes, botas y lo que pida el trabajo.

### Fuentes

DOL; Gobierno de Canadá, derechos de trabajadores extranjeros temporales; consultados el 5 de octubre de 2026.

---

## M6 U02. Si te lastimas o te enfermas

**Lo que lograrás:** Decidir qué hacer si te lastimas o te enfermas trabajando, y qué seguros te cubren. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Juan Carlos se cortó la mano con una herramienta. Le dijeron que «se aguantara para no perder el día». Rosaura tuvo fiebre fuerte y no sabía si podía ir al médico. En esta lección verás qué hacer.

### Lo esencial (5 minutos)

#### Qué te cubre

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Estados Unidos · H-2A | El empleador debe tener seguro de accidentes de trabajo (workers' compensation). | Atención y pago si no puedes trabajar. |
| Canadá · PTAT | Seguro de accidentes de trabajo de la provincia y cobertura de salud según tu contrato. | Pregunta tu tarjeta o póliza. |

#### Primero tu salud

Avisa al encargado y pide atención médica. Un accidente de trabajo se tiene que reportar; no te lo pueden negar.



#### Deja registro

Anota fecha, hora y cómo pasó. Pide copia del reporte del accidente y guarda las recetas y comprobantes médicos.



#### Un caso en un minuto

Juan Carlos pidió atención y que reportaran el accidente. Le cubrió el seguro de trabajo y le pagaron los días que no pudo trabajar. Rosaura usó la cobertura de salud de su contrato.

> **Idea clave:** si te lastimas, primero tu salud y reporta el accidente; el seguro de accidentes de trabajo te cubre en los dos países.



#### Comprueba lo que entendiste

1. ¿Qué seguro cubre accidentes de trabajo H-2A?
*Respuesta:* El de accidentes de trabajo (workers' compensation) del empleador.

2. ¿Qué haces después de un accidente?
*Respuesta:* Aviso, pido atención y que se reporte, y guardo el registro.


#### Para recordar

- Salud primero.
- Reporta el accidente.
- Guarda comprobantes.



### Profundiza (5 minutos más)

#### Mi ficha de salud

| Dato | Lo tengo |
|---|---|
| Tarjeta o póliza de salud | |
| Teléfono del encargado | |
| Clínica más cercana | |
| Teléfono del consulado | |



#### No te pueden presionar

Nadie puede presionarte para no reportar un accidente ni para trabajar lastimado.



#### Casos


**Caso 1. «Aguántate»**

Le dicen a Juan Carlos que se aguante la cortada.
- *¿Qué hace?* Pide atención y que se reporte el accidente.


**Caso 2. La fiebre**

Rosaura tiene fiebre fuerte en Ontario.
- *¿Qué hace?* Usa la cobertura de salud de su contrato y avisa al encargado.


**Caso 3. Sin papeles del accidente**

A Don Efrén no le dieron copia del reporte.
- *¿Qué hace?* La pide y guarda sus comprobantes médicos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aguantarte | Empeora | Atiéndete |
| No reportar | Sin cobertura | Reporta |
| No guardar comprobantes | Difícil reclamar | Guárdalos |
| Ceder a presiones | Pierdes derechos | Pide ayuda |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Rosaura y Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te lastimas trabajando. ¿Qué haces primero? a) Te aguantas para no perder el día · b) Pides atención y que se reporte · c) Te vas a México a curarte allá
2. ¿Te pueden presionar para no reportar un accidente? a) Sí · b) No · c) Solo si es leve
3. ¿Qué guardas? a) Solo la venda y la medicina · b) Nada, ya te atendieron · c) Reporte, recetas y comprobantes
**Respuestas:** 1-b: atención y reporte. 2-b: no. 3-c: comprobantes.



#### Ponlo en práctica

Escribe los cuatro datos de tu ficha de salud.
**Respuesta:** Tarjeta o póliza, teléfono del encargado, clínica más cercana y teléfono del consulado.



#### A tu plan

Llena tu ficha de salud al llegar.



### Para saber más

- **Protecciones H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** tus derechos de pago, vivienda, transporte y cómo reportar abusos.
- **Contrato PTAT 2026** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** «Contrato de trabajo para trabajadores agrícolas temporales mexicanos».

### Palabras clave

- *Workers' compensation:* seguro de accidentes de trabajo en EE. UU.
- *Reporte de accidente:* registro oficial de lo que pasó.
- *Cobertura de salud:* seguro que paga tu atención médica.

### Fuentes

DOL; Gobierno de Canadá, contrato SAWP-México 2026; consultados el 5 de octubre de 2026.

---

## M6 U03. A quién llamar

**Lo que lograrás:** Tener a la mano a quién llamar en Canadá y en Estados Unidos si tienes un problema. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Ramiro, en su primera temporada, tuvo un problema con su pago y no sabía a quién llamar. Pasaron semanas. En esta lección tendrás tu lista.

### Lo esencial (5 minutos)

#### En los dos países

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Consulado de México | Protección y, en Canadá, enlaces del PTAT. | Tu primer apoyo. |
| Emergencias | 911 en los dos países. | Si hay peligro. |
| Trata y trabajo forzoso | EE. UU.: 1-888-373-7888. | Confidencial. |

#### Estados Unidos · H-2A

Por pago y condiciones: División de Horas y Salarios, 1-866-487-9243. Por fraude de reclutadores: la Secretaría del Trabajo en México y el consulado.



#### Canadá · PTAT

El consulado de México tiene personal de enlace del PTAT. El Gobierno de Canadá también recibe reportes de abuso a trabajadores temporales (busca «sus derechos están protegidos» en canada.ca).



#### Un caso en un minuto

Ramiro llamó al consulado. Le ayudaron a reclamar su pago con su libreta y sus talones. Ahora lleva la lista en su cartera.

> **Idea clave:** el consulado de México es tu primer apoyo en los dos países; ten a la mano la lista de teléfonos.



#### Comprueba lo que entendiste

1. ¿Cuál es tu primer apoyo en Canadá y en EE. UU.?
*Respuesta:* El consulado de México.

2. ¿A qué número llamas por problemas de pago en EE. UU.?
*Respuesta:* A la División de Horas y Salarios, 1-866-487-9243.


#### Para recordar

- Consulado primero.
- 911 si hay peligro.
- Lista en la cartera.



### Profundiza (5 minutos más)

#### Mi lista de ayuda

| A quién | Teléfono |
|---|---|
| Consulado de México más cercano | |
| Enlace PTAT (Canadá) | |
| División de Horas y Salarios (EE. UU.) | 1-866-487-9243 |
| Línea contra la trata (EE. UU.) | 1-888-373-7888 |
| Emergencias | 911 |
| Mi familia | |



#### No estás solo

Pedir ayuda no te quita futuras temporadas por sí mismo. Las represalias están prohibidas.



#### Casos


**Caso 1. El pago**

Ramiro tiene un problema con su pago.
- *¿Qué hace?* Llama al consulado con su libreta y talones.


**Caso 2. Encerrados**

A un grupo no lo dejan salir de la vivienda en EE. UU.
- *¿Qué hacen?* Llaman al 911 o a la línea contra la trata.


**Caso 3. En Ontario**

Rosaura tiene un problema con su vivienda.
- *¿Qué hace?* Habla con el enlace del PTAT en el consulado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber a quién llamar | Pierdes semanas | Lista |
| Esperar | Se complica | Llama pronto |
| Callar | Sigue | Pide ayuda |
| Lista solo en el celular | Sin batería | En papel |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Ramiro, un grupo y Rosaura. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es tu primer apoyo en el extranjero? a) El reclutador que te contrató · b) El consulado de México · c) Nadie, lo resuelves tú solo
2. No los dejan salir de la vivienda. ¿Qué hacen? a) Esperan a que termine la temporada · b) Llaman al 911 o a la línea contra la trata · c) Se callan para no perder el trabajo
3. En Canadá, ¿quién apoya a trabajadores del PTAT? a) Nadie, lo resuelves tú solo · b) El vendedor de tarjetas telefónicas · c) El enlace del PTAT en el consulado
**Respuestas:** 1-b: consulado. 2-b: emergencia. 3-c: enlace.



#### Ponlo en práctica

Escribe el número de emergencias en Canadá y en Estados Unidos.
**Respuesta:** 911 en los dos.



#### A tu plan

Llena tu lista de ayuda y guárdala en papel en tu cartera.



### Para saber más

- **Consulados de México** (SRE · español): https://consulmex.sre.gob.mx — **Qué buscar:** el consulado más cercano y su teléfono de protección.
- **Línea contra la trata en EE. UU.:** 1-888-373-7888.
- **División de Horas y Salarios** (DOL · español): 1-866-487-9243.

### Palabras clave

- *Consulado:* oficina de México en otro país.
- *Trata:* obligar a alguien a trabajar con engaños o amenazas.
- *Enlace:* persona que te atiende y da seguimiento.

### Fuentes

SRE; DOL; Línea Nacional contra la Trata de Personas de EE. UU.; Gobierno de Canadá; consultados el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. El regreso y los meses sin temporada

## M7 U01. El regreso

**Lo que lograrás:** Prepararte para el regreso: transporte pagado, papeles y dinero en orden. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Don Efrén terminó antes su contrato por un problema familiar y no sabía si le pagarían el regreso. Rosaura siempre deja todo para el último día y olvida pedir papeles. En esta lección prepararás tu regreso.

### Lo esencial (5 minutos)

#### Lo que revisas antes de regresar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transporte de regreso | EE. UU. · H-2A: lo paga el empleador si terminas el contrato. Canadá · PTAT: lo paga el empleador, con el descuento permitido. | Pregunta. |
| Papeles | W-2 o T4, último talón. | En tu carpeta. |
| Último pago | Completo. | Revisa el talón. |
| Tu cuenta allá | Qué haces con ella. | Cerrar o dejarla. |

#### Las fechas

**Canadá · PTAT:** el regreso es a más tardar el 15 de diciembre. **Estados Unidos · H-2A:** al terminar tu contrato. Si terminas antes, pregunta qué pasa con tu regreso y tus pagos.



#### Lista de salida

Una semana antes, revisa la lista: papeles, último pago, cuenta y lo que llevarás. No esperes al último día.



#### Un caso en un minuto

Rosaura hizo su lista de salida una semana antes. Pidió su T4 y su último talón, y dejó su cuenta abierta para la siguiente temporada.

> **Idea clave:** una semana antes del regreso revisa transporte, papeles, último pago y tu cuenta.



#### Comprueba lo que entendiste

1. ¿Hasta cuándo es el regreso en el PTAT?
*Respuesta:* A más tardar el 15 de diciembre.

2. ¿Cuándo haces tu lista de salida?
*Respuesta:* Una semana antes.


#### Para recordar

- Transporte de regreso.
- Papeles y último pago.
- Una semana antes.



### Profundiza (5 minutos más)

#### Mi lista de salida

| Pendiente | Hecho |
|---|---|
| Fecha y transporte de regreso | |
| W-2 o T4 (o cómo me lo mandan) | |
| Último talón revisado | |
| Cuenta allá: la dejo o la cierro | |
| Efectivo: mandado a casa | |



#### Si el papel de impuestos llega después

La W-2 y la T4 a veces se entregan al inicio del año siguiente. Deja tu dirección de México o un correo para que te las manden.



#### Casos


**Caso 1. Contrato terminado antes**

Don Efrén se regresa antes por su familia.
- *¿Qué hace?* Pregunta qué pasa con su regreso y sus pagos antes de irse.


**Caso 2. El último día**

Rosaura suele dejar todo para el final.
- *¿Qué hace?* Hace su lista una semana antes.


**Caso 3. La W-2 tardía**

La W-2 de Juan Carlos llega hasta enero.
- *¿Qué hace?* Deja su dirección de México y su correo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar todo al final | Olvidas papeles | Una semana antes |
| No revisar el último pago | Te pagan menos | Revísalo |
| Regresar con mucho efectivo | Riesgo | Mándalo |
| No dejar dirección | No te llega tu forma | Déjala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Rosaura y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Hasta cuándo es el regreso en el PTAT? a) Al 15 de diciembre · b) En marzo del año siguiente · c) Cuando tú lo decidas, sin fecha fija
2. ¿Cuándo haces tu lista de salida? a) En México, cuando ya regresaste · b) El último día, antes de subirte · c) Una semana antes
3. Tu forma de impuestos llega después. ¿Qué haces? a) Dejas tu dirección de México y tu correo · b) Nada, ese año ya no declaras · c) Te quedas allá a esperarla
**Respuestas:** 1-a: 15 de diciembre. 2-c: antes. 3-a: deja tus datos.



#### Ponlo en práctica

Escribe tres pendientes de tu lista de salida.
**Respuesta:** Por ejemplo: transporte de regreso, último talón y W-2 o T4.



#### A tu plan

Llena tu lista de salida una semana antes de regresar.



### Para saber más

- **Contrato PTAT 2026** (Gobierno de Canadá · español): https://www.canada.ca — **Qué buscar:** tu contrato de la temporada: salario, horas, descuentos y vivienda.
- **Protecciones H-2A** (DOL · español): https://www.dol.gov/agencies/whd/agriculture/h2a — **Qué buscar:** tus derechos de pago, vivienda, transporte y cómo reportar abusos.

### Palabras clave

- *Lista de salida:* pendientes antes de regresar.
- *Último talón:* el detalle de tu último pago.
- *Regreso:* viaje de vuelta a México.

### Fuentes

Gobierno de Canadá, contrato SAWP-México 2026; DOL; consultados el 5 de octubre de 2026.

---

## M7 U02. Los meses sin temporada

**Lo que lograrás:** Hacer que el dinero de la temporada alcance para los meses en México hasta la siguiente. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Don Efrén regresa en noviembre con buen ahorro. En marzo ya no queda nada y faltan dos meses para irse otra vez. Cada año pide prestado. En esta lección repartirá su ahorro.

### Lo esencial (5 minutos)

#### Cuenta los meses

Cuenta cuántos meses estarás en México hasta la siguiente temporada. Ese es el tiempo que debe durar tu ahorro, más lo que ganes aquí.



#### Tu plan de meses sin temporada

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gasto mensual | Lo que necesita la casa. | Con cifras. |
| Lo que entra aquí | Trabajos, cosecha, ventas. | Solo lo seguro. |
| Lo que falta | Sale del ahorro. | Mes por mes. |

#### Divide el ahorro

Divide el ahorro entre los meses. Esa cantidad es tu «sueldo» de cada mes. No lo gastes todo en diciembre.



#### Un caso en un minuto

Don Efrén tiene 6 meses en México. Le faltan 4,000 al mes después de lo que gana aquí: necesita 24,000. Tenía 30,000; los 6,000 restantes los guardó para su meta.

> **Idea clave:** cuenta los meses hasta la siguiente temporada, calcula lo que falta cada mes y divide tu ahorro.



#### Comprueba lo que entendiste

1. ¿Qué cuentas primero?
*Respuesta:* Cuántos meses estaré en México hasta la siguiente temporada.

2. ¿Cómo sabes cuánto usar cada mes?
*Respuesta:* Divido el ahorro entre esos meses.


#### Para recordar

- Cuenta los meses.
- Lo que falta por mes.
- No todo en diciembre.



### Profundiza (5 minutos más)

#### Los meses de Don Efrén

- Lo que falta cada mes: **4,000**
- Meses en México: **6**
- Lo que debe durar del ahorro: **24,000**


#### Diciembre

Las fiestas llegan justo al regresar. Pon un tope para diciembre antes de llegar.



#### Casos


**Caso 1. Marzo sin dinero**

A Don Efrén se le acaba el ahorro en marzo.
- *¿Qué hace?* Divide su ahorro entre los meses hasta la siguiente temporada.


**Caso 2. Diciembre**

Juan Carlos quiere gastar mucho en las fiestas.
- *¿Qué hace?* Pone un tope antes de llegar.


**Caso 3. Trabajo aquí**

Rosaura puede vender comida en el pueblo.
- *¿Qué hace?* Lo cuenta como ingreso para que el ahorro dure más.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No contar los meses | Se acaba antes | Cuenta |
| Gastar en diciembre | Marzo sin dinero | Tope |
| Pedir prestado al final | Deudas | Divide el ahorro |
| No buscar ingreso aquí | El ahorro no alcanza | Trabajo local |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Juan Carlos y Rosaura. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Tienes 18,000 de ahorro y 6 meses. ¿Cuánto puedes usar al mes? a) 3,000 · b) 18,000 · c) 6,000
2. ¿Qué haces con diciembre? a) Gastas todo · b) Pides prestado · c) Pones un tope
3. ¿Qué haces con lo que ganas en México? a) Lo cuentas para que el ahorro dure más · b) No lo cuentas porque es poco · c) Lo gastas en las fiestas
**Respuestas:** 1-a: 18,000 entre 6. 2-c: tope. 3-a: súmalo.



#### Ponlo en práctica

Te faltan 3,500 al mes y estarás 5 meses. ¿Cuánto debe durar tu ahorro?
**Respuesta:** 17,500 pesos.



#### A tu plan

Haz tu plan de meses sin temporada antes de regresar.



### Para saber más

- **Presupuesto con ingreso variable** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ingresos variables».

### Palabras clave

- *Meses sin temporada:* tiempo en México entre una temporada y otra.
- *Tope:* lo máximo que vas a gastar.
- *Sueldo mensual:* lo que te das cada mes del ahorro.

### Fuentes

CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.

---

## M7 U03. ¿Otra temporada?

**Lo que lograrás:** Decidir con números si te conviene volver la siguiente temporada. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Juan Carlos regresó y no sabe si volver. Su papá dice que «allá se gana más». Su esposa dice que los niños lo extrañan. En esta lección hará la cuenta completa.

### Lo esencial (5 minutos)

#### La cuenta completa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo que ganas allá | Horas por salario. | Menos descuentos y gastos. |
| Lo que gastas allá | Comida, teléfono, envíos. | Lo tuyo. |
| Lo que ganarías aquí | En esos meses. | Si te quedas. |
| Lo que no se cuenta en pesos | Familia, salud, cansancio. | También pesa. |

#### Compara

Lo que te queda neto de la temporada, menos lo que ganarías aquí, es lo que de verdad te deja irte. Con ese número y lo que no se mide en pesos, decide.



#### Con una meta

Si vuelves, que sea con una meta clara (módulo 8): un cuarto, una tierra, un negocio. Así cada temporada te acerca a algo.



#### Un caso en un minuto

Juan Carlos hizo la cuenta: la temporada le deja unos 90,000 pesos netos; aquí ganaría 40,000 en esos meses. Decidió volver dos temporadas más con la meta de terminar su casa.

> **Idea clave:** compara lo que te deja de verdad la temporada con lo que ganarías aquí, y vuelve solo con una meta clara.



#### Comprueba lo que entendiste

1. ¿Qué restas para saber lo que de verdad te deja irte?
*Respuesta:* Lo que ganaría aquí en esos meses.

2. ¿Qué no se mide en pesos?
*Respuesta:* La familia, la salud y el cansancio.


#### Para recordar

- Neto de la temporada.
- Menos lo que ganarías aquí.
- Vuelve con una meta.



### Profundiza (5 minutos más)

#### La cuenta de Juan Carlos

- Lo que le deja la temporada (neto): **90,000**
- Lo que ganaría aquí: **40,000**
- Lo que de verdad le deja irse: **50,000**


#### Decídanlo en familia

La familia que se queda también vive la temporada. Platiquen la decisión con los números en la mesa.



#### Casos


**Caso 1. «Allá se gana más»**

El papá de Juan Carlos dice que siempre conviene ir.
- *¿Qué hace?* Hace la cuenta completa.


**Caso 2. Sin meta**

Ramiro vuelve cada año sin saber para qué.
- *¿Qué hace?* Define una meta antes de la siguiente temporada.


**Caso 3. La familia**

La esposa de Juan Carlos quiere opinar.
- *¿Qué hacen?* Deciden juntos con los números.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decidir sin números | Te equivocas | Cuenta completa |
| Olvidar lo que ganarías aquí | Inflas la ganancia | Réstalo |
| Ir sin meta | No avanzas | Meta clara |
| Decidir solo | Conflictos | En familia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Juan Carlos, Ramiro y su familia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. La temporada te deja 80,000 netos y aquí ganarías 35,000. ¿Cuánto te deja de verdad irte? a) 45,000 · b) 80,000 · c) 115,000
2. ¿Con qué conviene volver? a) Con deudas nuevas para el viaje · b) Sin plan, como cada año · c) Con una meta clara
3. ¿Quién decide? a) Tú solo, porque trabajas allá · b) Tu familia y tú, con números · c) El reclutador que te contrata
**Respuestas:** 1-a: 80,000 menos 35,000. 2-c: meta. 3-b: en familia.



#### Ponlo en práctica

Ganas 120,000 netos allá y gastarías 20,000 allá en lo tuyo. Aquí ganarías 50,000. ¿Cuánto te deja de verdad?
**Respuesta:** 50,000 pesos (120,000 menos 20,000 menos 50,000).



#### A tu plan

Hagan en familia la cuenta completa antes de decidir la siguiente temporada.



### Para saber más

- **Planeación financiera** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «metas financieras».

### Palabras clave

- *Neto:* lo que queda después de gastos y descuentos.
- *Costo de oportunidad:* lo que dejas de ganar al elegir otra cosa.
- *Meta:* lo que quieres lograr.

### Fuentes

Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Tu retiro y tu futuro en México

## M8 U01. Tu retiro: Canadá, Estados Unidos y México

**Lo que lograrás:** Identificar qué cuenta para tu retiro según el país donde trabajas y cómo completarlo en México. Aplica a Canadá (PTAT) y a Estados Unidos (H-2A); lo que cambia está marcado por país.

**Para empezar:** Rosaura lleva seis temporadas en Canadá y Don Efrén ocho en Estados Unidos. Los dos creen que «eso no cuenta para nada en la vejez». En esta lección verán que para Rosaura sí cuenta, y qué puede hacer Don Efrén.

### Lo esencial (5 minutos)

#### Qué cuenta en cada país

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Canadá · PTAT | Cotizas al Plan de Pensiones de Canadá (CPP). | Con el convenio México-Canadá se pueden sumar periodos. |
| Estados Unidos · H-2A | No cotizas al Seguro Social. | La temporada no da pensión allá. |
| En los dos países: México | Afore y semanas del IMSS. | Aportaciones voluntarias. |

#### Canadá · PTAT: el convenio México-Canadá

Desde 1996, un convenio de seguridad social permite sumar los periodos cotizados en México y en Canadá para tener derecho a una pensión. Guarda tus T4 (módulo 5) y pregunta en el consulado o en el IMSS cuando te acerques a la edad.



#### En los dos países: aporta en México

Con tu CURP puedes localizar o abrir tu Afore y hacer aportaciones voluntarias desde 50 pesos. Las temporadas son buen momento para aportar.



#### Un caso en un minuto

Rosaura guardó sus T4: sus años de CPP podrán sumar. Don Efrén abrió su Afore y aporta 500 pesos de cada mes de temporada.

> **Idea clave:** en Canadá cotizas al CPP y se puede sumar con México. Con la H-2A no cotizas allá, así que aporta a tu Afore.



#### Comprueba lo que entendiste

1. ¿Con la H-2A cotizas al Seguro Social de EE. UU.?
*Respuesta:* No.

2. ¿Qué permite el convenio México-Canadá?
*Respuesta:* Sumar periodos cotizados en ambos países para una pensión.


#### Para recordar

- Canadá: CPP y convenio.
- EE. UU.: sin Seguro Social.
- México: Afore.



### Profundiza (5 minutos más)

#### La aportación de Don Efrén

- Pesos al mes de temporada: **500**
- Meses de temporada: **7**
- Al año: **3,500**
- Años: **15**
- Aportado, sin contar lo que genere: **52,500**


#### Tus beneficiarios

Revisa los beneficiarios de tu Afore y de tus cuentas. Si faltas, que tu familia pueda cobrar sin trámites largos.



#### Casos


**Caso 1. «No cuenta para nada»**

Rosaura cree que sus temporadas no cuentan.
- *¿Qué hace?* Guarda sus T4 y pregunta por el convenio México-Canadá.


**Caso 2. Sin pensión allá**

Don Efrén no cotiza al Seguro Social de EE. UU.
- *¿Qué hace?* Aporta a su Afore cada mes de temporada.


**Caso 3. Afore desconocida**

Juan Carlos no sabe si tiene Afore.
- *¿Qué hace?* La busca con su CURP en AforeMóvil.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no cuenta | Pierdes derechos | Revisa |
| Perder los T4 | No pruebas tus años | Guárdalos |
| No aportar en México | Sin retiro | Aportación voluntaria |
| Beneficiarios viejos | Problemas | Actualízalos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosaura, Don Efrén y Juan Carlos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es el CPP? a) Una multa por faltar al trabajo · b) El Plan de Pensiones de Canadá · c) Un seguro de auto obligatorio
2. ¿Te da pensión en EE. UU. la temporada H-2A? a) Sí, después de la primera temporada · b) No, porque no cotizas al Seguro Social · c) Solo después de 10 temporadas
3. ¿Desde cuánto puedes aportar a tu Afore? a) No se puede · b) 5,000 pesos · c) 50 pesos
**Respuestas:** 1-b: CPP. 2-b: no cotizas. 3-c: desde 50.



#### Ponlo en práctica

Aportas 400 pesos cada mes de una temporada de 8 meses. ¿Cuánto al año?
**Respuesta:** 3,200 pesos.



#### A tu plan

Localiza tu Afore, decide cuánto aportarás cada mes de temporada y guarda tus T4 si vas a Canadá.



### Para saber más

- **AforeMóvil** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** cómo descargar la app, ver tu Afore y hacer aportaciones voluntarias.
- **Convenio de seguridad social México-Canadá** (Gobierno de Canadá · inglés y francés): https://www.canada.ca — **Qué buscar:** «Agreement on Social Security Mexico».

### Palabras clave

- *CPP:* Plan de Pensiones de Canadá.
- *Convenio de seguridad social:* acuerdo para sumar periodos cotizados entre países.
- *Aportación voluntaria:* lo que tú agregas a tu Afore.

### Fuentes

Convenio sobre Seguridad Social entre México y Canadá (DOF, 1998); IRS; CONSAR; consultados el 5 de octubre de 2026.

---

## M8 U02. Un proyecto que produce

**Lo que lograrás:** Convertir el ahorro de las temporadas en un proyecto que genere ingreso en México. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Don Efrén lleva ocho temporadas y su casa quedó bonita. Pero si un año no lo contratan, no tiene de qué vivir. En esta lección pensará en un proyecto que produzca.

### Lo esencial (5 minutos)

#### Tipos de meta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Que da comodidad | Casa, muebles. | Importante, no produce. |
| Que produce | Tierra, animales, invernadero, negocio. | Genera ingreso. |
| Que abre puertas | Estudios de los hijos, certificación. | A largo plazo. |

#### Prueba en pequeño

Antes de meter todo el ahorro, prueba el proyecto en pequeño: una parcela chica, pocos animales, ventas por encargo. Lo que aprendiste en el campo allá es experiencia.



#### La meta en números

Escribe cuánto cuesta, para cuándo y cuánto apartarás de cada envío (módulo 4). Separa el dinero del proyecto del gasto de la casa.



#### Un caso en un minuto

Don Efrén empezó un invernadero pequeño de jitomate con lo que aprendió allá. Ahora su esposa lo atiende durante la temporada y él lo amplía cuando regresa.

> **Idea clave:** combina metas de comodidad con una que produzca ingreso, y pruébala en pequeño antes de invertir todo.



#### Comprueba lo que entendiste

1. ¿Qué tipo de meta genera ingreso?
*Respuesta:* Una que produce: tierra, animales, invernadero o negocio.

2. ¿Qué haces antes de invertir todo el ahorro?
*Respuesta:* Pruebo en pequeño.


#### Para recordar

- Una meta que produzca.
- Prueba en pequeño.
- Separa el dinero.



### Profundiza (5 minutos más)

#### La meta de Don Efrén

- Costo del invernadero: **36,000**
- Envíos de la temporada: **24**
- Por envío: **1,500**


#### Con la familia

Si el proyecto lo atiende quien se queda, que esa persona participe en las decisiones y en las ganancias.



#### Casos


**Caso 1. Solo la casa**

Don Efrén invirtió todo en la casa.
- *¿Qué hace ahora?* Suma una meta que produzca ingreso.


**Caso 2. Todo de golpe**

Juan Carlos quiere comprar 50 animales con todo su ahorro.
- *¿Qué hace?* Prueba primero con pocos.


**Caso 3. El dinero mezclado**

Rosaura usa el dinero del proyecto para gastos de la casa.
- *¿Qué hace?* Lo separa en otra cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Solo metas de comodidad | Sin ingreso | Una que produzca |
| Invertir todo de golpe | Puedes perderlo | En pequeño |
| Mezclar dinero | No ves si gana | Sepáralo |
| Excluir a la familia | Conflictos | Que participe |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Efrén, Juan Carlos y Rosaura. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es una meta que produce? a) Una pantalla grande · b) Un invernadero · c) Una fiesta
2. ¿Qué haces antes de invertir todo? a) Pruebas en pequeño · b) Pides prestado más · c) Nada
3. La meta cuesta 30,000 y mandas 20 envíos. ¿Cuánto por envío? a) 600 · b) 3,000 · c) 1,500
**Respuestas:** 1-b: produce. 2-a: en pequeño. 3-c: 30,000 entre 20.



#### Ponlo en práctica

Tu proyecto cuesta 24,000 y quieres juntarlo en dos temporadas de 20 envíos cada una. ¿Cuánto por envío?
**Respuesta:** 600 pesos.



#### A tu plan

Escribe tu proyecto que produce: qué es, cuánto cuesta, para cuándo y cuánto por envío.



### Para saber más

- **Emprender** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores».

### Palabras clave

- *Proyecto productivo:* algo que genera ingreso.
- *Prueba piloto:* empezar en pequeño.
- *Inversión:* dinero que pones para que produzca.

### Fuentes

Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.

---

## M8 U03. Tu plan de temporada en una página

**Lo que lograrás:** Reunir en una página tu contrato, tu pago, tus envíos, tus papeles, tus derechos y tu futuro. Aplica igual a Canadá (PTAT) y a Estados Unidos (H-2A).

**Para empezar:** Rosaura tiene su carpeta, su lista de ayuda y su plan de envíos, pero en papeles distintos. Quiere verlo todo junto antes de la siguiente temporada. En esta lección hará su plan.

### Lo esencial (5 minutos)

#### Tu plan tiene seis partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Contrato | Verificado y revisado. | M1. |
| Casa | Acuerdo y presupuesto. | M2. |
| Pago y envíos | Talón, cobro y plan de remesa. | M3 y M4. |
| Papeles | Carpeta e impuestos. | M5. |
| Derechos | Lista de ayuda. | M6. |
| Futuro | Meses sin temporada, retiro y proyecto. | M7 y M8. |

#### Una acción y una fecha

Para cada parte, escribe la siguiente acción y cuándo la harás.



#### Antes de cada temporada

Revisa tu plan antes de irte y al regresar. Cada temporada cambia algo.



#### Un caso en un minuto

Rosaura escribió tres pasos. Confirmar su registro en el Servicio Nacional de Empleo (enero). Acordar el plan de remesas (antes de irse). Presentar su declaración en Canadá (abril). Lo revisa antes de cada temporada.

> **Idea clave:** junta todo en una página con una acción y una fecha, y revísalo antes de irte y al regresar.



#### Comprueba lo que entendiste

1. ¿Cuántas partes tiene tu plan?
*Respuesta:* Seis.

2. ¿Cuándo lo revisas?
*Respuesta:* Antes de irme y al regresar.


#### Para recordar

- Seis partes.
- Acción y fecha.
- Antes y después.



### Profundiza (5 minutos más)

#### Mi plan de temporada

| Parte | Siguiente acción | Fecha |
|---|---|---|
| Contrato | | |
| Casa | | |
| Pago y envíos | | |
| Papeles | | |
| Derechos | | |
| Futuro | | |



#### Compártelo con tu familia

Que la familia que se queda conozca el plan, sobre todo los envíos, el ahorro y la lista de ayuda.



#### Casos


**Caso 1. Papeles separados**

Rosaura tiene todo en papeles distintos.
- *¿Qué hace?* Junta todo en su plan de una página.


**Caso 2. Todo hoy**

Juan Carlos quiere resolverlo todo antes de mañana.
- *¿Qué hace?* Escribe una acción con fecha para cada parte.


**Caso 3. La familia no sabe**

Doña Imelda no conoce el plan de Don Efrén.
- *¿Qué hacen?* Lo revisan juntos antes de que se vaya.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Papeles regados | No ves el avance | Una página |
| Todo hoy | Te abrumas | Una acción por parte |
| Sin fechas | No pasa | Fecha |
| Familia sin saber | Desorden | Compártelo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosaura, Juan Carlos y la familia de Don Efrén. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué lleva cada parte? a) Solo lo que ya hiciste en la temporada · b) La siguiente acción y una fecha · c) Una lista de compras de la casa
2. ¿Cuándo revisas tu plan? a) Antes de irte y al regresar · b) Cada diez años, cuando cambie algo · c) Nunca, una vez escrito ya quedó
3. ¿Con quién compartes el plan? a) Con nadie · b) Con el reclutador · c) Con tu familia
**Respuestas:** 1-b: acción y fecha. 2-a: antes y después. 3-c: tu familia.



#### Ponlo en práctica

Escribe la siguiente acción de la parte «Papeles» con una fecha.
**Respuesta:** Ejemplo: «Presentar mi declaración en Canadá antes del 30 de abril».



#### A tu plan

Llena tu plan de temporada y revísalo con tu familia.



### Para saber más

- **Todo lo del curso** (Desarrolla Talento · español): repasa las tablas de los módulos 1 a 7.

### Palabras clave

- *Plan:* lista de lo que harás y cuándo.
- *Revisión:* volver a ver cómo vas.
- *Siguiente acción:* el próximo paso concreto.

### Fuentes

Elaboración propia con base en los módulos 1 a 8 del programa.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Temporada, Tu Dinero, Tu Futuro** — Programa de bienestar financiero para jornaleros mexicanos que van a trabajar al campo en Canadá (Programa de Trabajadores Agrícolas Temporales) o en Estados Unidos (visa H-2A), y para sus familias: reclutamiento sin fraudes, contrato, pago y derechos allá, envíos de dinero, impuestos, regreso y un proyecto para el futuro en México. 8 módulos y 24 lecciones cortas.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Antes de firmar: dos caminos y cero fraudes:** El camino correcto para ti, tu contrato revisado y ningún pago a reclutadores.
- **Antes de irte: la casa en orden:** Tu casa en orden: quién maneja el dinero, el presupuesto de la familia y sin deudas para irte.
- **Tu pago allá:** Tus talones de pago revisados y tu forma segura de cobrar.
- **Mandar dinero que rinda:** Tus envíos comparados y un plan para la remesa acordado con la familia.
- **Impuestos y papeles en Canadá y Estados Unidos:** Tus papeles de impuestos guardados y tu decisión sobre la declaración.
- **Tus derechos y tu seguridad:** Tus derechos claros y tu lista de a quién llamar.
- **El regreso y los meses sin temporada:** Tu presupuesto para los meses entre temporadas.
- **Tu retiro y tu futuro en México:** Tus semanas y aportaciones para el retiro (en México y Canadá) y tu proyecto en números.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 24 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Don Efrén:** 45 años. De Guanajuato. Lleva ocho temporadas con visa H-2A en el tabaco en Carolina del Norte.
- **Rosaura:** 38 años. De Tlaxcala. Va con el PTAT a invernaderos de Ontario, Canadá, desde hace seis temporadas.
- **Juan Carlos:** 23 años. De Hidalgo. Va por primera vez a la cosecha de manzana en Washington con visa H-2A.
- **Doña Imelda:** 43 años. Esposa de Don Efrén. Se queda a cargo de la casa y de los hijos.
- **Ramiro:** 35 años. De Michoacán. Un reclutador le cobró por «asegurar su lugar».

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **No se da asesoría migratoria ni legal:** se orienta a los consulados, al Servicio Nacional de Empleo, al Departamento del Trabajo de EE. UU., al Gobierno de Canadá y a oficinas públicas.
5. **No se recomiendan reclutadores, agencias ni empresas de envío:** se enseña a verificarlos y compararlos.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. Antes de firmar (Módulo 1)

**Datos.** A Ramiro un reclutador le pide 15,000 pesos para «asegurar su lugar» en la H-2A. Juan Carlos ya tiene su oferta: el contrato dice 12 semanas de 40 horas.

**Tareas.**

1. ¿Debe pagar Ramiro por su lugar?
2. ¿Por dónde se entra al PTAT a Canadá?
3. ¿Cuántas horas le garantizan a Juan Carlos (3/4)?
4. ¿Qué cuatro cosas lee en su contrato?

**Clave.**

- No: en la H-2A el empleador paga el reclutamiento. Si cobran por el lugar, es fraude; verifica antes de dar un peso.
- Por el Servicio Nacional de Empleo, sin costo.
- 12 por 40 son 480 horas; 3/4: 360 horas.
- Pago, horas, vivienda y descuentos.

### E2. La casa de Doña Imelda (Módulos 2 y 4)

**Datos.** Don Efrén se va seis meses. Doña Imelda administra la casa. Él manda 600 dólares al mes. Con un servicio llegan 10,200 pesos y con otro 10,500. Acordaron repartir: 60% básicos, 20% ahorro y 20% para terminar el cuarto.

**Tareas.**

1. ¿A nombre de quién debe estar la cuenta para recibir?
2. ¿Cuántos pesos más llegan al mes con el segundo servicio? ¿Y en la temporada?
3. ¿Cómo reparten 10,500?
4. ¿Cada cuándo hablan de dinero?

**Clave.**

- De Doña Imelda, que es quien administra.
- 300 al mes; 1,800 en seis meses.
- 6,300 básicos, 2,100 ahorro y 2,100 para el cuarto.
- Cada semana, y revisan el plan cada mes.

### E3. El pago y los impuestos de Rosaura (Módulos 3 y 5)

**Datos.** Rosaura anota en su libreta 44 horas en una semana; su talón dice 40. Gana 17.60 dólares canadienses por hora. En Canadá le descontaron impuesto, CPP y EI.

**Tareas.**

1. ¿Cuánto le falta en esa semana?
2. ¿Qué hace para reclamar?
3. ¿Qué documentos necesita para su declaración en Canadá?
4. ¿Por qué le conviene declarar?

**Clave.**

- 4 horas por 17.60: 70.40 dólares canadienses.
- Compara el talón con su libreta, pregunta al encargado y, si no se corrige, pide apoyo al consulado.
- Su T4 y su SIN.
- Puede haber reembolso y cuida su pensión del CPP.

### E4. Los meses sin temporada (Módulos 7 y 8)

**Datos.** Don Efrén regresa con 60,000 pesos ahorrados. Faltan 5 meses para la siguiente temporada. La casa necesita 9,000 al mes y él gana unos 4,000 al mes en trabajos del pueblo. Quiere poner un pequeño negocio de abarrotes.

**Tareas.**

1. ¿Cuánto les falta cada mes?
2. ¿Cuánto del ahorro usan en los 5 meses?
3. ¿Cuánto le queda para su proyecto?
4. ¿Cómo prueba la idea antes de invertir todo? ¿Y su retiro?

**Clave.**

- 9,000 menos 4,000: 5,000.
- 5,000 por 5: 25,000.
- 60,000 menos 25,000: 35,000.
- La prueba en pequeño antes de invertir todo. Con la H-2A no cotiza allá, así que aporta a su Afore.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Escribe una diferencia entre el PTAT y la H-2A en el retiro. |
| P02 | M1 U02 | Un reclutador cobra 15,000 a 20 personas. ¿Cuánto se lleva? |
| P03 | M1 U03 | Tu contrato H-2A dice 40 horas por semana durante 20 semanas. ¿Cuántas horas te garantizan? |
| P04 | M2 U01 | Necesitas 7,000 y tienes 5,500 ahorrados. ¿Cuánto pides? |
| P05 | M2 U02 | Escribe los cuatro puntos de su acuerdo. |
| P06 | M2 U03 | La casa gasta 1,250 por semana. ¿Cuánto apartan para cubrir 4 semanas antes del primer envío? |
| P07 | M3 U01 | Trabajaste 48 horas a 15 dólares la hora. ¿Cuánto debe decir tu talón antes de descuentos? |
| P08 | M3 U02 | Trabajas 900 horas a 16 dólares. ¿Cuánto ganas en la temporada antes de descuentos? |
| P09 | M3 U03 | Pierdes 20 dólares por semana durante 24 semanas. ¿Cuánto en la temporada? |
| P10 | M4 U01 | Con una empresa llegan 5,300 pesos y con otra 5,520 por el mismo envío. ¿Cuánto más con la segunda? |
| P11 | M4 U02 | Mandas 20 envíos de 7,000 y ahorran 20% de cada uno. ¿Cuánto ahorran en la temporada? |
| P12 | M4 U03 | Mandas 3,500 cada dos semanas a tu ahorro durante 12 envíos. ¿Cuánto juntas? |
| P13 | M5 U01 | Escribe por qué la temporada H-2A no te da pensión en EE. UU. |
| P14 | M5 U02 | Te retuvieron 2,100 dólares canadienses y tu impuesto final es 1,400. ¿Cuánto sería tu reembolso? |
| P15 | M5 U03 | Tienes 6 temporadas en Canadá. ¿Cuántas T4 deberías tener? |
| P16 | M6 U01 | Escribe dos derechos que tienes en los dos países. |
| P17 | M6 U02 | Escribe los cuatro datos de tu ficha de salud. |
| P18 | M6 U03 | Escribe el número de emergencias en Canadá y en Estados Unidos. |
| P19 | M7 U01 | Escribe tres pendientes de tu lista de salida. |
| P20 | M7 U02 | Te faltan 3,500 al mes y estarás 5 meses. ¿Cuánto debe durar tu ahorro? |
| P21 | M7 U03 | Ganas 120,000 netos allá y gastarías 20,000 allá en lo tuyo. Aquí ganarías 50,000. ¿Cuánto te deja de verdad? |
| P22 | M8 U01 | Aportas 400 pesos cada mes de una temporada de 8 meses. ¿Cuánto al año? |
| P23 | M8 U02 | Tu proyecto cuesta 24,000 y quieres juntarlo en dos temporadas de 20 envíos cada una. ¿Cuánto por envío? |
| P24 | M8 U03 | Escribe la siguiente acción de la parte «Papeles» con una fecha. |

### Respuestas

- **P01:** En Canadá cotizas al Plan de Pensiones de Canadá; con la H-2A no cotizas al Seguro Social de EE. UU.
- **P02:** 300,000 pesos.
- **P03:** 600 horas (3/4 de 800).
- **P04:** 1,500 pesos.
- **P05:** Quién administra, la cuenta para recibir, los pagos de cada mes y el día para hablar de dinero.
- **P06:** 5,000 pesos.
- **P07:** 720 dólares.
- **P08:** 14,400 dólares.
- **P09:** 480 dólares.
- **P10:** 220 pesos.
- **P11:** 28,000 pesos.
- **P12:** 42,000 pesos.
- **P13:** Porque el salario H-2A no paga Seguro Social.
- **P14:** 700 dólares canadienses.
- **P15:** 6, una por año.
- **P16:** Por ejemplo: guardar mi pasaporte y recibir mi pago completo y a tiempo.
- **P17:** Tarjeta o póliza, teléfono del encargado, clínica más cercana y teléfono del consulado.
- **P18:** 911 en los dos.
- **P19:** Por ejemplo: transporte de regreso, último talón y W-2 o T4.
- **P20:** 17,500 pesos.
- **P21:** 50,000 pesos (120,000 menos 20,000 menos 50,000).
- **P22:** 3,200 pesos.
- **P23:** 600 pesos.
- **P24:** Ejemplo: «Presentar mi declaración en Canadá antes del 30 de abril».


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Antes de firmar: dos caminos y cero fraudes

- **Agencia de colocación:** empresa que coloca trabajadores.
- **Deducción:** lo que te descuentan del pago.
- **Denuncia:** aviso formal a la autoridad.
- **Garantía de horas:** mínimo de horas que te deben pagar.
- **H-2A:** visa de trabajo agrícola temporal en Estados Unidos.
- **Pago por pieza:** pago por lo que cosechas.
- **PTAT:** Programa de Trabajadores Agrícolas Temporales México-Canadá.
- **Reclutador:** quien busca trabajadores para un empleador.
- **Servicio Nacional de Empleo:** oficina pública de empleo.

### Antes de irte: la casa en orden

- **Acuerdo escrito:** papel con lo que acordaron.
- **Administrar:** decidir y pagar los gastos.
- **Ahorro previo:** lo que se aparta antes.
- **Etapa:** parte de la temporada.
- **Intermediario:** persona que se mete entre tú y tu dinero.
- **Interés:** lo que pagas por un préstamo.
- **Poder limitado:** permiso para un trámite concreto.
- **Porcentaje:** parte de cada 100.
- **Reembolso:** que te regresen lo que pagaste.

### Tu pago allá

- **Comisión:** cobro por un servicio.
- **CPP:** Plan de Pensiones de Canadá.
- **Depósito directo:** el pago llega a tu cuenta o tarjeta.
- **EI:** Seguro de Empleo de Canadá.
- **Enlace del consulado:** personal que atiende a trabajadores del PTAT.
- **Nivel del puesto:** categoría según la habilidad que pide.
- **Salario de referencia:** salario fijado cada año para la tarea.
- **Talón de pago:** papel con el detalle de tu pago.
- **Tarjeta de nómina:** tarjeta donde te pagan.

### Mandar dinero que rinda

- **Ahorro:** dinero que guardas para después.
- **Apartado:** espacio separado en tu cuenta.
- **Declarar:** avisar a la autoridad.
- **Liquidar:** terminar de pagar una deuda.
- **Meta:** algo que quieren lograr.
- **Plan:** acuerdo de en qué se usa el dinero.
- **Remesa:** dinero que mandas a tu familia.
- **Tipo de cambio:** pesos por dólar.

### Impuestos y papeles en Canadá y Estados Unidos

- **1040-NR:** declaración para no residentes.
- **Carpeta:** lugar donde guardas tus papeles.
- **Copia:** foto o duplicado de un papel.
- **Identidad:** tus datos personales.
- **ITIN:** número de impuestos del IRS.
- **SIN:** número de seguro social de Canadá.
- **T4:** forma con tu salario y retenciones en Canadá.
- **W-2:** forma con tu salario del año.

### Tus derechos y tu seguridad

- **Cobertura de salud:** seguro que paga tu atención médica.
- **Consulado:** oficina de México en otro país.
- **Enlace:** persona que te atiende y da seguimiento.
- **Equipo de protección:** guantes, botas y lo que pida el trabajo.
- **Reporte de accidente:** registro oficial de lo que pasó.
- **Represalia:** castigo por quejarte.
- **Trata:** obligar a alguien a trabajar con engaños o amenazas.
- **Vivienda digna:** lugar seguro y limpio para vivir.
- **Workers' compensation:** seguro de accidentes de trabajo en EE. UU.

### El regreso y los meses sin temporada

- **Costo de oportunidad:** lo que dejas de ganar al elegir otra cosa.
- **Lista de salida:** pendientes antes de regresar.
- **Meses sin temporada:** tiempo en México entre una temporada y otra.
- **Neto:** lo que queda después de gastos y descuentos.
- **Regreso:** viaje de vuelta a México.
- **Sueldo mensual:** lo que te das cada mes del ahorro.
- **Tope:** lo máximo que vas a gastar.
- **Último talón:** el detalle de tu último pago.

### Tu retiro y tu futuro en México

- **Aportación voluntaria:** lo que tú agregas a tu Afore.
- **Convenio de seguridad social:** acuerdo para sumar periodos cotizados entre países.
- **Inversión:** dinero que pones para que produzca.
- **Proyecto productivo:** algo que genera ingreso.
- **Prueba piloto:** empezar en pequeño.
- **Revisión:** volver a ver cómo vas.
- **Siguiente acción:** el próximo paso concreto.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| PTAT | STPS: https://www.gob.mx/stps | «Programa de Trabajadores Agrícolas Temporales México-Canadá» | M1 U01 |
| Contrato PTAT 2026 | Gobierno de Canadá: https://www.canada.ca | «Contrato de trabajo para trabajadores agrícolas temporales mexicanos en Canadá 2026» | M1 U01, M1 U03, M6 U02, M7 U01 |
| Ofertas H-2A | DOL: https://seasonaljobs.dol.gov | — | M1 U01, M1 U02 |
| Servicio Nacional de Empleo | STPS: https://www.empleo.gob.mx | — | M1 U02 |
| Agencias de colocación registradas | STPS: https://www.gob.mx/stps | — | M1 U02 |
| Protecciones H-2A | DOL: https://www.dol.gov/agencies/whd/agriculture/h2a | — | M1 U03, M2 U01, M6 U01, M6 U02, M7 U01 |
| Créditos | CONDUSEF: https://www.condusef.gob.mx | «CAT» y «préstamos personales» | M2 U01 |
| Cuentas básicas | CONDUSEF: https://www.condusef.gob.mx | «cuenta básica» | M2 U02 |
| Presupuesto familiar | CONDUSEF: https://www.condusef.gob.mx | «presupuesto familiar» | M2 U03 |
| Derechos de pago H-2A | DOL: https://www.dol.gov/agencies/whd/agriculture/h2a | — | M3 U01 |
| Derechos de trabajadores temporales en Canadá | Gobierno de Canadá: https://www.canada.ca | «Trabajadores extranjeros temporales: sus derechos están protegidos» | M3 U01, M6 U01 |
| División de Horas y Salarios | DOL: https://www.dol.gov/agencies/whd/contact | 1-866-487-9243 | — | M3 U02, M6 U03 |
| Consulados de México en Canadá | SRE: https://consulmex.sre.gob.mx | «Programa de Trabajadores Agrícolas Temporales» | M3 U02, M5 U02 |
| Cuentas en EE. UU. | Consumer Financial Protection Bureau: https://www.consumerfinance.gov/es | — | M3 U03 |
| Cuentas en Canadá | Agencia del Consumidor en Materia Financiera de Canadá: https://www.canada.ca/en/financial-consumer-agency.html | — | M3 U03 |
| Quién es Quién en el Envío de Dinero | PROFECO: https://qqed.profeco.gob.mx | — | M4 U01 |
| Remesas | CONDUSEF: https://www.condusef.gob.mx | «remesas» | M4 U02 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M4 U03 |
| Declarar dinero al cruzar | CBP: https://www.cbp.gov | «declarar dinero» | M4 U03 |
| Declarar dinero en Canadá | Agencia de Servicios Fronterizos de Canadá: https://www.cbsa-asfc.gc.ca | «currency reporting» | M4 U03 |
| Trabajadores agrícolas extranjeros | IRS: https://www.irs.gov/individuals/international-taxpayers/foreign-agricultural-workers | — | M5 U01 |
| Impuestos para trabajadores temporales | Agencia de Ingresos de Canadá: https://www.canada.ca/en/revenue-agency.html | «seasonal agricultural workers» | M5 U02 |
| Robo de identidad | CONDUSEF: https://www.condusef.gob.mx | «robo de identidad» | M5 U03 |
| Consulados de México | SRE: https://consulmex.sre.gob.mx | — | M6 U03 |
| Presupuesto con ingreso variable | CONDUSEF: https://www.condusef.gob.mx | «ingresos variables» | M7 U02 |
| Planeación financiera | CONDUSEF: https://www.condusef.gob.mx | «metas financieras» | M7 U03 |
| AforeMóvil | CONSAR: https://www.gob.mx/consar | — | M8 U01 |
| Convenio de seguridad social México-Canadá | Gobierno de Canadá: https://www.canada.ca | «Agreement on Social Security Mexico» | M8 U01 |
| Emprender | CONDUSEF: https://www.condusef.gob.mx | «emprendedores» | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Antes de firmar: dos caminos y cero fraudes

- **M1 U01 · Dos caminos: Canadá y Estados Unidos.** STPS, PTAT; Gobierno de Canadá, contrato SAWP-México 2026; DOL, protecciones para trabajadores H-2A; consultados el 5 de octubre de 2026.
- **M1 U02 · Reclutadores falsos.** STPS, alerta por fraudes en visas de trabajo agrícola (septiembre de 2026) y PTAT; DOL; consultados el 5 de octubre de 2026.
- **M1 U03 · Lee tu contrato.** Gobierno de Canadá, contrato SAWP-México 2026; DOL, Wage and Hour Division; consultados el 5 de octubre de 2026.

### Antes de irte: la casa en orden

- **M2 U01 · No te endeudes para irte.** DOL, costos a cargo del empleador en el programa H-2A; CONDUSEF; consultados el 5 de octubre de 2026.
- **M2 U02 · Quién maneja el dinero en casa.** CONDUSEF, cuentas básicas; consultado el 5 de octubre de 2026.
- **M2 U03 · El presupuesto de la familia mientras no estás.** CONDUSEF, presupuesto familiar; consultado el 5 de octubre de 2026.

### Tu pago allá

- **M3 U01 · Tu talón de pago.** DOL, Wage and Hour Division; Gobierno de Canadá, contrato SAWP-México 2026; consultados el 5 de octubre de 2026.
- **M3 U02 · ¿Te pagan lo correcto?.** Gobierno de Canadá, contrato SAWP-México 2026; DOL, Federal Register (2 de octubre de 2025); consultados el 5 de octubre de 2026.
- **M3 U03 · Cobrar sin perder en comisiones.** Consumer Financial Protection Bureau; Agencia del Consumidor en Materia Financiera de Canadá; consultados el 5 de octubre de 2026.

### Mandar dinero que rinda

- **M4 U01 · Compara antes de mandar.** PROFECO, Quién es Quién en el Envío de Dinero; consultado el 5 de octubre de 2026.
- **M4 U02 · El plan para la remesa.** CONDUSEF, uso de remesas; consultado el 5 de octubre de 2026.
- **M4 U03 · Ahorrar allá o mandar a México.** CBP y Agencia de Servicios Fronterizos de Canadá, declaración de efectivo de 10,000 dólares o más; CONDUSEF; consultados el 5 de octubre de 2026.

### Impuestos y papeles en Canadá y Estados Unidos

- **M5 U01 · Impuestos en Estados Unidos con visa H-2A.** IRS, trabajadores agrícolas extranjeros y Publicación 5144; consultados el 5 de octubre de 2026.
- **M5 U02 · Impuestos en Canadá con el PTAT.** Gobierno de Canadá, deducciones de nómina y declaración de impuestos; consulados de México en Canadá; consultados el 5 de octubre de 2026.
- **M5 U03 · Tu carpeta de papeles.** IRS; Agencia de Ingresos de Canadá; consultados el 5 de octubre de 2026.

### Tus derechos y tu seguridad

- **M6 U01 · Tus derechos básicos allá.** DOL; Gobierno de Canadá, derechos de trabajadores extranjeros temporales; consultados el 5 de octubre de 2026.
- **M6 U02 · Si te lastimas o te enfermas.** DOL; Gobierno de Canadá, contrato SAWP-México 2026; consultados el 5 de octubre de 2026.
- **M6 U03 · A quién llamar.** SRE; DOL; Línea Nacional contra la Trata de Personas de EE. UU.; Gobierno de Canadá; consultados el 5 de octubre de 2026.

### El regreso y los meses sin temporada

- **M7 U01 · El regreso.** Gobierno de Canadá, contrato SAWP-México 2026; DOL; consultados el 5 de octubre de 2026.
- **M7 U02 · Los meses sin temporada.** CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.
- **M7 U03 · ¿Otra temporada?.** Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.

### Tu retiro y tu futuro en México

- **M8 U01 · Tu retiro: Canadá, Estados Unidos y México.** Convenio sobre Seguridad Social entre México y Canadá (DOF, 1998); IRS; CONSAR; consultados el 5 de octubre de 2026.
- **M8 U02 · Un proyecto que produce.** Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.
- **M8 U03 · Tu plan de temporada en una página.** Elaboración propia con base en los módulos 1 a 8 del programa.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Dos caminos: Canadá y Estados Unidos

**Caso 1. Los 40 mil.** El primo de Juan Carlos dice que hay que pagar 40 mil por la visa. **¿Qué hace?**

- ✔ Pregunta en el Servicio Nacional de Empleo y al empleador por escrito.
- Paga los 40 mil porque así le aseguran el lugar.
- Pide prestado para pagar rápido antes de que se acabe el cupo.

**Caso 2. El PTAT con cuota.** A Rosaura le ofrecen «meterla al programa de Canadá» por 8,000 pesos. **¿Qué hace?**

- ✔ No paga: el PTAT es sin costo en el Servicio Nacional de Empleo.
- Paga la cuota porque todos en el pueblo la pagan.
- Paga la mitad ahora y la otra mitad al llegar.

**Caso 3. La cuota a una cuenta personal.** Le piden a Don Efrén depositar la cuota de la visa a una cuenta personal. **¿Qué hace?**

- ✔ Paga solo en las cuentas oficiales del consulado.
- Deposita a la cuenta personal que le dieron.
- Paga en efectivo a quien le ofreció el trámite.

## M1 U02. Reclutadores falsos

**Caso 1. Asegurar el lugar.** A Ramiro le piden 15,000 para asegurar su lugar. **¿Qué hace?**

- ✔ No paga y verifica la oferta.
- Paga para asegurar el lugar antes que otros.
- Paga una parte para que lo pongan en la lista.

**Caso 2. «No le digas a nadie».** A Juan Carlos le dicen que no comente la oferta con nadie. **¿Qué hace?**

- ✔ Desconfía y pregunta en el consulado.
- Guarda el secreto para no perder la oportunidad.
- Invita a sus primos sin contarle a nadie más.

**Caso 3. Ya pagó.** Ramiro ya pagó y el reclutador desapareció. **¿Qué hace?**

- ✔ Junta pruebas y denuncia.
- Se queda callado por vergüenza y lo olvida.
- Le paga más al reclutador para que cumpla.

## M1 U03. Lee tu contrato

**Caso 1. Firmar sin leer.** Don Efrén firmó sin leer. **¿Qué hace ahora?**

- ✔ Lee pago, horas, vivienda y descuentos antes de firmar.
- Firma rápido porque todos firman igual.
- Firma y pregunta cuando ya esté trabajando allá.

**Caso 2. Los descuentos de Rosaura.** Rosaura no sabe qué le pueden descontar en Canadá. **¿Qué hace?**

- ✔ Revisa en su contrato el avión, la vivienda y las deducciones.
- Acepta los descuentos sin revisar nada.
- Le pide a una compañera que se los explique de memoria.

**Caso 3. Solo en inglés.** A Juan Carlos le dan el contrato solo en inglés. **¿Qué hace?**

- ✔ Pide una copia en español.
- Firma aunque no entienda el inglés.
- Pide que se lo resuman en una frase.

## M2 U01. No te endeudes para irte

**Caso 1. Los 20,000.** Juan Carlos quiere pedir 20,000 al 10% mensual. **¿Qué hace?**

- ✔ Hace su lista y pide solo lo necesario, sin intereses caros.
- Pide los 20,000 completos con un prestamista del pueblo.
- Empeña las escrituras de la casa por si falta.

**Caso 2. El reembolso.** Ramiro no sabe si le reembolsan la visa. **¿Qué hace?**

- ✔ Pregunta por escrito al empleador cuándo se la reembolsan.
- Da por perdido el dinero y no pregunta.
- Espera a que se lo devuelvan sin decir nada.

**Caso 3. El hermano.** El hermano de Juan Carlos le presta sin intereses. **¿Qué hacen?**

- ✔ Escriben cuánto y cuándo pagará.
- Lo dejan de palabra, porque son familia.
- Le paga cuando le sobre, sin fecha.

## M2 U02. Quién maneja el dinero en casa

**Caso 1. El compadre.** Don Efrén manda el dinero a través de su compadre. **¿Qué hace?**

- ✔ Manda directo a la cuenta de Doña Imelda.
- Sigue mandando a nombre del compadre.
- Manda efectivo con un paisano que va de regreso.

**Caso 2. El poder.** Doña Imelda necesita hacer trámites en el banco por Don Efrén. **¿Qué hacen?**

- ✔ Un poder limitado a ese trámite y con fecha.
- Un poder amplio para todo y sin fecha.
- Le deja firmadas hojas en blanco.

**Caso 3. La tarjeta.** Juan Carlos quiere dejar su tarjeta y NIP a su primo. **¿Qué hace?**

- ✔ No la deja: cada quien con la suya.
- Le deja su tarjeta y su NIP al cuñado.
- Le deja la tarjeta al vecino de confianza.

## M2 U03. El presupuesto de la familia mientras no estás

**Caso 1. Abril sin dinero.** La familia se endeuda al inicio de cada temporada. **¿Qué hacen?**

- ✔ Apartan antes para las primeras semanas.
- Esperan el primer envío para comprar comida.
- Piden fiado en la tienda todo abril.

**Caso 2. Todo a la casa.** Doña Imelda gasta todo el envío en la casa. **¿Qué hace?**

- ✔ Reparte en partes, con ahorro y meta.
- Gasta todo en la casa porque es lo urgente.
- Guarda todo y no gasta en nada de la casa.

**Caso 3. Sin revisar.** Don Efrén no sabe cuánto se ha ahorrado. **¿Qué hacen?**

- ✔ Revisan juntos cada domingo.
- Revisan solo cuando él regresa en diciembre.
- No revisan porque confían en que alcanza.

## M3 U01. Tu talón de pago

**Caso 1. Seis horas menos.** El talón de Juan Carlos tiene 6 horas menos que su libreta. **¿Qué hace?**

- ✔ Pregunta al encargado con su libreta en mano.
- Lo deja pasar porque son pocas horas.
- Reclama a gritos frente a todos sin pruebas.

**Caso 2. Renta en la H-2A.** A Ramiro le descuentan «renta» de la vivienda en EE. UU. **¿Qué hace?**

- ✔ Pregunta: la vivienda H-2A es sin costo para el trabajador.
- Paga la renta porque así viene en el talón.
- Se cambia de vivienda por su cuenta.

**Caso 3. Las siglas de Canadá.** Rosaura no entiende «CPP» y «EI» en su talón. **¿Qué hace?**

- ✔ Sabe que son cotizaciones y las anota para su declaración.
- Cree que son multas y se queja.
- Pide que ya no se las quiten.

## M3 U02. ¿Te pagan lo correcto?

**Caso 1. Bajó el salario.** El salario H-2A de Don Efrén bajó este año. **¿Qué hace?**

- ✔ Revisa su contrato y el nivel de su puesto.
- Acepta el pago porque así le dijeron.
- Renuncia sin revisar nada.

**Caso 2. Menos que el contrato en Canadá.** A Rosaura le pagan menos de lo que dice su contrato. **¿Qué hace?**

- ✔ Reclama con su libreta y, si no se corrige, acude al enlace del consulado.
- Lo acepta para que la vuelvan a pedir la siguiente temporada.
- Deja de trabajar sin avisar.

**Caso 3. Menos que el contrato en EE. UU..** A Juan Carlos le pagan menos que la tarifa del contrato. **¿Qué hace?**

- ✔ Reclama y, si no se corrige, llama al 1-866-487-9243.
- No dice nada porque es su primera temporada.
- Le pide al reclutador de México que hable por él.

## M3 U03. Cobrar sin perder en comisiones

**Caso 1. El 4%.** Juan Carlos cambia cheques en una tienda. **¿Qué hace?**

- ✔ Pide depósito directo o tarjeta de nómina.
- Sigue cambiando cheques en la tienda con 4%.
- Le pide a un compañero que se los cambie.

**Caso 2. La cuenta en Canadá.** A Rosaura le ofrecen abrir una cuenta en un banco canadiense. **¿Qué hace?**

- ✔ Pregunta sus comisiones y si puede mandar dinero a México desde ahí.
- Abre la cuenta sin preguntar nada.
- No abre cuenta y guarda todo en efectivo.

**Caso 3. Efectivo guardado.** Don Efrén guarda 1,500 dólares en su maleta. **¿Qué hace?**

- ✔ Lo manda a casa o lo deja en su cuenta.
- Lo esconde bajo el colchón de la vivienda.
- Lo carga siempre en la cartera.

## M4 U01. Compara antes de mandar

**Caso 1. Ocho años igual.** Don Efrén nunca ha comparado. **¿Qué hace?**

- ✔ Revisa el comparador de PROFECO.
- Sigue usando el mismo envío por costumbre.
- Manda con quien le recomiende el encargado.

**Caso 2. Sin comisión.** A Juan Carlos le anuncian envíos sin comisión. **¿Qué hace?**

- ✔ Revisa también el tipo de cambio y los pesos que llegan.
- Lo elige porque no cobra comisión.
- Manda todo de una vez para aprovechar.

**Caso 3. Desde Canadá.** Rosaura manda desde Ontario y nunca ha comparado. **¿Qué hace?**

- ✔ Pregunta en dos o tres opciones cuántos pesos llegan y compara.
- Manda con el primero que encuentra en la tienda.
- Espera a regresar con todo en efectivo.

## M4 U02. El plan para la remesa

**Caso 1. «¿Qué hicimos?».** La familia no sabe en qué se fue el dinero. **¿Qué hacen?**

- ✔ Acuerdan las cuatro partes antes de la temporada.
- Gastan como vaya llegando el dinero.
- Deciden todo hasta que él regrese.

**Caso 2. Los préstamos.** A Doña Imelda le piden prestado cuando llega el envío. **¿Qué hace?**

- ✔ Dice «ese dinero ya tiene destino».
- Presta a todos los que le piden.
- Presta la mitad del ahorro a su primo.

**Caso 3. La deuda del viaje.** Juan Carlos debe 2,000 a su hermano. **¿Qué hace?**

- ✔ Destina una parte de cada envío hasta liquidar.
- Deja la deuda para la siguiente temporada.
- Pide otro préstamo para pagar el primero.

## M4 U03. Ahorrar allá o mandar a México

**Caso 1. Todo en la maleta.** A Ramiro le sugieren guardar todo en efectivo. **¿Qué hace?**

- ✔ Manda su ahorro poco a poco a una cuenta suya.
- Junta todo en la maleta para el regreso.
- Lo deja con el encargado para que se lo cuide.

**Caso 2. Ahorro mezclado.** Don Efrén manda todo a la cuenta de la casa. **¿Qué hace?**

- ✔ Separa el ahorro en otra cuenta o apartado.
- Deja todo junto en la cuenta del gasto.
- Gasta primero y ahorra lo que sobre.

**Caso 3. El rendimiento milagro.** A Juan Carlos le ofrecen duplicar su ahorro en seis meses. **¿Qué hace?**

- ✔ Desconfía y verifica en CONDUSEF.
- Invierte todo porque lo recomendó un paisano.
- Mete una parte para probar si es cierto.

## M5 U01. Impuestos en Estados Unidos con visa H-2A

**Caso 1. «Te van a cobrar todo junto».** A Juan Carlos le preocupa que no le retengan Seguro Social. **¿Qué hace?**

- ✔ Entiende que la H-2A no paga esa cuota y guarda su W-2.
- Aparta dinero para pagar el Seguro Social después.
- Pide que le retengan Seguro Social cada semana.

**Caso 2. El preparador del porcentaje.** A Don Efrén le ofrecen «sacarle un reembolso» por 30%. **¿Qué hace?**

- ✔ Busca orientación sin costo en organizaciones que recomienda el consulado.
- Acepta el 30% porque así es más fácil.
- Le da sus papeles para que se encargue de todo.

**Caso 3. Sin número.** A Juan Carlos todavía no le llega su número de Seguro Social. **¿Qué hace?**

- ✔ Pregunta por el ITIN para sus trámites de impuestos.
- Usa el número de un compañero.
- Inventa un número para llenar la forma.

## M5 U02. Impuestos en Canadá con el PTAT

**Caso 1. «Ya me lo quitaron».** Rosaura nunca ha declarado en Canadá. **¿Qué hace?**

- ✔ Presenta su declaración con su T4 y su SIN.
- No declara porque ya le quitaron el impuesto.
- Espera a que Canadá le escriba primero.

**Caso 2. El T4 perdido.** A una compañera de Rosaura se le perdió su T4. **¿Qué hace?**

- ✔ Lo pide al empleador antes de regresar.
- Da por perdido ese año.
- Declara con el T4 de otra compañera.

**Caso 3. El preparador caro.** Le ofrecen a Rosaura hacer su declaración a cambio de la mitad del reembolso. **¿Qué hace?**

- ✔ Busca orientación sin costo con el consulado.
- Acepta dar la mitad del reembolso.
- Le deja su SIN al preparador para que decida.

## M5 U03. Tu carpeta de papeles

**Caso 1. Ocho temporadas.** Don Efrén solo tiene papeles de dos temporadas. **¿Qué hace?**

- ✔ Arma su carpeta y pide los que le faltan.
- Se queda solo con los de las dos últimas temporadas.
- Tira los papeles viejos porque ya no sirven.

**Caso 2. T4 regados.** Rosaura tiene sus T4 en tres lugares. **¿Qué hace?**

- ✔ Los junta en una carpeta y les toma foto.
- Los deja donde están porque sabe dónde quedaron.
- Le pide a su familia que los guarde sueltos.

**Caso 3. El número.** Un compañero le pide a Juan Carlos su número de Seguro Social «para un trámite». **¿Qué hace?**

- ✔ No se lo da.
- Se lo da porque es su compañero.
- Le manda una foto de su tarjeta.

## M6 U01. Tus derechos básicos allá

**Caso 1. El pasaporte.** Le piden el pasaporte a un compañero de Juan Carlos. **¿Qué hace?**

- ✔ No lo entrega.
- Lo entrega para no tener problemas.
- Lo entrega y pide un recibo.

**Caso 2. «No te vuelven a pedir».** Amenazan a una compañera de Rosaura si se queja. **¿Qué hace?**

- ✔ Habla con el enlace del consulado.
- Se calla para que la vuelvan a pedir.
- Renuncia y regresa a México.

**Caso 3. Sin agua.** En la vivienda de Don Efrén falla el agua potable una semana. **¿Qué hace?**

- ✔ Toma fotos, anota fechas y reclama.
- Compra agua y no dice nada.
- Espera a que se arregle sola.

## M6 U02. Si te lastimas o te enfermas

**Caso 1. «Aguántate».** Le dicen a Juan Carlos que se aguante la cortada. **¿Qué hace?**

- ✔ Pide atención y que se reporte el accidente.
- Se aguanta para no perder el día.
- Se cura solo con lo que tiene.

**Caso 2. La fiebre.** Rosaura tiene fiebre fuerte en Ontario. **¿Qué hace?**

- ✔ Usa la cobertura de salud de su contrato y avisa al encargado.
- Sigue trabajando hasta que se le pase.
- Espera a regresar a México para ir al médico.

**Caso 3. Sin papeles del accidente.** A Don Efrén no le dieron copia del reporte. **¿Qué hace?**

- ✔ La pide y guarda sus comprobantes médicos.
- No pide nada porque ya lo atendieron.
- Tira las recetas cuando se termina la medicina.

## M6 U03. A quién llamar

**Caso 1. El pago.** Ramiro tiene un problema con su pago. **¿Qué hace?**

- ✔ Llama al consulado con su libreta y talones.
- Espera a ver si le pagan solo el mes siguiente.
- Se queja con los compañeros y nada más.

**Caso 2. Encerrados.** A un grupo no lo dejan salir de la vivienda en EE. UU. **¿Qué hacen?**

- ✔ Llaman al 911 o a la línea contra la trata.
- Esperan a que termine la temporada.
- Le piden permiso al encargado para salir.

**Caso 3. En Ontario.** Rosaura tiene un problema con su vivienda. **¿Qué hace?**

- ✔ Habla con el enlace del PTAT en el consulado.
- Lo aguanta para no perder la temporada.
- Busca otra vivienda por su cuenta.

## M7 U01. El regreso

**Caso 1. Contrato terminado antes.** Don Efrén se regresa antes por su familia. **¿Qué hace?**

- ✔ Pregunta qué pasa con su regreso y sus pagos antes de irse.
- Se va sin avisar ni preguntar.
- Compra su boleto y no pide su último pago.

**Caso 2. El último día.** Rosaura suele dejar todo para el final. **¿Qué hace?**

- ✔ Hace su lista una semana antes.
- Lo deja todo para el último día.
- Hace su lista ya estando en México.

**Caso 3. La W-2 tardía.** La W-2 de Juan Carlos llega hasta enero. **¿Qué hace?**

- ✔ Deja su dirección de México y su correo.
- Se olvida de la forma ese año.
- Se queda allá hasta que llegue.

## M7 U02. Los meses sin temporada

**Caso 1. Marzo sin dinero.** A Don Efrén se le acaba el ahorro en marzo. **¿Qué hace?**

- ✔ Divide su ahorro entre los meses hasta la siguiente temporada.
- Pide prestado en marzo como cada año.
- Gasta igual y espera que alcance.

**Caso 2. Diciembre.** Juan Carlos quiere gastar mucho en las fiestas. **¿Qué hace?**

- ✔ Pone un tope antes de llegar.
- Gasta lo que quiera porque se lo ganó.
- Pide un préstamo para las fiestas.

**Caso 3. Trabajo aquí.** Rosaura puede vender comida en el pueblo. **¿Qué hace?**

- ✔ Lo cuenta como ingreso para que el ahorro dure más.
- No lo cuenta porque es poco.
- Deja de vender para descansar.

## M7 U03. ¿Otra temporada?

**Caso 1. «Allá se gana más».** El papá de Juan Carlos dice que siempre conviene ir. **¿Qué hace?**

- ✔ Hace la cuenta completa.
- Le hace caso a su papá sin hacer cuentas.
- Decide no volver sin hacer cuentas.

**Caso 2. Sin meta.** Ramiro vuelve cada año sin saber para qué. **¿Qué hace?**

- ✔ Define una meta antes de la siguiente temporada.
- Sigue yendo cada año sin pensar para qué.
- Deja de ir sin tener otro ingreso.

**Caso 3. La familia.** La esposa de Juan Carlos quiere opinar. **¿Qué hacen?**

- ✔ Deciden juntos con los números.
- Él decide solo porque es quien trabaja allá.
- Ella decide sola sin ver números.

## M8 U01. Tu retiro: Canadá, Estados Unidos y México

**Caso 1. «No cuenta para nada».** Rosaura cree que sus temporadas no cuentan. **¿Qué hace?**

- ✔ Guarda sus T4 y pregunta por el convenio México-Canadá.
- Tira sus T4 porque cree que no cuentan.
- Espera a cumplir 65 para preguntar.

**Caso 2. Sin pensión allá.** Don Efrén no cotiza al Seguro Social de EE. UU. **¿Qué hace?**

- ✔ Aporta a su Afore cada mes de temporada.
- Pide que le retengan Seguro Social allá.
- Deja el retiro para cuando deje de ir.

**Caso 3. Afore desconocida.** Juan Carlos no sabe si tiene Afore. **¿Qué hace?**

- ✔ La busca con su CURP en AforeMóvil.
- Abre otra Afore nueva sin buscar la suya.
- Supone que no tiene y no hace nada.

## M8 U02. Un proyecto que produce

**Caso 1. Solo la casa.** Don Efrén invirtió todo en la casa. **¿Qué hace ahora?**

- ✔ Suma una meta que produzca ingreso.
- Sigue arreglando la casa cada año.
- Compra una camioneta grande para lucirla.

**Caso 2. Todo de golpe.** Juan Carlos quiere comprar 50 animales con todo su ahorro. **¿Qué hace?**

- ✔ Prueba primero con pocos.
- Compra los 50 animales de una vez.
- Pide prestado para comprar 100.

**Caso 3. El dinero mezclado.** Rosaura usa el dinero del proyecto para gastos de la casa. **¿Qué hace?**

- ✔ Lo separa en otra cuenta.
- Sigue usando el mismo dinero para todo.
- Lo presta a su hermana mientras tanto.

## M8 U03. Tu plan de temporada en una página

**Caso 1. Papeles separados.** Rosaura tiene todo en papeles distintos. **¿Qué hace?**

- ✔ Junta todo en su plan de una página.
- Sigue con sus papeles en lugares distintos.
- Hace un plan nuevo cada semana.

**Caso 2. Todo hoy.** Juan Carlos quiere resolverlo todo antes de mañana. **¿Qué hace?**

- ✔ Escribe una acción con fecha para cada parte.
- Intenta resolverlo todo en un día.
- Lo deja para la siguiente temporada.

**Caso 3. La familia no sabe.** Doña Imelda no conoce el plan de Don Efrén. **¿Qué hacen?**

- ✔ Lo revisan juntos antes de que se vaya.
- Él lo guarda y no se lo enseña.
- Se lo explica por teléfono ya allá.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Dónde te registras para el PTAT a Canadá?

- Con un reclutador privado que cobra cuota
- ✔ En el Servicio Nacional de Empleo
- En la tienda del pueblo, con un anuncio

*¡Correcto! SNE.*

**M1 U01 P2.** ¿Cuánto cuesta el servicio del PTAT?

- ✔ Nada
- 8,000 pesos
- Una parte del primer pago

*¡Correcto! Sin costo.*

**M1 U01 P3.** En la H-2A, ¿quién paga el reclutamiento?

- El trabajador
- La familia
- ✔ El empleador

*¡Correcto! El empleador.*

**M1 U02 P1.** Te cobran por asegurar tu lugar. ¿Qué es?

- Normal
- Una cuota oficial
- ✔ Fraude

*¡Correcto! Es fraude.*

**M1 U02 P2.** ¿Dónde verificas el PTAT a Canadá?

- ✔ En el Servicio Nacional de Empleo
- En grupos de chat de paisanos
- Con el reclutador

*¡Correcto! SNE.*

**M1 U02 P3.** Ya pagaste a un reclutador falso. ¿Qué haces?

- Nada
- ✔ Juntas pruebas y denuncias
- Pagas más para que te contesten

*¡Correcto! Denuncia.*

**M1 U03 P1.** Tu contrato H-2A es de 800 horas. ¿Cuántas te garantizan como mínimo?

- ✔ 600
- 800
- 400

*¡Correcto! 3/4 de 800.*

**M1 U03 P2.** ¿Hasta cuándo debes regresar de Canadá con el PTAT?

- ✔ Al 15 de diciembre
- Cuando quieras
- En febrero

*¡Correcto! 15 de diciembre.*

**M1 U03 P3.** ¿En qué idioma tienes derecho a tu contrato?

- Solo en inglés
- ✔ En español
- En ninguno

*¡Correcto! Español.*

## Módulo 2

**M2 U01 P1.** Pides 10,000 al 10% mensual. ¿Cuánto pagas de interés al mes?

- 100
- ✔ 1,000
- 10,000

*¡Correcto! 10% de 10,000.*

**M2 U01 P2.** ¿Qué haces antes de pedir prestado para irte?

- Pides lo que te ofrezcan, sin hacer cuentas
- ✔ Haces la lista de lo que sí pagas tú
- Pides el doble por si acaso falta algo

*¡Correcto! La lista.*

**M2 U01 P3.** ¿Qué te deben reembolsar?

- Nada
- Tu comida en México
- ✔ La cuota de la visa

*¡Correcto! La visa.*

**M2 U02 P1.** ¿A dónde mandas el dinero?

- Con un compadre de confianza del pueblo
- ✔ A la cuenta de quien administra en México
- En efectivo con un conocido

*¡Correcto! Directo.*

**M2 U02 P2.** Hace falta un poder para trámites. ¿De qué tipo?

- Uno amplio para todo, sin fecha
- ✔ Uno limitado con fecha
- Ninguno: le das tu tarjeta y tu NIP

*¡Correcto! Limitado.*

**M2 U02 P3.** ¿Qué dejan acordado?

- Nada
- Solo cómo van a pintar y arreglar la casa
- ✔ Quién administra, qué se paga y cuándo hablan

*¡Correcto! El acuerdo.*

**M2 U03 P1.** ¿Qué se necesita para las primeras semanas de la temporada?

- Un préstamo caro
- ✔ Ahorro previo
- Nada

*¡Correcto! Ahorro previo.*

**M2 U03 P2.** Llega un envío de 5,000 y ahorran 20%. ¿Cuánto ahorran?

- ✔ 1,000
- 500
- 2,000

*¡Correcto! 20% de 5,000.*

**M2 U03 P3.** ¿Cada cuándo revisan juntos?

- Nunca
- Al terminar la temporada
- ✔ Cada semana

*¡Correcto! Cada semana.*

## Módulo 3

**M3 U01 P1.** ¿Qué trae tu talón de pago?

- Solo tu nombre, la fecha y el empleador
- ✔ Horas, lo que ganaste y descuentos
- Las horas que te faltan para el bono

*¡Correcto! Los tres.*

**M3 U01 P2.** Te descuentan renta de la vivienda H-2A. ¿Qué haces?

- ✔ Preguntas, porque es sin costo
- Lo aceptas porque así viene en el talón
- Pagas y luego lo reclamas en México

*¡Correcto! Sin costo.*

**M3 U01 P3.** ¿Qué son el CPP y el EI en tu talón de Canadá?

- Multas por faltas o retrasos en el trabajo
- Comisiones del banco por el depósito
- ✔ Cotizaciones de pensión y seguro de empleo

*¡Correcto! Cotizaciones.*

**M3 U02 P1.** ¿Qué es lo mínimo que te deben pagar?

- Lo que quiera el encargado
- Lo mismo que en México
- ✔ Lo que diga tu contrato

*¡Correcto! El contrato.*

**M3 U02 P2.** En Canadá con el PTAT, ¿quién te apoya si no corrigen tu pago?

- ✔ El enlace del PTAT en el consulado de México
- El reclutador que te llevó al programa
- Nadie, lo resuelves tú solo

*¡Correcto! El consulado.*

**M3 U02 P3.** En EE. UU., ¿a quién llamas si no corrigen tu pago?

- Al reclutador que te contrató en México
- ✔ A la División de Horas y Salarios
- A nadie, para no perder la temporada

*¡Correcto! Horas y Salarios.*

**M3 U03 P1.** Un cheque de 500 con 3% de comisión. ¿Cuánto pierdes?

- 3
- ✔ 15
- 150

*¡Correcto! 3% de 500.*

**M3 U03 P2.** ¿Qué opción suele ser más barata que cambiar cheques en tiendas?

- ✔ Depósito directo
- Guardar los cheques
- Cambiar en otra tienda

*¡Correcto! Depósito directo.*

**M3 U03 P3.** Tienes mucho efectivo en la vivienda. ¿Qué haces?

- ✔ Lo mandas a casa o lo dejas en tu cuenta
- Lo escondes en la maleta de la vivienda
- Lo prestas a compañeros que te lo pidan

*¡Correcto! Mándalo.*

## Módulo 4

**M4 U01 P1.** ¿Qué comparas entre empresas de envío?

- El color del anuncio
- ✔ Los pesos que llegan
- La música de la tienda

*¡Correcto! Lo que llega.*

**M4 U01 P2.** Un envío «sin comisión»…

- ✔ puede pagar un tipo de cambio más bajo
- siempre es el mejor, porque no cobra nada
- no está permitido por la ley

*¡Correcto! Revisa el cambio.*

**M4 U01 P3.** Cada envío cobra 8 dólares. ¿Cuánto ahorras al mandar 12 veces en vez de 24?

- Nada
- 8 dólares, lo mismo que la comisión
- ✔ 96 dólares

*¡Correcto! 12 por 8.*

**M4 U02 P1.** ¿Cuáles son las partes del plan?

- Fiestas, regalos y compras grandes
- ✔ Básico, deudas, ahorro y meta
- Todo a la casa, sin apartar nada

*¡Correcto! Cuatro partes.*

**M4 U02 P2.** Llega un envío de 6,000 y ahorran 20%. ¿Cuánto es?

- ✔ 1,200
- 600
- 2,000

*¡Correcto! 20% de 6,000.*

**M4 U02 P3.** ¿Cuándo acuerdan el plan?

- Nunca: se decide sobre la marcha
- Al final de la temporada, ya de regreso
- ✔ Antes de la temporada

*¡Correcto! Antes.*

**M4 U03 P1.** ¿Dónde es más seguro tu ahorro?

- En la maleta, para traerlo de regreso
- ✔ En una cuenta a tu nombre
- Con un compañero de la vivienda

*¡Correcto! Cuenta tuya.*

**M4 U03 P2.** ¿Por qué separar el ahorro del gasto de la casa?

- ✔ Para no tocarlo
- Por moda
- Para pagar más comisiones

*¡Correcto! No tocarlo.*

**M4 U03 P3.** Te prometen duplicar tu ahorro en seis meses. ¿Qué haces?

- Inviertes la mitad para probar
- Inviertes todo para ganar más rápido
- ✔ Desconfías y verificas

*¡Correcto! Desconfía.*

## Módulo 5

**M5 U01 P1.** ¿El salario H-2A paga Seguro Social de EE. UU.?

- Sí, el doble
- ✔ No
- Solo el primer mes

*¡Correcto! No.*

**M5 U01 P2.** ¿Está obligado el empleador a retener impuesto federal?

- Solo en los meses de invierno
- Sí, siempre retiene el 30%
- ✔ No, solo si lo acuerdan

*¡Correcto! Voluntario.*

**M5 U01 P3.** ¿Qué papel guardas para tus impuestos?

- ✔ El W-2
- El boleto de avión
- Nada

*¡Correcto! W-2.*

**M5 U02 P1.** ¿Qué es el CPP?

- Una multa por llegar tarde
- ✔ El Plan de Pensiones de Canadá
- El pago de la renta de la vivienda

*¡Correcto! Pensión.*

**M5 U02 P2.** ¿Por qué presentar tu declaración en Canadá?

- No sirve, ya te retuvieron todo
- Para pagar más impuesto del que debes
- ✔ Puede darte reembolso y cuida tu pensión

*¡Correcto! Reembolso y CPP.*

**M5 U02 P3.** ¿Qué forma te da el empleador?

- ✔ La T4
- La W-2
- Ninguna

*¡Correcto! T4.*

**M5 U03 P1.** ¿Qué va en tu carpeta?

- ✔ Contratos, talones y W-2 o T4
- Solo fotos de la cosecha y del grupo
- Nada

*¡Correcto! Los tres.*

**M5 U03 P2.** ¿Dónde guardas copias?

- Con el reclutador que te contrató
- Solo en la maleta, todos juntos
- ✔ En tu correo o con tu familia

*¡Correcto! Respaldo.*

**M5 U03 P3.** Te piden tu número de Seguro Social para «un trámite». ¿Qué haces?

- Lo das para no quedar mal
- ✔ No lo das si no es necesario
- Le mandas una foto de tu tarjeta

*¡Correcto! Protégelo.*

## Módulo 6

**M6 U01 P1.** ¿Quién guarda tu pasaporte?

- El encargado
- ✔ Tú
- El reclutador

*¡Correcto! Tú.*

**M6 U01 P2.** Te amenazan si te quejas. ¿Qué es?

- ✔ Una represalia que no está permitida
- Normal en los campos de cultivo
- Parte de lo que firmaste en el contrato

*¡Correcto! Represalia.*

**M6 U01 P3.** ¿Quién da el equipo de protección?

- Tú lo compras
- Tus compañeros
- ✔ El empleador

*¡Correcto! El empleador.*

**M6 U02 P1.** Te lastimas trabajando. ¿Qué haces primero?

- Te aguantas para no perder el día
- ✔ Pides atención y que se reporte
- Te vas a México a curarte allá

*¡Correcto! Atención y reporte.*

**M6 U02 P2.** ¿Te pueden presionar para no reportar un accidente?

- Sí
- ✔ No
- Solo si es leve

*¡Correcto! No.*

**M6 U02 P3.** ¿Qué guardas?

- Solo la venda y la medicina
- Nada, ya te atendieron
- ✔ Reporte, recetas y comprobantes

*¡Correcto! Comprobantes.*

**M6 U03 P1.** ¿Cuál es tu primer apoyo en el extranjero?

- El reclutador que te contrató
- ✔ El consulado de México
- Nadie, lo resuelves tú solo

*¡Correcto! Consulado.*

**M6 U03 P2.** No los dejan salir de la vivienda. ¿Qué hacen?

- Esperan a que termine la temporada
- ✔ Llaman al 911 o a la línea contra la trata
- Se callan para no perder el trabajo

*¡Correcto! Emergencia.*

**M6 U03 P3.** En Canadá, ¿quién apoya a trabajadores del PTAT?

- Nadie, lo resuelves tú solo
- El vendedor de tarjetas telefónicas
- ✔ El enlace del PTAT en el consulado

*¡Correcto! Enlace.*

## Módulo 7

**M7 U01 P1.** ¿Hasta cuándo es el regreso en el PTAT?

- ✔ Al 15 de diciembre
- En marzo del año siguiente
- Cuando tú lo decidas, sin fecha fija

*¡Correcto! 15 de diciembre.*

**M7 U01 P2.** ¿Cuándo haces tu lista de salida?

- En México, cuando ya regresaste
- El último día, antes de subirte
- ✔ Una semana antes

*¡Correcto! Antes.*

**M7 U01 P3.** Tu forma de impuestos llega después. ¿Qué haces?

- ✔ Dejas tu dirección de México y tu correo
- Nada, ese año ya no declaras
- Te quedas allá a esperarla

*¡Correcto! Deja tus datos.*

**M7 U02 P1.** Tienes 18,000 de ahorro y 6 meses. ¿Cuánto puedes usar al mes?

- ✔ 3,000
- 18,000
- 6,000

*¡Correcto! 18,000 entre 6.*

**M7 U02 P2.** ¿Qué haces con diciembre?

- Gastas todo
- Pides prestado
- ✔ Pones un tope

*¡Correcto! Tope.*

**M7 U02 P3.** ¿Qué haces con lo que ganas en México?

- ✔ Lo cuentas para que el ahorro dure más
- No lo cuentas porque es poco
- Lo gastas en las fiestas

*¡Correcto! Súmalo.*

**M7 U03 P1.** La temporada te deja 80,000 netos y aquí ganarías 35,000. ¿Cuánto te deja de verdad irte?

- ✔ 45,000
- 80,000
- 115,000

*¡Correcto! 80,000 menos 35,000.*

**M7 U03 P2.** ¿Con qué conviene volver?

- Con deudas nuevas para el viaje
- Sin plan, como cada año
- ✔ Con una meta clara

*¡Correcto! Meta.*

**M7 U03 P3.** ¿Quién decide?

- Tú solo, porque trabajas allá
- ✔ Tu familia y tú, con números
- El reclutador que te contrata

*¡Correcto! En familia.*

## Módulo 8

**M8 U01 P1.** ¿Qué es el CPP?

- Una multa por faltar al trabajo
- ✔ El Plan de Pensiones de Canadá
- Un seguro de auto obligatorio

*¡Correcto! CPP.*

**M8 U01 P2.** ¿Te da pensión en EE. UU. la temporada H-2A?

- Sí, después de la primera temporada
- ✔ No, porque no cotizas al Seguro Social
- Solo después de 10 temporadas

*¡Correcto! No cotizas.*

**M8 U01 P3.** ¿Desde cuánto puedes aportar a tu Afore?

- No se puede
- 5,000 pesos
- ✔ 50 pesos

*¡Correcto! Desde 50.*

**M8 U02 P1.** ¿Cuál es una meta que produce?

- Una pantalla grande
- ✔ Un invernadero
- Una fiesta

*¡Correcto! Produce.*

**M8 U02 P2.** ¿Qué haces antes de invertir todo?

- ✔ Pruebas en pequeño
- Pides prestado más
- Nada

*¡Correcto! En pequeño.*

**M8 U02 P3.** La meta cuesta 30,000 y mandas 20 envíos. ¿Cuánto por envío?

- 600
- 3,000
- ✔ 1,500

*¡Correcto! 30,000 entre 20.*

**M8 U03 P1.** ¿Qué lleva cada parte?

- Solo lo que ya hiciste en la temporada
- ✔ La siguiente acción y una fecha
- Una lista de compras de la casa

*¡Correcto! Acción y fecha.*

**M8 U03 P2.** ¿Cuándo revisas tu plan?

- ✔ Antes de irte y al regresar
- Cada diez años, cuando cambie algo
- Nunca, una vez escrito ya quedó

*¡Correcto! Antes y después.*

**M8 U03 P3.** ¿Con quién compartes el plan?

- Con nadie
- Con el reclutador
- ✔ Con tu familia

*¡Correcto! Tu familia.*
