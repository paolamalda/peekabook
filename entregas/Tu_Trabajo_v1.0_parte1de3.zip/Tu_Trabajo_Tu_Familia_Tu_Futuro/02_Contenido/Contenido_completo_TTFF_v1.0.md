# Tu Trabajo, Tu Familia, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Módulo 1. Lo que ganas por día o por quincena

## M1 U01. ¿Cuánto te entra al mes?

**Lo que lograrás:** Calcular cuánto dinero te entra de verdad en un mes, cobres por día (de entrada por salida) o por semana o quincena (de planta), y compararlo con el salario mínimo 2026 para trabajadoras del hogar.

**Para empezar:** Doña Tere trabaja de entrada por salida en cuatro casas y dice que gana «como 12 mil». Cuando sumó lo que cobró el mes pasado le salieron 9,350: dos casas cancelaron y una semana no hubo trabajo. En esta lección sabrás cuánto te entra de verdad.

### Lo esencial (5 minutos)

#### Por día o por quincena

Si trabajas **de entrada por salida**, cobras por día y cada día puede ser una casa distinta: lo que te entra depende de cuántos días trabajas. Si trabajas **de planta**, cobras por semana o por quincena y tu ingreso es más parejo. En los dos casos, lo que importa para tus cuentas es lo que **de verdad te entra** en el mes.



#### El mes de Doña Tere (por día)

Doña Tere cobra 550 por día. El mes pasado trabajó 17 días, no 22.
- Pago por día: **550**
- Días que sí trabajó: **17**
- Lo que le entró en el mes: **9,350**
Para su presupuesto usa lo que le entra en un mes flojo, no en el mejor.


#### Cómo cobras y cómo calcular

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| De entrada por salida | Pago por día × días trabajados. | Cuenta los días que se cancelan. |
| De planta por semana | Pago por semana × 4.3. | Un mes tiene unas 4.3 semanas. |
| De planta por quincena | Pago por quincena × 2. | El más parejo. |

#### El salario mínimo de tu trabajo

Para las trabajadoras del hogar hay un **salario mínimo profesional**: en 2026 es de 342.47 pesos por día de trabajo completo, más alto que el general. Con ese salario no te deben descontar ISR.

> **Dato vigente:** salario mínimo profesional 2026 para personas trabajadoras del hogar de 342.47 pesos diarios en la zona general (unos 10,400 al mes) y de 440.87 diarios en la Zona Libre de la Frontera Norte. Consultado el 30 de septiembre de 2026 a través de la CONASAMI.

> **Idea clave:** haz tus cuentas con lo que te entra en un mes flojo, no con lo que ganas en tu mejor mes.



#### Comprueba lo que entendiste

1. Cobras 500 por día y trabajaste 18 días. ¿Cuánto te entró?
*Respuesta:* 9,000.

2. ¿Con qué mes haces tu presupuesto?
*Respuesta:* Con un mes flojo, para que te alcance siempre.


#### Para recordar

- Por día: pago por días trabajados.
- De planta: semana × 4.3 o quincena × 2.
- Presupuesto con el mes flojo.



### Profundiza (5 minutos más)

#### Lo que hace que un mes sea flojo

| Motivo | Qué hacer |
|---|---|
| Una casa cancela | Acuerda aviso con tiempo o pago del día |
| Vacaciones de la familia | Pregunta si pagan esos días |
| Te enfermas | Ten un fondo para esos días (M3) |
| Diciembre y Semana Santa | Anótalos en tu calendario |



#### Anota lo que cobras

Durante un mes anota cada día qué casa, cuánto cobraste y si te pagaron pasajes. Con esa hoja sabrás tu mes flojo, tu mes bueno y qué casa te conviene más.



#### Casos


**Caso 1. El mes de Doña Tere**

Doña Tere hace sus cuentas con «12 mil», pero le entraron 9,350.
- *¿Qué hace?* Hace su presupuesto con lo que le entra en un mes flojo.


**Caso 2. La quincena de Mari**

Mari trabaja de planta y cobra 6,000 por quincena.
- *¿Cuánto le entra al mes?* 12,000, porque son dos quincenas.


**Caso 3. La casa que cancela de Chayo**

A Chayo una casa le cancela seguido el mismo día.
- *¿Qué hace?* Anota cuántos días pierde y lo platica con la familia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar con el mejor mes | No te alcanza | Usa el mes flojo |
| No anotar lo que cobras | No sabes tu ingreso | Anótalo un mes |
| Olvidar los días cancelados | Te falta dinero | Réstalos |
| Confundir semana con mes | Te equivocas | Semana × 4.3 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Mari y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 600 por día y trabajas 15 días. ¿Cuánto te entra en el mes? a) 9,000 · b) 6,000 · c) 15,600
2. Trabajas de planta y cobras 2,500 por semana. ¿Cuánto te entra al mes, más o menos? a) 5,000 · b) 10,750 · c) 2,500
3. ¿Con qué mes conviene hacer el presupuesto? a) Con diciembre, que llega el aguinaldo · b) Con el mejor mes del año · c) Con un mes flojo
**Respuestas:** 1-a: 600 por 15. 2-b: 2,500 por 4.3 semanas. 3-c: así te alcanza siempre.



#### Ponlo en práctica

Cobras 500 por día en tres casas y 650 en otra. En el mes trabajaste 12 días de 500 y 4 de 650. ¿Cuánto te entró?
**Respuesta:** 12 por 500 son 6,000; 4 por 650 son 2,600. En total, 8,600.



#### A tu plan

Durante este mes, anota cada día qué casa, cuánto cobraste y si te pagaron pasajes.



### Para saber más

- **Salarios mínimos** (CONASAMI · español): https://www.gob.mx/conasami — **Qué buscar:** salarios mínimos 2026, trabajadoras del hogar.

### Palabras clave

- *Salario mínimo profesional:* el pago más bajo que la ley permite para un oficio; para trabajadoras del hogar es más alto que el general.
- *De entrada por salida:* trabajo en el que llegas y te vas el mismo día, y cobras por día.
- *De planta:* trabajo en una sola casa, con pago por semana o por quincena.

### Fuentes

CONASAMI, salarios mínimos 2026, consultado el 30 de septiembre de 2026.

---

## M1 U02. Tu dinero de la semana

**Lo que lograrás:** Repartir el dinero que cobras cada día o cada semana para que alcance toda la semana, con sobres o apartados.

**Para empezar:** Chayo cobra cada día en una casa distinta. Llega a su casa con 500 en la bolsa y ese mismo día se va la mitad en mandado, pasajes y lo que le piden. El jueves ya no tiene para la renta. En esta lección repartirás el dinero de tu semana.

### Lo esencial (5 minutos)

#### Piensa en semanas

Si cobras por día, el dinero entra en pedacitos y se va igual. Ayuda pensar en **semanas**: cuánto te entra en la semana y cuánto necesitas en la semana. Si cobras por quincena, divide la quincena en dos semanas.



#### Tres sobres para cada pago

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ahorro | Lo apartas primero. | Aunque sea poco. |
| Casa | Renta, luz, gas, comida, escuela. | Lo fijo primero. |
| Trabajo y semana | Pasajes, comida fuera, recargas. | Lo que usas para trabajar. |

#### La semana de Chayo

Chayo trabaja 5 días a 500.
- Lo que le entra en la semana: **2,500**
- Ahorro, apartado primero: **250**
- Casa de la semana: **1,650**
- Para trabajo y semana: **600**
Si un día no hay trabajo, baja primero el sobre de la semana, no el de la casa.


#### Un caso en un minuto

Chayo usa tres sobres. Cada tarde, antes de hacer el mandado, reparte lo que cobró. Ahora la renta ya está junta el viernes.

> **Idea clave:** reparte cada pago el mismo día que cobras, antes de gastar: ahorro, casa y semana.



#### Comprueba lo que entendiste

1. ¿Cuándo repartes tu dinero?
*Respuesta:* El mismo día que cobras, antes de gastar.

2. Si un día no hay trabajo, ¿qué sobre bajas primero?
*Respuesta:* El de la semana, no el de la casa.


#### Para recordar

- Piensa en semanas.
- Tres sobres: ahorro, casa, semana.
- Reparte el día que cobras.



### Profundiza (5 minutos más)

#### Tu semana en una hoja

| Concepto | A la semana |
|---|---|
| Lo que te entra | |
| Ahorro (primero) | |
| Renta y servicios (renta del mes ÷ 4.3) | |
| Comida de la casa | |
| Escuela y otros | |
| Pasajes y comida del trabajo | |
| Pagos de deudas | |



#### Sobres de papel o apartados en el celular

Los sobres de papel funcionan si los guardas en casa, no en la bolsa. Si tienes cuenta, muchas apps permiten «apartados» o «cajitas» para separar el dinero sin sacarlo. Usa lo que te sea más fácil.



#### Casos


**Caso 1. La bolsa de Chayo**

Chayo lleva todo lo que cobra en la bolsa y lo gasta sin darse cuenta.
- *¿Qué hace?* Reparte el pago en sobres en su casa cada tarde.


**Caso 2. La renta de Doña Tere**

Doña Tere paga 3,000 de renta el día 1 y nunca la tiene junta.
- *¿Qué hace?* Aparta unos 700 cada semana para la renta.


**Caso 3. La semana sin trabajo de Mari**

A Mari le dieron una semana sin goce de sueldo.
- *¿Qué hace?* Recorta primero los gastos de la semana y cuida la renta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Llevar todo en la bolsa | Se va sin darte cuenta | Sobres en casa |
| Repartir al final de la semana | Ya no queda | Reparte el día que cobras |
| Recortar la renta primero | Te atrasas | Cuida lo fijo |
| Olvidar la renta del mes | Llega de golpe | Apártala cada semana |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Pagas 2,580 de renta al mes. ¿Cuánto apartas cada semana, más o menos? a) 2,580 · b) 600 · c) 1,290
2. ¿Qué sobre llenas primero cuando cobras? a) El de pasajes y comida · b) El de gustos · c) El de ahorro
3. ¿Dónde es mejor guardar los sobres? a) En tu casa · b) En la bolsa del trabajo · c) Con una vecina
**Respuestas:** 1-b: 2,580 entre 4.3 semanas. 2-c: el ahorro va primero. 3-a: si los cargas, se gastan.



#### Ponlo en práctica

Te entran 2,200 a la semana. Apartas 10% de ahorro y 1,400 para la casa. ¿Cuánto te queda para la semana?
**Respuesta:** 10% son 220. 2,200 menos 220 menos 1,400: 580.



#### A tu plan

Esta semana usa tres sobres o apartados: ahorro, casa y semana. Repártelos el día que cobres.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto personal».

### Palabras clave

- *Presupuesto:* plan de cuánto te entra y en qué lo vas a usar.
- *Apartado:* dinero que separas dentro de tu cuenta para una meta, sin sacarlo.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M1 U03. Los gastos chiquitos del trabajo

**Lo que lograrás:** Descubrir cuánto gastas al mes en pasajes entre casas, comida fuera, refrescos y recargas, y decidir qué cambiar.

**Para empezar:** Doña Tere va a dos casas algunos días y toma cuatro camiones. Compra un refresco y una torta cuando no le dan de comer. Nunca lo había sumado. En esta lección verás cuánto suman los gastos chiquitos.

### Lo esencial (5 minutos)

#### Lo que te cuesta ir a trabajar

Pasajes, comida, refrescos y recargas parecen poco porque se pagan de a poquito. Pero se repiten **cada día que trabajas**. Súmalos por día y multiplícalos por los días del mes.



#### Los gastos de Doña Tere

- Pasajes, torta y refresco por día: **120**
- Días que trabaja: **17**
- Al mes: **2,040**
Casi una cuarta parte de lo que le entra.


#### Qué puedes cambiar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comida | Lleva de casa o acuerda la comida. | Pregunta en cada casa. |
| Pasajes | Acuerda el pago de pasajes. | Pídelo al contratar. |
| Recargas | Un plan fijo sale más barato. | Compara. |
| Refrescos y antojos | Agua de casa. | Lo que más suma. |

#### Un caso en un minuto

Doña Tere empezó a llevar su comida los días que va a dos casas y pidió en una casa que le paguen los pasajes. Ahora ahorra unos 800 al mes.

> **Idea clave:** un gasto chiquito que se repite cada día que trabajas se vuelve grande; súmalo al mes.



#### Comprueba lo que entendiste

1. Gastas 60 en comida cada día y trabajas 20 días. ¿Cuánto al mes?
*Respuesta:* 1,200.

2. ¿Qué puedes pedir al contratar?
*Respuesta:* Que te paguen pasajes o te den de comer.


#### Para recordar

- Súmalo por día.
- Multiplica por los días que trabajas.
- Pide pasajes y comida al contratar.



### Profundiza (5 minutos más)

#### Tu cuenta de gastos chiquitos

| Gasto | Por día | Días | Al mes |
|---|---|---|---|
| Pasajes | | | |
| Comida | | | |
| Refrescos y café | | | |
| Recargas | | | |



#### Acordar pasajes y comida

Muchas familias pagan los pasajes o dan de comer. Si no lo hablaste al empezar, puedes decir: «Para seguir viniendo necesito que me apoyen con los pasajes, son 50 por día». Hablarlo con calma y con números ayuda.



#### Casos


**Caso 1. Los camiones de Doña Tere**

Doña Tere gasta 70 diarios en pasajes y nadie se los paga.
- *¿Qué hace?* Pide con calma que le apoyen con los pasajes y lo anota.


**Caso 2. La recarga de Chayo**

Chayo recarga 30 cada tercer día.
- *¿Qué hace?* Compara con un plan fijo al mes.


**Caso 3. La comida de Mari**

Mari trabaja de planta y compra comida afuera porque no sabe si puede usar la cocina.
- *¿Qué hace?* Pregunta y acuerda qué puede comer en la casa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No sumar los gastos chiquitos | Se comen tu ingreso | Súmalos al mes |
| No pedir pasajes | Pagas por trabajar | Acuérdalos |
| Recargas sueltas | Salen caras | Compara planes |
| Quitarte la comida | Te enfermas | Lleva de casa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastas 25 en refresco cada día y trabajas 20 días. ¿Cuánto al mes? a) 25 · b) 250 · c) 500
2. ¿Qué gasto del trabajo puedes acordar con la familia? a) Los pasajes · b) Tus recargas de la semana · c) Tus antojos
3. ¿Por qué suman tanto los gastos chiquitos? a) Porque son muy caros · b) Porque se repiten cada día · c) Porque tienen intereses
**Respuestas:** 1-c: 25 por 20. 2-a: muchas familias los pagan. 3-b: se repiten.



#### Ponlo en práctica

Gastas 50 en pasajes, 40 en comida y 15 en refresco cada día. Trabajas 18 días. ¿Cuánto al mes?
**Respuesta:** 105 por día por 18 días: 1,890.



#### A tu plan

Llena tu cuenta de gastos chiquitos y elige uno que vas a cambiar esta semana.



### Para saber más

- **Gastos hormiga** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «gastos hormiga».

### Palabras clave

- *Gasto hormiga:* gasto pequeño que se repite y, sumado, es grande.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M1 U04. Aparta primero

**Lo que lograrás:** Apartar ahorro el mismo día que cobras, aunque sea poco, antes de gastar.

**Para empezar:** Mari siempre dice: «Ahorro lo que sobre». Nunca sobra. Su hijo entra a la prepa el próximo año y no tiene nada junto. En esta lección aprenderás a apartar primero.

### Lo esencial (5 minutos)

#### Primero tú

Si ahorras lo que sobra, casi nunca sobra. Si **apartas primero**, el mismo día que cobras, te acostumbras a vivir con el resto. No importa que sea poco: lo que cuenta es hacerlo siempre.



#### El ahorro de Chayo

Chayo aparta 50 cada día que trabaja.
- Por día: **50**
- Días al mes: **20**
- Al mes: **1,000**
En un año son 12,000.


#### Dónde guardar tu ahorro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta aparte | Protegida y no la ves diario. | La mejor opción. |
| Sobre en casa | Fácil, pero se puede tomar. | Para empezar. |
| Tanda | Ayuda a comprometerte. | Tiene riesgos (M3). |
| En la bolsa | Se gasta. | Evítalo. |

#### Un caso en un minuto

Mari abrió una cuenta básica sin comisiones solo para ahorrar. Cada quincena transfiere 600 apenas le pagan. En un año tendrá 14,400 para la prepa de su hijo.

> **Idea clave:** aparta tu ahorro el mismo día que cobras, antes de gastar; poco pero siempre.



#### Comprueba lo que entendiste

1. ¿Cuándo apartas tu ahorro?
*Respuesta:* El mismo día que cobras.

2. ¿Dónde es mejor guardarlo?
*Respuesta:* En una cuenta aparte, que no uses diario.


#### Para recordar

- Primero tú.
- Poco pero siempre.
- En un lugar aparte.



### Profundiza (5 minutos más)

#### Si apartas…

| Por día trabajado (20 días) | Al mes | Al año |
|---|---|---|
| 20 | 400 | 4,800 |
| 50 | 1,000 | 12,000 |
| 100 | 2,000 | 24,000 |



#### Ahorrar cuando todo el dinero va a la familia

Si tu dinero sostiene a varias personas, apartar para ti puede sentirse egoísta. No lo es: tu ahorro es lo que protege a la familia cuando te enfermas o no hay trabajo.



#### Casos


**Caso 1. El ahorro de Mari**

Mari ahorra lo que sobre al final de la quincena.
- *¿Qué hace?* Aparta 600 el día que le pagan, antes de gastar.


**Caso 2. El sobre de Doña Tere**

Doña Tere guarda el ahorro en un sobre y lo toma cuando le piden.
- *¿Qué hace?* Lo pasa a una cuenta aparte que no usa diario.


**Caso 3. La culpa de Chayo**

Chayo siente culpa de ahorrar mientras su mamá necesita.
- *¿Qué hace?* Ahorra poco pero siempre, porque también protege a su mamá.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ahorrar lo que sobra | Nunca sobra | Aparta primero |
| Guardar en la bolsa | Se gasta | Cuenta aparte |
| Esperar a ganar más | Nunca empiezas | Empieza con poco |
| Sentir culpa | Dejas de ahorrar | Tu ahorro protege a todos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Doña Tere y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Apartas 30 cada día y trabajas 20 días al mes. ¿Cuánto ahorras en un año? a) 7,200 · b) 600 · c) 3,600
2. ¿Qué es apartar primero? a) Ahorrar lo que te sobra al terminar el fin de semana · b) Ahorrar solo en diciembre · c) Ahorrar el día que cobras, antes de gastar
3. ¿Dónde es más fácil que el ahorro no se gaste? a) En la bolsa del trabajo · b) En una cuenta aparte · c) Prestado a un familiar
**Respuestas:** 1-a: 30 por 20 por 12. 2-c: primero tú. 3-b: no lo ves diario.



#### Ponlo en práctica

Mari cobra 6,000 por quincena y quiere ahorrar 10%. ¿Cuánto aparta cada quincena y cuánto junta en un año?
**Respuesta:** 600 por quincena; 24 quincenas: 14,400.



#### A tu plan

Decide cuánto vas a apartar cada día que cobres y dónde lo vas a guardar. Empieza en tu próximo pago.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica» y «ahorro».

### Palabras clave

- *Ahorro:* dinero que guardas hoy para usarlo después.
- *Cuenta básica:* cuenta de banco sin comisión por manejo que todos los bancos deben ofrecer.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M1 U05. Compra inteligente: abonos, precios y pagos chiquitos

**Lo que lograrás:** Comparar precios por unidad, calcular lo que de verdad cuesta comprar en abonos semanales y esperar antes de comprar.

**Para empezar:** Doña Tere quiere una lavadora. En la tienda le ofrecen «solo 189 a la semana». Le pareció poco. En esta lección sabrás cuánto pagaría en total y cómo decidir.

### Lo esencial (5 minutos)

#### El precio que no te dicen

Los abonos chiquitos se anuncian por semana para que parezcan poco. Lo que importa es el **total**: abono por número de semanas. Compáralo con el precio de contado.



#### La lavadora de Doña Tere

- Abono por semana: **189**
- Semanas (dos años): **104**
- Total en abonos: **19,656**
De contado cuesta 8,900. En abonos pagaría más del doble.


#### Antes de comprar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Suma el total | Abono × semanas. | Compara con el contado. |
| Precio por unidad | Precio ÷ cantidad. | El grande no siempre sale mejor. |
| Espera un día | Si lo sigues queriendo, decide. | Evita compras de impulso. |
| «Solo hoy» | Presión para comprar. | Desconfía. |

#### Un caso en un minuto

Doña Tere sumó el total y decidió juntar 200 a la semana en su ahorro. En 45 semanas tendrá la lavadora de contado y se ahorra más de 10 mil.

> **Idea clave:** en los abonos mira siempre el total; si puedes esperar, juntar y pagar de contado sale mucho más barato.



#### Comprueba lo que entendiste

1. ¿Cómo sabes cuánto pagas en abonos?
*Respuesta:* Abono por número de semanas.

2. ¿Qué haces ante un «solo hoy»?
*Respuesta:* Esperas un día y comparas.


#### Para recordar

- Mira el total, no el abono.
- Compara precio por unidad.
- Espera un día.



### Profundiza (5 minutos más)

#### Precio por unidad

| Producto | Precio | Cantidad | Por litro |
|---|---|---|---|
| Detergente chico | 32 | 1 litro | 32 |
| Detergente grande | 95 | 3 litros | 31.7 |
| Detergente de oferta | 60 | 1.5 litros | 40 |



#### Suscripciones y cobros que se repiten

Paquetes de datos, apps y servicios que se cobran cada mes suman mucho al año. Revisa tus cobros y cancela los que no usas.



#### Casos


**Caso 1. La lavadora de Doña Tere**

Le ofrecen 189 a la semana por dos años.
- *¿Qué hace?* Suma el total, lo compara con el contado y junta para pagarla.


**Caso 2. El detergente de Chayo**

Chayo compra siempre el más grande porque cree que sale más barato.
- *¿Qué hace?* Calcula el precio por litro de cada uno.


**Caso 3. El celular de Mari**

Un vendedor le dice a Mari que la oferta es «solo hoy».
- *¿Qué hace?* Espera un día y compara en otras tiendas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el abono | Pagas el doble | Suma el total |
| Creer que lo grande es más barato | No siempre | Precio por unidad |
| Comprar por presión | Te arrepientes | Espera un día |
| Olvidar las suscripciones | Suman al año | Revísalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un celular cuesta 99 a la semana por 78 semanas. ¿Cuánto pagas en total? a) 99 · b) 7,722 · c) 3,900
2. ¿Qué haces ante una oferta «solo hoy»? a) Esperar un día y comparar · b) Comprar antes de que se acabe · c) Pedir prestado para aprovecharla
3. Aceite de 1 litro a 42 o de 3 litros a 135. ¿Cuál es más barato por litro? a) Los dos cuestan igual · b) El de 3 litros · c) El de 1 litro
**Respuestas:** 1-b: 99 por 78. 2-a: la presión es para que no compares. 3-c: 42 contra 45 por litro.



#### Ponlo en práctica

Una licuadora cuesta 1,200 de contado o 79 a la semana por 26 semanas. ¿Cuánto pagas de más en abonos?
**Respuesta:** 79 por 26: 2,054. Pagas 854 de más.



#### A tu plan

Antes de tu próxima compra en abonos, suma el total y compáralo con el contado.



### Para saber más

- **Compras a crédito** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «compras a crédito» y «Quién es quién en los precios».

### Palabras clave

- *Abono:* pago pequeño que haces cada semana o quincena por algo que compraste a crédito.
- *Precio por unidad:* lo que cuesta cada litro, kilo o pieza.

### Fuentes

PROFECO y CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 2. Módulo 2. Tu trabajo vale

## M2 U01. Tus derechos: lo que la ley dice de tu trabajo

**Lo que lograrás:** Conocer tus derechos como trabajadora del hogar (salario, aguinaldo, vacaciones, descanso y contrato) para platicarlos con calma con quien te contrata.

**Para empezar:** Mari lleva seis años de planta en la misma casa. Nunca ha tomado vacaciones pagadas y en diciembre le dan «lo que se puede». No sabe si le toca algo más. En esta lección conocerás tus derechos.

### Lo esencial (5 minutos)

#### Tu trabajo está en la ley

La Ley Federal del Trabajo tiene un capítulo para las personas trabajadoras del hogar. Aplica si trabajas **de planta** o **de entrada por salida**. Cuando trabajas por días en varias casas, cada casa te debe la parte que le toca según los días que trabajas con ella.



#### Tus derechos principales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Salario mínimo profesional | 342.47 por día completo en 2026. | Más alto que el general. |
| Aguinaldo | Al menos 15 días de salario al año. | Antes del 20 de diciembre. |
| Vacaciones pagadas | 12 días desde el primer año, más prima de 25%. | Suben con los años. |
| Descanso | Día y medio a la semana; de planta, 9 horas seguidas en la noche. | Y 3 horas entre la mañana y la tarde. |

#### El aguinaldo de Chayo en una casa

Chayo trabaja en una casa un día a la semana (52 días al año) y cobra 600.
- Días al año en esa casa: **52**
- Días del año: **365**
- Días de aguinaldo: **15**
- Días de aguinaldo que le toca en esa casa: **2.1**
Unos 1,280 pesos (2.1 por 600).

> **Dato vigente:** Ley Federal del Trabajo, capítulo XIII (personas trabajadoras del hogar, artículos 331 a 343), aguinaldo de 15 días (artículo 87) y vacaciones de 12 días desde el primer año con prima de 25% (artículos 76 y 80). Consultado el 30 de septiembre de 2026 a través de la PROFEDET y el Diario Oficial de la Federación.


#### Un caso en un minuto

Mari se informó y platicó con la señora con un papel en la mano: sus años, sus vacaciones y su aguinaldo. Acordaron sus vacaciones de este año y el aguinaldo completo en diciembre.

> **Idea clave:** tus derechos existen aunque no tengas contrato; conocerlos te ayuda a platicarlos con calma y con números.



#### Comprueba lo que entendiste

1. ¿Te toca aguinaldo si trabajas por días?
*Respuesta:* Sí, la parte proporcional en cada casa.

2. ¿Cuántos días de vacaciones pagadas te tocan desde el primer año?
*Respuesta:* 12, más una prima de 25%.


#### Para recordar

- Tus derechos aplican de planta y por días.
- Aguinaldo, vacaciones, descanso.
- Sin contrato también tienes derechos.



### Profundiza (5 minutos más)

#### Vacaciones según tus años

| Años trabajados | Días de vacaciones |
|---|---|
| 1 | 12 |
| 2 | 14 |
| 3 | 16 |
| 4 | 18 |
| 5 | 20 |
| 6 a 10 | 22 |



#### Cómo platicarlo sin pelear

Elige un momento tranquilo. Lleva tus números en un papel: fecha en que empezaste, días que trabajas y lo que te toca. Di lo que necesitas y pregunta cómo lo pueden acordar. Si no hay acuerdo, puedes pedir orientación sin costo en la PROFEDET.



#### Casos


**Caso 1. Las vacaciones de Mari**

Mari lleva seis años de planta y nunca ha tenido vacaciones pagadas.
- *¿Qué hace?* Hace sus cuentas y lo platica con la señora con calma y con números.


**Caso 2. El aguinaldo de Chayo**

Chayo trabaja un día a la semana en tres casas y cree que no le toca aguinaldo.
- *¿Qué hace?* Calcula la parte que le toca en cada casa y la pide.


**Caso 3. El descanso de Doña Tere**

En una casa le piden a Doña Tere que no coma para terminar antes.
- *¿Qué hace?* Pide su tiempo para comer; es parte de su descanso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que sin contrato no hay derechos | Pierdes lo tuyo | Sí los tienes |
| Pensar que por días no hay aguinaldo | Te toca la parte | Calcúlalo |
| Pelear sin números | No hay acuerdo | Lleva tus cuentas |
| No preguntar | Nadie te informa | PROFEDET orienta sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Chayo y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuántos días de aguinaldo te tocan como mínimo si trabajas todo el año? a) 30 · b) 5 · c) 15
2. ¿Tus derechos aplican si trabajas de entrada por salida? a) Sí, en proporción a los días · b) No, solo de planta · c) Solo si tienes contrato firmado
3. ¿Cuántos días de vacaciones pagadas te tocan al cumplir un año? a) 6 · b) 12 · c) Ninguno
**Respuestas:** 1-c: artículo 87 de la ley. 2-a: cada casa paga su parte. 3-b: desde 2023 son 12.



#### Ponlo en práctica

Cobras 400 por día y te tocan 12 días de vacaciones con prima de 25%. ¿Cuánto es tu pago de vacaciones?
**Respuesta:** 12 por 400: 4,800. Prima de 25%: 1,200. En total, 6,000.



#### A tu plan

Anota la fecha en que empezaste en cada casa y calcula tu aguinaldo de este año.



### Para saber más

- **Derechos de la persona trabajadora del hogar** (PROFEDET · español): https://www.gob.mx/profedet — **Qué buscar:** «trabajadora del hogar».

### Palabras clave

- *Ley Federal del Trabajo:* la ley que dice los derechos y obligaciones en el trabajo en México.
- *Aguinaldo:* pago de al menos 15 días de salario antes del 20 de diciembre.
- *Prima vacacional:* pago extra de al menos 25% sobre tus días de vacaciones.

### Fuentes

Ley Federal del Trabajo · PROFEDET, consultados el 30 de septiembre de 2026.

---

## M2 U02. ¿Cuánto cobrar? Tu tarifa

**Lo que lograrás:** Calcular una tarifa justa por día u hora que cubra tu tiempo, tus pasajes y el salario mínimo, y saber cómo pedir un aumento.

**Para empezar:** Chayo cobra 450 por día desde hace tres años. Ahora los pasajes cuestan más y en una casa le piden también planchar. En esta lección calcularás cuánto cobrar.

### Lo esencial (5 minutos)

#### Tu día incluye el camino

Tu día no son solo las horas en la casa: también el tiempo y el dinero para llegar. Si cobras 450 y gastas 80 en pasajes, en realidad te quedan 370.



#### La tarifa de Chayo

- Cobra por día: **450**
- Pasajes: **80**
- Lo que le queda: **370**
Si trabaja 8 horas, le quedan 46 pesos por hora.


#### Qué subir a tu tarifa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Salario mínimo | Tu tarifa no puede ser menor. | 342.47 por día completo. |
| Pasajes | Súmalos o pide que te los paguen. | Suben cada año. |
| Tareas extra | Planchar, cocinar, cuidar. | Se cobran aparte. |
| Cada año | Los precios suben. | Pide ajuste en enero. |

#### Un caso en un minuto

Chayo sacó sus cuentas: el planchado le toma dos horas más. Le dijo a la señora: «Por limpiar cobro 450; si también plancho, son 550». Le aceptaron 520 y los pasajes.

> **Idea clave:** calcula lo que te queda después del camino y cobra aparte las tareas extra; pide ajuste cada año.



#### Comprueba lo que entendiste

1. Cobras 500 y gastas 60 en pasajes. ¿Cuánto te queda?
*Respuesta:* 440.

2. ¿Cuándo es buen momento para pedir ajuste?
*Respuesta:* En enero, cuando sube el salario mínimo.


#### Para recordar

- Tu día incluye el camino.
- Las tareas extra se cobran.
- Ajuste cada año.



### Profundiza (5 minutos más)

#### Calcula tu tarifa

| Concepto | Tu cifra |
|---|---|
| Horas en la casa | |
| Horas de camino | |
| Pasajes del día | |
| Tareas extra | |
| Lo que quieres que te quede por hora | |



#### Cómo pedir un aumento

Hazlo con tiempo, no el día que estás molesta. Di cuánto tiempo llevas, qué haces y cuánto subieron los pasajes y el salario mínimo. Propón una cifra y escucha. Si no pueden, acuerda algo: pasajes, comida o menos tareas.



#### Casos


**Caso 1. El planchado de Chayo**

En una casa le piden a Chayo planchar además de limpiar, por el mismo pago.
- *¿Qué hace?* Calcula el tiempo extra y propone una tarifa con planchado.


**Caso 2. Los pasajes de Doña Tere**

Los pasajes de Doña Tere subieron y cobra lo mismo desde hace años.
- *¿Qué hace?* Pide un ajuste con sus números en enero.


**Caso 3. La casa nueva de Mari**

A Mari le ofrecen una casa extra los sábados y no sabe cuánto pedir.
- *¿Qué hace?* Suma horas, camino y tareas, y pide al menos el mínimo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Olvidar el camino | Ganas menos | Súmalo |
| Hacer extra sin cobrar | Trabajas de más | Cobra aparte |
| Nunca pedir ajuste | Tu pago pierde valor | Cada enero |
| Pedir enojada | No hay acuerdo | Con calma y números |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 480 y gastas 90 en pasajes. ¿Cuánto te queda? a) 570 · b) 390 · c) 480
2. ¿Qué haces si te piden una tarea extra? a) La haces sin decir nada a nadie · b) La dejas sin avisar · c) Propones cobrarla aparte
3. ¿Cuándo conviene pedir ajuste de tu tarifa? a) En enero, con números · b) El día que estás molesta · c) Nunca, para no perder la casa
**Respuestas:** 1-b: 480 menos 90. 2-c: es más trabajo. 3-a: cuando sube el salario mínimo.



#### Ponlo en práctica

Trabajas 7 horas en la casa y 2 de camino. Cobras 540 y gastas 70 en pasajes. ¿Cuánto te queda por cada hora de tu día?
**Respuesta:** 540 menos 70: 470. Entre 9 horas: unos 52 pesos por hora.



#### A tu plan

Llena la tabla de tu tarifa y decide cuánto vas a pedir en tu próxima casa o en enero.



### Para saber más

- **Salarios mínimos** (CONASAMI · español): https://www.gob.mx/conasami — **Qué buscar:** trabajadoras del hogar.

### Palabras clave

- *Tarifa:* lo que cobras por día u hora de trabajo.
- *Ajuste:* aumento para que tu pago no pierda valor cuando suben los precios.

### Fuentes

CONASAMI, consultado el 30 de septiembre de 2026.

---

## M2 U03. Acuerdos claros y qué hacer si no te pagan

**Lo que lograrás:** Poner por escrito lo que acuerdas, guardar pruebas de tus pagos y saber dónde pedir ayuda si no te pagan o te despiden.

**Para empezar:** A Doña Tere una familia le dejó de pagar tres días: «Luego te los damos». Luego se cambiaron de casa. No tenía nada por escrito. En esta lección sabrás cómo protegerte.

### Lo esencial (5 minutos)

#### Por escrito, aunque sea sencillo

La ley dice que el trabajo del hogar debe tener un contrato por escrito. Si no lo tienen, un mensaje de WhatsApp con lo que acordaron también sirve de prueba.



#### Lo que debe decir tu acuerdo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tareas | Qué haces y qué no. | Evita que te agreguen más. |
| Pago | Cuánto, cada cuándo, en efectivo o transferencia. | Y los pasajes. |
| Horario y descanso | Días, horas y comida. | Día y medio de descanso. |
| Vacaciones y aguinaldo | Cuándo y cuánto. | Por escrito. |

#### Si no te pagan

1. Pide el pago con calma y por mensaje, para que quede escrito.
2. Guarda tus pruebas: mensajes, fotos de recibos, transferencias.
3. Pide orientación sin costo en la PROFEDET o en la procuraduría del trabajo de tu estado.
4. Si te despiden, pide tu finiquito.



#### Un caso en un minuto

Ahora Doña Tere manda un mensaje a cada casa nueva: «Quedamos en 550 por día, martes y viernes, con pasajes». La familia contesta «sí». Ese mensaje es su acuerdo.

> **Idea clave:** pon tus acuerdos por escrito, aunque sea por mensaje, y guarda las pruebas de tus pagos.



#### Comprueba lo que entendiste

1. ¿Un mensaje de WhatsApp sirve como acuerdo?
*Respuesta:* Sí, como prueba de lo que acordaron.

2. ¿Dónde pides orientación si no te pagan?
*Respuesta:* En la PROFEDET o la procuraduría del trabajo de tu estado.


#### Para recordar

- Acuerdo por escrito o por mensaje.
- Guarda tus pruebas.
- Orientación sin costo.



### Profundiza (5 minutos más)

#### Tu finiquito

| Concepto | Qué incluye |
|---|---|
| Días trabajados sin pagar | Todos |
| Aguinaldo | La parte del año |
| Vacaciones | Las que no tomaste |
| Prima vacacional | 25% de esas vacaciones |



#### Si te despiden sin causa

Si te despiden sin una razón justificada, puede tocarte una indemnización además del finiquito. Cada caso es distinto: pide orientación antes de firmar cualquier papel.



#### Casos


**Caso 1. Los días de Doña Tere**

Una familia le debe tres días a Doña Tere y le dice «luego».
- *¿Qué hace?* Pide el pago por mensaje y guarda la conversación.


**Caso 2. El papel de Mari**

Al despedirla, le dan a Mari un papel para firmar que dice que no le deben nada.
- *¿Qué hace?* No firma sin revisar y pide orientación en la PROFEDET.


**Caso 3. La casa nueva de Chayo**

Chayo empieza en una casa nueva y todo fue de palabra.
- *¿Qué hace?* Manda un mensaje con lo que acordaron y pide que lo confirmen.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo de palabra | No tienes pruebas | Mensaje con el acuerdo |
| Borrar los mensajes | Pierdes pruebas | Guárdalos |
| Firmar sin leer | Renuncias a lo tuyo | Pide orientación |
| Pensar que nadie ayuda | Te quedas sin nada | PROFEDET orienta sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Mari y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué te sirve de prueba de lo que acordaste? a) Un mensaje con el acuerdo · b) Tu palabra · c) Lo que recuerdan tus vecinas
2. ¿Qué incluye tu finiquito? a) Solo el último día que trabajaste en la casa · b) Nada, si fue de palabra · c) Días pendientes, aguinaldo y vacaciones
3. Te piden firmar que no te deben nada. ¿Qué haces? a) Firmas para salir rápido · b) Pides orientación antes de firmar · c) Rompes el papel y te vas sin decir nada
**Respuestas:** 1-a: queda escrito. 2-c: todo lo pendiente. 3-b: no firmes sin revisar.



#### Ponlo en práctica

Te despiden en junio. Cobras 500 por día y trabajas 5 días a la semana. Te deben 3 días. ¿Cuánto es solo por los días pendientes?
**Respuesta:** 3 por 500: 1,500. Además te toca la parte de aguinaldo y vacaciones.



#### A tu plan

Manda a cada casa un mensaje con lo que acordaron: días, pago, pasajes y tareas.



### Para saber más

- **Orientación laboral sin costo** (PROFEDET · español): https://www.gob.mx/profedet — **Qué buscar:** «asesoría» y «trabajadora del hogar».
- **Modelo de contrato** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** «contrato trabajadoras del hogar».

### Palabras clave

- *Contrato por escrito:* papel firmado que dice qué haces, cuánto te pagan, tu horario y tus descansos.
- *Finiquito:* pago al terminar el trabajo: días pendientes, parte de aguinaldo y de vacaciones.
- *PROFEDET:* Procuraduría Federal de la Defensa del Trabajo; orienta sin costo.

### Fuentes

Ley Federal del Trabajo · PROFEDET · STPS, consultados el 30 de septiembre de 2026.

---

## M2 U04. Cobrar sin perder: tu cuenta y las transferencias

**Lo que lograrás:** Tener una cuenta sin comisiones para cobrar por transferencia, pagar sin cargar efectivo y reclamar si algo sale mal.

**Para empezar:** Chayo cobra en efectivo en cuatro casas y lleva el dinero en la bolsa en el camión. Una vez se lo robaron. En esta lección verás cómo cobrar más seguro.

### Lo esencial (5 minutos)

#### Una cuenta sin comisiones

Todos los bancos deben ofrecer una cuenta básica: no cobra por tenerla abierta y solo pide identificación y CURP. También está la cuenta del Banco del Bienestar, que se abre con 50 pesos.



#### Cómo cobrar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transferencia | Llega a tu cuenta y queda registro. | La más segura. |
| Con tu número de celular | Sin dar tu CLABE, si tu banco lo tiene. | Rápido. |
| Efectivo | Útil, pero se pierde o te lo roban. | Carga poco. |
| Dar tus datos a cualquiera | Solo tu CLABE o celular para recibir. | Nunca tu NIP. |

> **Dato vigente:** los bancos están obligados a ofrecer una cuenta básica sin comisión por manejo de cuenta. La cuenta de ahorro del Banco del Bienestar se abre con 50 pesos, sin saldo mínimo, y cobra 58 pesos al mes si pasa 12 meses sin movimientos. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF y el Banco del Bienestar.

#### Un caso en un minuto

Chayo abrió una cuenta básica y pidió a tres de sus casas que le paguen por transferencia. Ahora solo carga el efectivo de una casa y tiene registro de todos sus pagos.

> **Idea clave:** cobrar por transferencia es más seguro y deja prueba de tu pago; para recibir solo das tu CLABE o tu número, nunca tu NIP ni códigos.



#### Comprueba lo que entendiste

1. ¿Qué das para que te transfieran?
*Respuesta:* Tu CLABE o tu número de celular ligado a tu cuenta.

2. ¿Qué nunca das?
*Respuesta:* Tu NIP, contraseñas ni códigos.


#### Para recordar

- Cuenta básica sin comisiones.
- Transferencia deja prueba.
- Nunca des tu NIP ni códigos.



### Profundiza (5 minutos más)

#### Tu cuenta sin sorpresas

| Revisa | Por qué |
|---|---|
| Comisión por manejo | Debe ser 0 en la cuenta básica |
| Retiros en cajeros de otros bancos | Cobran |
| Límite de depósitos al mes | Las cuentas básicas tienen tope |
| Inactividad | Algunas cobran si no la usas |



#### Si te cobran algo que no reconoces

Llama a tu banco y pide un número de folio. Si no te resuelven, acude a la CONDUSEF. Reclamar no tiene costo.



#### Casos


**Caso 1. La bolsa de Chayo**

Chayo lleva en efectivo lo de cuatro casas y la asaltaron.
- *¿Qué hace?* Abre una cuenta y pide que le paguen por transferencia.


**Caso 2. La comisión de Mari**

A Mari le cobran 120 al mes en su cuenta.
- *¿Qué hace?* Pide que la cambien a cuenta básica sin comisión.


**Caso 3. El mensaje de Doña Tere**

Le llega un mensaje: «Para depositarte tu pago, dame el código que te llegó».
- *¿Qué hace?* No da el código: para recibir solo se necesita su CLABE.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cargar todo en efectivo | Te lo roban | Transferencia |
| Pagar comisiones | Pierdes dinero | Cuenta básica |
| Dar códigos | Te vacían la cuenta | Nunca |
| No reclamar | Pierdes lo tuyo | Folio y CONDUSEF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué necesitas dar para que te transfieran? a) Tu NIP · b) Tu CLABE · c) El código que te llega
2. ¿Cuánto cobra de manejo la cuenta básica? a) 120 al mes · b) Depende de tu saldo · c) Nada
3. ¿A dónde acudes si tu banco no resuelve tu reclamo? a) A la CONDUSEF · b) A la tienda de la esquina · c) A la policía de tránsito
**Respuestas:** 1-b: solo eso para recibir. 2-c: es sin comisión por manejo. 3-a: protege a usuarios.



#### Ponlo en práctica

Tu cuenta te cobra 99 al mes. ¿Cuánto pierdes en un año si no la cambias?
**Respuesta:** 99 por 12: 1,188.



#### A tu plan

Pregunta a cada casa si puede pagarte por transferencia y anota cuáles sí.



### Para saber más

- **Cuenta básica** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica».
- **Banco del Bienestar** (Gobierno de México · español): https://www.gob.mx/bancodelbienestar — **Qué buscar:** «abrir cuenta».

### Palabras clave

- *Cuenta básica:* cuenta sin comisión por manejo que todos los bancos deben ofrecer.
- *CLABE:* número de 18 dígitos para recibir transferencias.
- *NIP:* clave secreta de tu tarjeta; nunca se comparte.

### Fuentes

CONDUSEF · Banco del Bienestar, consultados el 30 de septiembre de 2026.

---


# Parte 3. Módulo 3. Tandas y ahorro

## M3 U01. Tandas: cómo funcionan y qué puede salir mal

**Lo que lograrás:** Entender cómo funciona una tanda, cuándo es ahorro y cuándo es deuda, y qué riesgos tiene.

**Para empezar:** Chayo organiza la tanda de la colonia: 10 señoras con 300 cada semana. Una cobró en el número 2 y se fue a vivir a otro estado. Chayo puso de su bolsa para cumplir. En esta lección verás qué puede salir mal.

### Lo esencial (5 minutos)

#### Cómo funciona

En una tanda, cada persona pone lo mismo cada semana o quincena y, por turnos, una se lleva todo. No paga intereses: recibes lo mismo que pones.



#### Ahorro o deuda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Si cobras al final | Es como ahorro. | Pones antes de recibir. |
| Si cobras al principio | Es como un préstamo. | Recibes antes de pagar. |
| Si alguien deja de pagar | Pierden las demás. | El mayor riesgo. |
| Sin protección | No hay institución detrás. | Solo confianza. |

#### La tanda de Chayo

- Por semana: **300**
- Personas: **10**
- Lo que cobra cada una: **3,000**
Quien cobra primero debe 2,700 en nueve semanas.


#### Un caso en un minuto

Chayo perdió 300 cuando una señora dejó de pagar. En la siguiente tanda puso reglas por escrito (M3 U02).

> **Idea clave:** una tanda no paga intereses y depende de que todas cumplan; si cobras primero, tienes una deuda.



#### Comprueba lo que entendiste

1. ¿Una tanda paga intereses?
*Respuesta:* No. Recibes lo mismo que pones.

2. ¿Qué pasa si cobras primero?
*Respuesta:* Tienes una deuda con el grupo.


#### Para recordar

- Sin intereses.
- Cobrar primero es deber.
- Depende de la confianza.



### Profundiza (5 minutos más)

#### Riesgos de una tanda

| Riesgo | Qué pasa |
|---|---|
| Alguien deja de pagar | Pierden las que cobran después |
| Quien organiza desaparece | Se pierde todo |
| Sin registro | Discusiones sobre quién pagó |
| Una se cambia de casa o de ciudad | Deja de pagar |



#### Tanda contra cuenta

En una cuenta de ahorro tu dinero está protegido y solo depende de ti. En una tanda depende del grupo. La tanda ayuda a ahorrar por compromiso, pero tiene más riesgo.



#### Casos


**Caso 1. La señora que se fue**

Una señora cobró en el número 2 y se cambió de estado.
- *¿Qué hace Chayo la próxima vez?* Pone reglas por escrito y da los primeros números a personas de confianza.


**Caso 2. El número de Doña Tere**

Doña Tere quiere el número 1 para pagar una deuda.
- *¿Qué hace?* Entiende que es otra deuda y revisa si podrá pagar todas las semanas.


**Caso 3. Las dos tandas de Mari**

Mari está en dos tandas y ya no le alcanza para pagar las dos.
- *¿Qué hace?* No entra a otra y termina una antes de seguir.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que da intereses | No es inversión | Es ahorro en grupo |
| Cobrar primero sin plan | No puedes pagar | Es deuda |
| Sin registro | Discusiones | Anota cada pago |
| Estar en muchas tandas | No alcanza | Una a la vez |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tanda de 8 personas con 250 cada semana. ¿Cuánto cobra cada una? a) 250 · b) 2,500 · c) 2,000
2. Cobraste primero. ¿Qué tienes? a) Una deuda con el grupo · b) Una ganancia · c) Un ahorro protegido por el banco
3. ¿Cuál es el mayor riesgo de una tanda? a) Los intereses que te cobra · b) Que el banco la cancele · c) Que alguien deje de pagar
**Respuestas:** 1-c: 250 por 8. 2-a: debes los pagos. 3-c: pierden las demás.



#### Ponlo en práctica

Tanda de 12 personas con 200 cada semana. Cobras en el número 3. ¿Cuánto has puesto al cobrar y cuánto te falta pagar?
**Respuesta:** Cobras 2,400. Al cobrar has puesto 600; te faltan 9 pagos: 1,800.



#### A tu plan

Si estás en una tanda, anota cuánto has puesto, cuándo cobras y cuánto te falta.



### Para saber más

- **Ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «tandas» y ahorro formal.

### Palabras clave

- *Tanda:* ahorro en grupo en el que cada persona pone lo mismo y, por turnos, una se lleva todo.
- *Número de la tanda:* el lugar en que te toca cobrar.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M3 U02. Tu tanda con reglas o tu propio ahorro

**Lo que lograrás:** Poner reglas escritas a una tanda para bajar su riesgo, o ahorrar por tu cuenta con la misma disciplina.

**Para empezar:** Chayo quiere volver a organizar la tanda, pero ahora sin perder. Doña Tere dice que mejor ahorra sola, pero nunca le dura. En esta lección verás las dos opciones.

### Lo esencial (5 minutos)

#### Reglas para una tanda más segura

1. Solo con personas que conoces bien y que tienen ingreso seguido.
2. Por escrito: quién, cuánto, cada cuándo, orden de cobro y qué pasa si alguien no paga.
3. Los primeros números para quien lleva más tiempo y ha cumplido.
4. Registro de cada pago con fecha, en papel o en un grupo de WhatsApp.
5. Grupos chicos y plazos cortos: menos personas, menos riesgo.



#### O tu propia tanda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta aparte | Pon lo mismo cada semana. | Protegida. |
| El mismo día | Como si fuera la tanda. | El hábito cuenta. |
| No la toques | Solo para tu meta. | Disciplina. |

#### Un caso en un minuto

Chayo armó una tanda de 6 señoras que conoce hace años, con reglas escritas y un grupo de WhatsApp para registrar pagos. Doña Tere hace «su tanda sola»: cada lunes transfiere 300 a su cuenta de ahorro.

> **Idea clave:** si entras a una tanda, que sea chica, con reglas escritas y registro; si prefieres ahorrar sola, hazlo el mismo día cada semana.



#### Comprueba lo que entendiste

1. ¿Por qué grupos chicos?
*Respuesta:* Menos personas, menos riesgo de que alguien falle.

2. ¿Qué es hacer tu propia tanda?
*Respuesta:* Poner lo mismo cada semana en tu cuenta de ahorro.


#### Para recordar

- Reglas por escrito.
- Registro de pagos.
- O tu propia tanda en una cuenta.



### Profundiza (5 minutos más)

#### Tanda con reglas contra ahorro propio

| Punto | Tanda con reglas | Ahorro propio |
|---|---|---|
| Depende de | El grupo | Solo de ti |
| Protección | Ninguna | Seguro del banco (IPAB) |
| Compromiso | Alto | Lo pones tú |
| Si necesitas antes | Esperas tu número | Lo sacas |



#### Tandas en internet y «tandas que multiplican»

Si te ofrecen una tanda por redes en la que «das 500 y recibes 4,000», no es tanda: es un fraude piramidal. En una tanda de verdad recibes lo mismo que pones.



#### Casos


**Caso 1. La nueva tanda de Chayo**

Chayo quiere organizar otra tanda.
- *¿Qué hace?* Grupo chico, reglas por escrito y registro de pagos.


**Caso 2. El ahorro de Doña Tere**

Doña Tere ahorra sola pero toma el dinero cada vez que le piden.
- *¿Qué hace?* Pone su ahorro en una cuenta aparte y deposita el mismo día cada semana.


**Caso 3. La tanda de Facebook de Mari**

A Mari le ofrecen una «tanda» en redes: pone 500 y recibe 4,000.
- *¿Qué hace?* No entra: es un fraude piramidal.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Tanda con desconocidas | Riesgo alto | Solo de confianza |
| Sin reglas escritas | Discusiones | Por escrito |
| Creer en tandas que multiplican | Fraude | Recibes lo mismo que pones |
| Ahorro sin fecha | No dura | El mismo día cada semana |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te ofrecen «pon 500 y recibe 4,000» en redes. ¿Qué es? a) Un ahorro con buenos intereses · b) Un fraude piramidal · c) Una tanda de verdad
2. ¿Qué regla baja el riesgo de una tanda? a) Un grupo grande con gente de otras colonias · b) Todo de palabra · c) Reglas escritas y registro
3. ¿Qué protege tu ahorro en una cuenta de banco? a) El seguro de depósitos (IPAB) · b) La señora que organiza la tanda del barrio · c) Nadie
**Respuestas:** 1-b: nadie multiplica así. 2-c: queda claro y comprobable. 3-a: protege tus depósitos.



#### Ponlo en práctica

Haces tu propia tanda: 300 cada semana durante 10 semanas. ¿Cuánto juntas?
**Respuesta:** 300 por 10: 3,000.



#### A tu plan

Decide: ¿tanda con reglas o tu propia tanda? Escribe tus reglas o el día fijo en que vas a depositar.



### Para saber más

- **Fraudes piramidales** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «pirámides» y «tandas».

### Palabras clave

- *Fraude piramidal:* esquema que promete multiplicar tu dinero pagando con lo que ponen personas nuevas; tarde o temprano se cae.
- *IPAB:* seguro que protege tus depósitos en bancos.

### Fuentes

CONDUSEF · IPAB, consultados el 30 de septiembre de 2026.

---

## M3 U03. Tu fondo para emergencias

**Lo que lograrás:** Juntar un fondo para cuando te enfermas, una casa cancela o surge algo en la familia, sin tener que pedir prestado.

**Para empezar:** Doña Tere se torció el pie y no pudo trabajar dos semanas. Sin esos días no tenía para la renta y le pidió a una prestamista 3,000 que ahora le cuestan 600 a la semana. En esta lección juntarás tu fondo.

### Lo esencial (5 minutos)

#### Para qué sirve

Si cobras por día, **un día sin trabajo es un día sin dinero**. Un fondo de emergencia te da tiempo sin tener que pedir prestado.



#### La meta de Doña Tere

- Gastos básicos por semana: **2,300**
- Semanas: **2**
- Meta del primer fondo: **4,600**
Después, la meta es un mes completo.


#### Cómo juntarlo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Meta chica primero | Dos semanas de gastos. | Luego un mes. |
| En cuenta aparte | Que no esté a la mano. | Protegida. |
| Con dinero extra | Aguinaldo, propinas, un día extra. | Una parte al fondo. |
| Solo emergencias | No es para gustos. | Si lo usas, lo repones. |

#### Un caso en un minuto

Doña Tere aparta 100 cada día que trabaja y la mitad de su aguinaldo. En tres meses tuvo sus 4,600. La siguiente vez que se enfermó no pidió prestado.

> **Idea clave:** junta primero dos semanas de gastos en una cuenta aparte; es tu seguro para no pedir prestado cuando no puedes trabajar.



#### Comprueba lo que entendiste

1. ¿Cuál es la primera meta del fondo?
*Respuesta:* Dos semanas de gastos básicos.

2. ¿Qué haces si lo usas?
*Respuesta:* Lo vuelves a llenar poco a poco.


#### Para recordar

- Primero dos semanas.
- Cuenta aparte.
- Solo emergencias.



### Profundiza (5 minutos más)

#### ¿Es emergencia?

| Situación | ¿Emergencia? |
|---|---|
| Te enfermas y no trabajas | Sí |
| Una casa cancela todo el mes | Sí |
| Un medicamento urgente | Sí |
| Ropa en oferta | No |
| Una fiesta | No, eso es una meta |



#### Cuando la emergencia es de otra persona

Si la emergencia es de tu hija o tu nieta, puedes usar el fondo, pero decide cuánto y acuerda cómo se repone. Ayudar sin dejarte sin nada es parte de cuidar a tu familia (M4).



#### Casos


**Caso 1. El pie de Doña Tere**

Doña Tere no pudo trabajar dos semanas y no tenía ahorro.
- *¿Qué hace para la próxima?* Junta un fondo de dos semanas de gastos en una cuenta aparte.


**Caso 2. La oferta de Chayo**

Chayo ve unos tenis en oferta y quiere usar su fondo.
- *¿Qué hace?* No lo usa: no es emergencia; ahorra aparte para eso.


**Caso 3. La urgencia de la nieta**

La nieta de Doña Tere necesita un medicamento urgente.
- *¿Qué hace?* Usa parte del fondo y se pone una meta para reponerlo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar a tener mucho | Nunca empiezas | Meta chica primero |
| Guardarlo en la bolsa | Se gasta | Cuenta aparte |
| Usarlo para gustos | No está cuando lo necesitas | Solo emergencias |
| No reponerlo | Te quedas sin nada | Vuelve a llenarlo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tus gastos básicos son 2,000 a la semana. ¿Cuál es tu primera meta de fondo? a) 2,000 · b) 20,000 · c) 4,000
2. ¿Para qué es el fondo de emergencia? a) Para días sin trabajo o enfermedad · b) Para ofertas · c) Para la cena y los regalos de fin de año
3. ¿Qué haces con el aguinaldo si no tienes fondo? a) Lo gastas todo en regalos para la familia · b) Guardas una parte para el fondo · c) Lo prestas completo
**Respuestas:** 1-c: dos semanas. 2-a: imprevistos. 3-b: una parte al fondo.



#### Ponlo en práctica

Apartas 80 cada día que trabajas y trabajas 20 días al mes. Tu meta son 4,800. ¿En cuántos meses la alcanzas?
**Respuesta:** 80 por 20: 1,600 al mes. 4,800 entre 1,600: 3 meses.



#### A tu plan

Calcula tu meta de dos semanas y decide cuánto vas a apartar cada día que cobres.



### Para saber más

- **Fondo de emergencia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Fondo de emergencia:* dinero guardado solo para imprevistos: enfermedad, días sin trabajo o una urgencia de la familia.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M3 U04. Ahorra para lo que viene: útiles, diciembre y metas

**Lo que lograrás:** Ahorrar para gastos que sabes que llegan (inscripciones, útiles, diciembre) y entender por qué el dinero guardado sin moverse pierde valor.

**Para empezar:** Cada agosto Mari se endeuda para los útiles y el uniforme de su hijo. Cada diciembre, para la cena y los regalos. En esta lección verás cómo ahorrar para lo que ya sabes que viene.

### Lo esencial (5 minutos)

#### Gastos que no son sorpresa

Útiles, uniformes, inscripciones, diciembre, el día de muertos: **no son emergencias, son fechas**. Si sabes cuánto y cuándo, puedes dividirlo entre las semanas que faltan.



#### Los útiles de Mari

- Útiles, uniforme e inscripción: **3,400**
- Semanas que faltan: **34**
- A la semana: **100**
Cien pesos a la semana y en agosto no pide prestado.


#### Tus metas del año

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Escuela | Agosto. | Divide entre las semanas. |
| Diciembre | Cena, regalos, viajes. | Empieza en enero. |
| Algo de la casa | Lavadora, refri. | Junta y paga de contado. |

#### El dinero guardado pierde valor

Con la inflación, lo que hoy compras con 100 pesos el próximo año cuesta más. Guardar en casa sirve para metas cortas; para metas largas conviene que el dinero esté en una cuenta o inversión segura que pague rendimiento.

> **Idea clave:** lo que sabes que viene no es emergencia; divide la meta entre las semanas que faltan y empieza hoy.



#### Comprueba lo que entendiste

1. Necesitas 2,000 en 20 semanas. ¿Cuánto apartas por semana?
*Respuesta:* 100.

2. ¿Qué es la inflación?
*Respuesta:* El aumento de los precios con el tiempo.


#### Para recordar

- Las fechas no son sorpresa.
- Meta entre semanas.
- El dinero quieto pierde valor.



### Profundiza (5 minutos más)

#### Tu calendario de metas

| Meta | Cuánto | Cuándo | Semanas que faltan | Por semana |
|---|---|---|---|---|
| Escuela | | Agosto | | |
| Diciembre | | Diciembre | | |
| Otra | | | | |



#### Metas largas

Para metas de más de un año, como la prepa o la universidad de un hijo, busca opciones que paguen rendimiento en instituciones reguladas, como Cetesdirecto. Compara antes y nunca en quien te promete ganancias muy altas.



#### Casos


**Caso 1. Los útiles de Mari**

Mari se endeuda cada agosto para los útiles.
- *¿Qué hace?* Divide lo que necesita entre las semanas que faltan y aparta cada semana.


**Caso 2. El diciembre de Doña Tere**

Doña Tere gasta todo su aguinaldo y además pide prestado.
- *¿Qué hace?* Empieza a apartar en enero para diciembre.


**Caso 3. El ahorro bajo el colchón de Chayo**

Chayo guarda en su casa lo de la universidad de su hija para dentro de 8 años.
- *¿Qué hace?* Busca una opción regulada que pague rendimiento.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Tratar las fechas como sorpresa | Te endeudas | Planéalas |
| Empezar tarde | No alcanza | Empieza hoy |
| Guardar años en casa | Pierde valor | Opción regulada |
| Metas sin número | No sabes cuánto | Ponle cifra y fecha |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Doña Tere y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Necesitas 3,000 en 30 semanas. ¿Cuánto apartas por semana? a) 300 · b) 100 · c) 30
2. ¿Los útiles de agosto son una emergencia? a) Sí, porque siempre llegan de sorpresa cada año · b) Depende del año · c) No, es un gasto que sabes que viene
3. Con inflación, ¿qué pasa con el dinero guardado en casa por años? a) Pierde valor · b) Gana valor · c) Se queda igual
**Respuestas:** 1-b: 3,000 entre 30. 2-c: sabes la fecha. 3-a: los precios suben.



#### Ponlo en práctica

Diciembre te cuesta 4,500. Empiezas a ahorrar en la semana 1 del año y te quedan 45 semanas. ¿Cuánto apartas por semana?
**Respuesta:** 4,500 entre 45: 100 por semana.



#### A tu plan

Llena tu calendario de metas con una meta de escuela y una de diciembre.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com — **Qué buscar:** «cómo abrir tu cuenta».
- **Inflación** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «inflación».

### Palabras clave

- *Inflación:* aumento de los precios con el tiempo.
- *Rendimiento:* lo que gana tu dinero por estar guardado o invertido.

### Fuentes

Banco de México · Cetesdirecto · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 4. Módulo 4. Ayudar sin hundirte

## M4 U01. ¿Cuánto das a tu familia?

**Lo que lograrás:** Sumar cuánto das cada mes a hijas, nietas, esposo y otras personas, y decidir un monto fijo que puedas sostener sin quedarte sin nada.

**Para empezar:** Doña Tere paga la escuela de su nieta Ximena, le da a su hija Rosa para la renta cuando no le alcanza y cubre el gas porque su esposo casi no tiene trabajo. Nunca lo ha sumado. Este mes se quedó sin para sus pasajes. En esta lección verás cuánto das.

### Lo esencial (5 minutos)

#### Dar es parte de tu vida

Apoyar a tu familia es una decisión de amor y muchas veces de necesidad. El problema no es dar: es **dar sin saber cuánto**, porque un día te quedas sin nada y ya no puedes ayudar a nadie.



#### Lo que da Doña Tere al mes

- Escuela y pasajes de Ximena: **900**
- Ayuda a Rosa para la renta: **1,500**
- Gas de la casa: **450**
- Al mes: **2,850**
Casi una tercera parte de lo que le entra.


#### Tres tipos de apoyo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fijo | Lo que das cada mes. | Ponle monto. |
| Urgente | Salud o un imprevisto. | Sale del fondo. |
| «Préstamo» que no regresa | Lo que prestas y no te pagan. | Cuéntalo como regalo. |

#### Un caso en un minuto

Doña Tere sumó lo que da y platicó con Rosa y su esposo. Acordaron que ella paga la escuela de Ximena y el gas, y Rosa busca cómo cubrir su renta. Ahora sabe que da 1,350 fijos y le alcanza para sus pasajes y su ahorro.

> **Idea clave:** ponle monto a lo que das cada mes; saber cuánto das te permite seguir ayudando sin quedarte sin nada.



#### Comprueba lo que entendiste

1. ¿Cuál es el problema de dar sin sumar?
*Respuesta:* Que un día te quedas sin nada y ya no puedes ayudar.

2. ¿Cómo cuentas un préstamo que no te regresan?
*Respuesta:* Como un regalo.


#### Para recordar

- Suma lo que das.
- Ponle monto fijo.
- Lo urgente sale del fondo.



### Profundiza (5 minutos más)

#### Tu mapa de apoyo

| Persona | Para qué | Cada cuándo | Cuánto al mes |
|---|---|---|---|
| | | | |
| | | | |
| Total | | | |



#### Tu parte y la parte de los demás

Cuando varias personas pueden aportar, platiquen quién paga qué. Que tú seas la que tiene trabajo seguido no quiere decir que debas pagarlo todo.



#### Casos


**Caso 1. Las cuentas de Doña Tere**

Doña Tere da a todos y se quedó sin para sus pasajes.
- *¿Qué hace?* Suma lo que da y acuerda con su familia un monto fijo.


**Caso 2. El hermano de Mari**

El hermano de Mari le pide dinero cada quincena «prestado» y nunca le paga.
- *¿Qué hace?* Lo cuenta como regalo y decide cuánto puede dar sin afectar su ahorro.


**Caso 3. El esposo de Chayo**

El esposo de Chayo ya no aporta al gasto porque «ella gana más».
- *¿Qué hace?* Platican con números qué paga cada quien.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar sin sumar | Te quedas sin nada | Suma y ponle monto |
| Llamar préstamo a un regalo | Te enojas | Cuéntalo como regalo |
| Pagar todo sola | Te agotas | Reparte con la familia |
| Usar tu ahorro para todo | Sin protección | Monto fijo aparte |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Mari y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Das 600 a tu hija y 400 a tu mamá cada quincena. ¿Cuánto das al mes? a) 1,000 · b) 2,000 · c) 600
2. ¿Qué haces con lo que prestas y nunca te pagan? a) Lo cobras con intereses · b) Lo cuentas como regalo · c) Lo olvidas y sigues prestando
3. ¿De dónde sale un apoyo urgente de salud? a) De tus pasajes de la semana · b) De un préstamo en app · c) De tu fondo de emergencia
**Respuestas:** 1-b: 1,000 por dos quincenas. 2-b: así no te engañas. 3-c: para eso es.



#### Ponlo en práctica

Te entran 9,000 al mes y das 2,700 a tu familia. ¿Qué porcentaje de tu ingreso das?
**Respuesta:** 2,700 entre 9,000: 30%.



#### A tu plan

Llena tu mapa de apoyo y decide el monto fijo que puedes dar cada mes.



### Para saber más

- **Finanzas en familia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «finanzas familiares».

### Palabras clave

- *Apoyo fijo:* lo que decides dar cada mes a tu familia, con monto.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M4 U02. Prestar a la familia sin perder

**Lo que lograrás:** Poner reglas cuando prestas dinero a familiares o amistades para no endeudarte por otra persona.

**Para empezar:** Rosa, la hija de Doña Tere, le pidió 5,000 para un abogado. Doña Tere no los tenía y los pidió a una prestamista a 20% al mes. Rosa le paga cuando puede. Doña Tere ya lleva 3,000 de intereses. En esta lección verás cómo prestar sin hundirte.

### Lo esencial (5 minutos)

#### Nunca te endeudes para prestar

Si pides prestado para prestarle a alguien, **la deuda es tuya**, con sus intereses, aunque la otra persona no te pague. Presta solo lo que tienes y podrías perder.



#### Reglas para prestar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Solo lo que tienes | Nunca pidas para prestar. | La deuda sería tuya. |
| Por escrito | Cuánto, cuándo y cómo te pagan. | Un mensaje sirve. |
| Pagos chicos y fijos | Fechas claras. | Más fácil de cumplir. |
| ¿Podrías regalarlo? | Si no, no lo prestes. | Protege la relación. |

#### El préstamo de Doña Tere

- Lo que pidió para Rosa: **5,000**
- Interés al mes: **20%**
- Intereses cada mes: **1,000**
En tres meses pagó 3,000 solo de intereses.


#### Un caso en un minuto

La siguiente vez que le pidieron, Doña Tere dijo: «No tengo, y no voy a pedir prestado. Te puedo dar 500 y te acompaño a buscar asesoría sin costo». Rosa encontró una defensoría pública.

> **Idea clave:** presta solo lo que tienes y podrías perder, por escrito y con fechas; nunca te endeudes para prestar.



#### Comprueba lo que entendiste

1. Pides prestado para prestar y no te pagan. ¿De quién es la deuda?
*Respuesta:* Tuya.

2. ¿Qué preguntas antes de prestar?
*Respuesta:* Si podrías regalarlo sin afectar tu casa.


#### Para recordar

- Solo lo que tienes.
- Por escrito y con fechas.
- Nunca te endeudes para prestar.



### Profundiza (5 minutos más)

#### Otras formas de ayudar

| En lugar de prestar | Cómo ayuda |
|---|---|
| Acompañar a buscar ayuda sin costo | Defensorías, becas, programas |
| Dar un monto chico que no regresa | No pones en riesgo tu casa |
| Ayudar con tiempo | Cuidar a los nietos, acompañar |
| Hacer juntos un presupuesto | Salen del problema de fondo |



#### Cobrar sin pelear

Recuerda la fecha con un mensaje amable: «Te recuerdo que quedamos en 300 este viernes». Si no puede, acuerden una nueva fecha. Si nunca paga, deja de prestarle.



#### Casos


**Caso 1. El abogado de Rosa**

Rosa le pide 5,000 a Doña Tere y ella no los tiene.
- *¿Qué hace?* No pide prestado; ofrece lo que puede y la acompaña a buscar ayuda sin costo.


**Caso 2. La vecina de Chayo**

Una vecina le pide a Chayo 2,000 y Chayo sí los tiene.
- *¿Qué hace?* Presta solo si podría perderlos, y acuerdan fechas por mensaje.


**Caso 3. El hijo de Mari**

El hijo de Mari no ha pagado los 1,500 que le prestó.
- *¿Qué hace?* Le recuerda la fecha con calma y no le presta más hasta que pague.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir para prestar | La deuda es tuya | Solo lo que tienes |
| Todo de palabra | Nadie recuerda | Mensaje con fechas |
| Prestar lo del ahorro | Sin protección | Solo lo que puedes perder |
| Seguir prestando a quien no paga | Pierdes más | Detente |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Pides 3,000 al 15% mensual para prestarle a tu hijo. ¿Cuánto pagas de interés al mes? a) 150 · b) 450 · c) 3,450
2. ¿Cuál es la regla más importante al prestar? a) Nunca pedir prestado para prestar · b) Prestar a quien te lo pida primero en la familia · c) Prestar siempre sin fecha
3. ¿Qué te sirve de acuerdo por escrito? a) Tu memoria · b) La palabra de tu hijo frente a la familia · c) Un mensaje con monto y fechas
**Respuestas:** 1-b: 15% de 3,000. 2-a: la deuda sería tuya. 3-c: queda registro.



#### Ponlo en práctica

Prestas 2,400 y acuerdan pagos iguales cada semana durante 8 semanas. ¿De cuánto es cada pago?
**Respuesta:** 2,400 entre 8: 300 por semana.



#### A tu plan

Escribe tus reglas para prestar y compártelas en casa.



### Para saber más

- **Defensoría pública** (Instituto Federal de Defensoría Pública · español): https://www.ifdp.cjf.gob.mx — **Qué buscar:** «asesoría jurídica».

### Palabras clave

- *Interés:* lo que pagas por usar dinero prestado.
- *Defensoría pública:* servicio de abogados sin costo que da el gobierno.

### Fuentes

CONDUSEF · Instituto Federal de Defensoría Pública, consultados el 30 de septiembre de 2026.

---

## M4 U03. Aval, obligado solidario y referencia: ¿qué firmas?

**Lo que lograrás:** Distinguir aval, obligado solidario, fiador y referencia personal, saber qué te pueden cobrar en cada caso y decidir antes de firmar por alguien de tu familia.

**Para empezar:** El yerno de Doña Tere quiere sacar una moto a crédito y le pide que firme «nada más como aval». Y a Chayo la pusieron de referencia en una tarjeta sin preguntarle. En esta lección verás qué implica cada papel.

### Lo esencial (5 minutos)

#### Cada papel, una responsabilidad

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aval | Firma el pagaré: si no pagan, te cobran a ti todo. | Aparece en tu historial. |
| Obligado solidario | Respondes por todo como si tú lo pidieras. | Te pueden cobrar directo. |
| Fiador | Común en rentas: pagas si la otra persona no paga. | Revisa el contrato. |
| Referencia personal | Solo das tus datos de contacto. | No te pueden cobrar. |

#### Ser referencia no es ser aval

Cuando alguien pide un crédito le piden referencias: nombre y teléfono de personas que lo conocen. Ser referencia personal no te obliga a pagar nada. Si no firmaste como aval, obligado solidario o fiador, esa deuda no es tuya.

> **Dato vigente:** las reglas de la CONDUSEF para despachos de cobranza solo les permiten cobrar al deudor, a sus avales y a sus obligados solidarios; no pueden cobrar a referencias personales ni amenazar a familiares. Las quejas se presentan en el REDECO. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF.



#### Un caso en un minuto

Doña Tere le dijo a su yerno: «No puedo firmar una deuda que no podría pagar». Lo ayudó a juntar para el enganche. Chayo supo que, como referencia, no le pueden cobrar nada.

> **Idea clave:** aval, obligado solidario y fiador pagan si la otra persona no paga; una referencia solo da sus datos y no le pueden cobrar. Firma solo si podrías pagar esa deuda completa.



#### Comprueba lo que entendiste

1. ¿Te pueden cobrar si solo fuiste referencia?
*Respuesta:* No. Solo diste tus datos.

2. ¿Qué pasa si firmas como aval y no pagan?
*Respuesta:* Te cobran a ti y puede aparecer en tu historial.


#### Para recordar

- Aval, obligado solidario y fiador pagan.
- Referencia: solo datos.
- Firma solo si podrías pagar todo.



### Profundiza (5 minutos más)

#### ¿Qué firmas?

| Papel | ¿Firmas? | ¿Te pueden cobrar? |
|---|---|---|
| Aval | Sí, el pagaré | Sí, todo |
| Obligado solidario | Sí, el contrato | Sí, directo |
| Fiador | Sí, el contrato | Sí, si el otro no paga |
| Referencia personal | No | No |



#### Si te llaman como referencia

Si un despacho te presiona por una deuda de la que solo eres referencia, no pagues ni des más datos. Pide el nombre del despacho, anota fecha y hora y preséntalo en el REDECO de la CONDUSEF.

> **Antes de actuar, verifica:** qué dice el documento que te piden firmar y en qué papel apareces.



#### Casos


**Caso 1. La moto del yerno**

El yerno de Doña Tere le pide que sea su aval.
- *¿Qué hace?* Dice que no puede firmar una deuda que no podría pagar y ofrece otra ayuda.


**Caso 2. La llamada a Chayo**

Un despacho le exige a Chayo pagar la tarjeta de una conocida de la que solo es referencia.
- *¿Qué hace?* No paga y reporta al despacho en el REDECO.


**Caso 3. La renta de Rosa**

Rosa le pide a Mari que firme como fiadora de su renta.
- *¿Qué hace?* Lee el contrato y solo firma si podría pagar la renta completa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar «nada más como aval» | La deuda puede ser tuya | Solo si podrías pagar |
| Pagar como referencia | Pierdes dinero | No te pueden cobrar |
| No leer | Firmas otra cosa | Lee el papel |
| Callar los abusos | Siguen | REDECO |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién NO puede ser cobrado por un despacho? a) El aval · b) La referencia personal · c) El obligado solidario
2. Firmaste como aval de 20,000 y no pagan. ¿Cuánto te pueden cobrar? a) Todo lo que se debe · b) Nada · c) Solo los intereses del último mes
3. ¿Dónde reportas a un despacho que te cobra como referencia? a) En la tienda donde se hizo la compra · b) En el REDECO de la CONDUSEF · c) En la escuela de tus nietas
**Respuestas:** 1-b: solo dio sus datos. 2-a: el aval responde por todo. 3-b: registro de despachos.



#### Ponlo en práctica

Tu yerno debe 18,000 y deja de pagar. Tú firmaste como aval. Si pagas 1,500 al mes, ¿en cuántos meses terminas?
**Respuesta:** 18,000 entre 1,500: 12 meses.



#### A tu plan

Antes de firmar por alguien, pregúntate: ¿podría pagar esta deuda completa? Si no, di que no.



### Para saber más

- **REDECO** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REDECO» y despachos de cobranza.

### Palabras clave

- *Aval:* persona que firma el pagaré y paga si quien pidió no paga.
- *Obligado solidario:* persona que responde por todo el crédito como si lo hubiera pedido.
- *Referencia personal:* persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no firma ni se obliga a pagar.

### Fuentes

CONDUSEF, reglas de despachos de cobranza y REDECO, consultado el 30 de septiembre de 2026.

---

## M4 U04. Decir que no sin culpa y hablar de dinero en casa

**Lo que lograrás:** Reconocer el estrés por dinero, decir que no sin romper la relación y tener una plática de dinero en familia de 20 minutos.

**Para empezar:** Mari no duerme bien. Su mamá, su hermano y su hijo le piden dinero y ella siente que si dice que no es mala hija, mala hermana y mala madre. En esta lección verás cómo decir que no sin culpa.

### Lo esencial (5 minutos)

#### El estrés por dinero se nota

No dormir, discutir por dinero, sentir culpa o dolor de cabeza cuando llegan los mensajes: son señales de estrés financiero. No es debilidad; le pasa a muchas personas que sostienen a su familia.



#### Decir que no en tres partes

1. Reconoce: «Entiendo que lo necesitas».
2. Di tu límite: «Este mes no puedo, ya tengo mi dinero repartido».
3. Ofrece otra ayuda: «Te acompaño a buscar opciones».



#### La plática de dinero de 20 minutos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Un día fijo | Tranquilos, sin prisas. | Una vez al mes. |
| Con números | Lo que entra y lo que sale. | Sin culpas. |
| Un acuerdo | Quién paga qué. | Por escrito. |

#### Un caso en un minuto

Mari empezó a decir: «Te quiero ayudar, pero este mes no puedo». Su hermano se enojó un día y después buscó otra forma. Cada primer domingo hace la plática de 20 minutos con su hijo. Duerme mejor.

> **Idea clave:** decir que no a una petición no es decir que no a la persona; reconoce, pon tu límite y ofrece otra ayuda.



#### Comprueba lo que entendiste

1. ¿Cuáles son las tres partes de un «no»?
*Respuesta:* Reconocer, poner tu límite y ofrecer otra ayuda.

2. ¿Cada cuándo es la plática de dinero?
*Respuesta:* Una vez al mes, en un día fijo.


#### Para recordar

- El estrés se nota.
- Reconoce, límite, otra ayuda.
- Plática de 20 minutos al mes.



### Profundiza (5 minutos más)

#### Frases que ayudan

| Cuando te dicen | Puedes responder |
|---|---|
| «Tú ganas más» | «Sí, y ya tengo repartido mi dinero» |
| «Es una emergencia» | «Vamos viendo qué otras opciones hay» |
| «Nunca me ayudas» | «Te ayudo con X cada mes; hoy no puedo más» |



#### Si el estrés no te deja vivir

Si no duermes, no comes o piensas en hacerte daño, pide ayuda hoy. La Línea de la Vida atiende las 24 horas en el 800 911 2000, sin costo.



#### Casos


**Caso 1. La culpa de Mari**

Mari siente que es mala hija si dice que no.
- *¿Qué hace?* Reconoce la necesidad, pone su límite y ofrece otra ayuda.


**Caso 2. Las peleas de Chayo**

Chayo y su esposo pelean cada vez que se habla de dinero.
- *¿Qué hace?* Proponen una plática de 20 minutos al mes con números.


**Caso 3. El insomnio de Doña Tere**

Doña Tere no duerme pensando en sus deudas.
- *¿Qué hace?* Hace su lista de deudas y busca apoyo; si no mejora, llama a la Línea de la Vida.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decir que sí a todo | Te hundes | Pon tu límite |
| Decir que no con enojo | Rompes la relación | Con calma |
| Hablar de dinero peleando | Nadie escucha | Día fijo |
| Callar el estrés | Te enfermas | Pide apoyo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Chayo y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es una señal de estrés por dinero? a) Dormir mal por las deudas · b) Anotar tus gastos cada día · c) Ahorrar el día que cobras
2. ¿Qué parte falta en este «no»: «Entiendo que lo necesitas, pero no puedo»? a) El enojo · b) Una explicación larga · c) Ofrecer otra ayuda
3. ¿A qué número llamas si el estrés no te deja vivir? a) Al 800 911 2000 · b) A la prestamista · c) Al banco
**Respuestas:** 1-a: es una señal. 2-c: cierra con otra ayuda. 3-a: Línea de la Vida.



#### Ponlo en práctica

Escribe tu «no» en tres partes para alguien que te pide 1,000 este mes.
**Respuesta:** Por ejemplo: «Entiendo que lo necesitas. Este mes ya tengo mi dinero repartido. Te acompaño a ver qué otra opción hay».



#### A tu plan

Elige un día de este mes para tu plática de dinero de 20 minutos.



### Para saber más

- **Línea de la Vida** (CONASAMA · español): https://www.gob.mx/conasama — **Qué buscar:** «Línea de la Vida 800 911 2000».

### Palabras clave

- *Estrés financiero:* preocupación constante por el dinero que afecta tu sueño, tu salud o tu familia.

### Fuentes

CONASAMA, Línea de la Vida, consultado el 30 de septiembre de 2026.

---

## M4 U05. Tu dinero a tu nombre: autonomía y violencia económica

**Lo que lograrás:** Reconocer la violencia económica, tener dinero y documentos a tu nombre y saber dónde pedir ayuda.

**Para empezar:** A Chayo su esposo le pide cada viernes todo lo que cobró «para administrarlo». Si ella quiere algo, tiene que pedírselo. Él sacó un crédito con la credencial de ella. En esta lección verás qué es la violencia económica.

### Lo esencial (5 minutos)

#### No es administración: es violencia

Si alguien te quita tu dinero, te impide trabajar, te exige cuentas de cada peso o usa tu nombre para endeudarse, es violencia económica. Es violencia y hay ayuda.



#### Tu autonomía

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta a tu nombre | Solo tú tienes la clave. | Aunque tengas poco. |
| Tus documentos | INE, CURP, actas en un lugar seguro. | Copia digital. |
| Tu fondo | Aunque sea chico. | Para salir si lo necesitas. |
| Prestar tu INE | Pueden sacar créditos a tu nombre. | Nunca. |

#### Dónde pedir ayuda

Si vives violencia, llama al 911 o acude al Centro de Justicia para las Mujeres de tu estado. En la Ciudad de México, Locatel *0311 o 55 5658 1111, Línea Mujeres, las 24 horas. La atención no tiene costo.

> **Dato vigente:** Línea Mujeres de Locatel (*0311 o 55 5658 1111, Ciudad de México) y 911 en todo el país. Consultado el 30 de septiembre de 2026 a través de Locatel y el Gobierno de México.



#### Un caso en un minuto

Chayo abrió una cuenta a su nombre y guarda ahí una parte de lo que cobra. Revisó su historial de crédito y reclamó el crédito que no pidió. Buscó orientación en el Centro de Justicia para las Mujeres.

> **Idea clave:** tener una cuenta, documentos y un fondo a tu nombre es tu derecho; si alguien controla tu dinero para dominarte, es violencia y hay ayuda.



#### Comprueba lo que entendiste

1. ¿Qué es violencia económica?
*Respuesta:* Cuando alguien controla, retiene o usa tu dinero para dominarte.

2. ¿A dónde llamas en una emergencia?
*Respuesta:* Al 911.


#### Para recordar

- Cuenta y documentos a tu nombre.
- Nunca prestes tu INE.
- Hay ayuda sin costo.



### Profundiza (5 minutos más)

#### Señales de violencia económica

| Señal | Ejemplo |
|---|---|
| Te quitan lo que ganas | «Dame todo lo que cobraste» |
| No te dejan trabajar | «Tú no sales a trabajar» |
| Usan tu nombre | Créditos con tu INE |
| Te esconden información | No sabes qué hay en la casa |



#### Si sacaron un crédito con tu nombre

Revisa tu reporte de crédito sin costo (M5 U05). Si hay algo que no pediste, reclámalo al buró y a la institución, y denuncia el uso de tu identidad.



#### Casos


**Caso 1. El viernes de Chayo**

El esposo de Chayo le pide todo lo que cobra.
- *¿Qué hace?* Abre una cuenta a su nombre, guarda una parte y busca orientación.


**Caso 2. La credencial de Mari**

Un familiar le pide a Mari su INE «para un trámite».
- *¿Qué hace?* No la presta; ofrece acompañarle al trámite.


**Caso 3. El crédito de Doña Tere**

Aparece un crédito a nombre de Doña Tere que ella no pidió.
- *¿Qué hace?* Revisa su reporte, reclama y denuncia el uso de su identidad.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es normal | Sigue la violencia | Pide ayuda |
| Todo en la cuenta de otro | Sin dinero propio | Cuenta a tu nombre |
| Prestar tu INE | Deudas ajenas | Nunca |
| Callar | Nadie te ayuda | 911 y Centros de Justicia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es violencia económica? a) Hacer juntos el presupuesto · b) Que te quiten lo que ganas · c) Ahorrar para una meta
2. ¿Qué haces si te piden tu INE para un trámite? a) La prestas porque le tienes confianza · b) Le mandas una foto · c) No la prestas y acompañas
3. ¿Qué tienes a tu nombre para tu autonomía? a) Cuenta, documentos y un fondo · b) Nada, porque todo lo guarda tu pareja · c) Solo el celular
**Respuestas:** 1-b: es control. 2-c: pueden usarla para créditos. 3-a: es tu derecho.



#### Ponlo en práctica

Cobras 2,500 a la semana y decides guardar 10% en tu cuenta a tu nombre. ¿Cuánto juntas en 12 semanas?
**Respuesta:** 250 por semana por 12: 3,000.



#### A tu plan

Guarda tus documentos en un lugar seguro, con copia en tu celular, y decide cuánto vas a guardar a tu nombre.



### Para saber más

- **Violencia económica** (Instituto Nacional de las Mujeres · español): https://www.gob.mx/inmujeres — **Qué buscar:** «violencia económica» y «Centros de Justicia para las Mujeres».

### Palabras clave

- *Violencia económica:* cuando otra persona controla, retiene o usa tu dinero o tus bienes para dominarte.
- *Autonomía económica:* poder decidir sobre tu propio dinero.

### Fuentes

Inmujeres · Locatel · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 5. Módulo 5. Deudas: salir y no volver

## M5 U01. ¿Cuánto debes en total?

**Lo que lograrás:** Hacer la lista de todas tus deudas, con cuánto debes, cuánto pagas y a quién, para ver el tamaño real del problema.

**Para empezar:** Doña Tere debe en la tienda de abonos, a una prestamista del barrio, a su comadre y en la tanda donde cobró primero. Cada semana paga un poco a cada una y nunca sabe cuánto debe en total. En esta lección harás tu lista.

### Lo esencial (5 minutos)

#### Lo que no se ve no se arregla

Mientras las deudas estén sueltas en la cabeza, parecen más chicas o más grandes de lo que son. Escribirlas todas en una hoja es el primer paso para salir.



#### Cuenta todas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tiendas en abonos | Muebles, celular, ropa. | Suman mucho. |
| Prestamistas y conocidos | Con o sin intereses. | Anótalas igual. |
| Tandas donde cobraste primero | También es deuda. | Lo que falta pagar. |
| Apps de préstamo | Las más caras. | Primero en la lista. |

#### La lista de Doña Tere

- Tienda de abonos: **6,400**
- Prestamista: **3,000**
- Comadre: **1,200**
- Tanda: **1,800**
- Debe en total: **12,400**
Paga 1,450 a la semana entre todas.


#### Un caso en un minuto

Doña Tere escribió su lista por primera vez. Le asustó el total, pero vio que la prestamista le cobra más que todas y decidió empezar por ahí (M5 U04).

> **Idea clave:** escribe todas tus deudas en una hoja, con lo que debes, lo que pagas y lo que te cobran; lo que ves, lo puedes arreglar.



#### Comprueba lo que entendiste

1. ¿La tanda donde cobraste primero es deuda?
*Respuesta:* Sí, lo que te falta pagar.

2. ¿Qué anotas de cada deuda?
*Respuesta:* A quién, cuánto debes, cuánto pagas y cuánto te cobran.


#### Para recordar

- Escríbelas todas.
- Incluye tandas y conocidos.
- El total te da el tamaño real.



### Profundiza (5 minutos más)

#### Tu lista de deudas

| A quién | Cuánto debes | Pago por semana | Interés o recargo | Fecha final |
|---|---|---|---|---|
| | | | | |
| | | | | |
| Total | | | | |



#### Cuánto de tu ingreso se va en deudas

Divide lo que pagas de deudas a la semana entre lo que te entra a la semana. Si pasa de 30%, estás en zona de riesgo: no tomes deudas nuevas.



#### Casos


**Caso 1. Las deudas sueltas de Doña Tere**

Doña Tere paga a cuatro personas y no sabe el total.
- *¿Qué hace?* Escribe todas en una lista con montos y pagos.


**Caso 2. La tanda de Chayo**

Chayo cobró primero en la tanda y no la cuenta como deuda.
- *¿Qué hace?* La anota en su lista con lo que le falta pagar.


**Caso 3. El 40% de Mari**

Mari paga 40% de lo que le entra en deudas y le ofrecen otra tarjeta.
- *¿Qué hace?* No toma deudas nuevas hasta bajar de 30%.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No anotar las deudas con conocidos | Olvidas pagos | Todas en la lista |
| Olvidar la tanda | Te quedas corta | Es deuda |
| Ver solo el pago semanal | No ves el total | Suma el total |
| Tomar más deuda arriba de 30% | Te hundes | Detente |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Debes 4,000, 2,500 y 1,500. ¿Cuánto debes en total? a) 6,500 · b) 8,000 · c) 4,000
2. Te entran 2,500 a la semana y pagas 1,000 de deudas. ¿Qué porcentaje es? a) 40% · b) 25% · c) 10%
3. ¿Cuál es deuda? a) Tu ahorro guardado en la cuenta del banco · b) Lo que te falta pagar en la tanda · c) Tu fondo de emergencia
**Respuestas:** 1-b: suma de las tres. 2-a: 1,000 entre 2,500. 3-b: debes esos pagos.



#### Ponlo en práctica

Pagas 300, 450 y 250 a la semana en tres deudas. Te entran 2,800 a la semana. ¿Qué porcentaje se va en deudas?
**Respuesta:** 1,000 entre 2,800: unos 36%. Está arriba de 30%.



#### A tu plan

Haz hoy tu lista de deudas con todas, incluidas tandas y conocidos.



### Para saber más

- **Deudas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «sobreendeudamiento».

### Palabras clave

- *Sobreendeudamiento:* cuando tus pagos de deudas son tan altos que ya no alcanza para lo básico.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M5 U02. Lo que de verdad cuesta un préstamo

**Lo que lograrás:** Calcular el costo total de un préstamo, entender el CAT y comparar tiendas en abonos, casas de empeño y bancos.

**Para empezar:** A Chayo le prestaron 3,000 en la tienda de abonos «a 150 por semana». Pagó 40 semanas. En esta lección verás cuánto le costó de verdad.

### Lo esencial (5 minutos)

#### El costo total

El costo real es **todo lo que pagas menos lo que te prestaron**. Así se comparan préstamos distintos.



#### El préstamo de Chayo

- Pago por semana: **150**
- Semanas: **40**
- Total pagado: **6,000**
Le prestaron 3,000: pagó 3,000 de más.


#### Antes de pedir

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| El CAT | Costo anual total, con comisiones. | Mientras más bajo, mejor. |
| Total a pagar | Pago por número de pagos. | Compáralo. |
| Empeño | Si no pagas, pierdes la prenda. | Revisa el refrendo. |
| «Sin revisar Buró» | Casi siempre muy caro. | Desconfía. |

#### Qué es el CAT

El CAT sirve para comparar créditos. Todas las instituciones reguladas deben decírtelo. Si no te lo dicen, pregunta.

> **Idea clave:** compara préstamos por el total que pagarás y por el CAT, no por el pago semanal.



#### Comprueba lo que entendiste

1. ¿Cómo calculas el costo real de un préstamo?
*Respuesta:* Todo lo que pagas menos lo que te prestaron.

2. ¿Para qué sirve el CAT?
*Respuesta:* Para comparar créditos con intereses y comisiones.


#### Para recordar

- Total pagado menos lo prestado.
- Compara el CAT.
- Desconfía de «sin Buró».



### Profundiza (5 minutos más)

#### Compara antes de pedir

| Pregunta | Préstamo A | Préstamo B |
|---|---|---|
| Cuánto te prestan | | |
| Pago y número de pagos | | |
| Total a pagar | | |
| CAT | | |
| Qué pasa si te atrasas | | |



#### Empeñar

En una casa de empeño dejas una prenda y te prestan una parte de su valor. Si no pagas o refrendas a tiempo, la pierdes. Verifica que esté registrada en la PROFECO.



#### Casos


**Caso 1. La tienda de Chayo**

Chayo pagó 6,000 por un préstamo de 3,000.
- *¿Qué hace la próxima vez?* Calcula el total y compara el CAT antes de pedir.


**Caso 2. El anillo de Doña Tere**

Doña Tere empeñó su anillo y no sabe cuándo vence.
- *¿Qué hace?* Revisa su boleta y anota la fecha para pagar o refrendar.


**Caso 3. El anuncio de Mari**

A Mari le ofrecen «préstamo sin revisar Buró» por WhatsApp.
- *¿Qué hace?* Desconfía, pide el CAT y verifica que la institución esté registrada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el pago semanal | Pagas el doble | Total a pagar |
| No preguntar el CAT | No puedes comparar | Pregúntalo |
| Olvidar la fecha del empeño | Pierdes la prenda | Anótala |
| Creer en «sin Buró» | Muy caro o fraude | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prestan 2,000 y pagas 120 por semana durante 25 semanas. ¿Cuánto pagas de más? a) 3,000 · b) 120 · c) 1,000
2. ¿Qué te dice el CAT? a) El pago semanal · b) El costo anual con intereses y comisiones · c) Cuánto te prestan y en cuántas semanas pagas
3. ¿Qué pasa si no pagas un empeño a tiempo? a) Pierdes la prenda · b) Te regalan el préstamo · c) Nada, te esperan siempre
**Respuestas:** 1-c: 3,000 menos 2,000. 2-b: sirve para comparar. 3-a: se queda con la prenda.



#### Ponlo en práctica

Préstamo A: 150 por 30 semanas. Préstamo B: 250 por 16 semanas. Los dos prestan 3,000. ¿Cuál cuesta menos?
**Respuesta:** A: 4,500, cuesta 1,500. B: 4,000, cuesta 1,000. Cuesta menos el B.



#### A tu plan

Para tu próxima deuda, pide por escrito el total a pagar y el CAT.



### Para saber más

- **Simulador de créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simuladores» y «CAT».
- **Casas de empeño registradas** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «casas de empeño».

### Palabras clave

- *CAT:* Costo Anual Total: porcentaje que incluye intereses y comisiones de un crédito en un año.
- *Refrendo:* pago para alargar el plazo de un empeño sin perder la prenda.

### Fuentes

CONDUSEF · PROFECO, consultados el 30 de septiembre de 2026.

---

## M5 U03. Prestamistas, «gota a gota» y apps que amenazan

**Lo que lograrás:** Reconocer los préstamos más peligrosos (prestamistas informales, «gota a gota» y apps montadeudas) y saber qué hacer si ya caíste.

**Para empezar:** A Doña Tere le prestaron 2,000 «gota a gota»: 100 diarios durante 24 días. Un día no pagó y el cobrador llegó a la casa donde trabaja. En esta lección verás cómo salir.

### Lo esencial (5 minutos)

#### Los más caros y peligrosos

Los préstamos «gota a gota» cobran diario, con intereses altísimos y cobranza con amenazas. Las apps montadeudas hacen lo mismo con tu celular.



#### El gota a gota de Doña Tere

- Diario: **100**
- Días: **24**
- Pagado: **2,400**
Por 2,000 prestados en menos de un mes: 20% al mes, casi 240% al año.


#### Señales de peligro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobro diario | Casi siempre gota a gota. | Muy caro. |
| Piden tus contactos | Para amenazarlos. | Montadeuda. |
| «Sin requisitos, al momento» | Sin registro. | Verifica en SIPRES. |
| Registrada en la CONDUSEF | Mínimo que debes revisar. | En el SIPRES. |

#### Un caso en un minuto

Doña Tere juntó con su fondo y su familia lo que faltaba, pagó y no volvió a pedir. Cuando la amenazaron, anotó los datos y denunció al 088.

> **Idea clave:** nunca pidas a prestamistas gota a gota ni a apps que piden tus contactos; si ya caíste, no pidas otro préstamo para pagar y denuncia las amenazas.



#### Comprueba lo que entendiste

1. ¿Qué señal tiene una app montadeudas?
*Respuesta:* Pide acceso a tus contactos y fotos.

2. ¿Dónde verificas si una institución está registrada?
*Respuesta:* En el SIPRES de la CONDUSEF.


#### Para recordar

- Cobro diario: peligro.
- Contactos: montadeuda.
- Verifica en el SIPRES.



### Profundiza (5 minutos más)

#### Si ya caíste

1. No pidas otro préstamo para pagar este.
2. Guarda capturas de mensajes y amenazas.
3. Avisa a tus contactos que no paguen nada.
4. Denuncia en el 088 de la Guardia Nacional o en la fiscalía de tu estado.
5. Quita los permisos a la app y desinstálala.



#### Si llegan a la casa donde trabajas

Explica con calma a la familia que es un cobro con amenazas y que ya lo denunciaste. Nadie tiene derecho a cobrarte con violencia ni en tu trabajo.

> **Dato vigente:** entre enero y febrero de 2026 la Policía Cibernética de la Ciudad de México recibió más de 5,800 reportes de apps de préstamo fraudulentas. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF y medios nacionales.



#### Casos


**Caso 1. El cobrador de Doña Tere**

El cobrador del gota a gota llegó a la casa donde trabaja Doña Tere.
- *¿Qué hace?* Explica a la familia, paga con apoyo sin pedir otro préstamo y denuncia las amenazas.


**Caso 2. La app de Chayo**

Chayo descargó una app que le pidió acceso a sus contactos.
- *¿Qué hace?* No pide el préstamo, quita permisos y desinstala la app.


**Caso 3. Los mensajes a Mari**

Le escriben a Mari para que pague la deuda de su sobrino en una app.
- *¿Qué hace?* No paga nada y guarda las capturas para denunciar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir gota a gota | Te hunde en días | Nunca |
| Pagar un préstamo con otro | Más deuda | Busca apoyo |
| Dar permisos a apps | Amenazas a tu familia | Revisa antes |
| Callar las amenazas | Siguen | 088 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prestan 1,000 y pagas 60 diarios por 20 días. ¿Cuánto pagas de más? a) 60 · b) 1,200 · c) 200
2. ¿Qué haces si una app te amenaza? a) Pides otro préstamo para pagar · b) Guardas capturas y denuncias · c) Borras todo sin guardar nada
3. ¿Dónde denuncias las amenazas? a) En el 088 · b) En la tienda de la esquina · c) En la misma app
**Respuestas:** 1-c: 1,200 menos 1,000. 2-b: sirven de prueba. 3-a: Guardia Nacional.



#### Ponlo en práctica

Un gota a gota te presta 3,000 y cobras 150 diarios por 25 días. ¿Cuánto pagas y cuánto de más?
**Respuesta:** 150 por 25: 3,750. Pagas 750 de más en menos de un mes.



#### A tu plan

Revisa las apps de tu celular y quita el acceso a contactos a las que no lo necesiten.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES» y «apps de préstamo».

### Palabras clave

- *Gota a gota:* préstamo informal con cobro diario, intereses altísimos y cobranza con amenazas.
- *App montadeudas:* app de préstamo sin registro que usa tus contactos y fotos para amenazarte y cobrarte de más.
- *SIPRES:* registro de la CONDUSEF donde verificas si una institución financiera está autorizada.

### Fuentes

CONDUSEF · Policía Cibernética de la Ciudad de México, consultados el 30 de septiembre de 2026.

---

## M5 U04. Tu plan para salir de deudas

**Lo que lograrás:** Elegir un orden para pagar tus deudas (bola de nieve o avalancha), negociar con quien te presta y no tomar deudas nuevas.

**Para empezar:** Con su lista en la mano, Doña Tere tiene 12,400 de deuda y paga 1,450 a la semana. No sabe por cuál empezar. En esta lección harás tu plan.

### Lo esencial (5 minutos)

#### Dos formas de ordenar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Avalancha | Primero la más cara. | Pagas menos intereses. |
| Bola de nieve | Primero la más chica. | Ves avances rápido. |
| Sin deudas nuevas | Mientras sales. | La regla de oro. |

#### Tu plan en cinco pasos

1. Tu lista de deudas completa (M5 U01).
2. Paga lo mínimo en todas para no atrasarte.
3. Lo que te sobre, a una sola: la más cara o la más chica.
4. Cuando termines una, ese pago pasa a la siguiente.
5. Si no puedes pagar, habla antes de atrasarte y negocia.



#### El plan de Doña Tere

- Pago a la prestamista: **500**
- Extra que encontró en su semana: **200**
- Pago a la prestamista: **700**
En cinco semanas termina con ella y esos 700 pasan a la tienda.


#### Un caso en un minuto

Doña Tere usó la avalancha: primero la prestamista, que le cobra 20% al mes. Habló con la tienda y le quitaron recargos por pagar a tiempo. En 5 meses bajó su deuda a la mitad.

> **Idea clave:** paga lo mínimo en todas, pon el extra en una sola y, al terminarla, pasa ese pago a la siguiente; no tomes deudas nuevas mientras sales.



#### Comprueba lo que entendiste

1. ¿Qué deuda pagas primero en la avalancha?
*Respuesta:* La más cara.

2. ¿Qué haces cuando terminas una?
*Respuesta:* Pasas ese pago a la siguiente.


#### Para recordar

- Mínimo en todas.
- Extra a una sola.
- Sin deudas nuevas.



### Profundiza (5 minutos más)

#### Tu orden

| Orden | Deuda | Por qué va aquí |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |



#### Negociar

Antes de atrasarte, habla: pide un plazo más largo, quitar recargos o pagar una cantidad fija. Pide todo por escrito. En bancos y tiendas reguladas puedes pedir apoyo a la CONDUSEF.



#### Casos


**Caso 1. Por dónde empieza Doña Tere**

Doña Tere tiene cuatro deudas y no sabe por cuál empezar.
- *¿Qué hace?* Paga lo mínimo en todas y pone el extra en la más cara.


**Caso 2. El atraso de Chayo**

Chayo sabe que la próxima semana no le alcanza para el abono.
- *¿Qué hace?* Habla antes con la tienda y negocia un pago menor por escrito.


**Caso 3. La oferta de Mari**

Mientras paga sus deudas, a Mari le ofrecen un celular en abonos.
- *¿Qué hace?* No toma deudas nuevas hasta terminar su plan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar un poco a todas sin orden | Tardas años | Extra a una sola |
| Esconderte | Recargos | Habla antes |
| Deudas nuevas | No sales | Espera |
| Acuerdos de palabra | Luego no se respetan | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. En la bola de nieve, ¿cuál pagas primero? a) La más grande · b) La más chica · c) La más reciente
2. ¿Qué haces si sabes que te vas a atrasar? a) Hablas antes y negocias · b) Cambias de número para que no te encuentren · c) Pides otro préstamo
3. Terminas una deuda donde pagabas 300. ¿Qué haces con esos 300? a) Los gastas en gustos · b) Los guardas para gastarlos solo en diciembre · c) Los pasas a la siguiente deuda
**Respuestas:** 1-b: ves avances rápido. 2-a: evitas recargos. 3-c: así aceleras.



#### Ponlo en práctica

Debes 2,100 a una prestamista y le pagas 300 por semana. Si le agregas 120 extra, ¿en cuántas semanas terminas?
**Respuesta:** 420 por semana: 2,100 entre 420, 5 semanas.



#### A tu plan

Elige avalancha o bola de nieve y escribe tu orden de deudas.



### Para saber más

- **Planea tus pagos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cómo salir de deudas».

### Palabras clave

- *Avalancha:* pagar primero la deuda más cara.
- *Bola de nieve:* pagar primero la deuda más chica.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M5 U05. Tu historial de crédito sin miedo

**Lo que lograrás:** Saber qué es el Buró de Crédito, pedir tu reporte sin costo, reclamar errores y construir un buen historial.

**Para empezar:** Mari quiere un crédito para arreglar su casa y le dijeron que «está en Buró». Tiene miedo de preguntar. En esta lección verás qué es y cómo revisarlo.

### Lo esencial (5 minutos)

#### No es una lista negra

El Buró de Crédito guarda cómo pagas: lo bueno y lo malo. Todas las personas que han tenido un crédito «están en Buró». Lo que importa es cómo pagaste.



#### Lo que ayuda y lo que no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pagar a tiempo | Construye buen historial. | Lo más importante. |
| Revisar tu reporte | Una vez al año sin costo. | Busca errores. |
| Atrasarte | Queda registrado. | Habla antes. |
| «Limpiamos tu Buró» | Nadie puede borrarlo pagando. | Es fraude. |

#### Tu reporte sin costo

Puedes pedir tu reporte especial una vez al año sin costo en Buró de Crédito y en Círculo de Crédito, en sus sitios oficiales. Si hay un error o un crédito que no pediste, puedes reclamarlo.



#### Un caso en un minuto

Mari pidió su reporte. Tenía una deuda vieja de una tienda que ya había pagado y aparecía como pendiente. La reclamó con el comprobante y la corrigieron.

> **Idea clave:** estar en Buró no es malo; revisa tu reporte cada año sin costo y paga a tiempo para construir buen historial.



#### Comprueba lo que entendiste

1. ¿Cada cuándo puedes pedir tu reporte sin costo?
*Respuesta:* Una vez al año.

2. ¿Alguien puede borrar tu historial si le pagas?
*Respuesta:* No, es fraude.


#### Para recordar

- Buró no es lista negra.
- Reporte sin costo cada año.
- Nadie lo «limpia» pagando.



### Profundiza (5 minutos más)

#### Tu reporte

| Revisa | Si hay error |
|---|---|
| Tus datos personales | Pide corrección |
| Créditos que no reconoces | Reclama y denuncia |
| Deudas pagadas como pendientes | Reclama con comprobante |
| Atrasos | Paga y construye historial |



#### Tarjeta de crédito para construir historial

Si quieres empezar historial, una tarjeta con límite bajo, usada poco y pagada completa cada mes, ayuda. No la uses para gastos que no podrías pagar.



#### Casos


**Caso 1. El miedo de Mari**

Le dijeron a Mari que «está en Buró» y no quiere preguntar.
- *¿Qué hace?* Pide su reporte sin costo y revisa qué dice.


**Caso 2. La deuda pagada de Doña Tere**

Aparece como pendiente una deuda que Doña Tere ya pagó.
- *¿Qué hace?* La reclama con su comprobante de pago.


**Caso 3. El anuncio de Chayo**

A Chayo le ofrecen «limpiar su Buró» por 1,500.
- *¿Qué hace?* No paga: nadie puede borrar el historial.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es lista negra | Te da miedo | Revísalo |
| No revisar nunca | Errores sin corregir | Cada año |
| Pagar para «limpiar» | Fraude | Nadie lo borra |
| Atrasarte sin avisar | Queda registrado | Habla antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Doña Tere y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el Buró de Crédito? a) Tu historial de pagos · b) Una lista negra de morosos · c) Un banco que presta
2. ¿Cuántas veces al año puedes pedir tu reporte sin costo? a) Ninguna, siempre cuesta · b) Doce · c) Una
3. Te ofrecen «limpiar tu Buró» por 1,500. ¿Qué es? a) Un servicio oficial · b) Un fraude · c) Un trámite del banco
**Respuestas:** 1-a: lo bueno y lo malo. 2-c: una vez al año. 3-b: nadie lo borra pagando.



#### Ponlo en práctica

Tienes una tarjeta con límite de 3,000 y quieres usar menos de 30%. ¿Cuánto es lo máximo que gastas al mes?
**Respuesta:** 30% de 3,000: 900.



#### A tu plan

Pide tu reporte de crédito sin costo este mes y revísalo.



### Para saber más

- **Reporte de crédito especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** «reporte de crédito especial».
- **Reporte de Círculo de Crédito** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** «reporte de crédito».

### Palabras clave

- *Buró de Crédito:* empresa que guarda tu historial de cómo pagas tus créditos.
- *Historial de crédito:* registro de tus créditos y de cómo los pagaste.

### Fuentes

Buró de Crédito · Círculo de Crédito · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 6. Módulo 6. Tu salud y tu protección

## M6 U01. Cuando la casa te inscribe al IMSS

**Lo que lograrás:** Conocer qué te da el IMSS cuando la casa donde trabajas te inscribe, cómo funciona si trabajas en varias casas y cómo platicarlo.

**Para empezar:** La señora con quien trabaja Mari le dijo: «Te puedo inscribir al IMSS, pero no sé cómo y no sé si te conviene». Mari tampoco sabe qué ganaría. En esta lección lo verás.

### Lo esencial (5 minutos)

#### Qué te da el IMSS

Si la casa te inscribe, tienes seguridad social: médico y hospital para ti y tu familia, pago de incapacidades si te enfermas o te accidentas, guardería, semanas para tu pensión y ahorro en tu Afore.



#### Lo que ganas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Servicio médico | Para ti y tus hijos, y tu pareja o padres según el caso. | Consultas, hospital, medicinas. |
| Incapacidades | Te pagan una parte si no puedes trabajar. | Por enfermedad o accidente. |
| Guardería | Para tus hijos pequeños. | Según el caso. |
| Pensión y Afore | Semanas y ahorro para tu vejez. | Cada mes suma. |

#### Si trabajas en varias casas

En el esquema de personas trabajadoras del hogar del IMSS, cada casa puede inscribirte y pagar por los días y el salario que trabajas con ella. No tiene que ser una sola casa.

> **Dato vigente:** el IMSS permite que cada persona empleadora inscriba a la trabajadora del hogar y pague sus cuotas de forma individual, según los días laborados y el salario, en línea o en la App IMSS Digital. Consultado el 30 de septiembre de 2026 a través del IMSS (esquema de Personas Trabajadoras del Hogar).



#### Un caso en un minuto

Mari y la señora vieron juntas la calculadora de cuotas del IMSS. La señora la inscribió. Tres meses después Mari se fracturó la muñeca: la atendieron y le pagaron su incapacidad.

> **Idea clave:** si una casa te inscribe al IMSS ganas médico, incapacidades, guardería y semanas para tu pensión; cada casa puede inscribirte por los días que trabajas con ella.



#### Comprueba lo que entendiste

1. ¿Tiene que ser una sola casa la que te inscriba?
*Respuesta:* No, cada casa puede inscribirte por los días que trabajas con ella.

2. ¿Qué es una incapacidad?
*Respuesta:* Un pago del IMSS cuando no puedes trabajar por enfermedad o accidente.


#### Para recordar

- Médico, incapacidades, guardería, pensión.
- Cada casa puede inscribirte.
- Se calcula por días y salario.



### Profundiza (5 minutos más)

#### Para platicarlo con la casa

| Llévale | Por qué |
|---|---|
| Tu CURP y tu número de seguridad social (NSS) | Para inscribirte |
| Tus días y tu pago | Para calcular la cuota |
| La página del IMSS para trabajadoras del hogar | Tiene calculadora y trámite en línea |



#### Cómo proponerlo

«Me gustaría tener IMSS por los días que trabajo aquí. En la página del IMSS hay una calculadora y el trámite es en línea. ¿Lo vemos juntas?». Muchas familias no lo hacen porque no saben cómo; mostrarles la página ayuda.



#### Casos


**Caso 1. La propuesta de Mari**

La señora le ofrece a Mari inscribirla, pero no sabe cómo.
- *¿Qué hace?* Revisan juntas la página del IMSS y la calculadora de cuotas.


**Caso 2. Las cuatro casas de Doña Tere**

Doña Tere cree que no puede tener IMSS porque trabaja en cuatro casas.
- *¿Qué hace?* Pregunta en cada casa si pueden inscribirla por sus días.


**Caso 3. El NSS de Chayo**

Chayo no sabe su número de seguridad social.
- *¿Qué hace?* Lo consulta con su CURP en el sitio o la app del IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que solo es para quien trabaja de planta | Te quedas sin nada | Cada casa puede inscribirte |
| No saber tu NSS | Retrasas el trámite | Consúltalo con tu CURP |
| No preguntar | Nadie te lo ofrece | Propónlo con la página |
| Pagar a gestores | Te cobran por algo sencillo | Trámite en línea |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Doña Tere y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué te da el IMSS si la casa te inscribe? a) Solo medicinas · b) Médico, incapacidades, guardería y pensión · c) Un préstamo con descuento para tu familia y tu casa
2. Trabajas en tres casas. ¿Quién puede inscribirte? a) Nadie · b) Solo la casa donde más días trabajas · c) Cada casa, por tus días con ella
3. ¿Con qué consultas tu número de seguridad social? a) Con tu CURP · b) Con tu recibo de luz · c) Con tu acta de matrimonio
**Respuestas:** 1-b: son los seguros del régimen. 2-c: cada una paga su parte. 3-a: en el sitio o la app del IMSS.



#### Ponlo en práctica

Trabajas 2 días a la semana en una casa y 3 en otra. ¿Qué días cubre la cuota de cada casa?
**Respuesta:** La primera casa paga por 2 días a la semana y la segunda por 3.



#### A tu plan

Consulta tu NSS con tu CURP y elige una casa con quien platicarlo.



### Para saber más

- **Personas Trabajadoras del Hogar** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-hogar — **Qué buscar:** «inscripción», «calculadora de cuotas» y «beneficios».

### Palabras clave

- *Seguridad social:* protección que da el IMSS: servicio médico, incapacidades, guardería, pensión y ahorro para el retiro.
- *NSS:* número de seguridad social que te identifica en el IMSS.
- *Incapacidad:* pago del IMSS cuando no puedes trabajar por enfermedad o accidente.

### Fuentes

IMSS, esquema de Personas Trabajadoras del Hogar, consultado el 30 de septiembre de 2026.

---

## M6 U02. IMSS por tu cuenta: inscríbete tú y paga tu cuota

**Lo que lograrás:** Conocer las formas de tener IMSS pagando tú la cuota (Seguro de Salud para la Familia y personas trabajadoras independientes), cuánto cuestan en 2026 y cómo decidir.

**Para empezar:** Ninguna de las casas de Chayo la inscribe. Su mamá, de 62 años, necesita médico seguido y su hija es chica. Chayo escuchó que se puede «pagar el IMSS por tu cuenta». En esta lección verás cómo.

### Lo esencial (5 minutos)

#### Seguro de Salud para la Familia

El Seguro de Salud para la Familia (también llamado Modalidad 33) es para quien no tiene seguridad social. Da consultas, hospital y medicinas. Se paga una cuota al año por cada persona que inscribes, según su edad.



#### Cuota anual por persona en 2026

| Edad | Cuota al año |
|---|---|
| 0 a 19 | 9,300 |
| 20 a 29 | 11,550 |
| 30 a 39 | 11,850 |
| 40 a 49 | 13,800 |
| 50 a 59 | 14,250 |
| 60 a 69 | 19,800 |
| 70 a 79 | 20,650 |
| 80 o más | 21,300 |

> **Dato vigente:** cuotas anuales del Seguro de Salud para la Familia (Modalidad 33) por persona según la edad, vigentes desde el 1 de marzo de 2026. Consultado el 30 de septiembre de 2026 a través de medios nacionales que citan las tablas del IMSS; confirma en tu clínica o en el IMSS antes de pagar.



#### Lo que da y lo que no

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sí da | Consultas, hospital y medicinas. | Para cada persona inscrita. |
| Periodos de espera | Algunas atenciones se cubren después de meses. | Pregunta cuáles. |
| No da | Incapacidades, pensión ni guardería. | Solo salud. |
| Enfermedades previas | Algunas no se cubren al inicio. | Pregunta antes. |

#### Personas trabajadoras independientes

El IMSS también tiene un esquema para quien trabaja por su cuenta (Modalidad 10), con médico, incapacidades, semanas para la pensión y Afore. La cuota se paga cada mes según el ingreso que registras; con un salario mínimo ronda 2,500 al mes. Como el trabajo del hogar es trabajo para una casa, **pregunta en el IMSS si puedes inscribirte así** cuando trabajas por días en varias casas.



#### Un caso en un minuto

Chayo sacó cuentas: inscribir a su mamá (19,800) y a su hija (9,300) cuesta 29,100 al año, unos 2,425 al mes. Empezó con su mamá, que es quien más lo necesita, y aparta cada semana para pagar la cuota. Para su hija usa los servicios de IMSS-Bienestar (M6 U03).

> **Idea clave:** si nadie te inscribe, puedes pagar tú el Seguro de Salud para la Familia por persona y edad; da médico, pero no incapacidades ni pensión. Pregunta antes qué cubre y desde cuándo.



#### Comprueba lo que entendiste

1. ¿Qué da el Seguro de Salud para la Familia?
*Respuesta:* Servicio médico: consultas, hospital y medicinas.

2. ¿Qué no da?
*Respuesta:* Incapacidades, pensión ni guardería.


#### Para recordar

- Cuota al año por persona y edad.
- Solo salud.
- Pregunta periodos de espera.



### Profundiza (5 minutos más)

#### ¿Cuál te sirve?

| Si necesitas | Opción |
|---|---|
| Médico para ti o tu familia | Seguro de Salud para la Familia |
| Médico, incapacidades y pensión | Que una casa te inscriba (M6 U01) o, si aplica, el esquema de independientes |
| Médico y no puedes pagar cuota | IMSS-Bienestar (M6 U03) |



#### Cómo juntar la cuota

Divide la cuota anual entre 52 semanas y apártala como un gasto fijo. Por ejemplo, 13,800 al año son unos 265 a la semana.



#### Casos


**Caso 1. La mamá de Chayo**

La mamá de Chayo tiene 62 años, no tiene seguridad social y necesita médico seguido.
- *¿Qué hace?* Revisa el Seguro de Salud para la Familia y aparta la cuota cada semana.


**Caso 2. La diabetes de Doña Tere**

Doña Tere tiene diabetes y quiere inscribirse para que le den su tratamiento.
- *¿Qué hace?* Pregunta antes si su enfermedad se cubre y desde cuándo.


**Caso 3. La pensión de Mari**

Mari cree que con el seguro de salud también suma semanas para su pensión.
- *¿Qué hace?* Sabe que solo da salud y busca que una casa la inscriba para sumar semanas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que da pensión | No sumas semanas | Solo salud |
| No preguntar por enfermedades previas | Sorpresas | Pregunta antes |
| Pagar a gestores | Te cobran de más | Trámite en el IMSS |
| Juntar la cuota al final | No la tienes | Aparta cada semana |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta al año el Seguro de Salud para la Familia para una persona de 45 años en 2026? a) 9,300 · b) 13,800 · c) 21,300
2. ¿Qué NO da el Seguro de Salud para la Familia? a) Hospital · b) Consultas · c) Pensión
3. La cuota anual es de 11,550. ¿Cuánto apartas por semana, más o menos? a) 222 · b) 1,155 · c) 50
**Respuestas:** 1-b: de 40 a 49 años. 2-c: solo es salud. 3-a: 11,550 entre 52.



#### Ponlo en práctica

Quieres inscribirte tú (35 años) y a tu hijo (12 años). ¿Cuánto pagas al año y cuánto por semana?
**Respuesta:** 11,850 más 9,300: 21,150 al año. Entre 52: unos 407 por semana.



#### A tu plan

Calcula la cuota de las personas de tu familia que no tienen seguridad social y decide por quién empezar.



### Para saber más

- **Seguro de Salud para la Familia** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «Seguro de Salud para la Familia» y requisitos.
- **Personas trabajadoras independientes** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-independientes — **Qué buscar:** requisitos y calculadora.

### Palabras clave

- *Seguro de Salud para la Familia:* seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- *Periodo de espera:* tiempo que tiene que pasar desde que te inscribes para que te cubran ciertas atenciones.

### Fuentes

IMSS · medios nacionales que citan las cuotas 2026, consultados el 30 de septiembre de 2026.

---

## M6 U03. Sin seguridad social: IMSS-Bienestar y tu prevención

**Lo que lograrás:** Saber dónde atenderte si no tienes seguridad social, qué documentos llevar y cómo prevenir para no perder días de trabajo.

**Para empezar:** Doña Tere no tiene IMSS. Cuando se enferma va a la farmacia de la esquina y pierde días de trabajo. Nunca se ha hecho un chequeo. En esta lección verás dónde atenderte.

### Lo esencial (5 minutos)

#### Si no tienes seguridad social

Si no tienes IMSS, ISSSTE ni otra seguridad social, puedes atenderte en los centros de salud y hospitales públicos. En muchos estados funcionan con **IMSS-Bienestar**; en otros, con los servicios de salud del estado. La atención y los medicamentos para personas sin seguridad social no tienen costo.



#### Lo que te ayuda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu CURP e INE | Para registrarte. | Llévalas siempre. |
| Chequeo una vez al año | Presión, azúcar, peso. | Encuentra a tiempo. |
| Revisiones de la mujer | Papanicolaou y mama. | Según tu edad. |
| Automedicarte | Gastas y no te curas. | Evítalo. |

#### Un caso en un minuto

Doña Tere fue a su centro de salud con su CURP. Le hicieron un chequeo y le encontraron la presión alta a tiempo. Ahora lleva su control sin costo y no ha perdido días de trabajo.

> **Idea clave:** sin seguridad social puedes atenderte sin costo en el centro de salud; un chequeo al año te ayuda a no perder días de trabajo.



#### Comprueba lo que entendiste

1. ¿Dónde te atiendes si no tienes seguridad social?
*Respuesta:* En el centro de salud u hospital público de tu zona.

2. ¿Qué llevas?
*Respuesta:* Tu CURP y tu identificación.


#### Para recordar

- Centro de salud sin costo.
- CURP e INE.
- Chequeo cada año.



### Profundiza (5 minutos más)

#### Tu calendario de salud

| Revisión | Cada cuándo |
|---|---|
| Presión y azúcar | Una vez al año |
| Papanicolaou | Según indicación médica |
| Mastografía | Desde los 40, según indicación |
| Vacunas | Las de tu edad |



#### Enfermarte también cuesta

Si cobras por día, un día enferma es un día sin ingreso. Prevenir es cuidar tu dinero: chequeos, tu fondo de emergencia (M3 U03) y descanso.



#### Casos


**Caso 1. La farmacia de Doña Tere**

Doña Tere se automedica en la farmacia cada vez que se enferma.
- *¿Qué hace?* Va a su centro de salud con su CURP y se hace un chequeo.


**Caso 2. La nieta de Chayo**

La nieta de Chayo no tiene seguridad social y se enfermó.
- *¿Qué hace?* La lleva al centro de salud con su CURP.


**Caso 3. El papanicolaou de Mari**

Mari nunca se ha hecho el papanicolaou porque no tiene IMSS.
- *¿Qué hace?* Pregunta en su centro de salud; no necesita IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Automedicarte | No te curas | Centro de salud |
| Esperar a estar muy mal | Más días sin trabajo | Chequeo cada año |
| Creer que sin IMSS no hay atención | No te atiendes | Centro de salud |
| No llevar la CURP | Retrasa | Llévala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta atenderte en el centro de salud si no tienes seguridad social? a) Lo mismo que un médico privado · b) Una cuota al año · c) No tiene costo
2. ¿Qué llevas para registrarte? a) Tu CURP e identificación · b) Tu recibo de nómina de la casa · c) Tu tarjeta del banco
3. ¿Por qué prevenir cuida tu dinero? a) Porque te regalan medicinas · b) Porque evitas perder días de trabajo · c) Porque en el centro de salud te pagan por ir a consulta
**Respuestas:** 1-c: para personas sin seguridad social. 2-a: te registran con ellas. 3-b: cobras por día.



#### Ponlo en práctica

Cobras 550 por día y una enfermedad sin atender te quita 4 días. ¿Cuánto dejas de ganar?
**Respuesta:** 550 por 4: 2,200.



#### A tu plan

Agenda un chequeo en tu centro de salud este mes.



### Para saber más

- **IMSS-Bienestar** (Gobierno de México · español): https://www.gob.mx/imss-bienestar — **Qué buscar:** «unidades médicas» y «atención sin seguridad social».

### Palabras clave

- *IMSS-Bienestar:* servicio de salud para personas sin seguridad social en los estados que se sumaron.
- *Chequeo:* revisión médica para encontrar problemas a tiempo.

### Fuentes

IMSS-Bienestar · Secretaría de Salud, consultados el 30 de septiembre de 2026.

---

## M6 U04. Cuida tu cuerpo, cuida tu ingreso

**Lo que lograrás:** Prevenir accidentes y lesiones en el trabajo del hogar (químicos, escaleras, cargas) y saber qué hacer si te pasa algo en una casa.

**Para empezar:** Chayo mezcló cloro con otro limpiador para que rindiera más y se mareó. Doña Tere se cayó de una escalera limpiando ventanas. En esta lección verás cómo cuidarte.

### Lo esencial (5 minutos)

#### Tu cuerpo es tu herramienta

Si te lastimas, no puedes trabajar y no cobras. Los accidentes más comunes en el trabajo del hogar son caídas, cortes, quemaduras, dolores de espalda y problemas por mezclar químicos.



#### Reglas de cuidado

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| No mezcles químicos | Cloro con amoniaco o ácidos es tóxico. | Uno a la vez. |
| Guantes | Para limpiadores fuertes. | Pídelos a la casa. |
| Escaleras firmes | Nada de sillas ni banquitos. | Si no hay, no subas. |
| Cargas | Dobla las rodillas, no la espalda. | Pide ayuda. |

#### Un caso en un minuto

Chayo ya no mezcla limpiadores y lleva sus guantes. Doña Tere acordó con las familias que no sube a limpiar ventanas altas sin escalera firme.

> **Idea clave:** no mezcles químicos, usa guantes y escalera firme; si no hay condiciones seguras, dilo antes de hacerlo.



#### Comprueba lo que entendiste

1. ¿Por qué no mezclar cloro con otros limpiadores?
*Respuesta:* Porque puede soltar gases tóxicos.

2. ¿Qué haces si no hay escalera firme?
*Respuesta:* No subes y lo dices.


#### Para recordar

- Un químico a la vez.
- Guantes y escalera firme.
- Dilo antes de arriesgarte.



### Profundiza (5 minutos más)

#### Si te pasa algo en una casa

| Paso | Qué hacer |
|---|---|
| 1 | Atiéndete: 911 si es grave, centro de salud si no |
| 2 | Avisa a la familia por mensaje |
| 3 | Guarda recetas y notas médicas |
| 4 | Si tienes IMSS, pide tu incapacidad |



#### Si el accidente fue por trabajar

Si te accidentas trabajando y la casa te tiene inscrita al IMSS, es un riesgo de trabajo y el IMSS lo atiende y paga la incapacidad. Si no te tiene inscrita, pide orientación en la PROFEDET.



#### Casos


**Caso 1. El cloro de Chayo**

Chayo mezcla cloro con otro limpiador para que rinda.
- *¿Qué hace?* Usa un solo producto a la vez y ventila.


**Caso 2. La ventana de Doña Tere**

Le piden a Doña Tere limpiar una ventana alta y solo hay una silla.
- *¿Qué hace?* No se sube a la silla y pide una escalera firme.


**Caso 3. La caída de Mari**

Mari se cayó en la casa donde trabaja y le duele la muñeca.
- *¿Qué hace?* Se atiende, avisa por mensaje y guarda las notas médicas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mezclar químicos | Intoxicación | Uno a la vez |
| Subir a sillas | Caídas | Escalera firme |
| Cargar con la espalda | Lesiones | Dobla las rodillas |
| No avisar el accidente | Sin pruebas | Mensaje a la familia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si mezclas cloro con amoniaco? a) Limpia mejor · b) Suelta gases tóxicos · c) Nada
2. Solo hay una silla para limpiar una ventana alta. ¿Qué haces? a) Pides una escalera firme · b) Te subes con cuidado · c) Pones la silla sobre la mesa
3. Te accidentas en una casa. ¿Qué guardas? a) Nada, ya pasó · b) Solo la foto del lugar donde te caíste y del piso mojado · c) Recetas, notas médicas y el mensaje de aviso
**Respuestas:** 1-b: es peligroso. 2-a: evita caídas. 3-c: son tus pruebas.



#### Ponlo en práctica

Cobras 500 por día. Una caída te deja 10 días sin trabajar y no tienes IMSS. ¿Cuánto dejas de ganar?
**Respuesta:** 500 por 10: 5,000.



#### A tu plan

Revisa qué limpiadores usas en cada casa y pide guantes donde no haya.



### Para saber más

- **Riesgos de trabajo** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «riesgos de trabajo».

### Palabras clave

- *Riesgo de trabajo:* accidente o enfermedad que te pasa por tu trabajo.

### Fuentes

IMSS · Secretaría de Salud, consultados el 30 de septiembre de 2026.

---

## M6 U05. Seguros chiquitos: vida y gastos funerarios

**Lo que lograrás:** Entender los seguros de vida y los planes de previsión funeraria, qué revisar antes de contratar y cómo nombrar beneficiarios.

**Para empezar:** Cuando murió su mamá, Doña Tere pidió prestado 25,000 para el funeral. Todavía lo está pagando. Ahora piensa: «Si me pasa algo, no quiero que mi hija se endeude». En esta lección verás tus opciones.

### Lo esencial (5 minutos)

#### Para qué sirve

Un seguro de vida protege a quien depende de ti. Un plan de previsión funeraria cubre el funeral. Los dos evitan que tu familia se endeude.



#### Antes de contratar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lee qué cubre | Y qué no cubre. | Pide la póliza. |
| Beneficiarios | Nombres completos y parte de cada quien. | Actualízalos. |
| Empresa registrada | Aseguradora en la CONDUSEF; funeraria en la PROFECO. | Verifica. |
| Pagar en efectivo sin recibo | No hay prueba. | Nunca. |

#### El plan de Doña Tere

- Al mes: **180**
- Meses: **12**
- Al año: **2,160**
Mucho menos que endeudarse de golpe.


#### Un caso en un minuto

Doña Tere comparó dos planes, verificó que la funeraria estuviera registrada en la PROFECO y puso a su hija Rosa como beneficiaria de su seguro de vida del banco.

> **Idea clave:** un seguro chico o un plan funerario evita que tu familia se endeude; verifica la empresa y nombra a tus beneficiarios con nombre completo.



#### Comprueba lo que entendiste

1. ¿Dónde verificas una funeraria con plan de previsión?
*Respuesta:* En la PROFECO.

2. ¿Qué pones de cada beneficiaria?
*Respuesta:* Nombre completo y qué parte le toca.


#### Para recordar

- Lee qué cubre.
- Verifica la empresa.
- Nombra beneficiarios.



### Profundiza (5 minutos más)

#### Seguro de vida contra plan funerario

| Punto | Seguro de vida | Plan funerario |
|---|---|---|
| Qué paga | Dinero a tus beneficiarias | Los servicios del funeral |
| Quién lo vigila | CONDUSEF | PROFECO |
| Cuidado con | Exclusiones | Empresas sin registro |



#### Seguros que ya tienes

Algunas cuentas y créditos incluyen un seguro de vida. Pregunta en tu banco si tienes uno y quién es tu beneficiaria.



#### Casos


**Caso 1. El miedo de Doña Tere**

Doña Tere no quiere que su hija se endeude por su funeral.
- *¿Qué hace?* Compara planes, verifica en la PROFECO y nombra beneficiarias.


**Caso 2. El vendedor de Chayo**

Un vendedor de puerta en puerta le ofrece a Chayo un plan funerario en efectivo sin recibo.
- *¿Qué hace?* No paga sin contrato ni recibo, y verifica la empresa.


**Caso 3. La cuenta de Mari**

Mari no sabe si su cuenta tiene seguro de vida.
- *¿Qué hace?* Pregunta en el banco y revisa quién es su beneficiaria.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No leer la póliza | Sorpresas | Pide y lee |
| Empresa sin registro | Pierdes lo pagado | Verifica |
| Beneficiarios viejos | El dinero va a otra persona | Actualízalos |
| Pagar sin recibo | Sin prueba | Nunca |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué institución vigila los planes de previsión funeraria? a) El Banco de México · b) La PROFECO · c) El IMSS
2. ¿Qué pones al nombrar beneficiarias? a) Solo el apodo con el que la conoce toda la familia · b) Solo el parentesco · c) Nombre completo y parte de cada una
3. Pagas 150 al mes por un plan. ¿Cuánto pagas al año? a) 1,800 · b) 150 · c) 15,000
**Respuestas:** 1-b: registro de planes funerarios. 2-c: así no hay dudas. 3-a: 150 por 12.



#### Ponlo en práctica

Un funeral cuesta 25,000. Si lo pides prestado al 5% mensual y pagas en 12 meses, ¿cuánto pagas de intereses solo el primer mes?
**Respuesta:** 5% de 25,000: 1,250 solo el primer mes.



#### A tu plan

Pregunta en tu banco si tu cuenta tiene seguro de vida y revisa quién es tu beneficiaria.



### Para saber más

- **Previsión funeraria** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «previsión funeraria» y registro de contratos.
- **Seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de vida» y «seguro básico estandarizado».

### Palabras clave

- *Seguro de vida:* contrato que paga una cantidad a las personas que nombras si falleces.
- *Previsión funeraria:* plan que pagas en abonos para cubrir un funeral cuando se necesite.
- *Beneficiaria:* persona que recibe el dinero de un seguro o cuenta si falleces.

### Fuentes

PROFECO · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 7. Módulo 7. Fraudes y tu celular

## M7 U01. «Mamá, estoy en problemas»: llamadas y mensajes falsos

**Lo que lograrás:** Reconocer las llamadas y mensajes falsos más comunes (familiar detenido, premio, banco) y aplicar la regla de colgar y verificar.

**Para empezar:** A Doña Tere le llamó un «licenciado»: su nieto chocó y necesita 8,000 en ese momento para no ir a la cárcel. Se oía un joven llorando. Casi los deposita. En esta lección verás cómo reconocer el engaño.

### Lo esencial (5 minutos)

#### Todas usan prisa y miedo

Las llamadas falsas quieren que actúes **rápido y con miedo**, sin pensar ni preguntar a nadie. Cambian la historia (un familiar detenido, un premio, tu banco), pero la trampa es la misma.



#### Señales de engaño

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Tiene que ser ahora» | Prisa para que no verifiques. | Cuelga. |
| «No le digas a nadie» | Te aíslan. | Pide ayuda. |
| Piden depósito o códigos | Ninguna autoridad lo pide así. | Nunca. |
| Cuelgas y llamas tú | Al número que ya tienes. | La regla de oro. |

#### La regla de oro

1. Cuelga, aunque suene real.
2. Llama tú al familiar o al banco, al número que ya tienes.
3. Pregunta a alguien de confianza antes de depositar.
4. Nunca des códigos que te llegan por mensaje.



#### Un caso en un minuto

Doña Tere colgó y le llamó a su nieto. Estaba en la escuela. Reportó el número al 088.

> **Idea clave:** si te piden dinero con prisa y miedo, cuelga y llama tú a la persona o al banco, al número que ya tienes.



#### Comprueba lo que entendiste

1. ¿Qué quieren las llamadas falsas?
*Respuesta:* Que actúes rápido y con miedo.

2. ¿Qué haces primero?
*Respuesta:* Colgar y llamar tú al número que ya tienes.


#### Para recordar

- Prisa y miedo: engaño.
- Cuelga y verifica.
- Nunca des códigos.



### Profundiza (5 minutos más)

#### Engaños comunes

| Engaño | Qué dicen | Qué haces |
|---|---|---|
| Familiar en problemas | «Chocó, está detenido» | Llama al familiar |
| Premio | «Ganó, pague el envío» | No pagas nada |
| Banco | «Bloqueamos su cuenta, dé el código» | Llama al banco |
| Paquete | «Pague para liberar su envío» | No das datos |



#### Palabra clave familiar

Acuerden en familia una palabra secreta. Si alguien llama diciendo que es tu nieto y no sabe la palabra, es falso.



#### Casos


**Caso 1. El nieto de Doña Tere**

Le llaman a Doña Tere: su nieto está detenido y necesita 8,000.
- *¿Qué hace?* Cuelga, le llama a su nieto y reporta el número.


**Caso 2. El premio de Chayo**

A Chayo le llega un mensaje: ganó una pantalla y debe pagar 500 de envío.
- *¿Qué hace?* No paga: nadie cobra por darte un premio.


**Caso 3. El código de Mari**

«Su banco» le pide a Mari el código que le llegó por mensaje.
- *¿Qué hace?* Cuelga y llama al número de su tarjeta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Actuar con prisa | Pierdes dinero | Cuelga |
| Guardar el secreto | Nadie te frena | Pregunta a alguien |
| Dar códigos | Vacían tu cuenta | Nunca |
| No reportar | Siguen engañando | 088 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es lo primero que haces ante una llamada que pide dinero urgente? a) Depositas rápido para ayudar a tu familiar · b) Pides más datos · c) Cuelgas y verificas
2. ¿Tu banco te pide códigos por teléfono? a) No, nunca · b) Solo si es urgente · c) Sí, para cancelar cargos
3. ¿Para qué sirve una palabra clave familiar? a) Para abrir la cuenta · b) Para saber si de verdad es tu familiar · c) Para cobrar premios y promociones que te lleguen por teléfono
**Respuestas:** 1-c: la regla de oro. 2-a: nunca los pide. 3-b: los engañadores no la saben.



#### Ponlo en práctica

Escribe qué dirías para colgar una llamada sospechosa sin discutir.
**Respuesta:** Por ejemplo: «Voy a llamar yo directamente». Y cuelgas.



#### A tu plan

Acuerda una palabra clave con tu familia esta semana.



### Para saber más

- **Fraudes telefónicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes» y «llamadas falsas».

### Palabras clave

- *Fraude telefónico:* engaño por llamada o mensaje para quitarte dinero o datos.

### Fuentes

CONDUSEF · Guardia Nacional (088), consultados el 30 de septiembre de 2026.

---

## M7 U02. Falsos apoyos, falsos trabajos y cobros por trámites

**Lo que lograrás:** Reconocer a quien cobra por inscribirte a pensiones, becas o programas, y las ofertas de trabajo falsas que piden depósito.

**Para empezar:** Una señora le ofreció a Chayo «apurar» el registro de la beca de su hija por 300 pesos. A Mari le llegó una oferta de trabajo de planta en Canadá: solo tenía que depositar 4,500 para la visa. En esta lección verás estos engaños.

### Lo esencial (5 minutos)

#### Los programas no cobran

Los registros para pensiones del Bienestar y becas no tienen costo. Nadie puede «apurar» tu registro ni garantizarte un apoyo a cambio de dinero.



#### Señales de engaño

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobran por inscribirte | Los registros no tienen costo. | Engaño. |
| Trabajo en otro país con depósito | Para «visa» o «papeles». | Engaño. |
| Solo por WhatsApp | Sin oficina ni contrato. | Desconfía. |
| Sitios oficiales | Terminan en gob.mx. | Verifica ahí. |

#### Ofertas de trabajo

Una casa o agencia seria no te pide depósito para contratarte. Desconfía de sueldos muy altos, de trabajo en otro país sin papeles claros y de quien pide tu INE y tus datos antes de conocerte.



#### Un caso en un minuto

Chayo registró a su hija en el sitio oficial sin pagar a nadie. Mari no depositó y preguntó en la oficina del Servicio Nacional de Empleo: la oferta era falsa.

> **Idea clave:** los registros a programas no tienen costo y nadie serio te pide depósito para darte trabajo; verifica en sitios que terminan en gob.mx.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta registrarte a una beca o pensión del Bienestar?
*Respuesta:* No tiene costo.

2. ¿Qué haces si una oferta de trabajo pide depósito?
*Respuesta:* No depositas: es señal de engaño.


#### Para recordar

- Los registros no se cobran.
- Trabajo serio no pide depósito.
- Verifica en gob.mx.



### Profundiza (5 minutos más)

#### Dónde verificar

| Si te ofrecen | Verifica en |
|---|---|
| Pensión o beca | Programas para el Bienestar (gob.mx) |
| Trabajo en otro país | Servicio Nacional de Empleo |
| Préstamo | SIPRES de la CONDUSEF |
| Trámite del IMSS | imss.gob.mx |



#### Si ya pagaste

Guarda el comprobante y los mensajes, denuncia en el 088 o en la fiscalía y, si fue por transferencia, avisa a tu banco de inmediato.



#### Casos


**Caso 1. La beca de la hija de Chayo**

Le ofrecen a Chayo «apurar» el registro de la beca por 300.
- *¿Qué hace?* Registra a su hija en el sitio oficial sin pagar a nadie.


**Caso 2. La oferta de Canadá**

A Mari le piden 4,500 para la visa de un trabajo en Canadá.
- *¿Qué hace?* No deposita y verifica en el Servicio Nacional de Empleo.


**Caso 3. La pensión de Doña Tere**

Un señor le dice a Doña Tere que por 500 le «asegura» su pensión.
- *¿Qué hace?* No paga: la pensión se tramita sin costo en el sitio oficial.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por un registro | Pierdes dinero | Los registros no se cobran |
| Depositar por un trabajo | Engaño | Nunca |
| Dar tu INE a desconocidos | Robo de identidad | No |
| Creer en sitios parecidos | Fraude | Solo gob.mx |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta registrarte a una pensión del Bienestar? a) 500 · b) No tiene costo · c) Lo que pida el gestor
2. Te ofrecen trabajo en otro país si depositas 4,000. ¿Qué es? a) Una señal de engaño · b) Un trámite normal · c) Una buena oportunidad
3. ¿En qué terminan los sitios oficiales del gobierno? a) .com · b) .net · c) gob.mx
**Respuestas:** 1-b: los registros no se cobran. 2-a: nadie serio pide depósito. 3-c: así los reconoces.



#### Ponlo en práctica

Te piden 350 por registrar a tres nietos en una beca. ¿Cuánto perderías y cuánto cuesta el registro oficial?
**Respuesta:** Perderías 1,050. El registro oficial no tiene costo.



#### A tu plan

Guarda en tu celular los sitios oficiales de Programas para el Bienestar y del Servicio Nacional de Empleo.



### Para saber más

- **Programas para el Bienestar** (Gobierno de México · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** registro de pensiones y becas.
- **Servicio Nacional de Empleo** (STPS · español): https://www.empleo.gob.mx — **Qué buscar:** ofertas de trabajo verificadas.

### Palabras clave

- *Gestor:* persona que cobra por hacer trámites que puedes hacer tú sin costo.

### Fuentes

Programas para el Bienestar · Servicio Nacional de Empleo · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M7 U03. Tu celular con candado

**Lo que lograrás:** Proteger tu celular y tu banca en línea con NIP, verificación en dos pasos y alertas, y saber qué hacer si lo pierdes.

**Para empezar:** Chayo presta su celular a su nieta para jugar. No tiene contraseña y tiene abierta la app del banco. Un día apareció una compra que ella no hizo. En esta lección pondrás candados.

### Lo esencial (5 minutos)

#### Los candados básicos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bloqueo de pantalla | NIP o huella. | Siempre. |
| Verificación en dos pasos | En WhatsApp y en tu correo. | Evita que te roben la cuenta. |
| Alertas del banco | Un aviso por cada movimiento. | Te enteras al momento. |
| Contraseñas guardadas en notas | Cualquiera las ve. | Nunca. |

#### Tu app del banco

Pon un límite a tus transferencias, activa alertas y cierra la sesión. Si prestas el celular, que sea sin la app abierta.



#### Si pierdes el celular o te lo roban

1. Llama a tu banco y bloquea tu tarjeta y tu app.
2. Pide a tu compañía que suspenda tu línea.
3. Cambia tus contraseñas desde otro dispositivo.
4. Avisa a tus contactos que no respondan pedidos de dinero.



#### Un caso en un minuto

Chayo puso NIP a su celular, activó alertas y la verificación en dos pasos de WhatsApp. Reclamó la compra en su banco con folio. Ahora su nieta juega sin acceso a la app.

> **Idea clave:** NIP en tu celular, verificación en dos pasos y alertas del banco; si lo pierdes, bloquea todo el mismo día.



#### Comprueba lo que entendiste

1. ¿Para qué sirve la verificación en dos pasos?
*Respuesta:* Para que no te roben tu cuenta de WhatsApp.

2. ¿Qué haces primero si te roban el celular?
*Respuesta:* Llamas al banco para bloquear tarjeta y app.


#### Para recordar

- NIP y dos pasos.
- Alertas del banco.
- Si lo pierdes, bloquea.



### Profundiza (5 minutos más)

#### Revisa tu celular

| Candado | ¿Lo tienes? |
|---|---|
| Bloqueo de pantalla | |
| Verificación en dos pasos en WhatsApp | |
| Alertas del banco | |
| Límite de transferencias | |
| Número del banco guardado | |



#### Redes públicas

No entres a tu banco con el internet abierto de un lugar público: usa tus datos. En redes abiertas otras personas pueden ver lo que haces.



#### Casos


**Caso 1. La nieta de Chayo**

Chayo presta su celular sin contraseña y con el banco abierto.
- *¿Qué hace?* Pone NIP, cierra la app y activa alertas.


**Caso 2. El WhatsApp de Doña Tere**

Le piden a Doña Tere «el código de seis números» que le llegó por WhatsApp.
- *¿Qué hace?* No lo da y activa la verificación en dos pasos.


**Caso 3. El robo de Mari**

A Mari le roban el celular en el camión.
- *¿Qué hace?* Llama a su banco para bloquear y suspende su línea.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Celular sin bloqueo | Cualquiera entra | NIP |
| Dar el código de WhatsApp | Te roban la cuenta | Nunca |
| Sin alertas | Te enteras tarde | Actívalas |
| Esperar para bloquear | Más cargos | El mismo día |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué candado evita que te roben tu WhatsApp? a) Verificación en dos pasos · b) Fondo de pantalla · c) Más memoria y una funda más resistente
2. Te roban el celular. ¿Qué haces primero? a) Compras otro · b) Esperas a que alguien lo encuentre y te lo regrese · c) Llamas al banco y bloqueas
3. ¿Para qué sirven las alertas del banco? a) Para ganar puntos y premios en cada compra del mes · b) Para enterarte de cada movimiento · c) Para pagar menos comisiones
**Respuestas:** 1-a: pide un NIP extra. 2-c: evitas cargos. 3-b: te enteras al momento.



#### Ponlo en práctica

Pones un límite de 2,000 al día en transferencias. Si alguien entra a tu app, ¿cuánto es lo máximo que podría sacar en un día?
**Respuesta:** 2,000.



#### A tu plan

Hoy pon NIP a tu celular y activa la verificación en dos pasos en WhatsApp.



### Para saber más

- **Seguridad en tu celular** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «banca móvil segura».

### Palabras clave

- *Verificación en dos pasos:* un NIP extra que pide la app para que nadie más use tu cuenta.
- *Alerta:* aviso que te manda el banco por cada movimiento.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M7 U04. Tus datos, tu identidad y los registros para que no te molesten

**Lo que lograrás:** Proteger tus documentos y datos personales, saber qué hacer si usan tu identidad y registrarte para que no te llamen con publicidad.

**Para empezar:** A Mari le llegan llamadas de bancos y tiendas todo el día. Y a Doña Tere le cobran un celular que nunca compró: alguien usó una copia de su INE que dejó en una tienda. En esta lección cuidarás tus datos.

### Lo esencial (5 minutos)

#### Tu INE vale dinero

Con una copia de tu INE, tu CURP y tu comprobante de domicilio alguien puede sacar créditos a tu nombre. Entrégalos solo cuando es necesario y escribe en la copia para qué es y la fecha.



#### Cuida tus datos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Copia con leyenda | «Solo para trámite X, fecha». | Así no la reúsan. |
| Rompe papeles | Recibos y estados de cuenta. | Antes de tirarlos. |
| Fotos de tu INE por WhatsApp | A desconocidos, nunca. | Robo de identidad. |
| Registros para no recibir llamadas | REPEP y REUS. | Sin costo. |

#### Que no te llamen

Registra tu número en el REPEP de la PROFECO para que no te llamen empresas con publicidad, y en el REUS de la CONDUSEF para que no te llamen bancos y financieras. Los dos no tienen costo.



#### Un caso en un minuto

Doña Tere revisó su reporte de crédito, reclamó el celular que no compró y denunció el robo de identidad. Mari registró su número en el REPEP y el REUS y dejaron de llamarle.

> **Idea clave:** entrega copias de tu INE con leyenda, rompe tus papeles y registra tu número en el REPEP y el REUS; si usan tu identidad, reclama y denuncia.



#### Comprueba lo que entendiste

1. ¿Qué escribes en la copia de tu INE?
*Respuesta:* Para qué trámite es y la fecha.

2. ¿Para qué sirve el REUS?
*Respuesta:* Para que no te llamen bancos y financieras con publicidad.


#### Para recordar

- Copia con leyenda.
- Rompe tus papeles.
- REPEP y REUS sin costo.



### Profundiza (5 minutos más)

#### Si usan tu identidad

1. Revisa tu reporte de crédito (M5 U05).
2. Reclama a la institución y al buró lo que no reconoces.
3. Denuncia en la fiscalía y guarda el número de denuncia.
4. Presenta queja en la CONDUSEF si no te resuelven.



#### Datos de las casas donde trabajas

Tampoco compartas datos, fotos o direcciones de las familias con quienes trabajas. Cuidar sus datos también te protege a ti.



#### Casos


**Caso 1. La copia de Doña Tere**

Le cobran a Doña Tere un celular que nunca compró.
- *¿Qué hace?* Revisa su reporte, reclama y denuncia el robo de identidad.


**Caso 2. Las llamadas de Mari**

A Mari la llaman todo el día bancos y tiendas.
- *¿Qué hace?* Registra su número en el REUS y el REPEP.


**Caso 3. La foto de la INE de Chayo**

Un «reclutador» le pide a Chayo foto de su INE por WhatsApp antes de conocerla.
- *¿Qué hace?* No la manda; la entrega solo en persona y con leyenda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Copias sin leyenda | Las reúsan | Escribe para qué |
| Tirar papeles enteros | Roban tus datos | Rómpelos |
| Mandar fotos de tu INE | Robo de identidad | No |
| No denunciar | Te siguen cobrando | Fiscalía y CONDUSEF |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Mari y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué registro evita llamadas de bancos con publicidad? a) El REUS · b) El RFC · c) El SIPRES
2. ¿Qué escribes en la copia de tu INE? a) Tu firma y tu número de celular completo · b) Tu número de cuenta · c) Para qué trámite es y la fecha
3. ¿Cuánto cuesta registrarte en el REPEP? a) 200 al año · b) No tiene costo · c) Lo que cobre el gestor
**Respuestas:** 1-a: de la CONDUSEF. 2-c: así no la reúsan. 3-b: es sin costo.



#### Ponlo en práctica

Te cobran 3,600 de un celular que no compraste, en 12 pagos. Si no reclamas, ¿cuánto pagarías cada mes?
**Respuesta:** 3,600 entre 12: 300 al mes por algo que no compraste.



#### A tu plan

Registra tu número en el REPEP y en el REUS esta semana.



### Para saber más

- **REPEP** (PROFECO · español): https://repep.profeco.gob.mx — **Qué buscar:** registro de tu número.
- **REUS** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REUS».

### Palabras clave

- *REPEP:* registro de la PROFECO para que no te llamen empresas con publicidad.
- *REUS:* registro de la CONDUSEF para que no te llamen bancos y financieras con publicidad.
- *Robo de identidad:* cuando alguien usa tus datos para sacar créditos o hacer trámites a tu nombre.

### Fuentes

PROFECO · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 8. Módulo 8. Tu vejez y tus nietas

## M8 U01. Tus pensiones del Bienestar

**Lo que lograrás:** Conocer la Pensión Mujeres Bienestar (60 a 64 años) y la Pensión para Adultos Mayores (65 o más), cuánto dan en 2026 y por qué conviene ahorrar además.

**Para empezar:** Doña Tere tiene 58 años. Piensa que «cuando llegue la pensión» ya no tendrá que trabajar. No sabe cuánto es ni cuándo le toca. En esta lección sacarás cuentas.

### Lo esencial (5 minutos)

#### Las dos pensiones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mujeres Bienestar | De 60 a 64 años. | 3,100 cada dos meses. |
| Adultos Mayores | De 65 años en adelante. | 6,400 cada dos meses. |
| Nadie cobra por inscribirte | El registro no tiene costo. | Cuidado con gestores. |

> **Dato vigente:** en 2026 la Pensión Mujeres Bienestar da 3,100 pesos bimestrales a mujeres de 60 a 64 años, y la Pensión para el Bienestar de las Personas Adultas Mayores, 6,400 pesos bimestrales a partir de los 65 años; se depositan en la tarjeta del Banco del Bienestar. Consultado el 30 de septiembre de 2026 a través de Programas para el Bienestar.

#### ¿Alcanza la pensión?

- Pensión de Adultos Mayores, cada dos meses: **6,400**
- Meses: **2**
- Al mes: **3,200**
Doña Tere gasta unos 8,000 al mes. La pensión ayuda, pero no alcanza sola.


#### Un caso en un minuto

Doña Tere anotó en su calendario el mes en que cumple 60 para registrarse. Mientras, ahorra en su Afore cada semana (M8 U02) para completar lo que la pensión no cubre.

> **Idea clave:** las pensiones del Bienestar ayudan, pero no alcanzan solas; regístrate a tiempo sin pagar a nadie y ahorra además para tu vejez.



#### Comprueba lo que entendiste

1. ¿A qué edad puedes recibir la Pensión Mujeres Bienestar?
*Respuesta:* De los 60 a los 64 años.

2. ¿Cuánto da al mes la Pensión de Adultos Mayores en 2026?
*Respuesta:* Unos 3,200 (6,400 cada dos meses).


#### Para recordar

- 60 a 64: Mujeres Bienestar.
- 65 o más: Adultos Mayores.
- Ayuda, pero ahorra además.



### Profundiza (5 minutos más)

#### Tu línea del tiempo

| Edad | Qué pasa |
|---|---|
| Hoy | Ahorra en tu Afore y tu fondo |
| 60 | Regístrate en Mujeres Bienestar |
| 65 | Pasas a Adultos Mayores |



#### Qué llevar al registro

Tu INE, CURP, acta de nacimiento y comprobante de domicilio. Revisa las fechas de registro en el sitio oficial; se anuncian por letra del apellido.



#### Casos


**Caso 1. El plan de Doña Tere**

Doña Tere cree que la pensión le alcanzará para todo.
- *¿Qué hace?* Saca cuentas y ahorra además para completar.


**Caso 2. La mamá de Chayo**

La mamá de Chayo tiene 63 años y no se ha registrado.
- *¿Qué hace?* La registra en Mujeres Bienestar con sus documentos, sin pagar a nadie.


**Caso 3. El gestor de Mari**

A Mari le ofrecen «adelantar» la pensión de su mamá por 800.
- *¿Qué hace?* No paga: el registro no tiene costo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que alcanza sola | Te falta dinero | Ahorra además |
| Registrarte tarde | Pierdes meses | Anota tu fecha |
| Pagar a gestores | Pierdes dinero | Sin costo |
| Dejar la tarjeta a otra persona | Te la usan | Cuídala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto da al año la Pensión Mujeres Bienestar en 2026? a) 18,600 · b) 3,100 · c) 38,400
2. ¿A partir de qué edad es la Pensión de Adultos Mayores? a) 60 · b) 55 · c) 65
3. ¿Cuánto cuesta registrarte? a) No tiene costo · b) 800 con gestor · c) Un mes de pensión
**Respuestas:** 1-a: 3,100 por 6 bimestres. 2-c: de 65 en adelante. 3-a: el registro es sin costo.



#### Ponlo en práctica

Gastas 7,000 al mes y a los 65 recibes 3,200 al mes de pensión. ¿Cuánto te falta cada mes?
**Respuesta:** 7,000 menos 3,200: 3,800 al mes.



#### A tu plan

Anota en tu calendario el mes en que cumples 60 y 65, y cuánto te faltaría al mes.



### Para saber más

- **Pensión Mujeres Bienestar** (Programas para el Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** requisitos y fechas de registro.

### Palabras clave

- *Pensión Mujeres Bienestar:* apoyo bimestral para mujeres de 60 a 64 años.
- *Pensión para Adultos Mayores:* apoyo bimestral para personas de 65 años o más.

### Fuentes

Programas para el Bienestar, consultado el 30 de septiembre de 2026.

---

## M8 U02. Tu Afore: encuéntrala y ahórrale desde 50 pesos

**Lo que lograrás:** Saber si tienes Afore, registrarla y ahorrar en ella desde 50 pesos en tiendas, aunque trabajes por día.

**Para empezar:** Mari trabajó dos años en una fábrica antes de dedicarse al hogar. No sabe si tiene Afore ni cuánto hay. Chayo nunca ha tenido una. En esta lección verás cómo empezar.

### Lo esencial (5 minutos)

#### ¿Tienes Afore?

Si alguna vez trabajaste con IMSS, tienes una Afore con tu dinero. Puedes buscarla con tu CURP en la app AforeMóvil o en el sitio de la CONSAR. Si nunca has tenido, puedes abrir una desde la app.



#### Ahórrale aunque cobres por día

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En tiendas | Desde 50 pesos con tu CURP. | 7-Eleven, Bodega Aurrera, Telecomm y más. |
| En AforeMóvil | Desde tu celular. | Consultas tu saldo. |
| Beneficiarios | Nombra a quién recibe si faltas. | Actualízalos. |
| Gestores | Nadie cobra por darte tu Afore. | Sin costo. |

> **Dato vigente:** las aportaciones voluntarias a la Afore se pueden hacer desde 50 pesos con tu CURP en tiendas como 7-Eleven, Círculo K, Bodega Aurrera y Walmart, en Telecomm, en el Banco del Bienestar y en la app AforeMóvil. Consultado el 30 de septiembre de 2026 a través de la CONSAR.

#### El ahorro de Chayo

- Cada semana: **50**
- Semanas: **52**
- Al año, más rendimientos: **2,600**
En 20 años son más de 52,000 sin contar lo que gana.


#### Un caso en un minuto

Mari encontró su Afore con su CURP: tenía 11,000 pesos que no sabía. Chayo abrió la suya en AforeMóvil y deposita 50 cada lunes en la tienda de la esquina.

> **Idea clave:** busca tu Afore con tu CURP; aunque cobres por día puedes ahorrar en ella desde 50 pesos en tiendas y nombrar a tus beneficiarias.



#### Comprueba lo que entendiste

1. ¿Con qué buscas tu Afore?
*Respuesta:* Con tu CURP en AforeMóvil o en el sitio de la CONSAR.

2. ¿Desde cuánto puedes ahorrar en tu Afore?
*Respuesta:* Desde 50 pesos.


#### Para recordar

- Búscala con tu CURP.
- Desde 50 pesos en tiendas.
- Nombra beneficiarias.



### Profundiza (5 minutos más)

#### Si ahorras cada semana

| Por semana | En 10 años | En 20 años |
|---|---|---|
| 50 | 26,000 | 52,000 |
| 100 | 52,000 | 104,000 |
| 200 | 104,000 | 208,000 |



#### Por qué en la Afore

Tu ahorro en la Afore se invierte y gana rendimientos con los años. Las aportaciones voluntarias de corto plazo se pueden retirar según las reglas de tu Afore; las de largo plazo son para tu retiro.



#### Casos


**Caso 1. La Afore olvidada de Mari**

Mari no sabe si tiene Afore de cuando trabajó en la fábrica.
- *¿Qué hace?* La busca con su CURP en AforeMóvil.


**Caso 2. El ahorro de Chayo**

Chayo nunca ha tenido Afore y cobra por día.
- *¿Qué hace?* Abre su Afore en la app y deposita cada semana en la tienda.


**Caso 3. Los beneficiarios de Doña Tere**

Doña Tere tiene Afore pero nunca nombró beneficiarias.
- *¿Qué hace?* Las registra en su Afore con nombres completos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que sin patrón no hay Afore | No ahorras | Ábrela tú |
| Olvidar la Afore vieja | Dinero perdido | Búscala |
| Pagar a gestores | Pierdes | Sin costo |
| No nombrar beneficiarias | Trámite largo | Regístralas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Chayo y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Desde cuánto puedes ahorrar en tu Afore en una tienda? a) 1,000 · b) 50 · c) 500
2. ¿Qué necesitas para depositar en la tienda? a) Tu CURP · b) Tu contrato de trabajo · c) Tu recibo de luz
3. Ahorras 100 cada semana. ¿Cuánto juntas en un año, sin rendimientos? a) 1,200 · b) 100 · c) 5,200
**Respuestas:** 1-b: desde 50 pesos. 2-a: con ella te identifican. 3-c: 100 por 52.



#### Ponlo en práctica

Ahorras 80 a la semana en tu Afore durante 15 años. ¿Cuánto pones, sin contar rendimientos?
**Respuesta:** 80 por 52 por 15: 62,400.



#### A tu plan

Busca tu Afore con tu CURP o ábrela en AforeMóvil, y decide cuánto vas a depositar cada semana.



### Para saber más

- **AforeMóvil y ahorro voluntario** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «ahorro voluntario» y «AforeMóvil».

### Palabras clave

- *Afore:* administradora que guarda tu ahorro para el retiro.
- *Aportación voluntaria:* dinero que tú depositas en tu Afore además de lo que pone un patrón.

### Fuentes

CONSAR, consultado el 30 de septiembre de 2026.

---

## M8 U03. Las becas de tus hijas y nietas, sin coyotes

**Lo que lograrás:** Conocer las becas universales para estudiantes de escuelas públicas, cómo registrarlas sin pagar a nadie y cómo usar el dinero para la escuela.

**Para empezar:** Doña Tere se hace cargo de la escuela de su nieta Yaretzi, que entra a la prepa. Una vecina le dice que la beca «solo sale si conoces a alguien». En esta lección verás cómo funciona.

### Lo esencial (5 minutos)

#### Becas universales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Beca Benito Juárez | Preparatoria pública. | 1,900 cada dos meses. |
| Beca Rita Cetina | Educación básica pública. | Revisa montos por nivel. |
| Coyotes | Nadie cobra por registrar. | Registro oficial. |

> **Dato vigente:** en 2026 la Beca Benito Juárez da 1,900 pesos bimestrales a estudiantes de preparatoria pública, en cinco depósitos al año, en su tarjeta del Banco del Bienestar; la Beca Rita Cetina es para educación básica pública y sus montos cambian por nivel. Consultado el 30 de septiembre de 2026 a través de Programas para el Bienestar.

#### La beca de Yaretzi

- Cada dos meses: **1,900**
- Depósitos al año: **5**
- Al año para la escuela: **9,500**
Alcanza para útiles, pasajes y uniforme si se aparta para eso.


#### Un caso en un minuto

Yaretzi se registró en el sitio oficial con su CURP y la ayuda de la escuela. Con su abuela acordó que la beca se usa primero para pasajes y útiles, y lo que sobre se ahorra.

> **Idea clave:** las becas universales no necesitan coyotes; regístralas en el sitio oficial y acuerden en familia para qué se usa el dinero.



#### Comprueba lo que entendiste

1. ¿Cuánto da la Beca Benito Juárez al año?
*Respuesta:* 9,500 (1,900 en cinco depósitos).

2. ¿Quién puede cobrarte por registrar?
*Respuesta:* Nadie: el registro no tiene costo.


#### Para recordar

- Becas universales en escuela pública.
- Registro sin costo.
- Primero para la escuela.



### Profundiza (5 minutos más)

#### El dinero de la beca

| Para qué | Cuánto |
|---|---|
| Pasajes | |
| Útiles y uniforme | |
| Ahorro para el siguiente ciclo | |



#### La tarjeta es de la estudiante

La beca se deposita en una tarjeta a nombre de la estudiante o de su mamá, papá o tutora. Cuídenla como cualquier cuenta: NIP secreto y sin prestarla.



#### Casos


**Caso 1. La vecina de Doña Tere**

Una vecina dice que la beca «solo sale si conoces a alguien».
- *¿Qué hace?* Registra a su nieta en el sitio oficial sin pagar a nadie.


**Caso 2. La beca que se va**

La beca del hijo de Mari se gasta en lo que sea.
- *¿Qué hace?* Acuerdan que primero va a la escuela y lo que sobre se ahorra.


**Caso 3. La tarjeta de la nieta de Chayo**

Un familiar le pide la tarjeta de la beca a la nieta de Chayo.
- *¿Qué hace?* No la presta y cuida su NIP.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar a coyotes | Pierdes dinero | Registro oficial |
| Gastar la beca en todo | No alcanza para la escuela | Primero la escuela |
| Prestar la tarjeta | Te la vacían | Cuídala |
| No revisar fechas | Te quedas sin registro | Revisa el sitio |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Mari y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Para quién es la Beca Benito Juárez? a) Estudiantes de preparatoria pública · b) Solo quien tenga promedio de 10 en la secundaria · c) Estudiantes de escuela privada
2. ¿Cuántos depósitos al año da la Beca Benito Juárez? a) 12 · b) 5 · c) 1
3. ¿Qué haces si alguien te cobra por registrar una beca? a) Pagas para asegurarla antes de que se acaben los lugares · b) Pagas la mitad · c) No pagas y registras en el sitio oficial
**Respuestas:** 1-a: es universal en prepa pública. 2-b: no se paga en verano. 3-c: es sin costo.



#### Ponlo en práctica

Tu nieta recibe 1,900 cada dos meses y gasta 600 de pasajes al mes. ¿Cuánto le queda de cada depósito para útiles y ahorro?
**Respuesta:** Dos meses de pasajes: 1,200. Le quedan 700 de cada depósito.



#### A tu plan

Revisa si tus hijas o nietas ya están registradas y acuerden para qué se usa la beca.



### Para saber más

- **Becas para el Bienestar** (Gobierno de México · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «Beca Benito Juárez» y «Beca Rita Cetina».

### Palabras clave

- *Beca universal:* apoyo para todas las personas que estudian en un nivel, sin concurso.
- *Coyote:* persona que cobra por trámites que no tienen costo.

### Fuentes

Programas para el Bienestar, consultado el 30 de septiembre de 2026.

---

## M8 U04. Sin juicio: beneficiarias en todo lo que tienes

**Lo que lograrás:** Nombrar beneficiarias en tus cuentas, Afore, seguros y con las casas donde trabajas, para que tu familia reciba tu dinero sin juicio.

**Para empezar:** Cuando murió la hermana de Chayo, su cuenta del banco, su Afore y la tanda quedaron «atoradas». La familia tardó un año y gastó en abogados. Nadie estaba nombrado como beneficiaria. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Qué es una beneficiaria

Una beneficiaria recibe tu dinero directamente, **sin juicio**. Es lo más rápido y barato que puedes hacer por tu familia, y se hace en un rato.



#### Dónde nombrarlas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuentas de banco | Incluida la del Banco del Bienestar. | Pídelo en tu banco. |
| Afore | En AforeMóvil o en tu Afore. | Actualízalas. |
| Seguros | De vida y funerarios. | En la póliza. |
| Con quien te contrata | En tu contrato: quién recibe tus pagos pendientes. | La ley lo permite. |

#### En la Afore hay un orden

En la Afore, la ley da primero el dinero a tus beneficiarios legales: pareja, hijas e hijos y, a falta de ellos, madre y padre. Las personas que tú nombras reciben si no hay beneficiarios legales. Por eso, además, conviene tu testamento (M8 U05).



#### Un caso en un minuto

Chayo nombró a sus dos hijas en su cuenta, su Afore y su seguro, con nombre completo y la parte de cada una. Pidió a la casa donde trabaja de planta que su contrato diga quién recibe sus pagos pendientes.

> **Idea clave:** nombra beneficiarias en tu cuenta, tu Afore, tus seguros y tu contrato; así tu familia recibe tu dinero sin juicio.



#### Comprueba lo que entendiste

1. ¿Qué ventaja tiene nombrar beneficiarias?
*Respuesta:* Tu familia recibe el dinero sin juicio.

2. ¿Dónde puedes nombrarlas?
*Respuesta:* En cuentas, Afore, seguros y tu contrato de trabajo.


#### Para recordar

- Beneficiarias en todo.
- Nombre completo y porcentaje.
- Revísalas cada año.



### Profundiza (5 minutos más)

#### Tu lista de beneficiarias

| Dónde | ¿Tiene beneficiarias? | Quiénes y qué parte |
|---|---|---|
| Cuenta de banco | | |
| Afore | | |
| Seguro de vida o funerario | | |
| Contrato de trabajo | | |



#### Tu carpeta

Guarda en un solo lugar: INE, CURP, actas, escrituras o papeles de la casa, contratos, pólizas, datos de tus cuentas y de tu Afore, y tu lista de beneficiarias. Dile a una persona de confianza dónde está.



#### Casos


**Caso 1. La cuenta de la hermana de Chayo**

La cuenta de la hermana de Chayo quedó atorada por no tener beneficiaria.
- *¿Qué hace Chayo con la suya?* Nombra a sus hijas en su cuenta, Afore y seguro.


**Caso 2. La nieta de Doña Tere**

Doña Tere quiere dejar su cuenta a su nieta de 9 años.
- *¿Qué hace?* Pregunta cómo se le entregaría y prevé un tutor en su testamento.


**Caso 3. El contrato de Mari**

Mari tiene contrato de planta.
- *¿Qué hace?* Pide que el contrato diga quién recibe sus pagos pendientes si falta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No nombrar a nadie | Juicio largo | Nombra beneficiarias |
| Poner solo apodos | No las encuentran | Nombre completo |
| No actualizar | El dinero va a quien ya no quieres | Revisa cada año |
| Carpeta regada | Nadie encuentra nada | Un solo lugar |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Doña Tere y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si nombras beneficiarias en tu cuenta? a) Pagan más impuestos cuando reciben el dinero · b) Reciben el dinero sin juicio · c) No cambia nada
2. ¿Qué datos pones de cada beneficiaria? a) Solo el apodo con el que la conoce la familia · b) Solo el parentesco · c) Nombre completo y porcentaje
3. ¿Dónde más puedes nombrar beneficiarias? a) En tu Afore y tus seguros · b) En tu recibo de luz · c) En tu tarjeta de la tienda
**Respuestas:** 1-b: es lo más rápido. 2-c: así no hay dudas. 3-a: y en tu contrato.



#### Ponlo en práctica

Tienes 30,000 en tu Afore y nombras a dos hijas: 60% y 40%. ¿Cuánto recibiría cada una?
**Respuesta:** 60%: 18,000. 40%: 12,000.



#### A tu plan

Llena tu lista de beneficiarias y corrige esta semana las que falten.



### Para saber más

- **Beneficiarios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «beneficiarios en cuentas».
- **Beneficiarios en la Afore** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «designar beneficiarios».

### Palabras clave

- *Beneficiaria:* persona que nombras para recibir el dinero de una cuenta, Afore o seguro si faltas.
- *Beneficiarios legales:* personas que la ley pone primero para recibir tu Afore: pareja, hijas e hijos, y madre y padre.

### Fuentes

CONDUSEF · CONSAR · Ley Federal del Trabajo (artículo 25, designación de beneficiarios), consultados el 30 de septiembre de 2026.

---

## M8 U05. Tu casa, tu tierra y tu testamento

**Lo que lograrás:** Poner en orden los papeles de tu casa o terreno, conocer la lista de sucesión si tienes tierra ejidal, hacer tu testamento y saber qué pasa si no lo haces.

**Para empezar:** Doña Tere vive desde hace 30 años en una casa que era de su suegra. Nunca se escrituró. En su pueblo tiene una parcela ejidal que era de su papá. Si ella falta, no sabe qué pasaría con ninguna. En esta lección verás qué hacer.

### Lo esencial (5 minutos)

#### Cada bien, su camino

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Casa con escrituras | Se hereda con testamento. | Revisa a nombre de quién está. |
| Casa sin escrituras | En papel no hay nada que heredar. | Primero regulariza. |
| Tierra ejidal | Se hereda con la lista de sucesión. | En el Registro Agrario Nacional. |
| Testamento | Tu decisión por escrito. | Ante notario. |

#### Si tienes tierra ejidal

Los derechos de un ejidatario se heredan con la lista de sucesión que se deposita en el Registro Agrario Nacional o ante notario. Si no hay lista, la ley decide el orden y puede haber pleitos.



#### Tu testamento

Un testamento evita juicios largos y peleas. En septiembre, Mes del Testamento, muchas notarías dan descuentos. Ahí también puedes nombrar a quien cuidaría a tus nietas si faltas.

> **Dato vigente:** en el Mes del Testamento 2026 hubo descuentos de hasta 50%, con testamentos desde unos 2,750 pesos según el estado. Consultado el 30 de septiembre de 2026 a través de la Secretaría de Gobernación y medios nacionales.



#### Un caso en un minuto

Doña Tere pidió orientación para regularizar la casa y fue al Registro Agrario Nacional a ver quién aparece en la lista de sucesión de la parcela. En septiembre hizo su testamento y nombró a Rosa como tutora de Ximena.

> **Idea clave:** revisa a nombre de quién están tu casa y tu tierra; regulariza lo que no tenga papeles, registra tu lista de sucesión si es ejidal y haz tu testamento.



#### Comprueba lo que entendiste

1. ¿Cómo se heredan los derechos ejidales?
*Respuesta:* Con la lista de sucesión registrada en el Registro Agrario Nacional.

2. ¿Qué pasa si no hay testamento?
*Respuesta:* Hay un juicio o trámite sucesorio, más largo y caro.


#### Para recordar

- Revisa papeles de casa y tierra.
- Lista de sucesión si es ejidal.
- Testamento en septiembre.



### Profundiza (5 minutos más)

#### Si no hay testamento

| Qué pasa | Por qué importa |
|---|---|
| Juicio o trámite ante notario | Tarda meses o años |
| La ley decide quién hereda | Puede no ser lo que querías |
| Gastos de abogado y notario | Salen de la herencia |
| Peleas en la familia | Pasa mucho |



#### Si vives en unión libre

Tu pareja en unión libre puede heredar si cumple lo que pide la ley de tu estado, como cierto tiempo viviendo juntos o tener hijos en común. Un testamento lo deja claro.



#### Casos


**Caso 1. La casa de la suegra**

Doña Tere vive en una casa que nunca se escrituró.
- *¿Qué hace?* Pide orientación para regularizarla antes de pensar en heredarla.


**Caso 2. La parcela del papá de Chayo**

Chayo no sabe quién heredará la parcela ejidal de su papá.
- *¿Qué hace?* Revisa en el Registro Agrario Nacional si hay lista de sucesión.


**Caso 3. La pareja de Mari**

Mari vive en unión libre hace 12 años y su casa está a su nombre.
- *¿Qué hace?* Hace su testamento para dejar claro quién hereda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Casa sin papeles | No hay qué heredar | Regulariza |
| Parcela sin lista | Pleitos | Registra tu lista |
| Sin testamento | Juicio largo | Hazlo en septiembre |
| Nietas sin tutora nombrada | Incertidumbre | Nómbrala en tu testamento |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Con qué se heredan los derechos de una parcela ejidal? a) Con la lista de sucesión · b) Con un recibo de luz · c) Con una carta escrita a mano por el ejidatario
2. ¿Qué mes tiene descuentos para hacer testamento? a) Enero · b) Diciembre · c) Septiembre
3. ¿Qué haces si tu casa no tiene escrituras? a) Nada, se hereda sola · b) Pides orientación para regularizarla · c) La vendes rápido a un vecino para no tener problemas
**Respuestas:** 1-a: se registra en el RAN. 2-c: Mes del Testamento. 3-b: primero los papeles.



#### Ponlo en práctica

Un testamento cuesta 5,500 y en septiembre tiene 50% de descuento. ¿Cuánto pagas y en cuántas semanas lo juntas si apartas 250 a la semana?
**Respuesta:** Pagas 2,750. Con 250 a la semana lo juntas en 11 semanas.



#### A tu plan

Anota a nombre de quién están tu casa y tu tierra, y aparta para tu testamento de septiembre.



### Para saber más

- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento».
- **Lista de sucesión** (Registro Agrario Nacional · español): https://www.gob.mx/ran — **Qué buscar:** «lista de sucesión».
- **Regularización de vivienda** (INSUS · español): https://www.gob.mx/insus — **Qué buscar:** «regularización».

### Palabras clave

- *Testamento:* documento ante notario en el que dices quién recibe tus bienes y quién cuida a tus hijos o nietos menores.
- *Lista de sucesión:* lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.
- *Regularizar:* poner en orden los papeles de una casa o terreno.

### Fuentes

Secretaría de Gobernación · Registro Agrario Nacional · INSUS · Ley Agraria (artículo 17), consultados el 30 de septiembre de 2026.

---

## M8 U06. Heredar sin sustos: deudas, impuestos y la plática en familia

**Lo que lograrás:** Saber qué pasa con tus deudas cuando faltas, qué impuestos hay (y cuáles no) al heredar, y cómo platicarlo en familia.

**Para empezar:** Cuando murió el papá de Mari, un despacho le dijo que ella tenía que pagar sus deudas. Y su hermano no quiere pasar la casa a su nombre porque «hay que pagar 30% de impuestos». En esta lección verás qué es cierto.

### Lo esencial (5 minutos)

#### Lo que es cierto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Recibir una herencia no paga ISR | Está exenta. | Si pasa de 500,000, se informa al SAT. |
| Pasar la casa a tu nombre sí cuesta | Impuesto estatal, notario y registro. | Varía por estado. |
| Las deudas se pagan con la herencia | No con el dinero de la familia. | Salvo el aval. |
| «Hay que pagar 30%» | Falso para recibir una herencia. | Pregunta. |

#### Las deudas de quien falta

Las deudas se pagan con lo que dejó la persona. Si no alcanza, la familia **no** paga con su propio dinero. La excepción: quien firmó como aval u obligado solidario (M4 U03). Algunos créditos tienen un seguro que paga la deuda si la persona fallece: pregúntalo.

> **Dato vigente:** los ingresos por herencia están exentos de ISR (Ley del ISR, artículo 93, fracción XXII); si el monto pasa de 500,000 pesos, quien presenta declaración anual debe informarlo. Consultado el 30 de septiembre de 2026 a través del SAT y medios nacionales.



#### La plática en familia

Hablar de lo que pasará cuando faltes no es de mala suerte: evita peleas. Di dónde está tu carpeta, quiénes son tus beneficiarias y qué dice tu testamento.



#### Un caso en un minuto

Mari no pagó las deudas de su papá: no había firmado como aval. Su hermano preguntó en una notaría: no pagan ISR por heredar la casa, solo los gastos de escriturar. Juntaron para hacerlo.

> **Idea clave:** heredar no paga ISR y tu familia no paga tus deudas con su dinero, salvo quien firmó como aval; escriturar a tu nombre sí cuesta, y conviene no dejarlo pendiente.



#### Comprueba lo que entendiste

1. ¿Se paga ISR por recibir una herencia?
*Respuesta:* No, está exenta.

2. ¿Quién paga las deudas si la herencia no alcanza?
*Respuesta:* Nadie de la familia, salvo quien firmó como aval u obligado solidario.


#### Para recordar

- Heredar no paga ISR.
- Escriturar sí cuesta.
- La familia no paga las deudas, salvo el aval.



### Profundiza (5 minutos más)

#### Costos al pasar una casa a tu nombre

| Concepto | Quién lo cobra |
|---|---|
| Impuesto por adquirir el inmueble | Estado o municipio (algunos lo reducen entre familia) |
| Honorarios del notario | Notaría |
| Registro | Registro Público de la Propiedad |
| Avalúo | Perito |



#### Si luego vendes lo heredado

Si vendes una casa heredada puede haber ISR sobre la ganancia. Si vives en ella, puede aplicar la exención por casa habitación. Pregunta a la notaría antes de vender.



#### Casos


**Caso 1. El despacho de Mari**

Un despacho le dice a Mari que pague las deudas de su papá.
- *¿Qué hace?* Revisa si firmó como aval; si no, no paga con su dinero.


**Caso 2. El hermano de Mari**

El hermano de Mari cree que heredar la casa paga 30% de ISR.
- *¿Qué hace?* Pregunta en una notaría: no paga ISR, solo los gastos de escriturar.


**Caso 3. La plática de Doña Tere**

Doña Tere nunca ha hablado con su familia de su carpeta y su testamento.
- *¿Qué hace?* Hace una plática en familia y les dice dónde está todo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar deudas ajenas sin haber firmado | Pierdes tu dinero | Revisa qué firmaste |
| Creer que heredar paga 30% | No escrituras | Pregunta |
| Dejar la casa sin escriturar | Problema para tus nietas | Escritura a tiempo |
| No hablarlo | Peleas | Plática en familia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto ISR pagas por recibir una herencia? a) 30% · b) Nada, está exenta · c) 10%
2. La herencia de tu papá no alcanza para sus deudas y tú no firmaste nada. ¿Pagas con tu dinero? a) No · b) Sí, todo · c) Solo la mitad
3. ¿Qué sí cuesta al heredar una casa? a) El ISR de la herencia, que es de 30% del valor de la casa · b) Nada, no cuesta ni un peso · c) Escriturar: impuesto estatal, notario y registro
**Respuestas:** 1-b: artículo 93 de la Ley del ISR. 2-a: solo paga quien firmó como aval. 3-c: son los gastos de pasarla a tu nombre.



#### Ponlo en práctica

Heredas una casa. El impuesto estatal es 2% de 600,000 y el notario cobra 12,000. ¿Cuánto necesitas para escriturarla?
**Respuesta:** 2% de 600,000: 12,000. Más 12,000 del notario: 24,000.



#### A tu plan

Haz una plática en familia de 20 minutos: dónde está tu carpeta, quiénes son tus beneficiarias y si ya tienes testamento.



### Para saber más

- **Herencias e impuestos** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «herencias» y «ingresos exentos».
- **Despachos de cobranza** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REDECO».

### Palabras clave

- *Herencia:* bienes y derechos que recibe una persona cuando otra fallece.
- *Escriturar:* pasar legalmente una casa o terreno a tu nombre ante notario.

### Fuentes

Ley del ISR (artículo 93) · SAT · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 9. Módulo 9. Crecer y tu plan

## M9 U01. De sobrevivir a crecer: lo que ya sabes vale

**Lo que lograrás:** Reconocer tus habilidades (limpieza profunda, cocina, planchado, cuidado de niñas y personas mayores, organización) como algo que vale dinero, y pensar en crecer, no solo en aguantar.

**Para empezar:** Chayo dice: «Yo nomás sé limpiar». Pero en sus casas le piden que cocine para la semana, que cuide a la abuelita y que organice los clósets. Nunca ha cobrado aparte por nada de eso. En esta lección verás lo que ya sabes hacer.

### Lo esencial (5 minutos)

#### Mente que crece

Cuando el dinero no alcanza, la cabeza se va a sobrevivir: pagar hoy, aguantar mañana. Crecer es preguntarte **qué sé hacer que otras personas valoran y cómo puedo ganar más con eso**, poco a poco.



#### Lo que ya sabes hacer

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cocina | Comida de la semana, eventos. | Se cobra por guisado o por día. |
| Cuidado | Niñas, niños y personas mayores. | Pagan más por hora. |
| Organización | Clósets, mudanzas, limpieza profunda. | Servicio por proyecto. |
| Planchado y lavado | Por prenda o por docena. | Desde tu casa. |

#### Aprender te sube el precio

Un curso corto de cocina, primeros auxilios o cuidado de personas mayores te permite cobrar más. Pregunta en tu municipio, el DIF o los institutos de capacitación de tu estado por cursos de bajo costo o sin costo.



#### Un caso en un minuto

Chayo hizo su lista y se dio cuenta de que cocina muy bien. Ofreció a dos de sus casas guisados para la semana por 350 extra. Ahora gana 2,800 más al mes con algo que ya sabía hacer.

> **Idea clave:** lo que ya sabes hacer vale dinero; crecer es encontrar qué valoran las familias y cobrarlo aparte, poco a poco.



#### Comprueba lo que entendiste

1. ¿Qué es pensar en crecer?
*Respuesta:* Preguntarte qué sabes hacer que otras personas valoran y cómo ganar más con eso.

2. ¿Qué te ayuda a cobrar más?
*Respuesta:* Aprender algo nuevo, como un curso corto.


#### Para recordar

- Lo que sabes vale.
- Crecer poco a poco.
- Aprender te sube el precio.



### Profundiza (5 minutos más)

#### Tu lista de habilidades

| Sé hacer | ¿Quién lo necesita? | ¿Cuánto podría cobrar? |
|---|---|---|
| | | |
| | | |
| | | |



#### Tus hijas y nietas también

Cuando platicas en casa de lo que sabes hacer y de lo que quieres lograr, les enseñas que el trabajo vale y que se puede crecer.



#### Casos


**Caso 1. «Nomás sé limpiar»**

Chayo cree que solo sabe limpiar.
- *¿Qué hace?* Hace su lista de habilidades y busca qué le valoran sus casas.


**Caso 2. La abuelita de la casa de Mari**

En la casa donde trabaja Mari le piden cuidar a la abuelita sin pagarle más.
- *¿Qué hace?* Lo platica y propone cobrar el cuidado aparte.


**Caso 3. El curso de Doña Tere**

Doña Tere cree que ya está grande para aprender.
- *¿Qué hace?* Busca un curso corto en su municipio para cobrar más.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no sabes nada | No creces | Haz tu lista |
| Hacer más sin cobrar | Trabajas de más | Cobra aparte |
| Querer todo de golpe | Te agotas | Poco a poco |
| Creer que ya no puedes aprender | Te quedas igual | Cursos cortos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es pensar en crecer? a) Aguantar hasta que las cosas mejoren solas · b) Buscar cómo ganar más con lo que sabes · c) Pedir un préstamo
2. Cobras 350 extra por guisados en dos casas cada semana. ¿Cuánto ganas de más al mes? a) 700 · b) 350 · c) 2,800
3. ¿Qué te ayuda a cobrar más por hora? a) Un curso de cuidado de personas mayores · b) Trabajar sin descanso los siete días de la semana · c) Bajar tu tarifa
**Respuestas:** 1-b: es la idea. 2-c: 350 por 2 por 4 semanas. 3-a: te especializa.



#### Ponlo en práctica

Planchas los sábados una docena de camisas a 180. Si haces 3 docenas cada sábado, ¿cuánto ganas al mes?
**Respuesta:** 3 por 180: 540 por sábado. Por 4: 2,160 al mes.



#### A tu plan

Llena tu lista de habilidades y elige una que puedas ofrecer este mes.



### Para saber más

- **Capacitación para el trabajo** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «institutos de capacitación para el trabajo» de tu estado.

### Palabras clave

- *Habilidad:* algo que sabes hacer bien.
- *Ingreso extra:* dinero que ganas además de tu trabajo de siempre.

### Fuentes

Secretaría del Trabajo y Previsión Social, consultado el 30 de septiembre de 2026.

---

## M9 U02. Ofrece servicios extra y consigue clientas

**Lo que lograrás:** Poner precio a un servicio extra, calcular si te conviene y conseguir clientas por recomendación sin descuidar tu descanso.

**Para empezar:** Chayo quiere ofrecer limpieza profunda los domingos para mudanzas. No sabe cuánto cobrar ni cómo encontrar clientas. En esta lección armarás tu servicio.

### Lo esencial (5 minutos)

#### La limpieza profunda de Chayo

- Cobra por la limpieza profunda: **1,200**
- Productos: **150**
- Pasajes: **100**
- Le queda: **950**
Por 7 horas de trabajo: unos 135 por hora.


#### Tu servicio en una frase

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Qué haces | «Limpieza profunda para mudanzas». | Claro y corto. |
| Cuánto cobras | Precio fijo o por hora. | Que te deje ganancia. |
| Cómo te encuentran | Recomendaciones de tus casas. | Las más confiables. |
| Tu descanso | No trabajes todos los días. | Te enfermas. |

#### Recomendaciones

Las familias con las que trabajas son tu mejor publicidad. Pide: «Si conoce a alguien que necesite limpieza profunda, le dejo mi número». Una tarjeta o un mensaje de WhatsApp con tu servicio ayuda.



#### Un caso en un minuto

Chayo le pidió a dos señoras que la recomendaran. En un mes tuvo tres limpiezas de mudanza. Descansa un domingo sí y uno no.

> **Idea clave:** ponle precio a tu servicio restando productos y pasajes, pide recomendaciones a tus casas y cuida tu descanso.



#### Comprueba lo que entendiste

1. ¿Cómo sabes si un servicio te conviene?
*Respuesta:* Restas productos y pasajes y ves cuánto te queda por hora.

2. ¿Cuál es tu mejor publicidad?
*Respuesta:* Las recomendaciones de las familias con que trabajas.


#### Para recordar

- Precio menos costos.
- Recomendaciones.
- Cuida tu descanso.



### Profundiza (5 minutos más)

#### Tu servicio

| Pregunta | Tu respuesta |
|---|---|
| ¿Qué ofreces? | |
| ¿Cuánto cobras? | |
| ¿Cuánto te cuestan productos y pasajes? | |
| ¿Cuánto te queda por hora? | |
| ¿Qué días lo ofreces? | |



#### Cuídate con clientas nuevas

Pide la dirección por mensaje, avisa a alguien de confianza dónde estarás y cobra al terminar o la mitad al llegar. No entregues tu INE ni datos de tus otras casas.



#### Casos


**Caso 1. El precio de Chayo**

Chayo no sabe cuánto cobrar por limpieza profunda.
- *¿Qué hace?* Calcula productos, pasajes y horas, y fija un precio que le deje ganancia.


**Caso 2. Las clientas de Mari**

Mari quiere ofrecer cocina los sábados y no conoce a nadie.
- *¿Qué hace?* Pide a sus casas que la recomienden y comparte un mensaje con su servicio.


**Caso 3. El cansancio de Doña Tere**

Doña Tere aceptó trabajo los siete días y se enfermó.
- *¿Qué hace?* Deja un día de descanso a la semana.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cobrar sin restar costos | Ganas menos | Resta productos y pasajes |
| No pedir recomendaciones | Pocas clientas | Pídelas |
| Trabajar todos los días | Te enfermas | Descansa |
| Ir a casas nuevas sin avisar | Riesgo | Avisa dónde estarás |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo, Mari y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 900, gastas 120 en productos y 80 en pasajes. ¿Cuánto te queda? a) 900 · b) 700 · c) 1,100
2. ¿Cuál es la mejor forma de conseguir clientas al inicio? a) Recomendaciones de tus casas · b) Bajar tu precio a la mitad · c) Trabajar sin cobrar la primera vez
3. ¿Qué haces antes de ir a una casa nueva? a) Das tu INE por WhatsApp · b) Avisas a alguien de confianza dónde estarás · c) Llevas todo tu dinero y tu INE por si te los piden
**Respuestas:** 1-b: 900 menos 200. 2-a: generan confianza. 3-b: por tu seguridad.



#### Ponlo en práctica

Haces 4 limpiezas profundas al mes y te quedan 950 de cada una. ¿Cuánto ganas de más al mes?
**Respuesta:** 4 por 950: 3,800.



#### A tu plan

Llena la tabla de tu servicio y pide una recomendación esta semana.



### Para saber más

- **Emprende** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «emprendimiento» y apoyos de tu estado.

### Palabras clave

- *Servicio extra:* trabajo que ofreces además de tu trabajo de siempre.
- *Ganancia:* lo que te queda después de restar tus costos.

### Fuentes

Secretaría de Economía · STPS, consultados el 30 de septiembre de 2026.

---

## M9 U03. Apps y agencias de limpieza: ¿cuánto te queda?

**Lo que lograrás:** Comparar trabajar directo con las familias contra hacerlo por medio de apps o agencias, calculando lo que te queda después de comisiones y costos.

**Para empezar:** A Mari le ofrecen trabajar por una app de limpieza: «Te llegan clientas todos los días». La app se queda con una parte de lo que paga cada clienta. En esta lección sacarás cuentas.

### Lo esencial (5 minutos)

#### Lo que cobras contra lo que te queda

En una app o agencia, la clienta paga un precio, pero la app o agencia se queda con una comisión. Lo que importa es **cuánto te queda por hora**, no lo que paga la clienta.



#### La app de Mari

- Paga la clienta: **600**
- Comisión de la app (25%): **150**
- Pasajes: **80**
- Le queda a Mari: **370**
Por 5 horas: 74 por hora.


#### Qué comparar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión | Cuánto se queda la app. | Pregúntalo por escrito. |
| Clientas seguidas | La app te consigue trabajo. | Ventaja al inicio. |
| Seguro y protección | ¿Te dan seguro? | Pregunta. |
| Te cobran por inscribirte | Señal de engaño. | Desconfía. |

#### Un caso en un minuto

Mari usa la app dos días a la semana para conseguir clientas nuevas. A las que le gustan su trabajo les ofrece seguir directo, sin romper las reglas de la app. Así sube lo que le queda por hora.

> **Idea clave:** compara por lo que te queda por hora después de comisiones y pasajes; una app puede ayudarte a empezar, pero revisa sus reglas y su comisión.



#### Comprueba lo que entendiste

1. ¿Qué es la comisión?
*Respuesta:* La parte del pago que se queda la app o agencia.

2. ¿Qué comparas?
*Respuesta:* Lo que te queda por hora.


#### Para recordar

- Lo que te queda, no lo que paga la clienta.
- Pregunta la comisión.
- Revisa las reglas.



### Profundiza (5 minutos más)

#### Directo contra app

| Punto | Directo | App o agencia |
|---|---|---|
| Lo que te queda | Todo | Menos la comisión |
| Clientas | Las consigues tú | Te las mandan |
| Pagos | Acuerdas tú | Por la app |
| Protección | La que acuerdes | Pregunta qué incluye |



#### Lee los términos

Antes de registrarte, lee cuánto cobra la app, cuándo te paga, qué pasa si cancelas y si te prohíbe trabajar directo con las clientas. No pagues por inscribirte.



#### Casos


**Caso 1. La oferta de Mari**

A Mari le ofrecen una app «con clientas todos los días».
- *¿Qué hace?* Pregunta la comisión y calcula cuánto le queda por hora.


**Caso 2. La agencia de Chayo**

Una agencia le pide a Chayo 800 para «darla de alta».
- *¿Qué hace?* No paga: cobrar por inscribirte es señal de engaño.


**Caso 3. La clienta de Doña Tere**

A una clienta de la app le gustó el trabajo de Doña Tere.
- *¿Qué hace?* Revisa las reglas de la app antes de acordar trabajar directo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo lo que paga la clienta | Ganas menos | Resta la comisión |
| No leer los términos | Sorpresas | Léelos |
| Pagar por inscribirte | Engaño | Nunca |
| Depender de una sola app | Si cambia, pierdes | Ten clientas directas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mari, Chayo y Doña Tere. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. La clienta paga 800 y la app se queda con 20%. ¿Cuánto te llega antes de pasajes? a) 160 · b) 800 · c) 640
2. ¿Qué es señal de engaño en una agencia? a) Que te pida pagar por inscribirte · b) Que tenga contrato · c) Que te explique la comisión y cuándo te paga
3. ¿Con qué comparas la app contra trabajar directo? a) Con lo que paga la clienta · b) Con lo que te queda por hora · c) Con cuántas estrellas tienes
**Respuestas:** 1-c: 800 menos 160. 2-a: nadie serio cobra por darte trabajo. 3-b: es tu ganancia real.



#### Ponlo en práctica

Directo cobras 550 y gastas 70 en pasajes por 6 horas. En la app la clienta paga 700, la app se queda con 25% y gastas 70 por 6 horas. ¿Qué te deja más por hora?
**Respuesta:** Directo: 480 entre 6, 80 por hora. App: 700 menos 175 menos 70 = 455 entre 6, unos 76 por hora. Directo deja un poco más.



#### A tu plan

Si usas o piensas usar una app, pregunta su comisión y calcula lo que te queda por hora.



### Para saber más

- **Derechos en el trabajo** (PROFEDET · español): https://www.gob.mx/profedet — **Qué buscar:** «orientación laboral».

### Palabras clave

- *Comisión:* parte del pago que se queda la app o agencia por conseguirte el trabajo.
- *Términos:* reglas de una app que aceptas al registrarte.

### Fuentes

PROFEDET · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M9 U04. Tu plan de una página y tu compromiso

**Lo que lograrás:** Reunir en una hoja tu ingreso, tu ahorro, tu apoyo a la familia, tus deudas, tu protección, tu futuro y tu idea para crecer, con un compromiso con nombre, testigo y recordatorio.

**Para empezar:** Doña Tere ya tiene su lista de deudas, su fondo, sus beneficiarias y su Afore, pero en papelitos sueltos. Quiere verlo todo junto. En esta lección harás tu plan de una página.

### Lo esencial (5 minutos)

#### Las partes de tu plan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu semana | Lo que te entra y tus sobres. | Módulo 1. |
| Tu familia | Cuánto das y tus reglas para prestar. | Módulo 4. |
| Deudas y ahorro | Orden para pagar y fondo. | Módulos 3 y 5. |
| Protección y futuro | Salud, beneficiarias, Afore y testamento. | Módulos 6 y 8. |

#### Revísalo cada semana

Tu plan de una página se revisa en cinco minutos el día que cobras la última casa de la semana: ¿aparté mi ahorro? ¿pagué mis deudas? ¿cuánto me falta para mi meta?



#### Tu compromiso

Escribe una meta con nombre («fondo para la prepa de Yaretzi»), cuánto apartarás y cada cuándo. Díselo a alguien de confianza que te pregunte cómo vas. Aparta el ahorro el mismo día que cobras, antes de gastar, y pon un recordatorio mensual en tu celular con el nombre de tu meta.



#### Un caso en un minuto

Doña Tere llenó su plan y le tomó una foto. Su compromiso: «Fondo de un mes para mi tranquilidad, 100 cada día que trabajo». Su hija Rosa es su testigo. En seis meses terminó con la prestamista y juntó su fondo.

> **Idea clave:** tu plan en una hoja, revisado cada semana, te dice dónde estás y qué sigue; un compromiso con nombre, testigo y recordatorio te ayuda a cumplirlo.



#### Comprueba lo que entendiste

1. ¿Cada cuándo revisas tu plan?
*Respuesta:* Cada semana, el día que cobras.

2. ¿Qué no va en tu plan?
*Respuesta:* Contraseñas, NIP ni números completos de cuenta.


#### Para recordar

- Tu plan en una hoja.
- Meta con nombre, testigo y recordatorio.
- Sin datos sensibles.



### Profundiza (5 minutos más)

#### Tu plan

| Parte | Hoy | Siguiente paso |
|---|---|---|
| Lo que me entra al mes (mes flojo) | | |
| Ahorro por día o semana | | |
| Apoyo fijo a mi familia | | |
| Deudas (total y la que pago primero) | | |
| Fondo de emergencia | | |
| Salud (IMSS, seguro o centro de salud) | | |
| Beneficiarias, testamento y papeles de la casa | | |
| Afore y pensión | | |
| Mi idea para crecer | | |
| Mi compromiso: meta, monto, fecha y testigo | | |



#### Por qué funciona

Estudios en varios países encontraron que ponerle nombre a una meta, comprometerse con alguien y recibir un recordatorio mensual con esa meta ayuda a ahorrar más. Apartar el dinero antes de verlo también ayuda: no tienes que decidir cada vez.



#### Casos


**Caso 1. Los papelitos de Doña Tere**

Doña Tere tiene todo en papelitos sueltos.
- *¿Qué hace?* Llena su plan de una página y le toma una foto.


**Caso 2. El plan olvidado de Chayo**

Chayo hizo su plan pero nunca lo vuelve a ver.
- *¿Qué hace?* Lo revisa cinco minutos cada semana.


**Caso 3. El NIP de Mari**

Mari quiere anotar su NIP en su plan para no olvidarlo.
- *¿Qué hace?* No lo anota: el plan no lleva datos sensibles.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo suelto | No ves el conjunto | Una hoja |
| No revisarlo | Se olvida | Cada semana |
| Datos sensibles | Riesgo | Sin NIP ni cuentas |
| Meta sin nombre | No te motiva | Ponle nombre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Tere, Chayo y Mari. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué ayuda a cumplir una meta de ahorro? a) Guardarla en secreto para que nadie opine · b) Ahorrar lo que sobre · c) Nombre, testigo y recordatorio
2. ¿Qué no va en tu plan? a) Tu NIP · b) Tu meta de ahorro · c) Tu lista de deudas
3. ¿Cada cuándo conviene revisar tu plan si cobras por día? a) Una vez al año · b) Cada semana · c) Solo en diciembre
**Respuestas:** 1-c: así ahorras más. 2-a: es un dato sensible. 3-b: el día que cobras.



#### Ponlo en práctica

Tu meta es 6,000 para la prepa de tu nieta en 30 semanas. ¿Cuánto apartas por semana?
**Respuesta:** 6,000 entre 30: 200 por semana.



#### A tu plan

Llena tu plan de una página, escribe tu compromiso con nombre, monto y testigo, y pon tu recordatorio mensual.



### Para saber más

- **Tu plan financiero** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «plan financiero personal».

### Palabras clave

- *Plan de una página:* resumen de tus decisiones de dinero en una sola hoja.
- *Testigo:* persona de confianza a quien le cuentas tu meta para que te pregunte cómo vas.

### Fuentes

CONDUSEF · Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera», consultados el 30 de septiembre de 2026.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Trabajo, Tu Familia, Tu Futuro** es un programa de bienestar financiero para trabajadoras del hogar en México: limpieza, cocina y cuidado, de entrada por salida o de planta.

Aquí aprenderás a saber cuánto te entra de verdad, a cobrar lo justo, a repartir el dinero de la semana, a organizar tandas con reglas, a ayudar a tu familia sin hundirte, a salir de deudas, a proteger tu salud, a cuidarte de fraudes, a preparar tu vejez y la de tus nietas, y a crecer con lo que ya sabes hacer.

Cada lección dura unos 5 minutos y está hecha para el celular: puedes tomarla en el camión o en tu descanso.

Versión 1.0 · Septiembre de 2026.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos |
| **¿Qué harías?** | Tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todo el módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 minutos |

### Las personajes

- **Doña Tere** (58): trabaja de entrada por salida en cuatro casas; sostiene a su hija Rosa y a sus nietas Ximena (9) y Yaretzi (15); tiene deudas y está en una tanda.
- **Mari** (41): trabaja de planta de lunes a viernes y cobra por quincena; quiere ahorrar para la prepa de su hijo.
- **Chayo** (34): trabaja por días, organiza la tanda de la colonia y quiere ganar más con lo que sabe hacer.
- **Rosa** (36): hija de Doña Tere, mamá sola; a veces le pide dinero a su mamá.

### Tres reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, montos reales ni datos de las casas donde trabajas.
2. **No te vendemos nada**, ni préstamos ni seguros.
3. **Tu información es tuya.** Nadie recibe tus datos personales ni financieros.

### Los datos cambian

Los datos del programa se consultaron el **30 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa la información vigente en el sitio oficial de la institución.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay ocho insignias. Al aprobar las nueve autoevaluaciones recibes la insignia **Plan completo · Tu Trabajo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. El mes de Doña Tere (Módulos 1 y 2)

**Datos.** Doña Tere cobra 550 por día en tres casas y 600 en otra. El mes pasado trabajó 13 días a 550 y 4 a 600. Gasta 70 de pasajes cada día. Una casa le pide planchar sin pagarle más.

**Tareas.**

1. ¿Cuánto le entró en el mes?
2. ¿Cuánto gastó en pasajes?
3. ¿Qué hace con el planchado?

**Clave.**

- 13 por 550: 7,150; 4 por 600: 2,400. Total: 9,550.
- 17 días por 70: 1,190.
- Calcula el tiempo extra y propone cobrarlo aparte (M2 U02).

### E2. La tanda y el fondo de Chayo (Módulo 3)

**Datos.** Chayo está en una tanda de 8 personas con 300 por semana y cobra en el número 2. Sus gastos básicos son 2,200 por semana.

**Tareas.**

1. ¿Cuánto cobra en la tanda?
2. ¿Cuánto le falta pagar al cobrar?
3. ¿Cuál es su primera meta de fondo de emergencia?

**Clave.**

- 300 por 8: 2,400.
- Ha puesto 600; le faltan 6 pagos: 1,800.
- Dos semanas de gastos: 4,400.

### E3. La familia y las deudas de Doña Tere (Módulos 4 y 5)

**Datos.** Doña Tere da 1,350 fijos al mes a su familia. Debe 6,400 a una tienda (400 por semana), 3,000 a una prestamista (500 por semana, 20% al mes) y 1,200 a su comadre. Su yerno le pide que sea aval de una moto.

**Tareas.**

1. ¿Cuánto debe en total?
2. ¿Por cuál empieza si usa la avalancha?
3. ¿Qué responde al yerno?

**Clave.**

- 10,600.
- Por la prestamista: es la más cara.
- «No puedo firmar una deuda que no podría pagar»; ofrece otra ayuda (M4 U03).

### E4. La salud de la familia de Chayo (Módulo 6)

**Datos.** Ninguna casa inscribe a Chayo al IMSS. Su mamá tiene 62 años y su hija 10. Cuotas 2026 del Seguro de Salud para la Familia: 19,800 (60 a 69 años) y 9,300 (0 a 19 años).

**Tareas.**

1. ¿Cuánto cuesta inscribir a las dos al año?
2. ¿Cuánto aparta por semana?
3. ¿Qué opción tiene si no puede pagar?

**Clave.**

- 29,100 al año.
- 29,100 entre 52: unos 560 por semana.
- Centro de salud de IMSS-Bienestar, sin costo (M6 U03).

### E5. La herencia de Doña Tere (Módulo 8)

**Datos.** Doña Tere vive en una casa sin escrituras y tiene una parcela ejidal en su pueblo. Tiene cuenta, Afore y un seguro sin beneficiarias. Su hija cree que heredar paga 30% de ISR.

**Tareas.**

1. ¿Qué hace primero con su cuenta, Afore y seguro?
2. ¿Qué hace con la casa y la parcela?
3. ¿Es cierto lo del 30%?

**Clave.**

- Nombra beneficiarias en los tres (M8 U04).
- Pide orientación para regularizar la casa y revisa la lista de sucesión en el Registro Agrario Nacional; hace su testamento (M8 U05).
- No: recibir una herencia está exento de ISR; sí cuesta escriturar (M8 U06).


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | 520 por día, 16 días. ¿Cuánto te entra al mes? |
| P02 | M1 U01 | 2,300 por semana de planta. ¿Al mes, más o menos? |
| P03 | M1 U03 | 110 diarios en pasajes y comida, 18 días. ¿Al mes? |
| P04 | M1 U05 | 149 por semana durante 52 semanas. ¿Total? |
| P05 | M2 U01 | Aguinaldo en una casa donde trabajas 104 días al año, cobrando 500. |
| P06 | M2 U02 | Cobras 500, pasajes 80, 9 horas contando camino. ¿Por hora? |
| P07 | M3 U01 | Tanda de 10 con 250 por semana. ¿Cuánto cobras? |
| P08 | M3 U04 | Útiles de 2,800 en 28 semanas. ¿Por semana? |
| P09 | M5 U02 | Préstamo de 2,500, pagas 150 por 30 semanas. ¿Cuánto de más? |
| P10 | M6 U02 | Seguro de Salud para la Familia de 13,800 al año. ¿Por semana? |
| P11 | M8 U02 | 70 a la semana en tu Afore por 20 años. ¿Cuánto pones? |
| P12 | M9 U03 | Clienta paga 700, comisión 20%, pasajes 60. ¿Te queda? |

### Respuestas

- P01: 8,320.
- P02: unos 9,890.
- P03: 1,980.
- P04: 7,748.
- P05: 104 entre 365 por 15: unos 4.3 días; por 500, unos 2,140.
- P06: 420 entre 9: unos 47.
- P07: 2,500.
- P08: 100.
- P09: 4,500 menos 2,500: 2,000.
- P10: unos 265.
- P11: 72,800.
- P12: 700 menos 140 menos 60: 500.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Lo que ganas por día o por quincena

- **Abono:** pago pequeño que haces cada semana o quincena por algo que compraste a crédito.
- **Ahorro:** dinero que guardas hoy para usarlo después.
- **Apartado:** dinero que separas dentro de tu cuenta para una meta, sin sacarlo.
- **Cuenta básica:** cuenta de banco sin comisión por manejo que todos los bancos deben ofrecer.
- **De entrada por salida:** trabajo en el que llegas y te vas el mismo día, y cobras por día.
- **De planta:** trabajo en una sola casa, con pago por semana o por quincena.
- **Gasto hormiga:** gasto pequeño que se repite y, sumado, es grande.
- **Precio por unidad:** lo que cuesta cada litro, kilo o pieza.
- **Presupuesto:** plan de cuánto te entra y en qué lo vas a usar.
- **Salario mínimo profesional:** el pago más bajo que la ley permite para un oficio; para trabajadoras del hogar es más alto que el general.

### Tu trabajo vale

- **Aguinaldo:** pago de al menos 15 días de salario antes del 20 de diciembre.
- **Ajuste:** aumento para que tu pago no pierda valor cuando suben los precios.
- **CLABE:** número de 18 dígitos para recibir transferencias.
- **Contrato por escrito:** papel firmado que dice qué haces, cuánto te pagan, tu horario y tus descansos.
- **Finiquito:** pago al terminar el trabajo: días pendientes, parte de aguinaldo y de vacaciones.
- **Ley Federal del Trabajo:** la ley que dice los derechos y obligaciones en el trabajo en México.
- **NIP:** clave secreta de tu tarjeta; nunca se comparte.
- **Prima vacacional:** pago extra de al menos 25% sobre tus días de vacaciones.
- **PROFEDET:** Procuraduría Federal de la Defensa del Trabajo; orienta sin costo.
- **Tarifa:** lo que cobras por día u hora de trabajo.

### Tandas y ahorro

- **Fondo de emergencia:** dinero guardado solo para imprevistos: enfermedad, días sin trabajo o una urgencia de la familia.
- **Fraude piramidal:** esquema que promete multiplicar tu dinero pagando con lo que ponen personas nuevas; tarde o temprano se cae.
- **Inflación:** aumento de los precios con el tiempo.
- **IPAB:** seguro que protege tus depósitos en bancos.
- **Número de la tanda:** el lugar en que te toca cobrar.
- **Rendimiento:** lo que gana tu dinero por estar guardado o invertido.
- **Tanda:** ahorro en grupo en el que cada persona pone lo mismo y, por turnos, una se lleva todo.

### Ayudar sin hundirte

- **Apoyo fijo:** lo que decides dar cada mes a tu familia, con monto.
- **Autonomía económica:** poder decidir sobre tu propio dinero.
- **Aval:** persona que firma el pagaré y paga si quien pidió no paga.
- **Defensoría pública:** servicio de abogados sin costo que da el gobierno.
- **Estrés financiero:** preocupación constante por el dinero que afecta tu sueño, tu salud o tu familia.
- **Interés:** lo que pagas por usar dinero prestado.
- **Obligado solidario:** persona que responde por todo el crédito como si lo hubiera pedido.
- **Referencia personal:** persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no firma ni se obliga a pagar.
- **Violencia económica:** cuando otra persona controla, retiene o usa tu dinero o tus bienes para dominarte.

### Deudas: salir y no volver

- **App montadeudas:** app de préstamo sin registro que usa tus contactos y fotos para amenazarte y cobrarte de más.
- **Avalancha:** pagar primero la deuda más cara.
- **Bola de nieve:** pagar primero la deuda más chica.
- **Buró de Crédito:** empresa que guarda tu historial de cómo pagas tus créditos.
- **CAT:** Costo Anual Total: porcentaje que incluye intereses y comisiones de un crédito en un año.
- **Gota a gota:** préstamo informal con cobro diario, intereses altísimos y cobranza con amenazas.
- **Historial de crédito:** registro de tus créditos y de cómo los pagaste.
- **Refrendo:** pago para alargar el plazo de un empeño sin perder la prenda.
- **SIPRES:** registro de la CONDUSEF donde verificas si una institución financiera está autorizada.
- **Sobreendeudamiento:** cuando tus pagos de deudas son tan altos que ya no alcanza para lo básico.

### Tu salud y tu protección

- **Beneficiaria:** persona que recibe el dinero de un seguro o cuenta si falleces.
- **Chequeo:** revisión médica para encontrar problemas a tiempo.
- **IMSS-Bienestar:** servicio de salud para personas sin seguridad social en los estados que se sumaron.
- **Incapacidad:** pago del IMSS cuando no puedes trabajar por enfermedad o accidente.
- **NSS:** número de seguridad social que te identifica en el IMSS.
- **Periodo de espera:** tiempo que tiene que pasar desde que te inscribes para que te cubran ciertas atenciones.
- **Previsión funeraria:** plan que pagas en abonos para cubrir un funeral cuando se necesite.
- **Riesgo de trabajo:** accidente o enfermedad que te pasa por tu trabajo.
- **Seguridad social:** protección que da el IMSS: servicio médico, incapacidades, guardería, pensión y ahorro para el retiro.
- **Seguro de Salud para la Familia:** seguro voluntario del IMSS que da servicio médico a quien no tiene seguridad social; se paga una cuota al año por persona según su edad.
- **Seguro de vida:** contrato que paga una cantidad a las personas que nombras si falleces.

### Fraudes y tu celular

- **Alerta:** aviso que te manda el banco por cada movimiento.
- **Fraude telefónico:** engaño por llamada o mensaje para quitarte dinero o datos.
- **Gestor:** persona que cobra por hacer trámites que puedes hacer tú sin costo.
- **REPEP:** registro de la PROFECO para que no te llamen empresas con publicidad.
- **REUS:** registro de la CONDUSEF para que no te llamen bancos y financieras con publicidad.
- **Robo de identidad:** cuando alguien usa tus datos para sacar créditos o hacer trámites a tu nombre.
- **Verificación en dos pasos:** un NIP extra que pide la app para que nadie más use tu cuenta.

### Tu vejez y tus nietas

- **Afore:** administradora que guarda tu ahorro para el retiro.
- **Aportación voluntaria:** dinero que tú depositas en tu Afore además de lo que pone un patrón.
- **Beca universal:** apoyo para todas las personas que estudian en un nivel, sin concurso.
- **Beneficiarios legales:** personas que la ley pone primero para recibir tu Afore: pareja, hijas e hijos, y madre y padre.
- **Coyote:** persona que cobra por trámites que no tienen costo.
- **Escriturar:** pasar legalmente una casa o terreno a tu nombre ante notario.
- **Herencia:** bienes y derechos que recibe una persona cuando otra fallece.
- **Lista de sucesión:** lista en la que la persona ejidataria nombra quién hereda sus derechos; se registra en el Registro Agrario Nacional.
- **Pensión Mujeres Bienestar:** apoyo bimestral para mujeres de 60 a 64 años.
- **Pensión para Adultos Mayores:** apoyo bimestral para personas de 65 años o más.
- **Regularizar:** poner en orden los papeles de una casa o terreno.
- **Testamento:** documento ante notario en el que dices quién recibe tus bienes y quién cuida a tus hijos o nietos menores.

### Crecer y tu plan

- **Comisión:** parte del pago que se queda la app o agencia por conseguirte el trabajo.
- **Ganancia:** lo que te queda después de restar tus costos.
- **Habilidad:** algo que sabes hacer bien.
- **Ingreso extra:** dinero que ganas además de tu trabajo de siempre.
- **Plan de una página:** resumen de tus decisiones de dinero en una sola hoja.
- **Servicio extra:** trabajo que ofreces además de tu trabajo de siempre.
- **Testigo:** persona de confianza a quien le cuentas tu meta para que te pregunte cómo vas.
- **Términos:** reglas de una app que aceptas al registrarte.


## Dónde encontrar ayuda

Todas las opciones de esta tabla son oficiales y sin costo. Información consultada el 30 de septiembre de 2026; confírmala en el sitio oficial.

| Necesidad | Dónde | Qué verificar |
|---|---|---|
| Tus derechos como trabajadora del hogar | PROFEDET y la procuraduría del trabajo de tu estado | Orientación sin costo |
| Salario mínimo | CONASAMI | Salario profesional de trabajadoras del hogar |
| IMSS cuando la casa te inscribe | IMSS, Personas Trabajadoras del Hogar | Calculadora y trámite en línea |
| IMSS pagando tú | IMSS, Seguro de Salud para la Familia | Cuota por edad y periodos de espera |
| Atención médica sin seguridad social | Centro de salud o IMSS-Bienestar | Tu CURP |
| Reclamar a un banco o financiera | Unidad de atención del banco y CONDUSEF: 55 5340 0999 u 800 999 8080 | Folio de tu reclamación |
| Saber si una financiera existe | SIPRES de la CONDUSEF | Nombre exacto |
| Despachos de cobranza que abusan | REDECO de la CONDUSEF | Nombre del despacho y fechas |
| Tu reporte de crédito | Buró de Crédito y Círculo de Crédito (uno sin costo al año en cada uno) | Solo sitios oficiales |
| Fraudes y amenazas de apps | 088 | Capturas |
| Emergencias y violencia | 911; Línea Mujeres en la Ciudad de México: *0311 o 55 5658 1111 | Atención 24 horas |
| Tu Afore | AforeMóvil y CONSAR | Tu CURP |
| Pensiones y becas del Bienestar | Programas para el Bienestar | Registro sin costo, sin coyotes |
| Testamento | Notarías del Mes del Testamento (septiembre) | Descuentos por estado |
| Tierra ejidal | Registro Agrario Nacional | Lista de sucesión |
| Casa sin escrituras | INSUS y el instituto de vivienda de tu estado | Programas de regularización |
| Llamadas de publicidad | REPEP de la PROFECO y REUS de la CONDUSEF | Nadie cobra por inscribirte |
| Planes funerarios | PROFECO | Registro del contrato |
| Apoyo emocional | Línea de la Vida: 800 911 2000 | Atención 24 horas |

---

## Preguntas frecuentes

**¿Las familias donde trabajo ven mis respuestas?** No. El curso no comparte información personal ni financiera con nadie.

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados.

**¿El curso me presta dinero o me vende seguros?** No. Te enseña a comparar y a decidir.

**¿El curso me dice que pelee con quien me contrata?** No. Te da información y números para platicarlo con calma, y te dice dónde pedir orientación si no hay acuerdo.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso; cada lección dura unos 5 minutos.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.


## Referencias

Fuentes que usamos en el curso, consultadas el 30 de septiembre de 2026.

### Instituciones

- **I01** CONASAMI: salarios mínimos 2026, incluido el salario mínimo profesional de personas trabajadoras del hogar.
- **I02** PROFEDET y STPS: derechos de las personas trabajadoras del hogar y modelo de contrato.
- **I03** IMSS: esquema de Personas Trabajadoras del Hogar, Seguro de Salud para la Familia y personas trabajadoras independientes.
- **I04** IMSS-Bienestar y Secretaría de Salud: atención a personas sin seguridad social.
- **I05** CONDUSEF: cuenta básica, CAT, SIPRES, REDECO, REUS y alertas sobre montadeudas.
- **I06** Banco del Bienestar: cuenta de ahorro.
- **I07** Buró de Crédito y Círculo de Crédito: reportes sin costo.
- **I08** CONSAR y AforeMóvil: aportaciones voluntarias y beneficiarios.
- **I09** Programas para el Bienestar: Pensión Mujeres Bienestar, Pensión para Adultos Mayores, Beca Benito Juárez y Beca Rita Cetina.
- **I10** PROFECO: REPEP, casas de empeño y previsión funeraria.
- **I11** Registro Agrario Nacional, INSUS y Secretaría de Gobernación (Mes del Testamento).
- **I12** SAT: herencias e ingresos exentos.
- **I13** CONASAMA: Línea de la Vida. Locatel: Línea Mujeres. Inmujeres: violencia económica.

### Leyes

- **L01** Ley Federal del Trabajo: capítulo XIII (personas trabajadoras del hogar), artículos 76, 80, 87 y 25.
- **L02** Ley del Seguro Social: régimen de personas trabajadoras del hogar e incorporación voluntaria.
- **L03** Ley del Impuesto sobre la Renta: artículo 93, fracción XXII (herencias).
- **L04** Ley Agraria: artículo 17 (lista de sucesión).

### Estudios

- **E01** Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera».
- **E02** Medios nacionales que citan las cuotas 2026 del Seguro de Salud para la Familia del IMSS.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. ¿Cuánto te entra al mes?

**Caso 1. El mes de Doña Tere.** Doña Tere hace sus cuentas con «12 mil», pero le entraron 9,350. **¿Qué hace?**

- ✔ Hace su presupuesto con lo que le entra en un mes flojo.
- Hace sus cuentas con los 12 mil que dice ganar cada mes.
- Pide prestado cada mes para completar lo que falta.

**Caso 2. La quincena de Mari.** Mari trabaja de planta y cobra 6,000 por quincena. **¿Cuánto le entra al mes?**

- ✔ 12,000, porque son dos quincenas.
- 6,000, porque cobra una sola vez al mes.
- 18,000, porque el mes tiene tres quincenas.

**Caso 3. La casa que cancela de Chayo.** A Chayo una casa le cancela seguido el mismo día. **¿Qué hace?**

- ✔ Anota los días que pierde y lo platica con la familia.
- No dice nada para no perder esa casa de trabajo.
- Deja de ir a esa casa sin avisar a la familia.

## M1 U02. Tu dinero de la semana

**Caso 1. La bolsa de Chayo.** Chayo lleva todo lo que cobra en la bolsa y lo gasta sin darse cuenta. **¿Qué hace?**

- ✔ Reparte el pago en sobres en su casa cada tarde.
- Sigue cargando todo en la bolsa para tenerlo a la mano.
- Gasta todo el día que cobra y ve cómo sale la renta.

**Caso 2. La renta de Doña Tere.** Doña Tere paga 3,000 de renta el día 1 y nunca la tiene junta. **¿Qué hace?**

- ✔ Aparta unos 700 cada semana para la renta.
- Junta la renta el último día con lo que traiga en la bolsa.
- Pide prestado cada mes a su hija para completar la renta.

**Caso 3. La semana sin trabajo de Mari.** A Mari le dieron una semana sin goce de sueldo. **¿Qué hace?**

- ✔ Recorta primero los gastos de la semana y cuida la renta.
- Deja de pagar la renta ese mes y paga luego.
- Pide un préstamo en una app para cubrir la semana.

## M1 U03. Los gastos chiquitos del trabajo

**Caso 1. Los camiones de Doña Tere.** Doña Tere gasta 70 diarios en pasajes y nadie se los paga. **¿Qué hace?**

- ✔ Pide con calma el apoyo de pasajes y lo anota.
- Sigue pagando todo porque le da pena pedirlo a la familia.
- Deja de ir a esa casa sin decir nada a la familia.

**Caso 2. La recarga de Chayo.** Chayo recarga 30 cada tercer día. **¿Qué hace?**

- ✔ Compara con un plan fijo al mes.
- Sigue recargando cada tercer día como siempre lo hace.
- Pide datos prestados a la familia donde trabaja.

**Caso 3. La comida de Mari.** Mari trabaja de planta y compra comida afuera porque no sabe si puede usar la cocina. **¿Qué hace?**

- ✔ Pregunta y acuerda qué puede comer en la casa.
- Sigue comprando afuera todos los días para no molestar.
- Deja de comer en el trabajo para ahorrar ese dinero.

## M1 U04. Aparta primero

**Caso 1. El ahorro de Mari.** Mari ahorra lo que sobre al final de la quincena. **¿Qué hace?**

- ✔ Aparta 600 el día que le pagan, antes de gastar.
- Sigue ahorrando lo que sobre al final de cada quincena.
- Ahorra solo en diciembre, cuando le dan su aguinaldo.

**Caso 2. El sobre de Doña Tere.** Doña Tere guarda el ahorro en un sobre y lo toma cuando le piden. **¿Qué hace?**

- ✔ Lo pasa a una cuenta aparte que no usa diario.
- Sigue guardando el sobre en su casa, a la vista de todos.
- Lo presta a quien se lo pida para que no se quede parado.

**Caso 3. La culpa de Chayo.** Chayo siente culpa de ahorrar mientras su mamá necesita. **¿Qué hace?**

- ✔ Ahorra poco pero siempre, porque también protege a su mamá.
- Deja de ahorrar hasta que su mamá ya no necesite dinero.
- Le da todo su ahorro a su mamá cada vez que se lo pide.

## M1 U05. Compra inteligente: abonos, precios y pagos chiquitos

**Caso 1. La lavadora de Doña Tere.** Le ofrecen 189 a la semana por dos años. **¿Qué hace?**

- ✔ Suma el total, compara y junta para pagarla.
- La compra: 189 a la semana casi no se siente en su bolsa.
- Pide un préstamo para llevarse la lavadora hoy mismo.

**Caso 2. El detergente de Chayo.** Chayo compra siempre el más grande porque cree que sale más barato. **¿Qué hace?**

- ✔ Calcula el precio por litro de cada uno.
- Compra el grande porque siempre sale más barato al final.
- Compra el que tiene más anuncios en la televisión.

**Caso 3. El celular de Mari.** Un vendedor le dice a Mari que la oferta es «solo hoy». **¿Qué hace?**

- ✔ Espera un día y compara en otras tiendas.
- Lo compra ya, antes de que se acabe la oferta de hoy.
- Pide prestado a su hermana para aprovechar la oferta.

## M2 U01. Tus derechos: lo que la ley dice de tu trabajo

**Caso 1. Las vacaciones de Mari.** Mari lleva seis años de planta y nunca ha tenido vacaciones pagadas. **¿Qué hace?**

- ✔ Hace sus cuentas y lo platica con calma y con números.
- No dice nada para no perder el trabajo de tantos años.
- Se va sin avisar para que la señora aprenda la lección.

**Caso 2. El aguinaldo de Chayo.** Chayo trabaja un día a la semana en tres casas y cree que no le toca aguinaldo. **¿Qué hace?**

- ✔ Calcula la parte de cada casa y la pide.
- No pide nada porque cree que por días no le toca aguinaldo.
- Pide el aguinaldo completo de un año en cada una de las casas.

**Caso 3. El descanso de Doña Tere.** En una casa le piden a Doña Tere que no coma para terminar antes. **¿Qué hace?**

- ✔ Pide su tiempo para comer; es parte de su descanso.
- No come para terminar antes y quedar bien con la familia.
- Come a escondidas en la cocina para que no la vean.

## M2 U02. ¿Cuánto cobrar? Tu tarifa

**Caso 1. El planchado de Chayo.** En una casa le piden a Chayo planchar además de limpiar, por el mismo pago. **¿Qué hace?**

- ✔ Calcula el tiempo extra y propone una tarifa con planchado.
- Plancha sin cobrar para no perder la casa donde trabaja.
- Deja de ir a esa casa sin decir nada a la señora.

**Caso 2. Los pasajes de Doña Tere.** Los pasajes de Doña Tere subieron y cobra lo mismo desde hace años. **¿Qué hace?**

- ✔ Pide un ajuste con sus números en enero.
- Sigue cobrando lo mismo para no incomodar a nadie.
- Sube su tarifa el mismo día sin avisar a la familia.

**Caso 3. La casa nueva de Mari.** A Mari le ofrecen una casa extra los sábados y no sabe cuánto pedir. **¿Qué hace?**

- ✔ Suma horas, camino y tareas, y pide al menos el mínimo.
- Acepta lo que le quieran dar para no perder la oportunidad.
- Pide el doble de lo que cobra en sus otras casas.

## M2 U03. Acuerdos claros y qué hacer si no te pagan

**Caso 1. Los días de Doña Tere.** Una familia le debe tres días a Doña Tere y le dice «luego». **¿Qué hace?**

- ✔ Pide el pago por mensaje y guarda la conversación.
- Espera a que se acuerden de pagarle sin decir nada.
- Borra el número de la familia para ya no enojarse.

**Caso 2. El papel de Mari.** Al despedirla, le dan a Mari un papel para firmar que dice que no le deben nada. **¿Qué hace?**

- ✔ No firma sin revisar y pide orientación.
- Firma rápido para irse y no tener problemas con nadie.
- Firma y después se queja con sus vecinas del trato.

**Caso 3. La casa nueva de Chayo.** Chayo empieza en una casa nueva y todo fue de palabra. **¿Qué hace?**

- ✔ Manda un mensaje con lo acordado y pide confirmación.
- Lo deja de palabra porque la familia se ve muy confiable.
- Pide un contrato con notario antes del primer día.

## M2 U04. Cobrar sin perder: tu cuenta y las transferencias

**Caso 1. La bolsa de Chayo.** Chayo lleva en efectivo lo de cuatro casas y la asaltaron. **¿Qué hace?**

- ✔ Abre una cuenta y pide pagos por transferencia.
- Sigue cargando todo el efectivo, pero lo esconde mejor.
- Pide que le paguen solo una vez al mes para cargar menos.

**Caso 2. La comisión de Mari.** A Mari le cobran 120 al mes en su cuenta. **¿Qué hace?**

- ✔ Pide que la cambien a cuenta básica sin comisión.
- Sigue pagando porque cree que así es en todos los bancos.
- Cierra su cuenta y guarda todo en efectivo en su casa.

**Caso 3. El mensaje de Doña Tere.** Le llega un mensaje: «Para depositarte tu pago, dame el código que te llegó». **¿Qué hace?**

- ✔ No da el código: para recibir basta su CLABE.
- Da el código porque la familia necesita depositarle ya.
- Da el código y después cambia su NIP por si acaso.

## M3 U01. Tandas: cómo funcionan y qué puede salir mal

**Caso 1. La señora que se fue.** Una señora cobró en el número 2 y se cambió de estado. **¿Qué hace Chayo la próxima vez?**

- ✔ Pone reglas escritas y da los primeros números a gente de confianza.
- Organiza igual que antes porque fue mala suerte y no se repetirá.
- Deja de organizar tandas y guarda todo su dinero en un cajón de su casa.

**Caso 2. El número de Doña Tere.** Doña Tere quiere el número 1 para pagar una deuda. **¿Qué hace?**

- ✔ Entiende que es otra deuda y revisa si podrá pagar.
- Pide el número 1 sin pensar: así paga su deuda más rápido.
- Pide el número 1 y después ve cómo le hace para pagar las semanas.

**Caso 3. Las dos tandas de Mari.** Mari está en dos tandas y ya no le alcanza para pagar las dos. **¿Qué hace?**

- ✔ No entra a otra y termina una antes de seguir.
- Entra a una tercera tanda para pagar las otras dos con esa.
- Deja de pagar una de las tandas sin avisar a las demás señoras.

## M3 U02. Tu tanda con reglas o tu propio ahorro

**Caso 1. La nueva tanda de Chayo.** Chayo quiere organizar otra tanda. **¿Qué hace?**

- ✔ Grupo chico, reglas por escrito y registro de pagos.
- Invita a toda la colonia para que la tanda sea más grande.
- Lo deja todo de palabra porque todas se conocen desde hace años.

**Caso 2. El ahorro de Doña Tere.** Doña Tere ahorra sola pero toma el dinero cada vez que le piden. **¿Qué hace?**

- ✔ Pone su ahorro en una cuenta aparte y deposita cada semana.
- Sigue guardando en su casa y presta a quien le pida.
- Deja de ahorrar porque de todos modos se le acaba el dinero.

**Caso 3. La tanda de Facebook de Mari.** A Mari le ofrecen una «tanda» en redes: pone 500 y recibe 4,000. **¿Qué hace?**

- ✔ No entra: es un fraude piramidal.
- Entra con poco para probar si de verdad le pagan lo prometido.
- Entra e invita a sus amigas para cobrar primero que ellas.

## M3 U03. Tu fondo para emergencias

**Caso 1. El pie de Doña Tere.** Doña Tere no pudo trabajar dos semanas y no tenía ahorro. **¿Qué hace para la próxima?**

- ✔ Junta un fondo de dos semanas en una cuenta aparte.
- Busca otra prestamista por si vuelve a pasar lo mismo.
- Sigue igual y espera no volver a lastimarse nunca más.

**Caso 2. La oferta de Chayo.** Chayo ve unos tenis en oferta y quiere usar su fondo. **¿Qué hace?**

- ✔ No lo usa: no es emergencia; ahorra aparte.
- Usa el fondo porque la oferta de los tenis se acaba hoy.
- Usa la mitad del fondo y promete reponerlo algún día.

**Caso 3. La urgencia de la nieta.** La nieta de Doña Tere necesita un medicamento urgente. **¿Qué hace?**

- ✔ Usa parte del fondo y se pone una meta para reponerlo.
- Pide prestado a una app para no tocar su fondo de emergencia.
- Usa todo el fondo y no se preocupa por volver a juntarlo.

## M3 U04. Ahorra para lo que viene: útiles, diciembre y metas

**Caso 1. Los útiles de Mari.** Mari se endeuda cada agosto para los útiles. **¿Qué hace?**

- ✔ Divide lo que necesita entre las semanas y aparta cada semana.
- Pide prestado en agosto como siempre y paga en septiembre.
- Espera a ver si le alcanza el aguinaldo de diciembre.

**Caso 2. El diciembre de Doña Tere.** Doña Tere gasta todo su aguinaldo y además pide prestado. **¿Qué hace?**

- ✔ Empieza a apartar en enero para diciembre.
- Sigue gastando el aguinaldo y pide prestado lo que falte.
- Deja de celebrar diciembre para no gastar nada ese mes.

**Caso 3. El ahorro bajo el colchón de Chayo.** Chayo guarda en su casa lo de la universidad de su hija para dentro de 8 años. **¿Qué hace?**

- ✔ Busca una opción regulada que pague rendimiento.
- Sigue guardando el dinero en su casa porque es lo más seguro.
- Lo invierte con un conocido que le promete duplicarlo en un año.

## M4 U01. ¿Cuánto das a tu familia?

**Caso 1. Las cuentas de Doña Tere.** Doña Tere da a todos y se quedó sin para sus pasajes. **¿Qué hace?**

- ✔ Suma lo que da y acuerda con su familia un monto fijo.
- Sigue dando a todos y deja de pagar sus propios pasajes.
- Deja de ayudar a todos de golpe para que aprendan.

**Caso 2. El hermano de Mari.** El hermano de Mari le pide dinero cada quincena «prestado» y nunca le paga. **¿Qué hace?**

- ✔ Lo cuenta como regalo y decide cuánto puede dar.
- Le sigue prestando cada quincena esperando que un día le pague.
- Le cobra con intereses todo lo que le ha prestado.

**Caso 3. El esposo de Chayo.** El esposo de Chayo ya no aporta al gasto porque «ella gana más». **¿Qué hace?**

- ✔ Platican con números qué paga cada quien.
- Paga todo ella sola para no pelear con su esposo.
- Deja de aportar ella también para que él se ponga las pilas.

## M4 U02. Prestar a la familia sin perder

**Caso 1. El abogado de Rosa.** Rosa le pide 5,000 a Doña Tere y ella no los tiene. **¿Qué hace?**

- ✔ No pide prestado; da lo que puede y la acompaña a buscar ayuda.
- Pide prestado a una prestamista para no dejar sola a su hija.
- Le dice que no y no la vuelve a ayudar con nada.

**Caso 2. La vecina de Chayo.** Una vecina le pide a Chayo 2,000 y Chayo sí los tiene. **¿Qué hace?**

- ✔ Presta solo si podría perderlo y acuerdan fechas por mensaje.
- Le presta sin fechas porque es su vecina de muchos años.
- Le presta lo de su fondo de emergencia sin pensarlo.

**Caso 3. El hijo de Mari.** El hijo de Mari no ha pagado los 1,500 que le prestó. **¿Qué hace?**

- ✔ Le recuerda la fecha con calma y no presta más hasta que pague.
- Le sigue prestando para que no se sienta mal.
- Le deja de hablar hasta que le pague todo lo que debe.

## M4 U03. Aval, obligado solidario y referencia: ¿qué firmas?

**Caso 1. La moto del yerno.** El yerno de Doña Tere le pide que sea su aval. **¿Qué hace?**

- ✔ Dice que no puede firmar una deuda que no podría pagar.
- Firma porque «nada más es aval» y confía en su yerno.
- Firma y le pide que le pague a ella los abonos cada semana.

**Caso 2. La llamada a Chayo.** Un despacho le exige a Chayo pagar la tarjeta de una conocida de la que solo es referencia. **¿Qué hace?**

- ✔ No paga y reporta al despacho en el REDECO.
- Paga para que dejen de llamarle a su casa y al trabajo.
- Paga la mitad para que el despacho la deje en paz un tiempo.

**Caso 3. La renta de Rosa.** Rosa le pide a Mari que firme como fiadora de su renta. **¿Qué hace?**

- ✔ Lee el contrato y solo firma si podría pagar toda la renta.
- Firma sin leer porque es su amiga y confía en ella.
- Firma y guarda el contrato sin revisar lo que dice.

## M4 U04. Decir que no sin culpa y hablar de dinero en casa

**Caso 1. La culpa de Mari.** Mari siente que es mala hija si dice que no. **¿Qué hace?**

- ✔ Reconoce la necesidad, pone su límite y ofrece otra ayuda.
- Dice que sí a todos para no sentirse mala hija y madre.
- Deja de contestar el teléfono a su familia para no sentir culpa.

**Caso 2. Las peleas de Chayo.** Chayo y su esposo pelean cada vez que se habla de dinero. **¿Qué hace?**

- ✔ Proponen una plática de 20 minutos al mes con números.
- Dejan de hablar de dinero para no pelear en la casa.
- Cada uno maneja su dinero sin decirle nada al otro.

**Caso 3. El insomnio de Doña Tere.** Doña Tere no duerme pensando en sus deudas. **¿Qué hace?**

- ✔ Hace su lista de deudas y pide apoyo, con la Línea de la Vida si hace falta.
- Pide otro préstamo para pagar las deudas y dormir tranquila.
- No le cuenta a nadie y espera a que se le pase.

## M4 U05. Tu dinero a tu nombre: autonomía y violencia económica

**Caso 1. El viernes de Chayo.** El esposo de Chayo le pide todo lo que cobra. **¿Qué hace?**

- ✔ Abre una cuenta a su nombre, guarda una parte y busca orientación.
- Le sigue dando todo porque así se hace en su familia.
- Deja de trabajar para que ya no haya problemas en casa.

**Caso 2. La credencial de Mari.** Un familiar le pide a Mari su INE «para un trámite». **¿Qué hace?**

- ✔ No la presta; ofrece acompañarle al trámite.
- La presta porque es su familia y confía en él.
- Le manda una foto de la INE por WhatsApp para ayudar.

**Caso 3. El crédito de Doña Tere.** Aparece un crédito a nombre de Doña Tere que ella no pidió. **¿Qué hace?**

- ✔ Revisa su reporte, reclama y denuncia el uso de su identidad.
- Paga el crédito para no tener problemas con el banco.
- Lo ignora porque ella no lo pidió y no es su problema.

## M5 U01. ¿Cuánto debes en total?

**Caso 1. Las deudas sueltas de Doña Tere.** Doña Tere paga a cuatro personas y no sabe el total. **¿Qué hace?**

- ✔ Escribe todas en una lista con montos y pagos.
- Sigue pagando un poco a cada una sin anotar nada.
- Deja de pagar la más chica para ver si se olvidan.

**Caso 2. La tanda de Chayo.** Chayo cobró primero en la tanda y no la cuenta como deuda. **¿Qué hace?**

- ✔ La anota en su lista con lo que le falta pagar.
- No la cuenta porque la tanda no cobra intereses.
- Deja de pagar la tanda porque ya cobró su parte.

**Caso 3. El 40% de Mari.** Mari paga 40% de lo que le entra en deudas y le ofrecen otra tarjeta. **¿Qué hace?**

- ✔ No toma deudas nuevas hasta bajar de 30%.
- Toma la tarjeta para pagar con ella las otras deudas.
- Toma la tarjeta y la guarda por si surge una emergencia.

## M5 U02. Lo que de verdad cuesta un préstamo

**Caso 1. La tienda de Chayo.** Chayo pagó 6,000 por un préstamo de 3,000. **¿Qué hace la próxima vez?**

- ✔ Calcula el total y compara el CAT antes de pedir.
- Pide donde le cobren el abono semanal más bajito.
- Pide en la misma tienda porque ya la conocen ahí.

**Caso 2. El anillo de Doña Tere.** Doña Tere empeñó su anillo y no sabe cuándo vence. **¿Qué hace?**

- ✔ Revisa su boleta y anota la fecha para pagar o refrendar.
- Espera a que la casa de empeño le avise por teléfono.
- Deja el anillo ahí y se olvida porque ya tiene el dinero.

**Caso 3. El anuncio de Mari.** A Mari le ofrecen «préstamo sin revisar Buró» por WhatsApp. **¿Qué hace?**

- ✔ Desconfía, pide el CAT y verifica el registro.
- Lo pide rápido porque no revisan Buró y lo necesita ya.
- Manda sus datos y su INE para ver cuánto le prestan.

## M5 U03. Prestamistas, «gota a gota» y apps que amenazan

**Caso 1. El cobrador de Doña Tere.** El cobrador del gota a gota llegó a la casa donde trabaja Doña Tere. **¿Qué hace?**

- ✔ Explica a la familia, paga con apoyo y denuncia.
- Pide otro gota a gota para pagar el primero hoy mismo.
- Deja de ir a esa casa para que el cobrador no la encuentre.

**Caso 2. La app de Chayo.** Chayo descargó una app que le pidió acceso a sus contactos. **¿Qué hace?**

- ✔ No pide el préstamo, quita permisos y desinstala la app.
- Pide poquito para probar si es confiable antes de pedir más.
- Acepta los permisos porque todas las apps los piden.

**Caso 3. Los mensajes a Mari.** Le escriben a Mari para que pague la deuda de su sobrino en una app. **¿Qué hace?**

- ✔ No paga nada y guarda las capturas para denunciar.
- Paga la deuda del sobrino para que dejen de molestarla.
- Bloquea el número y borra los mensajes sin guardar nada.

## M5 U04. Tu plan para salir de deudas

**Caso 1. Por dónde empieza Doña Tere.** Doña Tere tiene cuatro deudas y no sabe por cuál empezar. **¿Qué hace?**

- ✔ Paga lo mínimo en todas y pone el extra en la más cara.
- Paga un poquito a cada una sin ningún orden cada semana.
- Deja de pagar tres para terminar primero con una sola.

**Caso 2. El atraso de Chayo.** Chayo sabe que la próxima semana no le alcanza para el abono. **¿Qué hace?**

- ✔ Habla antes con la tienda y negocia un pago menor por escrito.
- No dice nada y espera a ver si no le cobran recargos.
- Pide prestado a una app para no atrasarse ni una semana.

**Caso 3. La oferta de Mari.** Mientras paga sus deudas, a Mari le ofrecen un celular en abonos. **¿Qué hace?**

- ✔ No toma deudas nuevas hasta terminar su plan.
- Lo toma porque el abono semanal es muy pequeño.
- Lo toma y lo paga con el dinero de sus otras deudas.

## M5 U05. Tu historial de crédito sin miedo

**Caso 1. El miedo de Mari.** Le dijeron a Mari que «está en Buró» y no quiere preguntar. **¿Qué hace?**

- ✔ Pide su reporte sin costo y revisa qué dice.
- No pregunta y deja de buscar créditos para siempre.
- Paga a alguien para que le diga qué hay en su reporte.

**Caso 2. La deuda pagada de Doña Tere.** Aparece como pendiente una deuda que Doña Tere ya pagó. **¿Qué hace?**

- ✔ La reclama con su comprobante de pago.
- La vuelve a pagar para que ya no aparezca en su reporte.
- No hace nada porque ya la pagó y eso es suficiente.

**Caso 3. El anuncio de Chayo.** A Chayo le ofrecen «limpiar su Buró» por 1,500. **¿Qué hace?**

- ✔ No paga: nadie puede borrar el historial.
- Paga porque así podrá sacar un crédito más fácil.
- Paga la mitad ahora y la otra mitad cuando la limpien.

## M6 U01. Cuando la casa te inscribe al IMSS

**Caso 1. La propuesta de Mari.** La señora le ofrece a Mari inscribirla, pero no sabe cómo. **¿Qué hace?**

- ✔ Revisan juntas la página del IMSS y la calculadora de cuotas.
- Le dice que no se preocupe, que así está bien sin IMSS.
- Le pide que mejor le dé el dinero de la cuota en efectivo.

**Caso 2. Las cuatro casas de Doña Tere.** Doña Tere cree que no puede tener IMSS porque trabaja en cuatro casas. **¿Qué hace?**

- ✔ Pregunta en cada casa si pueden inscribirla por sus días.
- Se queda sin IMSS porque cree que debe ser una sola casa.
- Paga a un gestor para que la inscriba en las cuatro casas.

**Caso 3. El NSS de Chayo.** Chayo no sabe su número de seguridad social. **¿Qué hace?**

- ✔ Lo consulta con su CURP en el sitio o la app del IMSS.
- Le pide a un gestor que se lo busque a cambio de dinero.
- Espera a que una casa lo averigüe por ella algún día.

## M6 U02. IMSS por tu cuenta: inscríbete tú y paga tu cuota

**Caso 1. La mamá de Chayo.** La mamá de Chayo tiene 62 años, no tiene seguridad social y necesita médico seguido. **¿Qué hace?**

- ✔ Revisa el seguro familiar del IMSS y aparta la cuota cada semana.
- Espera a que su mamá se ponga grave para ver qué hace.
- Pide un préstamo cada vez que su mamá necesita médico.

**Caso 2. La diabetes de Doña Tere.** Doña Tere tiene diabetes y quiere inscribirse para que le den su tratamiento. **¿Qué hace?**

- ✔ Pregunta antes si su enfermedad se cubre y desde cuándo.
- Paga la cuota sin preguntar porque da por hecho que la cubre.
- No se inscribe porque cree que el IMSS no atiende la diabetes.

**Caso 3. La pensión de Mari.** Mari cree que con el seguro de salud también suma semanas para su pensión. **¿Qué hace?**

- ✔ Sabe que solo da salud y busca que una casa la inscriba.
- Paga el seguro de salud creyendo que así suma sus semanas.
- Deja de ahorrar en su Afore porque ya tiene el seguro familiar.

## M6 U03. Sin seguridad social: IMSS-Bienestar y tu prevención

**Caso 1. La farmacia de Doña Tere.** Doña Tere se automedica en la farmacia cada vez que se enferma. **¿Qué hace?**

- ✔ Va a su centro de salud con su CURP y se hace un chequeo.
- Sigue comprando en la farmacia lo que le recomienden ahí.
- Espera a que se le pase solo para no perder un día de trabajo.

**Caso 2. La nieta de Chayo.** La nieta de Chayo no tiene seguridad social y se enfermó. **¿Qué hace?**

- ✔ La lleva al centro de salud con su CURP.
- Paga un médico privado con dinero prestado de una app.
- Le da medicina de la que le sobró a otra de sus nietas.

**Caso 3. El papanicolaou de Mari.** Mari nunca se ha hecho el papanicolaou porque no tiene IMSS. **¿Qué hace?**

- ✔ Pregunta en su centro de salud; no necesita IMSS.
- No se lo hace porque cree que sin IMSS no la atienden.
- Espera a tener IMSS algún día para hacerse la revisión.

## M6 U04. Cuida tu cuerpo, cuida tu ingreso

**Caso 1. El cloro de Chayo.** Chayo mezcla cloro con otro limpiador para que rinda. **¿Qué hace?**

- ✔ Usa un solo producto a la vez y ventila.
- Sigue mezclando porque así limpia más rápido y mejor.
- Mezcla, pero con la ventana abierta para que no huela.

**Caso 2. La ventana de Doña Tere.** Le piden a Doña Tere limpiar una ventana alta y solo hay una silla. **¿Qué hace?**

- ✔ No se sube a la silla y pide una escalera firme.
- Se sube a la silla con cuidado para no quedar mal.
- Pone la silla sobre una mesa para alcanzar la parte de arriba.

**Caso 3. La caída de Mari.** Mari se cayó en la casa donde trabaja y le duele la muñeca. **¿Qué hace?**

- ✔ Se atiende, avisa por mensaje y guarda las notas médicas.
- No dice nada para no causar problemas con la familia.
- Sigue trabajando con dolor para no perder el pago del día.

## M6 U05. Seguros chiquitos: vida y gastos funerarios

**Caso 1. El miedo de Doña Tere.** Doña Tere no quiere que su hija se endeude por su funeral. **¿Qué hace?**

- ✔ Compara planes, verifica en la PROFECO y nombra beneficiarias.
- Firma el primer plan que le ofrecen en la calle.
- Deja todo para después porque no le gusta pensar en eso.

**Caso 2. El vendedor de Chayo.** Un vendedor de puerta en puerta le ofrece a Chayo un plan funerario en efectivo sin recibo. **¿Qué hace?**

- ✔ No paga sin contrato ni recibo, y verifica la empresa.
- Paga en efectivo porque el vendedor se ve muy amable.
- Paga el primer mes para probar y pide el recibo después.

**Caso 3. La cuenta de Mari.** Mari no sabe si su cuenta tiene seguro de vida. **¿Qué hace?**

- ✔ Pregunta en el banco y revisa quién es su beneficiaria.
- Da por hecho que el dinero va a su hijo sin preguntar.
- Contrata otro seguro por si acaso sin revisar el que tiene.

## M7 U01. «Mamá, estoy en problemas»: llamadas y mensajes falsos

**Caso 1. El nieto de Doña Tere.** Le llaman a Doña Tere: su nieto está detenido y necesita 8,000. **¿Qué hace?**

- ✔ Cuelga, le llama a su nieto y reporta el número.
- Deposita rápido porque se oía a un joven llorando.
- Pide al licenciado más tiempo para juntar el dinero.

**Caso 2. El premio de Chayo.** A Chayo le llega un mensaje: ganó una pantalla y debe pagar 500 de envío. **¿Qué hace?**

- ✔ No paga: nadie cobra por darte un premio.
- Paga el envío porque la pantalla vale mucho más.
- Manda sus datos para ver si de verdad es cierto el premio.

**Caso 3. El código de Mari.** «Su banco» le pide a Mari el código que le llegó por mensaje. **¿Qué hace?**

- ✔ Cuelga y llama al número de su tarjeta.
- Da el código porque la llamada dice que es de su banco.
- Da solo la mitad del código para ver qué pasa.

## M7 U02. Falsos apoyos, falsos trabajos y cobros por trámites

**Caso 1. La beca de la hija de Chayo.** Le ofrecen a Chayo «apurar» el registro de la beca por 300. **¿Qué hace?**

- ✔ Registra a su hija en el sitio oficial sin pagar a nadie.
- Paga los 300 para que su hija no se quede sin beca.
- Paga la mitad ahora y la otra mitad cuando llegue la beca.

**Caso 2. La oferta de Canadá.** A Mari le piden 4,500 para la visa de un trabajo en Canadá. **¿Qué hace?**

- ✔ No deposita y verifica en el Servicio Nacional de Empleo.
- Deposita porque el sueldo en Canadá es muy bueno.
- Manda su INE y pasaporte para apartar el lugar.

**Caso 3. La pensión de Doña Tere.** Un señor le dice a Doña Tere que por 500 le «asegura» su pensión. **¿Qué hace?**

- ✔ No paga: la pensión se tramita sin costo.
- Paga para asegurarse de que no se la quiten.
- Le da su INE al señor para que haga el trámite por ella.

## M7 U03. Tu celular con candado

**Caso 1. La nieta de Chayo.** Chayo presta su celular sin contraseña y con el banco abierto. **¿Qué hace?**

- ✔ Pone NIP, cierra la app y activa alertas.
- Sigue prestándolo así porque confía en su nieta.
- Deja de usar la app del banco y guarda todo en efectivo.

**Caso 2. El WhatsApp de Doña Tere.** Le piden a Doña Tere «el código de seis números» que le llegó por WhatsApp. **¿Qué hace?**

- ✔ No lo da y activa la verificación en dos pasos.
- Lo da porque se lo pidió un contacto que conoce.
- Lo da y después cambia su foto de perfil por si acaso.

**Caso 3. El robo de Mari.** A Mari le roban el celular en el camión. **¿Qué hace?**

- ✔ Llama a su banco para bloquear y suspende su línea.
- Espera unos días a ver si alguien se lo regresa.
- Compra otro celular y deja la cuenta como estaba.

## M7 U04. Tus datos, tu identidad y los registros para que no te molesten

**Caso 1. La copia de Doña Tere.** Le cobran a Doña Tere un celular que nunca compró. **¿Qué hace?**

- ✔ Revisa su reporte, reclama y denuncia el robo de identidad.
- Paga el celular para no quedar mal en el buró.
- Lo ignora porque ella no lo compró y ya se les pasará.

**Caso 2. Las llamadas de Mari.** A Mari la llaman todo el día bancos y tiendas. **¿Qué hace?**

- ✔ Registra su número en el REUS y el REPEP.
- Cambia de número cada vez que la llaman mucho.
- Contesta y les pide amablemente que ya no le llamen.

**Caso 3. La foto de la INE de Chayo.** Un «reclutador» le pide a Chayo foto de su INE por WhatsApp antes de conocerla. **¿Qué hace?**

- ✔ No la manda; la entrega solo en persona y con leyenda.
- La manda porque así la contratan más rápido.
- Manda una foto borrosa para cuidar un poco sus datos.

## M8 U01. Tus pensiones del Bienestar

**Caso 1. El plan de Doña Tere.** Doña Tere cree que la pensión le alcanzará para todo. **¿Qué hace?**

- ✔ Saca cuentas y ahorra además para completar.
- Deja de ahorrar porque la pensión le alcanzará para todo.
- Pide prestado ahora y piensa pagarlo con la pensión.

**Caso 2. La mamá de Chayo.** La mamá de Chayo tiene 63 años y no se ha registrado. **¿Qué hace?**

- ✔ La registra con sus documentos, sin pagar a nadie.
- Espera a que cumpla 65 para registrarla en la otra.
- Paga a un gestor para que la registre más rápido.

**Caso 3. El gestor de Mari.** A Mari le ofrecen «adelantar» la pensión de su mamá por 800. **¿Qué hace?**

- ✔ No paga: el registro no tiene costo.
- Paga los 800 para que su mamá cobre antes que otras.
- Le da la tarjeta de su mamá al señor para el trámite.

## M8 U02. Tu Afore: encuéntrala y ahórrale desde 50 pesos

**Caso 1. La Afore olvidada de Mari.** Mari no sabe si tiene Afore de cuando trabajó en la fábrica. **¿Qué hace?**

- ✔ La busca con su CURP en AforeMóvil.
- Da por perdido ese dinero porque ya no trabaja ahí.
- Paga a un gestor para que le diga dónde está su Afore.

**Caso 2. El ahorro de Chayo.** Chayo nunca ha tenido Afore y cobra por día. **¿Qué hace?**

- ✔ Abre su Afore en la app y deposita cada semana.
- No abre Afore porque cree que es solo para quien tiene patrón.
- Espera a tener un trabajo con IMSS para empezar a ahorrar.

**Caso 3. Los beneficiarios de Doña Tere.** Doña Tere tiene Afore pero nunca nombró beneficiarias. **¿Qué hace?**

- ✔ Las registra en su Afore con nombres completos.
- Lo deja así porque cree que su familia recibirá todo sola.
- Le dice de palabra a su hija que el dinero es para ella.

## M8 U03. Las becas de tus hijas y nietas, sin coyotes

**Caso 1. La vecina de Doña Tere.** Una vecina dice que la beca «solo sale si conoces a alguien». **¿Qué hace?**

- ✔ Registra a su nieta en el sitio oficial sin pagar a nadie.
- Paga a la vecina para que la ayude a conseguir la beca.
- No la registra porque cree que no conoce a nadie.

**Caso 2. La beca que se va.** La beca del hijo de Mari se gasta en lo que sea. **¿Qué hace?**

- ✔ Acuerdan que primero va a la escuela y lo que sobre se ahorra.
- La siguen gastando en lo que haga falta en la casa.
- Mari se queda con la beca para pagar sus propias deudas.

**Caso 3. La tarjeta de la nieta de Chayo.** Un familiar le pide la tarjeta de la beca a la nieta de Chayo. **¿Qué hace?**

- ✔ No la presta y cuida su NIP.
- La presta porque es de la familia y luego la regresa.
- La presta y le da el NIP para que no se equivoque.

## M8 U04. Sin juicio: beneficiarias en todo lo que tienes

**Caso 1. La cuenta de la hermana de Chayo.** La cuenta de la hermana de Chayo quedó atorada por no tener beneficiaria. **¿Qué hace Chayo con la suya?**

- ✔ Nombra a sus hijas en su cuenta, Afore y seguro.
- Lo deja así porque sus hijas sabrán qué hacer después.
- Pone todo a nombre de su hija mayor desde ahora.

**Caso 2. La nieta de Doña Tere.** Doña Tere quiere dejar su cuenta a su nieta de 9 años. **¿Qué hace?**

- ✔ Pregunta cómo se le entregaría y prevé una tutora en su testamento.
- La pone de beneficiaria sin preguntar nada más.
- Le da el dinero ahora a la niña para que lo guarde.

**Caso 3. El contrato de Mari.** Mari tiene contrato de planta. **¿Qué hace?**

- ✔ Pide que el contrato diga quién recibe sus pagos pendientes.
- No lo pide porque le da pena hablar de eso con la señora.
- Le dice de palabra a la señora a quién darle su dinero.

## M8 U05. Tu casa, tu tierra y tu testamento

**Caso 1. La casa de la suegra.** Doña Tere vive en una casa que nunca se escrituró. **¿Qué hace?**

- ✔ Pide orientación para regularizarla antes de heredarla.
- La deja así porque ha vivido ahí 30 años y es suya.
- Hace un testamento para heredar la casa sin papeles.

**Caso 2. La parcela del papá de Chayo.** Chayo no sabe quién heredará la parcela ejidal de su papá. **¿Qué hace?**

- ✔ Revisa en el Registro Agrario Nacional si hay lista de sucesión.
- Da por hecho que la parcela es para el hijo mayor.
- Vende la parcela antes de que haya problemas en la familia.

**Caso 3. La pareja de Mari.** Mari vive en unión libre hace 12 años y su casa está a su nombre. **¿Qué hace?**

- ✔ Hace su testamento para dejar claro quién hereda.
- Lo deja así porque su pareja heredará todo solo.
- Pone la casa a nombre de su pareja desde ahora.

## M8 U06. Heredar sin sustos: deudas, impuestos y la plática en familia

**Caso 1. El despacho de Mari.** Un despacho le dice a Mari que pague las deudas de su papá. **¿Qué hace?**

- ✔ Revisa si firmó como aval; si no, no paga con su dinero.
- Paga las deudas de su papá para que ya no la busquen.
- Paga la mitad para que el despacho la deje en paz.

**Caso 2. El hermano de Mari.** El hermano de Mari cree que heredar la casa paga 30% de ISR. **¿Qué hace?**

- ✔ Pregunta en una notaría: solo paga los gastos de escriturar.
- No escritura porque cree que hay que pagar 30% de ISR.
- Vende la casa sin escriturar para no pagar impuestos.

**Caso 3. La plática de Doña Tere.** Doña Tere nunca ha hablado con su familia de su carpeta y su testamento. **¿Qué hace?**

- ✔ Hace una plática en familia y les dice dónde está todo.
- No dice nada para no atraer la mala suerte a la casa.
- Le deja una nota escondida para que la encuentren después.

## M9 U01. De sobrevivir a crecer: lo que ya sabes vale

**Caso 1. «Nomás sé limpiar».** Chayo cree que solo sabe limpiar. **¿Qué hace?**

- ✔ Hace su lista de habilidades y busca qué le valoran.
- Sigue creyendo que nomás sabe limpiar y no cambia nada.
- Deja sus casas para poner un restaurante de un día para otro.

**Caso 2. La abuelita de la casa de Mari.** En la casa donde trabaja Mari le piden cuidar a la abuelita sin pagarle más. **¿Qué hace?**

- ✔ Lo platica y propone cobrar el cuidado aparte.
- Cuida a la abuelita sin decir nada para no perder la casa.
- Deja de ir a esa casa sin explicar por qué se va.

**Caso 3. El curso de Doña Tere.** Doña Tere cree que ya está grande para aprender. **¿Qué hace?**

- ✔ Busca un curso corto en su municipio para cobrar más.
- Se queda igual porque cree que ya está grande para aprender.
- Paga un curso caro en línea que le promete hacerla rica.

## M9 U02. Ofrece servicios extra y consigue clientas

**Caso 1. El precio de Chayo.** Chayo no sabe cuánto cobrar por limpieza profunda. **¿Qué hace?**

- ✔ Calcula productos, pasajes y horas, y fija un precio con ganancia.
- Cobra lo mismo que un día normal para no espantar clientas.
- Cobra lo que le quieran dar la primera vez para darse a conocer.

**Caso 2. Las clientas de Mari.** Mari quiere ofrecer cocina los sábados y no conoce a nadie. **¿Qué hace?**

- ✔ Pide a sus casas que la recomienden y comparte su servicio.
- Espera a que las clientas lleguen solas con el tiempo.
- Cocina sin cobrar tres sábados para que la conozcan.

**Caso 3. El cansancio de Doña Tere.** Doña Tere aceptó trabajo los siete días y se enfermó. **¿Qué hace?**

- ✔ Deja un día de descanso a la semana.
- Sigue trabajando los siete días para juntar más dinero.
- Toma pastillas para aguantar el cansancio de la semana.

## M9 U03. Apps y agencias de limpieza: ¿cuánto te queda?

**Caso 1. La oferta de Mari.** A Mari le ofrecen una app «con clientas todos los días». **¿Qué hace?**

- ✔ Pregunta la comisión y calcula cuánto le queda por hora.
- Se registra rápido porque le llegarán clientas diario.
- Se registra y acepta todos los trabajos que le manden.

**Caso 2. La agencia de Chayo.** Una agencia le pide a Chayo 800 para «darla de alta». **¿Qué hace?**

- ✔ No paga: cobrar por inscribirte es señal de engaño.
- Paga los 800 porque así asegura su trabajo con la agencia.
- Paga la mitad ahora y la otra mitad con su primer pago.

**Caso 3. La clienta de Doña Tere.** A una clienta de la app le gustó el trabajo de Doña Tere. **¿Qué hace?**

- ✔ Revisa las reglas de la app antes de acordar algo directo.
- Le da su número a la clienta sin revisar nada de la app.
- Deja la app de golpe y se queda solo con esa clienta.

## M9 U04. Tu plan de una página y tu compromiso

**Caso 1. Los papelitos de Doña Tere.** Doña Tere tiene todo en papelitos sueltos. **¿Qué hace?**

- ✔ Llena su plan de una página y le toma una foto.
- Sigue con sus papelitos porque así ya se acostumbró.
- Guarda todo en una caja y lo revisa una vez al año.

**Caso 2. El plan olvidado de Chayo.** Chayo hizo su plan pero nunca lo vuelve a ver. **¿Qué hace?**

- ✔ Lo revisa cinco minutos cada semana.
- Lo guarda en un cajón porque ya lo hizo una vez.
- Lo rehace completo cada vez que se acuerda de él.

**Caso 3. El NIP de Mari.** Mari quiere anotar su NIP en su plan para no olvidarlo. **¿Qué hace?**

- ✔ No lo anota: el plan no lleva datos sensibles.
- Lo anota en la última línea para tenerlo a la mano.
- Lo anota al revés para que nadie lo entienda.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** Cobras 600 por día y trabajas 15 días. ¿Cuánto te entra en el mes?

- ✔ 9,000
- 6,000
- 15,600

*¡Correcto! 600 por 15.*

**M1 U01 P2.** Trabajas de planta y cobras 2,500 por semana. ¿Cuánto te entra al mes, más o menos?

- 5,000
- ✔ 10,750
- 2,500

*¡Correcto! 2,500 por 4.3 semanas.*

**M1 U01 P3.** ¿Con qué mes conviene hacer el presupuesto?

- Con diciembre, que llega el aguinaldo
- Con el mejor mes del año
- ✔ Con un mes flojo

*¡Correcto! Así te alcanza siempre.*

**M1 U02 P1.** Pagas 2,580 de renta al mes. ¿Cuánto apartas cada semana, más o menos?

- 2,580
- ✔ 600
- 1,290

*¡Correcto! 2,580 entre 4.3 semanas.*

**M1 U02 P2.** ¿Qué sobre llenas primero cuando cobras?

- El de pasajes y comida
- El de gustos
- ✔ El de ahorro

*¡Correcto! El ahorro va primero.*

**M1 U02 P3.** ¿Dónde es mejor guardar los sobres?

- ✔ En tu casa
- En la bolsa del trabajo
- Con una vecina

*¡Correcto! Si los cargas, se gastan.*

**M1 U03 P1.** Gastas 25 en refresco cada día y trabajas 20 días. ¿Cuánto al mes?

- 25
- 250
- ✔ 500

*¡Correcto! 25 por 20.*

**M1 U03 P2.** ¿Qué gasto del trabajo puedes acordar con la familia?

- ✔ Los pasajes
- Tus recargas de la semana
- Tus antojos

*¡Correcto! Muchas familias los pagan.*

**M1 U03 P3.** ¿Por qué suman tanto los gastos chiquitos?

- Porque son muy caros
- ✔ Porque se repiten cada día
- Porque tienen intereses

*¡Correcto! Se repiten.*

**M1 U04 P1.** Apartas 30 cada día y trabajas 20 días al mes. ¿Cuánto ahorras en un año?

- ✔ 7,200
- 600
- 3,600

*¡Correcto! 30 por 20 por 12.*

**M1 U04 P2.** ¿Qué es apartar primero?

- Ahorrar lo que te sobra al terminar el fin de semana
- Ahorrar solo en diciembre
- ✔ Ahorrar el día que cobras, antes de gastar

*¡Correcto! Primero tú.*

**M1 U04 P3.** ¿Dónde es más fácil que el ahorro no se gaste?

- En la bolsa del trabajo
- ✔ En una cuenta aparte
- Prestado a un familiar

*¡Correcto! No lo ves diario.*

**M1 U05 P1.** Un celular cuesta 99 a la semana por 78 semanas. ¿Cuánto pagas en total?

- 99
- ✔ 7,722
- 3,900

*¡Correcto! 99 por 78.*

**M1 U05 P2.** ¿Qué haces ante una oferta «solo hoy»?

- ✔ Esperar un día y comparar
- Comprar antes de que se acabe
- Pedir prestado para aprovecharla

*¡Correcto! La presión es para que no compares.*

**M1 U05 P3.** Aceite de 1 litro a 42 o de 3 litros a 135. ¿Cuál es más barato por litro?

- Los dos cuestan igual
- El de 3 litros
- ✔ El de 1 litro

*¡Correcto! 42 contra 45 por litro.*

## Módulo 2

**M2 U01 P1.** ¿Cuántos días de aguinaldo te tocan como mínimo si trabajas todo el año?

- 30
- 5
- ✔ 15

*¡Correcto! Artículo 87 de la ley.*

**M2 U01 P2.** ¿Tus derechos aplican si trabajas de entrada por salida?

- ✔ Sí, en proporción a los días
- No, solo de planta
- Solo si tienes contrato firmado

*¡Correcto! Cada casa paga su parte.*

**M2 U01 P3.** ¿Cuántos días de vacaciones pagadas te tocan al cumplir un año?

- 6
- ✔ 12
- Ninguno

*¡Correcto! Desde 2023 son 12.*

**M2 U02 P1.** Cobras 480 y gastas 90 en pasajes. ¿Cuánto te queda?

- 570
- ✔ 390
- 480

*¡Correcto! 480 menos 90.*

**M2 U02 P2.** ¿Qué haces si te piden una tarea extra?

- La haces sin decir nada a nadie
- La dejas sin avisar
- ✔ Propones cobrarla aparte

*¡Correcto! Es más trabajo.*

**M2 U02 P3.** ¿Cuándo conviene pedir ajuste de tu tarifa?

- ✔ En enero, con números
- El día que estás molesta
- Nunca, para no perder la casa

*¡Correcto! Cuando sube el salario mínimo.*

**M2 U03 P1.** ¿Qué te sirve de prueba de lo que acordaste?

- ✔ Un mensaje con el acuerdo
- Tu palabra
- Lo que recuerdan tus vecinas

*¡Correcto! Queda escrito.*

**M2 U03 P2.** ¿Qué incluye tu finiquito?

- Solo el último día que trabajaste en la casa
- Nada, si fue de palabra
- ✔ Días pendientes, aguinaldo y vacaciones

*¡Correcto! Todo lo pendiente.*

**M2 U03 P3.** Te piden firmar que no te deben nada. ¿Qué haces?

- Firmas para salir rápido
- ✔ Pides orientación antes de firmar
- Rompes el papel y te vas sin decir nada

*¡Correcto! No firmes sin revisar.*

**M2 U04 P1.** ¿Qué necesitas dar para que te transfieran?

- Tu NIP
- ✔ Tu CLABE
- El código que te llega

*¡Correcto! Solo eso para recibir.*

**M2 U04 P2.** ¿Cuánto cobra de manejo la cuenta básica?

- 120 al mes
- Depende de tu saldo
- ✔ Nada

*¡Correcto! Es sin comisión por manejo.*

**M2 U04 P3.** ¿A dónde acudes si tu banco no resuelve tu reclamo?

- ✔ A la CONDUSEF
- A la tienda de la esquina
- A la policía de tránsito

*¡Correcto! Protege a usuarios.*

## Módulo 3

**M3 U01 P1.** Tanda de 8 personas con 250 cada semana. ¿Cuánto cobra cada una?

- 250
- 2,500
- ✔ 2,000

*¡Correcto! 250 por 8.*

**M3 U01 P2.** Cobraste primero. ¿Qué tienes?

- ✔ Una deuda con el grupo
- Una ganancia
- Un ahorro protegido por el banco

*¡Correcto! Debes los pagos.*

**M3 U01 P3.** ¿Cuál es el mayor riesgo de una tanda?

- Los intereses que te cobra
- Que el banco la cancele
- ✔ Que alguien deje de pagar

*¡Correcto! Pierden las demás.*

**M3 U02 P1.** Te ofrecen «pon 500 y recibe 4,000» en redes. ¿Qué es?

- Un ahorro con buenos intereses
- ✔ Un fraude piramidal
- Una tanda de verdad

*¡Correcto! Nadie multiplica así.*

**M3 U02 P2.** ¿Qué regla baja el riesgo de una tanda?

- Un grupo grande con gente de otras colonias
- Todo de palabra
- ✔ Reglas escritas y registro

*¡Correcto! Queda claro y comprobable.*

**M3 U02 P3.** ¿Qué protege tu ahorro en una cuenta de banco?

- ✔ El seguro de depósitos (IPAB)
- La señora que organiza la tanda del barrio
- Nadie

*¡Correcto! Protege tus depósitos.*

**M3 U03 P1.** Tus gastos básicos son 2,000 a la semana. ¿Cuál es tu primera meta de fondo?

- 2,000
- 20,000
- ✔ 4,000

*¡Correcto! Dos semanas.*

**M3 U03 P2.** ¿Para qué es el fondo de emergencia?

- ✔ Para días sin trabajo o enfermedad
- Para ofertas
- Para la cena y los regalos de fin de año

*¡Correcto! Imprevistos.*

**M3 U03 P3.** ¿Qué haces con el aguinaldo si no tienes fondo?

- Lo gastas todo en regalos para la familia
- ✔ Guardas una parte para el fondo
- Lo prestas completo

*¡Correcto! Una parte al fondo.*

**M3 U04 P1.** Necesitas 3,000 en 30 semanas. ¿Cuánto apartas por semana?

- 300
- ✔ 100
- 30

*¡Correcto! 3,000 entre 30.*

**M3 U04 P2.** ¿Los útiles de agosto son una emergencia?

- Sí, porque siempre llegan de sorpresa cada año
- Depende del año
- ✔ No, es un gasto que sabes que viene

*¡Correcto! Sabes la fecha.*

**M3 U04 P3.** Con inflación, ¿qué pasa con el dinero guardado en casa por años?

- ✔ Pierde valor
- Gana valor
- Se queda igual

*¡Correcto! Los precios suben.*

## Módulo 4

**M4 U01 P1.** Das 600 a tu hija y 400 a tu mamá cada quincena. ¿Cuánto das al mes?

- 1,000
- ✔ 2,000
- 600

*¡Correcto! 1,000 por dos quincenas.*

**M4 U01 P2.** ¿Qué haces con lo que prestas y nunca te pagan?

- Lo cobras con intereses
- ✔ Lo cuentas como regalo
- Lo olvidas y sigues prestando

*¡Correcto! Así no te engañas.*

**M4 U01 P3.** ¿De dónde sale un apoyo urgente de salud?

- De tus pasajes de la semana
- De un préstamo en app
- ✔ De tu fondo de emergencia

*¡Correcto! Para eso es.*

**M4 U02 P1.** Pides 3,000 al 15% mensual para prestarle a tu hijo. ¿Cuánto pagas de interés al mes?

- 150
- ✔ 450
- 3,450

*¡Correcto! 15% de 3,000.*

**M4 U02 P2.** ¿Cuál es la regla más importante al prestar?

- ✔ Nunca pedir prestado para prestar
- Prestar a quien te lo pida primero en la familia
- Prestar siempre sin fecha

*¡Correcto! La deuda sería tuya.*

**M4 U02 P3.** ¿Qué te sirve de acuerdo por escrito?

- Tu memoria
- La palabra de tu hijo frente a la familia
- ✔ Un mensaje con monto y fechas

*¡Correcto! Queda registro.*

**M4 U03 P1.** ¿Quién NO puede ser cobrado por un despacho?

- El aval
- ✔ La referencia personal
- El obligado solidario

*¡Correcto! Solo dio sus datos.*

**M4 U03 P2.** Firmaste como aval de 20,000 y no pagan. ¿Cuánto te pueden cobrar?

- ✔ Todo lo que se debe
- Nada
- Solo los intereses del último mes

*¡Correcto! El aval responde por todo.*

**M4 U03 P3.** ¿Dónde reportas a un despacho que te cobra como referencia?

- En la tienda donde se hizo la compra
- ✔ En el REDECO de la CONDUSEF
- En la escuela de tus nietas

*¡Correcto! Registro de despachos.*

**M4 U04 P1.** ¿Cuál es una señal de estrés por dinero?

- ✔ Dormir mal por las deudas
- Anotar tus gastos cada día
- Ahorrar el día que cobras

*¡Correcto! Es una señal.*

**M4 U04 P2.** ¿Qué parte falta en este «no»: «Entiendo que lo necesitas, pero no puedo»?

- El enojo
- Una explicación larga
- ✔ Ofrecer otra ayuda

*¡Correcto! Cierra con otra ayuda.*

**M4 U04 P3.** ¿A qué número llamas si el estrés no te deja vivir?

- ✔ Al 800 911 2000
- A la prestamista
- Al banco

*¡Correcto! Línea de la Vida.*

**M4 U05 P1.** ¿Cuál es violencia económica?

- Hacer juntos el presupuesto
- ✔ Que te quiten lo que ganas
- Ahorrar para una meta

*¡Correcto! Es control.*

**M4 U05 P2.** ¿Qué haces si te piden tu INE para un trámite?

- La prestas porque le tienes confianza
- Le mandas una foto
- ✔ No la prestas y acompañas

*¡Correcto! Pueden usarla para créditos.*

**M4 U05 P3.** ¿Qué tienes a tu nombre para tu autonomía?

- ✔ Cuenta, documentos y un fondo
- Nada, porque todo lo guarda tu pareja
- Solo el celular

*¡Correcto! Es tu derecho.*

## Módulo 5

**M5 U01 P1.** Debes 4,000, 2,500 y 1,500. ¿Cuánto debes en total?

- 6,500
- ✔ 8,000
- 4,000

*¡Correcto! Suma de las tres.*

**M5 U01 P2.** Te entran 2,500 a la semana y pagas 1,000 de deudas. ¿Qué porcentaje es?

- ✔ 40%
- 25%
- 10%

*¡Correcto! 1,000 entre 2,500.*

**M5 U01 P3.** ¿Cuál es deuda?

- Tu ahorro guardado en la cuenta del banco
- ✔ Lo que te falta pagar en la tanda
- Tu fondo de emergencia

*¡Correcto! Debes esos pagos.*

**M5 U02 P1.** Te prestan 2,000 y pagas 120 por semana durante 25 semanas. ¿Cuánto pagas de más?

- 3,000
- 120
- ✔ 1,000

*¡Correcto! 3,000 menos 2,000.*

**M5 U02 P2.** ¿Qué te dice el CAT?

- El pago semanal
- ✔ El costo anual con intereses y comisiones
- Cuánto te prestan y en cuántas semanas pagas

*¡Correcto! Sirve para comparar.*

**M5 U02 P3.** ¿Qué pasa si no pagas un empeño a tiempo?

- ✔ Pierdes la prenda
- Te regalan el préstamo
- Nada, te esperan siempre

*¡Correcto! Se queda con la prenda.*

**M5 U03 P1.** Te prestan 1,000 y pagas 60 diarios por 20 días. ¿Cuánto pagas de más?

- 60
- 1,200
- ✔ 200

*¡Correcto! 1,200 menos 1,000.*

**M5 U03 P2.** ¿Qué haces si una app te amenaza?

- Pides otro préstamo para pagar
- ✔ Guardas capturas y denuncias
- Borras todo sin guardar nada

*¡Correcto! Sirven de prueba.*

**M5 U03 P3.** ¿Dónde denuncias las amenazas?

- ✔ En el 088
- En la tienda de la esquina
- En la misma app

*¡Correcto! Guardia Nacional.*

**M5 U04 P1.** En la bola de nieve, ¿cuál pagas primero?

- La más grande
- ✔ La más chica
- La más reciente

*¡Correcto! Ves avances rápido.*

**M5 U04 P2.** ¿Qué haces si sabes que te vas a atrasar?

- ✔ Hablas antes y negocias
- Cambias de número para que no te encuentren
- Pides otro préstamo

*¡Correcto! Evitas recargos.*

**M5 U04 P3.** Terminas una deuda donde pagabas 300. ¿Qué haces con esos 300?

- Los gastas en gustos
- Los guardas para gastarlos solo en diciembre
- ✔ Los pasas a la siguiente deuda

*¡Correcto! Así aceleras.*

**M5 U05 P1.** ¿Qué es el Buró de Crédito?

- ✔ Tu historial de pagos
- Una lista negra de morosos
- Un banco que presta

*¡Correcto! Lo bueno y lo malo.*

**M5 U05 P2.** ¿Cuántas veces al año puedes pedir tu reporte sin costo?

- Ninguna, siempre cuesta
- Doce
- ✔ Una

*¡Correcto! Una vez al año.*

**M5 U05 P3.** Te ofrecen «limpiar tu Buró» por 1,500. ¿Qué es?

- Un servicio oficial
- ✔ Un fraude
- Un trámite del banco

*¡Correcto! Nadie lo borra pagando.*

## Módulo 6

**M6 U01 P1.** ¿Qué te da el IMSS si la casa te inscribe?

- Solo medicinas
- ✔ Médico, incapacidades, guardería y pensión
- Un préstamo con descuento para tu familia y tu casa

*¡Correcto! Son los seguros del régimen.*

**M6 U01 P2.** Trabajas en tres casas. ¿Quién puede inscribirte?

- Nadie
- Solo la casa donde más días trabajas
- ✔ Cada casa, por tus días con ella

*¡Correcto! Cada una paga su parte.*

**M6 U01 P3.** ¿Con qué consultas tu número de seguridad social?

- ✔ Con tu CURP
- Con tu recibo de luz
- Con tu acta de matrimonio

*¡Correcto! En el sitio o la app del IMSS.*

**M6 U02 P1.** ¿Cuánto cuesta al año el Seguro de Salud para la Familia para una persona de 45 años en 2026?

- 9,300
- ✔ 13,800
- 21,300

*¡Correcto! De 40 a 49 años.*

**M6 U02 P2.** ¿Qué NO da el Seguro de Salud para la Familia?

- Hospital
- Consultas
- ✔ Pensión

*¡Correcto! Solo es salud.*

**M6 U02 P3.** La cuota anual es de 11,550. ¿Cuánto apartas por semana, más o menos?

- ✔ 222
- 1,155
- 50

*¡Correcto! 11,550 entre 52.*

**M6 U03 P1.** ¿Cuánto cuesta atenderte en el centro de salud si no tienes seguridad social?

- Lo mismo que un médico privado
- Una cuota al año
- ✔ No tiene costo

*¡Correcto! Para personas sin seguridad social.*

**M6 U03 P2.** ¿Qué llevas para registrarte?

- ✔ Tu CURP e identificación
- Tu recibo de nómina de la casa
- Tu tarjeta del banco

*¡Correcto! Te registran con ellas.*

**M6 U03 P3.** ¿Por qué prevenir cuida tu dinero?

- Porque te regalan medicinas
- ✔ Porque evitas perder días de trabajo
- Porque en el centro de salud te pagan por ir a consulta

*¡Correcto! Cobras por día.*

**M6 U04 P1.** ¿Qué pasa si mezclas cloro con amoniaco?

- Limpia mejor
- ✔ Suelta gases tóxicos
- Nada

*¡Correcto! Es peligroso.*

**M6 U04 P2.** Solo hay una silla para limpiar una ventana alta. ¿Qué haces?

- ✔ Pides una escalera firme
- Te subes con cuidado
- Pones la silla sobre la mesa

*¡Correcto! Evita caídas.*

**M6 U04 P3.** Te accidentas en una casa. ¿Qué guardas?

- Nada, ya pasó
- Solo la foto del lugar donde te caíste y del piso mojado
- ✔ Recetas, notas médicas y el mensaje de aviso

*¡Correcto! Son tus pruebas.*

**M6 U05 P1.** ¿Qué institución vigila los planes de previsión funeraria?

- El Banco de México
- ✔ La PROFECO
- El IMSS

*¡Correcto! Registro de planes funerarios.*

**M6 U05 P2.** ¿Qué pones al nombrar beneficiarias?

- Solo el apodo con el que la conoce toda la familia
- Solo el parentesco
- ✔ Nombre completo y parte de cada una

*¡Correcto! Así no hay dudas.*

**M6 U05 P3.** Pagas 150 al mes por un plan. ¿Cuánto pagas al año?

- ✔ 1,800
- 150
- 15,000

*¡Correcto! 150 por 12.*

## Módulo 7

**M7 U01 P1.** ¿Qué es lo primero que haces ante una llamada que pide dinero urgente?

- Depositas rápido para ayudar a tu familiar
- Pides más datos
- ✔ Cuelgas y verificas

*¡Correcto! La regla de oro.*

**M7 U01 P2.** ¿Tu banco te pide códigos por teléfono?

- ✔ No, nunca
- Solo si es urgente
- Sí, para cancelar cargos

*¡Correcto! Nunca los pide.*

**M7 U01 P3.** ¿Para qué sirve una palabra clave familiar?

- Para abrir la cuenta
- ✔ Para saber si de verdad es tu familiar
- Para cobrar premios y promociones que te lleguen por teléfono

*¡Correcto! Los engañadores no la saben.*

**M7 U02 P1.** ¿Cuánto cuesta registrarte a una pensión del Bienestar?

- 500
- ✔ No tiene costo
- Lo que pida el gestor

*¡Correcto! Los registros no se cobran.*

**M7 U02 P2.** Te ofrecen trabajo en otro país si depositas 4,000. ¿Qué es?

- ✔ Una señal de engaño
- Un trámite normal
- Una buena oportunidad

*¡Correcto! Nadie serio pide depósito.*

**M7 U02 P3.** ¿En qué terminan los sitios oficiales del gobierno?

- .com
- .net
- ✔ gob.mx

*¡Correcto! Así los reconoces.*

**M7 U03 P1.** ¿Qué candado evita que te roben tu WhatsApp?

- ✔ Verificación en dos pasos
- Fondo de pantalla
- Más memoria y una funda más resistente

*¡Correcto! Pide un NIP extra.*

**M7 U03 P2.** Te roban el celular. ¿Qué haces primero?

- Compras otro
- Esperas a que alguien lo encuentre y te lo regrese
- ✔ Llamas al banco y bloqueas

*¡Correcto! Evitas cargos.*

**M7 U03 P3.** ¿Para qué sirven las alertas del banco?

- Para ganar puntos y premios en cada compra del mes
- ✔ Para enterarte de cada movimiento
- Para pagar menos comisiones

*¡Correcto! Te enteras al momento.*

**M7 U04 P1.** ¿Qué registro evita llamadas de bancos con publicidad?

- ✔ El REUS
- El RFC
- El SIPRES

*¡Correcto! De la CONDUSEF.*

**M7 U04 P2.** ¿Qué escribes en la copia de tu INE?

- Tu firma y tu número de celular completo
- Tu número de cuenta
- ✔ Para qué trámite es y la fecha

*¡Correcto! Así no la reúsan.*

**M7 U04 P3.** ¿Cuánto cuesta registrarte en el REPEP?

- 200 al año
- ✔ No tiene costo
- Lo que cobre el gestor

*¡Correcto! Es sin costo.*

## Módulo 8

**M8 U01 P1.** ¿Cuánto da al año la Pensión Mujeres Bienestar en 2026?

- ✔ 18,600
- 3,100
- 38,400

*¡Correcto! 3,100 por 6 bimestres.*

**M8 U01 P2.** ¿A partir de qué edad es la Pensión de Adultos Mayores?

- 60
- 55
- ✔ 65

*¡Correcto! De 65 en adelante.*

**M8 U01 P3.** ¿Cuánto cuesta registrarte?

- ✔ No tiene costo
- 800 con gestor
- Un mes de pensión

*¡Correcto! El registro es sin costo.*

**M8 U02 P1.** ¿Desde cuánto puedes ahorrar en tu Afore en una tienda?

- 1,000
- ✔ 50
- 500

*¡Correcto! Desde 50 pesos.*

**M8 U02 P2.** ¿Qué necesitas para depositar en la tienda?

- ✔ Tu CURP
- Tu contrato de trabajo
- Tu recibo de luz

*¡Correcto! Con ella te identifican.*

**M8 U02 P3.** Ahorras 100 cada semana. ¿Cuánto juntas en un año, sin rendimientos?

- 1,200
- 100
- ✔ 5,200

*¡Correcto! 100 por 52.*

**M8 U03 P1.** ¿Para quién es la Beca Benito Juárez?

- ✔ Estudiantes de preparatoria pública
- Solo quien tenga promedio de 10 en la secundaria
- Estudiantes de escuela privada

*¡Correcto! Es universal en prepa pública.*

**M8 U03 P2.** ¿Cuántos depósitos al año da la Beca Benito Juárez?

- 12
- ✔ 5
- 1

*¡Correcto! No se paga en verano.*

**M8 U03 P3.** ¿Qué haces si alguien te cobra por registrar una beca?

- Pagas para asegurarla antes de que se acaben los lugares
- Pagas la mitad
- ✔ No pagas y registras en el sitio oficial

*¡Correcto! Es sin costo.*

**M8 U04 P1.** ¿Qué pasa si nombras beneficiarias en tu cuenta?

- Pagan más impuestos cuando reciben el dinero
- ✔ Reciben el dinero sin juicio
- No cambia nada

*¡Correcto! Es lo más rápido.*

**M8 U04 P2.** ¿Qué datos pones de cada beneficiaria?

- Solo el apodo con el que la conoce la familia
- Solo el parentesco
- ✔ Nombre completo y porcentaje

*¡Correcto! Así no hay dudas.*

**M8 U04 P3.** ¿Dónde más puedes nombrar beneficiarias?

- ✔ En tu Afore y tus seguros
- En tu recibo de luz
- En tu tarjeta de la tienda

*¡Correcto! Y en tu contrato.*

**M8 U05 P1.** ¿Con qué se heredan los derechos de una parcela ejidal?

- ✔ Con la lista de sucesión
- Con un recibo de luz
- Con una carta escrita a mano por el ejidatario

*¡Correcto! Se registra en el RAN.*

**M8 U05 P2.** ¿Qué mes tiene descuentos para hacer testamento?

- Enero
- Diciembre
- ✔ Septiembre

*¡Correcto! Mes del Testamento.*

**M8 U05 P3.** ¿Qué haces si tu casa no tiene escrituras?

- Nada, se hereda sola
- ✔ Pides orientación para regularizarla
- La vendes rápido a un vecino para no tener problemas

*¡Correcto! Primero los papeles.*

**M8 U06 P1.** ¿Cuánto ISR pagas por recibir una herencia?

- 30%
- ✔ Nada, está exenta
- 10%

*¡Correcto! Artículo 93 de la Ley del ISR.*

**M8 U06 P2.** La herencia de tu papá no alcanza para sus deudas y tú no firmaste nada. ¿Pagas con tu dinero?

- ✔ No
- Sí, todo
- Solo la mitad

*¡Correcto! Solo paga quien firmó como aval.*

**M8 U06 P3.** ¿Qué sí cuesta al heredar una casa?

- El ISR de la herencia, que es de 30% del valor de la casa
- Nada, no cuesta ni un peso
- ✔ Escriturar: impuesto estatal, notario y registro

*¡Correcto! Son los gastos de pasarla a tu nombre.*

## Módulo 9

**M9 U01 P1.** ¿Qué es pensar en crecer?

- Aguantar hasta que las cosas mejoren solas
- ✔ Buscar cómo ganar más con lo que sabes
- Pedir un préstamo

*¡Correcto! Es la idea.*

**M9 U01 P2.** Cobras 350 extra por guisados en dos casas cada semana. ¿Cuánto ganas de más al mes?

- 700
- 350
- ✔ 2,800

*¡Correcto! 350 por 2 por 4 semanas.*

**M9 U01 P3.** ¿Qué te ayuda a cobrar más por hora?

- ✔ Un curso de cuidado de personas mayores
- Trabajar sin descanso los siete días de la semana
- Bajar tu tarifa

*¡Correcto! Te especializa.*

**M9 U02 P1.** Cobras 900, gastas 120 en productos y 80 en pasajes. ¿Cuánto te queda?

- 900
- ✔ 700
- 1,100

*¡Correcto! 900 menos 200.*

**M9 U02 P2.** ¿Cuál es la mejor forma de conseguir clientas al inicio?

- ✔ Recomendaciones de tus casas
- Bajar tu precio a la mitad
- Trabajar sin cobrar la primera vez

*¡Correcto! Generan confianza.*

**M9 U02 P3.** ¿Qué haces antes de ir a una casa nueva?

- Das tu INE por WhatsApp
- ✔ Avisas a alguien de confianza dónde estarás
- Llevas todo tu dinero y tu INE por si te los piden

*¡Correcto! Por tu seguridad.*

**M9 U03 P1.** La clienta paga 800 y la app se queda con 20%. ¿Cuánto te llega antes de pasajes?

- 160
- 800
- ✔ 640

*¡Correcto! 800 menos 160.*

**M9 U03 P2.** ¿Qué es señal de engaño en una agencia?

- ✔ Que te pida pagar por inscribirte
- Que tenga contrato
- Que te explique la comisión y cuándo te paga

*¡Correcto! Nadie serio cobra por darte trabajo.*

**M9 U03 P3.** ¿Con qué comparas la app contra trabajar directo?

- Con lo que paga la clienta
- ✔ Con lo que te queda por hora
- Con cuántas estrellas tienes

*¡Correcto! Es tu ganancia real.*

**M9 U04 P1.** ¿Qué ayuda a cumplir una meta de ahorro?

- Guardarla en secreto para que nadie opine
- Ahorrar lo que sobre
- ✔ Nombre, testigo y recordatorio

*¡Correcto! Así ahorras más.*

**M9 U04 P2.** ¿Qué no va en tu plan?

- ✔ Tu NIP
- Tu meta de ahorro
- Tu lista de deudas

*¡Correcto! Es un dato sensible.*

**M9 U04 P3.** ¿Cada cuándo conviene revisar tu plan si cobras por día?

- Una vez al año
- ✔ Cada semana
- Solo en diciembre

*¡Correcto! El día que cobras.*
