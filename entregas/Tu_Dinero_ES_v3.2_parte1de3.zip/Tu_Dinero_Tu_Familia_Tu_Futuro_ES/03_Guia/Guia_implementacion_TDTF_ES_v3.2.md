# Tu Dinero, Tu Familia, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10: instalación, puntos, insignias y constancia, y mantenimiento.

# Parte 1. Instalación en Moodle, paso a paso

Escrita para que Claude (o una persona con rol de administración) la siga en el navegador. El mismo archivo está en `04_Moodle/README_INSTALAR_TU_DINERO_PARA_CLAUDE.md`.


Vas a crear el curso en español **Tu Dinero, Tu Familia, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert).

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TDTF-CA-ES`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**, y si Level Up es la versión gratuita o Level Up+. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

*Administración del sitio > Cursos > Agregar un nuevo curso*:

| Campo | Valor |
|---|---|
| Nombre | Tu Dinero, Tu Familia, Tu Futuro (piloto California) |
| Nombre corto | TDTF-CA-ES |
| Visibilidad | **Ocultar** |
| Formato | Temas, 7 secciones |
| Seguimiento de finalización | Sí |

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Entiende tu dinero y organiza tu economía | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Entiende el sistema financiero y planea tus remesas | `M2_resumen.html` |
| 3 | Módulo 3. Construye tu crédito y maneja tus deudas | `M3_resumen.html` |
| 4 | Módulo 4. Protege tu dinero, tu identidad y tu familia | `M4_resumen.html` |
| 5 | Módulo 5. Construye patrimonio y prepara tu futuro | `M5_resumen.html` |
| 6 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 7 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas números de cuenta, SSN, ITIN, contraseñas ni tu situación migratoria."

### 3. Libros de lecciones (M1 a M5)

En cada sección de módulo:

1. Crea un libro:
   - Nombre: `Lecciones del Módulo N`.
   - Formato de capítulo: Nada.
   - Finalización: Ver.
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba las páginas. En cada lección, la portada va primero y sus 3 subcapítulos sangrados debajo.

   | Módulo | Capítulos | Páginas |
   |---|---|---|
   | M1 | 14 | 56 |
   | M2 | 13 | 52 |
   | M3 | 10 | 40 |
   | M4 | 11 | 44 |
   | M5 | 11 | 44 |

4. El libro es la **primera actividad** de su sección.

### 4. Libro de apoyo

En la sección 6, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos).

En la sección General, agrega una **URL** o etiqueta que apunte al capítulo 1 ("Bienvenida") de este libro.

### 5. Glosario

En la sección 6, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, con destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Administración del curso > Banco de preguntas > Importar*: formato GIFT, archivo `4_preguntas/banco_preguntas_v3_es.gift.txt`.
   - Se crean las categorías *Tu Dinero v3/M1* a *M5*, con 177 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`:
   - Calificación aprobatoria: 70.
   - Intentos: ilimitados.
   - Método: calificación más alta.
   - Ordenar al azar las respuestas: sí.
   - Revisión: después del intento, mostrar si fue correcta, la retroalimentación y la respuesta correcta.
   - Finalización: "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Dinero v3/MN*, 10 por página:

   | Módulo | Preguntas |
   |---|---|
   | M1 | 42 |
   | M2 | 39 |
   | M3 | 30 |
   | M4 | 33 |
   | M5 | 33 |

### 7. Actividades H5P (59)

Los archivos están en `2_h5p/MN/`, en orden. Cada archivo trae sus librerías. En cada sección de módulo, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`. Por ejemplo: `M1 U01 · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones de H5P: permitir descarga no; botón de incrustar no; botón de derechos de autor sí.
5. Calificación: seguimiento de intentos sí; método "calificación más alta".
6. Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P de sus lecciones en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos, 3 opciones por caso y la calificación al terminar.

### 8. Level Up

Agrega el bloque Level Up al curso y sigue la sección 2 de `7_guias/guia_gamificacion_v3.md`: reglas, 6 niveles y clasificación anónima. Si Level Up no existe en el sitio, sáltate este paso y repórtalo.

### 9. Insignias

Sigue la sección 3 de la guía con las 8 imágenes de `5_insignias/`. Crea cada insignia con su criterio y actívalas al final.

### 10. Finalización del curso y constancia

1. Configura la **Finalización del curso** con las 5 autoevaluaciones (sección 4 de la guía).
2. Si **Certificado personalizado** está instalado, crea en la sección 7 la "Constancia de conclusión" según la sección 5 de la guía, con `6_certificado/certificado_fondo.png`. Revisa la vista previa en PDF y compárala con `certificado_muestra.png`.
3. Si **no** está instalado, no lo instales. Deja en la sección 7 la etiqueta: "Al aprobar las cinco autoevaluaciones recibirás la insignia Plan completo y tu constancia de conclusión", y repórtalo.

### 11. Revisión final (con rol de estudiante)

- M1 U01: la portada aparece primero, con los dos botones de ruta; "Lo esencial", "Profundiza" y "Practica" van debajo de su lección; los términos en color muestran su significado.
- La página *Practica* describe "¿Qué harías?" y su quiz tiene 3 opciones.
- La H5P de M1 U01 funciona y registra la calificación.
- La autoevaluación de M1 muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores.

### 12. Reporte para la persona

Incluye el enlace del curso, el número de páginas de cada libro, las H5P subidas por módulo, las preguntas por autoevaluación, las insignias creadas, la configuración de Level Up (gratuita o Level Up+), si la constancia quedó lista, todo lo que no pudiste hacer y por qué, y capturas de: una portada de lección, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **oculto**. La persona decide cuándo mostrarlo.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2. Usa lo que ya tiene tu plataforma y solo pide un complemento: el certificado.

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (59 en total) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo | Calificación aprobatoria de 70% |

**Las actividades H5P:**

- Cada una trae tres casos de la lección, con tres opciones cada uno.
- Mezclan las opciones, marcan la respuesta correcta y dejan reintentar.
- Son de tipo *Single Choice Set*. Traen incluidas sus librerías, en versiones compatibles con Moodle 3.10.
- Súbelas como **Actividad H5P** (mod_h5pactivity, parte de Moodle desde 3.9).

**Configuración de cada actividad H5P:**

- Opciones de H5P: sin botón de descarga, con botón de derechos de autor e incrustar desactivado.
- Intentos: seguimiento activado y método "Calificación más alta".
- Finalización: "El estudiante debe recibir una calificación".

**Las autoevaluaciones:**

- Usan el banco de preguntas v3: 177 preguntas con tres opciones y retroalimentación.
- Cada módulo tiene su propia categoría: *Tu Dinero v3/M1* a *M5*.
- Configuración: calificación aprobatoria de 70%, intentos ilimitados y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

La versión gratuita de Level Up da puntos por **eventos**. Configura una sola regla principal, así funciona con la versión gratuita y con Level Up+.

**Reglas** (*Level Up > Reglas*):

1. **Quita o pon en 0 las reglas predeterminadas.** Así, abrir una página o ver un recurso no da puntos.
2. **Por completar cualquier actividad:** 25 puntos. Usa el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos. Usa el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la **protección contra trampas** que trae Level Up. Evita que el mismo evento repetido sume puntos.

Con esas reglas, completar todo el curso da unos 1,725 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 59 | 1,475 |
| Libros | 5 | 125 |
| Autoevaluaciones | 5 | 125 |
| **Total** | 69 | **1,725** |

**Niveles** (*Level Up > Niveles*, 6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Empiezo | 0 | Al entrar |
| 2 | Me organizo | 150 | A mitad del Módulo 1 |
| 3 | Uso mi cuenta | 450 | Durante el Módulo 2 |
| 4 | Cuido mi crédito | 800 | Durante el Módulo 3 |
| 5 | Protejo a mi familia | 1,150 | Durante el Módulo 4 |
| 6 | Construyo mi futuro | 1,500 | Durante el Módulo 5 |

**Clasificación** (*Level Up > Clasificación*):

- Anonimato activado.
- Mostrar solo a los vecinos cercanos, o desactivar la clasificación.

### 3. Insignias

Créalas en *Administración del curso > Insignias > Agregar una nueva insignia*. Las imágenes están en `5_insignias/`.

Para cada insignia:

- **Emisor:** Desarrolla Talento.
- **Vencimiento:** nunca.
- **Criterio:** "Finalización de actividad", salvo "Plan completo", que usa "Finalización del curso".

| Imagen | Insignia | Criterio | Descripción |
|---|---|---|---|
| 01_M1_mi_dinero_en_orden.png | Mi dinero en orden | Autoevaluación del Módulo 1 completada (aprobada) | Organizaste tu flujo de dinero, tu presupuesto y tus impuestos. 14 lecciones, unas 3 horas. |
| 02_M2_envio_inteligente.png | Envío inteligente | Autoevaluación del Módulo 2 | Sabes elegir cuenta, comparar remesas y proteger a tu familia de fraudes. 13 lecciones. |
| 03_M3_credito_con_rumbo.png | Crédito con rumbo | Autoevaluación del Módulo 3 | Entiendes tu reporte, comparas préstamos y tienes un plan de deudas. 10 lecciones. |
| 04_M4_familia_protegida.png | Familia protegida | Autoevaluación del Módulo 4 | Tienes un plan de protección, seguros y preparación familiar. 11 lecciones. |
| 05_M5_futuro_en_marcha.png | Futuro en marcha | Autoevaluación del Módulo 5 | Tus metas, tu retiro y tu plan de una página están escritos. 11 lecciones. |
| 06_detective_de_estafas.png | Detective de estafas | H5P de M2 U11, M4 U01 y M4 U02 completados | Reconoces las señales de fraude y verificas antes de actuar. |
| 07_comparador_experto.png | Comparador experto | H5P de M2 U08, M3 U05 y M5 U05 completados | Comparas con el costo total, no solo con el precio anunciado. |
| 08_plan_completo.png | Plan completo | Finalización del curso | Concluiste los cinco módulos del programa. |

Al terminar, **activa** cada insignia (*Habilitar acceso*). Moodle no deja cambiar el criterio de una insignia que ya se entregó.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*:

- **Condición:** finalización de actividades, con **todas** estas: las 5 autoevaluaciones.
- **Opcional:** agrega también los 5 libros.

### 5. Constancia de conclusión (certificado)

Moodle 3.10 no trae certificados. Hay dos caminos.

#### Camino recomendado: complemento "Custom certificate" (mod_customcert)

Es gratuito y muy usado. Tiene versión para Moodle 3.10, la rama MOODLE_310_STABLE.

Instálalo **tú**, con la cuenta de administración del sitio, desde *Administración del sitio > Extensiones > Instalar complementos*. También puedes subirlo por cPanel.

Haz antes un respaldo del sitio.

1. En la sección "Evaluación y constancia", agrega la actividad **Certificado personalizado**.
   - **Nombre:** Constancia de conclusión.
   - **Tamaño:** A4 horizontal (297 × 210 mm).
2. **Restringir acceso:** agrega una condición de "Finalización de actividad" por cada una de las 5 autoevaluaciones, con la opción "debe estar completa con calificación aprobatoria".
3. **Editar certificado.** Agrega estos elementos:

   | Elemento | Posición aproximada (mm) | Formato |
   |---|---|---|
   | Imagen de fondo | Cubre la página | `6_certificado/certificado_fondo.png` |
   | Nombre del estudiante | X 0, Y 74, ancho 297, centrado | Negrita, 32 pt, color #0B1220 |
   | Fecha (fecha de finalización del curso) | X 17, Y 170, ancho 70, centrado | 12 pt, color #E4007C |
   | Código | X 210, Y 170, ancho 70, centrado | 12 pt, color #E4007C |

4. Usa **Vista previa en PDF** y ajusta las posiciones Y si algo se encima. Compara con `certificado_muestra.png`.
5. **Opcional:** activa "Verificar certificado" para que cualquiera pueda comprobar el código.

#### Camino sin complemento

La insignia **Plan completo** funciona como constancia digital. Moodle la entrega por correo y la persona la puede descargar.

Si alguien necesita la constancia en papel, se hace a mano con `certificado_muestra.png` como modelo.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No crear insignias con criterios que dependan de montos de dinero o de contratar productos.


# Parte 3. Mantenimiento

| Cuándo | Qué revisar | Dónde |
|---|---|---|
| Cada mes | Matriz comparativa de productos | Manual del operador, sección 6 |
| Antes de la temporada de impuestos (enero) | M1 U09 a U13: créditos fiscales, ITIN, VITA, preparadores | IRS y Franchise Tax Board |
| Cada año | Todo el contenido, enlaces "Para saber más" y datos con fecha | Sitios oficiales de cada institución |
| Ante cambios de ley o programa | Carga pública, Medi-Cal, impuesto a remesas y otros temas sensibles | Fuente oficial del cambio |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco en los dos idiomas y volver a armar esta carpeta | Herramientas del proyecto |
