# Comunidad Tu Patrimonio: manual de la comunidad

# Parte 1. Comunidad y canales


### 1. Comunidad Tu Patrimonio en Moodle

Un curso aparte, **"Comunidad Tu Patrimonio"** (nombre corto `DT-PATRIMONIO-MX-ES-COM`), complemento de este curso. Tiene avisos, foros de dudas por tema, alertas de fraude, logros, sesiones de acompañamiento y un foro separado de referencias comerciales. Su creación está en su propia carpeta.

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Patrimonio" y agregarla con "Sincronización de cohortes" en el curso y en la comunidad.

### 2. Sesiones de acompañamiento

- Una sesión en grupo por módulo o cada dos semanas, presencial o por videollamada, de 60 a 90 minutos.
- En los módulos 3 y 4, práctica guiada con capturas y un simulador. **Nunca** en la banca real de una participante frente al grupo y **nunca** tomando su celular.
- Se invita a la persona de confianza de cada participante, si ella quiere.

### 3. Canal de WhatsApp

- Nombre: "Tu Patrimonio · Desarrolla Talento".
- Contenido: avisos del curso, alertas de fraude, recordatorios (declaración anual, Mes del Testamento, renovación de seguros, pensiones del Bienestar) y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles y circulan fraudes.

### 4. Línea de apoyo

- Horario fijo semanal para dudas del curso por teléfono o mensaje.
- El equipo **nunca** pide datos personales, contraseñas, códigos ni fotos de tarjetas, y **nunca** opera la banca de una participante ni pide instalar apps de control remoto.
- Todos los mensajes del programa se firman igual y dan el mismo número, publicado en el curso, para que las participantes puedan distinguirlo de un fraude.

### 5. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial se publican **solo** en el canal y en el foro de referencias, nunca en lecciones, actividades, autoevaluaciones ni constancia. Cada publicación dice: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 6. Reglas de moderación

1. Borrar publicaciones con datos personales o capturas de cuentas y avisar en privado.
2. No permitir que participantes promuevan productos financieros, préstamos, inversiones o asesores.
3. Revisar el mismo día cualquier alerta de fraude.
4. Canalizar casos legales, fiscales, de pensión o de control económico a la institución o profesional adecuado.


# Parte 2. Guía de moderación


Para el equipo que modera los foros, el canal y la línea de apoyo. Versión 1.0 · Septiembre de 2026.

### 1. Principios

1. **Proteger datos personales** antes que cualquier otra cosa.
2. **Educar, no asesorar:** explicamos y canalizamos; no resolvemos casos legales, fiscales o de inversión concretos.
3. **Nunca operar por ellas:** no pedimos celulares, contraseñas ni pantallas compartidas; explicamos y ellas hacen los pasos.
4. **Cero venta dentro de la comunidad**, salvo el foro de referencias, siempre con aviso.
5. **Tono del curso:** tuteo cálido, sin culpas ni paternalismo.

### 2. Tiempos de respuesta

| Tipo | Meta |
|---|---|
| Publicación con datos personales | Retirar en menos de 2 horas hábiles |
| Alerta de fraude | Revisar el mismo día y fijar si es relevante |
| Fraude en curso (mensaje privado o línea de apoyo) | Responder de inmediato con el plan de respuesta |
| Duda general | Responder en 48 horas hábiles |

### 3. Qué hacer en cada caso

| Situación | Acción | Mensaje privado sugerido |
|---|---|---|
| Publica cuenta, INE, CURP o captura | Retirar la publicación | "Retiramos tu publicación porque tenía datos personales. Puedes volver a preguntar con números inventados o redondeados." |
| Ofrece inversiones, préstamos o asesores | Retirar y advertir | "En la comunidad no se permiten ofertas de inversiones, préstamos ni asesores. Revisa las reglas en el capítulo 2." |
| Recomienda un gestor de pensiones o del SAT | Retirar y explicar | "Los trámites del IMSS, la AFORE y el SAT no tienen costo y se hacen sin gestores (M7 y M9)." |
| Pide ayuda para operar su app | Explicar y canalizar | "Te explicamos los pasos en la línea de apoyo o en la sesión; tú los haces desde tu celular. Nunca compartas tu pantalla con desconocidos." |
| Fraude en curso | Responder de inmediato | "Bloquea tus tarjetas y accesos desde la app o el número de atrás de tu tarjeta, reclama por escrito, acude a la CONDUSEF y reporta al 088 (M4 U08)." |
| Extorsión telefónica | Responder de inmediato | "Cuelga y localiza a tu familiar por otro medio. Si hay riesgo, 911; puedes denunciar en el 089 (M4 U04)." |
| Señales de control económico | Responder con cuidado y canalizar | "Tu dinero es tuyo. Puedes buscar orientación en la instancia de las mujeres de tu estado; si hay riesgo, llama al 911 (M11 U02)." |
| Caso legal o de herencia | Responder con lo general y canalizar | "Tu caso depende de tus documentos. Te sugerimos una notaría; la lección M10 U01 explica el tema." |
| Crisis emocional o duelo | Responder con empatía y canalizar | "Lamentamos lo que vives. Si estás en riesgo, llama al 911. También puedes buscar apoyo en la Línea de la Vida (800 911 2000)." |
| Conflicto entre participantes | Recordar reglas; si sigue, suspender | "Te pedimos mantener el respeto. Es la regla de la comunidad." |

### 4. Respuestas tipo

**Duda que ya está en el curso:**
"¡Buena pregunta! Lo explicamos en [lección]. En corto: [resumen de 2 líneas]. Si después de leerla sigues con dudas, cuéntanos qué parte."

**Dato que cambia:**
"Este dato cambia con el tiempo. Al [fecha] era [dato] según [fuente]. Confírmalo en [institución oficial] antes de decidir."

**Petición de recomendación:**
"No recomendamos instituciones, fondos ni asesores. Te dejamos cómo verificar y comparar: [lección]. Si quieres, comparte las opciones que ves, sin datos personales, y te ayudamos a revisar qué preguntar."

### 5. Qué nunca hacemos

- Pedir datos personales, contraseñas, códigos o fotos de tarjetas.
- Pedir el celular de una participante, compartir pantalla o instalar apps.
- Recomendar una institución, un producto o una persona fuera del foro de referencias.
- Prometer resultados.

### 6. Escalamiento

1. Moderación responde o canaliza.
2. Coordinación revisa casos repetidos, quejas sobre referencias, suspensiones y señales de violencia.
3. Si un contenido del curso resulta incorrecto o desactualizado, se registra para la siguiente versión.

### 7. Métricas mensuales

| Métrica | Para qué |
|---|---|
| Personas activas y nuevas | Saber si la comunidad crece |
| Dudas publicadas y respondidas en 48 horas | Calidad de atención |
| Temas más preguntados | Mejorar lecciones y sesiones |
| Alertas de fraude y casos de fraude en curso | Detectar tendencias |
| Asistencia a sesiones de acompañamiento | Participación |
| Llamadas a la línea de apoyo | Carga y temas |
| Publicaciones retiradas | Ajustar reglas y avisos |

