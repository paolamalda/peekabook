# Comunidad Tu Patrimonio: contenido

## Bienvenida a la comunidad

**Comunidad Tu Patrimonio** es el espacio de quienes toman el programa *Tu Patrimonio, Tu Tranquilidad, Tu Futuro*. Es un complemento del curso: aquí resuelves dudas, compartes avances, te enteras de fechas importantes y te alertas de fraudes junto con otras mujeres.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas, recordatorios, sesiones y alertas. Solo publica el equipo. |
| **Lo que quiero lograr** | En una frase, qué quieres lograr. Sin datos personales. |
| **Foros de dudas** | Tres foros por tema: tu dinero y el sistema; seguridad y fraudes; retiro, salud y familia. |
| **Alertas de fraude** | Avisa de llamadas, mensajes o visitas sospechosas. |
| **Logros** | Celebra tus avances: activaste tus alertas, hiciste tu testamento, pediste tu reporte. |
| **Sesiones de acompañamiento** | Sesiones en grupo para repasar cada módulo, con práctica guiada. |
| **Referencias comerciales** | Servicios con acuerdo comercial, separados y señalados. Son opcionales. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar y apoyarnos.
- **No es** asesoría legal, fiscal ni de inversión personalizada. Para tu caso concreto, te orientamos hacia una institución o un profesional.
- **No es** un lugar para vender productos, ofrecer préstamos ni invitar a inversiones.

### Cómo reconocer al equipo

El equipo **nunca** te pide datos personales, contraseñas, códigos, fotos de tarjetas ni que instales apps. Nunca te llama para ofrecerte inversiones. Si alguien lo hace en nombre de la comunidad, es un fraude: repórtalo en **Alertas de fraude**.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Si quieres, comparte en **Lo que quiero lograr** qué te gustaría lograr, en una frase y sin datos personales.
3. Revisa las fechas de las sesiones (capítulo 5).
4. Cuando tengas una duda, usa la plantilla del capítulo 3.


## Reglas y privacidad

Estas reglas protegen tu información y la de todas.

### Tus datos

- **Nunca publiques** números de cuenta o tarjeta, NIP, contraseñas, códigos, CURP, INE, montos reales ni capturas de estados de cuenta.
- Si quieres dar un ejemplo, usa **números inventados o redondeados**: «tengo unos 500 mil en dos bancos».
- Los foros no permiten adjuntar archivos, para evitar que se compartan documentos por error.

### Respeto

- Sin burlas, juicios ni culpas: a cualquiera la pueden engañar.
- Sin discusiones personales ni publicaciones sobre terceros con nombre y apellido.

### Lo que no se permite

1. Vender productos o servicios, ofrecer préstamos o invitar a inversiones, tandas o «negocios».
2. Recomendar asesores, gestores o despachos que «arreglan» pensiones, el SAT o el Buró.
3. Publicar enlaces acortados o de sitios no oficiales para trámites.
4. Hacerse pasar por el equipo, por una institución o por otra persona.

### Si algo te parece fraude

Publícalo en **Alertas de fraude** sin datos personales, o escribe en privado al equipo. Si ya te afectó, sigue tu plan de respuesta (M4 U08): bloquea, reclama por escrito, acude a la CONDUSEF, reporta al 088 y denuncia.

### Qué hace el equipo

- Retira publicaciones con datos personales y te avisa en privado.
- Retira publicaciones que venden, prestan o invitan a invertir.
- Responde dudas generales y canaliza los casos personales.


## Cómo preguntar y pedir apoyo

Una pregunta clara recibe una respuesta útil más rápido.

### Plantilla

**Módulo o tema:** (por ejemplo, M8 seguro de gastos médicos)
**Mi situación, sin datos personales:** (por ejemplo, «mi seguro subió 30% y tengo 50 años»)
**Lo que ya revisé:** (por ejemplo, «leí la lección M8 U02»)
**Mi duda concreta:** (una pregunta, no cinco)

### Lo que la comunidad puede y no puede resolver

| Sí | No |
|---|---|
| Dudas sobre lo que explica el curso | Revisar tu estado de cuenta o tu póliza completa |
| Cómo comparar opciones | Decirte en qué banco, fondo o seguro contratar |
| A qué institución acudir | Hacer trámites por ti |
| Cómo reconocer un fraude | Operar tu banca o tu celular |

### Pedir apoyo de forma segura

- Para dudas con tu celular o tu banca, usa la **línea de apoyo** del programa o tu **persona de confianza**. El equipo te explica; tú haces los pasos.
- Nunca compartas tu pantalla con desconocidos ni instales apps que te pidan para «ayudarte».

### Responder a otras

Puedes compartir tu experiencia: di que es tu experiencia, no una regla; no recomiendes marcas ni personas; si no estás segura, remite a la lección o a la institución oficial.


## Tu calendario del año

Fechas y recordatorios que importan para tu dinero y tu familia. En **Avisos** y en el canal te recordamos cada una a tiempo.

| Mes | Recordatorio | Lección |
|---|---|---|
| Enero | Suma tus gastos anuales del año y apártalos cada mes | M1 U02 |
| Enero y febrero | Revisa montos y fechas de registro de las pensiones del Bienestar | M7 U04 |
| Febrero | Nueva UMA: límite exento de pensiones y tope de deducciones | M9 |
| Marzo | Junta tus facturas médicas para la declaración anual | M9 U03 |
| Abril | Declaración anual de personas físicas, si te corresponde | M9 |
| Mayo | Revisa tu AFORE y tus beneficiarios | M7 U02 |
| Junio | Pide tu reporte de crédito sin costo | M4 U06 |
| Julio | Revisa tus candados en la app: alertas y límite de transferencias | M3 U03 |
| Agosto | Revisa tus seguros antes de renovar | M8 |
| Septiembre | Mes del Testamento: revisa tu carpeta y tu plan | M10 U01 · M11 U03 |
| Octubre | Revisa tus inversiones y a tu asesor | M6 |
| Noviembre | Cuidado con fraudes de ofertas de fin de año | M4 U03 |
| Diciembre | Revisa tu plan de una página para el próximo año | M11 U03 |

### Solo en 2026

| Cuándo | Qué hacer | Lección |
|---|---|---|
| A más tardar el 31 de diciembre de 2026 | Vincula tu línea de celular con tu CURP y consulta si hay líneas a tu nombre que no reconoces | M4 U06 |

Las fechas oficiales pueden cambiar. Confírmalas en el sitio de cada institución.


## Sesiones de acompañamiento y retos

### Sesiones de acompañamiento

Una sesión en grupo por módulo o cada dos semanas, presencial o por videollamada. La fecha y el lugar o enlace se publican en **Avisos** y en el canal.

- Duración: 60 a 90 minutos.
- Repasamos el módulo, resolvemos dudas generales y hacemos un ejercicio.
- En los módulos 3 y 4 hay **práctica guiada** con capturas y un simulador. Nunca se usa tu banca real frente al grupo ni se te pide tu celular.
- Puedes invitar a tu persona de confianza.

### Retos del mes

Cada mes proponemos un reto corto en **Avisos**. Cuando lo cumplas, compártelo en **Logros**, sin datos personales.

| Mes | Reto |
|---|---|
| 1 | Haz tu inventario (M1 U01) |
| 2 | Calcula tu mes promedio con tus gastos anuales (M1 U02) |
| 3 | Activa las alertas de tu app y fija tu límite de transferencias (M3 U03) |
| 4 | Acuerda una palabra clave con tu familia (M4 U04) |
| 5 | Inscribe tus números en el REPEP y el REUS (M4 U07) |
| 6 | Pide tu reporte de crédito sin costo (M4 U06) |
| 7 | Revisa si tu ahorro está dentro del límite del IPAB (M5 U02) |
| 8 | Localiza tu AFORE y revisa tus beneficiarios (M7 U02) |
| 9 | Agenda tu testamento (M10 U01) |
| 10 | Llena los datos de tu póliza de gastos médicos (M8 U01) |
| 11 | Escribe tu tarjeta de reglas para decidir (M11 U01) |
| 12 | Llena tu plan de una página (M11 U03) |

### Encuesta de la comunidad

Dos veces al año te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima.


## Cómo funcionan las referencias comerciales

Queremos que sepas exactamente qué es contenido del programa y qué es una oferta comercial.

### Dónde aparecen

- **Solo** en el foro **Referencias comerciales** y en el canal de WhatsApp.
- **Nunca** en las lecciones, las actividades, las autoevaluaciones, las insignias, la constancia, las sesiones de acompañamiento ni la línea de apoyo.

### Qué dicen siempre

> **Referencia comercial:** Desarrolla Talento puede recibir una comisión si contratas este servicio. Compara con al menos otra opción. Usarlo es voluntario y no afecta tu acceso, tus puntos ni tu constancia.

### Antes de contratar cualquier servicio

- Verifica la institución o el asesor (M2 U03 y M6 U04).
- Pide la propuesta por escrito y aplica la regla de las 72 horas (M11 U01).
- Compara con al menos otra opción.

### Qué nunca verás

- Recomendaciones de SOFIPO, SOCAP ni SOFOM.
- Inversiones con rendimientos garantizados.
- Presión para decidir.

