YOUR MONEY, YOUR FAMILY, YOUR FUTURE
Version 1.0 · California pilot · Desarrolla Talento · October 2026

Financial well-being program for Latino immigrants in California: 5 modules on money, remittances, credit, protection and future.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt   This file.
01_Manual/      Program manual: characters, operator manual (editorial guide, evaluation, product matrix, metrics, privacy) and traceability.
02_Content/     Full content: lessons, support book, H5P activities and question bank (.docx and .md).
03_Guide/       Implementation guide: Moodle installation, gamification and maintenance (.docx and .md).
04_Moodle/      Package to install: books, H5P, glossary, bank, badges, certificate data, surveys, guides, preview and the README for Claude.

HOW IT FITS TOGETHER
--------------------
The folder comes in 4 zips because of size. Unzip them all in the same place: they merge into this folder.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Coordination read the program manual
[ ] Content reviewed by professionals for taxes, immigration-adjacent topics and insurance
[ ] Current facts confirmed on official sites
[ ] Course installed with 04_Moodle/README_INSTALL_YOUR_MONEY_EN_FOR_CLAUDE.md
[ ] Level Up, badges, certificate and surveys configured
[ ] Review with the student role

KEEP IN MIND
------------
- The course never gives immigration advice; it refers to attorneys and DOJ-accredited representatives.
- No personal data is requested: no SSN, ITIN, accounts or immigration status.
