# Update 1.1 → 1.2 · Your Business, Your Money, Your Future (U.S.) · for Claude

This package updates a course **already installed** in Moodle 3.10 from version 1.1 to 1.2. It only contains what changed. **Do not reinstall the course and do not delete activities, attempts, grades, badges or Level Up points.**

Before starting: make a course backup (*Course administration > Backup*, no user data is fine) and turn editing on. If a step can't be done, skip it and report it at the end.

## What changes

- M1 U04. Records in 10 minutes a day · updated
- M1 U05. Online betting: business money isn't for gambling · new
- M7 U05. Identity theft and unwanted calls · updated
- M7 U06. AI scams: fake voices, videos and messages · new
- M7 U07. If disaster strikes: your business ready · new
- M8 U03. Your monthly numbers · updated
- M8 U04. Stress, business and family · new
- "Support materials" book: chapters 1, 4, 5, 6
- 12 new questions; 1 new glossary terms.

## 1. By module

### Module 1

**Book `Module 1 lessons`**
1. In "M1 U04. Records in 10 minutes a day", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M1 U05. Online betting: business money isn't for gambling." and save.
2. *Import chapter* > `1_books/M1/M1_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M1 U05. Online betting: business money isn't for gambling" with 3 subchapters.
3. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M1 U01. Is your business making money or just selling?» → «M1 U02. Keep business money separate from home money» → «M1 U03. Pay yourself a salary» → «M1 U04. Records in 10 minutes a day» → «M1 U05. Online betting: business money isn't for gambling».

**Section summary:** *Edit section* for Module 1 > summary, HTML source view, replace everything with `5_section_summaries/M1_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M1 U05 · What would you do?`, file `2_h5p/M1/M1_U05_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 7

**Book `Module 7 lessons`**
1. In "M7 U05. Identity theft and unwanted calls", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M7 U06. AI scams: fake voices, videos and messages." and save.
2. *Import chapter* > `1_books/M7/M7_U06_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U06. AI scams: fake voices, videos and messages" with 3 subchapters.
3. *Import chapter* > `1_books/M7/M7_U07_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U07. If disaster strikes: your business ready" with 3 subchapters.
4. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M7 U01. Your health when you work for yourself» → «M7 U02. Insurance for your business» → «M7 U03. Scams against businesses» → «M7 U04. Your brand and your name» → «M7 U05. Identity theft and unwanted calls» → «M7 U06. AI scams: fake voices, videos and messages» → «M7 U07. If disaster strikes: your business ready».

**Section summary:** *Edit section* for Module 7 > summary, HTML source view, replace everything with `5_section_summaries/M7_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M7 U06 · What would you do?`, file `2_h5p/M7/M7_U06_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- New: *Add an activity > H5P*, name `M7 U07 · What would you do?`, file `2_h5p/M7/M7_U07_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

### Module 8

**Book `Module 8 lessons`**
1. In "M8 U03. Your monthly numbers", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M8 U04. Stress, business and family." and save.
2. *Import chapter* > `1_books/M8/M8_U04_lesson.zip`, type "Each HTML file represents one chapter". It creates "M8 U04. Stress, business and family" with 3 subchapters.
3. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M8 U01. Hiring help» → «M8 U02. Selling online and on platforms» → «M8 U03. Your monthly numbers» → «M8 U04. Stress, business and family».

**Section summary:** *Edit section* for Module 8 > summary, HTML source view, replace everything with `5_section_summaries/M8_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M8 U04 · What would you do?`, file `2_h5p/M8/M8_U04_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

## 2. "Support materials" book

- Chapter 1 "Welcome": delete it, *Import chapter* > `1_books/Apoyo/01_apoyo.zip` and move it up with the arrows to position 1.
- Chapter 4 "Glossary": delete it, *Import chapter* > `1_books/Apoyo/04_apoyo.zip` and move it up with the arrows to position 4.
- Chapter 5 "Where to get help": delete it, *Import chapter* > `1_books/Apoyo/05_apoyo.zip` and move it up with the arrows to position 5.
- Chapter 6 "References": delete it, *Import chapter* > `1_books/Apoyo/06_apoyo.zip` and move it up with the arrows to position 6.

## 3. Glossary

In the `Course key words` glossary: *Import entries* > `3_glossary/Glossary_new_terms.xml`, destination "current glossary". It only has the 1 new terms, so existing ones are not duplicated.

## 4. Questions and self-assessments

1. *Question bank > Import*, GIFT format, `4_questions/new_questions.gift.txt`. They go into the existing categories (12 questions).
2. In each self-assessment below, open *Edit quiz*. **If the quiz already has attempts, Moodle won't let you change its questions:** do not delete attempts; leave it as is and note it in your report (the new lessons still have their book and H5P). If it has no attempts, make the changes, 10 per page:
   - `Module 1 self-assessment`: add M1 U05 P1, M1 U05 P2, M1 U05 P3.
   - `Module 7 self-assessment`: add M7 U06 P1, M7 U06 P2, M7 U06 P3, M7 U07 P1, M7 U07 P2, M7 U07 P3.
   - `Module 8 self-assessment`: add M8 U04 P1, M8 U04 P2, M8 U04 P3.

## 5. What doesn't change

Level Up (rules and levels), badges, course completion and certificate stay the same: new H5P activities earn points automatically through the completion rule. No other file needs to be uploaded again.

## 6. Check and report

With *Switch role to > Student*, open one new lesson and its H5P. Report: chapters per changed book, new or replaced H5P, imported questions, quizzes that couldn't change because they have attempts, imported terms and anything you couldn't do.
