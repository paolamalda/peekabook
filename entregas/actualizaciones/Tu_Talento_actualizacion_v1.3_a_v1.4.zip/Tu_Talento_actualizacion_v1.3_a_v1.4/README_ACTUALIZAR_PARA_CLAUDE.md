# Actualización 1.3 → 1.4 · Tu Talento, Tu Marca, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.3 a la 1.4. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M4 U04: texto corregido; M7 U01: texto corregido; M9 U08: texto corregido; M10: lección nueva U08; M10 U07: texto corregido; Apoyo: capítulos 4, 5 corregidos; Preguntas: 3 nuevas; Glosario: 1 término nuevo; categoría de preguntas: Tu Talento v1.4.

## 1. Categoría de preguntas

En *Banco de preguntas > Categorías*, renombra `Tu Talento v1.3` a `Tu Talento v1.4` (sus subcategorías M1… se quedan). Hazlo antes de importar preguntas.

## 2. Por módulo

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. En «M4 U04. Tus derechos como usuario», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis.» por «Sin costo.» y guarda.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U01. ¿Qué son el Buró y el Círculo de Crédito?», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis una vez al año.» por «Sin costo una vez al año.» y guarda.

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. En «M9 U08. Que dejen de llamarte: REPEP, REUS y tu línea», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis; denuncia si siguen llamando.» por «Sin costo; denuncia si siguen llamando.» y guarda.

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U08. Tus regalías cuando faltes: derechos, sociedades de gestión e impuestos.» y guarda.
2. *Importar capítulo* > `1_libros/M10/M10_U08_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U08. Tus regalías cuando faltes: derechos, sociedades de gestión e impuestos» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Sin seguro de empresa: el Seguro de Gastos Médicos Mayores» → «M10 U02. IMSS Modalidad 10: seguridad social para independientes» → «M10 U03. Si no puedes trabajar: incapacidad, invalidez y accidentes» → «M10 U04. Seguro de vida y beneficiarios» → «M10 U05. Protege tu nombre y tu marca» → «M10 U06. Testamento y documentos para tu familia» → «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo» → «M10 U08. Tus regalías cuando faltes: derechos, sociedades de gestión e impuestos».

**Resumen de la sección:** *Editar sección* del Módulo 10 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M10_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U08 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U08_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 3. Libro «Materiales de apoyo»

- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.

## 4. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 1 términos nuevos.

## 5. Preguntas y autoevaluaciones

1. **Nuevas (3):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Talento v1.4/MN`.
2. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 10`: M10 U08 P1, M10 U08 P2, M10 U08 P3.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
