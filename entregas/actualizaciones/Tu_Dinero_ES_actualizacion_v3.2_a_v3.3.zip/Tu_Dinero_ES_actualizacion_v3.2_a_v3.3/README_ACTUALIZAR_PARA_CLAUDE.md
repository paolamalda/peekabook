# Actualización 3.2 → 3.3 · Tu Dinero, Tu Familia, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 3.2 a la 3.3. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M1 U01: texto corregido; M1 U02: texto corregido; M1 U03: texto corregido; M1 U04: texto corregido; M1 U05: texto corregido; M1 U06: texto corregido; M1 U07: texto corregido; M1 U08: texto corregido; M1 U09: texto corregido; M1 U10: texto corregido; M1 U11: texto corregido; M1 U12: texto corregido; M1 U13: texto corregido; M1 U14: texto corregido; M2 U01: texto corregido; M2 U02: texto corregido; M2 U03: texto corregido; M2 U04: texto corregido; M2 U05: texto corregido; M2 U06: texto corregido; M2 U07: texto corregido; M2 U08: texto corregido; M2 U09: texto corregido; M2 U10: texto corregido; M2 U11: texto corregido; M2 U12: texto corregido; M2 U13: texto corregido; M3 U01: texto corregido; M3 U02: texto corregido; M3 U03: texto corregido; M3 U04: texto corregido; M3 U05: texto corregido; M3 U06: texto corregido; M3 U07: texto corregido; M3 U08: texto corregido; M3 U09: texto corregido; M3 U10: texto corregido; M4 U01: texto corregido; M4 U02: texto corregido; M4 U03: texto corregido; M4 U04: texto corregido; M4 U05: texto corregido; M4 U06: texto corregido; M4 U07: texto corregido; M4 U08: texto corregido; M4 U09: texto corregido; M4 U10: texto corregido; M4 U11: texto corregido; M5 U01: texto corregido; M5 U02: texto corregido; M5 U03: texto corregido; M5 U04: texto corregido; M5 U05: texto corregido; M5 U06: texto corregido; M5 U07: texto corregido; M5 U08: texto corregido; M5 U09: texto corregido; M5 U10: texto corregido; M5 U11: texto corregido; Apoyo: capítulos 1, 4, 5, 6 corregidos; Preguntas: 112 con texto corregido; Apoyo: herramientas en Excel (recurso nuevo); Plataforma: categoría con versión, insignias con nombre del curso, constancia estándar, encuestas, curso visible con clave y mosaicos.

## 1. Ajustes de plataforma (una sola vez)

1. **Categoría de preguntas:** en *Banco de preguntas > Categorías*, renombra `Tu Dinero v3` a `Tu Dinero v3.3` (sus subcategorías M1… se quedan).
2. **Insignias:** renombra cada insignia para que sea única en la plataforma: «Mi dinero en orden» → «Mi dinero en orden · Tu Dinero»; «Envío inteligente» → «Envío inteligente · Tu Dinero»; «Crédito con rumbo» → «Crédito con rumbo · Tu Dinero»; «Familia protegida» → «Familia protegida · Tu Dinero»; «Futuro en marcha» → «Futuro en marcha · Tu Dinero»; «Detective de estafas» → «Detective de estafas · Tu Dinero»; «Comparador experto» → «Comparador experto · Tu Dinero»; «Plan completo» → «Plan completo · Tu Dinero». Las insignias ya otorgadas se conservan.
3. **Constancia:** edita el Certificado personalizado, quita la imagen de fondo y usa la plantilla estándar de la plataforma con: título «Tu Dinero, Tu Familia, Tu Futuro», línea «por concluir el programa de bienestar financiero Tu Dinero, Tu Familia, Tu Futuro» y temas Mi dinero · Sistema y remesas · Crédito y deudas · Protección · Futuro y patrimonio (también en `7_constancia/`). Agrega la **Encuesta final** como condición de acceso.
4. **Visibilidad e inscripción:** curso **visible**; *Métodos de inscripción* > **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes). Sin acceso de invitados.
5. **Formato:** si **Mosaicos** (Tiles) está instalado, cambia el formato del curso a Mosaicos con el progreso en los mosaicos **como porcentaje**; si no, deja Temas.
6. **Encuestas:** con el módulo **Retroalimentación** (anónima), crea `Encuesta de inicio` (sección General), `Encuesta final`, `Seguimiento a 30 días` y `Seguimiento a 90 días` (última sección) e importa los XML de `6_encuestas/` (`encuestas.md` los explica). Restringe los seguimientos por fecha («[por definir]»).
7. **Catálogo:** actualiza la ficha del curso con `tarjeta_catalogo.md`.

## 2. Herramientas en Excel

En la sección «Materiales de apoyo», agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con `8_herramientas/Herramientas_TDTF.xlsx`. Mostrar: "Forzar descarga". Descripción: "Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver". No cuenta para la finalización del curso.

## 3. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M1/M1_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 14 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Cambia: abre `M1 U06 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M1/M1_U06_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M2/M2_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 13 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 2 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M2_resumen.html`.

**Actividades H5P**
- Cambia: abre `M2 U03 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M2/M2_U03_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M2 U04 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M2/M2_U04_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M2 U08 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M2/M2_U08_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 3

**Libro `Lecciones del Módulo 3`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M3/M3_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 10 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 3 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M3_resumen.html`.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M4/M4_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 11 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 4 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M4_resumen.html`.

**Actividades H5P**
- Cambia: abre `M4 U02 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M4/M4_U02_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M5/M5_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 11 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 5 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M5_resumen.html`.

**Actividades H5P**
- Cambia: abre `M5 U07 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M5/M5_U07_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 4. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 5. Preguntas y autoevaluaciones

1. **Texto corregido (112):** en el banco, abre cada pregunta y *Editar*; reemplaza el enunciado, las opciones y la retroalimentación con los de `4_preguntas/preguntas_corregidas_referencia.gift.txt` (mismo nombre, no la importes). Editar no borra intentos. Preguntas: M1 U01 P2, M1 U02 P1, M1 U02 P3, M1 U03 P2, M1 U03 P3, M1 U04 P3, M1 U05 P2, M1 U05 P3, M1 U06 P2, M1 U06 P3, M1 U07 P1, M1 U07 P3, M1 U08 P2, M1 U08 P3, M1 U09 P2, M1 U09 P3, M1 U10 P1, M1 U10 P2, M1 U10 P3, M1 U11 P3, M1 U12 P1, M1 U12 P3, M1 U13 P2, M1 U13 P3, M1 U14 P3, M2 U01 P1, M2 U01 P2, M2 U01 P3, M2 U02 P1, M2 U02 P3, M2 U03 P1, M2 U03 P3, M2 U04 P1, M2 U04 P2, M2 U05 P1, M2 U05 P3, M2 U06 P1, M2 U06 P3, M2 U07 P1, M2 U07 P3, M2 U08 P1, M2 U09 P1, M2 U09 P2, M2 U09 P3, M2 U10 P1, M2 U11 P1, M2 U11 P3, M2 U12 P1, M2 U12 P3, M2 U13 P1, M2 U13 P3, M3 U01 P1, M3 U01 P2, M3 U02 P1, M3 U02 P2, M3 U03 P1, M3 U03 P2, M3 U04 P1, M3 U04 P2, M3 U04 P3, M3 U05 P1, M3 U05 P2, M3 U06 P2, M3 U07 P1, M3 U07 P2, M3 U08 P2, M3 U09 P1, M3 U09 P2, M3 U09 P3, M3 U10 P1, M3 U10 P2, M3 U10 P3, M4 U01 P2, M4 U01 P3, M4 U02 P3, M4 U03 P2, M4 U03 P3, M4 U04 P2, M4 U04 P3, M4 U05 P2, M4 U05 P3, M4 U06 P1, M4 U06 P2, M4 U06 P3, M4 U07 P2, M4 U07 P3, M4 U08 P3, M4 U09 P2, M4 U09 P3, M4 U10 P2, M4 U10 P3, M4 U11 P2, M4 U11 P3, M5 U01 P1, M5 U01 P3, M5 U02 P1, M5 U03 P1, M5 U04 P1, M5 U04 P3, M5 U05 P1, M5 U05 P3, M5 U06 P1, M5 U06 P3, M5 U07 P1, M5 U07 P3, M5 U08 P1, M5 U08 P3, M5 U09 P1, M5 U09 P3, M5 U10 P1, M5 U11 P1, M5 U11 P3.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
