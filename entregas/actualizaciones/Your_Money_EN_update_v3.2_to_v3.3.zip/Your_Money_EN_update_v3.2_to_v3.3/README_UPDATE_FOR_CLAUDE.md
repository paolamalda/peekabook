# Update 3.2 → 3.3 · Your Money, Your Family, Your Future · for Claude

This package updates a course **already installed** in Moodle 3.10 from version 3.2 to 3.3. It only contains what changed. Activity names stay the same. **Do not reinstall the course and do not delete activities, attempts, grades, badges or Level Up points.**

Before starting: make a course backup (*Course administration > Backup*, no user data is fine) and turn editing on. If a step can't be done, skip it and report it at the end.

## Change list

M1 U01: text corrected; M1 U02: text corrected; M1 U03: text corrected; M1 U04: text corrected; M1 U05: text corrected; M1 U06: text corrected; M1 U07: text corrected; M1 U08: text corrected; M1 U09: text corrected; M1 U10: text corrected; M1 U11: text corrected; M1 U12: text corrected; M1 U13: text corrected; M1 U14: text corrected; M2 U01: text corrected; M2 U02: text corrected; M2 U03: text corrected; M2 U04: text corrected; M2 U05: text corrected; M2 U06: text corrected; M2 U07: text corrected; M2 U08: text corrected; M2 U09: text corrected; M2 U10: text corrected; M2 U11: text corrected; M2 U12: text corrected; M2 U13: text corrected; M3 U01: text corrected; M3 U02: text corrected; M3 U03: text corrected; M3 U04: text corrected; M3 U05: text corrected; M3 U06: text corrected; M3 U07: text corrected; M3 U08: text corrected; M3 U09: text corrected; M3 U10: text corrected; M4 U01: text corrected; M4 U02: text corrected; M4 U03: text corrected; M4 U04: text corrected; M4 U05: text corrected; M4 U06: text corrected; M4 U07: text corrected; M4 U08: text corrected; M4 U09: text corrected; M4 U10: text corrected; M4 U11: text corrected; M5 U01: text corrected; M5 U02: text corrected; M5 U03: text corrected; M5 U04: text corrected; M5 U05: text corrected; M5 U06: text corrected; M5 U07: text corrected; M5 U08: text corrected; M5 U09: text corrected; M5 U10: text corrected; M5 U11: text corrected; Support book: chapters 1, 2, 4, 5, 6 corrected; Questions: 112 with corrected text; Support: Excel tools (new resource); Platform: versioned category, badges with course name, standard certificate, surveys, visible course with key and tiles.

## 1. Platform adjustments (one time)

1. **Question category:** in *Question bank > Categories*, rename `Your Money v3` to `Your Money v3.3` (its M1… subcategories stay).
2. **Badges:** rename each badge so it's unique on the platform: «My money in order» → «My money in order · Your Money»; «Smart sending» → «Smart sending · Your Money»; «Credit on track» → «Credit on track · Your Money»; «Protected family» → «Protected family · Your Money»; «Future in motion» → «Future in motion · Your Money»; «Scam detective» → «Scam detective · Your Money»; «Expert comparer» → «Expert comparer · Your Money»; «Complete plan» → «Complete plan · Your Money». Badges already issued are kept.
3. **Certificate:** edit the Custom certificate, remove the background image and use the platform's standard template with: course title «Your Money, Your Family, Your Future», line «for completing the financial well-being program Your Money, Your Family, Your Future» and topics My money · Financial system · Credit and debt · Protection · Future and wealth (also in `7_certificate/`). Add the **Final survey** as an access condition.
4. **Visibility and enrolment:** course **visible**; *Enrolment methods* > **Self enrolment** with the enrolment key the person gives you ("[TBD]" if you don't have it). Guest access off.
5. **Format:** if **Tiles** is installed, switch the course format to Tiles with progress on tiles **as a percentage**; otherwise leave Topics.
6. **Surveys:** with the **Feedback** module (anonymous), create `Start survey` (General section), `Final survey`, `30-day follow-up` and `90-day follow-up` (last section) and import the XML files in `6_surveys/` (`surveys.md` explains them). Restrict the follow-ups by date ("[TBD]").
7. **Catalog:** update the course listing with `catalog_card.md`.

## 2. Excel tools

In the "Support materials" section, add a **File** resource named `Tools for your numbers (Excel)` with `8_tools/Tools_TDTF.xlsx`. Display: "Force download". Description: "Type only in the pink cells; the file is yours and isn't shared." Completion: "View". It doesn't count toward course completion.

## 3. By module

### Module 1

**Book `Module 1 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M1/M1_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 14 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 1 > summary, HTML source view, replace everything with `5_section_summaries/M1_resumen.html`.

**H5P activities**
- Changed: open `M1 U03 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M1/M1_U03_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M1 U06 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M1/M1_U06_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M1 U14 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M1/M1_U14_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 2

**Book `Module 2 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M2/M2_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 13 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 2 > summary, HTML source view, replace everything with `5_section_summaries/M2_resumen.html`.

**H5P activities**
- Changed: open `M2 U03 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M2/M2_U03_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M2 U04 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M2/M2_U04_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M2 U08 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M2/M2_U08_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M2 U10 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M2/M2_U10_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 3

**Book `Module 3 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M3/M3_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 10 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 3 > summary, HTML source view, replace everything with `5_section_summaries/M3_resumen.html`.

### Module 4

**Book `Module 4 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M4/M4_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 11 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 4 > summary, HTML source view, replace everything with `5_section_summaries/M4_resumen.html`.

**H5P activities**
- Changed: open `M4 U02 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M4/M4_U02_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

### Module 5

**Book `Module 5 lessons`**
1. Open the book, *Edit* and delete **all** its chapters (the book, its completion and its views are kept).
2. *Import chapter* > `1_books/M5/M5_libro_Moodle.zip`, type "Each HTML file represents one chapter". It creates 11 chapters with their subchapters, already in order.

**Section summary:** *Edit section* for Module 5 > summary, HTML source view, replace everything with `5_section_summaries/M5_resumen.html`.

**H5P activities**
- Changed: open `M5 U01 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M5/M5_U01_what_would_you_do.h5p`. Previous attempts are kept.
- Changed: open `M5 U07 · What would you do?` > *Edit settings* and replace the file with `2_h5p/M5/M5_U07_what_would_you_do.h5p`. Previous attempts are kept.
- Final section order: book, H5P in lesson order, self-assessment.

## 4. "Support materials" book

- Chapter 1 "Welcome": delete it, *Import chapter* > `1_books/Apoyo/01_apoyo.zip` and move it up with the arrows to position 1.
- Chapter 2 "Capstone cases": delete it, *Import chapter* > `1_books/Apoyo/02_apoyo.zip` and move it up with the arrows to position 2.
- Chapter 4 "Glossary": delete it, *Import chapter* > `1_books/Apoyo/04_apoyo.zip` and move it up with the arrows to position 4.
- Chapter 5 "Where to find help": delete it, *Import chapter* > `1_books/Apoyo/05_apoyo.zip` and move it up with the arrows to position 5.
- Chapter 6 "References": delete it, *Import chapter* > `1_books/Apoyo/06_apoyo.zip` and move it up with the arrows to position 6.

## 5. Questions and self-assessments

1. **Corrected text (112):** in the bank, open each question and *Edit*; replace the stem, options and feedback with those in `4_questions/corrected_questions_reference.gift.txt` (same name, don't import it). Editing doesn't delete attempts. Questions: M1 U01 P2, M1 U02 P1, M1 U02 P3, M1 U03 P2, M1 U03 P3, M1 U04 P3, M1 U05 P2, M1 U05 P3, M1 U06 P2, M1 U06 P3, M1 U07 P1, M1 U07 P3, M1 U08 P2, M1 U08 P3, M1 U09 P2, M1 U09 P3, M1 U10 P1, M1 U10 P2, M1 U10 P3, M1 U11 P3, M1 U12 P1, M1 U12 P3, M1 U13 P2, M1 U13 P3, M1 U14 P3, M2 U01 P1, M2 U01 P2, M2 U01 P3, M2 U02 P1, M2 U02 P3, M2 U03 P1, M2 U03 P3, M2 U04 P1, M2 U04 P2, M2 U05 P1, M2 U05 P3, M2 U06 P1, M2 U06 P3, M2 U07 P1, M2 U07 P3, M2 U08 P1, M2 U09 P1, M2 U09 P2, M2 U09 P3, M2 U10 P1, M2 U11 P1, M2 U11 P3, M2 U12 P1, M2 U12 P3, M2 U13 P1, M2 U13 P3, M3 U01 P1, M3 U01 P2, M3 U02 P1, M3 U02 P2, M3 U03 P1, M3 U03 P2, M3 U04 P1, M3 U04 P2, M3 U04 P3, M3 U05 P1, M3 U05 P2, M3 U06 P2, M3 U07 P1, M3 U07 P2, M3 U08 P2, M3 U09 P1, M3 U09 P2, M3 U09 P3, M3 U10 P1, M3 U10 P2, M3 U10 P3, M4 U01 P2, M4 U01 P3, M4 U02 P3, M4 U03 P2, M4 U03 P3, M4 U04 P2, M4 U04 P3, M4 U05 P2, M4 U05 P3, M4 U06 P1, M4 U06 P2, M4 U06 P3, M4 U07 P2, M4 U07 P3, M4 U08 P3, M4 U09 P2, M4 U09 P3, M4 U10 P2, M4 U10 P3, M4 U11 P2, M4 U11 P3, M5 U01 P1, M5 U01 P3, M5 U02 P1, M5 U03 P1, M5 U04 P1, M5 U04 P3, M5 U05 P1, M5 U05 P3, M5 U06 P1, M5 U06 P3, M5 U07 P1, M5 U07 P3, M5 U08 P1, M5 U08 P3, M5 U09 P1, M5 U09 P3, M5 U10 P1, M5 U11 P1, M5 U11 P3.

## 6. Check and report

With *Switch role to > Student*, open one new lesson and its H5P. Report: chapters per changed book, new or replaced H5P, corrected and imported questions, quizzes that couldn't change because they have attempts, imported terms, platform adjustments done and anything you couldn't do.

The `9_for_the_team/` folder (facilitator kit, WhatsApp and audio scripts, OECD map) is for the program team: **don't upload it to Moodle**.
