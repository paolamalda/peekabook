# Actualización 1.2 → 1.3 · Tu Negocio, Tu Dinero, Tu Futuro · México · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.2 a la 1.3. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M7 U01: texto corregido; M7 U05: texto corregido; M9: lección nueva U04; M9 U03: texto corregido; Apoyo: capítulos 4, 5 corregidos; Preguntas: 3 nuevas; categoría de preguntas: Tu Negocio MX v1.3.

## 1. Categoría de preguntas

En *Banco de preguntas > Categorías*, renombra `Tu Negocio MX v1.2` a `Tu Negocio MX v1.3` (sus subcategorías M1… se quedan). Hazlo antes de importar preguntas.

## 2. Por módulo

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M7 U01. IMSS para personas independientes (Modalidad 10)».
2. En «M7 U05. Tu identidad y la de tu negocio», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Gratis una vez al año en Buró y en Círculo.» por «Sin costo una vez al año en Buró y en Círculo.» y guarda.
3. En «M7 U05. Tu identidad y la de tu negocio», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Gratis cada año» por «Sin costo cada año» y guarda.
4. *Importar capítulo* > `1_libros/M7/M7_U01_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U01. IMSS para personas independientes (Modalidad 10)» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. IMSS para personas independientes (Modalidad 10)» → «M7 U02. Seguros para tu negocio» → «M7 U03. Fraudes a negocios» → «M7 U04. Tu marca y tu nombre» → «M7 U05. Tu identidad y la de tu negocio» → «M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos» → «M7 U07. Si llega un desastre: tu negocio preparado» → «M7 U08. Si faltas: seguro de vida y gastos funerarios».

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. En «M9 U03. Tu plan de una página», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M9 U04. Si faltas: tu casa, tus socios, lo digital y los impuestos de la herencia.» y guarda.
2. *Importar capítulo* > `1_libros/M9/M9_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U04. Si faltas: tu casa, tus socios, lo digital y los impuestos de la herencia» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M9 U01. Tu retiro si trabajas por tu cuenta» → «M9 U02. Si el negocio cambia o si faltas» → «M9 U03. Tu plan de una página» → «M9 U04. Si faltas: tu casa, tus socios, lo digital y los impuestos de la herencia».

**Resumen de la sección:** *Editar sección* del Módulo 9 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M9_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M9 U04 · ¿Qué harías?`, archivo `2_h5p/M9/M9_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 3. Libro «Materiales de apoyo»

- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.

## 4. Preguntas y autoevaluaciones

1. **Nuevas (3):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Negocio MX v1.3/MN`.
2. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 9`: M9 U04 P1, M9 U04 P2, M9 U04 P3.

## 5. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
