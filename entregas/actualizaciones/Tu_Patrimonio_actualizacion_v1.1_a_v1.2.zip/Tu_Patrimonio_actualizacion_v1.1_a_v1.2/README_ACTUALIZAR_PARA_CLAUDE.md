# Actualización 1.1 → 1.2 · Tu Patrimonio, Tu Tranquilidad, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M1: lección nueva U05; M1 U01: texto corregido; M1 U03: texto corregido; M1 U04: texto corregido; M2 U01: texto corregido; M2 U03: texto corregido; M2 U04: texto corregido; M4 U06: texto corregido; M4 U07: texto corregido; M5: lecciones nuevas U05, U06, U07; M5 U02: texto corregido; M5 U04: texto corregido; M6: lección nueva U06; M6 U05: texto corregido; M7 U02: texto corregido; M7 U03: texto corregido; M7 U04: texto corregido; M7 U05: texto corregido; M8: lección nueva U06; M8 U04: texto corregido; M8 U05: texto corregido; M9 U01: texto corregido; M10: lección nueva U06; M10 U05: texto corregido; M11 U03: texto corregido; Apoyo: capítulos 1, 4, 5, 6 corregidos; Preguntas: 21 nuevas; Preguntas: 9 con texto corregido; Glosario: 5 términos nuevos; Apoyo: herramientas en Excel (recurso nuevo); Plataforma: categoría con versión, insignias con nombre del curso, constancia estándar, encuestas, curso visible con clave y mosaicos.

## 1. Ajustes de plataforma (una sola vez)

1. **Categoría de preguntas:** en *Banco de preguntas > Categorías*, renombra `Tu Patrimonio` a `Tu Patrimonio v1.2` (sus subcategorías M1… se quedan).
2. **Insignias:** renombra cada insignia para que sea única en la plataforma: «Mi mapa en orden» → «Mi mapa en orden · Tu Patrimonio»; «Celular con candado» → «Celular con candado · Tu Patrimonio»; «Nadie me engaña» → «Nadie me engaña · Tu Patrimonio»; «Ahorro protegido» → «Ahorro protegido · Tu Patrimonio»; «Retiro claro» → «Retiro claro · Tu Patrimonio»; «Salud asegurada» → «Salud asegurada · Tu Patrimonio»; «Familia en orden» → «Familia en orden · Tu Patrimonio»; «Plan completo» → «Plan completo · Tu Patrimonio». Las insignias ya otorgadas se conservan.
3. **Constancia:** edita el Certificado personalizado, quita la imagen de fondo y usa la plantilla estándar de la plataforma con: título «Tu Patrimonio, Tu Tranquilidad, Tu Futuro», línea «por concluir el programa de bienestar financiero Tu Patrimonio, Tu Tranquilidad, Tu Futuro» y temas Tu dinero y el sistema · Seguridad y fraudes · Ahorro e inversión · Retiro y salud · Familia y plan (también en `7_constancia/`). Agrega la **Encuesta final** como condición de acceso.
4. **Visibilidad e inscripción:** curso **visible**; *Métodos de inscripción* > **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes). Sin acceso de invitados.
5. **Formato:** si **Mosaicos** (Tiles) está instalado, cambia el formato del curso a Mosaicos con el progreso en los mosaicos **como porcentaje**; si no, deja Temas.
6. **Encuestas:** con el módulo **Retroalimentación** (anónima), crea `Encuesta de inicio` (sección General), `Encuesta final`, `Seguimiento a 30 días` y `Seguimiento a 90 días` (última sección) e importa los XML de `6_encuestas/` (`encuestas.md` los explica). Restringe los seguimientos por fecha («[por definir]»).
7. **Catálogo:** actualiza la ficha del curso con `tarjeta_catalogo.md`.

## 2. Herramientas en Excel

En la sección «Materiales de apoyo», agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con `8_herramientas/Herramientas_TPTF.xlsx`. Mostrar: "Forzar descarga". Descripción: "Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver". No cuenta para la finalización del curso.

## 3. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. En «M1 U01. ¿Qué tengo y dónde está?», subcapítulo «Practica», *Editar*: cambia el texto «el reporte gratis una vez al año, para ver créditos y tarjetas a tu nombre.» por «el reporte sin costo una vez al año, para ver créditos y tarjetas a tu nombre.» y guarda.
2. En «M1 U03. Mi dinero, nuestro dinero», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
3. En «M1 U04. Tu carpeta de documentos», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M1 U05. Compra inteligente: el súper, las ofertas y los pagos a plazos.» y guarda.
4. *Importar capítulo* > `1_libros/M1/M1_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U05. Compra inteligente: el súper, las ofertas y los pagos a plazos» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Qué tengo y dónde está?» → «M1 U02. ¿Cuánto cuesta vivir en mi casa, al mes y al año?» → «M1 U03. Mi dinero, nuestro dinero» → «M1 U04. Tu carpeta de documentos» → «M1 U05. Compra inteligente: el súper, las ofertas y los pagos a plazos».

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U05 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M2 U04. Tus derechos y dónde reclamar».
2. En «M2 U01. ¿Quién es quién en el sistema financiero?», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «No. Es gratuita y nunca pide depósitos; si alguien lo hace en su nombre, es fraude.» por «No. Es sin costo y nunca pide depósitos; si alguien lo hace en su nombre, es fraude.» y guarda.
3. En «M2 U01. ¿Quién es quién en el sistema financiero?», subcapítulo «Practica», *Editar*: cambia el texto «1-b: es gratuita y defiende a los usuarios. 2-a: la CNBV tiene el padrón. 3-c: cuelga y verifica en el canal oficial.» por «1-b: no tiene costo y defiende a los usuarios. 2-a: la CNBV tiene el padrón. 3-c: cuelga y verifica en el canal oficial.» y guarda.
4. En «M2 U03. Verifica antes de confiar», subcapítulo «M2 U03. Verifica antes de confiar», *Editar*: cambia el texto «Tres consultas gratuitas» por «Tres consultas sin costo» y guarda.
5. En «M2 U03. Verifica antes de confiar», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Tres consultas gratuitas» por «Tres consultas sin costo» y guarda.
6. *Importar capítulo* > `1_libros/M2/M2_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M2 U04. Tus derechos y dónde reclamar» con 3 subcapítulos.
7. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M2 U01. ¿Quién es quién en el sistema financiero?» → «M2 U02. Bancos, casas de bolsa, aseguradoras y AFORE: ¿qué hace cada una?» → «M2 U03. Verifica antes de confiar» → «M2 U04. Tus derechos y dónde reclamar».

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M4 U06. Robo de identidad»; «M4 U07. Que dejen de llamarte: REPEP y REUS».
2. *Importar capítulo* > `1_libros/M4/M4_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M4 U06. Robo de identidad» con 3 subcapítulos.
3. *Importar capítulo* > `1_libros/M4/M4_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M4 U07. Que dejen de llamarte: REPEP y REUS» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M4 U01. Cómo piensa quien te quiere estafar» → «M4 U02. La llamada «del banco»» → «M4 U03. Mensajes y correos falsos» → «M4 U04. «Mamá, estoy en problemas»: extorsión y voces falsas» → «M4 U05. En el cajero y la sucursal» → «M4 U06. Robo de identidad» → «M4 U07. Que dejen de llamarte: REPEP y REUS» → «M4 U08. Si ya te pasó: tu plan de respuesta».

**Actividades H5P**
- Cambia: abre `M4 U06 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M4/M4_U06_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. En «M5 U02. El seguro del IPAB: hasta cuánto te protege», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «protege tus depósitos si un banco quiebra. Lo hace de forma automática y gratuita, sin trámites.» por «protege tus depósitos si un banco quiebra. Lo hace de forma automática y sin costo, sin trámites.» y guarda.
2. En «M5 U04. Ahorro con Cetes y BONDDIA», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U05. Tu tarjeta de crédito: pago mínimo, pago para no generar intereses y meses sin intereses.» y guarda.
3. *Importar capítulo* > `1_libros/M5/M5_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U05. Tu tarjeta de crédito: pago mínimo, pago para no generar intereses y meses sin intereses» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M5/M5_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U06. Tu historial de crédito: Buró, Círculo y ser aval» con 3 subcapítulos.
5. *Importar capítulo* > `1_libros/M5/M5_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U07. Aval, obligado solidario, fiador y referencia: ¿qué firmas?» con 3 subcapítulos.
6. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. Elige y revisa tus cuentas» → «M5 U02. El seguro del IPAB: hasta cuánto te protege» → «M5 U03. Tu fondo de emergencia» → «M5 U04. Ahorro con Cetes y BONDDIA» → «M5 U05. Tu tarjeta de crédito: pago mínimo, pago para no generar intereses y meses sin intereses» → «M5 U06. Tu historial de crédito: Buró, Círculo y ser aval» → «M5 U07. Aval, obligado solidario, fiador y referencia: ¿qué firmas?».

**Resumen de la sección:** *Editar sección* del Módulo 5 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M5_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U05 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U06 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U07 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. En «M6 U05. Inversiones milagro y «yo te lo manejo»», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M6 U06. Noticias, rumores y cambios: ajusta tu plan sin pánico.» y guarda.
2. *Importar capítulo* > `1_libros/M6/M6_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U06. Noticias, rumores y cambios: ajusta tu plan sin pánico» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M6 U01. Rendimiento, riesgo, plazo y liquidez» → «M6 U02. Qué hay en el menú» → «M6 U03. Lee tu estado de cuenta de inversión» → «M6 U04. Tu asesor: verifica, pregunta y compara» → «M6 U05. Inversiones milagro y «yo te lo manejo»» → «M6 U06. Noticias, rumores y cambios: ajusta tu plan sin pánico».

**Resumen de la sección:** *Editar sección* del Módulo 6 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M6_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M6 U06 · ¿Qué harías?`, archivo `2_h5p/M6/M6_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M7/M7_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 6 capítulos con sus subcapítulos, ya en orden.

**Actividades H5P**
- Cambia: abre `M7 U02 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U02_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M7 U03 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U03_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M7 U04 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U04_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M7 U05 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U05_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. En «M8 U04. Seguro de vida y gastos funerarios», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Revisa a quién nombraste. Si es un menor de edad, pregunta cómo se le entregaría. Actualizarlos es gratis.» por «Revisa a quién nombraste. Si es un menor de edad, pregunta cómo se le entregaría. Actualizarlos no tiene costo.» y guarda.
2. En «M8 U04. Seguro de vida y gastos funerarios», subcapítulo «Practica», *Editar*: cambia el texto «1-c: protege a tus dependientes. 2-a: para no perder aportaciones. 3-b: es gratis.» por «1-c: protege a tus dependientes. 2-a: para no perder aportaciones. 3-b: no tiene costo.» y guarda.
3. En «M8 U05. Casa y auto: lo básico», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado.» y guarda.
4. *Importar capítulo* > `1_libros/M8/M8_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Cómo funciona tu seguro de gastos médicos» → «M8 U02. ¿Por qué sube tanto y cómo bajarlo sin quedarte sin protección?» → «M8 U03. Compara y lee tu póliza» → «M8 U04. Seguro de vida y gastos funerarios» → «M8 U05. Casa y auto: lo básico» → «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U06 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M9 U01. ¿Tengo que declarar?».
2. *Importar capítulo* > `1_libros/M9/M9_U01_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U01. ¿Tengo que declarar?» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M9 U01. ¿Tengo que declarar?» → «M9 U02. Lo que te retienen» → «M9 U03. Deducciones personales y tu declaración anual».

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U05. Viudez o separación: los primeros 90 días», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U06. Tu casa: escrituras, predial y crédito en orden.» y guarda.
2. *Importar capítulo* > `1_libros/M10/M10_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U06. Tu casa: escrituras, predial y crédito en orden» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Testamento: tu decisión por escrito» → «M10 U02. Beneficiarios: cuentas, seguros y AFORE» → «M10 U03. Poder notarial y quién decide si tú no puedes» → «M10 U04. Ayudar a los hijos sin descuidar tu futuro» → «M10 U05. Viudez o separación: los primeros 90 días» → «M10 U06. Tu casa: escrituras, predial y crédito en orden».

**Resumen de la sección:** *Editar sección* del Módulo 10 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M10_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U06 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 11

**Libro `Lecciones del Módulo 11`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M11 U03. Tu plan de una página».
2. *Importar capítulo* > `1_libros/M11/M11_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M11 U03. Tu plan de una página» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M11 U01. Decidir con calma: tus reglas» → «M11 U02. Presión familiar y control del dinero» → «M11 U03. Tu plan de una página».

## 4. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 5. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 5 términos nuevos.

## 6. Preguntas y autoevaluaciones

1. **Texto corregido (9):** en el banco, abre cada pregunta y *Editar*; reemplaza el enunciado, las opciones y la retroalimentación con los de `4_preguntas/preguntas_corregidas_referencia.gift.txt` (mismo nombre, no la importes). Editar no borra intentos. Preguntas: M2 U01 P1, M2 U04 P2, M4 U06 P2, M4 U07 P3, M7 U02 P2, M7 U03 P3, M7 U04 P2, M8 U04 P3, M9 U01 P2.
2. **Nuevas (21):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Patrimonio v1.2/MN`.
3. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 1`: M1 U05 P1, M1 U05 P2, M1 U05 P3.
   - `Autoevaluación del Módulo 5`: M5 U05 P1, M5 U05 P2, M5 U05 P3, M5 U06 P1, M5 U06 P2, M5 U06 P3, M5 U07 P1, M5 U07 P2, M5 U07 P3.
   - `Autoevaluación del Módulo 6`: M6 U06 P1, M6 U06 P2, M6 U06 P3.
   - `Autoevaluación del Módulo 8`: M8 U06 P1, M8 U06 P2, M8 U06 P3.
   - `Autoevaluación del Módulo 10`: M10 U06 P1, M10 U06 P2, M10 U06 P3.

## 7. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
