# Actualización 1.1 → 1.2 · Tu Patrimonio, Tu Tranquilidad, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Qué cambia

- M8 U05. Casa y auto: lo básico · actualizada
- M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado · nueva
- M10 U05. Viudez o separación: los primeros 90 días · actualizada
- M10 U06. Tu casa: escrituras, predial y crédito en orden · nueva
- Libro «Materiales de apoyo»: capítulos 1, 4, 5, 6
- 6 preguntas nuevas; 1 términos nuevos de glosario.

## 1. Por módulo

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. En «M8 U05. Casa y auto: lo básico», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado.» y guarda.
2. *Importar capítulo* > `1_libros/M8/M8_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Cómo funciona tu seguro de gastos médicos» → «M8 U02. ¿Por qué sube tanto y cómo bajarlo sin quedarte sin protección?» → «M8 U03. Compara y lee tu póliza» → «M8 U04. Seguro de vida y gastos funerarios» → «M8 U05. Casa y auto: lo básico» → «M8 U06. Si llega un sismo o una inundación: tu patrimonio preparado».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U06 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U05. Viudez o separación: los primeros 90 días», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U06. Tu casa: escrituras, predial y crédito en orden.» y guarda.
2. *Importar capítulo* > `1_libros/M10/M10_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U06. Tu casa: escrituras, predial y crédito en orden» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Testamento: tu decisión por escrito» → «M10 U02. Beneficiarios: cuentas, seguros y AFORE» → «M10 U03. Poder notarial y quién decide si tú no puedes» → «M10 U04. Ayudar a los hijos sin descuidar tu futuro» → «M10 U05. Viudez o separación: los primeros 90 días» → «M10 U06. Tu casa: escrituras, predial y crédito en orden».

**Resumen de la sección:** *Editar sección* del Módulo 10 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M10_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U06 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 2. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 3. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 1 términos nuevos, así que no se duplican los que ya tienes.

## 4. Preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en las categorías que ya existen (6 preguntas).
2. En cada autoevaluación de abajo, abre *Editar cuestionario*. **Si el cuestionario ya tiene intentos, Moodle no deja cambiar las preguntas:** no borres intentos; déjalo como está y anótalo en tu reporte (las lecciones nuevas igual tienen su libro y su H5P). Si no tiene intentos, haz los cambios, 10 por página:
   - `Autoevaluación del Módulo 8`: agrega M8 U06 P1, M8 U06 P2, M8 U06 P3.
   - `Autoevaluación del Módulo 10`: agrega M10 U06 P1, M10 U06 P2, M10 U06 P3.

## 5. Lo que no cambia

Level Up (reglas y niveles), insignias, finalización del curso y constancia siguen igual: las H5P nuevas suman puntos solas con la regla de finalización. No hace falta volver a subir ningún otro archivo.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados y lo que no pudiste hacer.
