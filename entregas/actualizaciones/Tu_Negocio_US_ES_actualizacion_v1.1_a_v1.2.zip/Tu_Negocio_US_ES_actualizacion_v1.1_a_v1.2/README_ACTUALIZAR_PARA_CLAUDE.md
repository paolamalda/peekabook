# Actualización 1.1 → 1.2 · Tu Negocio, Tu Dinero, Tu Futuro (EE. UU., español) · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Qué cambia

- M1 U04. Registros en 10 minutos al día · actualizada
- M1 U05. Apuestas en línea: el dinero del negocio no se juega · nueva
- M7 U05. Robo de identidad y llamadas no deseadas · actualizada
- M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos · nueva
- M7 U07. Si llega un desastre: tu negocio preparado · nueva
- M8 U03. Tus números del mes · actualizada
- M8 U04. Estrés, negocio y familia · nueva
- Libro «Materiales de apoyo»: capítulos 1, 4, 5, 6
- 12 preguntas nuevas; 1 términos nuevos de glosario.

## 1. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. En «M1 U04. Registros en 10 minutos al día», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M1 U05. Apuestas en línea: el dinero del negocio no se juega.» y guarda.
2. *Importar capítulo* > `1_libros/M1/M1_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U05. Apuestas en línea: el dinero del negocio no se juega» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Tu negocio gana o solo vende?» → «M1 U02. Separa el dinero del negocio y de tu casa» → «M1 U03. Págate un sueldo» → «M1 U04. Registros en 10 minutos al día» → «M1 U05. Apuestas en línea: el dinero del negocio no se juega».

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U05 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U05. Robo de identidad y llamadas no deseadas», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos.» y guarda.
2. *Importar capítulo* > `1_libros/M7/M7_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos» con 3 subcapítulos.
3. *Importar capítulo* > `1_libros/M7/M7_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U07. Si llega un desastre: tu negocio preparado» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. Tu salud si trabajas por tu cuenta» → «M7 U02. Seguros para tu negocio» → «M7 U03. Fraudes a negocios» → «M7 U04. Tu marca y tu nombre» → «M7 U05. Robo de identidad y llamadas no deseadas» → «M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos» → «M7 U07. Si llega un desastre: tu negocio preparado».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U06 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U07 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. En «M8 U03. Tus números del mes», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U04. Estrés, negocio y familia.» y guarda.
2. *Importar capítulo* > `1_libros/M8/M8_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U04. Estrés, negocio y familia» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Contratar ayuda» → «M8 U02. Vender en línea y en plataformas» → «M8 U03. Tus números del mes» → «M8 U04. Estrés, negocio y familia».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U04 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 2. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 3. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 1 términos nuevos, así que no se duplican los que ya tienes.

## 4. Preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en las categorías que ya existen (12 preguntas).
2. En cada autoevaluación de abajo, abre *Editar cuestionario*. **Si el cuestionario ya tiene intentos, Moodle no deja cambiar las preguntas:** no borres intentos; déjalo como está y anótalo en tu reporte (las lecciones nuevas igual tienen su libro y su H5P). Si no tiene intentos, haz los cambios, 10 por página:
   - `Autoevaluación del Módulo 1`: agrega M1 U05 P1, M1 U05 P2, M1 U05 P3.
   - `Autoevaluación del Módulo 7`: agrega M7 U06 P1, M7 U06 P2, M7 U06 P3, M7 U07 P1, M7 U07 P2, M7 U07 P3.
   - `Autoevaluación del Módulo 8`: agrega M8 U04 P1, M8 U04 P2, M8 U04 P3.

## 5. Lo que no cambia

Level Up (reglas y niveles), insignias, finalización del curso y constancia siguen igual: las H5P nuevas suman puntos solas con la regla de finalización. No hace falta volver a subir ningún otro archivo.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados y lo que no pudiste hacer.
