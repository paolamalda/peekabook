# Actualización 1.1 → 1.2 · Tu Negocio, Tu Dinero, Tu Futuro · EE. UU. · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M1: lecciones nuevas U05, U06; M1 U01: texto corregido; M1 U04: texto corregido; M2 U01: texto corregido; M2 U04: texto corregido; M3: lección nueva U04; M3 U03: texto corregido; M4 U01: texto corregido; M5 U01: texto corregido; M5 U02: texto corregido; M5 U03: texto corregido; M6: lección nueva U05; M6 U02: texto corregido; M6 U03: texto corregido; M6 U04: texto corregido; M7: lecciones nuevas U06, U07; M7 U04: texto corregido; M7 U05: texto corregido; M8: lecciones nuevas U04, U05, U06; M8 U02: texto corregido; M8 U03: texto corregido; M9 U02: texto corregido; M9 U03: texto corregido; Apoyo: capítulos 1, 4, 5, 6 corregidos; Preguntas: 27 nuevas; Preguntas: 6 con texto corregido; Glosario: 5 términos nuevos; Apoyo: herramientas en Excel (recurso nuevo); Plataforma: categoría con versión, insignias con nombre del curso, constancia estándar, encuestas, curso visible con clave y mosaicos.

## 1. Ajustes de plataforma (una sola vez)

1. **Categoría de preguntas:** en *Banco de preguntas > Categorías*, renombra `Tu Negocio US ES` a `Tu Negocio US ES v1.2` (sus subcategorías M1… se quedan).
2. **Insignias:** renombra cada insignia para que sea única en la plataforma: «Dinero separado» → «Dinero separado · Tu Negocio US ES»; «Precio justo» → «Precio justo · Tu Negocio US ES»; «Flujo bajo control» → «Flujo bajo control · Tu Negocio US ES»; «Negocio formal» → «Negocio formal · Tu Negocio US ES»; «Crédito inteligente» → «Crédito inteligente · Tu Negocio US ES»; «Negocio protegido» → «Negocio protegido · Tu Negocio US ES»; «Crecer con orden» → «Crecer con orden · Tu Negocio US ES»; «Plan completo» → «Plan completo · Tu Negocio US ES». Las insignias ya otorgadas se conservan.
3. **Constancia:** edita el Certificado personalizado, quita la imagen de fondo y usa la plantilla estándar de la plataforma con: título «Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.», línea «por concluir el programa de bienestar financiero Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.» y temas Dinero separado · Precio y flujo · Impuestos y formalidad · Crédito y protección · Crecer y futuro (también en `7_constancia/`). Agrega la **Encuesta final** como condición de acceso.
4. **Visibilidad e inscripción:** curso **visible**; *Métodos de inscripción* > **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes). Sin acceso de invitados.
5. **Formato:** si **Mosaicos** (Tiles) está instalado, cambia el formato del curso a Mosaicos con el progreso en los mosaicos **como porcentaje**; si no, deja Temas.
6. **Encuestas:** con el módulo **Retroalimentación** (anónima), crea `Encuesta de inicio` (sección General), `Encuesta final`, `Seguimiento a 30 días` y `Seguimiento a 90 días` (última sección) e importa los XML de `6_encuestas/` (`encuestas.md` los explica). Restringe los seguimientos por fecha («[por definir]»).
7. **Catálogo:** actualiza la ficha del curso con `tarjeta_catalogo.md`.

## 2. Herramientas en Excel

En la sección «Materiales de apoyo», agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con `8_herramientas/Herramientas_TNDF.xlsx`. Mostrar: "Forzar descarga". Descripción: "Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver". No cuenta para la finalización del curso.

## 3. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M1/M1_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 6 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Cambia: abre `M1 U04 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M1/M1_U04_que_harias.h5p`. Los intentos anteriores se conservan.
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U05 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U06 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. En «M2 U01. Costos fijos y variables», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Trabajas gratis» por «Trabajas sin cobrar» y guarda.
2. En «M2 U01. Costos fijos y variables», subcapítulo «Practica», *Editar*: cambia el texto «1-b: sube con cada venta. 2-a: $600 entre 200. 3-c: sin él trabajas gratis.» por «1-b: sube con cada venta. 2-a: $600 entre 200. 3-c: sin él trabajas sin cobrar.» y guarda.
3. En «M2 U04. Inventario y merma», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «El proveedor ofrece a Don Ramón una caja gratis si compra 10 de un producto que vende poco.» por «El proveedor ofrece a Don Ramón una caja sin costo si compra 10 de un producto que vende poco.» y guarda.

**Actividades H5P**
- Cambia: abre `M2 U04 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M2/M2_U04_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 3

**Libro `Lecciones del Módulo 3`**
1. En «M3 U03. Tu reserva y las temporadas bajas», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M3 U04. Inflación, tasas e interés compuesto en tu negocio.» y guarda.
2. *Importar capítulo* > `1_libros/M3/M3_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M3 U04. Inflación, tasas e interés compuesto en tu negocio» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M3 U01. Ganar no es tener efectivo» → «M3 U02. Crédito a clientes, facturas y cobranza» → «M3 U03. Tu reserva y las temporadas bajas» → «M3 U04. Inflación, tasas e interés compuesto en tu negocio».

**Resumen de la sección:** *Editar sección* del Módulo 3 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M3_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M3 U04 · ¿Qué harías?`, archivo `2_h5p/M3/M3_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. En «M4 U01. Efectivo, tarjeta, apps o link de pago», subcapítulo «M4 U01. Efectivo, tarjeta, apps o link de pago», *Editar*: cambia el texto «Los clientes de Don Ramón le piden pagar con tarjeta y con apps. Le ofrecen un lector de tarjetas «gratis», pero no sabe cuánto le cobrarán ni cuándo le depositan. En esta lección verás cómo comparar.» por «Los clientes de Don Ramón le piden pagar con tarjeta y con apps. Le ofrecen un lector de tarjetas «sin costo», pero no sabe cuánto le cobrarán ni cuándo le depositan. En esta lección verás cómo comparar.» y guarda.
2. En «M4 U01. Efectivo, tarjeta, apps o link de pago», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «A Don Ramón le ofrecen un lector «gratis» con contrato de dos años.» por «A Don Ramón le ofrecen un lector «sin costo» con contrato de dos años.» y guarda.

**Actividades H5P**
- Cambia: abre `M4 U01 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M4/M4_U01_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M5 U02. Números y permisos: EIN, ITIN y licencias»; «M5 U03. Tus impuestos federales como dueño».
2. En «M5 U01. ¿Dueño único, LLC u otra forma?», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «las reglas y costos de tu estado en el sitio del Secretary of State; si tienes dudas, consulta a un contador o a un centro gratuito de la SBA (SBDC).» por «las reglas y costos de tu estado en el sitio del Secretary of State; si tienes dudas, consulta a un contador o a un centro sin costo de la SBA (SBDC).» y guarda.
3. *Importar capítulo* > `1_libros/M5/M5_U02_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U02. Números y permisos: EIN, ITIN y licencias» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M5/M5_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U03. Tus impuestos federales como dueño» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. ¿Dueño único, LLC u otra forma?» → «M5 U02. Números y permisos: EIN, ITIN y licencias» → «M5 U03. Tus impuestos federales como dueño» → «M5 U04. Pagos trimestrales y formularios 1099» → «M5 U05. El impuesto sobre ventas (sales tax)».

**Actividades H5P**
- Cambia: abre `M5 U02 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M5/M5_U02_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M6/M6_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 5 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 6 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M6_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M6 U05 · ¿Qué harías?`, archivo `2_h5p/M6/M6_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M7 U05. Robo de identidad y llamadas no deseadas».
2. En «M7 U04. Tu marca y tu nombre», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Si alguien dice que tu nombre es su marca, verifica en la USPTO antes de responder. Si su registro es real y cubre tus productos, cambiar de nombre suele ser lo más prudente. Hay clínicas legales gratuitas de propiedad intelectual en algunas universidades.» por «Si alguien dice que tu nombre es su marca, verifica en la USPTO antes de responder. Si su registro es real y cubre tus productos, cambiar de nombre suele ser lo más prudente. Hay clínicas legales sin costo de propiedad intelectual en algunas universidades.» y guarda.
3. *Importar capítulo* > `1_libros/M7/M7_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U05. Robo de identidad y llamadas no deseadas» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M7/M7_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos» con 3 subcapítulos.
5. *Importar capítulo* > `1_libros/M7/M7_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U07. Si llega un desastre: tu negocio preparado» con 3 subcapítulos.
6. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. Tu salud si trabajas por tu cuenta» → «M7 U02. Seguros para tu negocio» → «M7 U03. Fraudes a negocios» → «M7 U04. Tu marca y tu nombre» → «M7 U05. Robo de identidad y llamadas no deseadas» → «M7 U06. Fraudes con inteligencia artificial: voces, videos y mensajes falsos» → «M7 U07. Si llega un desastre: tu negocio preparado».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U06 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U07 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M8/M8_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 6 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Cambia: abre `M8 U01 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M8/M8_U01_que_harias.h5p`. Los intentos anteriores se conservan.
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U04 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U05 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U06 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M9 U03. Tu plan de una página».
2. En «M9 U02. Si el negocio cambia o si faltas», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «El equipo, el inventario y el dinero del negocio son parte de tu patrimonio. Un testamento o un fideicomiso en vida (living trust) y beneficiarios actualizados en cuentas, IRA y seguros evitan trámites largos a tu familia. Hay clínicas legales gratuitas o de bajo costo.» por «El equipo, el inventario y el dinero del negocio son parte de tu patrimonio. Un testamento o un fideicomiso en vida (living trust) y beneficiarios actualizados en cuentas, IRA y seguros evitan trámites largos a tu familia. Hay clínicas legales sin costo o de bajo costo.» y guarda.
3. *Importar capítulo* > `1_libros/M9/M9_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U03. Tu plan de una página» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M9 U01. Tu retiro si trabajas por tu cuenta» → «M9 U02. Si el negocio cambia o si faltas» → «M9 U03. Tu plan de una página».

## 4. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 5. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 5 términos nuevos.

## 6. Preguntas y autoevaluaciones

1. **Texto corregido (6):** en el banco, abre cada pregunta y *Editar*; reemplaza el enunciado, las opciones y la retroalimentación con los de `4_preguntas/preguntas_corregidas_referencia.gift.txt` (mismo nombre, no la importes). Editar no borra intentos. Preguntas: M1 U01 P3, M1 U04 P3, M2 U01 P3, M5 U02 P1, M6 U03 P3, M7 U05 P1.
2. **Nuevas (27):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Negocio US ES v1.2/MN`.
3. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 1`: M1 U05 P1, M1 U05 P2, M1 U05 P3, M1 U06 P1, M1 U06 P2, M1 U06 P3.
   - `Autoevaluación del Módulo 3`: M3 U04 P1, M3 U04 P2, M3 U04 P3.
   - `Autoevaluación del Módulo 6`: M6 U05 P1, M6 U05 P2, M6 U05 P3.
   - `Autoevaluación del Módulo 7`: M7 U06 P1, M7 U06 P2, M7 U06 P3, M7 U07 P1, M7 U07 P2, M7 U07 P3.
   - `Autoevaluación del Módulo 8`: M8 U04 P1, M8 U04 P2, M8 U04 P3, M8 U05 P1, M8 U05 P2, M8 U05 P3, M8 U06 P1, M8 U06 P2, M8 U06 P3.

## 7. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
