# Actualización 1.1 → 1.2 · Tu Turno, Tu Dinero, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Qué cambia

- M1 U01. ¿Cuánto entra de verdad? · actualizada
- M1 U04. Aparta primero · actualizada
- M1 U05. Dinero y estrés: cómo hablarlo en casa · nueva
- M3 U04. Tu plan para salir de deudas · actualizada
- M3 U05. Apuestas en línea: cuando el juego se vuelve deuda · nueva
- M6 U05. Tu identidad y que dejen de llamarte · actualizada
- M6 U06. Voces y videos falsos con inteligencia artificial · nueva
- M7 U03. Seguro de vida, gastos funerarios y beneficiarios · actualizada
- M7 U04. Si llega un desastre: sismo, inundación o incendio · nueva
- M8 U02. Un ingreso extra en tus días de descanso · actualizada
- M8 U03. Tu casa: Infonavit y el crédito de 100 puntos · nueva
- M8 U04. Tu plan de una página · actualizada
- Libro «Materiales de apoyo»: capítulos 1, 4, 5, 6
- 15 preguntas nuevas; 2 términos nuevos de glosario.

## 1. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M1 U01. ¿Cuánto entra de verdad?».
2. En «M1 U04. Aparta primero», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M1 U05. Dinero y estrés: cómo hablarlo en casa.» y guarda.
3. *Importar capítulo* > `1_libros/M1/M1_U01_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U01. ¿Cuánto entra de verdad?» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M1/M1_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U05. Dinero y estrés: cómo hablarlo en casa» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Cuánto entra de verdad?» → «M1 U02. Tu presupuesto de turno» → «M1 U03. Los gastos del turno que no ves» → «M1 U04. Aparta primero» → «M1 U05. Dinero y estrés: cómo hablarlo en casa».

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U05 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 3

**Libro `Lecciones del Módulo 3`**
1. En «M3 U04. Tu plan para salir de deudas», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M3 U05. Apuestas en línea: cuando el juego se vuelve deuda.» y guarda.
2. *Importar capítulo* > `1_libros/M3/M3_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M3 U05. Apuestas en línea: cuando el juego se vuelve deuda» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M3 U01. ¿Cuánto debes en total?» → «M3 U02. Lo que de verdad cuesta un préstamo» → «M3 U03. Prestamistas y «gota a gota»» → «M3 U04. Tu plan para salir de deudas» → «M3 U05. Apuestas en línea: cuando el juego se vuelve deuda».

**Resumen de la sección:** *Editar sección* del Módulo 3 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M3_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M3 U05 · ¿Qué harías?`, archivo `2_h5p/M3/M3_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. En «M6 U05. Tu identidad y que dejen de llamarte», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M6 U06. Voces y videos falsos con inteligencia artificial.» y guarda.
2. *Importar capítulo* > `1_libros/M6/M6_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U06. Voces y videos falsos con inteligencia artificial» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M6 U01. Llamadas y mensajes falsos» → «M6 U02. Apps «montadeudas»» → «M6 U03. Extorsión telefónica» → «M6 U04. Si ya te pasó: qué hacer» → «M6 U05. Tu identidad y que dejen de llamarte» → «M6 U06. Voces y videos falsos con inteligencia artificial».

**Resumen de la sección:** *Editar sección* del Módulo 6 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M6_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M6 U06 · ¿Qué harías?`, archivo `2_h5p/M6/M6_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U03. Seguro de vida, gastos funerarios y beneficiarios», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M7 U04. Si llega un desastre: sismo, inundación o incendio.» y guarda.
2. *Importar capítulo* > `1_libros/M7/M7_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U04. Si llega un desastre: sismo, inundación o incendio» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. Tu fondo de emergencia, de poco a poco» → «M7 U02. Tu salud y la de tu familia: estar preparado» → «M7 U03. Seguro de vida, gastos funerarios y beneficiarios» → «M7 U04. Si llega un desastre: sismo, inundación o incendio».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U04 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M8 U03. Tu plan de una página».
2. En «M8 U02. Un ingreso extra en tus días de descanso», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U03. Tu plan de una página.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U03. Tu casa: Infonavit y el crédito de 100 puntos.» y guarda.
3. *Importar capítulo* > `1_libros/M8/M8_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U03. Tu casa: Infonavit y el crédito de 100 puntos» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M8/M8_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U04. Tu plan de una página» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Ahorro para el retiro por tu cuenta» → «M8 U02. Un ingreso extra en tus días de descanso» → «M8 U03. Tu casa: Infonavit y el crédito de 100 puntos» → «M8 U04. Tu plan de una página».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Cambia: abre `M8 U03 · ¿Qué harías?` > *Editar ajustes*, cambia el nombre a `M8 U04 · ¿Qué harías?` y reemplaza el archivo por `2_h5p/M8/M8_U04_que_harias.h5p`. Los intentos anteriores se conservan.
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U03 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U03_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 2. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 3. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 2 términos nuevos, así que no se duplican los que ya tienes.

## 4. Preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en las categorías que ya existen (15 preguntas).
2. En cada autoevaluación de abajo, abre *Editar cuestionario*. **Si el cuestionario ya tiene intentos, Moodle no deja cambiar las preguntas:** no borres intentos; déjalo como está y anótalo en tu reporte (las lecciones nuevas igual tienen su libro y su H5P). Si no tiene intentos, haz los cambios, 10 por página:
   - `Autoevaluación del Módulo 1`: agrega M1 U05 P1, M1 U05 P2, M1 U05 P3.
   - `Autoevaluación del Módulo 3`: agrega M3 U05 P1, M3 U05 P2, M3 U05 P3.
   - `Autoevaluación del Módulo 6`: agrega M6 U06 P1, M6 U06 P2, M6 U06 P3.
   - `Autoevaluación del Módulo 7`: agrega M7 U04 P1, M7 U04 P2, M7 U04 P3.
   - `Autoevaluación del Módulo 8`: agrega M8 U03 P1, M8 U03 P2, M8 U03 P3.

## 5. Lo que no cambia

Level Up (reglas y niveles), insignias, finalización del curso y constancia siguen igual: las H5P nuevas suman puntos solas con la regla de finalización. No hace falta volver a subir ningún otro archivo.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados y lo que no pudiste hacer.
