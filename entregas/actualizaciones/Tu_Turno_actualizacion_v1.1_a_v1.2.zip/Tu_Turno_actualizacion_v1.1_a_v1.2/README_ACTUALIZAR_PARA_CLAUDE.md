# Actualización 1.1 → 1.2 · Tu Turno, Tu Dinero, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.1 a la 1.2. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M1: lecciones nuevas U05, U06; M1 U01: texto corregido; M1 U04: texto corregido; M2: lecciones nuevas U04, U05, U06; M2 U03: texto corregido; M3: lección nueva U05; M3 U04: texto corregido; M4: lección nueva U03; M4 U02: texto corregido; M5: lección nueva U04; M5 U01: texto corregido; M5 U02: texto corregido; M5 U03: texto corregido; M6: lección nueva U06; M6 U05: texto corregido; M7: lección nueva U04; M7 U03: texto corregido; M8 U01: texto corregido; M8 U02: texto corregido; M8 U03: texto corregido; Apoyo: capítulos 1, 2, 4, 5, 6 corregidos; Preguntas: 30 nuevas; Preguntas: 5 con texto corregido; Glosario: 8 términos nuevos; Apoyo: herramientas en Excel (recurso nuevo); Plataforma: categoría con versión, insignias con nombre del curso, constancia estándar, encuestas, curso visible con clave y mosaicos.

## 1. Ajustes de plataforma (una sola vez)

1. **Categoría de preguntas:** en *Banco de preguntas > Categorías*, renombra `Tu Turno` a `Tu Turno v1.2` (sus subcategorías M1… se quedan).
2. **Insignias:** renombra cada insignia para que sea única en la plataforma: «Quincena en orden» → «Quincena en orden · Tu Turno»; «Deudas claras» → «Deudas claras · Tu Turno»; «Tanda segura» → «Tanda segura · Tu Turno»; «Buró sin miedo» → «Buró sin miedo · Tu Turno»; «Nadie me extorsiona» → «Nadie me extorsiona · Tu Turno»; «Familia protegida» → «Familia protegida · Tu Turno»; «Futuro en marcha» → «Futuro en marcha · Tu Turno»; «Plan completo» → «Plan completo · Tu Turno». Las insignias ya otorgadas se conservan.
3. **Constancia:** edita el Certificado personalizado, quita la imagen de fondo y usa la plantilla estándar de la plataforma con: título «Tu Turno, Tu Dinero, Tu Futuro», línea «por concluir el programa de bienestar financiero Tu Turno, Tu Dinero, Tu Futuro» y temas Quincena y cuenta · Deudas y tandas · Buró y fraudes · Familia · Futuro (también en `7_constancia/`). Agrega la **Encuesta final** como condición de acceso.
4. **Visibilidad e inscripción:** curso **visible**; *Métodos de inscripción* > **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes). Sin acceso de invitados.
5. **Formato:** si **Mosaicos** (Tiles) está instalado, cambia el formato del curso a Mosaicos con el progreso en los mosaicos **como porcentaje**; si no, deja Temas.
6. **Encuestas:** con el módulo **Retroalimentación** (anónima), crea `Encuesta de inicio` (sección General), `Encuesta final`, `Seguimiento a 30 días` y `Seguimiento a 90 días` (última sección) e importa los XML de `6_encuestas/` (`encuestas.md` los explica). Restringe los seguimientos por fecha («[por definir]»).
7. **Catálogo:** actualiza la ficha del curso con `tarjeta_catalogo.md`.

## 2. Herramientas en Excel

En la sección «Materiales de apoyo», agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con `8_herramientas/Herramientas_TTDF.xlsx`. Mostrar: "Forzar descarga". Descripción: "Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver". No cuenta para la finalización del curso.

## 3. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M1 U01. ¿Cuánto entra de verdad?».
2. En «M1 U04. Aparta primero», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M1 U05. Dinero y estrés: cómo hablarlo en casa.» y guarda.
3. *Importar capítulo* > `1_libros/M1/M1_U01_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U01. ¿Cuánto entra de verdad?» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M1/M1_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U05. Dinero y estrés: cómo hablarlo en casa» con 3 subcapítulos.
5. *Importar capítulo* > `1_libros/M1/M1_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U06. Compra inteligente: precio por unidad, publicidad y pagos chiquitos» con 3 subcapítulos.
6. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Cuánto entra de verdad?» → «M1 U02. Tu presupuesto de turno» → «M1 U03. Los gastos del turno que no ves» → «M1 U04. Aparta primero» → «M1 U05. Dinero y estrés: cómo hablarlo en casa» → «M1 U06. Compra inteligente: precio por unidad, publicidad y pagos chiquitos».

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U05 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U06 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M2/M2_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 6 capítulos con sus subcapítulos, ya en orden.

**Resumen de la sección:** *Editar sección* del Módulo 2 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M2_resumen.html`.

**Actividades H5P**
- Cambia: abre `M2 U03 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M2/M2_U03_que_harias.h5p`. Los intentos anteriores se conservan.
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M2 U04 · ¿Qué harías?`, archivo `2_h5p/M2/M2_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M2 U05 · ¿Qué harías?`, archivo `2_h5p/M2/M2_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M2 U06 · ¿Qué harías?`, archivo `2_h5p/M2/M2_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 3

**Libro `Lecciones del Módulo 3`**
1. En «M3 U04. Tu plan para salir de deudas», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M3 U05. Apuestas en línea: cuando el juego se vuelve deuda.» y guarda.
2. *Importar capítulo* > `1_libros/M3/M3_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M3 U05. Apuestas en línea: cuando el juego se vuelve deuda» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M3 U01. ¿Cuánto debes en total?» → «M3 U02. Lo que de verdad cuesta un préstamo» → «M3 U03. Prestamistas y «gota a gota»» → «M3 U04. Tu plan para salir de deudas» → «M3 U05. Apuestas en línea: cuando el juego se vuelve deuda».

**Resumen de la sección:** *Editar sección* del Módulo 3 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M3_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M3 U05 · ¿Qué harías?`, archivo `2_h5p/M3/M3_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. En «M4 U02. Tu tanda con reglas o tu propio ahorro», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M4 U03. Tu casa: Infonavit y el crédito de 100 puntos.» y guarda.
2. *Importar capítulo* > `1_libros/M4/M4_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M4 U03. Tu casa: Infonavit y el crédito de 100 puntos» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M4 U01. Tandas: cómo funcionan y qué puede salir mal» → «M4 U02. Tu tanda con reglas o tu propio ahorro» → «M4 U03. Tu casa: Infonavit y el crédito de 100 puntos».

**Resumen de la sección:** *Editar sección* del Módulo 4 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M4_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M4 U03 · ¿Qué harías?`, archivo `2_h5p/M4/M4_U03_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M5 U02. Tu reporte gratis y cómo reclamar».
2. En «M5 U01. Qué es el Buró de Crédito», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Beto pidió su reporte gratis. No estaba «boletinado»: tenía un atraso en una tienda. Al pagarlo y mantener sus pagos a tiempo, su historial empezó a mejorar.» por «Beto pidió su reporte sin costo. No estaba «boletinado»: tenía un atraso en una tienda. Al pagarlo y mantener sus pagos a tiempo, su historial empezó a mejorar.» y guarda.
3. En «M5 U01. Qué es el Buró de Crédito», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Pide su reporte gratis para ver qué hay de verdad.» por «Pide su reporte sin costo para ver qué hay de verdad.» y guarda.
4. En «M5 U01. Qué es el Buró de Crédito», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U02. Tu reporte gratis y cómo reclamar.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U02. Tu reporte sin costo y cómo reclamar.» y guarda.
5. En «M5 U03. Cómo mejorar tu historial», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Los despachos que prometen «limpiar tu Buró» a cambio de dinero no pueden borrar información correcta. Si hay un error, lo reclamas tú, gratis (M5 U02).» por «Los despachos que prometen «limpiar tu Buró» a cambio de dinero no pueden borrar información correcta. Si hay un error, lo reclamas tú, sin costo (M5 U02).» y guarda.
6. En «M5 U03. Cómo mejorar tu historial», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?.» y guarda.
7. *Importar capítulo* > `1_libros/M5/M5_U02_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U02. Tu reporte sin costo y cómo reclamar» con 3 subcapítulos.
8. *Importar capítulo* > `1_libros/M5/M5_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?» con 3 subcapítulos.
9. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. Qué es el Buró de Crédito» → «M5 U02. Tu reporte sin costo y cómo reclamar» → «M5 U03. Cómo mejorar tu historial» → «M5 U04. Aval, obligado solidario, fiador y referencia: ¿qué firmas?».

**Resumen de la sección:** *Editar sección* del Módulo 5 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M5_resumen.html`.

**Actividades H5P**
- Cambia: abre `M5 U01 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M5/M5_U01_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M5 U02 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M5/M5_U02_que_harias.h5p`. Los intentos anteriores se conservan.
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U04 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M6 U05. Tu identidad y que dejen de llamarte».
2. *Importar capítulo* > `1_libros/M6/M6_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U05. Tu identidad y que dejen de llamarte» con 3 subcapítulos.
3. *Importar capítulo* > `1_libros/M6/M6_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U06. Voces y videos falsos con inteligencia artificial» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M6 U01. Llamadas y mensajes falsos» → «M6 U02. Apps «montadeudas»» → «M6 U03. Extorsión telefónica» → «M6 U04. Si ya te pasó: qué hacer» → «M6 U05. Tu identidad y que dejen de llamarte» → «M6 U06. Voces y videos falsos con inteligencia artificial».

**Resumen de la sección:** *Editar sección* del Módulo 6 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M6_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M6 U06 · ¿Qué harías?`, archivo `2_h5p/M6/M6_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. En «M7 U03. Seguro de vida, gastos funerarios y beneficiarios», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M7 U04. Si llega un desastre: sismo, inundación o incendio.» y guarda.
2. *Importar capítulo* > `1_libros/M7/M7_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U04. Si llega un desastre: sismo, inundación o incendio» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. Tu fondo de emergencia, de poco a poco» → «M7 U02. Tu salud y la de tu familia: estar preparado» → «M7 U03. Seguro de vida, gastos funerarios y beneficiarios» → «M7 U04. Si llega un desastre: sismo, inundación o incendio».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M7 U04 · ¿Qué harías?`, archivo `2_h5p/M7/M7_U04_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. Abre el libro, *Editar* y borra **todos** sus capítulos (el libro, su finalización y sus visitas se conservan).
2. *Importar capítulo* > `1_libros/M8/M8_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Crea 3 capítulos con sus subcapítulos, ya en orden.

**Actividades H5P**
- Cambia: abre `M8 U01 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M8/M8_U01_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 4. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 2 «Casos integradores»: bórralo, *Importar capítulo* > `1_libros/Apoyo/02_apoyo.zip` y súbelo con las flechas a la posición 2.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 5. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 8 términos nuevos.

## 6. Preguntas y autoevaluaciones

1. **Texto corregido (5):** en el banco, abre cada pregunta y *Editar*; reemplaza el enunciado, las opciones y la retroalimentación con los de `4_preguntas/preguntas_corregidas_referencia.gift.txt` (mismo nombre, no la importes). Editar no borra intentos. Preguntas: M2 U03 P1, M5 U02 P1, M5 U02 P2, M6 U05 P1, M8 U01 P2.
2. **Nuevas (30):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Turno v1.2/MN`.
3. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 1`: M1 U05 P1, M1 U05 P2, M1 U05 P3, M1 U06 P1, M1 U06 P2, M1 U06 P3.
   - `Autoevaluación del Módulo 2`: M2 U04 P1, M2 U04 P2, M2 U04 P3, M2 U05 P1, M2 U05 P2, M2 U05 P3, M2 U06 P1, M2 U06 P2, M2 U06 P3.
   - `Autoevaluación del Módulo 3`: M3 U05 P1, M3 U05 P2, M3 U05 P3.
   - `Autoevaluación del Módulo 4`: M4 U03 P1, M4 U03 P2, M4 U03 P3.
   - `Autoevaluación del Módulo 5`: M5 U04 P1, M5 U04 P2, M5 U04 P3.
   - `Autoevaluación del Módulo 6`: M6 U06 P1, M6 U06 P2, M6 U06 P3.
   - `Autoevaluación del Módulo 7`: M7 U04 P1, M7 U04 P2, M7 U04 P3.

## 7. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
