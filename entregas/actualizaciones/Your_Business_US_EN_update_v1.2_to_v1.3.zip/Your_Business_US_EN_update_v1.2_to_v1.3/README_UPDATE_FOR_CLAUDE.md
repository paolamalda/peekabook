# Update 1.2 → 1.3 · Your Business, Your Money, Your Future · U.S. · for Claude

This package updates a course **already installed** in Moodle 3.10 from version 1.2 to 1.3. It only contains what changed. Activity names stay the same. **Do not reinstall the course and do not delete activities, attempts, grades, badges or Level Up points.**

Before starting: make a course backup (*Course administration > Backup*, no user data is fine) and turn editing on. If a step can't be done, skip it and report it at the end.

## Change list

M5 U02: text corrected; M5 U03: text corrected; M6 U03: text corrected; M6 U04: text corrected; M7 U05: text corrected; M8 U05: text corrected; M9: new lesson U04; M9 U03: text corrected; Support book: chapters 4, 5 corrected; Questions: 3 new; Questions: 2 with corrected text; question category: Your Business US EN v1.3.

## 1. Question category

In *Question bank > Categories*, rename `Your Business US EN v1.2` to `Your Business US EN v1.3` (its M1… subcategories stay). Do it before importing questions.

## 2. By module

### Module 5

**Book `Module 5 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M5 U02. Numbers and permits: EIN, ITIN and licenses».
2. In "M5 U03. Your federal taxes as an owner", subchapter "Go deeper · +5 min", *Edit*: change the text "Free or low-cost help" to "No-cost or low-cost help" and save.
3. *Import chapter* > `1_books/M5/M5_U02_lesson.zip`, type "Each HTML file represents one chapter". It creates "M5 U02. Numbers and permits: EIN, ITIN and licenses" with 3 subchapters.
4. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M5 U01. Sole proprietor, LLC or something else?» → «M5 U02. Numbers and permits: EIN, ITIN and licenses» → «M5 U03. Your federal taxes as an owner» → «M5 U04. Quarterly payments and 1099 forms» → «M5 U05. Sales tax».

### Module 6

**Book `Module 6 lessons`**
1. In "M6 U03. The total cost: APR, fees and guarantees", subchapter "Practice", *Edit*: change the text "c) Free insurance" to "c) No-cost insurance" and save.
2. In "M6 U04. Don't mix debts, and be careful about cosigning", subchapter "Go deeper · +5 min", *Edit*: change the text "Free report" to "No-cost report" and save.

### Module 7

**Book `Module 7 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M7 U05. Identity theft and unwanted calls».
2. *Import chapter* > `1_books/M7/M7_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M7 U05. Identity theft and unwanted calls" with 3 subchapters.
3. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M7 U01. Your health when you work for yourself» → «M7 U02. Insurance for your business» → «M7 U03. Scams against businesses» → «M7 U04. Your brand and your name» → «M7 U05. Identity theft and unwanted calls» → «M7 U06. AI scams: fake voices, videos and messages» → «M7 U07. If disaster strikes: your business ready».

### Module 8

**Book `Module 8 lessons`**
1. Delete these chapters (each with its 3 subchapters; book completion is not lost): «M8 U05. Your one-page business plan and how to pitch it».
2. *Import chapter* > `1_books/M8/M8_U05_lesson.zip`, type "Each HTML file represents one chapter". It creates "M8 U05. Your one-page business plan and how to pitch it" with 3 subchapters.
3. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M8 U01. Hiring help» → «M8 U02. Selling online and on platforms» → «M8 U03. Your monthly numbers» → «M8 U04. Stress, business and family» → «M8 U05. Your one-page business plan and how to pitch it» → «M8 U06. Your business and its surroundings: competition, economy, community and rule changes».

### Module 9

**Book `Module 9 lessons`**
1. In "M9 U03. Your one-page plan", subchapter "Practice", *Edit*: change the text "Complete the activity and the quiz to earn points. Next lesson." to "Complete the activity and the quiz to earn points. Next lesson: M9 U04. If you're not there: beneficiary accounts, your home, digital access and taxes." and save.
2. *Import chapter* > `1_books/M9/M9_U04_lesson.zip`, type "Each HTML file represents one chapter". It creates "M9 U04. If you're not there: beneficiary accounts, your home, digital access and taxes" with 3 subchapters.
3. Moodle adds imported chapters at the end. Use the arrows in *Edit* to leave the main chapters in this order (each with its subchapters): «M9 U01. Your retirement when you work for yourself» → «M9 U02. If the business changes or you're not there» → «M9 U03. Your one-page plan» → «M9 U04. If you're not there: beneficiary accounts, your home, digital access and taxes».

**Section summary:** *Edit section* for Module 9 > summary, HTML source view, replace everything with `5_section_summaries/M9_resumen.html`.

**H5P activities**
- New: *Add an activity > H5P*, name `M9 U04 · What would you do?`, file `2_h5p/M9/M9_U04_what_would_you_do.h5p`, same settings as the others (download no, embed no, copyright yes; highest grade; completion "must receive a grade").
- Final section order: book, H5P in lesson order, self-assessment.

## 3. "Support materials" book

- Chapter 4 "Glossary": delete it, *Import chapter* > `1_books/Apoyo/04_apoyo.zip` and move it up with the arrows to position 4.
- Chapter 5 "Where to get help": delete it, *Import chapter* > `1_books/Apoyo/05_apoyo.zip` and move it up with the arrows to position 5.

## 4. Questions and self-assessments

1. **Corrected text (2):** in the bank, open each question and *Edit*; replace the stem, options and feedback with those in `4_questions/corrected_questions_reference.gift.txt` (same name, don't import it). Editing doesn't delete attempts. Questions: M5 U02 P1, M6 U03 P3.
2. **New (3):** *Question bank > Import*, GIFT format, `4_questions/new_questions.gift.txt`. They go into `Your Business US EN v1.3/MN`.
3. Add the new ones to their self-assessment, 10 per page. **If the quiz already has attempts, Moodle won't let you add questions:** don't delete attempts; leave it and note it in your report.
   - `Module 9 self-assessment`: M9 U04 P1, M9 U04 P2, M9 U04 P3.

## 5. Check and report

With *Switch role to > Student*, open one new lesson and its H5P. Report: chapters per changed book, new or replaced H5P, corrected and imported questions, quizzes that couldn't change because they have attempts, imported terms, platform adjustments done and anything you couldn't do.

The `9_for_the_team/` folder (facilitator kit, WhatsApp and audio scripts, OECD map) is for the program team: **don't upload it to Moodle**.
