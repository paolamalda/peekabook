# Actualización 1.2 → 1.3 · Tu Talento, Tu Marca, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.2 a la 1.3. Solo trae lo que cambió. Los nombres de las actividades se mantienen. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Lista de cambios

M1: lección nueva U07; M1 U01: texto corregido; M1 U02: texto corregido; M1 U03: texto corregido; M1 U06: texto corregido; M2 U01: texto corregido; M2 U04: texto corregido; M3 U06: texto corregido; M4: lección nueva U05; M4 U01: texto corregido; M4 U04: texto corregido; M5: lección nueva U08; M5 U07: texto corregido; M6 U04: texto corregido; M6 U05: texto corregido; M6 U06: texto corregido; M7 U01: texto corregido; M7 U02: texto corregido; M7 U03: texto corregido; M7 U05: texto corregido; M7 U07: texto corregido; M7 U08: texto corregido; M7 U09: texto corregido; M7 U10: texto corregido; M8: lección nueva U06; M8 U02: texto corregido; M8 U05: texto corregido; M9: lección nueva U10; M9 U08: texto corregido; M9 U09: texto corregido; M10: lección nueva U07; M10 U05: texto corregido; M10 U06: texto corregido; M11 U01: texto corregido; M11 U02: texto corregido; M11 U03: texto corregido; M11 U05: texto corregido; M11 U08: texto corregido; M11 U09: texto corregido; Apoyo: capítulos 1, 4, 5, 6 corregidos; Preguntas: 18 nuevas; Preguntas: 10 con texto corregido; Glosario: 3 términos nuevos; Apoyo: herramientas en Excel (recurso nuevo); Plataforma: categoría con versión, insignias con nombre del curso, constancia estándar, encuestas, curso visible con clave y mosaicos.

## 1. Ajustes de plataforma (una sola vez)

1. **Categoría de preguntas:** en *Banco de preguntas > Categorías*, renombra `Tu Talento` a `Tu Talento v1.3` (sus subcategorías M1… se quedan).
2. **Insignias:** renombra cada insignia para que sea única en la plataforma: «Dinero real» → «Dinero real · Tu Talento»; «Carrera en regla» → «Carrera en regla · Tu Talento»; «Sé elegir» → «Sé elegir · Tu Talento»; «Crédito bajo control» → «Crédito bajo control · Tu Talento»; «Nadie me engaña» → «Nadie me engaña · Tu Talento»; «Protección activa» → «Protección activa · Tu Talento»; «Futuro en escena» → «Futuro en escena · Tu Talento»; «Plan completo» → «Plan completo · Tu Talento». Las insignias ya otorgadas se conservan.
3. **Constancia:** edita el Certificado personalizado, quita la imagen de fondo y usa la plantilla estándar de la plataforma con: título «Tu Talento, Tu Marca, Tu Futuro», línea «por concluir el programa de bienestar financiero Tu Talento, Tu Marca, Tu Futuro» y temas Dinero e impuestos · Contratos y regalías · Crédito y Buró · Fraudes y protección · Retiro y futuro (también en `7_constancia/`). Agrega la **Encuesta final** como condición de acceso.
4. **Visibilidad e inscripción:** curso **visible**; *Métodos de inscripción* > **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes). Sin acceso de invitados.
5. **Formato:** si **Mosaicos** (Tiles) está instalado, cambia el formato del curso a Mosaicos con el progreso en los mosaicos **como porcentaje**; si no, deja Temas.
6. **Encuestas:** con el módulo **Retroalimentación** (anónima), crea `Encuesta de inicio` (sección General), `Encuesta final`, `Seguimiento a 30 días` y `Seguimiento a 90 días` (última sección) e importa los XML de `6_encuestas/` (`encuestas.md` los explica). Restringe los seguimientos por fecha («[por definir]»).
7. **Catálogo:** actualiza la ficha del curso con `tarjeta_catalogo.md`.

## 2. Herramientas en Excel

En la sección «Materiales de apoyo», agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con `8_herramientas/Herramientas_TTMF.xlsx`. Mostrar: "Forzar descarga". Descripción: "Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver". No cuenta para la finalización del curso.

## 3. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?».
2. En «M1 U01. ¿Todo lo que cobro por una producción es mi ganancia real?», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Trabajas casi gratis» por «Trabajas casi sin cobrar» y guarda.
3. En «M1 U02. ¿Cómo me pago un sueldo si no tengo sueldo fijo?», subcapítulo «Practica», *Editar*: cambia el texto «CONDUSEF, educación financiera · Banco de México, portabilidad de nómina, consultado el 29 de septiembre de 2026.» por «CONDUSEF, guías para usuarios · Banco de México, portabilidad de nómina, consultado el 29 de septiembre de 2026.» y guarda.
4. En «M1 U03. ¿Cuánto necesito en mi fondo de sequía?», subcapítulo «Practica», *Editar*: cambia el texto «CONDUSEF, educación financiera · Macías, S., Pequeño Cerdo Capitalista.» por «CONDUSEF, guías para usuarios · Macías, S., Pequeño Cerdo Capitalista.» y guarda.
5. *Importar capítulo* > `1_libros/M1/M1_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?» con 3 subcapítulos.
6. *Importar capítulo* > `1_libros/M1/M1_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U07. Meses sin llamados: estrés, rechazo y dinero» con 3 subcapítulos.
7. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Todo lo que cobro por una producción es mi ganancia real?» → «M1 U02. ¿Cómo me pago un sueldo si no tengo sueldo fijo?» → «M1 U03. ¿Cuánto necesito en mi fondo de sequía?» → «M1 U04. ¿Dónde guardo mi fondo de sequía?» → «M1 U05. Vestuario, imagen y estilismo: ¿gasto necesario o fuga?» → «M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?» → «M1 U07. Meses sin llamados: estrés, rechazo y dinero».

**Resumen de la sección:** *Editar sección* del Módulo 1 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M1_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U07 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 2

**Libro `Lecciones del Módulo 2`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M2 U04. Facturar, declarar y no atrasarte con el SAT».
2. En «M2 U01. ¿RESICO, Asimilados o Actividad Empresarial?», subcapítulo «Practica», *Editar*: cambia el texto «Orientación gratuita al contribuyente» por «Orientación sin costo al contribuyente» y guarda.
3. *Importar capítulo* > `1_libros/M2/M2_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M2 U04. Facturar, declarar y no atrasarte con el SAT» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M2 U01. ¿RESICO, Asimilados o Actividad Empresarial?» → «M2 U02. El IVA: el dinero que cobras pero no es tuyo» → «M2 U03. ¿Qué gastos de mi carrera sí puedo deducir, y en qué régimen?» → «M2 U04. Facturar, declarar y no atrasarte con el SAT» → «M2 U05. Deducciones personales y tu declaración anual».

**Resumen de la sección:** *Editar sección* del Módulo 2 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M2_resumen.html`.

### Módulo 3

**Libro `Lecciones del Módulo 3`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M3 U06. Cuando la productora no paga».
2. *Importar capítulo* > `1_libros/M3/M3_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M3 U06. Cuando la productora no paga» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M3 U01. Lo que revisas antes de firmar un llamado o una exclusividad» → «M3 U02. Derechos de imagen y voz: qué cedes y por cuánto tiempo» → «M3 U03. Mánagers y agencias: comisiones y cuentas claras» → «M3 U04. ANDA, ANDI y las organizaciones del medio: ¿quién hace qué?» → «M3 U05. Cómo cobro mis regalías y reviso mis pagos» → «M3 U06. Cuando la productora no paga».

**Resumen de la sección:** *Editar sección* del Módulo 3 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M3_resumen.html`.

### Módulo 4

**Libro `Lecciones del Módulo 4`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M4 U04. Tus derechos como usuario».
2. En «M4 U01. ¿Quién es quién en el sistema financiero?», subcapítulo «Practica», *Editar*: cambia el texto «"Educación financiera" y los comparativos de tarjetas.» por «los comparativos de tarjetas.» y guarda.
3. *Importar capítulo* > `1_libros/M4/M4_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M4 U04. Tus derechos como usuario» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M4/M4_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M4 U05. Noticias, rumores y cambios: ajusta tu plan sin pánico» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M4 U01. ¿Quién es quién en el sistema financiero?» → «M4 U02. Bancos, bancos digitales y otras entidades: ¿cuál es cuál?» → «M4 U03. ¿Cómo verifico una institución antes de contratar?» → «M4 U04. Tus derechos como usuario» → «M4 U05. Noticias, rumores y cambios: ajusta tu plan sin pánico».

**Resumen de la sección:** *Editar sección* del Módulo 4 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M4_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M4 U05 · ¿Qué harías?`, archivo `2_h5p/M4/M4_U05_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 5

**Libro `Lecciones del Módulo 5`**
1. En «M5 U07. Lee el contrato antes de firmar», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M5 U08. Aval, obligado solidario, fiador y referencia: ¿qué firmas?.» y guarda.
2. *Importar capítulo* > `1_libros/M5/M5_U08_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M5 U08. Aval, obligado solidario, fiador y referencia: ¿qué firmas?» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M5 U01. Primero elige la institución» → «M5 U02. Elige tu cuenta» → «M5 U03. Elige dónde ahorrar e invertir» → «M5 U04. Elige un seguro» → «M5 U05. Elige un crédito: los números» → «M5 U06. Elige un crédito: el tipo correcto para cada uso» → «M5 U07. Lee el contrato antes de firmar» → «M5 U08. Aval, obligado solidario, fiador y referencia: ¿qué firmas?».

**Resumen de la sección:** *Editar sección* del Módulo 5 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M5_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M5 U08 · ¿Qué harías?`, archivo `2_h5p/M5/M5_U08_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 6

**Libro `Lecciones del Módulo 6`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M6 U04. Tu inventario de deudas».
2. En «M6 U05. ¿Cuánta deuda aguanta un ingreso variable?», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
3. En «M6 U06. No uses la tarjeta para vivir la sequía», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
4. *Importar capítulo* > `1_libros/M6/M6_U04_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M6 U04. Tu inventario de deudas» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M6 U01. Tu línea de crédito no es tu ingreso» → «M6 U02. Pago mínimo, pago para no generar intereses y fechas clave» → «M6 U03. Meses sin intereses: cuándo ayudan y cuándo te atrapan» → «M6 U04. Tu inventario de deudas» → «M6 U05. ¿Cuánta deuda aguanta un ingreso variable?» → «M6 U06. No uses la tarjeta para vivir la sequía».

**Resumen de la sección:** *Editar sección* del Módulo 6 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M6_resumen.html`.

### Módulo 7

**Libro `Lecciones del Módulo 7`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M7 U01. ¿Qué son el Buró y el Círculo de Crédito?»; «M7 U02. Buró y Círculo: ¿en qué se parecen y en qué no?»; «M7 U03. Pide tus reportes gratis: dos al año»; «M7 U05. Tu score: qué lo sube y qué lo baja»; «M7 U09. Despachos que "limpian tu Buró": fraude».
2. En «M7 U07. Si hay un error: reclama paso a paso», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «2 reclamaciones gratis al año» por «2 reclamaciones sin costo al año» y guarda.
3. En «M7 U07. Si hay un error: reclama paso a paso», subcapítulo «Practica», *Editar*: cambia el texto «requisitos y reclamaciones gratuitas.» por «requisitos y reclamaciones sin costo.» y guarda.
4. En «M7 U08. Protege tu historial: bloqueo y alertas», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «"Avísame" es gratuito; "Avísame Mucho Más" cuesta 250 pesos al año.» por «"Avísame" no tiene costo; "Avísame Mucho Más" cuesta 250 pesos al año.» y guarda.
5. En «M7 U10. Cómo mejorar tu historial paso a paso», subcapítulo «Practica», *Editar*: cambia el texto «tu reporte gratis; el de Círculo está en circulodecredito.com.mx.» por «tu reporte sin costo; el de Círculo está en circulodecredito.com.mx.» y guarda.
6. *Importar capítulo* > `1_libros/M7/M7_U01_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U01. ¿Qué son el Buró y el Círculo de Crédito?» con 3 subcapítulos.
7. *Importar capítulo* > `1_libros/M7/M7_U02_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U02. Buró y Círculo: ¿en qué se parecen y en qué no?» con 3 subcapítulos.
8. *Importar capítulo* > `1_libros/M7/M7_U03_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U03. Pide tus reportes sin costo: dos al año» con 3 subcapítulos.
9. *Importar capítulo* > `1_libros/M7/M7_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U05. Tu score: qué lo sube y qué lo baja» con 3 subcapítulos.
10. *Importar capítulo* > `1_libros/M7/M7_U09_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M7 U09. Despachos que "limpian tu Buró": fraude» con 3 subcapítulos.
11. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M7 U01. ¿Qué son el Buró y el Círculo de Crédito?» → «M7 U02. Buró y Círculo: ¿en qué se parecen y en qué no?» → «M7 U03. Pide tus reportes sin costo: dos al año» → «M7 U04. Lee tu reporte» → «M7 U05. Tu score: qué lo sube y qué lo baja» → «M7 U06. ¿Cuánto tiempo se queda un atraso?» → «M7 U07. Si hay un error: reclama paso a paso» → «M7 U08. Protege tu historial: bloqueo y alertas» → «M7 U09. Despachos que "limpian tu Buró": fraude» → «M7 U10. Cómo mejorar tu historial paso a paso».

**Resumen de la sección:** *Editar sección* del Módulo 7 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M7_resumen.html`.

**Actividades H5P**
- Cambia: abre `M7 U03 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U03_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M7 U05 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M7/M7_U05_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M8 U05. Tu plan de salida con ingreso variable».
2. En «M8 U02. Negociar con el banco: reestructura, convenio o quita», subcapítulo «Profundiza · +5 min», *Editar*: cambia el texto «Si hoy no puedes pagar, dilo con claridad y pide un plan. Si tienes varias deudas, busca orientación gratuita en CONDUSEF antes de aceptar cualquier propuesta.» por «Si hoy no puedes pagar, dilo con claridad y pide un plan. Si tienes varias deudas, busca orientación sin costo en CONDUSEF antes de aceptar cualquier propuesta.» y guarda.
3. En «M8 U02. Negociar con el banco: reestructura, convenio o quita», subcapítulo «Practica», *Editar*: cambia el texto «cómo pedir orientación gratuita sobre tus deudas.» por «cómo pedir orientación sin costo sobre tus deudas.» y guarda.
4. *Importar capítulo* > `1_libros/M8/M8_U05_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U05. Tu plan de salida con ingreso variable» con 3 subcapítulos.
5. *Importar capítulo* > `1_libros/M8/M8_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U06. Apuestas en línea: el pago gordo no es para apostar» con 3 subcapítulos.
6. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Elige tu método: avalancha o bola de nieve» → «M8 U02. Negociar con el banco: reestructura, convenio o quita» → «M8 U03. ¿Consolidar deudas me conviene?» → «M8 U04. Cobranza: tus derechos» → «M8 U05. Tu plan de salida con ingreso variable» → «M8 U06. Apuestas en línea: el pago gordo no es para apostar».

**Resumen de la sección:** *Editar sección* del Módulo 8 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M8_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U06 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M9 U08. Que dejen de llamarte: REPEP, REUS y tu línea».
2. En «M9 U09. Si ya te pasó: tu plan de respuesta», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes.» y guarda.
3. *Importar capítulo* > `1_libros/M9/M9_U08_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U08. Que dejen de llamarte: REPEP, REUS y tu línea» con 3 subcapítulos.
4. *Importar capítulo* > `1_libros/M9/M9_U10_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes» con 3 subcapítulos.
5. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M9 U01. Cómo piensa quien te quiere estafar» → «M9 U02. Falsos castings, productoras y agencias que cobran» → «M9 U03. Llamadas, mensajes y páginas falsas» → «M9 U04. Robo de identidad: cuando usan tu nombre» → «M9 U05. Tus redes y tu teléfono: robo de cuentas y de línea» → «M9 U06. Apps de préstamo "montadeudas" y préstamos con depósito previo» → «M9 U07. Inversiones milagro y "yo te manejo tu dinero"» → «M9 U08. Que dejen de llamarte: REPEP, REUS y tu línea» → «M9 U09. Si ya te pasó: tu plan de respuesta» → «M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes».

**Resumen de la sección:** *Editar sección* del Módulo 9 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M9_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M9 U10 · ¿Qué harías?`, archivo `2_h5p/M9/M9_U10_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U05. Protege tu nombre y tu marca», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Buscar es gratis y te evita problemas.» por «Buscar no tiene costo y te evita problemas.» y guarda.
2. En «M10 U06. Testamento y documentos para tu familia», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo.» y guarda.
3. *Importar capítulo* > `1_libros/M10/M10_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo» con 3 subcapítulos.
4. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Sin seguro de empresa: el Seguro de Gastos Médicos Mayores» → «M10 U02. IMSS Modalidad 10: seguridad social para independientes» → «M10 U03. Si no puedes trabajar: incapacidad, invalidez y accidentes» → «M10 U04. Seguro de vida y beneficiarios» → «M10 U05. Protege tu nombre y tu marca» → «M10 U06. Testamento y documentos para tu familia» → «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo».

**Resumen de la sección:** *Editar sección* del Módulo 10 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M10_resumen.html`.

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U07 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 11

**Libro `Lecciones del Módulo 11`**
1. Borra estos capítulos (cada uno con sus 3 subcapítulos; la finalización del libro no se pierde): «M11 U02. Tu AFORE: encuéntrala y súmale»; «M11 U09. Tu plan de una página».
2. En «M11 U01. Llegó un pago gordo: repártelo antes de gastarlo», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
3. En «M11 U03. Modalidad 40: si cotizaste antes de julio de 1997», subcapítulo «Lo esencial · 5 min», *Editar*: cambia el texto «Pidió asesoría gratuita en el IMSS para calcular cuánto mejoraría su pensión con distintos salarios y decidió cuánto podía pagar sin afectar su fondo de sequía.» por «Pidió asesoría sin costo en el IMSS para calcular cuánto mejoraría su pensión con distintos salarios y decidió cuánto podía pagar sin afectar su fondo de sequía.» y guarda.
4. En «M11 U05. Invertir a largo plazo sin especular», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
5. En «M11 U08. Tu carrera larga», subcapítulo «Practica», *Editar*: cambia el texto «Educación financiera» por «Guías y herramientas» y guarda.
6. *Importar capítulo* > `1_libros/M11/M11_U02_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M11 U02. Tu AFORE: encuéntrala y súmale» con 3 subcapítulos.
7. *Importar capítulo* > `1_libros/M11/M11_U09_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M11 U09. Tu plan de una página» con 3 subcapítulos.
8. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M11 U01. Llegó un pago gordo: repártelo antes de gastarlo» → «M11 U02. Tu AFORE: encuéntrala y súmale» → «M11 U03. Modalidad 40: si cotizaste antes de julio de 1997» → «M11 U04. Plan Personal de Retiro (PPR) y aportaciones deducibles» → «M11 U05. Invertir a largo plazo sin especular» → «M11 U06. Vivienda: rentar, comprar o esperar» → «M11 U07. Ingresos fuera de cámara» → «M11 U08. Tu carrera larga» → «M11 U09. Tu plan de una página».

**Resumen de la sección:** *Editar sección* del Módulo 11 > descripción, vista de código HTML, reemplaza todo con `5_resumenes/M11_resumen.html`.

**Actividades H5P**
- Cambia: abre `M11 U02 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M11/M11_U02_que_harias.h5p`. Los intentos anteriores se conservan.
- Cambia: abre `M11 U08 · ¿Qué harías?` > *Editar ajustes* y reemplaza el archivo por `2_h5p/M11/M11_U08_que_harias.h5p`. Los intentos anteriores se conservan.
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 4. Libro «Materiales de apoyo»

- Capítulo 1 «Bienvenida»: bórralo, *Importar capítulo* > `1_libros/Apoyo/01_apoyo.zip` y súbelo con las flechas a la posición 1.
- Capítulo 4 «Glosario»: bórralo, *Importar capítulo* > `1_libros/Apoyo/04_apoyo.zip` y súbelo con las flechas a la posición 4.
- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 5. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 3 términos nuevos.

## 6. Preguntas y autoevaluaciones

1. **Texto corregido (10):** en el banco, abre cada pregunta y *Editar*; reemplaza el enunciado, las opciones y la retroalimentación con los de `4_preguntas/preguntas_corregidas_referencia.gift.txt` (mismo nombre, no la importes). Editar no borra intentos. Preguntas: M2 U04 P2, M3 U06 P2, M4 U04 P3, M7 U02 P3, M7 U03 P1, M7 U03 P2, M7 U03 P3, M7 U05 P3, M9 U08 P3, M11 U02 P3.
2. **Nuevas (18):** *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en `Tu Talento v1.3/MN`.
3. Agrega las nuevas a su autoevaluación, 10 por página. **Si el cuestionario ya tiene intentos, Moodle no deja agregar preguntas:** no borres intentos; déjalo y anótalo en tu reporte.
   - `Autoevaluación del Módulo 1`: M1 U07 P1, M1 U07 P2, M1 U07 P3.
   - `Autoevaluación del Módulo 4`: M4 U05 P1, M4 U05 P2, M4 U05 P3.
   - `Autoevaluación del Módulo 5`: M5 U08 P1, M5 U08 P2, M5 U08 P3.
   - `Autoevaluación del Módulo 8`: M8 U06 P1, M8 U06 P2, M8 U06 P3.
   - `Autoevaluación del Módulo 9`: M9 U10 P1, M9 U10 P2, M9 U10 P3.
   - `Autoevaluación del Módulo 10`: M10 U07 P1, M10 U07 P2, M10 U07 P3.

## 7. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas corregidas e importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados, ajustes de plataforma hechos y lo que no pudiste hacer.

La carpeta `9_para_el_equipo/` (kit para facilitadores, guiones de WhatsApp y audio, mapa OCDE) es para el equipo del programa: **no se sube a Moodle**.
