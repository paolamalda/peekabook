# Actualización 1.2 → 1.3 · Tu Talento, Tu Marca, Tu Futuro · para Claude

Este paquete actualiza un curso **ya instalado** en Moodle 3.10 de la versión 1.2 a la 1.3. Solo trae lo que cambió. **No reinstales el curso ni borres actividades, intentos, calificaciones, insignias o puntos de Level Up.**

Antes de empezar: haz una copia de seguridad del curso (*Administración del curso > Copia de seguridad*, sin datos de usuarios basta) y activa la edición. Si un paso no se puede, sáltalo y repórtalo al final.

## Qué cambia

- M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo? · actualizada
- M1 U07. Meses sin llamados: estrés, rechazo y dinero · nueva
- M8 U05. Tu plan de salida con ingreso variable · actualizada
- M8 U06. Apuestas en línea: el pago gordo no es para apostar · nueva
- M9 U09. Si ya te pasó: tu plan de respuesta · actualizada
- M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes · nueva
- M10 U06. Testamento y documentos para tu familia · actualizada
- M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo · nueva
- Libro «Materiales de apoyo»: capítulos 5, 6
- 12 preguntas nuevas; 1 términos nuevos de glosario.

## 1. Por módulo

### Módulo 1

**Libro `Lecciones del Módulo 1`**
1. En «M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M1 U07. Meses sin llamados: estrés, rechazo y dinero.» y guarda.
2. *Importar capítulo* > `1_libros/M1/M1_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M1 U07. Meses sin llamados: estrés, rechazo y dinero» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M1 U01. ¿Todo lo que cobro por una producción es mi ganancia real?» → «M1 U02. ¿Cómo me pago un sueldo si no tengo sueldo fijo?» → «M1 U03. ¿Cuánto necesito en mi fondo de sequía?» → «M1 U04. ¿Dónde guardo mi fondo de sequía?» → «M1 U05. Vestuario, imagen y estilismo: ¿gasto necesario o fuga?» → «M1 U06. La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?» → «M1 U07. Meses sin llamados: estrés, rechazo y dinero».

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M1 U07 · ¿Qué harías?`, archivo `2_h5p/M1/M1_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 8

**Libro `Lecciones del Módulo 8`**
1. En «M8 U05. Tu plan de salida con ingreso variable», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M8 U06. Apuestas en línea: el pago gordo no es para apostar.» y guarda.
2. *Importar capítulo* > `1_libros/M8/M8_U06_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M8 U06. Apuestas en línea: el pago gordo no es para apostar» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M8 U01. Elige tu método: avalancha o bola de nieve» → «M8 U02. Negociar con el banco: reestructura, convenio o quita» → «M8 U03. ¿Consolidar deudas me conviene?» → «M8 U04. Cobranza: tus derechos» → «M8 U05. Tu plan de salida con ingreso variable» → «M8 U06. Apuestas en línea: el pago gordo no es para apostar».

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M8 U06 · ¿Qué harías?`, archivo `2_h5p/M8/M8_U06_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 9

**Libro `Lecciones del Módulo 9`**
1. En «M9 U09. Si ya te pasó: tu plan de respuesta», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes.» y guarda.
2. *Importar capítulo* > `1_libros/M9/M9_U10_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M9 U01. Cómo piensa quien te quiere estafar» → «M9 U02. Falsos castings, productoras y agencias que cobran» → «M9 U03. Llamadas, mensajes y páginas falsas» → «M9 U04. Robo de identidad: cuando usan tu nombre» → «M9 U05. Tus redes y tu teléfono: robo de cuentas y de línea» → «M9 U06. Apps de préstamo "montadeudas" y préstamos con depósito previo» → «M9 U07. Inversiones milagro y "yo te manejo tu dinero"» → «M9 U08. Que dejen de llamarte: REPEP, REUS y tu línea» → «M9 U09. Si ya te pasó: tu plan de respuesta» → «M9 U10. Tu voz y tu cara con inteligencia artificial: deepfakes y fraudes».

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M9 U10 · ¿Qué harías?`, archivo `2_h5p/M9/M9_U10_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

### Módulo 10

**Libro `Lecciones del Módulo 10`**
1. En «M10 U06. Testamento y documentos para tu familia», subcapítulo «Practica», *Editar*: cambia el texto «Completa la actividad y el quiz para sumar puntos. Siguiente lección.» por «Completa la actividad y el quiz para sumar puntos. Siguiente lección: M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo.» y guarda.
2. *Importar capítulo* > `1_libros/M10/M10_U07_leccion.zip`, tipo "Cada archivo HTML representa un capítulo". Crea «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo» con 3 subcapítulos.
3. Moodle agrega lo importado al final. Con las flechas de *Editar*, deja los capítulos principales en este orden (cada uno con sus subcapítulos): «M10 U01. Sin seguro de empresa: el Seguro de Gastos Médicos Mayores» → «M10 U02. IMSS Modalidad 10: seguridad social para independientes» → «M10 U03. Si no puedes trabajar: incapacidad, invalidez y accidentes» → «M10 U04. Seguro de vida y beneficiarios» → «M10 U05. Protege tu nombre y tu marca» → «M10 U06. Testamento y documentos para tu familia» → «M10 U07. Si llega un sismo o una inundación: tu equipo y tu trabajo».

**Actividades H5P**
- Nueva: *Agregar actividad > Actividad H5P*, nombre `M10 U07 · ¿Qué harías?`, archivo `2_h5p/M10/M10_U07_que_harias.h5p`, con la misma configuración que las demás (descarga no, incrustar no, derechos de autor sí; calificación más alta; finalización "debe recibir una calificación").
- Orden final de la sección: libro, H5P en orden de lección, autoevaluación.

## 2. Libro «Materiales de apoyo»

- Capítulo 5 «Dónde encontrar ayuda»: bórralo, *Importar capítulo* > `1_libros/Apoyo/05_apoyo.zip` y súbelo con las flechas a la posición 5.
- Capítulo 6 «Referencias»: bórralo, *Importar capítulo* > `1_libros/Apoyo/06_apoyo.zip` y súbelo con las flechas a la posición 6.

## 3. Glosario

En el glosario `Palabras clave del curso`: *Importar entradas* > `3_glosario/Glosario_terminos_nuevos.xml`, destino "glosario actual". Solo trae los 1 términos nuevos, así que no se duplican los que ya tienes.

## 4. Preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*, formato GIFT, `4_preguntas/preguntas_nuevas.gift.txt`. Entran en las categorías que ya existen (12 preguntas).
2. En cada autoevaluación de abajo, abre *Editar cuestionario*. **Si el cuestionario ya tiene intentos, Moodle no deja cambiar las preguntas:** no borres intentos; déjalo como está y anótalo en tu reporte (las lecciones nuevas igual tienen su libro y su H5P). Si no tiene intentos, haz los cambios, 10 por página:
   - `Autoevaluación del Módulo 1`: agrega M1 U07 P1, M1 U07 P2, M1 U07 P3.
   - `Autoevaluación del Módulo 8`: agrega M8 U06 P1, M8 U06 P2, M8 U06 P3.
   - `Autoevaluación del Módulo 9`: agrega M9 U10 P1, M9 U10 P2, M9 U10 P3.
   - `Autoevaluación del Módulo 10`: agrega M10 U07 P1, M10 U07 P2, M10 U07 P3.

## 5. Lo que no cambia

Level Up (reglas y niveles), insignias, finalización del curso y constancia siguen igual: las H5P nuevas suman puntos solas con la regla de finalización. No hace falta volver a subir ningún otro archivo.

## 6. Comprueba y reporta

Con *Cambiar rol a > Estudiante*, abre una lección nueva y su H5P. Reporta: capítulos por libro cambiado, H5P nuevas o reemplazadas, preguntas importadas, cuestionarios que no se pudieron cambiar por tener intentos, términos importados y lo que no pudiste hacer.
