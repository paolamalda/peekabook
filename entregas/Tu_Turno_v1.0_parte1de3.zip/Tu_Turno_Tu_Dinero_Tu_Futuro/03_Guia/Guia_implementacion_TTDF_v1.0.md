# Tu Turno, Tu Dinero, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 4.5.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_TURNO_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Turno, Tu Dinero, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 4.5, el tema Boost, Level Up (block_xp) y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### En Moodle 4.5: dónde está cada cosa

El sitio usa **Moodle 4.5**. Donde estas instrucciones nombran un menú, búscalo así:

| Para | En Moodle 4.5 |
|---|---|
| Editar el curso | Interruptor **Modo de edición**, arriba a la derecha |
| Configuración, participantes, insignias, banco de preguntas, banco de contenido, finalización | Menú del curso (pestañas bajo el título): *Configuración*, *Participantes* y *Más* > *Banco de preguntas*, *Banco de contenido*, *Insignias*, *Finalización del curso* |
| Métodos de inscripción | *Participantes* > selector de arriba > *Métodos de inscripción* |
| Importar capítulos de un libro | Dentro del libro, menú de acciones (⋮ o *Más*) > *Importar capítulo* |
| Importar entradas del glosario | Dentro del glosario, selector o menú de acciones > *Importar entradas* |
| Importar preguntas de una encuesta (Retroalimentación) | Dentro de la actividad, pestaña *Preguntas* > menú > *Importar preguntas* |
| Ver como estudiante | Menú de tu usuario (arriba a la derecha) > *Cambiar rol a…* > *Estudiante* |
| Finalización de una actividad | En su configuración, sección *Condiciones de finalización* |

**Para ahorrar horas** (el curso tiene muchas piezas):

1. **Finalización predeterminada antes de crear los libros:** *Más > Finalización del curso* > selector > *Finalización de actividad predeterminada*. Para **Libro**: "Ver". Para **Cuestionario**: "Recibir una calificación aprobatoria". Así cada libro nuevo ya nace con su finalización.
2. **Edición masiva:** en modo de edición, *Edición masiva* (arriba a la derecha) permite mover, mostrar u ocultar varias actividades a la vez.
3. **Trabaja por etapas y reporta en cada una:** primero la sección General (Bienvenida, foro, «Mi meta», encuesta de inicio, «Tu punto de partida») y la Parte 1 completa. Detente, toma capturas y reporta a la persona antes de seguir con las demás partes.
4. Si una opción de estas instrucciones no existe con ese nombre en 4.5, usa la equivalente y anótala en el reporte.

**Mosaicos (Tiles) en 4.5:** si *Usar submosaicos para las actividades* o *Mostrar progreso* no aparecen en la configuración del curso, pueden estar desactivados para todo el sitio; no cambies la configuración del sitio: repórtalo.

**Level Up en 4.5:** las versiones nuevas agrupan las reglas en *Level Up > Puntos*. Si existe la regla de **finalización de actividad**, úsala con 25 puntos en lugar del evento. La *Clasificación* puede llamarse *Tabla de posiciones*.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `DT-TURNO-MX-ES`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Turno, Tu Dinero, Tu Futuro |
| Nombre corto | DT-TURNO-MX-ES |
| Visibilidad | **Mostrar** |
| Formato | **Mosaicos** (Tiles). 10 secciones |
| Seguimiento de finalización | Sí |

**Formato Mosaicos:**
- *Mostrar progreso en los mosaicos*: **como porcentaje**.
- **Usar submosaicos para las actividades: Sí** (cada lección se ve como un mosaico dentro de su parte).
- La sección General (Bienvenida) va arriba de los mosaicos.

**Íconos de los mosaicos** (se eligen en modo de edición, en cada mosaico; si un nombre no aparece en el selector, usa el más parecido):

| Mosaico | Ícono | Qué se ve |
|---|---|---|
| Tu quincena rinde | `calendar` | calendario |
| Tu cuenta y tu dinero | `university` | edificio de banco |
| Tus deudas claras | `file-text-o` | documento |
| Tandas y ahorro en grupo | `users` | grupo de personas |
| Buró de Crédito sin miedo | `bar-chart` | gráfica de barras |
| Que no te extorsionen | `phone` | teléfono |
| Tu familia y los imprevistos | `heartbeat` | pulso |
| Tu futuro | `hourglass-half` | reloj de arena |
| Cierre y constancia | `flag-checkered` | bandera de meta |
| Materiales de apoyo | `book` | libro |
| Programas y apoyos (extra) | `life-buoy` | salvavidas |

- Oculta el bloque *Tabla de posiciones* o *Ranking* de Level Up si aparece en la columna derecha.

**Inscripción:** *Métodos de inscripción* > activa **Autoinscripción** con la **clave de inscripción** que te dé la persona (si no la tienes, deja "[por definir]" y repórtalo). Desactiva el acceso de invitados.

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Libro «Bienvenida», foro "Dudas y comentarios", encuesta de inicio, «Tu punto de partida» y «Mi meta» |
| 1 | Tu quincena rinde | Contenido de `1_libros/M1_resumen.html` |
| 2 | Tu cuenta y tu dinero | `M2_resumen.html` |
| 3 | Tus deudas claras | `M3_resumen.html` |
| 4 | Tandas y ahorro en grupo | `M4_resumen.html` |
| 5 | Buró de Crédito sin miedo | `M5_resumen.html` |
| 6 | Que no te extorsionen | `M6_resumen.html` |
| 7 | Tu familia y los imprevistos | `M7_resumen.html` |
| 8 | Tu futuro | `M8_resumen.html` |
| 9 | Cierre y constancia | "Lo que lograste, tu constancia y hasta pronto." |
| 10 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |

Descripción del foro "Dudas y comentarios": "No compartas números de cuenta, contraseñas, códigos ni montos reales de tus deudas."

#### Bienvenida y despedida (libros con diseño)

Son lo primero y lo último que ve la persona: no los omitas.

1. **Sección General, arriba de todo:** crea el libro `Bienvenida` (formato de capítulo "Nada", navegación "Texto") e importa `1_libros/Bienvenida_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo". Deben quedar 4 capítulos: Te damos la bienvenida, Cómo funciona el curso, Guía de contacto y comunidad, Antes de empezar. Finalización: "Ver".
2. Debajo, el foro **"Dudas y comentarios"** (foro general). **No crees un foro de presentaciones:** pedir que la gente se presente invita a compartir datos personales.
   Después, la tarea **"Mi meta"**: tipo *Tarea*, entrega "Texto en línea" (límite de 60 palabras), **sin calificación**, sin fecha límite, sin avisos a otros participantes; las entregas solo las ven la persona y el equipo del curso. Instrucciones: "En una frase: qué esperas del programa y qué quieres lograr. No escribas datos personales ni montos reales. Al final del curso la vuelves a abrir." Permite editar la entrega en cualquier momento. Finalización: "Enviar".
3. Debajo, la **Encuesta de inicio** (sección 8) y el cuestionario **«Tu punto de partida»**: importa `4_preguntas/diagnostica.gift.txt` (crea su propia categoría «Diagnóstica»), todas las preguntas, calificación sobre 0 (no cuenta para la calificación), **un intento**, tiempo máximo 10 minutos, revisión con respuesta correcta al terminar.
4. **Restringir acceso** de la primera lección de la Parte 1: el libro `Bienvenida` debe estar visto y la **Encuesta de inicio** enviada.
5. **Sección 9, arriba de todo:** crea el libro `Cierre y despedida` con la misma configuración e importa `1_libros/Cierre_libro_Moodle.zip` (4 capítulos: Lo que lograste, Tu plan sigue, Encuesta final y constancia, Hasta pronto). Restringir acceso: la autoevaluación de la última parte debe estar completa. Debajo van la encuesta final y la constancia.
6. **Guía para imprimir o compartir:** `7_guias/Guia_de_contacto_y_comunidad.html`. Ábrela en el navegador > Imprimir > Guardar como PDF, y compártela en la sesión presencial o por WhatsApp.

### 3. Lecciones: un libro por lección

La estructura completa (nombres, orden, archivos y minutos) está en `estructura_moodle.json`. En cada sección, por cada lección y en orden:

1. Crea un **Libro** con el nombre de la lección **tal cual** (la pregunta, sin claves como «M1 U01»). Formato de capítulo "Nada"; estilo de navegación "Texto".
2. Menú del libro > **Importar capítulo** > el zip de la lección (`1_libros/MN/NN_MN_UYY.zip`), tipo "Cada archivo HTML representa un capítulo". Deben quedar 4 capítulos: Empieza, Lo esencial, Profundiza, Practica.
3. **Finalización:** "Ver".
4. **Restringir acceso:** la lección anterior debe estar completa (la primera de cada parte, sin restricción; la primera de la parte 2 en adelante pide la última de la parte anterior). Muestra la lección bloqueada en gris, no oculta.

| Parte | Lecciones | Carpeta |
|---|---|---|
| Tu quincena rinde | 6 | `1_libros/M1/` |
| Tu cuenta y tu dinero | 6 | `1_libros/M2/` |
| Tus deudas claras | 7 | `1_libros/M3/` |
| Tandas y ahorro en grupo | 3 | `1_libros/M4/` |
| Buró de Crédito sin miedo | 4 | `1_libros/M5/` |
| Que no te extorsionen | 6 | `1_libros/M6/` |
| Tu familia y los imprevistos | 9 | `1_libros/M7/` |
| Tu futuro | 3 | `1_libros/M8/` |

### 4. Libro de apoyo

En la sección 10, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos).

Debajo, crea el libro **`Para ir a fondo`** con la misma configuración e importa `1_libros/Fondo_libro_Moodle.zip` (9 capítulos: «Cómo ir a fondo» y uno por parte). Descripción: "Opcional. Para quien quiere leer las fuentes oficiales, las reglas y los documentos de cada tema." **Finalización: ninguna** (es opcional y no cuenta para terminar el curso).

En la misma sección 10, agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con el archivo de `10_herramientas/`. Mostrar: "Forzar descarga". Descripción: "Presupuesto, lista de deudas, fondo de emergencia y meta con interés compuesto; además: tu quincena con turnos extra. Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver".

### 5. Glosario

En la sección 10, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_ttdf.gift.txt`. Se crean *Tu Turno v1.0/M1* a *M8*, con 132 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Turno v1.0/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 |
|---|---|---|---|---|---|---|---|
| 18 | 18 | 21 | 9 | 12 | 18 | 27 | 9 |

### 7. Práctica dentro de cada lección (44 H5P)

La práctica **no** va como actividad aparte en la sección: va incrustada en el capítulo «Practica» de su libro.

1. *Banco de contenido* del curso > **Subir** los 44 archivos de `2_h5p/MN/` (`MN_UYY_practica.h5p`).
2. Abre el capítulo «Practica» de cada libro en modo edición. Verás un recuadro rosa con el texto `[[H5P MN_UYY_practica.h5p]]`.
3. Borra **todo el recuadro** y en su lugar inserta el H5P con el botón **Insertar H5P** del editor, eligiendo ese archivo del banco de contenido.
4. Guarda y comprueba con *Cambiar rol a > Estudiante* que se vean las situaciones y preguntas, una por pantalla.

**Nota:** la práctica incrustada no registra calificación. El avance de cada lección se marca al verla, y la calificación del módulo sale de la autoevaluación.

**Orden final de cada sección:** las lecciones en orden y al final la autoevaluación (restringida a completar la última lección de la parte).

### 8. Encuestas del programa

En `8_encuestas/` están las encuestas y su documento `encuestas.md`. Usa el módulo **Retroalimentación** (Feedback), modo **anónimo**, y en cada una *Plantillas > Importar preguntas* con su XML (si la importación falla, créalas a mano con `encuestas.md`):

| Actividad | Sección | Archivo | Finalización |
|---|---|---|---|
| `Encuesta de inicio` | General | `encuesta_inicio.xml` | Enviar |
| `Encuesta final` | 9 | `encuesta_final.xml` | Enviar; es requisito de la constancia |
| `Seguimiento a 30 días` | 9 | `encuesta_seguimiento.xml` | Enviar |
| `Seguimiento a 90 días` | 9 | `encuesta_seguimiento.xml` | Enviar |

Restringe los seguimientos por fecha: 30 y 90 días después de la fecha de fin de la cohorte ("[por definir]"). La encuesta final es la evidencia de resultados del programa: no la omitas.

### 9. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`; cada nombre lleva el curso para que sea único en la plataforma), 4 (finalización con las 8 autoevaluaciones) y 5 (constancia con la plantilla estándar y los datos de `6_constancia/constancia.md`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### 9. Canal de avisos (pregunta antes)

Este curso no tiene comunidad en Moodle; se acompaña con un **canal de WhatsApp** de avisos (ver `7_guias/comunidad_y_canales.md`). En la sección General agrega una **URL** `Canal de avisos` con el enlace que te dé la persona (si no lo tiene, escribe "[por definir]" y repórtalo). Confirma que las lecciones se ven bien en el celular: el público las toma entre turnos.

### Sección extra: Programas y apoyos

Esta sección va **aparte**: nada del curso depende de ella.

1. Agrega una sección **al final** del curso llamada `Programas y apoyos` (descripción: "Programas de gobierno y servicios públicos que pueden servirte. Información revisada; confírmala en el sitio oficial."). Elige un ícono de «ayuda» para su mosaico.
2. Crea el libro `Programas y apoyos` con la misma configuración e importa `1_libros/Programas_libro_Moodle.zip` (12 capítulos).
3. **Finalización: ninguna.** No lo incluyas en la finalización del curso ni en las restricciones de otras actividades, y no le des puntos.
4. **Para quitarla:** oculta la sección (ojo > Ocultar) o bórrala. El resto del curso sigue igual.
5. Si llega un paquete nuevo de este libro, reemplaza solo este libro.

### 11. Revisión final (con rol de estudiante)

- La portada muestra un mosaico por parte con su porcentaje; dentro de cada parte, un submosaico por lección sin claves técnicas.
- La primera lección: capítulos Empieza, Lo esencial, Profundiza y Practica; «Cuidado con estos errores» al final de Lo esencial; la práctica incrustada funciona.
- La segunda lección aparece bloqueada hasta ver la primera.
- No hay ranking ni tabla de posiciones visible.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 12. Reporte para la persona

Enlace del curso; libros por parte; H5P incrustadas; preguntas por autoevaluación; encuestas creadas; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de la portada en mosaicos, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **visible**, con inscripción por clave. Para la ficha del catálogo usa `tarjeta_catalogo.md`.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 4.5 con Level Up (block_xp) y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada parte

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro por lección (con la práctica incrustada) | 44 | Ver |
| Cuestionario "Autoevaluación del Módulo N" | 1 por parte (8) | Calificación aprobatoria de 70% |

**Las autoevaluaciones:** usan el banco de 132 preguntas con tres opciones y retroalimentación, en las categorías *Tu Turno v1.0/M1* a *M8*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 1,300 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Lecciones | 44 | 1,100 |
| Autoevaluaciones | 8 | 200 |
| **Total** | 52 | **1,300** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Primer turno | 0 | Al entrar |
| 2 | Quincena en orden | 150 | Durante el Módulo 2 |
| 3 | Sin deudas ocultas | 350 | Durante el Módulo 3 |
| 4 | Alerta | 550 | Durante el Módulo 5 |
| 5 | Protegido | 750 | Durante el Módulo 7 |
| 6 | Con futuro | 900 | Durante el Módulo 8 |

**Clasificación (ranking): desactivada.** En *Level Up > Clasificación* elige no mostrarla, y quita o esconde el bloque de tabla de posiciones. Cada persona ve solo sus puntos, su nivel y sus insignias.

### 3. Insignias

*Más > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca. Los nombres llevan el curso para que no se repitan en la plataforma: úsalos tal cual.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_quincena_en_orden.png | Quincena en orden · Tu Turno | Autoevaluaciones de los Módulos 1 y 2 | Tu quincena tiene presupuesto, ahorro apartado y una cuenta sin comisiones. |
| 02_deudas_claras.png | Deudas claras · Tu Turno | Autoevaluación del Módulo 3 | Conoces todas tus deudas, lo que cuestan y tu plan para salir. |
| 03_tanda_segura.png | Tanda segura · Tu Turno | Autoevaluación del Módulo 4 | Sabes organizar una tanda con reglas o ahorrar por tu cuenta. |
| 04_buro_sin_miedo.png | Buró sin miedo · Tu Turno | Autoevaluación del Módulo 5 | Revisaste tu reporte de crédito y sabes cómo mejorarlo. |
| 05_nadie_me_extorsiona.png | Nadie me extorsiona · Tu Turno | Autoevaluación del Módulo 6 | Reconoces fraudes, apps montadeudas y extorsiones, y sabes qué hacer. |
| 06_familia_protegida.png | Familia protegida · Tu Turno | Autoevaluación del Módulo 7 | Tienes fondo de emergencia y protección para tu familia. |
| 07_futuro_en_marcha.png | Futuro en marcha · Tu Turno | Autoevaluación del Módulo 8 | Ahorras para tu retiro y tienes tu plan de una página. |
| 08_plan_completo.png | Plan completo · Tu Turno | Finalización del curso | Concluiste los ocho módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Más > Finalización del curso*: condición de finalización de actividades con **todas** las 8 autoevaluaciones. Opcional: los 8 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado** con la **plantilla estándar de la plataforma** (sin imagen de fondo): nombre "Constancia de conclusión".
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 8 autoevaluaciones, "debe estar completa con calificación aprobatoria", y la **Encuesta final** enviada.
3. En la plantilla cambia solo estos datos (también están en `6_constancia/constancia.md`):

   | Campo | Texto |
   |---|---|
   | Título del curso | Tu Turno, Tu Dinero, Tu Futuro |
   | Línea | por concluir el programa de bienestar financiero Tu Turno, Tu Dinero, Tu Futuro |
   | Tema 1 | Quincena y cuenta |
   | Tema 2 | Deudas y tandas |
   | Tema 3 | Buró y fraudes |
   | Tema 4 | Familia |
   | Tema 5 | Futuro |

4. Revisa la **Vista previa en PDF** y activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo · Tu Turno** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.


# Parte 3. Comunidad y canales


Este curso no tiene una comunidad en Moodle. Se acompaña con un canal de WhatsApp de avisos, porque el público toma las lecciones en el celular y entre turnos.

### 1. Canal de WhatsApp

- Nombre: "Tu Turno · Desarrolla Talento".
- Solo publica el equipo; los seguidores no ven el número de los demás.
- Dos publicaciones por quincena: el **reto de la quincena** (el día de pago) y una **alerta de fraude**.
- Todas las publicaciones terminan igual: «Desarrolla Talento nunca te pide datos, contraseñas ni dinero».

### 2. Retos de la quincena

| Quincena | Reto | Lección |
|---|---|---|
| 1 | Anota cuánto te llega de verdad | M1 U01 |
| 2 | Calcula tu gasto de turnos por 15 | M1 U02 |
| 3 | Aparta aunque sean 100 hoy | M1 U04 |
| 4 | Revisa si tu cuenta cobra comisiones | M2 U01 |
| 5 | Haz tu lista de deudas | M3 U01 |
| 6 | Elige tu primera deuda para pagar | M3 U04 |
| 7 | Pide tu reporte de crédito sin costo | M5 U02 |
| 8 | Revisa los permisos de tus apps | M6 U02 |
| 9 | Acuerda una palabra clave con tu familia | M6 U03 |
| 10 | Anota tu clínica y el hospital cercano | M7 U02 |
| 11 | Localiza tu AFORE con tu CURP | M8 U01 |
| 12 | Llena tu plan de una página y tu compromiso | M8 U03 |

### 3. Si una empresa ofrece el curso

- La empresa puede invitar y dar tiempo para tomarlo, pero **no recibe** información personal, financiera ni de avance individual; si pide reportes, solo agregados y anónimos.
- El curso no aborda la relación laboral de las personas con la empresa.

### 4. Referencias comerciales

Solo en el canal, siempre marcadas y nunca préstamos. Cada publicación dice: «Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Es voluntario y no afecta tu acceso ni tu constancia.»


# Parte 4. Mantenimiento


| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Enero | Salario mínimo del año | M1 U01 |
| Cada año | Límites de la cuenta básica | M2 U01 |
| Cada año | Monto mínimo de aportaciones voluntarias a la AFORE | M8 U01 |
| Cada seis meses | Alertas de la CONDUSEF sobre préstamos fraudulentos | M3 U03, M6 U02 |
| Cada año | REPEP, REUS y registro de líneas con CURP | M6 U05 |
| Cada año | Reglas y tasas de crédito de Infonavit | M4 U03 |
| Cada año | Meta de inflación del Banco de México y funcionamiento de Cetesdirecto | M2 U05, M2 U06 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco y volver a armar la carpeta | Herramientas del proyecto |

