# Tu Pensión, Tu Tranquilidad, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Doña Mago | 72 años. Cobra la Pensión Bienestar. Vive con su hijo y su nuera en Puebla. |
| Don Toño | 68 años. Viudo, pensionado del IMSS desde hace ocho años. Vive solo en Saltillo. |
| Doña Bertha | 66 años. Cuida a sus nietos y cobra la Pensión Bienestar. No usa el cajero. |
| Sofía | 25 años. Nieta de Doña Mago; es su acompañante de confianza en el programa. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Tu pensión y tu mes | Tu pensión repartida en el bimestre, con lo básico primero. | Pensión que alcanza |
| Módulo 2. Tu tarjeta y el cajero, sin riesgos | Tu NIP protegido y tu forma segura de usar el cajero. | Mi NIP es mío |
| Módulo 3. Llamadas, mensajes y «el nieto en apuros» | Tu regla para colgar y verificar ante llamadas y mensajes. | Cuelgo y verifico |
| Módulo 4. Cuando el abuso viene de casa | Las señales de abuso patrimonial y a quién llamar. | Nadie decide por mí |
| Módulo 5. Préstamos a cuenta de tu pensión | Tu decisión informada sobre préstamos y el tope de 30%. | Préstamo con cabeza |
| Módulo 6. Decidir con apoyo, sin perder el control | Tu persona de apoyo elegida y ningún poder amplio firmado sin revisar. | Apoyo de confianza |
| Módulo 7. Testamento y beneficiarios | Tus beneficiarios revisados y tu decisión sobre el testamento. |  |
| Módulo 8. Tu salud y tus seguros | Tu guardadito para salud y tus seguros revisados. |  |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Pensión y tarjeta, Fraudes, Abuso patrimonial, Testamento, Salud y seguros.

## 3. Lecciones

# Parte 2. Módulo 1. Tu pensión y tu mes

## M1 U01. Tu pensión llega cada dos meses

**Lo que lograrás:** Repartir la pensión bimestral para que alcance los dos meses.

**Para empezar:** Doña Mago cobra su Pensión Bienestar y la primera semana paga todo lo que debía. Al segundo mes ya no tiene ni para el pasaje al doctor. En esta lección verás cómo repartirla.

### Lo esencial (5 minutos)

#### Un pago, dos meses

La Pensión Bienestar llega cada **dos meses**. En 2026 son 6,400 pesos por bimestre: 3,200 para cada mes. Si se gasta el primer mes, el segundo no alcanza.



#### Divide en dos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mes 1 | La mitad: 3,200. | Lo básico primero. |
| Mes 2 | La otra mitad: 3,200. | Sin tocarla antes. |

#### Dos sobres o dos apartados

Saca o aparta la mitad para el segundo mes. Puede ser un sobre en casa en un lugar seguro, o dejarla en la tarjeta y no tocarla. Lo importante es que la segunda mitad no se use en el primer mes.



#### Un caso en un minuto

Doña Mago ahora deja 3,200 en la tarjeta para el segundo mes. Con la otra mitad paga comida, gas y medicinas. Ya no se queda sin pasaje.

> **Idea clave:** la pensión es de dos meses; divídela en dos y no toques la segunda mitad antes de tiempo.



#### Comprueba lo que entendiste

1. ¿Cada cuándo llega la Pensión Bienestar?
*Respuesta:* Cada dos meses.

2. ¿Cuánto es para cada mes en 2026?
*Respuesta:* 3,200 pesos.


#### Para recordar

- Llega cada dos meses.
- Divide en dos.
- No toques la segunda mitad.



### Profundiza (5 minutos más)

#### La pensión de Doña Mago

- Pensión del bimestre: **6,400**
- Meses: **2**
- Para cada mes: **3,200**


#### Si tienes otra pensión

Las pensiones del IMSS y del ISSSTE llegan cada mes. Si cobras una de ellas y también la Bienestar, suma lo que te llega al mes y reparte igual: lo básico primero.



#### Casos


**Caso 1. Pagar todo el primer mes**

Doña Mago paga todas sus cuentas la primera semana.
- *¿Qué hace?* Aparta la mitad para el segundo mes.


**Caso 2. El sobre a la vista**

Doña Bertha guarda la segunda mitad en un sobre en la mesa.
- *¿Qué hace?* Lo guarda en un lugar seguro o lo deja en la tarjeta.


**Caso 3. El préstamo al vecino**

El vecino le pide a Don Toño prestado de su pensión.
- *¿Qué hace?* Revisa primero si le alcanza para su mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar todo el primer mes | No alcanza el segundo | Divide en dos |
| Dejar el dinero a la vista | Se pierde o se toma | Lugar seguro |
| Prestar sin revisar | Te quedas corto | Revisa tu mes |
| No contar las fechas | Te sorprende | Anota el próximo pago |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Mago, Doña Bertha y Don Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cada cuándo llega la Pensión Bienestar? a) Cada dos meses · b) Cada semana · c) Una vez al año
2. Te llegan 6,400 por bimestre. ¿Cuánto es para cada mes? a) 6,400 · b) 3,200 · c) 1,600
3. ¿Qué haces con la segunda mitad? a) La prestas · b) La gastas en la primera semana · c) La guardas para el segundo mes
**Respuestas:** 1-a: es bimestral. 2-b: la mitad. 3-c: es del segundo mes.



#### Ponlo en práctica

Te llegan 6,400. Ya gastaste 2,900 este mes. ¿Cuánto te queda de la mitad de este mes?
**Respuesta:** 300 pesos.



#### A tu plan

Anota la fecha de tu próximo pago y decide dónde guardarás la mitad del segundo mes.



### Para saber más

- **Pensión para el Bienestar** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «adultos mayores».

### Palabras clave

- *Bimestre:* dos meses.
- *Pensión:* dinero que recibes cada cierto tiempo por edad o trabajo.
- *Apartar:* separar dinero para después.

### Fuentes

Secretaría de Bienestar, Reglas de Operación de la Pensión para el Bienestar de las Personas Adultas Mayores 2026; consultado el 5 de octubre de 2026.

---

## M1 U02. Lo básico primero

**Lo que lograrás:** Ordenar los gastos del mes poniendo primero comida, medicinas, casa y transporte.

**Para empezar:** Don Toño cobra su pensión del IMSS y siempre paga primero los compromisos. El abono del refrigerador, la cooperación de la fiesta, el préstamo del sobrino. Las medicinas quedan al final. En esta lección verás otro orden.

### Lo esencial (5 minutos)

#### El orden de tu mes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1. Comida | Lo de todos los días. | Primero. |
| 2. Medicinas y salud | Tus tratamientos. | No se suspenden. |
| 3. Casa | Luz, agua, gas, renta. | Para vivir bien. |
| 4. Transporte | Citas y mandados. | Lo necesario. |

#### Después, lo demás

Cuando lo básico está cubierto, sigue lo demás: deudas, regalos, fiestas, ayudas a la familia. Si no alcanza, se recorta lo de esta lista, no lo básico.



#### Una hoja sencilla

Escribe en una hoja lo que gastas en cada cosa básica. No hace falta ser exacto. Así sabes cuánto necesitas antes de comprometerte.



#### Un caso en un minuto

Don Toño anotó que lo básico le cuesta 5,800 al mes. Su pensión es de 7,500. Ahora sabe que tiene 1,700 para lo demás y dejó de prestar al sobrino.

> **Idea clave:** cubre primero comida, medicinas, casa y transporte; lo demás va después.



#### Comprueba lo que entendiste

1. ¿Qué cuatro gastos van primero?
*Respuesta:* Comida, medicinas, casa y transporte.

2. Si no alcanza, ¿qué se recorta?
*Respuesta:* Lo demás: fiestas, regalos o préstamos, no lo básico.


#### Para recordar

- Comida.
- Medicinas.
- Casa y transporte.



### Profundiza (5 minutos más)

#### Tu hoja del mes

| Gasto básico | Cuánto al mes |
|---|---|
| Comida | |
| Medicinas | |
| Luz, agua y gas | |
| Transporte | |
| **Total básico** | |



#### Ayudar sin quedarte sin nada

Si quieres ayudar a tu familia, hazlo con lo que queda después de lo básico. Decir «este mes no puedo» también es cuidarte.



#### Casos


**Caso 1. Las medicinas al final**

Don Toño paga primero el abono y deja las medicinas para después.
- *¿Qué hace?* Paga primero comida y medicinas.


**Caso 2. La cooperación**

Le piden a Doña Bertha 800 pesos para una fiesta.
- *¿Qué hace?* Revisa si le alcanza después de lo básico.


**Caso 3. Sin saber cuánto**

Doña Mago no sabe cuánto gasta en lo básico.
- *¿Qué hace?* Llena su hoja del mes aunque sea aproximada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar compromisos primero | Faltan medicinas | Lo básico primero |
| Suspender tratamientos | Daño a tu salud | No se recortan |
| No anotar | No sabes cuánto necesitas | Una hoja sencilla |
| Sentir culpa por decir no | Te quedas sin nada | Cuidarte también cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Bertha y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué pagas primero? a) La fiesta · b) Comida y medicinas · c) El préstamo del sobrino
2. No alcanza este mes. ¿Qué recortas? a) Las medicinas · b) La comida · c) Los regalos y cooperaciones
3. ¿Para qué sirve la hoja del mes? a) Para saber cuánto necesitas en lo básico · b) Para enseñarla al banco cuando pidas un préstamo · c) Para nada
**Respuestas:** 1-b: lo básico. 2-c: lo que no es básico. 3-a: para saber cuánto necesitas.



#### Ponlo en práctica

Tu pensión es de 7,000 y lo básico cuesta 5,600. ¿Cuánto te queda para lo demás?
**Respuesta:** 1,400 pesos.



#### A tu plan

Llena tu hoja del mes con lo que gastas en lo básico.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto personas adultas mayores».

### Palabras clave

- *Gasto básico:* lo que necesitas para vivir.
- *Compromiso:* gasto que sientes que te toca.
- *Recortar:* gastar menos en algo.

### Fuentes

CONDUSEF, recomendaciones para personas adultas mayores; consultado el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Tu tarjeta y el cajero, sin riesgos

## M2 U01. Tu NIP es solo tuyo

**Lo que lograrás:** Proteger tu NIP y tu tarjeta para que nadie cobre tu pensión sin tu permiso.

**Para empezar:** Doña Bertha no ve bien los números del cajero. Le pasó su tarjeta y su NIP a su nieto para que le saque el dinero. Desde entonces, cada bimestre le llega menos de lo que espera. En esta lección verás cómo cuidar tu NIP.

### Lo esencial (5 minutos)

#### El NIP abre tu dinero

Con tu tarjeta y tu NIP cualquier persona puede sacar todo tu dinero. Por eso el NIP es como la llave de tu casa: no se presta.



#### Cuida tu NIP

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Memorízalo | No lo escribas en la tarjeta. | Ni en un papel en la cartera. |
| Tapa el teclado | Con tu otra mano. | Siempre. |
| No lo digas | Ni por teléfono ni en persona. | Nadie del banco lo pide. |
| Cámbialo | Si alguien lo supo. | En el cajero o en el banco. |

#### Si necesitas ayuda para cobrar

En la Pensión Bienestar puedes registrar a una **persona auxiliar** de tu confianza para trámites. Así queda registrado quién te ayuda, en lugar de prestar tu tarjeta a cualquiera.



#### Un caso en un minuto

Doña Bertha cambió su NIP y ahora va al cajero con su nieta Sofía, que solo la acompaña. Ella teclea su NIP tapando el teclado. Ya le llega lo completo.

> **Idea clave:** tu NIP no se presta; si necesitas ayuda, que te acompañen, no que cobren por ti.



#### Comprueba lo que entendiste

1. ¿Dónde guardas tu NIP?
*Respuesta:* En tu memoria, no escrito en la tarjeta ni en la cartera.

2. ¿Qué haces si alguien conoció tu NIP?
*Respuesta:* Lo cambio en el cajero o en el banco.


#### Para recordar

- El NIP no se presta.
- Tapa el teclado.
- Si alguien lo supo, cámbialo.



### Profundiza (5 minutos más)

#### Un NIP fácil para ti y difícil para otros

Evita tu fecha de nacimiento o 1234. Elige cuatro números que recuerdes por otra razón, como el número de una casa donde viviste.



#### Revisa tu saldo

Pide en el banco cómo consultar tu saldo, por mensaje o en el cajero. Si te llega menos de lo esperado, reclama.



#### Casos


**Caso 1. El nieto cobra**

Doña Bertha le da su tarjeta y su NIP a su nieto.
- *¿Qué hace?* Cambia su NIP y va acompañada a cobrar.


**Caso 2. El NIP en la tarjeta**

Don Toño tiene el NIP escrito atrás de la tarjeta.
- *¿Qué hace?* Lo borra, lo memoriza y lo cambia.


**Caso 3. Necesita ayuda**

Doña Mago no puede ir sola a hacer trámites.
- *¿Qué hace?* Registra a una persona auxiliar de su confianza.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Prestar el NIP | Te sacan dinero | No se presta |
| Escribirlo en la tarjeta | Si la pierdes, pierdes todo | Memorízalo |
| NIP fácil | Lo adivinan | Uno propio |
| No revisar el saldo | No notas faltantes | Revisa cada pago |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Bertha, Don Toño y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Con quién compartes tu NIP? a) Con nadie · b) Con quien te ayude en el cajero · c) Con el banco por teléfono
2. Alguien vio tu NIP. ¿Qué haces? a) Nada · b) Lo cambias · c) Le pides que lo olvide
3. Necesitas ayuda con trámites de la Pensión Bienestar. ¿Qué haces? a) Prestas tu tarjeta al vecino que se ofrece · b) Dejas de cobrar · c) Registras a una persona auxiliar
**Respuestas:** 1-a: es tuyo. 2-b: se cambia. 3-c: queda registrado.



#### Ponlo en práctica

¿Cuál NIP es más seguro: 1234, tu año de nacimiento o un número de una casa donde viviste?
**Respuesta:** El número de una casa donde viviste.



#### A tu plan

Si alguien más conoce tu NIP, cámbialo esta semana. Elige a tu persona de confianza para acompañarte.



### Para saber más

- **Persona auxiliar** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «persona auxiliar».
- **Protege tu tarjeta** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «adultos mayores».

### Palabras clave

- *NIP:* número secreto de tu tarjeta.
- *Persona auxiliar:* alguien registrado para ayudarte en trámites.
- *Saldo:* dinero que tienes en tu cuenta.

### Fuentes

CONDUSEF y PROFECO, recomendaciones para personas adultas mayores; Secretaría de Bienestar, persona auxiliar; consultados el 5 de octubre de 2026.

---

## M2 U02. El cajero, sin riesgos

**Lo que lograrás:** Usar el cajero de forma segura y no aceptar ayuda de desconocidos.

**Para empezar:** Don Toño no pudo sacar su dinero porque el cajero «no le daba». Un joven amable le ofreció ayudarle. Le cambió la tarjeta sin que se diera cuenta. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Antes de ir

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| De día | En horario del banco. | Con gente alrededor. |
| Dentro de sucursal | Mejor que en la calle. | Si hay problema, pides ayuda. |
| Acompañado | Por tu persona de confianza. | Que no teclee por ti. |

#### Nunca aceptes ayuda de extraños

Si el cajero falla, no aceptes ayuda de nadie que esté ahí. Cancela, toma tu tarjeta y pide ayuda dentro de la sucursal, a personal del banco con gafete.



#### Revisa que sea tu tarjeta

Antes de guardarla, mira que sea tu tarjeta: tu nombre y tus últimos números. Si el cajero se quedó con ella, llama de inmediato al banco para bloquearla.



#### Un caso en un minuto

Ahora Don Toño va al cajero dentro de la sucursal, en la mañana. Una vez falló: canceló, tomó su tarjeta y preguntó en ventanilla. Era el cajero sin dinero.

> **Idea clave:** ve de día, de preferencia dentro de sucursal, y nunca aceptes ayuda de extraños en el cajero.



#### Comprueba lo que entendiste

1. ¿Qué haces si el cajero falla?
*Respuesta:* Cancelo, tomo mi tarjeta y pido ayuda dentro, a personal del banco.

2. ¿Qué revisas antes de guardar la tarjeta?
*Respuesta:* Que sea la mía: mi nombre y mis números.


#### Para recordar

- De día y en sucursal.
- Nada de ayuda de extraños.
- Revisa que sea tu tarjeta.



### Profundiza (5 minutos más)

#### Tu ficha de emergencia

| Dato | Lo tengo |
|---|---|
| Teléfono del banco para bloquear | |
| Últimos 4 números de mi tarjeta | |
| Persona de confianza | |



#### Si te retuvo la tarjeta

Llama al banco desde ahí y bloquéala. No te vayas sin hacerlo: a veces quien «te ayudó» espera a que te vayas para usarla.



#### Casos


**Caso 1. El joven amable**

Un joven ofrece ayudar a Don Toño con el cajero.
- *¿Qué hace?* Le dice que no y pide ayuda dentro de la sucursal.


**Caso 2. El cajero de noche**

Doña Mago quiere sacar dinero a las 9 de la noche en la calle.
- *¿Qué hace?* Espera a la mañana y va a un cajero dentro de sucursal.


**Caso 3. La tarjeta retenida**

El cajero se queda con la tarjeta de Doña Bertha.
- *¿Qué hace?* Llama al banco de inmediato para bloquearla.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar ayuda de extraños | Cambio de tarjeta | Pide ayuda dentro |
| Ir de noche | Riesgo de robo | De día |
| No revisar la tarjeta | Te quedas con otra | Revísala |
| Irte sin bloquear | Usan tu tarjeta | Llama al banco |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Mago y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. El cajero falla y alguien ofrece ayuda. ¿Qué haces? a) Aceptas · b) Le das tu NIP · c) Cancelas y pides ayuda dentro
2. ¿Cuál es el mejor lugar para usar el cajero? a) Dentro de una sucursal, de día · b) En la calle, de noche · c) En la calle, donde haya menos gente que te vea
3. El cajero se quedó con tu tarjeta. ¿Qué haces? a) Te vas a casa · b) Llamas al banco y la bloqueas · c) Esperas un rato a que la máquina la devuelva sola
**Respuestas:** 1-c: nada de extraños. 2-a: de día y en sucursal. 3-b: bloqueo inmediato.



#### Ponlo en práctica

Escribe los tres datos de tu ficha de emergencia que debes llevar contigo.
**Respuesta:** El teléfono del banco, los últimos 4 números de tu tarjeta y el nombre de tu persona de confianza.



#### A tu plan

Llena tu ficha de emergencia y guárdala separada de tu tarjeta.



### Para saber más

- **Uso seguro del cajero** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cajeros automáticos».

### Palabras clave

- *Cajero automático:* máquina para sacar dinero.
- *Bloquear:* pedir al banco que nadie pueda usar tu tarjeta.
- *Sucursal:* oficina del banco.

### Fuentes

CONDUSEF, recomendaciones de uso seguro de cajeros; consultado el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Llamadas, mensajes y «el nieto en apuros»

## M3 U01. «Abuelita, soy yo, estoy en problemas»

**Lo que lograrás:** Reconocer la llamada del «nieto en apuros» y la del falso banco, y saber qué hacer.

**Para empezar:** A Doña Mago le llamaron llorando: «Abuelita, soy yo, choqué y me van a llevar si no deposito 5,000». La voz se parecía a la de su nieto. Estuvo a punto de ir al Oxxo. En esta lección verás cómo actuar.

### Lo esencial (5 minutos)

#### Las dos llamadas más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| El familiar en apuros | Choque, detención, hospital. | Piden depósito urgente. |
| El falso banco | «Detectamos un cargo». | Piden NIP, clave o código. |

#### Cuelga y llama tú

No discutas ni des datos. Cuelga y llama tú al familiar con el número que ya tienes, o al banco con el número de atrás de tu tarjeta. Si no te contesta, llama a otro familiar.



#### Una palabra clave familiar

Acuerden en familia una palabra que solo ustedes sepan. Si alguien llama pidiendo dinero «de parte de» un familiar, pide la palabra.



#### Un caso en un minuto

Doña Mago colgó y llamó a Sofía. Su nieto estaba en la escuela. No depositó nada y avisó a la familia.

> **Idea clave:** ante una llamada urgente pidiendo dinero o datos, cuelga y llama tú.



#### Comprueba lo que entendiste

1. ¿Qué haces si te llaman pidiendo un depósito urgente por un familiar?
*Respuesta:* Cuelgo y llamo yo al familiar con el número que ya tengo.

2. ¿El banco te pide tu NIP por teléfono?
*Respuesta:* No, nunca.


#### Para recordar

- Cuelga.
- Llama tú.
- Palabra clave familiar.



### Profundiza (5 minutos más)

#### La prisa es la trampa

Los delincuentes te apuran para que no pienses: «ahorita», «no cuelgues», «no le digas a nadie». Esa prisa es la señal para colgar.



#### Si ya depositaste

Llama al banco desde donde depositaste, guarda el comprobante y denuncia al 089. Avísale a tu familia para que no les pase lo mismo.



#### Casos


**Caso 1. El nieto que llora**

Le piden a Doña Mago 5,000 para su nieto «detenido».
- *¿Qué hace?* Cuelga y llama a su nieta Sofía.


**Caso 2. El cargo raro**

Llaman a Don Toño «del banco» para cancelar un cargo con su NIP.
- *¿Qué hace?* Cuelga y llama al número de atrás de su tarjeta.


**Caso 3. «No cuelgue»**

A Doña Bertha le dicen que no cuelgue porque «pierde su pensión».
- *¿Qué hace?* Cuelga: la prisa es la señal de fraude.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Depositar por miedo | Pierdes tu dinero | Cuelga y llama tú |
| Dar el NIP | Te vacían la cuenta | Nadie lo pide |
| Seguir en la llamada | Te convencen | Cuelga |
| No avisar a la familia | Les pasa a otros | Cuéntalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Mago, Don Toño y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te llaman «del banco» y piden tu NIP. ¿Qué haces? a) Lo das · b) Cuelgas · c) Das solo dos números
2. ¿Qué sirve para confirmar que es tu familiar? a) Una palabra clave familiar · b) Que llore · c) Que sepa tu nombre y el de tu familia
3. ¿Cuál es la señal más clara de fraude? a) Que llamen en la mañana · b) Que la voz sea joven y hable muy rápido · c) La prisa y que pidan dinero o datos
**Respuestas:** 1-b: nadie pide el NIP. 2-a: solo ustedes la saben. 3-c: la prisa.



#### Ponlo en práctica

Escribe tu frase para colgar sin discutir.
**Respuesta:** Ejemplo: «Ahorita le llamo yo», y cuelgo.



#### A tu plan

Acuerda con tu familia una palabra clave y guarda el 089 en tu teléfono.



### Para saber más

- **Fraudes telefónicos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraude telefónico».
- **Denuncia anónima:** 089.

### Palabras clave

- *Fraude:* engaño para quitarte dinero.
- *Palabra clave:* contraseña de tu familia.
- *Denuncia:* aviso a la autoridad.

### Fuentes

CONDUSEF y PROFECO, recomendaciones contra estafas a personas adultas mayores; consultados el 5 de octubre de 2026.

---

## M3 U02. Mensajes, premios y ligas

**Lo que lograrás:** Reconocer mensajes falsos de premios, apoyos y paquetes, y no abrir sus ligas.

**Para empezar:** A Don Toño le llegó un mensaje: «Ganaste un aumento a tu pensión, actualiza tus datos aquí» con una liga. Su vecina ya había puesto sus datos. En esta lección verás qué hacer con esos mensajes.

### Lo esencial (5 minutos)

#### Mensajes que son trampa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Premios | «Ganaste un sorteo». | No participaste. |
| Apoyos y aumentos | «Actualiza tus datos para cobrar». | Los programas no piden datos por mensaje. |
| Paquetes | «Tu paquete está detenido». | Piden pago o datos. |
| Número nuevo | «Soy tu hijo, cambié de número». | Pide dinero. |

#### No abras la liga

No toques las ligas de mensajes que no esperabas. Si dudas, pregunta en la oficina del programa o al familiar por otro medio.



#### Borra y bloquea

Borra el mensaje y bloquea el número. Si ya pusiste datos, llama a tu banco y avísale a tu familia.



#### Un caso en un minuto

Don Toño no abrió la liga. Preguntó en el módulo del Bienestar: no había ningún aumento por mensaje. Le ayudó a su vecina a llamar a su banco.

> **Idea clave:** si un mensaje promete dinero o pide datos, no abras la liga: borra, bloquea y pregunta por otro medio.



#### Comprueba lo que entendiste

1. ¿Los programas del Bienestar piden tus datos por mensaje con una liga?
*Respuesta:* No; si te piden datos por mensaje, es trampa.

2. ¿Qué haces con un mensaje así?
*Respuesta:* No abro la liga, lo borro y bloqueo el número.


#### Para recordar

- No abras ligas.
- Borra y bloquea.
- Pregunta por otro medio.



### Profundiza (5 minutos más)

#### El «hijo con número nuevo»

Si alguien dice ser tu hijo con un número nuevo y pide dinero, no hagas nada todavía. Primero llama al número de siempre de tu hijo.



#### Pide ayuda para revisar

Tu persona de confianza puede ayudarte a revisar mensajes dudosos. Mejor preguntar que perder.



#### Casos


**Caso 1. El aumento por mensaje**

A Don Toño le piden datos para un «aumento».
- *¿Qué hace?* No abre la liga y pregunta en el módulo del Bienestar.


**Caso 2. El paquete detenido**

A Doña Bertha le cobran 49 pesos por un paquete que no espera.
- *¿Qué hace?* Borra el mensaje y bloquea el número.


**Caso 3. El hijo con número nuevo**

A Doña Mago le escribe «su hijo» desde otro número pidiendo 3,000.
- *¿Qué hace?* Llama al número de siempre de su hijo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Abrir ligas | Robo de datos | No las abras |
| Pagar por paquetes | Fraude | Borra |
| Creer en premios | Pierdes dinero | No participaste |
| Mandar dinero al «número nuevo» | Fraude | Llama al de siempre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Bertha y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te llega un mensaje con un premio y una liga. ¿Qué haces? a) Lo abres · b) Lo borras y bloqueas · c) Lo reenvías
2. «Tu hijo» te escribe de otro número pidiendo dinero. ¿Qué haces? a) Llamas al número de siempre de tu hijo · b) Depositas · c) Le pides que espere una semana y luego depositas
3. Ya pusiste tus datos en una liga. ¿Qué haces? a) Nada · b) Pones más datos · c) Llamas a tu banco y avisas a tu familia
**Respuestas:** 1-b: es trampa. 2-a: verificas. 3-c: actúas rápido.



#### Ponlo en práctica

Un mensaje te cobra 49 pesos por un paquete que no esperas. ¿Lo pagas?
**Respuesta:** No; lo borro y bloqueo el número.



#### A tu plan

Pide a tu persona de confianza que te ayude a bloquear números desconocidos en tu teléfono.



### Para saber más

- **Fraudes por mensaje** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «phishing» y «smishing».

### Palabras clave

- *Liga:* enlace que abre una página.
- *Bloquear un número:* hacer que no te pueda escribir.
- *Datos personales:* información sobre ti, como tu nombre, NIP o CURP.

### Fuentes

CONDUSEF, alertas de fraude por mensaje; consultado el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Cuando el abuso viene de casa

## M4 U01. Señales de abuso patrimonial

**Lo que lograrás:** Reconocer cuando alguien cercano usa tu dinero o tus bienes sin tu permiso.

**Para empezar:** El hijo de Doña Mago le pidió firmar «unos papeles del predial». Eran para pasar la casa a su nombre. Ella no lo leyó porque confía en él. En esta lección verás las señales.

### Lo esencial (5 minutos)

#### Cuando el abuso viene de casa

La CONDUSEF reporta que las afectaciones a personas mayores vienen sobre todo de familiares y personas cercanas con acceso a sus tarjetas o teléfonos. Después vienen empleados desleales y, en tercer lugar, la delincuencia organizada. No es raro y no es tu culpa.



#### Señales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu dinero falta | Retiros que no hiciste. | Alguien usa tu tarjeta. |
| Te piden firmar | Papeles que no te explican. | Casa, préstamos, poderes. |
| Te quitan el control | Guardan tu tarjeta «por tu bien». | No te dejan ver tu saldo. |
| Te presionan | Insisten, te hacen sentir culpable. | O te amenazan. |

#### Nunca firmes sin leer

No firmes nada que no entiendas, aunque te lo pida alguien de confianza. Pide una copia, llévala con otra persona o a una notaría o asesoría jurídica, y pregunta.



#### Un caso en un minuto

Doña Mago pidió a Sofía leer los papeles con ella. Vio que era la casa. No firmó y habló con su hijo con calma.

> **Idea clave:** si falta tu dinero, te piden firmar sin explicar o te quitan el control, es una señal; no firmes sin leer.



#### Comprueba lo que entendiste

1. ¿De dónde vienen sobre todo las afectaciones a personas mayores, según CONDUSEF?
*Respuesta:* De familiares y personas cercanas con acceso a sus tarjetas o teléfonos.

2. ¿Qué haces si te piden firmar un papel que no entiendes?
*Respuesta:* No firmo; pido copia y lo reviso con alguien más.


#### Para recordar

- Revisa tu saldo.
- No firmes sin leer.
- Tu tarjeta la guardas tú.



### Profundiza (5 minutos más)

#### ¿Te ha pasado?

| Señal | Sí | No |
|---|---|---|
| Me falta dinero que no saqué | | |
| Me pidieron firmar sin explicar | | |
| Otra persona guarda mi tarjeta | | |
| Me presionan para prestar o ceder bienes | | |



#### Hablarlo no es traicionar

Puedes querer a tu familia y también poner límites. Proteger tus bienes es protegerte para los años que vienen.



#### Casos


**Caso 1. Los papeles del predial**

El hijo de Doña Mago le pide firmar sin explicar.
- *¿Qué hace?* Pide una copia y la lee con alguien de confianza.


**Caso 2. La tarjeta guardada**

La cuidadora de Don Toño guarda su tarjeta «para que no la pierda».
- *¿Qué hace?* La recupera y revisa su saldo.


**Caso 3. El retiro que no hizo**

A Doña Bertha le faltan 2,000 en su cuenta.
- *¿Qué hace?* Revisa sus movimientos, cambia su NIP y reclama al banco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar por confianza | Pierdes tu casa | Lee antes |
| Dejar tu tarjeta a otro | Te sacan dinero | Guárdala tú |
| Callar por pena | Sigue pasando | Habla con alguien |
| No revisar el saldo | No notas faltantes | Revisa cada pago |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Mago, Don Toño y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es una señal de abuso patrimonial? a) Te faltan retiros que no hiciste · b) Tu nieto te visita · c) Te llega tu pensión completa cada bimestre
2. Tu hijo te pide firmar un papel que no entiendes. ¿Qué haces? a) Firmas, porque confías en tu hijo · b) Pides copia y lo revisas con alguien · c) Lo tiras
3. ¿Quién debe guardar tu tarjeta? a) Tu cuidadora · b) El vecino · c) Tú
**Respuestas:** 1-a: alguien usa tu dinero. 2-b: revisa antes. 3-c: es tuya.



#### Ponlo en práctica

Te faltan 2,000 pesos en tu cuenta. Escribe dos cosas que haces hoy.
**Respuesta:** Cambio mi NIP y reclamo al banco (también puedo revisar mis movimientos).



#### A tu plan

Revisa tu saldo después de cada pago y llena la tabla «¿Te ha pasado?».



### Para saber más

- **Abuso financiero a personas mayores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «adultos mayores abuso».
- **INAPAM** (Gobierno de México · español): https://www.gob.mx/inapam — **Qué buscar:** «asesoría jurídica».

### Palabras clave

- *Abuso patrimonial:* cuando alguien usa tu dinero o tus bienes sin tu permiso.
- *Bienes:* lo que es tuyo, como tu casa o tu terreno.
- *Movimientos:* entradas y salidas de dinero de tu cuenta.

### Fuentes

CONDUSEF, abuso financiero a personas adultas mayores; INAPAM, asesoría jurídica; consultados el 5 de octubre de 2026.

---

## M4 U02. A quién llamar

**Lo que lograrás:** Explicar a dónde acudir si alguien abusa de tu dinero, tus bienes o tu persona.

**Para empezar:** Don Toño sospecha que su sobrino sacó un préstamo a su nombre. No sabe si ir al banco, a la policía o «dejarlo así». En esta lección tendrás tu lista de a quién llamar.

### Lo esencial (5 minutos)

#### Tu lista de ayuda

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu banco | Cargos y retiros que no hiciste. | Bloqueo y reclamación. |
| CONDUSEF | Si el banco no resuelve. | 55 5340 0999. |
| INAPAM o DIF | Asesoría jurídica y orientación. | Abuso, despojo. |
| 911 | Si hay violencia o peligro. | Emergencia. |

#### Junta pruebas

Guarda estados de cuenta, comprobantes, mensajes y papeles. Anota fechas. Con eso es más fácil que te ayuden.



#### No lo hagas solo

Ve con tu persona de confianza. Si el abuso viene de ella, busca a otra persona o ve directamente al INAPAM o al DIF.



#### Un caso en un minuto

Don Toño pidió su reporte de crédito y vio el préstamo. Lo reclamó al banco con su folio y pidió orientación en el INAPAM. Su sobrino tuvo que responder.

> **Idea clave:** banco para cargos, CONDUSEF si no resuelven, INAPAM o DIF para orientación jurídica y 911 si hay peligro.



#### Comprueba lo que entendiste

1. ¿A dónde vas si el banco no resuelve tu reclamación?
*Respuesta:* A CONDUSEF, 55 5340 0999.

2. ¿Qué llamas si hay violencia o peligro?
*Respuesta:* Al 911.


#### Para recordar

- Banco.
- CONDUSEF.
- INAPAM o DIF y 911.



### Profundiza (5 minutos más)

#### Mi lista de ayuda

| A quién | Teléfono o dirección |
|---|---|
| Mi banco | |
| CONDUSEF | 55 5340 0999 |
| INAPAM o DIF de mi municipio | |
| Persona de confianza | |
| Emergencias | 911 |



#### Revisa tu reporte de crédito

Puedes pedir tu reporte especial sin costo una vez al año en Buró de Crédito y en Círculo de Crédito. Ahí ves si alguien sacó un préstamo a tu nombre.



#### Casos


**Caso 1. El préstamo del sobrino**

Don Toño sospecha que sacaron un préstamo a su nombre.
- *¿Qué hace?* Pide su reporte de crédito y reclama con pruebas.


**Caso 2. El banco no contesta**

El banco no le resuelve a Doña Bertha en 30 días.
- *¿Qué hace?* Acude a CONDUSEF con su folio.


**Caso 3. Amenazas en casa**

A Doña Mago la amenazan para que firme.
- *¿Qué hace?* Llama al 911 y busca orientación en el INAPAM o el DIF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejarlo así | Sigue pasando | Actúa |
| Ir sin pruebas | Es más difícil | Junta papeles |
| Ir solo | Te desanimas | Con alguien de confianza |
| No revisar el reporte | No ves préstamos ajenos | Pídelo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Bertha y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Hay un retiro que no hiciste. ¿A quién llamas primero? a) A tu banco · b) Al 911 · c) A nadie
2. El banco no resuelve. ¿A dónde vas? a) A otro banco · b) A CONDUSEF · c) A la tienda
3. Te amenazan para que firmes. ¿Qué haces? a) Firmas · b) Esperas a que pase · c) Llamas al 911 y buscas orientación
**Respuestas:** 1-a: bloqueo y reclamación. 2-b: defiende usuarios. 3-c: es peligro.



#### Ponlo en práctica

¿Dónde puedes ver si alguien sacó un préstamo a tu nombre?
**Respuesta:** En tu reporte de crédito especial, sin costo una vez al año.



#### A tu plan

Llena tu lista de ayuda con los teléfonos y guárdala junto a tu ficha de emergencia.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** cómo presentar una queja contra un banco o financiera y qué papeles tener a la mano; teléfono 55 5340 0999.
- **INAPAM** (Gobierno de México · español): https://www.gob.mx/inapam — **Qué buscar:** «asesoría jurídica».
- **Reporte de crédito especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.
- **Reporte de crédito especial** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** cómo pedir tu reporte sin costo una vez al año y cómo levantar una aclaración.

### Palabras clave

- *Reclamación:* queja formal con folio.
- *Despojo:* cuando te quitan un bien de forma injusta.
- *Prueba:* papel o mensaje que muestra lo que pasó.

### Fuentes

CONDUSEF; INAPAM; Buró de Crédito y Círculo de Crédito; consultados el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Préstamos a cuenta de tu pensión

## M5 U01. El préstamo a cuenta de tu pensión

**Lo que lograrás:** Explicar cómo funcionan los préstamos que se descuentan de la pensión del IMSS y sus límites.

**Para empezar:** A Don Toño le ofrecen afuera de la clínica «un préstamo fácil, se descuenta solito de tu pensión». Le prometen 40,000 pesos. No le dicen cuánto pagará en total. En esta lección verás qué preguntar.

### Lo esencial (5 minutos)

#### Para quién es

Las personas pensionadas por la Ley del Seguro Social de 1973 pueden pedir préstamos que se descuentan de su pensión del IMSS. Solo con entidades financieras que tengan **convenio vigente** con el IMSS.



#### Los límites

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Descuento máximo | 30% de la pensión. | No más. |
| Plazo máximo | 60 meses. | Cinco años. |
| Solo con convenio | Lista oficial del IMSS. | Verifícalo. |

#### Pregunta el total

Antes de firmar, pregunta: ¿cuánto me descuentan cada mes?, ¿cuántos meses?, ¿cuánto pagaré en total?, ¿cuál es el CAT? Multiplica el descuento por los meses y compáralo con lo que te prestan.



#### Un caso en un minuto

A Don Toño le descontarían 1,800 al mes por 48 meses: 86,400 por 40,000. Decidió no pedirlo y apartar un poco cada mes para su imprevisto.

> **Idea clave:** el descuento no puede pasar de 30% de tu pensión; antes de firmar, calcula cuánto pagarás en total.



#### Comprueba lo que entendiste

1. ¿Cuál es el descuento máximo de un préstamo a cuenta de pensión del IMSS?
*Respuesta:* 30% de la pensión.

2. ¿Con quién puedes pedirlo?
*Respuesta:* Solo con entidades con convenio vigente con el IMSS.


#### Para recordar

- Tope de 30%.
- Máximo 60 meses.
- Pregunta el total.



### Profundiza (5 minutos más)

#### El préstamo de Don Toño

- Descuento al mes: **1,800**
- Meses: **48**
- Total que pagaría: **86,400**
- Lo que le prestan: **40,000**
- Lo que le cuesta: **46,400**


#### Cuidado con quien ofrece en la calle

Quien ofrece préstamos afuera de clínicas o bancos puede no tener convenio. Verifica en la lista oficial del IMSS y en el SIPRES de CONDUSEF.



#### Casos


**Caso 1. «Se descuenta solito»**

A Don Toño le ofrecen 40,000 sin decirle el total.
- *¿Qué hace?* Pregunta el descuento, los meses y el total antes de decidir.


**Caso 2. El 45%**

A un compañero le quieren descontar 45% de su pensión.
- *¿Qué hace?* Sabe que el tope es 30% y no firma.


**Caso 3. La oferta en la clínica**

Le ofrecen un préstamo afuera de la clínica.
- *¿Qué hace?* Verifica que la entidad tenga convenio con el IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin el total | Pagas el doble | Calcula |
| Aceptar más de 30% | Tu pensión no alcanza | Es el tope |
| Creer en ofertas en la calle | Fraude | Verifica el convenio |
| Pedir para gastos que no son urgentes | Deuda por años | Piensa antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño y un compañero. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es el tope de descuento a tu pensión del IMSS? a) 30% · b) 50% · c) No hay tope
2. Te descuentan 1,500 al mes por 36 meses. ¿Cuánto pagas en total? a) 15,000 · b) 54,000 · c) 36,000
3. ¿Con quién se puede pedir un préstamo a cuenta de pensión IMSS? a) Con cualquiera · b) Con quien te ofrezca afuera de la clínica · c) Solo con entidades con convenio
**Respuestas:** 1-a: 30%. 2-b: 1,500 por 36. 3-c: convenio vigente.



#### Ponlo en práctica

Tu pensión es de 8,000. ¿Cuánto es lo máximo que te pueden descontar al mes?
**Respuesta:** 2,400 pesos.



#### A tu plan

Si te ofrecen un préstamo, escribe las cuatro preguntas y no firmes hasta tener las respuestas por escrito.



### Para saber más

- **Préstamos a pensionados** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «préstamos a pensionados» y «entidades financieras con convenio».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Descuento:* lo que te quitan de la pensión cada mes.
- *Convenio:* acuerdo oficial entre el IMSS y una entidad.
- *CAT:* costo anual total del préstamo.

### Fuentes

IMSS, préstamos a cuenta de pensión para pensionados Ley 73 (tope de 30% y plazo máximo de 60 meses); consultado el 5 de octubre de 2026.

---

## M5 U02. Préstamos para otros

**Lo que lograrás:** Decidir con cuidado antes de pedir un préstamo o ser aval para alguien más.

**Para empezar:** La nuera de Doña Mago le pidió sacar un crédito a su nombre «porque a ella no le prestan». Prometió pagarlo ella. A los tres meses dejó de pagar y llaman a Doña Mago para cobrarle. En esta lección verás qué pasa.

### Lo esencial (5 minutos)

#### Si está a tu nombre, la deuda es tuya

Si el préstamo está a tu nombre, la deuda es tuya, aunque otra persona prometa pagarla. Si ella deja de pagar, te cobran a ti y afecta tu historial.



#### Antes de decir sí

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Puedo pagarlo yo sola? | Si la otra persona no paga. | Con mi pensión. |
| ¿Cuánto tiempo? | Meses o años. | Pagando. |
| ¿Lo puedo ayudar de otra forma? | Sin firmar. | Tiempo, consejo, compañía. |

#### Ser aval también es deber

Si firmas como aval, te pueden cobrar si la otra persona no paga. Firma solo si podrías pagarlo tú.



#### Un caso en un minuto

Ahora Doña Mago dice: «No firmo créditos para nadie; si puedo, ayudo con otra cosa». Su familia lo entendió.

> **Idea clave:** si el préstamo está a tu nombre o eres aval, la deuda también es tuya; firma solo si podrías pagarla tú.



#### Comprueba lo que entendiste

1. Sacas un préstamo para otra persona y deja de pagar. ¿A quién cobran?
*Respuesta:* A mí, porque está a mi nombre.

2. ¿Cuándo firmar como aval?
*Respuesta:* Solo si podría pagarlo yo.


#### Para recordar

- A tu nombre, deuda tuya.
- Aval también debe.
- Ayuda de otra forma.



### Profundiza (5 minutos más)

#### Una frase para decir que no

«Te quiero ayudar, pero no puedo firmar créditos. Te acompaño a buscar otra opción.»



#### Tu historial también cuenta

Un préstamo atrasado a tu nombre te puede cerrar puertas cuando tú necesites un crédito o un servicio.



#### Casos


**Caso 1. El crédito de la nuera**

Le piden a Doña Mago un crédito a su nombre.
- *¿Qué hace?* No firma, porque la deuda sería suya.


**Caso 2. El aval del vecino**

El vecino le pide a Don Toño ser su aval.
- *¿Qué hace?* Firma solo si podría pagarlo él; si no, dice que no.


**Caso 3. Ya firmó**

Doña Bertha firmó un crédito para su hijo y él no paga.
- *¿Qué hace?* Habla con el banco para buscar un plan de pago y deja de firmar créditos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer la promesa | La deuda es tuya | Piensa antes |
| Firmar como aval sin poder pagar | Te cobran | Solo si puedes |
| No decir que no | Te endeudas | Ten tu frase |
| Esconder la deuda | Crece | Busca un plan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Mago, Don Toño y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿De quién es la deuda de un préstamo a tu nombre? a) Tuya · b) De quien lo usa · c) De nadie
2. ¿Qué pasa si eres aval y la otra persona no paga? a) Nada · b) Te pueden cobrar a ti · c) Se cancela la deuda porque no es tuya
3. ¿Qué puedes ofrecer en lugar de firmar? a) Tu NIP · b) Tu casa · c) Tu compañía para buscar otra opción
**Respuestas:** 1-a: es tuya. 2-b: el aval debe. 3-c: ayudar sin firmar.



#### Ponlo en práctica

Escribe tu frase para decir que no a firmar un crédito para alguien.
**Respuesta:** Ejemplo: «Te quiero ayudar, pero no puedo firmar créditos».



#### A tu plan

Escribe tu frase para decir que no y practícala con tu persona de confianza.



### Para saber más

- **Aval y obligado solidario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ser aval».

### Palabras clave

- *Aval:* quien promete pagar si el otro no paga.
- *Historial de crédito:* registro de cómo pagas tus deudas.
- *Plan de pago:* acuerdo para pagar en partes.

### Fuentes

CONDUSEF, recomendaciones sobre ser aval y préstamos a nombre de otros; consultado el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Decidir con apoyo, sin perder el control

## M6 U01. Poder amplio o poder limitado

**Lo que lograrás:** Distinguir un poder notarial amplio de uno limitado y no firmar uno sin revisarlo.

**Para empezar:** El sobrino de Don Toño le pidió un poder «para hacerle los trámites del banco». El notario le leyó que era un poder general para actos de dominio: podía vender su casa. En esta lección verás la diferencia.

### Lo esencial (5 minutos)

#### Qué es un poder

Un poder notarial es un papel firmado ante notario que permite a otra persona actuar en tu nombre. Puede ser muy amplio o muy limitado. Lo que diga el papel es lo que la otra persona podrá hacer.



#### Dos tipos muy distintos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Poder amplio | Para casi todo, incluso vender tus bienes. | Mucho riesgo. |
| Poder limitado o especial | Para un trámite concreto y por un tiempo. | Menos riesgo. |

#### Lo que conviene pedir

Si necesitas que alguien te ayude, pide un poder **para ese trámite**, con fecha de término. Antes de firmar, pide al notario que te explique qué podrá hacer la otra persona y lee el papel con alguien de tu confianza.



#### Un caso en un minuto

Don Toño no firmó el poder general. Pidió uno especial solo para cobrar un trámite del banco, por seis meses. Su casa quedó a salvo.

> **Idea clave:** si das un poder, que sea limitado a un trámite y con fecha de término; nunca firmes uno amplio sin entenderlo.



#### Comprueba lo que entendiste

1. ¿Qué permite un poder amplio?
*Respuesta:* Que otra persona haga casi todo en tu nombre, incluso vender tus bienes.

2. ¿Qué tipo de poder conviene para ayudarte con un trámite?
*Respuesta:* Uno limitado o especial, para ese trámite y con fecha de término.


#### Para recordar

- Poder limitado.
- Con fecha de término.
- Que te lo expliquen.



### Profundiza (5 minutos más)

#### Antes de firmar un poder

| Pregunta | Respuesta |
|---|---|
| ¿Para qué trámite es? | |
| ¿Puede vender o hipotecar algo? | |
| ¿Hasta cuándo dura? | |
| ¿Cómo lo puedo cancelar? | |



#### Un poder se puede cancelar

Si cambias de opinión, puedes revocar el poder ante notario. Avisa también al banco u oficina donde se usaba.



#### Casos


**Caso 1. «Para los trámites del banco»**

El sobrino de Don Toño le pide un poder general.
- *¿Qué hace?* Pide uno especial solo para ese trámite y con fecha.


**Caso 2. Sin leer**

A Doña Mago le dicen que firme rápido «porque el notario se va».
- *¿Qué hace?* No firma hasta que le expliquen qué podrá hacer la otra persona.


**Caso 3. Ya no confía**

Doña Bertha dio un poder hace años y ya no confía en esa persona.
- *¿Qué hace?* Lo revoca ante notario y avisa al banco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar un poder amplio | Pueden vender tus bienes | Uno limitado |
| Sin fecha de término | Dura para siempre | Ponle fecha |
| Firmar con prisa | No sabes qué firmaste | Pide explicación |
| Olvidar que se puede cancelar | Sigues expuesto | Revócalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Mago y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué poder conviene para un solo trámite? a) Uno general para todo, así no vuelves a la notaría · b) Uno limitado con fecha de término · c) Ninguno, mejor das tu NIP
2. ¿Se puede cancelar un poder? a) Sí, ante notario · b) No, nunca · c) Solo si muere la otra persona
3. ¿Qué haces antes de firmar un poder? a) Firmas rápido · b) Pides que te expliquen qué podrá hacer la otra persona · c) Le das tu tarjeta
**Respuestas:** 1-b: limitado. 2-a: se revoca. 3-b: entiende antes.



#### Ponlo en práctica

Escribe las cuatro preguntas que haces antes de firmar un poder.
**Respuesta:** ¿Para qué trámite es?, ¿puede vender o hipotecar algo?, ¿hasta cuándo dura?, ¿cómo lo cancelo?



#### A tu plan

Si diste un poder, revisa qué tipo es y si sigue vigente.



### Para saber más

- **Poderes notariales** (Colegio Nacional del Notariado Mexicano · español): https://www.notariadomexicano.org.mx — **Qué buscar:** «poder notarial».
- **Recomendaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «adultos mayores poder notarial».

### Palabras clave

- *Poder notarial:* papel que permite a otro actuar en tu nombre.
- *Revocar:* cancelar.
- *Actos de dominio:* vender, regalar o hipotecar bienes.

### Fuentes

CONDUSEF, recomendaciones a personas adultas mayores sobre poderes notariales; consultado el 5 de octubre de 2026.

---

## M6 U02. Tu persona de apoyo

**Lo que lograrás:** Elegir a una persona de apoyo que te acompañe en tus decisiones de dinero sin decidir por ti.

**Para empezar:** Doña Bertha ya no se siente segura en el banco y le pide a «quien esté» que le ayude. A veces es su hijo, a veces el vecino, a veces nadie. En esta lección elegirás a tu persona de apoyo.

### Lo esencial (5 minutos)

#### Apoyo no es control

Tu persona de apoyo te acompaña, te explica y te ayuda a revisar. Pero **tú decides**. No guarda tu tarjeta ni sabe tu NIP.



#### Cómo elegirla

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Confianza | Alguien que te respete. | No que te presione. |
| Tiempo | Que pueda acompañarte. | En trámites y citas. |
| Sin interés propio | Que no gane con tus decisiones. | Mejor. |
| Más de una | Si se puede, dos personas. | Se cuidan entre sí. |

#### Regístrala donde se pueda

En la Pensión Bienestar puedes registrar a una persona auxiliar. En el banco pregunta qué opciones tienen para que alguien te acompañe sin darle tu NIP.



#### Un caso en un minuto

Doña Bertha eligió a su hija y a su comadre. Su hija está registrada como auxiliar. Las dos la acompañan, y ella sigue decidiendo.

> **Idea clave:** elige a una o dos personas de apoyo que te acompañen; tú sigues decidiendo y tu NIP es solo tuyo.



#### Comprueba lo que entendiste

1. ¿Quién decide cuando tienes persona de apoyo?
*Respuesta:* Yo.

2. ¿Tu persona de apoyo debe saber tu NIP?
*Respuesta:* No.


#### Para recordar

- Tú decides.
- Sin NIP compartido.
- Una o dos personas.



### Profundiza (5 minutos más)

#### Mi persona de apoyo

| Dato | Persona 1 | Persona 2 |
|---|---|---|
| Nombre | | |
| Teléfono | | |
| Me acompaña en | | |
| Registrada como auxiliar | | |



#### Puedes cambiarla

Si tu persona de apoyo ya no te da confianza, puedes cambiarla. Avisa en la oficina del programa o en el banco.



#### Casos


**Caso 1. «Quien esté»**

Doña Bertha pide ayuda a quien esté en el momento.
- *¿Qué hace?* Elige a una o dos personas de confianza.


**Caso 2. «Dame tu NIP para ayudarte»**

La persona de apoyo de Don Toño le pide su NIP.
- *¿Qué hace?* No se lo da: lo acompaña sin saberlo.


**Caso 3. Ya no confía**

Doña Mago ya no confía en su auxiliar.
- *¿Qué hace?* La cambia y avisa en la oficina del programa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Cambiar de ayudante cada vez | Nadie da seguimiento | Una o dos fijas |
| Compartir el NIP | Riesgo | Solo acompañamiento |
| Dejar que decida por ti | Pierdes el control | Tú decides |
| No cambiarla si falla | Sigues expuesto | Cámbiala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Bertha, Don Toño y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué hace tu persona de apoyo? a) Te acompaña y tú decides · b) Decide por ti para que no te equivoques · c) Guarda tu tarjeta
2. ¿Cuántas personas de apoyo conviene tener? a) Nadie · b) Una o dos · c) Todas las que se ofrezcan
3. Tu persona de apoyo te pide el NIP. ¿Qué haces? a) Se lo das · b) Le das la mitad · c) No se lo das
**Respuestas:** 1-a: tú decides. 2-b: una o dos. 3-c: el NIP es tuyo.



#### Ponlo en práctica

Escribe el nombre de una persona que podría ser tu apoyo y en qué te acompañaría.
**Respuesta:** Ejemplo: «Mi hija Rosa, para ir al banco y a las citas del programa».



#### A tu plan

Llena la tabla de tu persona de apoyo y habla con ella esta semana.



### Para saber más

- **Persona auxiliar** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «persona auxiliar».

### Palabras clave

- *Persona de apoyo:* alguien que te acompaña en tus decisiones.
- *Persona auxiliar:* quien queda registrada en la Pensión Bienestar para ayudarte.
- *Acompañar:* estar contigo sin decidir por ti.

### Fuentes

Secretaría de Bienestar, registro de persona auxiliar; consultado el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Testamento y beneficiarios

## M7 U01. Tu testamento

**Lo que lograrás:** Explicar para qué sirve un testamento y qué preparar antes de ir a la notaría.

**Para empezar:** Cuando murió el esposo de Doña Bertha no había testamento. Sus hijos tardaron años en un juicio para arreglar la casa y gastaron más de lo que pensaban. Ella no quiere que les pase lo mismo. En esta lección verás por dónde empezar.

### Lo esencial (5 minutos)

#### Para qué sirve

El testamento dice a quién le dejas tus bienes. Sin testamento, la familia hace un trámite largo para que un juez o un notario decida quién hereda. Eso cuesta tiempo y dinero.



#### Antes de ir a la notaría

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu lista de bienes | Casa, terreno, cuenta, auto. | Con papeles. |
| A quién | Nombres completos. | Y qué le dejas. |
| Tus papeles | INE, acta, CURP. | Comprobante de domicilio. |
| Tus preguntas | Lo que no sabes. | El notario te orienta. |

#### Septiembre, mes del testamento

Cada septiembre las notarías ofrecen testamentos con costo reducido, y muchas también durante el año para personas mayores. Pregunta en tu estado.



#### Un caso en un minuto

Doña Bertha hizo su lista: la casa para sus dos hijos por partes iguales. En septiembre fue a la notaría con su hija y salió con su testamento.

> **Idea clave:** el testamento evita un trámite largo y caro a tu familia; haz tu lista y aprovecha septiembre.



#### Comprueba lo que entendiste

1. ¿Qué pasa si no hay testamento?
*Respuesta:* La familia hace un trámite largo y costoso para saber quién hereda.

2. ¿En qué mes hay testamentos con costo reducido?
*Respuesta:* En septiembre.


#### Para recordar

- Haz tu lista.
- Ve a la notaría.
- Septiembre cuesta menos.



### Profundiza (5 minutos más)

#### Mi lista para el testamento

| Bien | Papel que lo comprueba | A quién |
|---|---|---|
| | | |
| | | |
| | | |



#### Si tu casa está en ejido

Los derechos ejidales se heredan con la **lista de sucesión**, que se registra en el Registro Agrario Nacional. Pregunta en tu comisariado ejidal.



#### Casos


**Caso 1. Sin testamento**

Doña Bertha no quiere que sus hijos pasen un juicio.
- *¿Qué hace?* Hace su lista y va a la notaría.


**Caso 2. «Es muy caro»**

Don Toño cree que el testamento es carísimo.
- *¿Qué hace?* Pregunta por el costo reducido de septiembre.


**Caso 3. El terreno ejidal**

Doña Mago tiene un terreno en el ejido.
- *¿Qué hace?* Pregunta por la lista de sucesión en su comisariado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejarlo para después | Juicio largo para la familia | Hazlo ya |
| Ir sin lista | Olvidas bienes | Lista con papeles |
| Creer que es carísimo | No lo haces | Septiembre |
| Olvidar el ejido | Se pierde el derecho | Lista de sucesión |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Bertha, Don Toño y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Para qué sirve el testamento? a) Para decir a quién dejas tus bienes · b) Para pedir un préstamo a cuenta de tus bienes · c) Para cobrar la pensión
2. ¿Qué llevas a la notaría? a) Nada · b) Tu lista de bienes y tus papeles · c) Solo a tus hijos
3. ¿Cómo se heredan los derechos ejidales? a) Con la lista de sucesión · b) Con un recibo · c) No se heredan, regresan al ejido
**Respuestas:** 1-a: tus bienes. 2-b: lista y papeles. 3-a: lista de sucesión.



#### Ponlo en práctica

Escribe dos bienes que tienes y a quién te gustaría dejarlos.
**Respuesta:** Ejemplo: «La casa, a mis dos hijos por partes iguales; mi cuenta, a mi hija».



#### A tu plan

Llena tu lista para el testamento y pregunta en una notaría el costo y la fecha.



### Para saber más

- **Mes del testamento** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «mes del testamento».
- **Lista de sucesión ejidal** (Registro Agrario Nacional · español): https://www.gob.mx/ran — **Qué buscar:** «lista de sucesión».

### Palabras clave

- *Testamento:* papel donde dices a quién dejas tus bienes.
- *Heredar:* recibir los bienes de alguien que falleció.
- *Lista de sucesión:* lista de herederos de derechos ejidales.

### Fuentes

Gobierno de México, Mes del Testamento; Registro Agrario Nacional, lista de sucesión; consultados el 5 de octubre de 2026.

---

## M7 U02. Tus beneficiarios al día

**Lo que lograrás:** Revisar quién recibiría el dinero de tus cuentas, tu Afore y tus seguros.

**Para empezar:** Don Toño puso a su esposa como beneficiaria de su cuenta hace 20 años. Ella falleció. Si él faltara hoy, nadie sabe a quién le tocaría ese dinero. En esta lección revisarás tus beneficiarios.

### Lo esencial (5 minutos)

#### Qué es un beneficiario

Es la persona que recibe el dinero de una cuenta, una Afore o un seguro si tú faltas. Se registra en cada lugar, aparte del testamento.



#### Dónde revisarlos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta del banco | En la sucursal. | Con tu INE. |
| Afore | En tu Afore o en AforeMóvil. | Si tienes. |
| Seguros | Con la aseguradora. | Vida, funerario. |

#### Cuándo actualizarlos

Revisa cuando alguien fallece, nace un nieto, cambia tu familia o pasan muchos años. Puedes poner a más de una persona y decir el porcentaje para cada una.



#### Un caso en un minuto

Don Toño fue al banco y puso a sus dos hijos, 50% cada uno. Revisó su Afore: ya los tenía. Le dijo a su hija dónde están sus papeles.

> **Idea clave:** revisa tus beneficiarios en tu banco, tu Afore y tus seguros, y actualízalos cuando cambie tu familia.



#### Comprueba lo que entendiste

1. ¿Qué es un beneficiario?
*Respuesta:* Quien recibe el dinero de una cuenta, Afore o seguro si tú faltas.

2. ¿Cuándo actualizarlos?
*Respuesta:* Cuando alguien fallece, nace alguien, cambia la familia o pasan muchos años.


#### Para recordar

- Banco, Afore y seguros.
- Actualízalos.
- Di dónde están tus papeles.



### Profundiza (5 minutos más)

#### Mis beneficiarios

| Dónde | Beneficiario | Porcentaje | Revisado |
|---|---|---|---|
| Banco | | | |
| Afore | | | |
| Seguro | | | |



#### Una carpeta para tu familia

Guarda en una carpeta tu testamento, tus pólizas, tus estados de cuenta y esta lista. Dile a tu persona de confianza dónde está, sin darle tu NIP.



#### Casos


**Caso 1. La beneficiaria que falleció**

La beneficiaria de la cuenta de Don Toño ya falleció.
- *¿Qué hace?* Va al banco y actualiza a sus beneficiarios.


**Caso 2. Tres nietos**

Doña Mago quiere repartir su seguro entre tres nietos.
- *¿Qué hace?* Pone a los tres con su porcentaje.


**Caso 3. Nadie sabe dónde están los papeles**

La familia de Doña Bertha no sabe dónde están sus pólizas.
- *¿Qué hace?* Hace una carpeta y le dice a su persona de confianza dónde está.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar en años | El dinero va a quien no quieres | Actualiza |
| Creer que el testamento basta | Las cuentas tienen sus propios beneficiarios | Revisa cada una |
| Papeles perdidos | La familia no cobra | Una carpeta |
| Dar tu NIP con la carpeta | Riesgo | Solo dónde están |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Mago y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde se registran los beneficiarios de una cuenta? a) En el banco · b) En el testamento solamente · c) En la tienda
2. ¿Puedes poner a más de un beneficiario? a) No · b) Solo a dos personas, sin porcentaje · c) Sí, con porcentaje para cada uno
3. ¿Qué guardas en la carpeta para tu familia? a) Tu NIP · b) Testamento, pólizas, estados de cuenta y la lista · c) Nada
**Respuestas:** 1-a: en cada lugar. 2-c: con porcentajes. 3-b: los papeles.



#### Ponlo en práctica

Quieres dejar tu seguro a dos hijos por igual. ¿Qué porcentaje para cada uno?
**Respuesta:** 50% cada uno.



#### A tu plan

Llena la tabla de beneficiarios y arma tu carpeta para la familia.



### Para saber más

- **Beneficiarios en tu Afore** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «beneficiarios».
- **Beneficiarios en cuentas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «designación de beneficiarios».

### Palabras clave

- *Beneficiario:* quien recibe tu dinero si faltas.
- *Póliza:* contrato de un seguro.
- *Porcentaje:* la parte que le toca a cada quien.

### Fuentes

CONDUSEF, designación de beneficiarios; CONSAR; consultados el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Tu salud y tus seguros

## M8 U01. Un guardadito para tu salud

**Lo que lograrás:** Apartar un poco cada mes para gastos de salud y conocer tus opciones de atención pública.

**Para empezar:** Doña Mago se cayó y necesitó radiografías y medicinas. No tenía nada apartado. Su hijo pidió un préstamo caro para pagarlas. En esta lección verás cómo prepararte.

### Lo esencial (5 minutos)

#### La salud sorprende

La mitad de las personas de 65 años y más no podría con un gasto imprevisto. Los de salud son los más comunes: consultas, estudios, medicinas.



#### Dos cosas que ayudan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Un guardadito | Aunque sea poco cada mes. | Solo para salud. |
| Tu atención pública | IMSS, ISSSTE o IMSS-Bienestar. | Según tu caso. |

#### Poco a poco

Si apartas 200 pesos al mes, en un año tienes 2,400 para salud. No lo uses para otra cosa.



#### Un caso en un minuto

Doña Mago ahora aparta 150 pesos de cada mes de su pensión en un sobre para salud. Y preguntó en su centro de salud qué servicios tiene sin costo.

> **Idea clave:** aparta un poco cada mes para salud y conoce qué atención pública te corresponde.



#### Comprueba lo que entendiste

1. ¿Qué parte de las personas de 65 y más no podría con un imprevisto?
*Respuesta:* La mitad (50%).

2. Si apartas 200 al mes, ¿cuánto tienes en un año?
*Respuesta:* 2,400 pesos.


#### Para recordar

- Guardadito de salud.
- Solo para salud.
- Conoce tu atención pública.



### Profundiza (5 minutos más)

#### El guardadito de Doña Mago

- Al mes: **150**
- Meses: **12**
- En un año, para salud: **1,800**


#### Pregunta antes de pagar

Antes de pagar un estudio o medicina, pregunta en tu clínica pública si lo tienen. Y compara precios entre farmacias.



#### Casos


**Caso 1. Sin nada apartado**

Doña Mago necesita estudios y no tiene dinero.
- *¿Qué hace?* Pregunta primero en su clínica pública y después empieza su guardadito.


**Caso 2. El sobre de salud**

Don Toño quiere usar el sobre de salud para un regalo.
- *¿Qué hace?* Lo deja solo para salud.


**Caso 3. La medicina cara**

A Doña Bertha le recetan una medicina cara.
- *¿Qué hace?* Pregunta si la tienen en su clínica y compara farmacias.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No apartar nada | Préstamos caros | Un poco cada mes |
| Usar el guardadito para otra cosa | Te quedas sin nada | Solo salud |
| No preguntar en la clínica | Pagas de más | Pregunta antes |
| No comparar farmacias | Gasto mayor | Compara |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Mago, Don Toño y Doña Bertha. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Para qué es el guardadito de salud? a) Solo para salud · b) Para regalos y fiestas de la familia · c) Para prestar
2. Apartas 100 al mes. ¿Cuánto en un año? a) 100 · b) 1,200 · c) 12,000
3. Te recetan algo caro. ¿Qué haces primero? a) Pides un préstamo en la farmacia · b) Lo dejas · c) Preguntas en tu clínica y comparas
**Respuestas:** 1-a: solo salud. 2-b: 100 por 12. 3-c: pregunta y compara.



#### Ponlo en práctica

Apartas 250 al mes. ¿Cuánto tienes en seis meses?
**Respuesta:** 1,500 pesos.



#### A tu plan

Decide cuánto apartarás al mes para salud y dónde lo guardarás.



### Para saber más

- **IMSS-Bienestar** (Gobierno de México · español): https://www.gob.mx/imss-bienestar — **Qué buscar:** «servicios».

### Palabras clave

- *Imprevisto:* gasto que no esperabas.
- *Guardadito:* ahorro pequeño para algo concreto.
- *Atención pública:* servicios de salud del gobierno.

### Fuentes

INEGI y CONDUSEF, ENSAFI 2023; IMSS-Bienestar; consultados el 5 de octubre de 2026.

---

## M8 U02. Seguros: lo que cubren y lo que te cobran

**Lo que lograrás:** Revisar si tienes seguros, qué cubren y si te cobran alguno que no pediste.

**Para empezar:** Don Toño revisó su estado de cuenta y vio un cargo de 189 pesos al mes por un «seguro de protección» que nunca pidió. Lleva dos años pagándolo. En esta lección verás qué revisar.

### Lo esencial (5 minutos)

#### Solo 18% tiene seguro

Entre las personas de 60 a 70 años, solo 18% tiene algún seguro. Un seguro de vida o funerario puede evitar que tu familia se endeude si faltas.



#### Antes de contratar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Qué cubre? | Y qué no. | Por escrito. |
| ¿Cuánto cuesta? | Al mes y al año. | Y si sube con la edad. |
| ¿Hasta qué edad? | Muchos tienen límite. | Revísalo. |
| ¿Quién cobra? | Tus beneficiarios. | Ponlos al día. |

#### Revisa tus cargos

Revisa tu estado de cuenta. Si hay un seguro que no pediste, pide al banco que lo cancele y que te devuelva lo cobrado. Si no resuelven, ve a CONDUSEF.



#### Un caso en un minuto

Don Toño pidió cancelar el seguro que no contrató. El banco lo canceló. Con ese dinero ahora paga un seguro funerario que sí eligió.

> **Idea clave:** pregunta qué cubre un seguro antes de contratarlo y cancela los que te cobran sin haberlos pedido.



#### Comprueba lo que entendiste

1. ¿Qué haces si te cobran un seguro que no pediste?
*Respuesta:* Pido al banco cancelarlo y que me devuelvan lo cobrado; si no, voy a CONDUSEF.

2. ¿Qué preguntas antes de contratar un seguro?
*Respuesta:* Qué cubre, cuánto cuesta, hasta qué edad y quién cobra.


#### Para recordar

- Pregunta qué cubre.
- Revisa tus cargos.
- Cancela lo que no pediste.



### Profundiza (5 minutos más)

#### El seguro que nunca pidió

- Al mes: **189**
- Meses: **24**
- Pagados sin querer: **4,536**


#### Seguros por teléfono

Si te llaman para venderte un seguro, no aceptes en la llamada. Pide la información por escrito y revísala con tu persona de apoyo.



#### Casos


**Caso 1. El seguro que no pidió**

Don Toño paga 189 al mes por un seguro que nunca contrató.
- *¿Qué hace?* Pide cancelarlo y que le devuelvan lo cobrado.


**Caso 2. Seguro por teléfono**

A Doña Bertha le ofrecen un seguro en una llamada.
- *¿Qué hace?* Pide la información por escrito antes de aceptar.


**Caso 3. El seguro funerario**

Doña Mago quiere que su familia no se endeude si ella falta.
- *¿Qué hace?* Pregunta qué cubre, cuánto cuesta y hasta qué edad antes de contratar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar el estado de cuenta | Cargos por años | Revísalo |
| Aceptar por teléfono | Contratas sin saber | Por escrito |
| No preguntar el límite de edad | Te quedas sin cobertura | Pregunta |
| Olvidar beneficiarios | Nadie cobra | Ponlos al día |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Toño, Doña Bertha y Doña Mago. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te cobran un seguro que no pediste. ¿Qué haces? a) Lo sigues pagando · b) Pides cancelarlo y la devolución · c) Cierras tu cuenta sin decir nada
2. Te ofrecen un seguro por teléfono. ¿Qué haces? a) Aceptas · b) Das tu tarjeta para que te manden la información · c) Pides la información por escrito
3. ¿Qué parte de las personas de 60 a 70 años tiene seguro? a) 18% · b) 80% · c) Todas
**Respuestas:** 1-b: cancela y reclama. 2-c: por escrito. 3-a: 18%.



#### Ponlo en práctica

Te cobraron 120 pesos al mes durante 18 meses por un seguro que no pediste. ¿Cuánto es?
**Respuesta:** 2,160 pesos.



#### A tu plan

Revisa tus últimos tres estados de cuenta y anota los seguros que te cobran.



### Para saber más

- **Seguros no solicitados** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cargos no reconocidos seguros». 55 5340 0999.

### Palabras clave

- *Seguro:* contrato que te paga si pasa algo.
- *Cobertura:* lo que cubre un seguro.
- *Cargo no reconocido:* cobro que no aceptaste.

### Fuentes

INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Pensión, Tu Tranquilidad, Tu Futuro** — Programa de bienestar financiero para personas adultas mayores: proteger la pensión, evitar fraudes y abusos, y dejar todo en orden. 8 módulos y 16 lecciones cortas, pensadas para sesiones presenciales con letra grande y acompañante de confianza.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Tu pensión y tu mes:** Tu pensión repartida en el bimestre, con lo básico primero.
- **Tu tarjeta y el cajero, sin riesgos:** Tu NIP protegido y tu forma segura de usar el cajero.
- **Llamadas, mensajes y «el nieto en apuros»:** Tu regla para colgar y verificar ante llamadas y mensajes.
- **Cuando el abuso viene de casa:** Las señales de abuso patrimonial y a quién llamar.
- **Préstamos a cuenta de tu pensión:** Tu decisión informada sobre préstamos y el tope de 30%.
- **Decidir con apoyo, sin perder el control:** Tu persona de apoyo elegida y ningún poder amplio firmado sin revisar.
- **Testamento y beneficiarios:** Tus beneficiarios revisados y tu decisión sobre el testamento.
- **Tu salud y tus seguros:** Tu guardadito para salud y tus seguros revisados.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 16 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Doña Mago:** 72 años. Cobra la Pensión Bienestar. Vive con su hijo y su nuera en Puebla.
- **Don Toño:** 68 años. Viudo, pensionado del IMSS desde hace ocho años. Vive solo en Saltillo.
- **Doña Bertha:** 66 años. Cuida a sus nietos y cobra la Pensión Bienestar. No usa el cajero.
- **Sofía:** 25 años. Nieta de Doña Mago; es su acompañante de confianza en el programa.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **Protección antes que crédito:** el programa no promueve préstamos; explica sus límites y riesgos.
5. **Letra grande y ritmo lento:** cada sesión repasa lo anterior y deja una sola tarea.
6. **La persona decide:** el acompañante apoya, no decide por ella.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. Los dos meses de Doña Mago (Módulos 1 y 2)

**Datos.** A Doña Mago le llegan 6,200 pesos cada dos meses. Sus básicos (comida, medicinas, luz, gas y pasajes) son 2,700 al mes. Su vecino se ofrece a sacarle el dinero del cajero «para que no batalle» si le da su NIP.

**Tareas.**

1. ¿Cuánto debe guardar para el segundo mes?
2. ¿Cuánto le queda al mes después de los básicos?
3. ¿Qué le responde al vecino?
4. Si quiere compañía para ir al cajero, ¿cómo lo hace sin riesgo?

**Clave.**

- 6,200 entre 2: 3,100 para el segundo mes.
- 3,100 menos 2,700: 400 al mes.
- No le da su NIP: el NIP es solo suyo.
- Va de día, de preferencia a un cajero dentro de sucursal, con Sofía, su persona de confianza; Doña Mago teclea su NIP.

### E2. La llamada y el préstamo (Módulos 3 y 5)

**Datos.** Don Toño cobra 9,000 al mes de pensión del IMSS. Le llaman: «Abuelo, soy tu nieto, choqué y necesito 5,000 ya». Una semana después le ofrecen un préstamo a cuenta de su pensión con un descuento de 3,200 al mes durante 24 meses por 40,000.

**Tareas.**

1. ¿Qué hace con la llamada?
2. ¿Cuál es el descuento máximo que pueden hacerle (30%)?
3. ¿El descuento ofrecido cabe en ese tope?
4. ¿Cuánto pagaría en total y cuánto de más?

**Clave.**

- Cuelga y llama él al número que ya tiene de su nieto.
- 30% de 9,000: 2,700.
- No: 3,200 pasa el tope de 2,700.
- 3,200 por 24: 76,800; paga 36,800 de más. No firma.

### E3. Las firmas que le piden a Doña Bertha (Módulos 4 y 6)

**Datos.** El yerno de Doña Bertha le pide que firme «unos papeles del banco» y un poder «para ayudarle con todo». Desde hace dos meses le falta dinero de su tarjeta y ya no la deja ver sus estados de cuenta.

**Tareas.**

1. ¿Qué señales de abuso patrimonial hay?
2. ¿Qué tipo de poder sí podría dar, si lo necesita?
3. ¿A quién llama por los cargos que no hizo?
4. ¿A quién acude para orientación jurídica?

**Clave.**

- Le falta dinero, le piden firmar sin explicar y le quitan el control de sus estados de cuenta.
- Un poder limitado a un trámite, con fecha de término; nunca uno amplio sin entenderlo.
- Al banco, para reclamar con folio; si no le resuelven, a la CONDUSEF.
- Al INAPAM o al DIF; y al 911 si hay peligro.

### E4. Todo en orden (Módulos 7 y 8)

**Datos.** Don Toño quiere que su casa sea para sus dos hijos. En su cuenta aparece como beneficiaria su esposa, que ya murió. Quiere apartar 150 al mes para salud y le cobran 180 al mes de un seguro que nunca pidió.

**Tareas.**

1. ¿Qué documento hace para su casa y en qué mes conviene?
2. ¿Qué hace con los beneficiarios de su cuenta?
3. ¿Cuánto junta para salud en un año?
4. ¿Cuánto ahorra al año si cancela el seguro que no pidió?

**Clave.**

- Su testamento; en septiembre, mes del testamento, suele costar menos.
- Los actualiza en el banco, y también revisa su Afore y sus seguros.
- 150 por 12: 1,800.
- 180 por 12: 2,160.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Te llegan 6,400. Ya gastaste 2,900 este mes. ¿Cuánto te queda de la mitad de este mes? |
| P02 | M1 U02 | Tu pensión es de 7,000 y lo básico cuesta 5,600. ¿Cuánto te queda para lo demás? |
| P03 | M2 U01 | ¿Cuál NIP es más seguro: 1234, tu año de nacimiento o un número de una casa donde viviste? |
| P04 | M2 U02 | Escribe los tres datos de tu ficha de emergencia que debes llevar contigo. |
| P05 | M3 U01 | Escribe tu frase para colgar sin discutir. |
| P06 | M3 U02 | Un mensaje te cobra 49 pesos por un paquete que no esperas. ¿Lo pagas? |
| P07 | M4 U01 | Te faltan 2,000 pesos en tu cuenta. Escribe dos cosas que haces hoy. |
| P08 | M4 U02 | ¿Dónde puedes ver si alguien sacó un préstamo a tu nombre? |
| P09 | M5 U01 | Tu pensión es de 8,000. ¿Cuánto es lo máximo que te pueden descontar al mes? |
| P10 | M5 U02 | Escribe tu frase para decir que no a firmar un crédito para alguien. |
| P11 | M6 U01 | Escribe las cuatro preguntas que haces antes de firmar un poder. |
| P12 | M6 U02 | Escribe el nombre de una persona que podría ser tu apoyo y en qué te acompañaría. |
| P13 | M7 U01 | Escribe dos bienes que tienes y a quién te gustaría dejarlos. |
| P14 | M7 U02 | Quieres dejar tu seguro a dos hijos por igual. ¿Qué porcentaje para cada uno? |
| P15 | M8 U01 | Apartas 250 al mes. ¿Cuánto tienes en seis meses? |
| P16 | M8 U02 | Te cobraron 120 pesos al mes durante 18 meses por un seguro que no pediste. ¿Cuánto es? |

### Respuestas

- **P01:** 300 pesos.
- **P02:** 1,400 pesos.
- **P03:** El número de una casa donde viviste.
- **P04:** El teléfono del banco, los últimos 4 números de tu tarjeta y el nombre de tu persona de confianza.
- **P05:** Ejemplo: «Ahorita le llamo yo», y cuelgo.
- **P06:** No; lo borro y bloqueo el número.
- **P07:** Cambio mi NIP y reclamo al banco (también puedo revisar mis movimientos).
- **P08:** En tu reporte de crédito especial, sin costo una vez al año.
- **P09:** 2,400 pesos.
- **P10:** Ejemplo: «Te quiero ayudar, pero no puedo firmar créditos».
- **P11:** ¿Para qué trámite es?, ¿puede vender o hipotecar algo?, ¿hasta cuándo dura?, ¿cómo lo cancelo?
- **P12:** Ejemplo: «Mi hija Rosa, para ir al banco y a las citas del programa».
- **P13:** Ejemplo: «La casa, a mis dos hijos por partes iguales; mi cuenta, a mi hija».
- **P14:** 50% cada uno.
- **P15:** 1,500 pesos.
- **P16:** 2,160 pesos.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu pensión y tu mes

- **Apartar:** separar dinero para después.
- **Bimestre:** dos meses.
- **Compromiso:** gasto que sientes que te toca.
- **Gasto básico:** lo que necesitas para vivir.
- **Pensión:** dinero que recibes cada cierto tiempo por edad o trabajo.
- **Recortar:** gastar menos en algo.

### Tu tarjeta y el cajero, sin riesgos

- **Bloquear:** pedir al banco que nadie pueda usar tu tarjeta.
- **Cajero automático:** máquina para sacar dinero.
- **NIP:** número secreto de tu tarjeta.
- **Persona auxiliar:** alguien registrado para ayudarte en trámites.
- **Saldo:** dinero que tienes en tu cuenta.
- **Sucursal:** oficina del banco.

### Llamadas, mensajes y «el nieto en apuros»

- **Bloquear un número:** hacer que no te pueda escribir.
- **Datos personales:** información sobre ti, como tu nombre, NIP o CURP.
- **Denuncia:** aviso a la autoridad.
- **Fraude:** engaño para quitarte dinero.
- **Liga:** enlace que abre una página.
- **Palabra clave:** contraseña de tu familia.

### Cuando el abuso viene de casa

- **Abuso patrimonial:** cuando alguien usa tu dinero o tus bienes sin tu permiso.
- **Bienes:** lo que es tuyo, como tu casa o tu terreno.
- **Despojo:** cuando te quitan un bien de forma injusta.
- **Movimientos:** entradas y salidas de dinero de tu cuenta.
- **Prueba:** papel o mensaje que muestra lo que pasó.
- **Reclamación:** queja formal con folio.

### Préstamos a cuenta de tu pensión

- **Aval:** quien promete pagar si el otro no paga.
- **CAT:** costo anual total del préstamo.
- **Convenio:** acuerdo oficial entre el IMSS y una entidad.
- **Descuento:** lo que te quitan de la pensión cada mes.
- **Historial de crédito:** registro de cómo pagas tus deudas.
- **Plan de pago:** acuerdo para pagar en partes.

### Decidir con apoyo, sin perder el control

- **Acompañar:** estar contigo sin decidir por ti.
- **Actos de dominio:** vender, regalar o hipotecar bienes.
- **Persona de apoyo:** alguien que te acompaña en tus decisiones.
- **Poder notarial:** papel que permite a otro actuar en tu nombre.
- **Revocar:** cancelar.

### Testamento y beneficiarios

- **Beneficiario:** quien recibe tu dinero si faltas.
- **Heredar:** recibir los bienes de alguien que falleció.
- **Lista de sucesión:** lista de herederos de derechos ejidales.
- **Porcentaje:** la parte que le toca a cada quien.
- **Póliza:** contrato de un seguro.
- **Testamento:** papel donde dices a quién dejas tus bienes.

### Tu salud y tus seguros

- **Atención pública:** servicios de salud del gobierno.
- **Cargo no reconocido:** cobro que no aceptaste.
- **Cobertura:** lo que cubre un seguro.
- **Guardadito:** ahorro pequeño para algo concreto.
- **Imprevisto:** gasto que no esperabas.
- **Seguro:** contrato que te paga si pasa algo.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Pensión para el Bienestar | Secretaría de Bienestar: https://programasparaelbienestar.gob.mx | «adultos mayores» | M1 U01 |
| Presupuesto | CONDUSEF: https://www.condusef.gob.mx | «presupuesto personas adultas mayores» | M1 U02 |
| Persona auxiliar | Secretaría de Bienestar: https://programasparaelbienestar.gob.mx | «persona auxiliar» | M2 U01, M6 U02 |
| Protege tu tarjeta | CONDUSEF: https://www.condusef.gob.mx | «adultos mayores» | M2 U01 |
| Uso seguro del cajero | CONDUSEF: https://www.condusef.gob.mx | «cajeros automáticos» | M2 U02 |
| Fraudes telefónicos | CONDUSEF: https://www.condusef.gob.mx | «fraude telefónico» | M3 U01 |
| Fraudes por mensaje | CONDUSEF: https://www.condusef.gob.mx | «phishing» y «smishing» | M3 U02 |
| Abuso financiero a personas mayores | CONDUSEF: https://www.condusef.gob.mx | «adultos mayores abuso» | M4 U01 |
| INAPAM | Gobierno de México: https://www.gob.mx/inapam | «asesoría jurídica» | M4 U01, M4 U02 |
| Reclamaciones | CONDUSEF: https://www.condusef.gob.mx | 55 5340 0999 | — | M4 U02 |
| Préstamos a pensionados | IMSS: https://www.imss.gob.mx | «préstamos a pensionados» y «entidades financieras con convenio» | M5 U01 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M5 U01 |
| Aval y obligado solidario | CONDUSEF: https://www.condusef.gob.mx | «ser aval» | M5 U02 |
| Poderes notariales | Colegio Nacional del Notariado Mexicano: https://www.notariadomexicano.org.mx | «poder notarial» | M6 U01 |
| Recomendaciones | CONDUSEF: https://www.condusef.gob.mx | «adultos mayores poder notarial» | M6 U01 |
| Mes del testamento | Gobierno de México: https://www.gob.mx | «mes del testamento» | M7 U01 |
| Lista de sucesión ejidal | Registro Agrario Nacional: https://www.gob.mx/ran | «lista de sucesión» | M7 U01 |
| Beneficiarios en tu Afore | CONSAR: https://www.gob.mx/consar | «beneficiarios» | M7 U02 |
| Beneficiarios en cuentas | CONDUSEF: https://www.condusef.gob.mx | «designación de beneficiarios» | M7 U02 |
| IMSS-Bienestar | Gobierno de México: https://www.gob.mx/imss-bienestar | «servicios» | M8 U01 |
| Seguros no solicitados | CONDUSEF: https://www.condusef.gob.mx | «cargos no reconocidos seguros». 55 5340 0999 | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Tu pensión y tu mes

- **M1 U01 · Tu pensión llega cada dos meses.** Secretaría de Bienestar, Reglas de Operación de la Pensión para el Bienestar de las Personas Adultas Mayores 2026; consultado el 5 de octubre de 2026.
- **M1 U02 · Lo básico primero.** CONDUSEF, recomendaciones para personas adultas mayores; consultado el 5 de octubre de 2026.

### Tu tarjeta y el cajero, sin riesgos

- **M2 U01 · Tu NIP es solo tuyo.** CONDUSEF y PROFECO, recomendaciones para personas adultas mayores; Secretaría de Bienestar, persona auxiliar; consultados el 5 de octubre de 2026.
- **M2 U02 · El cajero, sin riesgos.** CONDUSEF, recomendaciones de uso seguro de cajeros; consultado el 5 de octubre de 2026.

### Llamadas, mensajes y «el nieto en apuros»

- **M3 U01 · «Abuelita, soy yo, estoy en problemas».** CONDUSEF y PROFECO, recomendaciones contra estafas a personas adultas mayores; consultados el 5 de octubre de 2026.
- **M3 U02 · Mensajes, premios y ligas.** CONDUSEF, alertas de fraude por mensaje; consultado el 5 de octubre de 2026.

### Cuando el abuso viene de casa

- **M4 U01 · Señales de abuso patrimonial.** CONDUSEF, abuso financiero a personas adultas mayores; INAPAM, asesoría jurídica; consultados el 5 de octubre de 2026.
- **M4 U02 · A quién llamar.** CONDUSEF; INAPAM; Buró de Crédito y Círculo de Crédito; consultados el 5 de octubre de 2026.

### Préstamos a cuenta de tu pensión

- **M5 U01 · El préstamo a cuenta de tu pensión.** IMSS, préstamos a cuenta de pensión para pensionados Ley 73 (tope de 30% y plazo máximo de 60 meses); consultado el 5 de octubre de 2026.
- **M5 U02 · Préstamos para otros.** CONDUSEF, recomendaciones sobre ser aval y préstamos a nombre de otros; consultado el 5 de octubre de 2026.

### Decidir con apoyo, sin perder el control

- **M6 U01 · Poder amplio o poder limitado.** CONDUSEF, recomendaciones a personas adultas mayores sobre poderes notariales; consultado el 5 de octubre de 2026.
- **M6 U02 · Tu persona de apoyo.** Secretaría de Bienestar, registro de persona auxiliar; consultado el 5 de octubre de 2026.

### Testamento y beneficiarios

- **M7 U01 · Tu testamento.** Gobierno de México, Mes del Testamento; Registro Agrario Nacional, lista de sucesión; consultados el 5 de octubre de 2026.
- **M7 U02 · Tus beneficiarios al día.** CONDUSEF, designación de beneficiarios; CONSAR; consultados el 5 de octubre de 2026.

### Tu salud y tus seguros

- **M8 U01 · Un guardadito para tu salud.** INEGI y CONDUSEF, ENSAFI 2023; IMSS-Bienestar; consultados el 5 de octubre de 2026.
- **M8 U02 · Seguros: lo que cubren y lo que te cobran.** INEGI y CNBV, ENIF 2024; CONDUSEF; consultados el 5 de octubre de 2026.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Tu pensión llega cada dos meses

**Caso 1. Pagar todo el primer mes.** Doña Mago paga todas sus cuentas la primera semana. **¿Qué hace?**

- ✔ Aparta la mitad para el segundo mes.
- Paga todo de una vez para quitarse pendientes.
- Paga lo que pueda y espera el próximo depósito.

**Caso 2. El sobre a la vista.** Doña Bertha guarda la segunda mitad en un sobre en la mesa. **¿Qué hace?**

- ✔ Lo guarda en un lugar seguro.
- Lo deja en la mesa para tenerlo a la mano.
- Se lo da a su nuera para que lo cuide.

**Caso 3. El préstamo al vecino.** El vecino le pide a Don Toño prestado de su pensión. **¿Qué hace?**

- ✔ Revisa primero si le alcanza para su mes.
- Le presta lo que pida, porque es su vecino de años.
- Le presta todo y luego ve cómo le hace.

## M1 U02. Lo básico primero

**Caso 1. Las medicinas al final.** Don Toño paga primero el abono y deja las medicinas para después. **¿Qué hace?**

- ✔ Paga primero comida y medicinas.
- Paga primero el abono para que no le llamen.
- Deja las medicinas para el próximo mes.

**Caso 2. La cooperación.** Le piden a Doña Bertha 800 pesos para una fiesta. **¿Qué hace?**

- ✔ Revisa si le alcanza después de lo básico.
- Da los 800 porque todos van a cooperar.
- Pide prestado para cooperar.

**Caso 3. Sin saber cuánto.** Doña Mago no sabe cuánto gasta en lo básico. **¿Qué hace?**

- ✔ Llena su hoja del mes, aunque sea aproximada.
- Espera a saber los montos exactos para anotarlos.
- No anota nada, porque ya sabe más o menos.

## M2 U01. Tu NIP es solo tuyo

**Caso 1. El nieto cobra.** Doña Bertha le da su tarjeta y su NIP a su nieto. **¿Qué hace?**

- ✔ Cambia su NIP y va acompañada a cobrar.
- Le sigue dando la tarjeta porque es su nieto.
- Le da la tarjeta pero le pide los recibos.

**Caso 2. El NIP en la tarjeta.** Don Toño tiene el NIP escrito atrás de la tarjeta. **¿Qué hace?**

- ✔ Lo borra, lo memoriza y lo cambia.
- Lo deja, porque así no se le olvida.
- Lo pasa a un papel en su cartera.

**Caso 3. Necesita ayuda.** Doña Mago no puede ir sola a hacer trámites. **¿Qué hace?**

- ✔ Registra a una persona auxiliar.
- Le da su tarjeta al vecino que se ofrece.
- Deja de hacer sus trámites.

## M2 U02. El cajero, sin riesgos

**Caso 1. El joven amable.** Un joven ofrece ayudar a Don Toño con el cajero. **¿Qué hace?**

- ✔ Le dice que no y pide ayuda dentro.
- Acepta, porque el joven se ve amable y conoce el cajero.
- Le dice su NIP para que lo intente él.

**Caso 2. El cajero de noche.** Doña Mago quiere sacar dinero a las 9 de la noche en la calle. **¿Qué hace?**

- ✔ Espera a la mañana.
- Va de todos modos porque necesita el dinero.
- Le pide a un vecino que saque el dinero por ella.

**Caso 3. La tarjeta retenida.** El cajero se queda con la tarjeta de Doña Bertha. **¿Qué hace?**

- ✔ Llama al banco de inmediato.
- Se va a casa y regresa al día siguiente.
- Espera a que la máquina la devuelva sola.

## M3 U01. «Abuelita, soy yo, estoy en problemas»

**Caso 1. El nieto que llora.** Le piden a Doña Mago 5,000 para su nieto «detenido». **¿Qué hace?**

- ✔ Cuelga y llama a su nieta Sofía.
- Deposita los 5,000 para que no detengan a su nieto.
- Deposita la mitad para ganar tiempo.

**Caso 2. El cargo raro.** Llaman a Don Toño «del banco» para cancelar un cargo con su NIP. **¿Qué hace?**

- ✔ Cuelga y llama ella al banco.
- Da su NIP para que le cancelen el cargo rápido.
- Da solo los últimos dos números del NIP.

**Caso 3. «No cuelgue».** A Doña Bertha le dicen que no cuelgue porque «pierde su pensión». **¿Qué hace?**

- ✔ Cuelga: la prisa es la señal de fraude.
- Sigue en la llamada para no perder su pensión.
- Da sus datos y luego pregunta.

## M3 U02. Mensajes, premios y ligas

**Caso 1. El aumento por mensaje.** A Don Toño le piden datos para un «aumento». **¿Qué hace?**

- ✔ No abre la liga y pregunta en el módulo.
- Abre la liga para ver si es cierto el aumento.
- Pone sus datos porque el mensaje tiene el logotipo.

**Caso 2. El paquete detenido.** A Doña Bertha le cobran 49 pesos por un paquete que no espera. **¿Qué hace?**

- ✔ Borra el mensaje y bloquea el número.
- Paga los 49 pesos, porque es poco dinero.
- Responde para preguntar qué paquete es.

**Caso 3. El hijo con número nuevo.** A Doña Mago le escribe «su hijo» desde otro número pidiendo 3,000. **¿Qué hace?**

- ✔ Llama al número de siempre de su hijo.
- Deposita los 3,000 al número nuevo.
- Le pide que espere una semana y luego deposita.

## M4 U01. Señales de abuso patrimonial

**Caso 1. Los papeles del predial.** El hijo de Doña Mago le pide firmar sin explicar. **¿Qué hace?**

- ✔ Pide una copia para leerla.
- Firma porque confía en su hijo.
- Firma y después pregunta qué era.

**Caso 2. La tarjeta guardada.** La cuidadora de Don Toño guarda su tarjeta «para que no la pierda». **¿Qué hace?**

- ✔ La recupera y revisa su saldo.
- La deja con la cuidadora, porque así no la pierde.
- Le da también su NIP para que no batalle.

**Caso 3. El retiro que no hizo.** A Doña Bertha le faltan 2,000 en su cuenta. **¿Qué hace?**

- ✔ Revisa sus movimientos, cambia su NIP y reclama.
- Supone que se equivocó al sacar.
- Lo deja pasar para no pelear con nadie.

## M4 U02. A quién llamar

**Caso 1. El préstamo del sobrino.** Don Toño sospecha que sacaron un préstamo a su nombre. **¿Qué hace?**

- ✔ Pide su reporte de crédito y reclama con pruebas.
- Lo deja así para no meter en problemas al sobrino.
- Paga el préstamo para que no le llamen.

**Caso 2. El banco no contesta.** El banco no le resuelve a Doña Bertha en 30 días. **¿Qué hace?**

- ✔ Acude a CONDUSEF con su folio.
- Espera otros seis meses.
- Cierra su cuenta sin decir nada.

**Caso 3. Amenazas en casa.** A Doña Mago la amenazan para que firme. **¿Qué hace?**

- ✔ Llama al 911 y busca orientación en el INAPAM o el DIF.
- Firma para que la dejen en paz.
- Espera a que se calmen las cosas.

## M5 U01. El préstamo a cuenta de tu pensión

**Caso 1. «Se descuenta solito».** A Don Toño le ofrecen 40,000 sin decirle el total. **¿Qué hace?**

- ✔ Pregunta el descuento, los meses y el total.
- Firma porque se descuenta solito de la pensión.
- Firma y luego pregunta cuánto pagará.

**Caso 2. El 45%.** A un compañero le quieren descontar 45% de su pensión. **¿Qué hace?**

- ✔ Sabe que el tope es 30% y no firma.
- Firma porque la diferencia es poca.
- Firma y pide que luego le bajen el descuento.

**Caso 3. La oferta en la clínica.** Le ofrecen un préstamo afuera de la clínica. **¿Qué hace?**

- ✔ Verifica el convenio con el IMSS.
- Acepta porque está afuera de la clínica.
- Acepta si le dan tarjeta de presentación.

## M5 U02. Préstamos para otros

**Caso 1. El crédito de la nuera.** Le piden a Doña Mago un crédito a su nombre. **¿Qué hace?**

- ✔ No firma, porque la deuda sería suya.
- Firma porque su nuera promete pagar.
- Firma y le pide que le pague cada mes.

**Caso 2. El aval del vecino.** El vecino le pide a Don Toño ser su aval. **¿Qué hace?**

- ✔ Firma solo si podría pagarlo él; si no, dice que no.
- Firma porque es su vecino de toda la vida.
- Firma y le pide al vecino un pagaré.

**Caso 3. Ya firmó.** Doña Bertha firmó un crédito para su hijo y él no paga. **¿Qué hace?**

- ✔ Busca un plan de pago.
- Esconde la deuda y deja que crezca.
- Pide otro préstamo para pagar ese.

## M6 U01. Poder amplio o poder limitado

**Caso 1. «Para los trámites del banco».** El sobrino de Don Toño le pide un poder general. **¿Qué hace?**

- ✔ Pide uno especial solo para ese trámite y con fecha.
- Firma el general porque es su sobrino.
- Firma el general y le pide que no lo use.

**Caso 2. Sin leer.** A Doña Mago le dicen que firme rápido «porque el notario se va». **¿Qué hace?**

- ✔ No firma hasta que le expliquen.
- Firma rápido porque el notario se va.
- Firma y pide que le expliquen después.

**Caso 3. Ya no confía.** Doña Bertha dio un poder hace años y ya no confía en esa persona. **¿Qué hace?**

- ✔ Lo revoca ante notario.
- Lo deja porque ya está firmado.
- Le pide a esa persona que lo rompa.

## M6 U02. Tu persona de apoyo

**Caso 1. «Quien esté».** Doña Bertha pide ayuda a quien esté en el momento. **¿Qué hace?**

- ✔ Elige a una o dos personas de confianza.
- Sigue pidiendo ayuda a quien esté en el momento.
- Deja de ir al banco.

**Caso 2. «Dame tu NIP para ayudarte».** La persona de apoyo de Don Toño le pide su NIP. **¿Qué hace?**

- ✔ No se lo da: lo acompaña sin saberlo.
- Se lo da, porque es su persona de apoyo.
- Le da el NIP escrito en un papel.

**Caso 3. Ya no confía.** Doña Mago ya no confía en su auxiliar. **¿Qué hace?**

- ✔ La cambia y avisa en la oficina del programa.
- La deja porque ya está registrada.
- Deja de cobrar su pensión.

## M7 U01. Tu testamento

**Caso 1. Sin testamento.** Doña Bertha no quiere que sus hijos pasen un juicio. **¿Qué hace?**

- ✔ Hace su lista y va a la notaría.
- Lo deja para después, porque todavía se siente bien.
- Le dice a sus hijos que se pongan de acuerdo.

**Caso 2. «Es muy caro».** Don Toño cree que el testamento es carísimo. **¿Qué hace?**

- ✔ Pregunta por septiembre.
- No lo hace porque cree que es carísimo.
- Escribe su voluntad en una hoja y la guarda.

**Caso 3. El terreno ejidal.** Doña Mago tiene un terreno en el ejido. **¿Qué hace?**

- ✔ Pregunta por la lista de sucesión en su comisariado.
- Supone que el terreno pasa solo a sus hijos.
- Vende el terreno para no dejar problemas.

## M7 U02. Tus beneficiarios al día

**Caso 1. La beneficiaria que falleció.** La beneficiaria de la cuenta de Don Toño ya falleció. **¿Qué hace?**

- ✔ Va al banco y actualiza a sus beneficiarios.
- Lo deja así, porque el testamento ya lo arregla.
- Le pide a su hija que lo haga sin él.

**Caso 2. Tres nietos.** Doña Mago quiere repartir su seguro entre tres nietos. **¿Qué hace?**

- ✔ Pone a los tres con su porcentaje.
- Pone solo al mayor para que reparta.
- No pone a nadie para no hacer diferencias.

**Caso 3. Nadie sabe dónde están los papeles.** La familia de Doña Bertha no sabe dónde están sus pólizas. **¿Qué hace?**

- ✔ Hace una carpeta y dice dónde está.
- Le da a su persona de confianza la carpeta y su NIP.
- Guarda todo en distintos cajones.

## M8 U01. Un guardadito para tu salud

**Caso 1. Sin nada apartado.** Doña Mago necesita estudios y no tiene dinero. **¿Qué hace?**

- ✔ Pregunta en su clínica pública.
- Pide un préstamo caro de inmediato.
- Deja los estudios para después.

**Caso 2. El sobre de salud.** Don Toño quiere usar el sobre de salud para un regalo. **¿Qué hace?**

- ✔ Lo deja solo para salud.
- Lo usa para el regalo y lo repone después.
- Usa la mitad para el regalo.

**Caso 3. La medicina cara.** A Doña Bertha le recetan una medicina cara. **¿Qué hace?**

- ✔ Pregunta si la tienen en su clínica y compara farmacias.
- La compra en la primera farmacia que encuentra.
- Deja de tomarla porque es cara.

## M8 U02. Seguros: lo que cubren y lo que te cobran

**Caso 1. El seguro que no pidió.** Don Toño paga 189 al mes por un seguro que nunca contrató. **¿Qué hace?**

- ✔ Pide cancelarlo y que le devuelvan lo cobrado.
- Lo sigue pagando porque ya lleva dos años.
- Cierra su cuenta sin reclamar.

**Caso 2. Seguro por teléfono.** A Doña Bertha le ofrecen un seguro en una llamada. **¿Qué hace?**

- ✔ Pide la información por escrito antes de aceptar.
- Acepta en la llamada porque la señorita es amable.
- Da su número de tarjeta para que le manden información.

**Caso 3. El seguro funerario.** Doña Mago quiere que su familia no se endeude si ella falta. **¿Qué hace?**

- ✔ Pregunta qué cubre, cuánto cuesta y hasta qué edad.
- Contrata el primero que le ofrecen.
- Contrata el más caro, porque debe cubrir más.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Cada cuándo llega la Pensión Bienestar?

- ✔ Cada dos meses
- Cada semana
- Una vez al año

*¡Correcto! Es bimestral.*

**M1 U01 P2.** Te llegan 6,400 por bimestre. ¿Cuánto es para cada mes?

- 6,400
- ✔ 3,200
- 1,600

*¡Correcto! La mitad.*

**M1 U01 P3.** ¿Qué haces con la segunda mitad?

- La prestas
- La gastas en la primera semana
- ✔ La guardas para el segundo mes

*¡Correcto! Es del segundo mes.*

**M1 U02 P1.** ¿Qué pagas primero?

- La fiesta
- ✔ Comida y medicinas
- El préstamo del sobrino

*¡Correcto! Lo básico.*

**M1 U02 P2.** No alcanza este mes. ¿Qué recortas?

- Las medicinas
- La comida
- ✔ Los regalos y cooperaciones

*¡Correcto! Lo que no es básico.*

**M1 U02 P3.** ¿Para qué sirve la hoja del mes?

- ✔ Para saber cuánto necesitas en lo básico
- Para enseñarla al banco cuando pidas un préstamo
- Para nada

*¡Correcto! Para saber cuánto necesitas.*

## Módulo 2

**M2 U01 P1.** ¿Con quién compartes tu NIP?

- ✔ Con nadie
- Con quien te ayude en el cajero
- Con el banco por teléfono

*¡Correcto! Es tuyo.*

**M2 U01 P2.** Alguien vio tu NIP. ¿Qué haces?

- Nada
- ✔ Lo cambias
- Le pides que lo olvide

*¡Correcto! Se cambia.*

**M2 U01 P3.** Necesitas ayuda con trámites de la Pensión Bienestar. ¿Qué haces?

- Prestas tu tarjeta al vecino que se ofrece
- Dejas de cobrar
- ✔ Registras a una persona auxiliar

*¡Correcto! Queda registrado.*

**M2 U02 P1.** El cajero falla y alguien ofrece ayuda. ¿Qué haces?

- Aceptas
- Le das tu NIP
- ✔ Cancelas y pides ayuda dentro

*¡Correcto! Nada de extraños.*

**M2 U02 P2.** ¿Cuál es el mejor lugar para usar el cajero?

- ✔ Dentro de una sucursal, de día
- En la calle, de noche
- En la calle, donde haya menos gente que te vea

*¡Correcto! De día y en sucursal.*

**M2 U02 P3.** El cajero se quedó con tu tarjeta. ¿Qué haces?

- Te vas a casa
- ✔ Llamas al banco y la bloqueas
- Esperas un rato a que la máquina la devuelva sola

*¡Correcto! Bloqueo inmediato.*

## Módulo 3

**M3 U01 P1.** Te llaman «del banco» y piden tu NIP. ¿Qué haces?

- Lo das
- ✔ Cuelgas
- Das solo dos números

*¡Correcto! Nadie pide el NIP.*

**M3 U01 P2.** ¿Qué sirve para confirmar que es tu familiar?

- ✔ Una palabra clave familiar
- Que llore
- Que sepa tu nombre y el de tu familia

*¡Correcto! Solo ustedes la saben.*

**M3 U01 P3.** ¿Cuál es la señal más clara de fraude?

- Que llamen en la mañana
- Que la voz sea joven y hable muy rápido
- ✔ La prisa y que pidan dinero o datos

*¡Correcto! La prisa.*

**M3 U02 P1.** Te llega un mensaje con un premio y una liga. ¿Qué haces?

- Lo abres
- ✔ Lo borras y bloqueas
- Lo reenvías

*¡Correcto! Es trampa.*

**M3 U02 P2.** «Tu hijo» te escribe de otro número pidiendo dinero. ¿Qué haces?

- ✔ Llamas al número de siempre de tu hijo
- Depositas
- Le pides que espere una semana y luego depositas

*¡Correcto! Verificas.*

**M3 U02 P3.** Ya pusiste tus datos en una liga. ¿Qué haces?

- Nada
- Pones más datos
- ✔ Llamas a tu banco y avisas a tu familia

*¡Correcto! Actúas rápido.*

## Módulo 4

**M4 U01 P1.** ¿Cuál es una señal de abuso patrimonial?

- ✔ Te faltan retiros que no hiciste
- Tu nieto te visita
- Te llega tu pensión completa cada bimestre

*¡Correcto! Alguien usa tu dinero.*

**M4 U01 P2.** Tu hijo te pide firmar un papel que no entiendes. ¿Qué haces?

- Firmas, porque confías en tu hijo
- ✔ Pides copia y lo revisas con alguien
- Lo tiras

*¡Correcto! Revisa antes.*

**M4 U01 P3.** ¿Quién debe guardar tu tarjeta?

- Tu cuidadora
- El vecino
- ✔ Tú

*¡Correcto! Es tuya.*

**M4 U02 P1.** Hay un retiro que no hiciste. ¿A quién llamas primero?

- ✔ A tu banco
- Al 911
- A nadie

*¡Correcto! Bloqueo y reclamación.*

**M4 U02 P2.** El banco no resuelve. ¿A dónde vas?

- A otro banco
- ✔ A CONDUSEF
- A la tienda

*¡Correcto! Defiende usuarios.*

**M4 U02 P3.** Te amenazan para que firmes. ¿Qué haces?

- Firmas
- Esperas a que pase
- ✔ Llamas al 911 y buscas orientación

*¡Correcto! Es peligro.*

## Módulo 5

**M5 U01 P1.** ¿Cuál es el tope de descuento a tu pensión del IMSS?

- ✔ 30%
- 50%
- No hay tope

*¡Correcto! 30%.*

**M5 U01 P2.** Te descuentan 1,500 al mes por 36 meses. ¿Cuánto pagas en total?

- 15,000
- ✔ 54,000
- 36,000

*¡Correcto! 1,500 por 36.*

**M5 U01 P3.** ¿Con quién se puede pedir un préstamo a cuenta de pensión IMSS?

- Con cualquiera
- Con quien te ofrezca afuera de la clínica
- ✔ Solo con entidades con convenio

*¡Correcto! Convenio vigente.*

**M5 U02 P1.** ¿De quién es la deuda de un préstamo a tu nombre?

- ✔ Tuya
- De quien lo usa
- De nadie

*¡Correcto! Es tuya.*

**M5 U02 P2.** ¿Qué pasa si eres aval y la otra persona no paga?

- Nada
- ✔ Te pueden cobrar a ti
- Se cancela la deuda porque no es tuya

*¡Correcto! El aval debe.*

**M5 U02 P3.** ¿Qué puedes ofrecer en lugar de firmar?

- Tu NIP
- Tu casa
- ✔ Tu compañía para buscar otra opción

*¡Correcto! Ayudar sin firmar.*

## Módulo 6

**M6 U01 P1.** ¿Qué poder conviene para un solo trámite?

- Uno general para todo, así no vuelves a la notaría
- ✔ Uno limitado con fecha de término
- Ninguno, mejor das tu NIP

*¡Correcto! Limitado.*

**M6 U01 P2.** ¿Se puede cancelar un poder?

- ✔ Sí, ante notario
- No, nunca
- Solo si muere la otra persona

*¡Correcto! Se revoca.*

**M6 U01 P3.** ¿Qué haces antes de firmar un poder?

- Firmas rápido
- ✔ Pides que te expliquen qué podrá hacer la otra persona
- Le das tu tarjeta

*¡Correcto! Entiende antes.*

**M6 U02 P1.** ¿Qué hace tu persona de apoyo?

- ✔ Te acompaña y tú decides
- Decide por ti para que no te equivoques
- Guarda tu tarjeta

*¡Correcto! Tú decides.*

**M6 U02 P2.** ¿Cuántas personas de apoyo conviene tener?

- Nadie
- ✔ Una o dos
- Todas las que se ofrezcan

*¡Correcto! Una o dos.*

**M6 U02 P3.** Tu persona de apoyo te pide el NIP. ¿Qué haces?

- Se lo das
- Le das la mitad
- ✔ No se lo das

*¡Correcto! El NIP es tuyo.*

## Módulo 7

**M7 U01 P1.** ¿Para qué sirve el testamento?

- ✔ Para decir a quién dejas tus bienes
- Para pedir un préstamo a cuenta de tus bienes
- Para cobrar la pensión

*¡Correcto! Tus bienes.*

**M7 U01 P2.** ¿Qué llevas a la notaría?

- Nada
- ✔ Tu lista de bienes y tus papeles
- Solo a tus hijos

*¡Correcto! Lista y papeles.*

**M7 U01 P3.** ¿Cómo se heredan los derechos ejidales?

- ✔ Con la lista de sucesión
- Con un recibo
- No se heredan, regresan al ejido

*¡Correcto! Lista de sucesión.*

**M7 U02 P1.** ¿Dónde se registran los beneficiarios de una cuenta?

- ✔ En el banco
- En el testamento solamente
- En la tienda

*¡Correcto! En cada lugar.*

**M7 U02 P2.** ¿Puedes poner a más de un beneficiario?

- No
- Solo a dos personas, sin porcentaje
- ✔ Sí, con porcentaje para cada uno

*¡Correcto! Con porcentajes.*

**M7 U02 P3.** ¿Qué guardas en la carpeta para tu familia?

- Tu NIP
- ✔ Testamento, pólizas, estados de cuenta y la lista
- Nada

*¡Correcto! Los papeles.*

## Módulo 8

**M8 U01 P1.** ¿Para qué es el guardadito de salud?

- ✔ Solo para salud
- Para regalos y fiestas de la familia
- Para prestar

*¡Correcto! Solo salud.*

**M8 U01 P2.** Apartas 100 al mes. ¿Cuánto en un año?

- 100
- ✔ 1,200
- 12,000

*¡Correcto! 100 por 12.*

**M8 U01 P3.** Te recetan algo caro. ¿Qué haces primero?

- Pides un préstamo en la farmacia
- Lo dejas
- ✔ Preguntas en tu clínica y comparas

*¡Correcto! Pregunta y compara.*

**M8 U02 P1.** Te cobran un seguro que no pediste. ¿Qué haces?

- Lo sigues pagando
- ✔ Pides cancelarlo y la devolución
- Cierras tu cuenta sin decir nada

*¡Correcto! Cancela y reclama.*

**M8 U02 P2.** Te ofrecen un seguro por teléfono. ¿Qué haces?

- Aceptas
- Das tu tarjeta para que te manden la información
- ✔ Pides la información por escrito

*¡Correcto! Por escrito.*

**M8 U02 P3.** ¿Qué parte de las personas de 60 a 70 años tiene seguro?

- ✔ 18%
- 80%
- Todas

*¡Correcto! 18%.*
