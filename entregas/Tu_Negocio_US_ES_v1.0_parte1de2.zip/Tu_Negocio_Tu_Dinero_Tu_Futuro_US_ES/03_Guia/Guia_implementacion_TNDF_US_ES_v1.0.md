# Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_NEGOCIO_US_ES_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TNDF-US-ES`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Negocio, Tu Dinero, Tu Futuro · EE. UU. |
| Nombre corto | TNDF-US-ES |
| Visibilidad | **Ocultar** |
| Formato | Temas, 11 secciones |
| Seguimiento de finalización | Sí |

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Tu negocio y tu casa: dinero separado | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Costos y precio | `M2_resumen.html` |
| 3 | Módulo 3. Flujo de efectivo | `M3_resumen.html` |
| 4 | Módulo 4. Cobrar y vender sin perder | `M4_resumen.html` |
| 5 | Módulo 5. Formalízate e impuestos sin miedo | `M5_resumen.html` |
| 6 | Módulo 6. Crédito para tu negocio | `M6_resumen.html` |
| 7 | Módulo 7. Protege tu negocio | `M7_resumen.html` |
| 8 | Módulo 8. Crecer con orden | `M8_resumen.html` |
| 9 | Módulo 9. Tu futuro | `M9_resumen.html` |
| 10 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 11 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas tu SSN, ITIN, EIN, contraseñas, números de cuenta, montos reales de tu negocio ni tu situación migratoria."

### 3. Libros de lecciones

En cada sección de módulo:

1. Crea un libro: nombre `Lecciones del Módulo N`, formato de capítulo "Nada", finalización "Ver".
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba que cada lección tenga su portada primero y 3 subcapítulos sangrados.

| Módulo | Capítulos | Páginas |
|---|---|---|
| M1 | 4 | 16 |
| M2 | 4 | 16 |
| M3 | 3 | 12 |
| M4 | 3 | 12 |
| M5 | 5 | 20 |
| M6 | 4 | 16 |
| M7 | 4 | 16 |
| M8 | 3 | 12 |
| M9 | 3 | 12 |

### 4. Libro de apoyo

En la sección 10, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos). En la sección General, agrega una **URL** o etiqueta al capítulo 1 ("Bienvenida").

### 5. Glosario

En la sección 10, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_tndf_us_es.gift.txt`. Se crean *Tu Negocio US ES/M1* a *M9*, con 99 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Negocio US ES/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 |
|---|---|---|---|---|---|---|---|---|
| 12 | 12 | 9 | 9 | 15 | 12 | 12 | 9 | 9 |

### 7. Actividades H5P (33)

Archivos en `2_h5p/MN/`, en orden. En cada sección, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones: descarga no, incrustar no, derechos de autor sí.
5. Calificación: seguimiento sí, "calificación más alta". Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos, 3 opciones por caso y la calificación al terminar.

### 8. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`), 4 (finalización con las 9 autoevaluaciones) y 5 (constancia con `6_certificado/certificado_fondo.png`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### 9. Comunidad (opcional, pregunta antes)

Pregunta a la persona si quiere que crees el curso **Comunidad Tu Negocio EE. UU.** (`TNDF-US-ES-COM`, oculto). Tiene su propia carpeta y sus instrucciones: `README_CREAR_COMUNIDAD_PARA_CLAUDE.md`.

### 10. Revisión final (con rol de estudiante)

- M1 U01: portada primero, dos botones de ruta, términos en color con su significado y recuadros "Dato vigente" o "Antes de actuar, verifica".
- Una H5P por módulo abre, muestra 3 casos y registra calificación.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 11. Reporte para la persona

Enlace del curso; páginas por libro; H5P por módulo; preguntas por autoevaluación; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de una portada, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **oculto**. La persona decide cuándo mostrarlo.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2 y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo (9) | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (33) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo (9) | Calificación aprobatoria de 70% |

**Configuración de cada actividad H5P:** sin botón de descarga, con botón de derechos de autor e incrustar desactivado; seguimiento de intentos con "Calificación más alta"; finalización "El estudiante debe recibir una calificación".

**Las autoevaluaciones:** usan el banco de 99 preguntas con tres opciones y retroalimentación, en las categorías *Tu Negocio US ES/M1* a *M9*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 1,275 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 33 | 825 |
| Libros | 9 | 225 |
| Autoevaluaciones | 9 | 225 |
| **Total** | 51 | **1,275** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Idea | 0 | Al entrar |
| 2 | Arranque | 200 | Durante el Módulo 2 |
| 3 | En marcha | 400 | Durante el Módulo 4 |
| 4 | Formal | 650 | Durante el Módulo 5 |
| 5 | En crecimiento | 900 | Durante el Módulo 7 |
| 6 | Consolidado | 1,100 | Durante el Módulo 9 |

**Clasificación:** anonimato activado; mostrar solo vecinos cercanos o desactivarla.

### 3. Insignias

*Administración del curso > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_dinero_separado.png | Dinero separado | Autoevaluación del Módulo 1 | Separaste el dinero del negocio y de tu casa y te pagas un sueldo. |
| 02_precio_justo.png | Precio justo | Autoevaluación del Módulo 2 | Conoces tus costos, tu margen y tu punto de equilibrio. |
| 03_flujo_bajo_control.png | Flujo bajo control | Autoevaluaciones de los Módulos 3 y 4 | Controlas tu flujo, tu fiado y tus formas de cobro sin perder. |
| 04_negocio_formal.png | Negocio formal | Autoevaluación del Módulo 5 | Tienes tu estructura, tus números, permisos e impuestos en orden. |
| 05_credito_inteligente.png | Crédito inteligente | Autoevaluación del Módulo 6 | Sabes si necesitas crédito y cuánto cuesta de verdad. |
| 06_negocio_protegido.png | Negocio protegido | Autoevaluación del Módulo 7 | Protegiste tu salud, tu negocio y tu marca, y te cuidas de fraudes. |
| 07_crecer_con_orden.png | Crecer con orden | Autoevaluaciones de los Módulos 8 y 9 | Creces con orden y tienes tu plan de una página. |
| 08_plan_completo.png | Plan completo | Finalización del curso | Concluiste los nueve módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*: condición de finalización de actividades con **todas** las 9 autoevaluaciones. Opcional: los 9 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado**: nombre "Constancia de conclusión", tamaño A4 horizontal (297 × 210 mm).
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 9 autoevaluaciones, "debe estar completa con calificación aprobatoria".
3. **Editar certificado:**

   | Elemento | Posición aproximada (mm) | Formato |
   |---|---|---|
   | Imagen de fondo | Cubre la página | `6_certificado/certificado_fondo.png` |
   | Nombre del estudiante | X 0, Y 74, ancho 297, centrado | Negrita, 32 pt, color #0B1220 |
   | Fecha (finalización del curso) | X 17, Y 170, ancho 70, centrado | 12 pt, color #E4007C |
   | Código | X 210, Y 170, ancho 70, centrado | 12 pt, color #E4007C |

4. Revisa la **Vista previa en PDF** y compárala con `certificado_muestra.png`. Activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.


# Parte 3. Comunidad y canales


### 1. Comunidad Tu Negocio EE. UU. en Moodle

Un curso aparte, **"Comunidad Tu Negocio EE. UU."** (nombre corto `TNDF-US-ES-COM`), complemento de este curso. Tiene avisos, foros de dudas por tema, alertas de fraude, el foro «Presenta tu negocio», logros, una sesión mensual en vivo y un foro separado de referencias comerciales. Su creación está en su propia carpeta.

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Negocio US ES" y agregarla con "Sincronización de cohortes" en el curso y en la comunidad.

### 2. Sesión mensual en vivo

- Una sesión al mes por videollamada, de 60 minutos: tema del mes (por ejemplo, «Tus pagos estimados», «Precio con margen») y preguntas.
- Se usan ejemplos inventados. **Nunca** se abre la cuenta del IRS, la banca o la plataforma de una participante frente al grupo.
- Si se invita a una persona experta (preparador de impuestos, CPA, asesor de un SBDC), se aclara que es orientación general.

### 3. Canal de WhatsApp

- Nombre: "Tu Negocio EE. UU. · Desarrolla Talento".
- Contenido: avisos del curso, fechas de impuestos (pagos estimados, declaración anual en abril), alertas de fraude a negocios y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles y circulan fraudes y ofertas de «créditos».

### 4. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial (por ejemplo, procesadores de pago, preparadores de impuestos o seguros) se publican **solo** en el canal y en el foro de referencias, nunca en lecciones, actividades, autoevaluaciones ni constancia. Cada publicación dice: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 5. Reglas de moderación

1. Borrar publicaciones con datos personales o fiscales (SSN, ITIN, EIN, contraseñas, capturas de cuentas, situación migratoria) y avisar en privado.
2. No permitir que participantes promuevan préstamos, inversiones, productos financieros ni esquemas fiscales.
3. En «Presenta tu negocio», una publicación al mes por persona.
4. Revisar el mismo día cualquier alerta de fraude.
5. Canalizar casos fiscales, legales, laborales o migratorios al IRS, VITA, un preparador, un SBDC o un abogado u organización acreditada.


# Parte 4. Mantenimiento


Cada cifra de las lecciones va en un recuadro «Dato vigente» con fecha y fuente. La tabla completa está en el manual del programa, sección 7.

| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Noviembre y diciembre | Límites de retiro del año siguiente (IRS) | M9 U01 |
| Diciembre y julio | Tarifa estándar por milla (el IRS puede ajustarla a mitad de año) | M1 U04 |
| Octubre | Base de Seguro Social y monto por crédito (SSA) | M5 U03, M9 U01 |
| Enero | Umbrales de 1099 (ajuste por inflación desde 2027) | M5 U04, M8 U02 |
| Enero | Salario mínimo de California y de ciudades | M8 U01 |
| Cada año | Mínimo de LLC en California, tasas de sales tax, límite de la CSLB | M5 U01, M5 U02, M5 U05 |
| Cada año | Tarifas de la USPTO | M7 U04 |
| Cada seis meses | Comisiones de procesadores y plataformas | M4 U01, M8 U02 |
| Antes de la inscripción abierta | Reglas de Covered California y Medi-Cal | M7 U01 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco y volver a armar la carpeta | Herramientas del proyecto |

