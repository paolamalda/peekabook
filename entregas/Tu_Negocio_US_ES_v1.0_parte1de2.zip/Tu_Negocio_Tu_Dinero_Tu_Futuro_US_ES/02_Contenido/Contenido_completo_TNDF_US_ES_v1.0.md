# Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Perfil | Reto principal |
|---|---|---|
| **Lupita** (41) | Vende tamales y comida por encargo desde su casa en Los Ángeles; declara con ITIN; su sobrina le ayuda | Mezcla cuentas, no sabe qué permisos necesita ni si puede con su ITIN |
| **Javier** (38) | Pintor y handyman en Fresno; trabaja para contratistas y dueños de casa | Impuestos sin apartar, 1099, licencia de la CSLB, seguro que le piden los clientes |
| **Daniela** (27) | Vende joyería por redes y en una plataforma desde San José; tiene una LLC | 1099-K, sales tax, comisiones, deudas en tarjeta personal, marca |
| **Don Ramón** (60) | Tiene un food truck en Sacramento desde hace 12 años | Temporadas, crédito caro, seguros, retiro y quién seguirá con el negocio |

Son personajes inventados; cualquier parecido con personas reales es coincidencia.

---

## 2. Mapa de módulos

| Módulo | Lecciones | Resultado |
|---|---|---|
| M1 Tu negocio y tu casa: dinero separado | 4 | Dinero separado, cuenta para impuestos, sueldo fijo y registros |
| M2 Costos y precio | 4 | Costos calculados, precio con margen y punto de equilibrio |
| M3 Flujo de efectivo | 3 | Calendario de flujo, crédito a clientes y reserva |
| M4 Cobrar y vender sin perder | 3 | Formas de cobro comparadas y protocolo contra fraudes al vender |
| M5 Formalízate e impuestos sin miedo | 5 | Estructura, EIN e ITIN, permisos, impuestos federales, pagos estimados y sales tax |
| M6 Crédito para tu negocio | 4 | Decidir si necesitas crédito, compararlo por APR y no mezclarlo |
| M7 Protege tu negocio | 4 | Seguro médico, seguros del negocio, fraudes a negocios y marca |
| M8 Crecer con orden | 3 | Contratar bien, vender en plataformas y medir |
| M9 Tu futuro | 3 | Seguro Social y retiro, plan de continuidad y plan de una página |

**Insignias:** Dinero separado (M1), Precio justo (M2), Flujo bajo control (M3 y M4), Negocio formal (M5), Crédito inteligente (M6), Negocio protegido (M7), Crecer con orden (M8 y M9) y Plan completo (curso).

---

## 3. Lecciones

# Parte 2. Módulo 1. Tu negocio y tu casa: dinero separado

## M1 U01. ¿Tu negocio gana o solo vende?

**Lo que lograrás:** Distinguir entre ventas y ganancia, y calcular si tu negocio gana, pierde o apenas sale.

**Para empezar:** Lupita vende tamales y comida por encargo en Los Ángeles: unos $4,000 al mes. Siente que le va bien, pero a fin de mes no le alcanza para la renta. En esta lección verás por qué vender mucho no siempre es ganar.

### Lo esencial (5 minutos)

#### Vender no es ganar

Las ventas son lo que cobras. La ganancia es lo que queda después de pagar todo lo que te costó vender: ingredientes, empaques, gas, gasolina, comisiones y ayuda.



#### La cuenta de Lupita en un mes

- Ventas: **$4,000**
- Ingredientes y empaques: **$1,700**
- Gas, gasolina, comisiones y ayuda de su sobrina: **$900**
- Ganancia del negocio: **$1,400**
Lupita creía que ganaba $4,000. En realidad le quedan $1,400, y de ahí también salen sus impuestos (M5).


#### Tres resultados posibles

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ganas | Ventas mayores que todos los costos. | Puedes pagarte y ahorrar. |
| Sales tablas | Ventas iguales a los costos. | Trabajas gratis. |
| Pierdes | Costos mayores que las ventas. | Pones de tu bolsa. |

#### Un caso en un minuto

Lupita guardó durante un mes todos sus recibos. Descubrió que la gasolina para entregar y las hojas de maíz eran casi $400 que nunca contaba. Ahora sabe que su ganancia real es de $1,400.

> **Idea clave:** no midas tu negocio por lo que vendes, sino por lo que te queda después de pagar todo.



#### Comprueba lo que entendiste

1. ¿Qué diferencia hay entre ventas y ganancia?
*Respuesta:* Las ventas son lo que cobras; la ganancia es lo que queda después de pagar todos los costos.

2. Si vendes $2,000 y gastas $2,000, ¿cuánto ganas?
*Respuesta:* Nada: sales tablas y trabajas gratis.


#### Para recordar

- Ventas menos costos es ganancia.
- Cuenta todos los costos, también los chicos.
- De la ganancia también salen tus impuestos.



### Profundiza (5 minutos más)

#### Costos que se olvidan

| Costo | Por qué se olvida |
|---|---|
| Gasolina y millas de entregas | Se pagan de tu bolsa |
| Empaques, bolsas, etiquetas | Son montos chicos que se suman |
| Comisiones de apps y tarjetas | Se descuentan solas |
| Tu teléfono e internet | Los usas también en casa |
| Lo que se echa a perder | No se ve como gasto |



#### Tu tiempo también cuesta

Si trabajas 50 horas a la semana y el negocio te deja $1,400 al mes, ganas unos $7 por hora: menos que el salario mínimo. Compararlo te ayuda a decidir qué mejorar: precios, costos o ventas.



#### Casos


**Caso 1. El mes de Lupita**

Lupita vendió más que nunca en diciembre por los tamales, pero pagó más ingredientes y ayuda.
- *¿Qué hace para saber si ganó?* Resta todos los costos del mes a sus ventas antes de celebrar.


**Caso 2. Los pedidos de Daniela**

Daniela vendió 90 aretes en un mes, pero pagó envíos que no cobró.
- *¿Qué revisa?* Cuánto le queda por pieza después de material, envío y comisión.


**Caso 3. Las horas de Javier**

Javier cobra bien cada trabajo de pintura, pero pasa muchas horas manejando y cotizando sin cobrar.
- *¿Qué hace?* Calcula cuánto gana por hora contando traslados y ajusta su tarifa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Medir por ventas | Crees que ganas | Resta todos los costos |
| Olvidar costos chicos | Ganancia inflada | Guarda recibos un mes |
| No contar tu tiempo | Trabajas barato | Calcula por hora |
| Olvidar impuestos | Sorpresa en abril | Aparta una parte (M5) |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Daniela y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Vendes $3,000 y tus costos son $2,200. ¿Cuánto ganas? a) $800 · b) $3,000 · c) $5,200
2. ¿Qué es la ganancia? a) Todo lo que cobras a tus clientes en el mes, en efectivo y por apps · b) Lo que queda después de pagar todos los costos · c) Lo que hay en tu cuenta al cerrar
3. Tus ventas y tus costos son iguales. ¿Qué pasa? a) Ganas poco, pero el negocio sí te deja algo · b) Pierdes dinero cada mes · c) Sales tablas: trabajas gratis
**Respuestas:** 1-a: $3,000 menos $2,200. 2-b: ventas menos costos. 3-c: no queda nada para ti.



#### Ponlo en práctica

Vendes $2,500 al mes. Gastas $1,100 en materiales, $300 en gasolina y $100 en comisiones. ¿Cuánto ganas?
**Respuesta:** $2,500 menos $1,500: $1,000.



#### A tu plan

Esta semana anota todas tus ventas y guarda todos los recibos del negocio, aunque sean pequeños.



### Para saber más

- **Guía para empezar un negocio** (SBA · español e inglés): https://www.sba.gov — **Qué buscar:** «plan your business» y recursos en español.

### Palabras clave

- *Ventas:* todo lo que cobras a tus clientes, antes de restar lo que te costó.
- *Ganancia:* lo que queda de las ventas después de pagar todos los costos del negocio.

### Fuentes

Small Business Administration (SBA), consultado el 29 de septiembre de 2026.

---

## M1 U02. Separa el dinero del negocio y de tu casa

**Lo que lograrás:** Separar el dinero del negocio del de tu casa con una cuenta aparte y reglas claras.

**Para empezar:** Lupita recibe pagos por Zelle y en efectivo en la misma cuenta donde le llega su sueldo de medio tiempo. Paga ahí la renta y los ingredientes. En esta lección verás cómo separar sin complicarte.

### Lo esencial (5 minutos)

#### Dos bolsas, dos dueños

El negocio y tu casa son dos bolsas distintas. Si mezclas, nunca sabrás si tu negocio gana, y a la hora de declarar impuestos será difícil demostrar tus gastos. La regla: **el dinero del negocio solo sale para cosas del negocio o para tu sueldo.**



#### Cómo separar

1. Abre una cuenta de cheques solo para el negocio (puede estar a tu nombre).
2. Todos los cobros entran ahí: efectivo, tarjetas y apps de pago.
3. Paga materiales, permisos y gasolina del negocio solo desde ahí.
4. Para tu casa, págate un sueldo fijo (M1 U03).



#### Qué va en cada bolsa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Del negocio | Ingredientes, material, comisiones, permisos. | Salen de la cuenta del negocio. |
| De tu casa | Renta, comida, escuela. | Salen de tu sueldo. |
| Mezclados | Todo en una cuenta. | No sabes si ganas. |
| Cobros a tu app personal | Se pierden entre tus gastos. | Usa una cuenta del negocio. |

> **Dato vigente:** el FDIC asegura los depósitos en bancos hasta $250,000 por persona, por banco y por tipo de cuenta; el NCUA protege lo mismo en cooperativas de crédito (credit unions). Consultado el 29 de septiembre de 2026 a través de FDIC y NCUA.

#### Un caso en un minuto

Lupita abrió una segunda cuenta de cheques en una cooperativa de crédito, sin cargo mensual, y conectó su app de pagos a esa cuenta. Ya sabe cuánto vende cada semana.

> **Idea clave:** separa el dinero y págate un sueldo; sabrás si tu negocio gana y tendrás tus gastos listos para declarar.



#### Comprueba lo que entendiste

1. ¿Para qué sirve separar el dinero?
*Respuesta:* Para saber si tu negocio gana y tener pruebas de tus gastos para los impuestos.

2. ¿Cómo pasas dinero del negocio a tu casa?
*Respuesta:* Con un sueldo fijo, no pagando gastos de la casa desde el negocio.


#### Para recordar

- Dos bolsas: negocio y casa.
- Todo cobro entra al negocio.
- A tu casa, solo tu sueldo.



### Profundiza (5 minutos más)

#### ¿Cuenta personal o de negocio?

Si trabajas como dueño único (sole proprietor), puedes usar una segunda cuenta personal solo para el negocio. Muchas cuentas de negocio piden un EIN o documentos de tu negocio (M5 U02). Compara cargos mensuales, saldo mínimo y cuántas transacciones incluye. Algunos bancos y cooperativas abren cuentas con ITIN.



#### El efectivo

Si cobras mucho en efectivo, cuenta al cerrar, anota el total y deposita seguido. El efectivo también se declara como ingreso.



#### Si tienes que tomar prestado

Si un día usas dinero del negocio para una emergencia de tu casa, anótalo como préstamo y devuélvelo.



#### Casos


**Caso 1. La cuenta de Lupita**

Lupita recibe cobros del negocio y su sueldo en la misma cuenta.
- *¿Qué hace?* Abre una cuenta solo para el negocio y conecta ahí sus cobros.


**Caso 2. El material de Javier**

Javier compra pintura con la tarjeta de débito de su casa.
- *¿Qué hace?* La paga desde la cuenta del negocio y guarda el recibo.


**Caso 3. El efectivo de Don Ramón**

Don Ramón guarda en su casa el efectivo del food truck durante semanas.
- *¿Qué hace?* Cuenta, anota y deposita seguido en la cuenta del negocio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Una sola cuenta | Todo se mezcla | Cuenta aparte |
| Pagar la casa del negocio | No sabes si ganas | Sueldo fijo |
| Efectivo sin anotar | Ingresos sin registro | Anota y deposita |
| Préstamos sin anotar | Hoyos en las cuentas | Anota y devuelve |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Desde dónde pagas el material del negocio? a) Desde tu cuenta de la casa · b) Desde la cuenta del negocio · c) Desde lo que haya ese día en tu cartera o en la caja
2. Usas $200 del negocio para una emergencia de tu casa. ¿Qué haces? a) Lo olvidas, total es tu negocio · b) Lo cubres con tu tarjeta de crédito y te olvidas del tema · c) Lo anotas como préstamo y lo devuelves
3. ¿Hasta cuánto asegura el FDIC por persona, por banco y por tipo de cuenta? a) $250,000 · b) $25,000 · c) Todo lo que tengas, sin límite
**Respuestas:** 1-b: cada bolsa paga lo suyo. 2-c: así no se pierde. 3-a: por persona, banco y tipo de cuenta.



#### Ponlo en práctica

En una semana entraron a la cuenta del negocio $900 y pagaste $520 de material. ¿Cuánto queda en el negocio?
**Respuesta:** $380.



#### A tu plan

Elige esta semana tu cuenta del negocio y conecta ahí tus apps de cobro.



### Para saber más

- **Seguro de depósitos** (FDIC · español): https://www.fdic.gov — **Qué buscar:** «seguro de depósitos» en español.
- **Cuentas de banco** (CFPB · español): https://www.consumerfinance.gov/es — **Qué buscar:** «cuentas de cheques».

### Palabras clave

- *Cuenta del negocio:* cuenta que usas solo para cobrar y pagar cosas del negocio.
- *FDIC:* agencia federal que asegura los depósitos en bancos.

### Fuentes

FDIC · NCUA · CFPB, consultados el 29 de septiembre de 2026.

---

## M1 U03. Págate un sueldo

**Lo que lograrás:** Fijar un sueldo para ti que el negocio pueda pagar, apartando antes para impuestos.

**Para empezar:** Lupita ya separó el dinero, pero no sabe cuánto llevar a su casa. Algunas semanas saca mucho y otras nada, y le preocupa lo que deberá de impuestos. En esta lección verás cómo fijar un sueldo.

### Lo esencial (5 minutos)

#### Tú también trabajas para tu negocio

Si trabajas en tu negocio, mereces un sueldo del dueño fijo, en la misma fecha. Así tu casa tiene un ingreso estable y el negocio conserva lo que necesita.



#### Cómo fijarlo

1. Calcula tu ganancia promedio de los últimos 3 meses.
2. Aparta primero para impuestos (una regla práctica: 25% a 30% de la ganancia; M5 U03).
3. De lo que queda, toma una parte como sueldo y deja el resto como reserva.
4. Págalo siempre el mismo día y revísalo cada 3 meses.



#### El sueldo de Lupita

- Ganancia promedio al mes: **$1,400**
- Apartado para impuestos (25%): **$350**
- Reserva del negocio: **$150**
- Sueldo al mes (unos $225 por semana): **$900**


#### Un caso en un minuto

Lupita se transfiere $225 cada lunes de la cuenta del negocio a la suya. Los impuestos los aparta en una cuenta de ahorro para pagar sus pagos trimestrales (M5 U04).

> **Idea clave:** primero impuestos, luego reserva, luego tu sueldo fijo; así ni tu casa ni el IRS te sorprenden.



#### Comprueba lo que entendiste

1. ¿De dónde sale tu sueldo?
*Respuesta:* De la ganancia promedio, después de apartar impuestos y reserva.

2. ¿Por qué apartar para impuestos antes?
*Respuesta:* Porque como dueño nadie te retiene impuestos: los pagas tú.


#### Para recordar

- Impuestos, reserva, sueldo.
- Basado en la ganancia promedio.
- Revísalo cada 3 meses.



### Profundiza (5 minutos más)

#### Si eres dueño único

Como sole proprietor, tu «sueldo» no es un gasto del negocio para el IRS: pagas impuestos sobre toda la ganancia, la saques o no. Por eso apartar impuestos es tan importante. Si tienes una LLC u otra estructura, las reglas pueden cambiar (M5 U01).



#### Tu sueldo en números

| Dato | Monto |
|---|---|
| Ganancia promedio de 3 meses | |
| Impuestos (25% a 30%) | |
| Reserva | |
| Sueldo al mes | |
| Sueldo por semana | |



#### Si ayuda tu familia

Si tu sobrina o tu pareja trabajan en el negocio, acuerden un pago. Si son empleados, hay reglas de nómina (M8 U01).



#### Casos


**Caso 1. La buena semana de Lupita**

Lupita vendió el triple la semana de Navidad.
- *¿Qué hace?* Se paga su sueldo normal y aparta el excedente para impuestos y reserva.


**Caso 2. Los meses de Javier**

Javier gana $6,000 en verano y $2,000 en invierno.
- *¿Qué hace?* Se paga un sueldo con base en su promedio y guarda lo de los meses buenos.


**Caso 3. Los impuestos de Daniela**

Daniela gasta toda su ganancia y no ha apartado para impuestos.
- *¿Qué hace desde hoy?* Aparta un porcentaje de cada ganancia en una cuenta para impuestos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar todo | Deuda con el IRS | Aparta impuestos |
| Sacar según las ventas | Casa inestable | Sueldo fijo |
| No pagarte | No sabes tu costo | Págate |
| Creer que el sueldo reduce impuestos | Sorpresa | Pagas sobre la ganancia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Javier y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu ganancia es $2,000 y apartas 25% para impuestos. ¿Cuánto apartas? a) $250 · b) $2,000 · c) $500
2. Tuviste una semana excelente. ¿Qué haces? a) Te pagas tu sueldo y apartas el excedente · b) Sacas todo lo extra para la casa porque te lo ganaste · c) Te subes el sueldo desde ese día
3. ¿Por qué apartas impuestos como dueño? a) Porque nadie te los retiene · b) Porque el banco te lo pide al abrir la cuenta · c) No hace falta: se pagan solos
**Respuestas:** 1-c: 25% de $2,000. 2-a: el excedente se aparta. 3-a: los pagas tú.



#### Ponlo en práctica

Tu ganancia fue $1,800, $2,100 y $1,500 en tres meses. Apartas 25% de impuestos y $200 de reserva. ¿Cuál es tu sueldo mensual?
**Respuesta:** Promedio $1,800; menos $450 y $200: $1,150.



#### A tu plan

Calcula tu ganancia promedio, abre una cuenta para impuestos y fija tu sueldo y tu día de pago.



### Para saber más

- **Impuestos para trabajadores por cuenta propia** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «impuesto sobre el trabajo por cuenta propia».

### Palabras clave

- *Sueldo del dueño:* cantidad fija que te pasas del negocio cada semana o quincena.
- *Sole proprietor (dueño único):* persona que tiene un negocio a su nombre, sin crear una empresa aparte.

### Fuentes

IRS · SBA, consultados el 29 de septiembre de 2026.

---

## M1 U04. Registros en 10 minutos al día

**Lo que lograrás:** Llevar un registro sencillo de ventas y gastos, guardar recibos y hacer un corte cada semana.

**Para empezar:** Daniela vende joyería por Instagram y en una tienda en línea. Guarda los pagos en capturas y los gastos en la memoria. En abril no supo qué declarar. En esta lección verás cómo llevar tus registros.

### Lo esencial (5 minutos)

#### Qué anotar

Cada día anota: fecha, cuánto vendiste (efectivo, tarjeta, apps) y cuánto gastaste y en qué. Guarda los recibos. El IRS te pide poder **demostrar** tus ingresos y gastos.



#### Elige tu herramienta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Libreta | Sencilla. | Súmala cada semana. |
| Hoja de cálculo | Suma sola. | En el celular o la computadora. |
| App de contabilidad | Conecta tu cuenta y reportes. | Revisa costo y datos. |
| Solo capturas | Se pierden. | No suman. |

#### Tu corte semanal

1. Suma las ventas de la semana.
2. Suma los gastos del negocio.
3. Resta: esa es tu ganancia de la semana.
4. Compara con el saldo de la cuenta del negocio.



#### Un caso en un minuto

Daniela hizo una hoja con fecha, concepto, entra y sale, y una carpeta digital para fotos de recibos. Cada domingo hace su corte. En enero tendrá su año listo para declarar.

> **Idea clave:** anota cada día, guarda recibos y haz un corte cada semana; sin registros no hay decisiones ni declaración correcta.



#### Comprueba lo que entendiste

1. ¿Qué anotas cada día?
*Respuesta:* Fecha, ventas y gastos con su concepto.

2. ¿Por qué guardar recibos?
*Respuesta:* Para demostrar tus gastos del negocio ante el IRS.


#### Para recordar

- Diario: fecha, entra, sale.
- Recibos guardados.
- Corte semanal.



### Profundiza (5 minutos más)

#### Tu registro

| Fecha | Concepto | Entra | Sale |
|---|---|---|---|
| | | | |
| | | | |
| **Total de la semana** | | | |



#### Millas del negocio

Si usas tu auto para el negocio, anota fecha, destino, motivo y millas de cada viaje. Puedes deducir con la tarifa estándar por milla del IRS (M5 U03). Sin registro, no hay deducción.

> **Dato vigente:** la tarifa estándar del IRS para uso de negocio es de 72.5 centavos por milla de enero a junio de 2026 y de 76 centavos por milla desde el 1 de julio de 2026. Consultado el 29 de septiembre de 2026 a través del IRS (Notice 2026-10 e Internal Revenue Bulletin 2026-29).



#### Cuánto tiempo guardar

El IRS recomienda guardar tus registros y recibos al menos 3 años después de presentar tu declaración, y más tiempo en algunos casos.



#### Casos


**Caso 1. Las capturas de Daniela**

Daniela tiene cientos de capturas de pagos del año.
- *¿Qué hace?* Pasa cada pago a su hoja el mismo día y guarda los recibos en una carpeta.


**Caso 2. Las millas de Javier**

Javier maneja a cotizar trabajos todos los días y no anota nada.
- *¿Qué hace?* Anota fecha, destino, motivo y millas de cada viaje.


**Caso 3. La app de Don Ramón**

Una app gratuita pide a Don Ramón su número de Seguro Social y la contraseña de su banco para «hacer sus cuentas».
- *¿Qué hace?* No da su contraseña y elige una herramienta confiable o una hoja.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Anotar de memoria | Se olvidan gastos | Diario |
| Sin recibos | No puedes deducir | Guárdalos |
| Sin registro de millas | Pierdes deducción | Anota cada viaje |
| Dar contraseñas | Robo | Nunca |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es lo mínimo que anotas cada día? a) Solo las ventas grandes · b) Lo que recuerdes el domingo · c) Fecha, ventas y gastos
2. ¿Qué necesitas para deducir millas? a) Un registro de cada viaje · b) Solo el recibo de gasolina del mes · c) Nada, se calcula solo
3. Una app te pide la contraseña de tu banco. ¿Qué haces? a) Se la das si es gratis y tiene buenas reseñas · b) No se la das y eliges otra herramienta · c) Le das solo tu número de Seguro Social
**Respuestas:** 1-c: con eso basta. 2-a: sin registro no hay deducción. 3-b: pide de más.



#### Ponlo en práctica

Manejaste 300 millas de negocio en agosto de 2026. ¿Cuánto podrías deducir con la tarifa estándar?
**Respuesta:** 300 por 76 centavos: $228.



#### A tu plan

Elige tu herramienta, crea una carpeta para recibos y anota tus ventas, gastos y millas esta semana.



### Para saber más

- **Registros para pequeños negocios** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «mantenimiento de registros».

### Palabras clave

- *Registro:* lista de lo que entra y sale del negocio, con fecha y concepto.
- *Corte:* suma de ventas y gastos de un periodo para saber cuánto ganaste.
- *Tarifa estándar por milla:* cantidad que el IRS permite deducir por cada milla manejada para el negocio.

### Fuentes

IRS, consultado el 29 de septiembre de 2026.

---


# Parte 3. Módulo 2. Costos y precio

## M2 U01. Costos fijos y variables

**Lo que lograrás:** Separar tus costos en fijos y variables y calcular cuánto te cuesta cada producto o servicio.

**Para empezar:** Daniela compra material para cada par de aretes en $6 y los vende en $25. Cree que gana $19 por par. Pero no ha contado la comisión de la tienda en línea, el envío ni su suscripción mensual. En esta lección verás cuánto le cuesta de verdad cada par.

### Lo esencial (5 minutos)

#### Dos tipos de costos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fijos | Los pagas vendas o no: suscripciones, seguro, teléfono, permisos. | Cada mes igual. |
| Variables | Suben si vendes más: material, empaques, comisiones, envíos. | Por cada venta. |
| Tu sueldo | Es un costo fijo más. | No lo olvides. |
| Sin clasificar | No sabes cuánto te cuesta vender. | Ordénalos. |

#### Tu costo por unidad

El costo por unidad suma lo que gastas en cada pieza (variable) más la parte que le toca de tus costos fijos.



#### Los aretes de Daniela

- Material: **$6**
- Empaque, envío y comisión: **$5**
- Parte de sus fijos ($360 al mes ÷ 120 pares): **$3**
- Costo real por par: **$14**
Daniela no gana $19 por par, sino $11, y de ahí salen sus impuestos.


#### Un caso en un minuto

Lupita calculó que cada docena de tamales le cuesta $14 en ingredientes y $4 de su parte de fijos: $18. La vende en $30. Ahora sabe que le quedan $12 por docena.

> **Idea clave:** suma a cada producto lo que gastas en él y la parte que le toca de tus costos fijos.



#### Comprueba lo que entendiste

1. ¿Qué es un costo fijo?
*Respuesta:* Uno que pagas aunque no vendas, como una suscripción, el seguro o tu sueldo.

2. ¿Cómo repartes los fijos por unidad?
*Respuesta:* Divides los costos fijos del mes entre las unidades que vendes al mes.


#### Para recordar

- Fijos: vendas o no.
- Variables: por cada venta.
- Costo por unidad = variable + parte de fijos.



### Profundiza (5 minutos más)

#### Tus costos del mes

| Costo | Fijo o variable | Monto al mes |
|---|---|---|
| Renta o cocina comercial | Fijo | |
| Teléfono, internet, suscripciones | Fijo | |
| Seguro y permisos (divididos entre 12) | Fijo | |
| Tu sueldo y ayudantes | Fijo | |
| Material o ingredientes | Variable | |
| Empaques y envíos | Variable | |
| Comisiones de cobro y apps | Variable | |



#### Servicios: tu hora cuesta

Si vendes servicios, como Javier, tu costo principal es tu tiempo. Divide tus costos fijos y tu sueldo entre las horas que de verdad cobras al mes: ese es tu costo por hora. Suma material, millas y herramienta que se desgasta.



#### Casos


**Caso 1. Los aretes de Daniela**

Daniela cree que gana $19 por par porque el material cuesta $6 y los vende en $25.
- *¿Qué le falta sumar?* Empaque, envío, comisión y su parte de costos fijos.


**Caso 2. La hora de Javier**

Javier cobra $35 la hora, pero no sabe si le alcanza.
- *¿Qué calcula?* Su costo por hora con sus costos fijos, su sueldo y las horas que cobra.


**Caso 3. El seguro de Don Ramón**

Don Ramón paga el seguro del food truck una vez al año y nunca lo cuenta en sus costos.
- *¿Qué hace?* Lo divide entre 12 y lo suma a sus costos fijos de cada mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar solo el material | Precio bajo | Suma los fijos |
| Olvidar tu sueldo | Trabajas gratis | Es un costo fijo |
| Ignorar pagos anuales | Sorpresas | Divide entre 12 |
| No contar el tiempo | Servicio barato | Costo por hora |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál de estos es un costo variable? a) La suscripción de tu tienda en línea · b) El empaque de cada pedido · c) Tu plan de teléfono
2. Tus fijos son $600 y vendes 200 piezas al mes. ¿Cuánto fijo le toca a cada pieza? a) $3 · b) $30 · c) $600
3. ¿Tu sueldo es un costo del negocio? a) No, es ganancia · b) Solo si te sobra algo al final del mes · c) Sí, es un costo fijo
**Respuestas:** 1-b: sube con cada venta. 2-a: $600 entre 200. 3-c: sin él trabajas gratis.



#### Ponlo en práctica

Un pastel te cuesta $18 de ingredientes y $2 de caja. Tus fijos son $400 al mes y vendes 50 pasteles. ¿Cuál es el costo por pastel?
**Respuesta:** $18 más $2 más $8 ($400 entre 50): $28.



#### A tu plan

Haz tu lista de costos del mes, sepáralos en fijos y variables y calcula el costo de tu producto principal.



### Para saber más

- **Calcula tus costos** (SBA · inglés): https://www.sba.gov — **Qué buscar:** «calculate your startup costs».

### Palabras clave

- *Costo fijo:* gasto que pagas vendas o no, como una suscripción o tu sueldo.
- *Costo variable:* gasto que sube con cada venta, como material o empaques.
- *Costo por unidad:* lo que te cuesta producir o vender una pieza, un platillo o un servicio, contando costos variables y una parte de los fijos.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---

## M2 U02. ¿Cuánto cobrar?

**Lo que lograrás:** Poner un precio que cubra tus costos, deje un margen y tenga sentido para tus clientes y frente a la competencia.

**Para empezar:** Javier cobra lo mismo que otros pintores de su barrio porque «así se cobra». Pero él tiene seguro, camioneta y herramienta nueva. En esta lección verás cómo poner tu propio precio.

### Lo esencial (5 minutos)

#### Tres miradas para tu precio

Tu precio se revisa desde tres lados: **tu costo** (el piso, nunca cobres menos), **la competencia** (qué cobran otros por algo parecido) y **el valor para tu cliente** (rapidez, calidad, garantía, seguro).



#### Precio con margen

- Costo real por par de aretes: **$14**
- Para un margen de 30% sobre el precio: **0.70**
- Precio mínimo: **$20**
Daniela vende en $25: su margen es de 44%. Tiene espacio para promociones sin perder.


#### Tu precio frente a otros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Más barato que todos | Muchas ventas, poca ganancia. | Riesgo de perder. |
| Parecido | Compites por servicio y calidad. | Muestra por qué tú. |
| Más caro | Necesitas explicar el valor. | Seguro, garantía, rapidez. |
| Debajo de tu costo | Pierdes con cada venta. | Nunca. |

#### Un caso en un minuto

Javier calculó su costo por hora en $32. Cobraba $35 y apenas le quedaba. Subió a $45 y en sus cotizaciones escribe que tiene seguro de responsabilidad civil y garantía de 30 días. Perdió un cliente, pero ganó más con los demás.

> **Idea clave:** tu costo es el piso; el margen es lo que te permite crecer y pagar impuestos; la competencia y el valor te dicen hasta dónde subir.



#### Comprueba lo que entendiste

1. ¿Qué es el piso de tu precio?
*Respuesta:* Tu costo por unidad: nunca cobras menos.

2. ¿Qué es el margen?
*Respuesta:* La parte del precio que queda después de cubrir el costo.


#### Para recordar

- Costo = piso.
- Margen = crecimiento.
- Competencia y valor = techo.



### Profundiza (5 minutos más)

#### Margen y sobreprecio no son lo mismo

Si a un costo de $100 le sumas 30%, cobras $130 y tu margen es de 23% ($30 entre $130). Para tener 30% de margen, divide el costo entre 0.70: $143.



#### Envíos, comisiones e impuesto sobre ventas

El envío, la comisión de la plataforma y la de la tarjeta son costos variables: súmalos al costo o cóbralos con claridad. El impuesto sobre ventas (sales tax) no es parte de tu precio: se cobra aparte y es del estado (M5 U05).



#### Subir precios sin perder clientes

Avisa con anticipación, explica el porqué (materiales, calidad) y mantén una opción económica si puedes.



#### Casos


**Caso 1. El precio de Javier**

Javier cobra lo mismo que otros pintores, aunque sus costos son mayores.
- *¿Qué hace?* Calcula su costo por hora y pone un precio con margen, explicando su seguro y garantía.


**Caso 2. La oferta de Daniela**

Daniela quiere bajar sus aretes a $15 para vender más.
- *¿Qué revisa?* Que $15 cubra su costo real de $14 y deje margen para impuestos.


**Caso 3. El aumento de Lupita**

La masa y la carne subieron y los tamales de Lupita ya casi no dejan.
- *¿Qué hace?* Recalcula su costo, avisa a sus clientes y sube el precio con anticipación.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Copiar el precio | No cubres tus costos | Calcula el tuyo |
| Vender bajo costo | Pierdes con cada venta | Costo = piso |
| Meter el sales tax en tu ganancia | Debes al estado | Es aparte |
| Subir sin avisar | Clientes molestos | Avisa y explica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Daniela y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu costo es $35. ¿Cuál es el precio mínimo para un margen de 30% sobre el precio? a) $45.50 · b) $35 · c) $50
2. ¿Cuándo nunca debes vender? a) Por debajo de tu costo · b) Más caro que la competencia · c) Con garantía por escrito para tu cliente
3. Tus materiales subieron. ¿Qué haces? a) Usas material más barato sin avisar a tus clientes · b) Recalculas tu costo y avisas del nuevo precio · c) Esperas a que bajen solos
**Respuestas:** 1-c: $35 entre 0.70. 2-a: pierdes con cada venta. 3-b: con aviso y claridad.



#### Ponlo en práctica

Un servicio te cuesta $120. Quieres un margen de 25% sobre el precio. ¿Cuánto cobras?
**Respuesta:** $120 entre 0.75: $160.



#### A tu plan

Revisa el precio de tu producto principal: ¿cubre tu costo y deja margen? Ajusta si no.



### Para saber más

- **Fijar precios** (SBA · inglés): https://www.sba.gov — **Qué buscar:** «pricing».

### Palabras clave

- *Margen:* parte del precio que queda después de cubrir el costo.
- *Precio piso:* el precio mínimo que cubre tu costo.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---

## M2 U03. Tu punto de equilibrio

**Lo que lograrás:** Calcular cuánto necesitas vender al mes para cubrir todos tus costos.

**Para empezar:** Don Ramón paga cada mes el espacio del food truck, el seguro, el permiso del condado, su sueldo y el de su ayudante: $6,000. Quiere saber cuánto debe vender para no perder. En esta lección verás cómo calcularlo.

### Lo esencial (5 minutos)

#### Qué es

El punto de equilibrio es lo que necesitas vender para que tus ventas cubran todos tus costos. Por debajo pierdes; por arriba ganas.



#### La fórmula

Divide tus **costos fijos** entre lo que te deja cada dólar de venta después de los variables (tu margen de contribución).



#### El food truck de Don Ramón

- Costos fijos al mes: **$6,000**
- Lo que le deja cada venta después de ingredientes y comisiones: **60%**
- Ventas mínimas al mes (unos $400 por día, 25 días): **$10,000**
Si vende menos de $10,000, pierde; si vende más, gana.


#### Un caso en un minuto

Don Ramón vende en promedio $480 al día: $12,000 al mes. Está $2,000 arriba de su punto de equilibrio: eso le deja $1,200 de ganancia (60% de $2,000) además de su sueldo, antes de impuestos.

> **Idea clave:** conoce tu venta mínima de cada día; es tu meta para no perder.



#### Comprueba lo que entendiste

1. ¿Qué pasa si vendes menos que tu punto de equilibrio?
*Respuesta:* Pierdes dinero ese mes.

2. ¿Qué necesitas para calcularlo?
*Respuesta:* Tus costos fijos y lo que te deja cada venta después de los variables.


#### Para recordar

- Fijos ÷ margen de contribución.
- Tu meta diaria para no perder.
- Arriba ganas, abajo pierdes.



### Profundiza (5 minutos más)

#### En unidades

Si vendes un producto principal, calcula en piezas. Lupita tiene $500 de fijos y cada docena le deja $16 ($30 menos $14 de ingredientes): necesita unas 32 docenas al mes, unas 8 por semana.



#### Tu punto de equilibrio

| Dato | Monto |
|---|---|
| Costos fijos al mes (incluye tu sueldo) | |
| Lo que te deja cada venta (%) o cada pieza | |
| Punto de equilibrio al mes | |
| Meta al día (entre días que trabajas) | |



#### Cómo bajarlo

Baja costos fijos, sube el precio o mejora lo que te deja cada venta (comprar mejor, reducir merma, negociar comisiones).



#### Casos


**Caso 1. El espacio de Don Ramón**

Le suben a Don Ramón $400 al mes el espacio donde se estaciona.
- *¿Qué hace?* Recalcula su punto de equilibrio y su meta diaria.


**Caso 2. Los tamales de Lupita**

Lupita vende 6 docenas por semana y su equilibrio es de 8.
- *¿Qué hace?* Busca subir ventas, precio o bajar costos para no perder.


**Caso 3. El local de Daniela**

Daniela quiere rentar un pequeño local por $900 al mes.
- *¿Qué calcula antes?* Cuánto tendría que vender de más para cubrir la nueva renta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No conocer tu mínimo | Pierdes sin saber | Calcula tu equilibrio |
| Olvidar tu sueldo en los fijos | Equilibrio falso | Inclúyelo |
| No recalcular | Metas viejas | Cada cambio de costos |
| Rentar sin calcular | Deudas | Calcula antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Fijos de $3,000 y cada venta te deja 50%. ¿Punto de equilibrio? a) $1,500 · b) $6,000 · c) $3,500
2. Vendes menos que tu punto de equilibrio. ¿Qué pasa? a) Ganas poco · b) Estás igual · c) Pierdes dinero
3. ¿Qué baja tu punto de equilibrio? a) Bajar costos fijos · b) Rentar un local más grande en una mejor zona · c) Dar más crédito a tus clientes
**Respuestas:** 1-b: $3,000 entre 0.50. 2-c: no cubres tus costos. 3-a: necesitas vender menos.



#### Ponlo en práctica

Tus fijos son $1,200 y cada pieza te deja $8. ¿Cuántas piezas necesitas vender al mes?
**Respuesta:** $1,200 entre $8: 150 piezas.



#### A tu plan

Calcula tu punto de equilibrio y escribe tu meta de venta diaria donde la veas.



### Para saber más

- **Punto de equilibrio** (SBA · inglés): https://www.sba.gov — **Qué buscar:** «break-even point».

### Palabras clave

- *Punto de equilibrio:* ventas mínimas para cubrir todos tus costos: ni ganas ni pierdes.
- *Margen de contribución:* lo que queda de cada venta después de pagar sus costos variables, para cubrir los fijos.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---

## M2 U04. Inventario y merma

**Lo que lograrás:** Comprar lo que se vende, reducir lo que se pierde y no tener dinero parado en mercancía.

**Para empezar:** Don Ramón tira carne y tortillas cada semana, y Daniela tiene cajas de un modelo de collar que nadie compra. En esta lección verás cuánto les cuesta y cómo reducirlo.

### Lo esencial (5 minutos)

#### El inventario es dinero

Tu inventario es dinero convertido en productos. Si no se vende, es dinero parado; si se echa a perder, es dinero tirado. A lo que se pierde se le llama merma.



#### Tres tipos de producto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Rota rápido | Se vende cada día. | Nunca te falte. |
| Rota lento | Se vende de vez en cuando. | Compra poco. |
| Parado | No se vende. | Liquídalo y no vuelvas a comprar. |
| Merma | Se echa a perder. | Mídela y redúcela. |

#### Cómo reducir la merma

1. Anota una semana lo que tiras o no vendes.
2. Compra más seguido y en menor cantidad lo perecedero.
3. Primero en entrar, primero en salir: usa primero lo más viejo.
4. Vende a precio especial antes de que se eche a perder, si las reglas de salud lo permiten.



#### Un caso en un minuto

Don Ramón anotó su merma: $350 al mes. Empezó a comprar carne dos veces por semana en menos cantidad y a preparar según los días fuertes. Redujo la merma a $120.

> **Idea clave:** compra lo que rota, mide lo que tiras y no dejes tu dinero parado.



#### Comprueba lo que entendiste

1. ¿Por qué el inventario parado es un problema?
*Respuesta:* Es dinero que no puedes usar para otra cosa.

2. ¿Qué es primero en entrar, primero en salir?
*Respuesta:* Usar o vender primero lo más viejo para que no se eche a perder.


#### Para recordar

- Inventario = dinero.
- Mide tu merma.
- Compra lo que rota.



### Profundiza (5 minutos más)

#### Tu merma de la semana

| Producto | Cantidad perdida | Costo |
|---|---|---|
| | | |
| **Total** | | |



#### Las ofertas por volumen

«Compra 10 cajas y te regalo una» solo conviene si vendes las 11 antes de que se echen a perder o de que necesites ese dinero.



#### Inventario e impuestos

El costo de la mercancía que vendes se descuenta en tu declaración como costo de ventas. Lleva registro de lo que compras y de lo que tienes al final del año.



#### Casos


**Caso 1. La oferta a Don Ramón**

El proveedor ofrece a Don Ramón una caja gratis si compra 10 de un producto que vende poco.
- *¿Qué hace?* Compra solo lo que vende antes de que caduque, aunque pierda el regalo.


**Caso 2. Los ingredientes de Lupita**

Lupita tira chiles y hojas cada semana.
- *¿Qué hace?* Anota lo que tira y compra menos cantidad y más seguido.


**Caso 3. Los collares de Daniela**

Daniela tiene 50 collares de un modelo que no se vendió.
- *¿Qué hace?* Los ofrece con descuento para recuperar el dinero y no vuelve a comprar ese modelo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comprar por oferta | Dinero parado | Compra lo que rota |
| No medir la merma | Pierdes sin saber | Anota una semana |
| Guardar lo que no se vende | Ocupa espacio y dinero | Liquídalo |
| Sin registro de inventario | Declaración incorrecta | Anota compras |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es la merma? a) El descuento que te da el proveedor por volumen · b) Lo que se echa a perder o ya no puedes vender · c) La mercancía nueva
2. Tienes 30 piezas que no se venden. ¿Qué haces? a) Las ofreces con descuento · b) Compras más para exhibir · c) Las guardas por si acaso
3. ¿Cuándo conviene una oferta de «lleva más»? a) Siempre · b) Si el proveedor es de confianza y te da buen precio · c) Si vendes todo antes de que caduque
**Respuestas:** 1-b: dinero tirado. 2-a: dinero parado. 3-c: si no, sale cara.



#### Ponlo en práctica

Compras 100 piezas a $2 y tiras 10. ¿Cuánto te cuesta cada pieza que vendes?
**Respuesta:** $200 entre 90: unos $2.22.



#### A tu plan

Anota esta semana lo que tiras o no vendes y decide qué dejar de comprar.



### Para saber más

- **Costo de ventas** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «costo de bienes vendidos».

### Palabras clave

- *Inventario:* mercancía o insumos que compraste y todavía no vendes.
- *Merma:* mercancía que se echa a perder, se rompe o se pierde y ya no puedes vender.
- *Rotación:* qué tan rápido se vende un producto.

### Fuentes

IRS · SBA, consultados el 29 de septiembre de 2026.

---


# Parte 4. Módulo 3. Flujo de efectivo

## M3 U01. Ganar no es tener efectivo

**Lo que lograrás:** Entender el flujo de efectivo y hacer un calendario sencillo de entradas y salidas para no quedarte sin dinero.

**Para empezar:** Javier terminó de pintar una casa por $4,500 para un contratista, pero le pagarán en 30 días. Mientras, tiene que pagar pintura, gasolina y su pago trimestral de impuestos. En esta lección verás por qué ganar no es lo mismo que tener dinero.

### Lo esencial (5 minutos)

#### Qué es el flujo

El flujo de efectivo es el dinero que de verdad entra y sale, y **cuándo**. Puedes tener ganancia en papel y no tener efectivo para pagar esta semana, porque te pagan tarde o porque compraste de golpe.



#### Qué afecta tu flujo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te pagan tarde | Facturas a 30 días o clientes que se atrasan. | El dinero llega después. |
| Compras grandes | Material o equipo. | Sale mucho de golpe. |
| Pagos fijos | Seguro, permisos, impuestos trimestrales. | Siempre llegan. |
| Depósitos o anticipos | Cobras antes de trabajar. | Mejora tu flujo. |

#### Tu calendario de 4 semanas

1. Escribe cuánto dinero tienes hoy en el negocio.
2. Anota, por semana, lo que esperas cobrar.
3. Anota, por semana, lo que tienes que pagar (incluye impuestos trimestrales).
4. Suma y resta: si alguna semana queda en negativo, actúa antes.



#### Un caso en un minuto

Javier vio en su calendario que en la semana 3 le faltarían $700 por su pago de impuestos. Pidió un depósito de 30% para el siguiente trabajo y negoció con la tienda de pintura pagar a 30 días.

> **Idea clave:** mira tus próximas cuatro semanas: el problema de efectivo se resuelve antes, no el día que no alcanza.



#### Comprueba lo que entendiste

1. ¿Por qué puedes ganar y no tener efectivo?
*Respuesta:* Porque te pagan después o porque pagas antes de cobrar.

2. ¿Para qué sirve el calendario?
*Respuesta:* Para ver antes las semanas en que faltará dinero.


#### Para recordar

- Flujo = cuándo entra y sale.
- Calendario de 4 semanas.
- Actúa antes de que falte.



### Profundiza (5 minutos más)

#### Tu calendario

| | Semana 1 | Semana 2 | Semana 3 | Semana 4 |
|---|---|---|---|---|
| Saldo inicial | | | | |
| + Cobros esperados | | | | |
| − Pagos | | | | |
| = Saldo final | | | | |



#### Depósitos y plazos

Pide depósito en trabajos grandes y por escrito. Si un cliente paga a 30 días, pide a tu proveedor una cuenta con plazo parecido. Revisa las reglas de tu estado sobre depósitos: en California, por ejemplo, los contratos de mejoras al hogar limitan el anticipo.



#### Crédito caro para tapar huecos

Si el calendario muestra un hueco, no lo tapes con adelantos de efectivo de tu tarjeta, préstamos de día de pago (payday) o adelantos sobre ventas futuras (merchant cash advance): su costo se come tu ganancia (M6).



#### Casos


**Caso 1. El pago tardío a Javier**

El contratista le paga a Javier a 30 días y él necesita material ya.
- *¿Qué hace?* Pide depósito y negocia plazo con su proveedor.


**Caso 2. La compra de Don Ramón**

Don Ramón quiere comprar de una vez todos los insumos de un festival y se quedaría sin efectivo dos semanas.
- *¿Qué hace?* Revisa su calendario y compra en partes o con plazo.


**Caso 3. El adelanto de Daniela**

A Daniela le faltan $300 para pagar a su proveedor y una app le ofrece un adelanto sobre sus ventas futuras.
- *¿Qué hace antes?* Revisa su reserva y pide plazo al proveedor antes de un crédito caro.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo la ganancia | Te quedas sin efectivo | Mira el flujo |
| No pedir depósito | Financias al cliente | Depósito por escrito |
| Olvidar los impuestos trimestrales | Hueco | En el calendario |
| Tapar con crédito caro | Pierdes ganancia | Reserva y plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Don Ramón y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tienes $600, cobrarás $900 y pagarás $1,700 esta semana. ¿Cómo terminas? a) Con $200 de sobra · b) Con $3,200 · c) Con $200 de faltante
2. ¿Qué mejora tu flujo? a) Pagar antes a tus proveedores para que te traten mejor · b) Pedir depósito en trabajos grandes · c) Dar más plazo a tus clientes
3. Tu calendario muestra un hueco en tres semanas. ¿Qué haces? a) Buscas soluciones desde hoy · b) Esperas a ver si se arregla · c) Pides un adelanto rápido el día que falte
**Respuestas:** 1-c: $600 más $900 menos $1,700. 2-b: cobras antes. 3-a: actúa antes.



#### Ponlo en práctica

Saldo inicial $800. Semana 1: cobras $1,200 y pagas $1,500. Semana 2: cobras $600 y pagas $1,200. ¿Cómo terminas cada semana?
**Respuesta:** Semana 1: $500. Semana 2: $500 más $600 menos $1,200: faltan $100.



#### A tu plan

Haz tu calendario de las próximas cuatro semanas y marca las semanas con riesgo.



### Para saber más

- **Flujo de efectivo** (SBA · inglés): https://www.sba.gov — **Qué buscar:** «manage your finances» y «cash flow».

### Palabras clave

- *Flujo de efectivo:* el dinero que realmente entra y sale del negocio, y cuándo.
- *Depósito o anticipo:* parte del pago que el cliente da antes de que hagas el trabajo.

### Fuentes

SBA · Contractors State License Board (CSLB), consultados el 29 de septiembre de 2026.

---

## M3 U02. Crédito a clientes, facturas y cobranza

**Lo que lograrás:** Poner reglas para vender a crédito, enviar facturas claras y cobrar con respeto y dentro de la ley.

**Para empezar:** Lupita tiene $650 pendientes de clientes que le encargaron comida para fiestas y «luego le pagan». Javier tiene una factura de $1,200 con 45 días de atraso. En esta lección verás cómo poner reglas y cobrar.

### Lo esencial (5 minutos)

#### Vender a crédito es prestar

Cuando entregas antes de cobrar, prestas tu dinero sin intereses. Puede ayudarte a vender más, pero si crece sin control, te deja sin efectivo.



#### Reglas claras

1. Para pedidos grandes, pide un depósito (por ejemplo, 50%).
2. Pon por escrito el precio, la fecha de entrega y la fecha de pago.
3. Envía una factura (invoice) el mismo día que entregas.
4. Lleva una lista de quién te debe, cuánto y desde cuándo.
5. Si alguien no paga, no hay más crédito hasta que liquide.



#### Cómo cobrar con respeto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Recuerda la fecha | Un mensaje amable antes del día. | Sin presión. |
| Reenvía la factura | Con el monto y la fecha. | Claridad. |
| Acepta pagos parciales | Mejor poco que nada. | Anota cada pago. |
| Exhibir o amenazar | Nunca: dañas tu negocio y puede ser ilegal. | No. |

#### Un caso en un minuto

Lupita ahora pide 50% de depósito en pedidos de fiesta y el resto al entregar. Ya no tiene cuentas pendientes de más de una semana.

> **Idea clave:** vender a crédito es prestar; pide depósito, pon todo por escrito y factura el mismo día.



#### Comprueba lo que entendiste

1. ¿Qué pones por escrito en un pedido grande?
*Respuesta:* Precio, fecha de entrega, depósito y fecha de pago.

2. ¿Cuándo envías la factura?
*Respuesta:* El mismo día que entregas.


#### Para recordar

- Depósito en pedidos grandes.
- Todo por escrito.
- Factura el mismo día.



### Profundiza (5 minutos más)

#### Quién te debe

| Cliente | Fecha de factura | Monto | Pagos | Debe | Días de atraso |
|---|---|---|---|---|---|
| | | | | | |



#### Si no te pagan

Primero recuerda por escrito. Después, una carta formal con fecha límite. Para montos pequeños, la corte de reclamos menores (small claims court) de tu condado es una opción sin abogado; en California el límite para personas es de $12,500 (revísalo en la corte). Si trabajas en construcción en California, investiga el «mechanics lien» con tiempo: tiene plazos estrictos.



#### Lo que no se hace

No publiques a tus deudores en redes, no amenaces y no contactes a su familia o su trabajo. Además de dañar tu negocio, puede traerte problemas legales.



#### Casos


**Caso 1. Los pedidos de Lupita**

Un cliente de Lupita pide 20 docenas para una boda y promete pagar después.
- *¿Qué hace?* Pide 50% de depósito y pone por escrito el precio y la fecha de pago.


**Caso 2. La factura de Javier**

Una factura de Javier de $1,200 lleva 45 días de atraso.
- *¿Qué hace?* Recuerda por escrito, manda carta con fecha límite y considera la corte de reclamos menores.


**Caso 3. El cliente de Don Ramón**

Una oficina le pide a Don Ramón comida cada viernes y pagar a fin de mes.
- *¿Qué hace?* Acepta con acuerdo escrito, factura cada entrega y pone un límite.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin depósito | Pierdes si cancelan | Pide depósito |
| Acuerdos de palabra | Discusiones | Por escrito |
| Facturar tarde | Te pagan tarde | El mismo día |
| Exhibir al deudor | Problemas legales | Cobra con respeto |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es vender a crédito para tu negocio? a) Una venta ya cobrada · b) Un préstamo sin intereses a tu cliente · c) Una ganancia extra
2. Un cliente no ha pagado y pide otro pedido. ¿Qué haces? a) Le entregas para no perderlo · b) Publicas su nombre en tus redes para presionarlo · c) No le das más crédito hasta que pague
3. ¿Qué pides en un pedido grande? a) Un depósito y el acuerdo por escrito · b) Solo su número de teléfono · c) Nada: la confianza basta
**Respuestas:** 1-b: dinero que no ha regresado. 2-c: regla clara. 3-a: te protege.



#### Ponlo en práctica

Un pedido de $480 con 50% de depósito. ¿Cuánto cobras antes y cuánto al entregar?
**Respuesta:** $240 y $240.



#### A tu plan

Escribe tus reglas de crédito a clientes y haz una lista de quién te debe hoy.



### Para saber más

- **Corte de reclamos menores** (California Courts · español): https://www.courts.ca.gov — **Qué buscar:** «reclamos menores».

### Palabras clave

- *Factura (invoice):* documento con lo que vendiste, el monto y la fecha límite de pago.
- *Corte de reclamos menores:* corte para cobrar montos pequeños sin abogado.

### Fuentes

California Courts · SBA, consultados el 29 de septiembre de 2026.

---

## M3 U03. Tu reserva y las temporadas bajas

**Lo que lograrás:** Formar una reserva para el negocio y prepararte para los meses flojos, los impuestos y los gastos anuales.

**Para empezar:** El food truck de Don Ramón vende mucho en verano y en ferias, pero en enero y febrero casi nada. El año pasado usó su tarjeta de crédito para pagar el seguro. En esta lección verás cómo prepararte.

### Lo esencial (5 minutos)

#### Qué es la reserva

La reserva del negocio es el colchón del negocio: dinero para pagar costos fijos y tu sueldo cuando vendes menos o surge un imprevisto. Es distinta de tu fondo de emergencia personal y de tu cuenta para impuestos.



#### La reserva de Don Ramón

- Costos fijos al mes (con su sueldo): **$6,000**
- Meses de colchón: **2**
- Meta de reserva: **$12,000**
Aparta un porcentaje de cada venta en los meses buenos hasta llegar a la meta.


#### Dónde guardarla

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta de ahorro aparte | Asegurada por FDIC o NCUA. | Disponible. |
| Cuenta de alto rendimiento | Asegurada y con más interés. | Revisa cargos. |
| Efectivo en casa o en el truck | Riesgo de robo o gasto. | Evítalo. |
| La tarjeta de crédito | No es reserva: es deuda. | Evítalo. |

#### Un caso en un minuto

Don Ramón aparta 10% de cada venta de mayo a octubre en una cuenta de ahorro. En enero paga el seguro y su sueldo con la reserva, sin usar la tarjeta.

> **Idea clave:** en los meses buenos, aparta para los flojos; la reserva evita deudas caras.



#### Comprueba lo que entendiste

1. ¿Para qué sirve la reserva?
*Respuesta:* Para pagar costos fijos y tu sueldo en meses flojos o imprevistos.

2. ¿Es lo mismo que tu cuenta para impuestos?
*Respuesta:* No: los impuestos se apartan en otra cuenta.


#### Para recordar

- Reserva = colchón del negocio.
- Aparta un % de cada venta.
- Aparte de los impuestos.



### Profundiza (5 minutos más)

#### Tus gastos anuales del negocio

| Gasto | Mes | Monto | Aparta al mes |
|---|---|---|---|
| Licencia y permisos | | | |
| Seguro | | | |
| Tarifa anual de tu LLC (si tienes) | | | |
| Mantenimiento o equipo | | | |



#### Tu mapa del año

Revisa tus ventas de cada mes del año pasado. Marca los meses altos y bajos. Planea compras y reserva según ese mapa.



#### Qué no es reserva

Los ahorros de tu casa, el inventario, lo que te deben y el límite de tu tarjeta no son reserva.



#### Casos


**Caso 1. El invierno de Don Ramón**

Don Ramón sabe que enero y febrero son flojos.
- *¿Qué hace en verano?* Aparta un porcentaje de cada venta en una cuenta de ahorro.


**Caso 2. El efectivo de Lupita**

Lupita guarda su reserva en efectivo en su cocina.
- *¿Qué hace?* La pasa a una cuenta de ahorro asegurada.


**Caso 3. La tarifa de Daniela**

Daniela tiene una LLC y paga una tarifa anual al estado.
- *¿Qué hace desde enero?* Divide el monto entre 12 y lo aparta cada mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin reserva | Deudas caras | Aparta cada venta |
| Reserva en efectivo | Robo o gasto | Cuenta asegurada |
| Mezclar con impuestos | Te falta en abril | Cuentas separadas |
| La tarjeta como reserva | Intereses | Reserva real |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Costos fijos de $1,500 al mes. ¿Reserva para 3 meses? a) $500 · b) $1,500 · c) $4,500
2. ¿Dónde conviene guardar la reserva? a) En una cuenta de ahorro asegurada · b) En efectivo en tu casa, donde siempre la tienes a la mano · c) En más inventario
3. Tu seguro cuesta $1,200 al año. ¿Cuánto apartas al mes? a) $120 · b) $100 · c) $1,200
**Respuestas:** 1-c: $1,500 por 3. 2-a: protegida y disponible. 3-b: $1,200 entre 12.



#### Ponlo en práctica

Vendes $15,000 en julio y apartas 10%. ¿Cuánto va a la reserva?
**Respuesta:** $1,500.



#### A tu plan

Fija tu meta de reserva y el porcentaje de cada venta que apartarás desde esta semana.



### Para saber más

- **Ahorro y seguro de depósitos** (FDIC · español): https://www.fdic.gov — **Qué buscar:** «seguro de depósitos».

### Palabras clave

- *Reserva del negocio:* dinero apartado para cubrir los costos fijos del negocio en meses flojos o imprevistos.
- *Temporada baja:* meses en que tu negocio vende menos.

### Fuentes

FDIC · NCUA, consultados el 29 de septiembre de 2026.

---


# Parte 5. Módulo 4. Cobrar y vender sin perder

## M4 U01. Efectivo, tarjeta, apps o link de pago

**Lo que lograrás:** Comparar las formas de cobro por su costo, rapidez, protección y seguridad, y elegir las que convienen a tu negocio.

**Para empezar:** Los clientes de Don Ramón le piden pagar con tarjeta y con apps. Le ofrecen un lector de tarjetas «gratis», pero no sabe cuánto le cobrarán ni cuándo le depositan. En esta lección verás cómo comparar.

### Lo esencial (5 minutos)

#### Formas de cobro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Efectivo | Sin comisión. | Riesgo de robo; también se declara. |
| Apps de pago (Zelle, cuentas de negocio en apps) | Rápidas; algunas cobran por cuenta de negocio. | Casi sin protección si hay fraude. |
| Lector de tarjetas | Cobras con tarjeta. | Comisión por cobro. |
| Link de pago o factura en línea | Cobras a distancia. | Comisión; revisa contracargos. |

> **Dato vigente:** los procesadores de pago cobran comúnmente entre 2.6% y 3.5% por cobro con tarjeta, más una cuota fija de unos centavos por transacción; los cobros a distancia suelen costar más que los presenciales. Consultado el 29 de septiembre de 2026 a través de las tarifas publicadas de procesadores de pago.

#### Lo que cuesta cobrar con tarjeta

- Cobros con tarjeta al mes: **$8,000**
- Comisión aproximada: **2.9%**
- Costo al mes: **$232**
Súmalo a tus costos variables; también es un gasto deducible del negocio.


#### Antes de contratar, pregunta

1. Comisión por cobro presencial, a distancia y con tarjeta digitada.
2. Cargo mensual, costo del aparato y contrato mínimo.
3. En cuántos días depositan y si cobran por depósito inmediato.
4. Qué pasa con los contracargos y cuánto cobran por cada uno.



#### Un caso en un minuto

Don Ramón comparó dos opciones: una sin cargo mensual y 2.6% más 15 centavos; otra con $30 al mes y 2.3%. Con $8,000 al mes y 800 cobros, la primera le cuesta unos $328 y la segunda $214. Eligió la segunda.

> **Idea clave:** compara el costo total al mes con tus ventas reales, no solo el porcentaje.



#### Comprueba lo que entendiste

1. ¿Qué preguntas antes de contratar un lector de tarjetas?
*Respuesta:* Comisiones, cargo mensual, contrato, días de depósito y contracargos.

2. ¿Por qué las apps de pago tienen riesgo?
*Respuesta:* Porque si te pagan con una cuenta robada o te engañan, casi no hay protección.


#### Para recordar

- Compara costo total.
- Pregunta depósito y contracargos.
- La comisión es costo del negocio.



### Profundiza (5 minutos más)

#### Compara tus opciones

| Dato | Opción A | Opción B | Opción C |
|---|---|---|---|
| Comisión presencial | | | |
| Cuota fija por cobro | | | |
| Cargo mensual | | | |
| Días de depósito | | | |
| Costo total con tus ventas | | | |



#### Recargos por pagar con tarjeta

Algunos estados limitan o prohíben cobrar un recargo por pagar con tarjeta, y las redes de tarjetas tienen reglas propias. Lo más sencillo es incluir el costo en tu precio. Si quieres ofrecer un descuento por pagar en efectivo, revisa las reglas de tu estado.



#### Apps personales para cobrar

Muchas apps de pago prohíben usar cuentas personales para cobros del negocio y pueden cerrarlas. Usa la opción de negocio o una cuenta conectada a tu cuenta del negocio. Recuerda: todo lo que cobras es ingreso, llegue por donde llegue.



#### Casos


**Caso 1. El lector de Don Ramón**

A Don Ramón le ofrecen un lector «gratis» con contrato de dos años.
- *¿Qué hace?* Calcula el costo total con sus ventas y revisa el contrato antes de firmar.


**Caso 2. Los cobros de Lupita**

Lupita cobra sus pedidos en su app personal de pagos.
- *¿Qué hace?* Usa la opción de negocio o una cuenta conectada a su cuenta del negocio.


**Caso 3. El link de Daniela**

Daniela quiere cobrar con link a clientes que no conoce.
- *¿Qué revisa?* Comisión, días de depósito y quién paga si hay contracargo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el porcentaje | Costo oculto | Costo total |
| Contratos largos sin leer | Penalización | Lee antes |
| Apps personales para el negocio | Cuenta cerrada | Opción de negocio |
| Creer que las apps no se declaran | Problemas con el IRS | Todo es ingreso |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras $5,000 al mes con tarjeta y la comisión es 3%. ¿Cuánto pagas? a) $150 · b) $500 · c) $15
2. ¿Los cobros por apps de pago son ingreso del negocio? a) No, si son menos de $600 · b) Sí, llegue por donde llegue · c) Solo si recibes un formulario 1099-K
3. Opción A: 2.6% sin cargo mensual. Opción B: 2.3% más $30 al mes. Vendes $4,000 con tarjeta. ¿Cuál es más barata, sin contar cuotas fijas? a) La A: $104 · b) La B: $122 · c) Cuestan igual
**Respuestas:** 1-a: 3% de $5,000. 2-b: todo ingreso se declara. 3-a: $104 contra $92 más $30.



#### Ponlo en práctica

Con la opción B (2.3% más $30 al mes), ¿a partir de cuántas ventas al mes es más barata que la A (2.6% sin cargo)?
**Respuesta:** Cuando 0.3% de las ventas supera $30: más de $10,000 al mes.



#### A tu plan

Anota cuánto cobras al mes con tarjeta y compara al menos dos opciones con tus números.



### Para saber más

- **Pagos digitales** (CFPB · español): https://www.consumerfinance.gov/es — **Qué buscar:** «aplicaciones de pago».

### Palabras clave

- *Procesador de pagos:* empresa que te permite cobrar con tarjeta y cobra una comisión.
- *Contracargo:* cuando el banco del cliente le regresa un pago con tarjeta porque lo desconoce o lo reclama.

### Fuentes

CFPB · tarifas publicadas de procesadores de pago, consultados el 29 de septiembre de 2026.

---

## M4 U02. Cobros por apps y transferencias seguras

**Lo que lograrás:** Cobrar por apps y transferencias confirmando cada pago y cuidando tu cuenta.

**Para empezar:** Daniela entrega pedidos cuando el cliente le manda la captura del pago. Una vez la captura era falsa y perdió un collar de $80. En esta lección verás cómo confirmar cada pago.

### Lo esencial (5 minutos)

#### La captura no es prueba

Las apps de pago y las transferencias llegan rápido, pero **la captura del cliente no es prueba de pago**: se puede falsificar o mostrar un pago «pendiente» que nunca llega.



#### Antes de entregar, confirma

1. Abre tu app o tu banco y revisa que el dinero **ya esté disponible**.
2. Revisa monto, nombre y fecha.
3. No aceptes «ya te mandé, revisa el correo»: los correos falsos imitan a las apps.
4. Solo entonces entrega.



#### Cuida tu cuenta de cobro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Alertas | Aviso de cada pago recibido. | Confirmas al instante. |
| Autenticación en dos pasos | Contraseña más código. | Menos robo de cuentas. |
| Comparte solo tu usuario o correo de cobro | Nunca códigos ni contraseñas. | Para cobrar basta eso. |
| Captura como prueba | Se falsifica fácil. | No es prueba. |

#### Un caso en un minuto

Daniela activó las alertas de su app y de su banco. Ahora solo entrega cuando ve el pago disponible. Dos clientes con capturas falsas desaparecieron cuando les dijo que esperaría.

> **Idea clave:** entrega solo cuando el dinero esté disponible en tu cuenta, no cuando te manden una captura o un correo.



#### Comprueba lo que entendiste

1. ¿Por qué una captura no es prueba de pago?
*Respuesta:* Porque se puede falsificar o ser de un pago que no se completó.

2. ¿Qué compartes para que te paguen?
*Respuesta:* Solo tu usuario, correo o teléfono de cobro; nunca códigos ni contraseñas.


#### Para recordar

- Revisa en tu app antes de entregar.
- Alertas y dos pasos.
- Nunca códigos.



### Profundiza (5 minutos más)

#### El código de verificación

Si alguien te pide el código que te llegó por mensaje «para verificar que eres real» o «para mandarte el pago», es un fraude: con ese código entran a tu cuenta o crean una a tu nombre.



#### Correos falsos de «pago pendiente»

Hay correos que imitan a las apps y dicen que el pago está «detenido» hasta que pagues una «actualización a cuenta de negocio». Las apps reales no funcionan así: revisa siempre dentro de la app.



#### Si te equivocas al enviar

Los pagos entre personas por apps suelen ser como efectivo: una vez enviados, difícilmente se recuperan. Revisa bien a quién pagas, sobre todo a proveedores.



#### Casos


**Caso 1. La captura de Daniela**

Un cliente manda a Daniela una captura y pide que envíe ya.
- *¿Qué hace?* Revisa su app y envía solo cuando el pago esté disponible.


**Caso 2. El correo a Lupita**

Lupita recibe un correo de «su app de pagos»: el pago de un cliente está detenido hasta que ella pague $50.
- *¿Qué hace?* No paga y revisa dentro de la app; es un fraude.


**Caso 3. El código de Javier**

Un supuesto cliente le pide a Javier el código que le llegó «para confirmar su identidad».
- *¿Qué hace?* No da el código: para pagarle solo necesita su usuario de cobro.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar capturas | Pierdes mercancía | Revisa tu app |
| Dar códigos | Te roban la cuenta | Nunca |
| Creer correos | Pagas un fraude | Revisa en la app |
| Sin alertas | No ves los pagos | Actívalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Lupita y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo entregas un pedido pagado por app? a) Cuando te mandan la captura · b) Cuando el cliente te jura por teléfono que ya pagó · c) Cuando el dinero está disponible en tu cuenta
2. ¿Qué compartes para que te paguen? a) Tu usuario o correo de cobro · b) Tu contraseña · c) El código que te llegó por mensaje
3. Un correo dice que tu pago está detenido hasta que pagues una «actualización». ¿Qué es? a) Un trámite normal de la app · b) Un fraude: revisa dentro de la app · c) Un cargo de tu banco
**Respuestas:** 1-c: la captura no es prueba. 2-a: basta para cobrar. 3-b: las apps no cobran así.



#### Ponlo en práctica

Recibes 10 pedidos al día por app. Si revisar cada uno toma 30 segundos, ¿cuánto tiempo al día te cuesta confirmar?
**Respuesta:** 5 minutos al día.



#### A tu plan

Activa las alertas de pagos recibidos y la autenticación en dos pasos en tu app y tu banco.



### Para saber más

- **Estafas con aplicaciones de pago** (FTC · español): https://consumidor.ftc.gov — **Qué buscar:** «aplicaciones de pago» y «estafas».

### Palabras clave

- *Autenticación en dos pasos:* acceso con contraseña más un código o aprobación en tu teléfono.
- *Pago pendiente:* pago que todavía no está disponible y puede no llegar.

### Fuentes

FTC · CFPB, consultados el 29 de septiembre de 2026.

---

## M4 U03. Fraudes al vender

**Lo que lograrás:** Reconocer los fraudes más comunes contra quien vende y tener un protocolo para no caer.

**Para empezar:** A Javier un cliente le mandó un cheque por $2,500 cuando el trabajo era de $1,500, y le pidió regresarle $1,000 por Zelle. A Daniela le llegó un pedido grande con envío urgente a otro estado. En esta lección verás estos y otros fraudes.

### Lo esencial (5 minutos)

#### Fraudes frecuentes al vender

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cheque de más | Te pagan de más y piden regresar la diferencia. | El cheque rebota días después. |
| Captura falsa | Pago que no existe. | Revisa tu app. |
| Tarjeta robada | Compra grande con prisa y otra dirección. | Contracargo. |
| Proveedor falso | «Cambiamos de cuenta, paga aquí». | Confirma por otro medio. |

#### Tu protocolo

1. Entrega solo con el dinero disponible en tu cuenta.
2. Nunca regreses «excedentes» de un pago; si alguien pagó de más, cancela y que pague el monto correcto.
3. Espera a que un cheque se compense de verdad: «disponible» no siempre significa que ya se cobró.
4. Ante cambios de cuenta de un proveedor, llama al número que ya tenías.
5. Desconfía de la prisa, las compras grandes de desconocidos y los envíos a otra dirección.



#### Un caso en un minuto

Javier no depositó el cheque de $2,500. Le pidió al cliente un pago por el monto exacto y el cliente desapareció. Su banco le confirmó que era un fraude conocido.

> **Idea clave:** nunca regreses dinero de un pago de más; prisa, excedentes y cambios de cuenta son señales de fraude.



#### Comprueba lo que entendiste

1. ¿Qué haces si alguien te paga de más y pide la diferencia?
*Respuesta:* No regresas nada; pides el pago por el monto correcto.

2. ¿«Disponible» en tu cuenta significa que el cheque es bueno?
*Respuesta:* No siempre: el banco puede cobrarte si rebota días después.


#### Para recordar

- Nunca regreses excedentes.
- Espera a que el cheque se compense.
- Cambios de cuenta: llama tú.



### Profundiza (5 minutos más)

#### Contracargos

Si cobras con tarjeta y el titular desconoce la compra, su banco puede regresarle el dinero y tu procesador te lo descuenta. Guarda pruebas de entrega y evita envíos grandes a desconocidos con pagos a distancia.



#### Si ya te pasó

Guarda capturas, mensajes y números. Avisa a tu banco o procesador de pagos. Reporta en ReportFraud.ftc.gov y, si hubo pérdidas por internet, en el IC3 del FBI (ic3.gov). Avisa a otros negocios en la comunidad, sin datos personales.

> **Antes de actuar, verifica:** cualquier cambio de datos de pago de un proveedor llamando al número que ya tenías, nunca con el número o enlace que venga en el mismo mensaje.



#### Casos


**Caso 1. El cheque de Javier**

Un cliente manda a Javier un cheque de $2,500 por un trabajo de $1,500 y pide $1,000 de vuelta.
- *¿Qué hace?* No lo deposita ni regresa nada; pide un pago por el monto exacto.


**Caso 2. El pedido de Daniela**

Un desconocido pide a Daniela 40 collares con envío urgente a otro estado y paga con link.
- *¿Qué hace?* Desconfía, verifica y no envía sin confirmar.


**Caso 3. El proveedor de Don Ramón**

Un correo «de su proveedor de carne» pide pagar la factura a una cuenta nueva.
- *¿Qué hace?* Llama al número del proveedor que ya tenía antes de pagar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Regresar excedentes | Pierdes dinero | Nunca |
| Confiar en «disponible» | Cheque rebota | Espera |
| Envíos urgentes a desconocidos | Contracargo | Verifica |
| Pagar a cuentas nuevas | Proveedor falso | Llama tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Daniela y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te pagan de más con un cheque y piden la diferencia. ¿Qué haces? a) Regresas la diferencia en cuanto el cheque aparece disponible · b) No regresas nada y pides el monto exacto · c) Regresas la mitad
2. Tu proveedor te escribe que cambió de cuenta. ¿Qué haces? a) Pagas a la nueva cuenta · b) Respondes al mismo correo para confirmar · c) Llamas al número que ya tenías
3. ¿Cuál es una señal de fraude al vender? a) Prisa, compra grande y envío a otra dirección · b) Un cliente que pregunta por tallas, colores y tiempos de envío · c) Un pago disponible por el monto exacto
**Respuestas:** 1-b: es el fraude del cheque. 2-c: confirma por otro medio. 3-a: la prisa es un gancho.



#### Ponlo en práctica

En un año, tres fraudes te costaron $80, $150 y $1,000. ¿Cuánto habrías evitado con tu protocolo?
**Respuesta:** $1,230.



#### A tu plan

Escribe tu protocolo contra fraudes en una tarjeta y pégala donde cobras.



### Para saber más

- **Reporta un fraude** (FTC · español): https://reportefraude.ftc.gov — **Qué buscar:** «reportar».
- **Delitos por internet** (FBI IC3 · inglés): https://www.ic3.gov — **Qué buscar:** «file a complaint».

### Palabras clave

- *Fraude del cheque de más:* engaño en el que te pagan de más con un cheque falso y te piden regresar la diferencia.
- *Suplantación de proveedor:* fraude en el que alguien se hace pasar por tu proveedor para que pagues a otra cuenta.

### Fuentes

FTC · FBI IC3, consultados el 29 de septiembre de 2026.

---


# Parte 6. Módulo 5. Formalízate e impuestos sin miedo

## M5 U01. ¿Dueño único, LLC u otra forma?

**Lo que lograrás:** Conocer las formas más comunes de organizar un negocio pequeño, qué protegen y cuánto cuestan, para decidir con información.

**Para empezar:** A Javier le dijeron que «tiene que abrir una LLC» para trabajar con contratistas. Un sitio en internet le cobra $299 por hacerlo. No sabe si la necesita. En esta lección verás las opciones.

### Lo esencial (5 minutos)

#### Las formas más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Dueño único (sole proprietor) | Empiezas al vender; sin trámite de empresa. | Tú respondes con tus bienes. |
| LLC | Empresa registrada en tu estado. | Separa tus bienes personales de las deudas del negocio, si la manejas bien. |
| Sociedad (partnership) | Dos o más dueños. | Acuerdo por escrito. |
| Corporación | Más trámites y reglas. | Para negocios más grandes. |

#### La pregunta clave

Una LLC puede proteger tu casa y tus ahorros si el negocio tiene deudas o demandas, pero cuesta dinero cada año y exige mantener todo separado. Para muchos negocios que empiezan, ser dueño único con buen seguro es suficiente al inicio.

> **Dato vigente:** en California, una LLC paga un impuesto mínimo anual de $800 al Franchise Tax Board, aunque no tenga ingresos, hasta que se disuelve formalmente; también presenta una declaración de información cada dos años ante el Secretary of State. Consultado el 29 de septiembre de 2026 a través del Franchise Tax Board y el Secretary of State de California.



#### Un caso en un minuto

Javier hizo cuentas: la LLC le costaría al menos $800 al año en California. Decidió empezar como dueño único con un seguro de responsabilidad civil (M7 U02) y revisar la LLC cuando crezca. Si la abre, lo hará en el sitio oficial del estado, sin pagar $299 a un intermediario.

> **Idea clave:** la LLC protege, pero cuesta; compara con tu riesgo y tu seguro, y haz los trámites en los sitios oficiales.



#### Comprueba lo que entendiste

1. ¿Qué protege una LLC?
*Respuesta:* Tus bienes personales frente a deudas o demandas del negocio, si la manejas bien.

2. ¿Cuánto cuesta una LLC en California como mínimo al año?
*Respuesta:* $800 de impuesto mínimo anual.


#### Para recordar

- Dueño único: sencillo, sin separación.
- LLC: protege, pero cuesta.
- Trámites en sitios oficiales.



### Profundiza (5 minutos más)

#### Nombre comercial (DBA)

Si como dueño único usas un nombre distinto al tuyo («Tamales Lupita»), en California registras un nombre comercial ficticio (Fictitious Business Name o DBA) en tu condado. No es una empresa: solo registra el nombre.



#### Para que la LLC te proteja

Usa una cuenta bancaria solo de la LLC, firma contratos a nombre de la LLC y no mezcles dinero. Si mezclas, un juez puede no respetar la separación.



#### Cuidado con los intermediarios

Muchos sitios cobran por abrir una LLC o sacar un EIN, trámites que puedes hacer tú en los sitios oficiales. También llegan cartas que imitan al gobierno cobrando por «certificados» o «reportes anuales». Revisa siempre el remitente.

> **Antes de actuar, verifica:** las reglas y costos de tu estado en el sitio del Secretary of State; si tienes dudas, consulta a un contador o a un centro gratuito de la SBA (SBDC).



#### Casos


**Caso 1. La LLC de Javier**

Un sitio le cobra a Javier $299 por abrir una LLC «obligatoria».
- *¿Qué hace?* Compara costos y riesgos, y si la abre, lo hace en el sitio oficial del estado.


**Caso 2. El nombre de Lupita**

Lupita vende como «Tamales Lupita» y es dueña única.
- *¿Qué hace?* Registra su nombre comercial ficticio en su condado.


**Caso 3. La cuenta de la LLC de Daniela**

Daniela tiene una LLC, pero cobra en su cuenta personal.
- *¿Qué hace?* Abre una cuenta solo de la LLC y deja de mezclar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Abrir LLC sin calcular | $800 cada año | Compara |
| Pagar intermediarios | Gasto innecesario | Sitio oficial |
| Mezclar en la LLC | Pierdes protección | Cuenta aparte |
| Olvidar el DBA | Problemas con bancos | Registra tu nombre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué forma de negocio empieza sin trámite de empresa? a) Dueño único · b) LLC · c) Corporación
2. Tu LLC en California no tuvo ventas este año. ¿Paga el impuesto mínimo? a) No, si no vendió · b) Solo si ganó más de $10,000 · c) Sí, $800 mientras exista
3. ¿Qué hace que una LLC pierda protección? a) Tener seguro · b) Mezclar el dinero de la LLC con el tuyo · c) Tener una cuenta propia de la LLC
**Respuestas:** 1-a: empiezas al vender. 2-c: aunque no venda. 3-b: la separación se rompe.



#### Ponlo en práctica

Mantienes una LLC en California durante 3 años. ¿Cuánto pagas como mínimo en impuesto anual?
**Respuesta:** $800 por 3: $2,400.



#### A tu plan

Anota qué forma tiene hoy tu negocio y qué riesgo te preocupa; revisa las reglas de tu estado.



### Para saber más

- **Elige una estructura** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «estructura empresarial».
- **LLC en California** (Secretary of State · inglés): https://bizfileonline.sos.ca.gov — **Qué buscar:** «LLC».

### Palabras clave

- *LLC:* compañía de responsabilidad limitada: empresa registrada en un estado que separa tus bienes personales de las deudas del negocio.
- *Dueño único (sole proprietor):* persona que tiene un negocio a su nombre, sin crear una empresa aparte.
- *DBA:* nombre comercial ficticio con el que operas.

### Fuentes

SBA · Franchise Tax Board · California Secretary of State, consultados el 29 de septiembre de 2026.

---

## M5 U02. Números y permisos: EIN, ITIN y licencias

**Lo que lograrás:** Saber qué número fiscal usar, cómo tramitar un EIN gratis y qué licencias y permisos puede necesitar tu negocio.

**Para empezar:** Lupita quiere vender tamales en un mercado y le piden «licencia, permiso de salud y seller's permit». No sabe por dónde empezar ni si puede con su ITIN. En esta lección verás los números y permisos más comunes.

### Lo esencial (5 minutos)

#### Tus números fiscales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| SSN o ITIN | Tu número personal para impuestos. | El ITIN sirve para declarar si no tienes SSN. |
| EIN | Número del negocio ante el IRS. | Gratis en irs.gov. |
| Seller's permit (California) | Para vender productos con sales tax. | Del CDTFA, sin costo. |
| Sitios que cobran por el EIN | El trámite es gratis. | No pagues. |

#### El EIN

El EIN identifica a tu negocio. Lo necesitas si tienes empleados o una LLC con ciertas características, y es útil para abrir cuentas y dar a clientes en lugar de tu SSN. Se tramita gratis en el sitio del IRS; quien lo solicita debe tener SSN o ITIN.



#### Permisos que puedes necesitar

1. **Licencia de negocio** de tu ciudad o condado.
2. **Seller's permit** del CDTFA si vendes productos (M5 U05).
3. **Permiso de salud** del condado si vendes comida (por ejemplo, operación de comida casera o Cottage Food, o permiso para food truck).
4. **Licencia profesional** si tu oficio la pide (por ejemplo, la CSLB para construcción).

> **Dato vigente:** en California, los trabajos de construcción o reparación de más de $1,000 en total (mano de obra y materiales), o que requieren permiso, necesitan licencia de la Contractors State License Board (CSLB). Consultado el 29 de septiembre de 2026 a través de la CSLB (AB 2622, vigente desde el 1 de enero de 2025).



#### Un caso en un minuto

Lupita sacó su EIN gratis en irs.gov con su ITIN, pidió su seller's permit al CDTFA sin costo y se registró como operación de comida casera en el departamento de salud de su condado. Ahora puede vender en el mercado.

> **Idea clave:** el EIN y el seller's permit son gratis en los sitios oficiales; revisa en tu ciudad y tu condado qué licencias pide tu giro.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta el EIN?
*Respuesta:* Nada: es gratis en irs.gov.

2. ¿Qué permiso necesitas en California para vender productos con impuesto sobre ventas?
*Respuesta:* El seller's permit del CDTFA.


#### Para recordar

- EIN gratis en irs.gov.
- Seller's permit sin costo.
- Licencias según ciudad y giro.



### Profundiza (5 minutos más)

#### El ITIN

El ITIN es un número del IRS para quien debe declarar impuestos y no puede tener SSN. Con él puedes declarar los ingresos de tu negocio y solicitar un EIN. Se tramita con el formulario W-7, directamente o con un Agente Tramitador Certificado (CAA). Declarar tus ingresos crea un historial que puede servirte para crédito y otros trámites.



#### Tu situación migratoria

Este curso no da asesoría migratoria. Si tienes dudas sobre cómo tu situación afecta tu negocio, consulta a un abogado de inmigración o a una organización acreditada por el Departamento de Justicia. Desconfía de «notarios» que ofrecen trámites migratorios.



#### Busca lo que pide tu ciudad

CalGold (calgold.ca.gov) te muestra los permisos que suelen pedirse en California según tu ciudad y tu giro. En otros estados, busca la oficina de pequeños negocios de tu estado o tu SBDC local.



#### Casos


**Caso 1. El EIN de Lupita**

Un sitio cobra a Lupita $150 por tramitar su EIN.
- *¿Qué hace?* Lo tramita gratis en irs.gov con su ITIN.


**Caso 2. El trabajo grande de Javier**

A Javier le ofrecen remodelar un baño por $4,000.
- *¿Qué revisa?* Que en California necesita licencia de la CSLB para trabajos de más de $1,000.


**Caso 3. El notario de Don Ramón**

Un «notario» ofrece a Don Ramón arreglar sus papeles migratorios y sus permisos por $2,000.
- *¿Qué hace?* No le paga y busca un abogado o una organización acreditada.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por el EIN | Gasto innecesario | irs.gov |
| Vender sin permisos | Multas o cierre | Revisa en tu ciudad |
| Trabajos grandes sin licencia | Multas y sin cobro | Revisa la CSLB |
| Confiar en «notarios» | Fraude | Abogado o organización acreditada |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde sacas tu EIN? a) En un sitio privado que cobra una tarifa · b) Gratis en irs.gov · c) En tu banco
2. ¿Para qué sirve el ITIN? a) Para declarar impuestos si no puedes tener SSN · b) Para trabajar como empleado · c) Para votar
3. En California, ¿cuándo necesitas licencia de la CSLB? a) Nunca para trabajos pequeños de pintura o reparación · b) Solo si tienes empleados de tiempo completo · c) En trabajos de más de $1,000 o que requieren permiso
**Respuestas:** 1-b: es gratuito. 2-a: número fiscal del IRS. 3-c: regla vigente desde 2025.



#### Ponlo en práctica

Un sitio te cobra $150 por el EIN y $100 por el seller's permit. ¿Cuánto te ahorras haciéndolo tú?
**Respuesta:** $250.



#### A tu plan

Busca en CalGold (o la oficina de tu estado) qué licencias pide tu giro en tu ciudad.



### Para saber más

- **Solicita un EIN** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «número de identificación del empleador».
- **ITIN** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «ITIN formulario W-7».
- **Permisos en California** (CalGold · inglés): https://www.calgold.ca.gov — **Qué buscar:** tu ciudad y tu giro.

### Palabras clave

- *EIN:* número de identificación del empleador: número del negocio ante el IRS, gratuito.
- *ITIN:* número de identificación personal del contribuyente, para quien no puede tener SSN.
- *Seller's permit:* permiso de California para vender productos y cobrar impuesto sobre ventas.

### Fuentes

IRS · CDTFA · CSLB · CalGold, consultados el 29 de septiembre de 2026.

---

## M5 U03. Tus impuestos federales como dueño

**Lo que lograrás:** Entender los dos impuestos federales que paga un dueño único, qué gastos se deducen y cuánto apartar.

**Para empezar:** Daniela ganó $14,000 limpios en su primer año vendiendo joyería. En abril descubrió que debía más de $2,000 al IRS y no había apartado nada. En esta lección verás por qué y cómo prepararte.

### Lo esencial (5 minutos)

#### Dos impuestos sobre tu ganancia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Impuesto sobre el trabajo por cuenta propia | Seguro Social y Medicare. | 15.3% de casi toda tu ganancia. |
| Impuesto sobre la renta | Según tu ingreso total y tu familia. | Puede ser 0% o más. |
| Deducciones del negocio | Gastos ordinarios y necesarios. | Bajan tu ganancia. |
| Deducción de 20% (QBI) | Sobre la ganancia del negocio, con límites. | Baja tu impuesto sobre la renta. |

> **Dato vigente:** el impuesto sobre el trabajo por cuenta propia es de 15.3% (12.4% Seguro Social y 2.9% Medicare) sobre el 92.35% de tu ganancia neta; se paga si ganas $400 o más. La parte de Seguro Social se aplica hasta $184,500 en 2026. La deducción de 20% por ingreso calificado de negocio (QBI) quedó permanente desde 2026. Consultado el 29 de septiembre de 2026 a través del IRS y la ley One Big Beautiful Bill Act.

#### El impuesto por cuenta propia de Daniela

- Ganancia neta del año: **$14,000**
- Base del impuesto: **92.35%**
- Tasa: **15.3%**
- Impuesto por cuenta propia (aprox.): **$1,978**
Además, según su ingreso total, puede deber impuesto sobre la renta.


#### Un caso en un minuto

Daniela no sabía que, como dueña, paga el Seguro Social y el Medicare completos. Este año aparta 25% de cada ganancia en una cuenta aparte y lleva sus recibos para deducir material, envíos y comisiones.

> **Idea clave:** como dueño pagas 15.3% de Seguro Social y Medicare, más impuesto sobre la renta; aparta 25% a 30% de tu ganancia y deduce tus gastos con recibos.



#### Comprueba lo que entendiste

1. ¿Qué dos impuestos federales paga un dueño único sobre su ganancia?
*Respuesta:* El impuesto sobre el trabajo por cuenta propia y el impuesto sobre la renta.

2. ¿Desde qué ganancia pagas el impuesto por cuenta propia?
*Respuesta:* Desde $400 de ganancia neta al año.


#### Para recordar

- 15.3% por cuenta propia.
- Más impuesto sobre la renta.
- Deducciones con recibos.



### Profundiza (5 minutos más)

#### Gastos que suelen deducirse

| Gasto | Qué necesitas |
|---|---|
| Material, ingredientes, mercancía | Recibos |
| Comisiones de apps y tarjetas | Estados de cuenta |
| Millas del negocio (tarifa estándar) | Registro de viajes |
| Parte del teléfono e internet | Cálculo del uso del negocio |
| Oficina en casa (espacio usado solo para el negocio) | Medidas y reglas del IRS |
| Seguro del negocio, licencias, permisos | Recibos |



#### El Schedule C

Como dueño único, reportas ventas y gastos en el Schedule C de tu declaración (Formulario 1040) y calculas el impuesto por cuenta propia en el Schedule SE. La mitad del impuesto por cuenta propia se resta de tu ingreso.



#### Ayuda gratuita o de bajo costo

Los programas VITA ayudan gratis a personas con ingresos moderados, aunque no todos atienden negocios con gastos complejos. Si tu negocio crece, un contador o un preparador con PTIN te ahorra errores. Tu estado (en California, el Franchise Tax Board) también cobra impuesto sobre la renta.

> **Antes de actuar, verifica:** tu situación con un preparador de impuestos; las reglas cambian cada año y dependen de tu familia y tus otros ingresos.



#### Casos


**Caso 1. La sorpresa de Daniela**

Daniela debe más de $2,000 al IRS y no apartó nada.
- *¿Qué hace desde hoy?* Aparta 25% de cada ganancia y guarda recibos para deducir.


**Caso 2. Los recibos de Javier**

Javier no guarda los recibos de pintura porque «el IRS no los pide».
- *¿Qué hace?* Los guarda: sin recibos no puede demostrar sus deducciones.


**Caso 3. La ganancia pequeña de Lupita**

Lupita ganó $3,000 limpios en el año y cree que no tiene que declarar.
- *¿Qué revisa?* Que con $400 o más de ganancia debe declarar y pagar impuesto por cuenta propia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No apartar | Deuda con el IRS | 25% a 30% |
| Sin recibos | Pierdes deducciones | Guárdalos |
| Creer que ganancias chicas no se declaran | Multas | Desde $400 |
| Olvidar el impuesto del estado | Doble sorpresa | Revisa tu estado |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Javier y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es la tasa del impuesto sobre el trabajo por cuenta propia? a) 15.3% · b) 7.65% · c) 2.5%
2. Ganaste $350 limpios en el año con tu negocio. ¿Pagas impuesto por cuenta propia? a) Sí, siempre, aunque ganes poco · b) Sí, si vendiste por apps · c) No, porque es menos de $400
3. ¿Qué necesitas para deducir un gasto? a) Recordarlo · b) Que sea del negocio y tener prueba · c) Que sea mayor de $600
**Respuestas:** 1-a: Seguro Social y Medicare. 2-c: el mínimo es $400. 3-b: ordinario, necesario y con prueba.



#### Ponlo en práctica

Tu ganancia neta es $20,000. ¿Cuánto es aproximadamente tu impuesto por cuenta propia?
**Respuesta:** $20,000 por 92.35% por 15.3%: unos $2,826.



#### A tu plan

Abre una cuenta para impuestos y define qué porcentaje de cada ganancia apartarás.



### Para saber más

- **Impuesto sobre el trabajo por cuenta propia** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «trabajo por cuenta propia».
- **Ayuda gratuita VITA** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «VITA».

### Palabras clave

- *Impuesto sobre el trabajo por cuenta propia:* Seguro Social y Medicare que paga quien trabaja por su cuenta.
- *Deducción:* gasto que se resta de tus ingresos para calcular impuestos.
- *QBI:* deducción de hasta 20% sobre la ganancia calificada de un negocio.

### Fuentes

IRS · One Big Beautiful Bill Act (2025), consultados el 29 de septiembre de 2026.

---

## M5 U04. Pagos trimestrales y formularios 1099

**Lo que lograrás:** Conocer las fechas de los pagos estimados, los formularios 1099 que puedes recibir o enviar y cómo protegerte de fraudes «del IRS».

**Para empezar:** Javier recibió un formulario 1099 de un contratista y no sabía qué era. Además, le llamaron «del IRS» diciendo que lo arrestarían si no pagaba con tarjetas de regalo. En esta lección verás tu calendario y cómo cuidarte.

### Lo esencial (5 minutos)

#### Pagos estimados

Como nadie te retiene impuestos, el IRS espera que pagues durante el año con pagos estimados si calculas que deberás $1,000 o más. Si no, puedes pagar multas.

> **Dato vigente:** las fechas de pagos estimados para el año fiscal 2026 son el 15 de abril, el 15 de junio y el 15 de septiembre de 2026, y el 15 de enero de 2027. Consultado el 29 de septiembre de 2026 a través del IRS (Formulario 1040-ES).



#### Los formularios 1099

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1099-NEC | Un negocio te pagó por servicios. | Desde $2,000 en pagos de 2026. |
| 1099-K | Una plataforma o procesador reporta tus cobros. | Más de $20,000 y más de 200 cobros. |
| Todo ingreso se declara | Recibas o no un 1099. | Siempre. |
| «Si no me llega 1099, no declaro» | Error común. | No es así. |

> **Dato vigente:** desde los pagos de 2026, el formulario 1099-NEC se envía cuando un negocio te paga $2,000 o más en el año (antes $600). El 1099-K lo envían plataformas y procesadores cuando tus cobros superan $20,000 y 200 transacciones. Todo ingreso se declara aunque no recibas formulario. Consultado el 29 de septiembre de 2026 a través del IRS y la ley One Big Beautiful Bill Act.

#### Un caso en un minuto

Javier entendió que el 1099-NEC solo reporta lo que ya ganó. Ahora paga cada trimestre en IRS Direct Pay con lo que aparta. La llamada «del IRS» era un fraude: el IRS no llama para exigir tarjetas de regalo.

> **Idea clave:** paga tus impuestos cada trimestre y declara todo tu ingreso; el IRS nunca te exige pagar con tarjetas de regalo ni te amenaza con arresto por teléfono.



#### Comprueba lo que entendiste

1. ¿Cuándo debes hacer pagos estimados?
*Respuesta:* Si calculas que deberás $1,000 o más al IRS en el año.

2. ¿Declaras un ingreso si no recibiste 1099?
*Respuesta:* Sí: todo ingreso se declara.


#### Para recordar

- Abril, junio, septiembre y enero.
- Todo ingreso se declara.
- El IRS no pide tarjetas de regalo.



### Profundiza (5 minutos más)

#### Cuánto pagar cada trimestre

Una forma práctica: toma lo que apartaste (25% a 30% de tu ganancia del trimestre) y págalo en IRS Direct Pay o en tu cuenta en línea del IRS. Tu preparador de impuestos puede calcularlo mejor con el formulario 1040-ES. En California, el FTB también pide pagos estimados del impuesto estatal.



#### Fraudes «del IRS»

El IRS normalmente te contacta primero por correo postal. No llama para exigir pagos inmediatos, no pide tarjetas de regalo, criptomonedas ni transferencias a personas, y no amenaza con policía. Si dudas, entra tú a irs.gov o llama al número oficial.



#### Tu PIN de protección de identidad

El IRS ofrece un PIN de protección de identidad (IP PIN) para evitar que alguien presente una declaración con tu SSN o ITIN. Solicítalo en irs.gov.



#### Casos


**Caso 1. El 1099 de Javier**

Javier recibió un 1099-NEC por $6,000 de un contratista.
- *¿Qué hace?* Lo incluye en su declaración junto con el resto de sus ingresos.


**Caso 2. La llamada a Don Ramón**

Una llamada «del IRS» exige a Don Ramón pagar hoy con tarjetas de regalo.
- *¿Qué hace?* Cuelga y revisa su cuenta en irs.gov; es un fraude.


**Caso 3. Las ventas de Daniela**

Daniela vendió $9,000 en una plataforma y no recibió 1099-K.
- *¿Qué hace?* Declara esas ventas: todo ingreso se declara.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No pagar trimestral | Multas | Paga cada trimestre |
| Esperar el 1099 | No declaras ingreso | Declara todo |
| Pagar con tarjetas de regalo | Fraude | Nunca |
| Contestar llamadas «del IRS» | Robo | Entra tú a irs.gov |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Don Ramón y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es una fecha de pago estimado de 2026? a) 15 de junio · b) 31 de diciembre · c) 1 de marzo
2. No recibiste 1099-K por tus ventas en una plataforma. ¿Qué haces? a) No declaras esas ventas · b) Declaras solo si vendiste más de $600 · c) Las declaras igual
3. Te llaman «del IRS» para pagar hoy con tarjetas de regalo. ¿Qué es? a) Un fraude · b) Un cobro urgente real · c) Un nuevo método del IRS para pagos pequeños
**Respuestas:** 1-a: segundo pago estimado. 2-c: todo ingreso se declara. 3-a: el IRS no cobra así.



#### Ponlo en práctica

Tu ganancia del trimestre fue $5,000 y apartas 25%. ¿Cuánto pagas de estimado?
**Respuesta:** $1,250.



#### A tu plan

Anota las cuatro fechas de pagos estimados en tu calendario y solicita tu IP PIN en irs.gov.



### Para saber más

- **Pagos estimados** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «impuesto estimado 1040-ES».
- **Estafas del IRS** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «estafas».

### Palabras clave

- *Pagos estimados:* pagos de impuestos que haces cada trimestre sobre lo que vas ganando.
- *1099-NEC:* formulario que reporta pagos por servicios a trabajadores independientes.
- *1099-K:* formulario que reporta cobros por plataformas y procesadores de pago.
- *IP PIN:* número del IRS que protege tu declaración contra el robo de identidad.

### Fuentes

IRS · One Big Beautiful Bill Act (2025), consultados el 29 de septiembre de 2026.

---

## M5 U05. El impuesto sobre ventas (sales tax)

**Lo que lograrás:** Saber qué ventas llevan impuesto sobre ventas, cómo se cobra y cómo se entrega al estado.

**Para empezar:** Lupita vende comida en un mercado y en fiestas. Alguien le dijo que tiene que cobrar sales tax; otra persona le dijo que la comida no lleva. En esta lección verás cómo funciona, con el ejemplo de California.

### Lo esencial (5 minutos)

#### El impuesto no es tuyo

El sales tax lo cobras a tu cliente y lo entregas al estado. No es parte de tu ganancia: sepáralo desde que cobras. Cada estado tiene sus reglas; algunos no cobran impuesto sobre ventas.

> **Dato vigente:** en California, la tasa estatal base de impuesto sobre ventas es de 7.25%, y muchas ciudades y condados suman tasas locales. Para vender productos sujetos a impuesto se necesita un seller's permit del CDTFA, que no tiene costo. Consultado el 29 de septiembre de 2026 a través del CDTFA.



#### ¿Lleva impuesto? (California, en general)

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Productos: ropa, joyería, artículos | Sí, en general. | Seller's permit. |
| Comida caliente o para comer ahí | Sí, en general. | Reglas especiales. |
| Comida fría para llevar | Muchas veces no. | Revisa tu caso. |
| Muchos servicios (pintura, limpieza) | En general no. | Revisa el material. |

#### El impuesto en una venta de Daniela

- Precio de un collar: **$50**
- Tasa total de su ciudad (ejemplo): **9.25%**
- Impuesto que cobra y entrega al estado: **$4.63**


#### Un caso en un minuto

Lupita consultó al CDTFA: su comida caliente en el mercado lleva impuesto; los tamales fríos para llevar, en general no. Ahora separa lo que cobra de impuesto en su cuenta para impuestos y presenta su declaración cuando el CDTFA le indica.

> **Idea clave:** el sales tax es del estado, no tuyo; averigua qué ventas lo llevan, cóbralo aparte y sepáralo.



#### Comprueba lo que entendiste

1. ¿De quién es el sales tax que cobras?
*Respuesta:* Del estado; tú lo cobras y lo entregas.

2. ¿Qué necesitas en California para vender productos con impuesto?
*Respuesta:* Un seller's permit del CDTFA.


#### Para recordar

- Es del estado.
- Depende del producto y del estado.
- Sepáralo al cobrar.



### Profundiza (5 minutos más)

#### Si vendes en plataformas

En la mayoría de los estados, las plataformas grandes de comercio en línea cobran y entregan el sales tax por ti en las ventas que pasan por ellas (se les llama «facilitadores de mercado»). Tus ventas directas por tu página o redes siguen siendo tu responsabilidad.



#### Declaraciones de sales tax

El CDTFA te asigna una frecuencia (anual, trimestral o mensual) según cuánto vendes. Presenta aunque no hayas vendido nada en el periodo, si así te lo indican.



#### Ferias y eventos

Si vendes en ferias o eventos temporales, puedes necesitar un permiso temporal o reportar las ventas del lugar del evento. Pregunta al organizador y al CDTFA.

> **Antes de actuar, verifica:** qué productos llevan impuesto y la tasa de tu ciudad en el sitio del CDTFA (o de tu estado); las reglas de comida son especiales.



#### Casos


**Caso 1. La comida de Lupita**

Lupita no sabe si su comida lleva impuesto.
- *¿Qué hace?* Consulta al CDTFA qué ventas llevan impuesto y lo separa al cobrar.


**Caso 2. La tienda en línea de Daniela**

Daniela vende en una plataforma grande y también por su página.
- *¿Qué revisa?* Que la plataforma cobra el impuesto en sus ventas, pero ella debe cobrarlo en su página.


**Caso 3. Los servicios de Javier**

Javier cree que debe cobrar sales tax por pintar.
- *¿Qué revisa?* Que muchos servicios no llevan impuesto y consulta su caso con el CDTFA.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que el impuesto es tuyo | Te lo gastas | Sepáralo |
| Aplicarlo a todo | Precio alto | Revisa tu producto |
| Olvidar las ventas directas | Deuda con el estado | Cóbralo |
| No presentar | Multas | Según tu frecuencia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Daniela y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es la tasa estatal base de sales tax en California? a) 16% · b) 0% · c) 7.25%
2. Vendes $1,000 en productos con una tasa de 9%. ¿Cuánto impuesto cobras? a) $90 · b) $9 · c) $900
3. ¿Qué haces con el sales tax que cobras? a) Lo usas para comprar material · b) Lo separas y lo entregas al estado · c) Lo guardas como reserva del negocio
**Respuestas:** 1-c: más tasas locales. 2-a: 9% de $1,000. 3-b: es del estado.



#### Ponlo en práctica

Vendes $2,400 en el trimestre con una tasa de 9.5%. ¿Cuánto impuesto debes entregar?
**Respuesta:** $228.



#### A tu plan

Revisa si tus ventas llevan sales tax en tu estado y, si aplica, tramita tu permiso.



### Para saber más

- **Seller's permit y tasas** (CDTFA · español e inglés): https://www.cdtfa.ca.gov — **Qué buscar:** «seller's permit» y «tasas».

### Palabras clave

- *Sales tax:* impuesto sobre ventas que cobras a tu cliente y entregas al estado.
- *Facilitador de mercado:* plataforma que cobra y entrega el sales tax por quienes venden en ella.

### Fuentes

CDTFA, consultado el 29 de septiembre de 2026.

---


# Parte 7. Módulo 6. Crédito para tu negocio

## M6 U01. ¿Necesitas crédito?

**Lo que lograrás:** Distinguir el crédito que ayuda a crecer del que solo tapa problemas, y decidir con números si te conviene.

**Para empezar:** A Don Ramón le ofrecen $15,000 para comprar un segundo equipo de cocina y abrir más horas. Se emociona, pero no sabe si el food truck podrá pagarlo. En esta lección verás cómo decidir.

### Lo esencial (5 minutos)

#### Para qué pides

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Para crecer | Equipo o mercancía que genera ventas. | Puede pagarse solo. |
| Para capital de trabajo | Temporadas o pedidos grandes. | Si ya tienes el cliente. |
| Para tapar pérdidas | El negocio no gana. | Agranda el problema. |
| Para gastos de la casa | Con crédito del negocio. | Mezcla. |

#### La pregunta clave

¿Cuánto más ganarás con lo que compras con el crédito? Si la ganancia extra al mes es **mayor** que el pago mensual, el crédito puede pagarse solo. Si no, lo pagarás de tu sueldo o de tu reserva.



#### El equipo de Don Ramón

- Ganancia extra al mes esperada: **$700**
- Pago mensual del préstamo: **$480**
- Lo que le queda: **$220**
Si las ventas extra fueran la mitad, le faltarían $130 cada mes.


#### Un caso en un minuto

Don Ramón hizo cuentas con un escenario prudente: solo la mitad de las ventas esperadas. Le faltarían $130 al mes. Decidió pedir $8,000 para un equipo más pequeño, con un pago de $260.

> **Idea clave:** pide crédito para algo que genere ventas y haz cuentas con un escenario prudente.



#### Comprueba lo que entendiste

1. ¿Cuándo puede pagarse solo un crédito?
*Respuesta:* Cuando la ganancia extra que genera es mayor que el pago mensual.

2. ¿Por qué no pedir crédito para tapar pérdidas?
*Respuesta:* Porque el negocio no gana y la deuda agranda el problema.


#### Para recordar

- Crédito para crecer, no para tapar.
- Ganancia extra mayor que el pago.
- Escenario prudente.



### Profundiza (5 minutos más)

#### Decide con números

| Dato | Escenario esperado | Escenario prudente (mitad) |
|---|---|---|
| Ventas extra al mes | | |
| Ganancia extra al mes | | |
| Pago mensual | | |
| Diferencia | | |



#### Antes de pedir, revisa alternativas

Depósitos de clientes, plazo con proveedores, vender inventario parado o usar parte de la reserva pueden resolver sin crédito. Si el problema es de precio o costos (M2), el crédito no lo arregla.



#### Casos


**Caso 1. El equipo de Don Ramón**

Don Ramón calcula que el préstamo se paga solo, pero con ventas optimistas.
- *¿Qué hace?* Revisa un escenario prudente antes de firmar.


**Caso 2. Las pérdidas de Lupita**

Lupita pierde dinero desde hace tres meses y le ofrecen un préstamo.
- *¿Qué hace?* Primero corrige precio y costos; no usa crédito para tapar pérdidas.


**Caso 3. El contrato de Javier**

Javier tiene un contrato firmado y necesita material para cumplirlo.
- *¿Qué revisa primero?* Si puede pedir depósito al cliente antes de pedir crédito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Crédito para tapar pérdidas | Deuda mayor | Corrige el negocio |
| Cuentas optimistas | No alcanza | Escenario prudente |
| Pedir de más | Pagos altos | Lo necesario |
| No revisar alternativas | Intereses innecesarios | Depósitos y plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Lupita y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. La ganancia extra es $300 al mes y el pago es $400. ¿Qué pasa? a) El crédito se paga solo · b) Te faltan $100 al mes · c) Ganas $100
2. ¿Para qué es más sano un crédito del negocio? a) Para pagar gastos de la casa este mes · b) Para cubrir las pérdidas de los últimos meses · c) Para algo que genere ventas
3. ¿Qué haces antes de pedir crédito para un pedido? a) Revisas si el cliente puede dar depósito · b) Pides el monto máximo · c) Firmas rápido el primer crédito para no perder la oferta del día
**Respuestas:** 1-b: pago mayor que ganancia. 2-c: puede pagarse solo. 3-a: alternativa sin intereses.



#### Ponlo en práctica

Un equipo te dejaría $600 al mes de ganancia extra. En un escenario prudente, la mitad. El pago es $250. ¿Te conviene?
**Respuesta:** Prudente: $300 menos $250: te quedan $50. Conviene, con poco margen.



#### A tu plan

Si piensas pedir crédito, llena la tabla con un escenario esperado y uno prudente.



### Para saber más

- **Préstamos para negocios** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «préstamos».

### Palabras clave

- *Capital de trabajo:* dinero para operar el día a día: mercancía, insumos y pagos.
- *Escenario prudente:* cálculo con ventas menores a las esperadas.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---

## M6 U02. Opciones de crédito y cómo verificarlas

**Lo que lograrás:** Conocer las opciones de crédito para pequeños negocios, incluidas las que aceptan ITIN, y detectar préstamos caros o falsos.

**Para empezar:** Lupita recibió un mensaje: «Préstamo para tu negocio sin revisar crédito. Deposita $200 de cuota de apertura y recibe $5,000 hoy». En esta lección verás las opciones reales y cómo detectar fraudes.

### Lo esencial (5 minutos)

#### Opciones que puedes revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bancos y cooperativas de crédito | Préstamos y líneas de crédito. | Piden historial. |
| CDFI y microprestamistas sin fines de lucro | Préstamos pequeños; algunos aceptan ITIN. | Con asesoría. |
| Micropréstamos de la SBA | A través de intermediarios. | Hasta $50,000. |
| Adelantos de efectivo sobre ventas (MCA) | Cobran diario; muy caros. | Evítalos. |

> **Dato vigente:** el programa de micropréstamos de la SBA ofrece préstamos de hasta $50,000 a través de organizaciones intermediarias sin fines de lucro, que suelen dar también asesoría. Consultado el 29 de septiembre de 2026 a través de la SBA.

#### Verifica antes de pedir

1. Busca el nombre exacto de quien presta y su sitio oficial.
2. En California, verifica su licencia en el DFPI; en otros estados, en el regulador financiero estatal.
3. Pide el costo total por escrito (M6 U03).
4. Nunca pagues por adelantado para «liberar» un préstamo.



#### Un caso en un minuto

Lupita borró el mensaje: pedir una cuota por adelantado es señal de fraude. Buscó un CDFI de su zona que trabaja con ITIN; le ofreció un microcrédito de $3,000 con clases gratuitas de negocio.

> **Idea clave:** compara bancos, cooperativas y CDFI; quien te pide dinero por adelantado para darte un préstamo es un fraude.



#### Comprueba lo que entendiste

1. ¿Qué son los CDFI?
*Respuesta:* Instituciones de desarrollo comunitario que prestan a negocios pequeños, a veces con ITIN.

2. ¿Qué haces si te piden una cuota para liberar un préstamo?
*Respuesta:* No pagas: es fraude.


#### Para recordar

- Bancos, cooperativas, CDFI, SBA.
- Verifica la licencia.
- Nunca pagues por adelantado.



### Profundiza (5 minutos más)

#### Adelantos sobre ventas y préstamos de día de pago

Un adelanto de efectivo sobre ventas (merchant cash advance) te da dinero a cambio de un porcentaje de tus ventas diarias. No se presenta como préstamo ni con APR, y su costo puede ser altísimo. Los préstamos de día de pago (payday) también son muy caros. Evítalos o compáralos con cuidado.



#### Crédito con ITIN

Algunos bancos, cooperativas y CDFI dan cuentas, tarjetas aseguradas y préstamos con ITIN. Declarar tus impuestos y tener una cuenta del negocio ordenada te ayuda a demostrar tus ingresos.



#### Qué te pedirán

Identificación, declaraciones de impuestos, estados de cuenta del negocio, licencias y, a veces, un plan de negocio. Por eso separar tu dinero (M1) y declarar (M5) te abre mejores opciones.

> **Antes de actuar, verifica:** la licencia del prestamista con el regulador de tu estado (en California, el DFPI) y compara el costo total por escrito.



#### Casos


**Caso 1. El mensaje a Lupita**

Un mensaje ofrece a Lupita $5,000 si deposita $200 de cuota de apertura.
- *¿Qué hace?* No deposita y busca opciones verificadas; es fraude.


**Caso 2. El adelanto de Don Ramón**

Una empresa ofrece a Don Ramón $10,000 a cambio de 15% de sus ventas diarias.
- *¿Qué hace?* Calcula el costo total y lo compara con un préstamo de banco, cooperativa o CDFI.


**Caso 3. El préstamo de Daniela**

Daniela tiene ITIN y cree que ningún lugar le prestará.
- *¿Qué hace?* Busca cooperativas y CDFI que trabajen con ITIN.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar para «liberar» | Fraude | Nunca |
| No verificar licencia | Prestamista ilegal | Regulador estatal |
| Aceptar adelantos sobre ventas | Costo altísimo | Compara |
| Creer que con ITIN no hay opciones | Te pierdes crédito sano | Busca CDFI |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Don Ramón y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden una cuota para liberar tu préstamo. ¿Qué es? a) Un trámite normal · b) Una comisión de apertura de ley · c) Una señal de fraude
2. ¿Dónde verificas a un prestamista en California? a) En el DFPI · b) En sus redes sociales · c) En las reseñas de su app
3. ¿Hasta cuánto prestan los microcréditos de la SBA? a) $5,000 · b) $50,000 · c) Sin límite
**Respuestas:** 1-c: nunca pagues por adelantado. 2-a: regulador del estado. 3-b: a través de intermediarios.



#### Ponlo en práctica

Un adelanto te da $10,000 y te cobra $13,500 en 6 meses. ¿Cuánto pagas de más?
**Respuesta:** $3,500 en solo 6 meses.



#### A tu plan

Busca una cooperativa de crédito o un CDFI de tu zona y pregunta qué ofrecen a negocios pequeños.



### Para saber más

- **Microcréditos** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «microcréditos».
- **Verifica una licencia** (DFPI · inglés): https://dfpi.ca.gov — **Qué buscar:** «search licensees».
- **CDFI** (CDFI Fund · inglés): https://www.cdfifund.gov — **Qué buscar:** «CDFI locator».

### Palabras clave

- *CDFI:* institución financiera de desarrollo comunitario que presta a personas y negocios con menos acceso.
- *Adelanto sobre ventas (MCA):* dinero a cambio de un porcentaje de tus ventas futuras, muy caro.
- *Cooperativa de crédito (credit union):* institución financiera sin fines de lucro, propiedad de sus socios.

### Fuentes

SBA · DFPI · CDFI Fund, consultados el 29 de septiembre de 2026.

---

## M6 U03. El costo total: APR, cuotas y garantías

**Lo que lograrás:** Comparar créditos por su costo total, entender el APR y la «tasa de factor», y revisar las garantías.

**Para empezar:** A Don Ramón le ofrecen dos opciones por $10,000: un préstamo de cooperativa a 12 meses con APR de 14%, y un adelanto con «factor de 1.35». Suena parecido, pero no lo es. En esta lección verás cómo compararlos.

### Lo esencial (5 minutos)

#### El APR

El APR resume el costo anual del crédito con intereses y ciertas cuotas. Sirve para comparar créditos: **menor APR, más barato**. Si alguien no te da el APR, pide el total a pagar.



#### Lo que realmente pagas

- Adelanto recibido: **$10,000**
- Tasa de factor: **1.35**
- Total a pagar en 6 meses: **$13,500**
El préstamo de la cooperativa, con 14% de APR a 12 meses, cuesta unos $775 de intereses en total.


#### Compara con estas preguntas

1. ¿Cuál es el APR?
2. ¿Cuánto pagaré en total?
3. ¿Qué cuotas hay: apertura, pago tardío, pago anticipado?
4. ¿Qué garantía piden: garantía personal, equipo, casa?
5. ¿Puedo pagar antes sin penalización?



#### Un caso en un minuto

Don Ramón pidió todo por escrito. El adelanto le costaba $3,500 en seis meses; la cooperativa, unos $775 en un año. Eligió la cooperativa aunque tardó dos semanas más en aprobarle.

> **Idea clave:** compara el APR y el total a pagar, no el pago diario ni lo rápido que te dan el dinero.



#### Comprueba lo que entendiste

1. ¿Qué es el APR?
*Respuesta:* El costo anual del crédito con intereses y ciertas cuotas.

2. ¿Qué haces si no te dan el APR?
*Respuesta:* Pides el total a pagar por escrito y lo comparas.


#### Para recordar

- Menor APR, más barato.
- Total a pagar.
- Pregunta cuotas y garantías.



### Profundiza (5 minutos más)

#### Compara dos créditos

| Dato | Crédito A | Crédito B |
|---|---|---|
| Monto | | |
| Plazo | | |
| Pago (mensual, semanal o diario) | | |
| Total a pagar | | |
| APR | | |
| Cuotas | | |
| Garantía | | |



#### Garantías

Muchos préstamos a negocios piden tu garantía personal (personal guarantee): si el negocio no paga, pagas tú, aunque tengas una LLC. Algunos piden un bien como garantía. No pongas tu casa en garantía para un negocio que no ha probado que gana.



#### Divulgación en California

California exige que muchos prestamistas comerciales den por escrito el costo estimado, incluido un APR, en préstamos y adelantos de hasta $500,000. Pídelo.



#### Casos


**Caso 1. Las dos ofertas de Don Ramón**

Don Ramón compara un préstamo con APR de 14% contra un adelanto con factor de 1.35.
- *¿Qué hace?* Pide por escrito el total a pagar de cada uno y los compara.


**Caso 2. La garantía de Javier**

Un préstamo para una camioneta pide a Javier poner su casa en garantía.
- *¿Qué hace?* Busca otra opción o un monto menor sin arriesgar su casa.


**Caso 3. El pago extra de Daniela**

Daniela tuvo un buen mes y quiere adelantar pagos de su préstamo.
- *¿Qué pregunta?* Si hay penalización y que el pago se aplique al capital.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comparar el pago diario | Engaño | APR y total |
| Elegir lo más rápido | Costo alto | Compara |
| Casa en garantía | Riesgo de perderla | Evítalo |
| No leer la garantía personal | Pagas tú | Lee antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Javier y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Dos créditos de igual monto y plazo: APR 12% y APR 30%. ¿Cuál es más barato? a) El de 12% · b) El de 30% · c) Cuestan igual
2. Un adelanto de $5,000 con factor de 1.4. ¿Cuánto pagas en total? a) $5,400 · b) $1,400 · c) $7,000
3. ¿Qué es una garantía personal? a) Que el préstamo no se cobra si el negocio cierra · b) Que pagas tú si el negocio no paga · c) Un seguro gratuito
**Respuestas:** 1-a: menor APR. 2-c: $5,000 por 1.4. 3-b: respondes con tus bienes.



#### Ponlo en práctica

Te prestan $6,000 y pagarás $290 durante 24 meses. ¿Cuánto pagas de más?
**Respuesta:** $6,960 menos $6,000: $960.



#### A tu plan

Si tienes una oferta de crédito, pide por escrito el APR y el total a pagar y llena la tabla.



### Para saber más

- **Préstamos a pequeñas empresas** (CFPB · inglés): https://www.consumerfinance.gov — **Qué buscar:** «small business lending».
- **Divulgación de financiamiento comercial** (DFPI · inglés): https://dfpi.ca.gov — **Qué buscar:** «commercial financing disclosures».

### Palabras clave

- *APR:* tasa de porcentaje anual: costo del crédito al año, con intereses y ciertas cuotas.
- *Tasa de factor:* número por el que se multiplica el monto de un adelanto para saber el total a pagar.
- *Garantía personal:* compromiso de pagar tú si el negocio no paga.

### Fuentes

CFPB · DFPI, consultados el 29 de septiembre de 2026.

---

## M6 U04. No mezcles deudas y cuida con ser cofirmante

**Lo que lograrás:** Evitar usar deudas personales para el negocio, prestar a la familia con reglas y entender el riesgo de ser cofirmante.

**Para empezar:** Daniela paga su material con su tarjeta de crédito personal y ya debe $4,500. Y a Don Ramón su sobrino le pide que sea cofirmante de un préstamo de auto. En esta lección verás los riesgos.

### Lo esencial (5 minutos)

#### Mezclas peligrosas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tarjeta personal para el negocio | Intereses altos si no pagas el total. | Deuda escondida. |
| Préstamos a familia | Sin reglas, no regresan. | Dinero del negocio. |
| Ser cofirmante | Si no paga, pagas tú. | Afecta tu crédito. |
| Deudas separadas y registradas | Sabes cuánto debe el negocio. | Control. |

#### La tarjeta personal

Usar tu tarjeta para el negocio puede servir si pagas el total cada mes (sin intereses) y guardas los recibos. Si solo pagas el mínimo, la deuda crece con intereses de más de 20% al año y se mezcla con tus gastos.



#### Ser cofirmante

Un cofirmante responde por la deuda si el deudor no paga. Aparece en tu reporte de crédito. **Solo firma una deuda que podrías pagar tú sin poner en riesgo tu negocio.**



#### Un caso en un minuto

Don Ramón calculó el pago del auto del sobrino: $520 al mes. No podría pagarlo si el sobrino fallara. Le dijo que no con cariño y le ayudó a buscar un auto más barato que pudiera pagar solo.

> **Idea clave:** registra las deudas del negocio aparte, presta con reglas y solo sé cofirmante si podrías pagar tú.



#### Comprueba lo que entendiste

1. ¿Cuándo sirve la tarjeta personal para el negocio?
*Respuesta:* Solo si pagas el total cada mes y guardas los recibos.

2. ¿Qué arriesgas al ser cofirmante?
*Respuesta:* Pagar tú la deuda y dañar tu crédito.


#### Para recordar

- Tarjeta: total cada mes.
- Préstamos a familia con reglas.
- Cofirmante: solo si podrías pagar.



### Profundiza (5 minutos más)

#### Si ya mezclaste

Haz una lista de las deudas que usaste para el negocio. Págalas primero con el dinero del negocio, empezando por la de interés más alto. No sigas comprando material con la tarjeta mientras la pagas.



#### Crédito del negocio

Una tarjeta a nombre del negocio, usada con cuidado y pagada completa, ayuda a separar gastos. Revisa tu reporte de crédito personal gratis cada año en AnnualCreditReport.com.



#### Cómo decir que no

«Te quiero ayudar, pero no puedo arriesgar mi negocio. Busquemos otra forma.» Decir que no protege a tu familia y a tu negocio.



#### Casos


**Caso 1. La tarjeta de Daniela**

Daniela debe $4,500 en su tarjeta personal por material.
- *¿Qué hace?* Deja de usarla para el negocio y la paga con el dinero del negocio.


**Caso 2. El cofirmante**

El sobrino de Don Ramón le pide ser cofirmante de un auto de $520 al mes.
- *¿Qué hace?* No acepta porque no podría pagarlo y le ayuda a buscar otra opción.


**Caso 3. El préstamo a la comadre**

La comadre de Lupita le pide $400 del dinero del negocio.
- *¿Qué hace?* Presta solo de su sueldo o su ahorro, por escrito y con fechas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar el mínimo | Deuda crece | Paga el total |
| Firmar sin calcular | Pagas tú | Solo si podrías |
| Prestar del negocio | Sin efectivo | De tu sueldo, por escrito |
| No revisar tu crédito | Errores sin corregir | Reporte gratis |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Don Ramón y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo es aceptable usar tu tarjeta personal para el negocio? a) Si pagas el mínimo cada mes · b) Siempre que el negocio lo necesite, aunque no pagues el total · c) Si pagas el total cada mes y guardas recibos
2. Si eres cofirmante y el deudor no paga, ¿qué pasa? a) Te pueden cobrar a ti · b) Nada, solo firmaste · c) El banco perdona la deuda
3. ¿De dónde prestas a un familiar? a) De la cuenta del negocio · b) De tu sueldo o tu ahorro, por escrito · c) Con la tarjeta del negocio
**Respuestas:** 1-c: sin intereses. 2-a: respondes por la deuda. 3-b: sin afectar el negocio.



#### Ponlo en práctica

Debes $4,500 con 24% de interés anual. ¿Cuánto interés te cobran el primer mes, aproximadamente?
**Respuesta:** 24% entre 12 es 2% al mes: unos $90.



#### A tu plan

Haz una lista de las deudas que usaste para el negocio y un plan para pagarlas.



### Para saber más

- **Cofirmar un préstamo** (FTC · español): https://consumidor.ftc.gov — **Qué buscar:** «cofirmar un préstamo».
- **Reporte de crédito gratis** (AnnualCreditReport.com · inglés): https://www.annualcreditreport.com.

### Palabras clave

- *Cofirmante:* persona que firma un préstamo y se obliga a pagarlo si el deudor no paga.
- *Pago mínimo:* lo menos que puedes pagar de tu tarjeta; la deuda casi no baja.

### Fuentes

FTC · CFPB, consultados el 29 de septiembre de 2026.

---


# Parte 8. Módulo 7. Protege tu negocio

## M7 U01. Tu salud si trabajas por tu cuenta

**Lo que lograrás:** Conocer las opciones de seguro médico para quien trabaja por su cuenta y cómo proteger tu ingreso si te enfermas.

**Para empezar:** Javier se lastimó la espalda cargando una escalera y estuvo dos semanas sin trabajar. No tenía seguro médico y pagó la consulta de urgencias de su bolsa. En esta lección verás tus opciones.

### Lo esencial (5 minutos)

#### Opciones de seguro médico

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Mercado de seguros (en California, Covered California) | Planes para quien no tiene seguro del trabajo. | Puede haber ayuda para pagar la prima según tu ingreso. |
| Medi-Cal (Medicaid en California) | Para ingresos bajos. | Requisitos según ingreso y situación. |
| Clínicas comunitarias | Cobran según ingreso. | Atención básica. |
| Sin seguro | Una emergencia puede costar miles. | Riesgo alto. |

#### Cuándo inscribirte

El mercado de seguros tiene un periodo de inscripción abierta cada año (en otoño e invierno). Fuera de ese periodo, solo puedes inscribirte si tienes un cambio de vida, como perder otro seguro o cambiar de domicilio. En California, Covered California y Medi-Cal tienen ayuda en español.



#### Un caso en un minuto

Javier revisó Covered California con su ingreso estimado del negocio. Calificó para ayuda con la prima y eligió un plan con consultas a bajo costo. También aparta una pequeña reserva para su deducible.

> **Idea clave:** si trabajas por tu cuenta, revisa el mercado de seguros, Medi-Cal y las clínicas comunitarias; una emergencia sin seguro puede costarte tu negocio.



#### Comprueba lo que entendiste

1. ¿Cuándo te inscribes al mercado de seguros?
*Respuesta:* En la inscripción abierta de cada año o si tienes un cambio de vida.

2. ¿Qué es Medi-Cal?
*Respuesta:* El programa de salud de California para personas de bajos ingresos.


#### Para recordar

- Mercado de seguros cada año.
- Medi-Cal según ingreso.
- Clínicas comunitarias.



### Profundiza (5 minutos más)

#### Seguro médico y tus impuestos

Si trabajas por tu cuenta y pagas tu seguro médico, en muchos casos puedes deducir las primas en tu declaración. Si recibes ayuda para la prima, al declarar se ajusta según tu ingreso real: reporta cambios a tiempo.



#### Si no puedes trabajar

Como dueño no tienes pago por incapacidad del empleador. Tu reserva (M3 U03) y, si puedes pagarlo, un seguro de incapacidad o de accidentes protegen tu ingreso. En California, los dueños únicos pueden inscribirse voluntariamente al seguro estatal de incapacidad (Elective Coverage del EDD); revisa costos y requisitos.



#### Información y situación migratoria

Las reglas de elegibilidad para programas de salud dependen de tu situación. Consulta con un consejero certificado de Covered California o una clínica comunitaria; la información que das para salud tiene protecciones de privacidad.

> **Antes de actuar, verifica:** la elegibilidad y los costos en Covered California (o el mercado de tu estado) y en Medi-Cal; cambian cada año.



#### Casos


**Caso 1. La espalda de Javier**

Javier no tiene seguro médico y trabaja por su cuenta.
- *¿Qué hace?* Revisa el mercado de seguros y Medi-Cal con su ingreso estimado.


**Caso 2. El cambio de Lupita**

Lupita dejó su trabajo de medio tiempo y perdió su seguro del empleador en junio.
- *¿Qué hace?* Revisa si ese cambio le permite inscribirse fuera de la inscripción abierta.


**Caso 3. El ingreso de Daniela**

Daniela recibe ayuda para su prima y sus ventas subieron mucho.
- *¿Qué hace?* Actualiza su ingreso estimado para evitar deber al declarar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin seguro | Deudas médicas | Revisa opciones |
| Esperar a enfermarte | Fuera de inscripción | Inscríbete a tiempo |
| No reportar cambios de ingreso | Deuda al declarar | Actualiza |
| Sin reserva para deducible | Sorpresa | Aparta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Javier, Lupita y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde revisas seguro médico en California si trabajas por tu cuenta? a) En Covered California y Medi-Cal · b) Solo con tu banco · c) En el IRS
2. Perdiste el seguro de tu trabajo a mitad de año. ¿Qué puedes revisar? a) Nada, esperas a noviembre · b) Si ese cambio te permite inscribirte ya · c) Un préstamo para consultas
3. Recibes ayuda para tu prima y tu ingreso sube. ¿Qué haces? a) No haces nada hasta el próximo año · b) Cancelas el seguro · c) Actualizas tu ingreso estimado
**Respuestas:** 1-a: opciones oficiales. 2-b: cambio de vida. 3-c: evita deber al declarar.



#### Ponlo en práctica

Tu prima es $180 al mes y tu deducible $1,500. ¿Cuánto podrías pagar en un año si usas todo el deducible?
**Respuesta:** $2,160 de primas más $1,500: $3,660.



#### A tu plan

Revisa tus opciones de seguro médico y apunta la fecha de la próxima inscripción abierta.



### Para saber más

- **Covered California** (español): https://www.coveredca.com/espanol — **Qué buscar:** «trabajadores por cuenta propia».
- **Medi-Cal** (DHCS · español): https://www.dhcs.ca.gov — **Qué buscar:** «Medi-Cal».
- **Mercado de seguros** (HealthCare.gov · español): https://www.cuidadodesalud.gov.

### Palabras clave

- *Prima:* lo que pagas cada mes por tu seguro.
- *Deducible:* lo que pagas tú antes de que el seguro empiece a pagar.
- *Inscripción abierta:* periodo del año para contratar o cambiar tu seguro médico.

### Fuentes

Covered California · DHCS · HealthCare.gov · EDD, consultados el 29 de septiembre de 2026.

---

## M7 U02. Seguros para tu negocio

**Lo que lograrás:** Identificar los riesgos de tu negocio y conocer los seguros que los cubren y qué preguntar antes de contratar.

**Para empezar:** El food truck de Don Ramón tuvo un pequeño incendio en la freidora. Su seguro de auto personal no lo cubrió porque era un vehículo de negocio. En esta lección verás qué seguros existen para negocios pequeños.

### Lo esencial (5 minutos)

#### Riesgos y seguros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Responsabilidad civil general | Si un cliente se lastima o dañas algo ajeno. | Muchos clientes lo piden. |
| Auto comercial | Vehículos que usas para el negocio. | El personal puede no cubrir. |
| Propiedad y equipo | Incendio, robo, daños. | Local, equipo, inventario. |
| Compensación al trabajador | Obligatorio en California si tienes empleados. | Lesiones en el trabajo. |

#### Antes de contratar, pregunta

1. ¿Qué cubre y qué no (exclusiones)?
2. ¿Cuál es el deducible?
3. ¿Hasta cuánto paga (límite)?
4. ¿Cubre el uso de mi vehículo para el negocio?
5. ¿Cómo se reclama y en cuánto tiempo pagan?



#### Un caso en un minuto

Don Ramón contrató un paquete para food trucks con auto comercial, responsabilidad civil y equipo. Le cuesta $210 al mes. Los organizadores de ferias ahora lo aceptan porque les muestra su certificado de seguro.

> **Idea clave:** asegura lo que no podrías reponer y lo que tus clientes te piden; tu seguro personal casi nunca cubre el negocio.



#### Comprueba lo que entendiste

1. ¿Qué cubre la responsabilidad civil general?
*Respuesta:* Daños que causes a otras personas o a sus bienes.

2. ¿Tu seguro de auto personal cubre el uso del negocio?
*Respuesta:* Muchas veces no; revisa o contrata auto comercial.


#### Para recordar

- Responsabilidad civil.
- Auto comercial.
- Compensación al trabajador si tienes empleados.



### Profundiza (5 minutos más)

#### Tus riesgos

| Riesgo | ¿Podrías pagarlo tú? | ¿Seguro? |
|---|---|---|
| Un cliente se lastima | | |
| Choque con el vehículo del negocio | | |
| Robo o incendio del equipo | | |
| Un empleado se lastima | | |



#### El certificado de seguro

Muchos contratistas, mercados y eventos piden un certificado de seguro (COI) antes de dejarte trabajar. Tenerlo te abre clientes y puede justificar un mejor precio.



#### Verifica la aseguradora

Verifica al agente y a la aseguradora con el Departamento de Seguros de tu estado (en California, el CDI). Pide la póliza completa y guarda recibos de tu equipo.



#### Casos


**Caso 1. El incendio del food truck**

El seguro personal de Don Ramón no cubrió el incendio de su food truck.
- *¿Qué hace?* Contrata un seguro comercial con auto, responsabilidad y equipo.


**Caso 2. El contratista de Javier**

Un contratista pide a Javier su certificado de seguro para darle trabajo.
- *¿Qué hace?* Contrata responsabilidad civil general y pide su certificado.


**Caso 3. El ayudante de Lupita**

Lupita contratará a un ayudante como empleado.
- *¿Qué revisa?* Que en California necesita seguro de compensación al trabajador.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que el seguro personal cubre | Sin pago | Seguro comercial |
| Sin certificado | Pierdes clientes | Tenlo listo |
| Empleados sin compensación | Multas y demandas | Obligatorio |
| No verificar al agente | Fraude | Departamento de Seguros |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Javier y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un cliente se resbala en tu puesto. ¿Qué seguro ayuda? a) Seguro de vida · b) Responsabilidad civil general · c) Seguro de auto personal
2. ¿Qué es el deducible? a) La parte del daño que pagas tú · b) Lo que paga la aseguradora · c) El precio de la póliza
3. Tienes un empleado en California. ¿Qué seguro es obligatorio? a) Seguro de vida para el empleado · b) Seguro de equipo · c) Compensación al trabajador
**Respuestas:** 1-b: daños a terceros. 2-a: tu parte. 3-c: obligatorio con empleados.



#### Ponlo en práctica

Un robo te causa $6,000 de daño y el deducible es $1,000. ¿Cuánto paga la aseguradora?
**Respuesta:** $5,000.



#### A tu plan

Llena tu tabla de riesgos y cotiza al menos dos seguros para lo que no podrías reponer.



### Para saber más

- **Seguros para negocios** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «seguro comercial».
- **Verifica agentes** (California Department of Insurance · español): https://www.insurance.ca.gov — **Qué buscar:** «verificar licencia».

### Palabras clave

- *Responsabilidad civil general:* seguro que paga daños que causas a otras personas o a sus bienes.
- *Compensación al trabajador:* seguro que cubre lesiones de empleados en el trabajo.
- *Certificado de seguro (COI):* documento que prueba que tienes seguro.

### Fuentes

SBA · California Department of Insurance, consultados el 29 de septiembre de 2026.

---

## M7 U03. Fraudes a negocios

**Lo que lograrás:** Reconocer los fraudes que sufren los negocios pequeños y responder con un protocolo.

**Para empezar:** Daniela recibió una carta «oficial» que le cobra $243 por un «certificado de su LLC», con amenaza de multa. A Lupita la llamó alguien «del departamento de salud» para cobrarle una multa por teléfono. En esta lección verás cómo reconocer estos engaños.

### Lo esencial (5 minutos)

#### Fraudes frecuentes a negocios

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cartas que imitan al gobierno | Cobran por certificados o reportes que no necesitas o que cuestan menos. | Revisa el remitente. |
| Autoridad falsa por teléfono | «Salud», «IRS» o «policía» exigen pagos inmediatos. | Cuelga y verifica. |
| Correo falso de proveedor | Cambio de cuenta bancaria. | Llama al número que ya tenías. |
| Avisos falsos de marca | Cobran por «registros» privados. | Solo la USPTO. |

#### Tu protocolo

1. No pagues con prisa: las autoridades reales dan tiempo y avisan por escrito.
2. Revisa el remitente: letra pequeña que dice «no somos una agencia del gobierno».
3. Verifica entrando tú al sitio oficial o llamando al número oficial.
4. Nunca pagues con tarjetas de regalo, cripto o transferencias a personas.
5. Reporta en ReportFraud.ftc.gov y avisa a otros negocios.



#### Un caso en un minuto

Daniela leyó la letra pequeña: «Este no es un documento del gobierno». En el sitio del Secretary of State vio que su declaración de información cuesta $20 y que ya la había presentado. Tiró la carta y avisó en la comunidad.

> **Idea clave:** ninguna autoridad cobra por teléfono ni pide pagos inmediatos con tarjetas de regalo; verifica en el sitio oficial antes de pagar cualquier carta.



#### Comprueba lo que entendiste

1. ¿Cómo reconoces una carta que imita al gobierno?
*Respuesta:* Por la letra pequeña que dice que no es del gobierno, el cobro alto y la prisa.

2. ¿Qué haces si te llaman para cobrarte una multa?
*Respuesta:* Cuelgas y verificas con el número oficial.


#### Para recordar

- Sin prisa.
- Revisa el remitente.
- Verifica tú.



### Profundiza (5 minutos más)

#### Tu cuenta de correo y tus cuentas del negocio

Muchos fraudes empiezan cuando alguien entra a tu correo. Usa contraseñas distintas, autenticación en dos pasos y revisa las reglas de reenvío de tu correo. Si un proveedor «cambia de banco», confírmalo por teléfono.



#### Extorsión

Si alguien te amenaza para cobrarte «protección» o te llama diciendo que tiene a un familiar, cuelga, localiza a tu familiar por otro medio y llama al 911 o a la policía local. No compartas horarios ni fotos de tu caja en redes.



#### Robo de identidad del negocio

Revisa tu registro en el Secretary of State de vez en cuando: si alguien cambia los datos de tu LLC, puede pedir crédito a tu nombre. Reporta el robo de identidad en IdentityTheft.gov.



#### Casos


**Caso 1. La carta de Daniela**

Una carta «oficial» cobra a Daniela $243 por un certificado de su LLC.
- *¿Qué hace?* Revisa el remitente y verifica en el sitio del Secretary of State antes de pagar.


**Caso 2. La llamada a Lupita**

Alguien «del departamento de salud» exige a Lupita pagar una multa por teléfono hoy.
- *¿Qué hace?* Cuelga y llama al número oficial del departamento de salud.


**Caso 3. El correo del proveedor**

Un correo del proveedor de Javier dice que cambió de cuenta.
- *¿Qué hace?* Llama al número del proveedor que ya tenía antes de pagar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar cartas sin revisar | Pierdes dinero | Lee la letra pequeña |
| Pagar por teléfono | Fraude | Verifica tú |
| Tarjetas de regalo | Fraude seguro | Nunca |
| Sin dos pasos en el correo | Te roban cuentas | Actívalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Lupita y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Una carta cobra por un «certificado» de tu LLC con amenaza de multa. ¿Qué haces primero? a) Pagas para evitar la multa · b) Llamas al número de la carta · c) Revisas el remitente y verificas en el sitio oficial
2. ¿Con qué nunca paga una autoridad real? a) Con tarjetas de regalo · b) Con cheque · c) En su sitio oficial
3. ¿Dónde reportas un fraude a tu negocio? a) En las reseñas de la empresa · b) En ReportFraud.ftc.gov · c) En ningún lado
**Respuestas:** 1-c: verifica antes de pagar. 2-a: señal de fraude. 3-b: reporte oficial.



#### Ponlo en práctica

Tres negocios de tu calle recibieron la misma carta de $243. Si todos pagaran, ¿cuánto perderían?
**Respuesta:** $729.



#### A tu plan

Activa la autenticación en dos pasos en tu correo y escribe tu protocolo contra fraudes.



### Para saber más

- **Reporta un fraude** (FTC · español): https://reportefraude.ftc.gov.
- **Robo de identidad** (FTC · español): https://www.robodeidentidad.gov.
- **Negocios de California** (Secretary of State · inglés): https://bizfileonline.sos.ca.gov — **Qué buscar:** tu negocio.

### Palabras clave

- *Carta que imita al gobierno:* correo de una empresa privada que parece oficial para cobrarte servicios.
- *Autenticación en dos pasos:* acceso con contraseña más un código o aprobación en tu teléfono.

### Fuentes

FTC · California Secretary of State, consultados el 29 de septiembre de 2026.

---

## M7 U04. Tu marca y tu nombre

**Lo que lograrás:** Saber cuándo conviene registrar tu marca, cómo buscar si ya existe y cómo hacerlo sin intermediarios abusivos.

**Para empezar:** Daniela vende joyería como «Luna Morena» desde hace dos años. Una tienda en otro estado le escribió diciendo que la marca es suya. En esta lección verás cómo proteger tu nombre.

### Lo esencial (5 minutos)

#### Qué es una marca registrada

Registrar tu marca en la USPTO te da derechos en todo el país para ciertos productos o servicios (clases). Usar un nombre te da algunos derechos locales, pero el registro federal protege mucho más.



#### Pasos

1. Busca en el buscador de marcas de la USPTO si el nombre ya existe.
2. Identifica la clase de tus productos o servicios.
3. Presenta la solicitud en línea y paga la tarifa.
4. Responde a tiempo los requerimientos de la USPTO.

> **Dato vigente:** la solicitud base de marca en la USPTO cuesta $350 por clase; puede haber cargos adicionales si la descripción no es del catálogo o falta información. Consultado el 29 de septiembre de 2026 a través de la USPTO (tarifas vigentes desde el 18 de enero de 2025).



#### Cuándo conviene

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu nombre ya vende | Clientes te buscan por él. | Protégelo. |
| Vendes en línea a otros estados | Más visible, más riesgo. | Registro federal. |
| Solo vendes en tu ciudad | Registro estatal puede bastar. | Más barato. |
| Avisos que cobran por «registrar» | No son de la USPTO. | Desconfía. |

#### Un caso en un minuto

Daniela buscó en la USPTO: «Luna Morena» estaba registrada para joyería desde antes. Cambió a un nombre libre y lo registró en una clase. Ahora puede crecer en línea sin miedo.

> **Idea clave:** busca en la USPTO antes de invertir en un nombre y regístralo cuando empiece a vender fuera de tu zona.



#### Comprueba lo que entendiste

1. ¿Dónde buscas si una marca ya existe?
*Respuesta:* En el buscador de marcas de la USPTO.

2. ¿Cuánto cuesta la solicitud base por clase?
*Respuesta:* $350.


#### Para recordar

- Busca en la USPTO.
- Registra por clase.
- Solo la USPTO registra marcas federales.



### Profundiza (5 minutos más)

#### Avisos y correos falsos

Después de solicitar tu marca, tus datos son públicos. Te llegarán cartas y correos que parecen de la USPTO cobrando por «publicar» o «monitorear» tu marca. Solo confía en comunicaciones de dominios uspto.gov.



#### Nombre de usuario y dominio

Tu cuenta de redes y tu dominio no son marca registrada. Te ayudan a vender, pero no te protegen si alguien registra el nombre.



#### Si te reclaman

Si alguien dice que tu nombre es su marca, verifica en la USPTO antes de responder. Si su registro es real y cubre tus productos, cambiar de nombre suele ser lo más prudente. Hay clínicas legales gratuitas de propiedad intelectual en algunas universidades.



#### Casos


**Caso 1. La marca de Daniela**

Una tienda dice a Daniela que «Luna Morena» es su marca.
- *¿Qué hace?* Verifica en la USPTO y, si el registro es real, cambia de nombre.


**Caso 2. El nombre del food truck**

Don Ramón quiere pintar un nombre nuevo en su food truck.
- *¿Qué hace antes?* Busca en la USPTO y en su estado que el nombre esté libre.


**Caso 3. El correo a Javier**

Javier recibe un correo que cobra $1,200 por «proteger su marca internacionalmente».
- *¿Qué hace?* Revisa que no sea de uspto.gov y no paga.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No buscar antes | Pierdes el nombre | USPTO |
| Creer que las redes protegen | Te lo quitan | Registra |
| Pagar avisos falsos | Fraude | Solo uspto.gov |
| Descripción libre sin revisar | Cargos extra | Usa el catálogo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Don Ramón y Javier. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde buscas si un nombre ya es marca federal? a) En la USPTO · b) En redes sociales · c) En un buscador de internet
2. ¿Tu cuenta de redes te da derecho exclusivo sobre el nombre en todo el país? a) Sí, si tiene muchos seguidores · b) Sí, si la abriste primero · c) No
3. ¿De qué dominio vienen los avisos reales de la USPTO? a) De cualquier correo con «marca» en el asunto · b) De uspto.gov · c) De un despacho que te escribe primero
**Respuestas:** 1-a: buscador oficial. 2-c: solo el registro. 3-b: dominio oficial.



#### Ponlo en práctica

Registras tu marca en dos clases con la tarifa base. ¿Cuánto pagas?
**Respuesta:** $700.



#### A tu plan

Busca el nombre de tu negocio en la USPTO y en el registro de tu estado.



### Para saber más

- **Buscador de marcas** (USPTO · inglés): https://www.uspto.gov — **Qué buscar:** «trademark search».
- **Marcas registradas en California** (Secretary of State · inglés): https://www.sos.ca.gov — **Qué buscar:** «trademarks».

### Palabras clave

- *Marca:* nombre, logotipo o combinación que distingue tu producto o servicio.
- *USPTO:* Oficina de Patentes y Marcas de Estados Unidos: registra marcas a nivel federal.
- *Clase:* grupo de productos o servicios que cubre un registro de marca.

### Fuentes

USPTO · California Secretary of State, consultados el 29 de septiembre de 2026.

---


# Parte 9. Módulo 8. Crecer con orden

## M8 U01. Contratar ayuda

**Lo que lograrás:** Calcular el costo real de contratar, distinguir entre empleado y contratista independiente, y conocer tus obligaciones básicas.

**Para empezar:** Lupita ya no alcanza a cumplir los pedidos de fin de semana. Quiere que su vecina le ayude y pagarle $15 la hora en efectivo «como contratista». En esta lección verás por qué eso puede traerle problemas.

### Lo esencial (5 minutos)

#### ¿Empleado o contratista?

Un contratista independiente decide cómo hace el trabajo y tiene su propio negocio. Si tú pones el horario, dices cómo hacerlo y el trabajo es parte central de tu negocio, en general es un **empleado**. En California se usa una prueba estricta (prueba ABC): la mayoría de quienes ayudan de forma regular son empleados.

> **Dato vigente:** el salario mínimo de California es de $16.90 por hora en 2026 (el federal es de $7.25, y muchas ciudades tienen uno más alto). Consultado el 29 de septiembre de 2026 a través del Departamento de Relaciones Industriales de California y el Departamento de Trabajo de EE. UU.



#### Lo que cuesta un empleado además del sueldo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Impuestos de nómina | Seguro Social, Medicare, desempleo. | Tú retienes y pagas. |
| Compensación al trabajador | Obligatoria en California. | Seguro. |
| Días de enfermedad pagados | Ley de California. | Se acumulan. |
| «Contratista» por conveniencia | Multas altas por mala clasificación. | Clasifica bien. |

#### La ayudante de Lupita (aproximado)

- Sueldo al mes (20 horas por semana a $16.90): **$1,352**
- Impuestos de nómina y seguro (aprox.): **$250**
- Costo real al mes: **$1,602**
Lupita recalcula su punto de equilibrio (M2 U03) antes de contratar.


#### Un caso en un minuto

Lupita vio que su vecina sería empleada: trabajaría en su cocina, con su horario y sus recetas. Usó un servicio de nómina para registrarse con el EDD, pagar el salario mínimo y el seguro de compensación. Subió sus precios de fin de semana para cubrirlo.

> **Idea clave:** clasifica bien a quien te ayuda, paga al menos el salario mínimo y calcula el costo real antes de contratar.



#### Comprueba lo que entendiste

1. ¿Qué define a un contratista independiente?
*Respuesta:* Que tiene su propio negocio y decide cómo hace el trabajo.

2. ¿Cuál es el salario mínimo de California en 2026?
*Respuesta:* $16.90 por hora.


#### Para recordar

- Empleado o contratista: no se elige por conveniencia.
- Salario mínimo.
- Costo real con impuestos y seguro.



### Profundiza (5 minutos más)

#### Si tienes empleados

Necesitas un EIN, registrarte con la agencia de empleo de tu estado (en California, el EDD), retener y pagar impuestos de nómina, tener compensación al trabajador y verificar la elegibilidad de empleo de cada persona con el Formulario I-9. Un servicio de nómina o un contador puede hacerlo por ti.



#### Contratistas de verdad

Si contratas a otro negocio para un trabajo puntual (un diseño, una reparación), pide su W-9 y, si le pagas $2,000 o más en el año, envíale un 1099-NEC.



#### Familia que ayuda

Hay reglas especiales para hijos menores de un dueño único y para cónyuges. Si tu familia ayuda de forma regular, revisa las reglas con un preparador de impuestos.

> **Antes de actuar, verifica:** la clasificación y tus obligaciones como empleador con el EDD, el DIR y el IRS; las reglas cambian por estado y ciudad.



#### Casos


**Caso 1. La vecina de Lupita**

Lupita quiere pagar a su vecina en efectivo «como contratista» para trabajar en su cocina con su horario.
- *¿Qué hace?* Reconoce que sería empleada y se registra como empleador.


**Caso 2. El ayudante de Javier**

Javier quiere que un ayudante le ayude en un trabajo de pintura de $3,000.
- *¿Qué revisa?* Que con ayudantes necesita licencia de la CSLB y tener compensación al trabajador.


**Caso 3. El diseñador de Daniela**

Daniela contrata a un diseñador independiente para su logo por $400.
- *¿Qué hace?* Le pide su W-9 y guarda la factura; no necesita 1099 si es menos de $2,000 en el año.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| «Contratista» por conveniencia | Multas altas | Clasifica bien |
| Menos del mínimo | Ilegal | Salario mínimo |
| Sin compensación | Demandas | Obligatoria |
| Ver solo el sueldo | Te falta dinero | Costo real |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Javier y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Alguien trabaja en tu local, con tu horario y tus instrucciones. ¿Qué suele ser? a) Un empleado · b) Un contratista independiente · c) Un socio
2. ¿Qué seguro es obligatorio en California si tienes empleados? a) Seguro de vida para cada empleado · b) Compensación al trabajador · c) Seguro de auto
3. Pagas $2,500 en el año a un diseñador independiente. ¿Qué le envías? a) Un W-2 · b) Nada · c) Un 1099-NEC
**Respuestas:** 1-a: tú controlas el trabajo. 2-b: obligatorio. 3-c: desde $2,000 en 2026.



#### Ponlo en práctica

Una persona trabaja 15 horas por semana a $16.90. ¿Cuánto es su sueldo en 4 semanas?
**Respuesta:** 60 horas por $16.90: $1,014.



#### A tu plan

Si piensas contratar, decide si sería empleado o contratista y calcula el costo real.



### Para saber más

- **Empleado o contratista** (DIR · español): https://www.dir.ca.gov — **Qué buscar:** «prueba ABC».
- **Empleadores** (EDD · español): https://edd.ca.gov/es — **Qué buscar:** «registro de empleadores».
- **Salario mínimo** (DIR · español): https://www.dir.ca.gov — **Qué buscar:** «salario mínimo».

### Palabras clave

- *Contratista independiente:* persona que tiene su propio negocio, decide cómo hace el trabajo y trabaja para varios clientes.
- *Impuestos de nómina:* impuestos que el empleador retiene y paga por sus empleados.
- *Prueba ABC:* prueba de California para saber si alguien es empleado o contratista.

### Fuentes

DIR · EDD · IRS · Departamento de Trabajo de EE. UU., consultados el 29 de septiembre de 2026.

---

## M8 U02. Vender en línea y en plataformas

**Lo que lograrás:** Calcular el costo real de vender en línea y en plataformas, y entender el 1099-K y el sales tax en plataformas.

**Para empezar:** Daniela vende un collar en $40 en una tienda en línea. Después de las comisiones de venta, de pago y de anuncios, y del envío, le queda mucho menos. En esta lección verás cuánto te queda de verdad.

### Lo esencial (5 minutos)

#### Lo que se descuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión de venta | Un porcentaje por venta. | Cambia por plataforma. |
| Comisión de pago | Por procesar el cobro. | Porcentaje más cuota fija. |
| Anuncios | Si pagas por aparecer más. | Mide si conviene. |
| Envío | Lo pagas tú o tu cliente. | Inclúyelo en el precio. |

#### El collar de Daniela

- Precio: **$40**
- Comisiones de venta y pago (aprox.): **$5**
- Envío: **$5**
- Material y empaque: **$10**
- Antes de sus costos fijos e impuestos: **$20**


#### Un caso en un minuto

Daniela calculó lo que le queda por plataforma. En una le quedaban $20; en su propia página, $26, pero vende menos. Subió su precio en la plataforma a $44 y ofrece envío gratis en su página a partir de dos piezas.

> **Idea clave:** calcula tu precio por canal, con todas las comisiones y el envío, y declara todo lo que vendes.



#### Comprueba lo que entendiste

1. ¿Qué comisiones cobran las plataformas?
*Respuesta:* De venta, de pago y, si los usas, de anuncios.

2. ¿Declaras tus ventas aunque no recibas 1099-K?
*Respuesta:* Sí, todo ingreso se declara.


#### Para recordar

- Comisiones + envío + anuncios.
- Precio por canal.
- Todo se declara.



### Profundiza (5 minutos más)

#### El 1099-K

Si tus cobros en una plataforma superan $20,000 y 200 transacciones en el año, recibirás un 1099-K. El formulario muestra cobros brutos: resta devoluciones, comisiones y costos en tu Schedule C. Aunque no lo recibas, declara todo.



#### Sales tax en plataformas

En la mayoría de los estados, las plataformas grandes cobran y entregan el sales tax de las ventas que pasan por ellas. En tu propia página o en ventas por redes, te toca a ti (M5 U05).



#### Reputación y devoluciones

Las calificaciones venden. Describe bien, envía a tiempo y responde rápido. Calcula lo que te cuestan las devoluciones y súmalo al precio.

> **Antes de actuar, verifica:** las comisiones vigentes en cada plataforma; cambian con frecuencia.



#### Casos


**Caso 1. El precio en plataforma**

Daniela vende igual en la plataforma que en su página.
- *¿Qué revisa?* Que el precio en la plataforma cubra comisiones, envío y anuncios.


**Caso 2. El 1099-K de Daniela**

Daniela recibió un 1099-K por $24,000 brutos.
- *¿Qué hace?* Declara los cobros y resta devoluciones, comisiones y costos con sus registros.


**Caso 3. Los anuncios de Lupita**

Lupita paga $100 al mes en anuncios y no sabe si le traen ventas.
- *¿Qué hace?* Mide cuántas ventas vienen de los anuncios y cuánto le dejan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mismo precio en todos lados | Pierdes en plataforma | Precio por canal |
| Declarar el 1099-K sin restar costos | Pagas de más | Usa tus registros |
| No declarar sin 1099-K | Problemas con el IRS | Declara todo |
| Anuncios sin medir | Gasto sin retorno | Mide |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo envía una plataforma el 1099-K? a) Siempre, desde la primera venta · b) Con más de $20,000 y más de 200 transacciones · c) Solo si lo pides
2. Tu 1099-K muestra $24,000 brutos. ¿Cuánto declaras como ganancia? a) $24,000 completos · b) Nada, ya lo reportó la plataforma · c) Los cobros menos devoluciones, comisiones y costos
3. ¿Quién suele cobrar el sales tax de ventas en plataformas grandes? a) La plataforma · b) Nadie · c) Tu cliente directamente al estado
**Respuestas:** 1-b: umbral vigente. 2-c: se restan costos. 3-a: facilitador de mercado.



#### Ponlo en práctica

Vendes 60 piezas de $30 en un mes; la plataforma cobra 12% en total y el envío es $4 por pieza. ¿Cuánto te queda antes de material?
**Respuesta:** $1,800 menos $216 menos $240: $1,344.



#### A tu plan

Calcula cuánto te queda por producto en cada canal donde vendes.



### Para saber más

- **Formulario 1099-K** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «formulario 1099-K».

### Palabras clave

- *Plataforma:* sitio o app que conecta a vendedores y compradores y cobra una comisión.
- *Cobros brutos:* total cobrado antes de restar comisiones, devoluciones y costos.

### Fuentes

IRS · CDTFA, consultados el 29 de septiembre de 2026.

---

## M8 U03. Tus números del mes

**Lo que lograrás:** Revisar cada mes cinco números de tu negocio y tomar decisiones con ellos.

**Para empezar:** Don Ramón siente que el food truck va «más o menos». Su hija le propone revisar cinco números cada mes. En esta lección verás cuáles son y qué dicen.

### Lo esencial (5 minutos)

#### Tus cinco números

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ventas | Cuánto vendiste. | Compara con el mes anterior. |
| Margen | Qué % te queda después de lo que vendes. | ¿Sube o baja? |
| Ganancia | Ventas menos todos los costos. | La que importa. |
| Efectivo al cierre | Lo que tienes al final del mes. | ¿Alcanza? |

#### El quinto: ticket promedio

El ticket promedio es lo que gasta cada cliente en promedio. Si sube, vendes más sin necesitar más clientes.



#### El ticket de Don Ramón

- Ventas del mes: **$12,000**
- Número de ventas: **1,000**
- Ticket promedio: **$12**
Si cada cliente gastara $1.50 más, vendería $1,500 más al mes.


#### Un caso en un minuto

Don Ramón vio que su margen bajó de 60% a 55%: la carne subió y él no ajustó. Cambió de proveedor y ofreció un combo con bebida. El siguiente mes su ticket subió a $13.40.

> **Idea clave:** cinco números al mes te dicen qué mejorar: ventas, margen, ganancia, efectivo y ticket promedio.



#### Comprueba lo que entendiste

1. ¿Qué es el ticket promedio?
*Respuesta:* Lo que gasta cada cliente en promedio: ventas entre número de ventas.

2. ¿Qué haces si tu margen baja?
*Respuesta:* Revisas precios y costos: proveedores, merma y precio.


#### Para recordar

- Cinco números al mes.
- Compara con el mes anterior.
- Una decisión por número.



### Profundiza (5 minutos más)

#### Tu tablero del mes

| Número | Mes anterior | Este mes | Decisión |
|---|---|---|---|
| Ventas | | | |
| Margen | | | |
| Ganancia | | | |
| Efectivo al cierre | | | |
| Ticket promedio | | | |



#### Compara con el mismo mes del año pasado

Si tu negocio tiene temporadas, compara julio con julio, no con junio.



#### Una decisión a la vez

Elige una mejora (precio, proveedor, horario), aplícala y mide el siguiente mes.



#### Casos


**Caso 1. El margen de Don Ramón**

El margen de Don Ramón bajó cinco puntos.
- *¿Qué hace?* Revisa qué costos subieron y ajusta proveedores o precios.


**Caso 2. Las ventas de Daniela**

Las ventas de Daniela bajaron en enero frente a diciembre.
- *¿Con qué compara?* Con enero del año pasado, por la temporada.


**Caso 3. El ticket de Lupita**

Lupita tiene muchos clientes, pero cada uno compra poco.
- *¿Qué prueba?* Un combo o una bebida para subir el ticket promedio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mirar solo ventas | Ganancia escondida | Cinco números |
| Comparar mal | Conclusiones falsas | Mismo mes del año pasado |
| Cambiar todo junto | No sabes qué funcionó | Una a la vez |
| No anotar decisiones | Se olvidan | Tablero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Daniela y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Ventas de $6,000 en 400 ventas. ¿Ticket promedio? a) $2,400 · b) $150 · c) $15
2. Tu margen bajó. ¿Qué revisas primero? a) Precios y costos de lo que vendes · b) El color de tu logo · c) Tu límite de la tarjeta
3. Tu negocio tiene temporadas. ¿Con qué comparas julio? a) Con junio · b) Con julio del año pasado · c) Con enero
**Respuestas:** 1-c: $6,000 entre 400. 2-a: el margen depende de ellos. 3-b: misma temporada.



#### Ponlo en práctica

Tienes 800 ventas al mes. Si tu ticket promedio sube de $10 a $11, ¿cuánto más vendes al mes?
**Respuesta:** $800.



#### A tu plan

Llena tu tablero con los números del mes pasado y elige una decisión para este mes.



### Para saber más

- **Asesoría gratuita** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «centros de desarrollo de pequeñas empresas» (SBDC) y SCORE.

### Palabras clave

- *Ticket promedio:* lo que gasta en promedio cada cliente por compra: ventas entre número de ventas.
- *Tablero:* tabla con los números clave del negocio cada mes.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---


# Parte 10. Módulo 9. Tu futuro

## M9 U01. Tu retiro si trabajas por tu cuenta

**Lo que lograrás:** Conocer cómo ahorrar para el retiro si trabajas por tu cuenta: Seguro Social, cuentas IRA, SEP IRA y Solo 401(k).

**Para empezar:** Don Ramón tiene 60 años. Piensa que «el food truck es su retiro», pero no sabe cuánto recibiría del Seguro Social ni si le alcanza. En esta lección verás tus opciones.

### Lo esencial (5 minutos)

#### El negocio no es tu retiro

Tu negocio depende de que tú trabajes. Si te enfermas o te cansas, puede dejar de dar. Por eso necesitas un ahorro para el retiro **aparte** del negocio.



#### El Seguro Social

El impuesto por cuenta propia que pagas (M5 U03) cuenta para tu Seguro Social. Para tener derecho a la pensión de retiro, en general necesitas 40 créditos (unos 10 años de trabajo). Revisa tu historial y tu estimado en my Social Security (ssa.gov).

> **Dato vigente:** en 2026 ganas un crédito del Seguro Social por cada $1,890 de ganancias, hasta 4 créditos al año ($7,560). Consultado el 29 de septiembre de 2026 a través de la Administración del Seguro Social (SSA).



#### Cuentas de retiro para quien trabaja por su cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IRA tradicional o Roth | Para cualquier persona con ingresos. | Hasta $7,500 en 2026 ($8,600 con 50 o más). |
| SEP IRA | Fácil de abrir para dueños. | Hasta 25% de tu ganancia ajustada, máximo $72,000. |
| Solo 401(k) | Para dueños sin empleados. | $24,500 como empleado más aportación del negocio, máximo $72,000. |
| Solo el negocio | Depende de tu salud. | Riesgoso. |

> **Dato vigente:** para 2026, el límite de aportación a una IRA es de $7,500 ($8,600 con 50 años o más); a una SEP IRA, hasta 25% de la compensación y un máximo de $72,000; y a un Solo 401(k), $24,500 como empleado y un total de $72,000, sin contar aportaciones adicionales por edad. Consultado el 29 de septiembre de 2026 a través del IRS.

#### Un caso en un minuto

Don Ramón revisó su cuenta en ssa.gov: tiene 52 créditos y un estimado de $1,300 al mes a los 67 años. Abrió una IRA y aporta $300 al mes. Sabe que cada año que espera para reclamar su pensión, el pago mensual sube.

> **Idea clave:** separa tu retiro de tu negocio; revisa tu Seguro Social y aporta algo fijo cada mes a una cuenta de retiro.



#### Comprueba lo que entendiste

1. ¿Cuántos créditos necesitas en general para la pensión de retiro del Seguro Social?
*Respuesta:* 40 créditos.

2. ¿Qué cuenta de retiro puede abrir cualquier persona con ingresos?
*Respuesta:* Una IRA tradicional o Roth.


#### Para recordar

- Retiro aparte del negocio.
- Revisa ssa.gov.
- Aportación fija cada mes.



### Profundiza (5 minutos más)

#### Ventajas fiscales

Las aportaciones a una IRA tradicional, SEP o Solo 401(k) pueden bajar tus impuestos de hoy; en una Roth pagas impuestos hoy y retiras sin impuestos en el retiro, si cumples las reglas. Retirar antes de los 59 años y medio suele tener multa. Pregunta a tu preparador cuál te conviene.



#### Si declaras con ITIN

Las ganancias se registran en el Seguro Social con un número de Seguro Social. Si hoy declaras con ITIN, pregunta a la SSA o a un profesional cómo podrían reconocerse tus ganancias en el futuro. Una IRA puede abrirse con ITIN en algunas instituciones.



#### CalSavers

En California, CalSavers es el programa estatal de ahorro para el retiro. Es obligatorio ofrecerlo si tienes empleados y no tienes otro plan, y también acepta a personas que trabajan por su cuenta.



#### Casos


**Caso 1. El retiro de Don Ramón**

Don Ramón no sabe cuánto recibiría del Seguro Social.
- *¿Qué hace?* Revisa su historial y su estimado en ssa.gov.


**Caso 2. La SEP de Javier**

Javier ganó bien este año y quiere pagar menos impuestos y ahorrar.
- *¿Qué revisa?* Abrir una SEP IRA o un Solo 401(k) con su preparador de impuestos.


**Caso 3. El ahorro de Daniela**

Daniela tiene 27 años y cree que es muy pronto para el retiro.
- *¿Qué hace?* Empieza con una aportación pequeña y fija a una IRA.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| El negocio como pensión | Sin ingreso si falla | Ahorro aparte |
| No revisar ssa.gov | Sorpresas | Revisa tu historial |
| Retirar antes de tiempo | Multas | Déjalo crecer |
| Empezar tarde | Menos ahorro | Empieza pequeño |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Ramón, Javier y Daniela. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde revisas tu historial del Seguro Social? a) En tu banco · b) En ssa.gov · c) En el IRS
2. ¿Cuánto puedes aportar a una IRA en 2026 si tienes menos de 50 años? a) $72,000 · b) $24,500 · c) $7,500
3. ¿Por qué el negocio no basta como retiro? a) Depende de que puedas trabajar · b) Porque los negocios pequeños no pagan impuestos · c) Porque es pequeño
**Respuestas:** 1-b: sitio oficial. 2-c: límite de 2026. 3-a: tu salud cambia.



#### Ponlo en práctica

Aportas $200 al mes a una IRA durante 25 años, sin contar rendimientos. ¿Cuánto aportaste?
**Respuesta:** $200 por 300 meses: $60,000.



#### A tu plan

Crea tu cuenta en ssa.gov, revisa tu estimado y fija una aportación mensual para tu retiro.



### Para saber más

- **my Social Security** (SSA · español): https://www.ssa.gov/espanol — **Qué buscar:** «mi cuenta de Seguro Social».
- **Planes de retiro para trabajadores por cuenta propia** (IRS · inglés): https://www.irs.gov — **Qué buscar:** «retirement plans for self-employed».
- **CalSavers** (español): https://www.calsavers.com — **Qué buscar:** «trabajadores por cuenta propia».

### Palabras clave

- *Crédito del Seguro Social:* unidad que ganas por tus ingresos; necesitas 40 para la pensión de retiro.
- *IRA:* cuenta individual de retiro con beneficios fiscales.
- *SEP IRA:* cuenta de retiro para dueños de negocio y sus empleados.

### Fuentes

SSA · IRS · CalSavers, consultados el 29 de septiembre de 2026.

---

## M9 U02. Si el negocio cambia o si faltas

**Lo que lograrás:** Prepararte para cerrar, pausar o pasar tu negocio, y dejar en orden la información por si faltas.

**Para empezar:** Lupita se enfermó tres semanas y su hija no sabía a qué proveedor pagar, dónde estaban las cuentas ni cómo cobrar los pedidos. En esta lección verás cómo preparar a tu negocio para cambios.

### Lo esencial (5 minutos)

#### Tres situaciones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pausar | Temporada, enfermedad, mudanza. | Avisa y ordena. |
| Cerrar | El negocio ya no da. | Cierre formal. |
| Pasar | A un familiar o a otra persona. | Acuerdo por escrito. |
| Si faltas | Nadie sabe qué hacer. | Deja la información en orden. |

#### Tu carpeta del negocio

1. Lista de proveedores, clientes y contactos.
2. Cuentas del negocio y quién puede operarlas (sin contraseñas escritas).
3. Deudas, préstamos y pagos pendientes.
4. Números fiscales, permisos, preparador de impuestos y fechas.
5. Seguros y beneficiarios.



#### Un caso en un minuto

Lupita armó una carpeta con proveedores, cuentas, fechas de pago y el contacto de su preparador. Autorizó a su hija en la cuenta del negocio. La siguiente vez que faltó, los pedidos siguieron.

> **Idea clave:** deja en una carpeta lo que alguien necesitaría para seguir o cerrar tu negocio sin ti.



#### Comprueba lo que entendiste

1. ¿Qué va en tu carpeta del negocio?
*Respuesta:* Proveedores, cuentas, deudas, datos fiscales, permisos, seguros y contactos.

2. ¿Por qué no escribir contraseñas?
*Respuesta:* Porque si alguien encuentra la carpeta, puede robar tus cuentas.


#### Para recordar

- Pausar, cerrar o pasar con orden.
- Carpeta del negocio.
- Nunca contraseñas por escrito.



### Profundiza (5 minutos más)

#### Cerrar bien

Presenta tu última declaración y marca que es la final si aplica, cancela tu seller's permit, tus licencias y, si tienes una LLC, disuélvela formalmente: en California, si no la disuelves, el impuesto mínimo de $800 sigue corriendo cada año.



#### Pasar el negocio

Si un familiar seguirá con el negocio, acuerden por escrito cuándo, en qué condiciones y qué pasa con el equipo, el inventario y las deudas. Los permisos y licencias casi siempre están a tu nombre y deben tramitarse de nuevo.



#### Testamento y beneficiarios

El equipo, el inventario y el dinero del negocio son parte de tu patrimonio. Un testamento o un fideicomiso en vida (living trust) y beneficiarios actualizados en cuentas, IRA y seguros evitan trámites largos a tu familia. Hay clínicas legales gratuitas o de bajo costo.

> **Antes de actuar, verifica:** los pasos para cerrar con el IRS, tu estado y tu ciudad, y consulta a un abogado para testamento o traspaso.



#### Casos


**Caso 1. La enfermedad de Lupita**

La hija de Lupita no sabía cómo seguir con los pedidos.
- *¿Qué prepara Lupita?* Una carpeta con proveedores, cuentas, pagos y contactos.


**Caso 2. La LLC de Daniela**

Daniela dejará de vender y ya no usará su LLC.
- *¿Qué hace?* La disuelve formalmente para no seguir pagando $800 al año.


**Caso 3. El food truck de Don Ramón**

Don Ramón quiere que su hija se quede con el food truck en unos años.
- *¿Qué hace?* Hace un acuerdo por escrito y revisa su testamento o fideicomiso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo en tu cabeza | Nadie puede seguir | Carpeta |
| Contraseñas escritas | Robo de cuentas | Autorizaciones |
| Dejar la LLC abierta | $800 al año | Disuélvela |
| Pasar de palabra | Conflictos familiares | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Daniela y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cierras tu negocio con LLC en California. ¿Qué haces? a) Nada: solo dejas de vender hasta que vuelvas · b) Cancelas tu cuenta del banco y listo · c) La disuelves formalmente para no seguir pagando el mínimo
2. ¿Qué no debe ir escrito en tu carpeta del negocio? a) Tus contraseñas · b) La lista de proveedores · c) Las fechas de pago
3. ¿Cómo pasas el negocio a un familiar? a) De palabra · b) Con un acuerdo por escrito · c) Sin avisar a nadie
**Respuestas:** 1-c: el mínimo sigue corriendo. 2-a: riesgo de robo. 3-b: evita conflictos.



#### Ponlo en práctica

Olvidas disolver tu LLC en California durante 3 años sin actividad. ¿Cuánto podrías deber de impuesto mínimo, sin multas?
**Respuesta:** $2,400.



#### A tu plan

Arma tu carpeta del negocio y dile a una persona de confianza dónde está.



### Para saber más

- **Cerrar un negocio** (IRS · inglés): https://www.irs.gov — **Qué buscar:** «closing a business».
- **Disolver una LLC** (California Secretary of State · inglés): https://bizfileonline.sos.ca.gov — **Qué buscar:** «dissolution».

### Palabras clave

- *Fideicomiso en vida (living trust):* documento legal para pasar tus bienes sin un juicio largo.
- *Disolución:* trámite formal para cerrar una empresa.

### Fuentes

IRS · California Secretary of State · Franchise Tax Board, consultados el 29 de septiembre de 2026.

---

## M9 U03. Tu plan de una página

**Lo que lograrás:** Reunir en una hoja las decisiones del curso: dinero, precio, flujo, formalidad, protección y futuro.

**Para empezar:** Daniela aprendió mucho, pero lo tiene en notas sueltas. Quiere una hoja que pueda pegar junto a su mesa de trabajo. En esta lección armarás tu plan de una página.

### Lo esencial (5 minutos)

#### Por qué una sola hoja

Una hoja te obliga a elegir lo importante. La pegas donde la veas y la revisas cada tres meses.



#### Tu plan de una página

| Tema | Mi decisión |
|---|---|
| Dinero separado | Cuenta del negocio: ___ · Cuenta de impuestos: ___ · Mi sueldo: ___ |
| Precio | Costo de mi producto principal: ___ · Precio: ___ · Margen: ___ |
| Punto de equilibrio | ___ al mes · ___ al día |
| Flujo | Reserva meta: ___ · % que aparto: ___ · Reglas de crédito: ___ |
| Cobro | Formas de cobro: ___ · Protocolo contra fraudes: sí / no |
| Formalidad | Estructura: ___ · EIN y permisos: ___ · Fechas de pagos estimados: ___ |
| Crédito | ¿Necesito? ___ · APR y total a pagar: ___ |
| Protección | Seguro médico: ___ · Seguro del negocio: ___ · Marca: ___ |
| Números del mes | Revisión el día ___ |
| Futuro | Seguro Social revisado: sí / no · Cuenta de retiro: ___ · Carpeta: sí / no |



#### Revisa cada tres meses

Pon una fecha fija, por ejemplo junto a tus pagos estimados. Actualiza números, revisa si cumpliste y cambia una decisión si hace falta.



#### Un caso en un minuto

Daniela llenó su hoja en una tarde. Le faltaban dos cosas: su cuenta de retiro y revisar su marca. Las puso como metas del próximo trimestre.

> **Idea clave:** tu plan cabe en una hoja; revísalo cada tres meses y mejora una cosa a la vez.



#### Comprueba lo que entendiste

1. ¿Cada cuánto revisas tu plan?
*Respuesta:* Cada tres meses.

2. ¿Qué haces si falta algo?
*Respuesta:* Lo pones como meta del próximo trimestre.


#### Para recordar

- Una hoja.
- Donde la veas.
- Revisión trimestral.



### Profundiza (5 minutos más)

#### Prioriza

Si te faltan muchas cosas, empieza por: 1) separar el dinero y apartar impuestos, 2) precio con margen, 3) reserva, 4) seguro médico y del negocio. Lo demás puede esperar unos meses.



#### Compártelo

Comparte tu plan con alguien de confianza o en la comunidad (sin datos personales ni montos reales). Un asesor gratuito de un SBDC o de SCORE también puede revisarlo contigo.



#### Casos


**Caso 1. La hoja de Daniela**

A Daniela le faltan su cuenta de retiro y su marca.
- *¿Qué hace?* Las pone como metas del próximo trimestre.


**Caso 2. Las prioridades de Javier**

Javier tiene muchas tareas pendientes y no sabe por dónde empezar.
- *¿Qué hace?* Empieza por separar el dinero, apartar impuestos y su precio.


**Caso 3. La revisión de Don Ramón**

Don Ramón hizo su plan hace tres meses y no lo ha revisado.
- *¿Qué hace?* Pone una fecha fija y actualiza sus números.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Notas sueltas | Se olvidan | Una hoja |
| Querer todo junto | Te abrumas | Prioriza |
| No revisar | Se queda viejo | Cada tres meses |
| Guardarlo en un cajón | No lo ves | Pégalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Daniela, Javier y Don Ramón. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cada cuánto revisas tu plan de una página? a) Cada tres meses · b) Una vez en la vida · c) Cada día
2. ¿Por dónde empiezas si te faltan muchas cosas? a) Por registrar tu marca · b) Por separar el dinero y apartar impuestos · c) Por pedir un préstamo para ordenar todo de una vez
3. ¿Qué compartes en la comunidad? a) Tus montos, cuentas y ventas reales del mes · b) Tu número de Seguro Social · c) Tu plan sin datos personales
**Respuestas:** 1-a: revisión trimestral. 2-b: la base de todo. 3-c: sin datos.



#### Ponlo en práctica

Revisas tu plan cada tres meses. ¿Cuántas revisiones haces en dos años?
**Respuesta:** 8.



#### A tu plan

Llena tu plan de una página y pon la fecha de tu primera revisión.



### Para saber más

- **Asesoría gratuita** (SBA · español): https://www.sba.gov/es — **Qué buscar:** «SBDC» y «SCORE».

### Palabras clave

- *Plan de una página:* resumen de las decisiones de tu negocio en una hoja.
- *Revisión trimestral:* revisión de tu plan cada tres meses.

### Fuentes

SBA, consultado el 29 de septiembre de 2026.

---


# Parte 11. Materiales de apoyo

## Bienvenida

**Tu Negocio, Tu Dinero, Tu Futuro · EE. UU.** es un programa de educación financiera para personas latinas que emprenden o trabajan por su cuenta en Estados Unidos.

Aquí aprenderás a separar el dinero del negocio y de tu casa, poner precio, cuidar tu flujo, cobrar sin perder, formalizarte y pagar tus impuestos sin miedo, usar el crédito con cuidado, proteger tu negocio y pensar en tu futuro.

No necesitas saber de finanzas ni de impuestos. Cada lección parte de una situación real y termina con una acción que puedes hacer esta semana. Usamos reglas federales y ejemplos de California; si vives en otro estado, te decimos qué revisar.

Versión 1.0 · Septiembre de 2026. También existe en inglés.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos por lección |
| **¿Qué harías?** | Una actividad por lección: tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todas las lecciones del módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 a 15 minutos |

### Elige tu ruta en cada lección

- **Ruta rápida (5 min):** lee *Lo esencial* y pasa a *Practica*.
- **Ruta completa (10 min):** suma *Profundiza*, con casos, errores frecuentes y más datos.

### Los personajes

- **Lupita** (41): vende tamales y comida por encargo desde su casa en Los Ángeles.
- **Javier** (38): pintor y handyman en Fresno.
- **Daniela** (27): vende joyería por redes y en una plataforma desde San José.
- **Don Ramón** (60): tiene un food truck en Sacramento.

### Tres reglas del programa

1. **Nunca te pediremos datos personales, fiscales ni tu situación migratoria**: SSN, ITIN, EIN, contraseñas ni números de cuenta. Si alguien lo hace en nombre del programa, es un fraude.
2. **No te vendemos nada.** En las lecciones no hay recomendaciones de bancos, procesadores, plataformas ni préstamos.
3. **Orientación, no asesoría.** Tu caso de impuestos lo revisas con un preparador de impuestos o CPA; tu caso migratorio, con un abogado o una organización acreditada.

### Los datos cambian

Límites, tarifas y reglas cambian cada año. Los datos del programa se consultaron el **29 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa el **IRS**, tu estado o el sitio oficial de la institución.

### Puntos, niveles e insignias

Ganas puntos al completar cada actividad. Hay seis niveles (Idea, Arranque, En marcha, Formal, En crecimiento y Consolidado) y ocho insignias. Nadie ve tu nombre en una tabla de posiciones.

### Constancia

Al aprobar las nueve autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión** con código de verificación. Es un reconocimiento educativo del programa; no es una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Los montos están en dólares. Resuelve cada caso antes de abrir la clave.

### E1. Los tamales de Lupita (Módulos 1 y 2)

**Datos.** Lupita vende $4,200 al mes. Gasta $1,800 en ingredientes y empaques (variables) y tiene $700 de costos fijos. Vende unas 140 docenas al mes a $30. No aparta nada para impuestos.

**Tareas.**

1. ¿Cuánto gana antes de impuestos?
2. Si aparta 25% para impuestos, ¿cuánto aparta?
3. ¿Cuánto le cuesta cada docena en ingredientes?
4. ¿Cuánto le deja cada docena después de ingredientes y cuántas necesita vender al mes para cubrir sus fijos?

**Clave.**

- $4,200 menos $1,800 menos $700: $1,700.
- 25% de $1,700: $425.
- $1,800 entre 140: unos $12.86.
- $30 menos $12.86: unos $17.14; $700 entre $17.14: unas 41 docenas.

### E2. El trimestre de Javier (Módulos 3 y 4)

**Datos.** Javier tiene $900 en la cuenta del negocio. Terminó un trabajo de $4,500 que le pagarán a 30 días. Necesita $1,200 de pintura ya y su pago estimado de $1,100 vence en tres semanas. Un cliente nuevo le manda un cheque de $2,500 por un trabajo de $1,500 y pide $1,000 de vuelta.

**Tareas.**

1. ¿Le alcanza para la pintura y el pago estimado sin cobrar?
2. ¿Qué dos acciones mejoran su flujo?
3. ¿Qué hace con el cheque?
4. ¿Cuándo vence su siguiente pago estimado si estamos en agosto de 2026?

**Clave.**

- $900 contra $2,300: le faltan $1,400.
- Pedir depósito en el siguiente trabajo y plazo en la tienda de pintura.
- No lo deposita ni regresa nada; pide el pago exacto. Es el fraude del cheque de más.
- El 15 de septiembre de 2026.

### E3. Los impuestos de Daniela (Módulos 5 y 8)

**Datos.** Daniela vendió $30,000 en el año: $22,000 en una plataforma (más de 200 transacciones) y $8,000 en su página. Sus costos y comisiones sumaron $14,000. Su ganancia neta fue de $16,000.

**Tareas.**

1. ¿Recibe 1099-K de la plataforma?
2. ¿Declara las ventas de su página?
3. ¿Cuánto es aproximadamente su impuesto por cuenta propia?
4. ¿Quién cobra el sales tax de sus ventas en la plataforma y quién el de su página?

**Clave.**

- Sí: más de $20,000 y más de 200 transacciones.
- Sí: todo ingreso se declara.
- $16,000 por 92.35% por 15.3%: unos $2,261.
- En general, la plataforma cobra el de sus ventas; ella, el de su página.

### E4. El food truck de Don Ramón (Módulos 6, 7 y 9)

**Datos.** Don Ramón recibe dos ofertas por $10,000: un préstamo de cooperativa a 12 meses con pagos de $898 y un adelanto con factor de 1.35 a 6 meses. Tiene 60 años, 52 créditos del Seguro Social y ningún ahorro para el retiro. Su seguro de auto personal no cubre el food truck.

**Tareas.**

1. ¿Cuánto paga en total con cada oferta?
2. ¿Cuál conviene?
3. ¿Qué seguro necesita?
4. ¿Qué dos acciones de retiro puede empezar este mes?

**Clave.**

- Préstamo: $898 por 12: $10,776. Adelanto: $13,500.
- El préstamo de la cooperativa: $2,724 menos.
- Seguro comercial con auto, responsabilidad civil y equipo.
- Revisar su estimado en ssa.gov y abrir una IRA con una aportación fija.


## Prácticas de cálculo

Resuelve cada práctica mostrando el procedimiento. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Ventas $3,200; materiales $1,400; gasolina y comisiones $500. ¿Ganancia? |
| P02 | M1 U03 | Ganancia promedio $2,400; 25% para impuestos y $200 de reserva. ¿Sueldo? |
| P03 | M1 U04 | 450 millas de negocio en marzo de 2026. ¿Deducción con la tarifa estándar? |
| P04 | M2 U01 | Material $7 por pieza, fijos $500 al mes, 250 piezas. ¿Costo por pieza? |
| P05 | M2 U02 | Costo $48. ¿Precio para 20% de margen sobre el precio? |
| P06 | M2 U03 | Fijos $4,500; cada venta deja 45%. ¿Punto de equilibrio? |
| P07 | M4 U01 | $6,000 al mes con tarjeta a 2.9%. ¿Costo al mes? |
| P08 | M5 U03 | Ganancia neta $25,000. ¿Impuesto por cuenta propia aproximado? |
| P09 | M5 U04 | Ganancia del trimestre $6,000; apartas 25%. ¿Pago estimado? |
| P10 | M5 U05 | Ventas de $3,000 con tasa de 9.5%. ¿Sales tax? |
| P11 | M6 U03 | Adelanto de $8,000 con factor 1.3. ¿Total a pagar? |
| P12 | M7 U04 | Marca en tres clases con tarifa base. ¿Costo? |
| P13 | M8 U01 | 25 horas por semana a $16.90 durante 4 semanas. ¿Sueldo? |
| P14 | M9 U01 | Ganancias de $5,000 en 2026. ¿Cuántos créditos del Seguro Social? |

### Respuestas

- **P01:** $3,200 menos $1,900: $1,300.
- **P02:** $2,400 menos $600 menos $200: $1,600.
- **P03:** 450 por 72.5 centavos: $326.25.
- **P04:** $7 más $2: $9.
- **P05:** $48 entre 0.80: $60.
- **P06:** $4,500 entre 0.45: $10,000.
- **P07:** $174.
- **P08:** $25,000 por 92.35% por 15.3%: unos $3,532.
- **P09:** $1,500.
- **P10:** $285.
- **P11:** $10,400.
- **P12:** $1,050.
- **P13:** 100 horas por $16.90: $1,690.
- **P14:** $5,000 entre $1,890: 2 créditos.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu negocio y tu casa: dinero separado

- **Corte:** suma de ventas y gastos de un periodo para saber cuánto ganaste.
- **Cuenta del negocio:** cuenta que usas solo para cobrar y pagar cosas del negocio.
- **FDIC:** agencia federal que asegura los depósitos en bancos.
- **Ganancia:** lo que queda de las ventas después de pagar todos los costos del negocio.
- **Registro:** lista de lo que entra y sale del negocio, con fecha y concepto.
- **Sole proprietor (dueño único):** persona que tiene un negocio a su nombre, sin crear una empresa aparte.
- **Sueldo del dueño:** cantidad fija que te pasas del negocio cada semana o quincena.
- **Tarifa estándar por milla:** cantidad que el IRS permite deducir por cada milla manejada para el negocio.
- **Ventas:** todo lo que cobras a tus clientes, antes de restar lo que te costó.

### Costos y precio

- **Costo fijo:** gasto que pagas vendas o no, como una suscripción o tu sueldo.
- **Costo por unidad:** lo que te cuesta producir o vender una pieza, un platillo o un servicio, contando costos variables y una parte de los fijos.
- **Costo variable:** gasto que sube con cada venta, como material o empaques.
- **Inventario:** mercancía o insumos que compraste y todavía no vendes.
- **Margen de contribución:** lo que queda de cada venta después de pagar sus costos variables, para cubrir los fijos.
- **Margen:** parte del precio que queda después de cubrir el costo.
- **Merma:** mercancía que se echa a perder, se rompe o se pierde y ya no puedes vender.
- **Precio piso:** el precio mínimo que cubre tu costo.
- **Punto de equilibrio:** ventas mínimas para cubrir todos tus costos: ni ganas ni pierdes.
- **Rotación:** qué tan rápido se vende un producto.

### Flujo de efectivo

- **Corte de reclamos menores:** corte para cobrar montos pequeños sin abogado.
- **Depósito o anticipo:** parte del pago que el cliente da antes de que hagas el trabajo.
- **Factura (invoice):** documento con lo que vendiste, el monto y la fecha límite de pago.
- **Flujo de efectivo:** el dinero que realmente entra y sale del negocio, y cuándo.
- **Reserva del negocio:** dinero apartado para cubrir los costos fijos del negocio en meses flojos o imprevistos.
- **Temporada baja:** meses en que tu negocio vende menos.

### Cobrar y vender sin perder

- **Autenticación en dos pasos:** acceso con contraseña más un código o aprobación en tu teléfono.
- **Contracargo:** cuando el banco del cliente le regresa un pago con tarjeta porque lo desconoce o lo reclama.
- **Fraude del cheque de más:** engaño en el que te pagan de más con un cheque falso y te piden regresar la diferencia.
- **Pago pendiente:** pago que todavía no está disponible y puede no llegar.
- **Procesador de pagos:** empresa que te permite cobrar con tarjeta y cobra una comisión.
- **Suplantación de proveedor:** fraude en el que alguien se hace pasar por tu proveedor para que pagues a otra cuenta.

### Formalízate e impuestos sin miedo

- **1099-K:** formulario que reporta cobros por plataformas y procesadores de pago.
- **1099-NEC:** formulario que reporta pagos por servicios a trabajadores independientes.
- **DBA:** nombre comercial ficticio con el que operas.
- **Deducción:** gasto que se resta de tus ingresos para calcular impuestos.
- **Dueño único (sole proprietor):** persona que tiene un negocio a su nombre, sin crear una empresa aparte.
- **EIN:** número de identificación del empleador: número del negocio ante el IRS, gratuito.
- **Facilitador de mercado:** plataforma que cobra y entrega el sales tax por quienes venden en ella.
- **Impuesto sobre el trabajo por cuenta propia:** Seguro Social y Medicare que paga quien trabaja por su cuenta.
- **IP PIN:** número del IRS que protege tu declaración contra el robo de identidad.
- **ITIN:** número de identificación personal del contribuyente, para quien no puede tener SSN.
- **LLC:** compañía de responsabilidad limitada: empresa registrada en un estado que separa tus bienes personales de las deudas del negocio.
- **Pagos estimados:** pagos de impuestos que haces cada trimestre sobre lo que vas ganando.
- **QBI:** deducción de hasta 20% sobre la ganancia calificada de un negocio.
- **Sales tax:** impuesto sobre ventas que cobras a tu cliente y entregas al estado.
- **Seller's permit:** permiso de California para vender productos y cobrar impuesto sobre ventas.

### Crédito para tu negocio

- **Adelanto sobre ventas (MCA):** dinero a cambio de un porcentaje de tus ventas futuras, muy caro.
- **APR:** tasa de porcentaje anual: costo del crédito al año, con intereses y ciertas cuotas.
- **Capital de trabajo:** dinero para operar el día a día: mercancía, insumos y pagos.
- **CDFI:** institución financiera de desarrollo comunitario que presta a personas y negocios con menos acceso.
- **Cofirmante:** persona que firma un préstamo y se obliga a pagarlo si el deudor no paga.
- **Cooperativa de crédito (credit union):** institución financiera sin fines de lucro, propiedad de sus socios.
- **Escenario prudente:** cálculo con ventas menores a las esperadas.
- **Garantía personal:** compromiso de pagar tú si el negocio no paga.
- **Pago mínimo:** lo menos que puedes pagar de tu tarjeta; la deuda casi no baja.
- **Tasa de factor:** número por el que se multiplica el monto de un adelanto para saber el total a pagar.

### Protege tu negocio

- **Carta que imita al gobierno:** correo de una empresa privada que parece oficial para cobrarte servicios.
- **Certificado de seguro (COI):** documento que prueba que tienes seguro.
- **Clase:** grupo de productos o servicios que cubre un registro de marca.
- **Compensación al trabajador:** seguro que cubre lesiones de empleados en el trabajo.
- **Deducible:** lo que pagas tú antes de que el seguro empiece a pagar.
- **Inscripción abierta:** periodo del año para contratar o cambiar tu seguro médico.
- **Marca:** nombre, logotipo o combinación que distingue tu producto o servicio.
- **Prima:** lo que pagas cada mes por tu seguro.
- **Responsabilidad civil general:** seguro que paga daños que causas a otras personas o a sus bienes.
- **USPTO:** Oficina de Patentes y Marcas de Estados Unidos: registra marcas a nivel federal.

### Crecer con orden

- **Cobros brutos:** total cobrado antes de restar comisiones, devoluciones y costos.
- **Contratista independiente:** persona que tiene su propio negocio, decide cómo hace el trabajo y trabaja para varios clientes.
- **Impuestos de nómina:** impuestos que el empleador retiene y paga por sus empleados.
- **Plataforma:** sitio o app que conecta a vendedores y compradores y cobra una comisión.
- **Prueba ABC:** prueba de California para saber si alguien es empleado o contratista.
- **Tablero:** tabla con los números clave del negocio cada mes.
- **Ticket promedio:** lo que gasta en promedio cada cliente por compra: ventas entre número de ventas.

### Tu futuro

- **Crédito del Seguro Social:** unidad que ganas por tus ingresos; necesitas 40 para la pensión de retiro.
- **Disolución:** trámite formal para cerrar una empresa.
- **Fideicomiso en vida (living trust):** documento legal para pasar tus bienes sin un juicio largo.
- **IRA:** cuenta individual de retiro con beneficios fiscales.
- **Plan de una página:** resumen de las decisiones de tu negocio en una hoja.
- **Revisión trimestral:** revisión de tu plan cada tres meses.
- **SEP IRA:** cuenta de retiro para dueños de negocio y sus empleados.


## Dónde encontrar ayuda

Todas las opciones de esta tabla son oficiales o sin fines de lucro. Información consultada el 29 de septiembre de 2026; confírmala en el sitio oficial.

| Necesidad | Dónde | Costo | Qué verificar |
|---|---|---|---|
| EIN, ITIN, pagos estimados, 1099 | IRS: irs.gov/es | Gratis | Entra tú al sitio oficial |
| Preparar tu declaración | VITA (ingresos moderados); preparadores con PTIN; CPA | Gratis o con costo | Que firme y te dé copia |
| Asesoría para tu negocio | SBDC y SCORE (SBA) | Gratis o bajo costo | Asesores de la red oficial |
| Permisos en California | CalGold; tu ciudad y condado | Variable | Ventanilla oficial |
| Seller's permit y sales tax | CDTFA | Permiso sin costo | Tasa de tu ciudad |
| LLC y nombre del negocio | Secretary of State; tu condado (DBA) | Con costo | Sin intermediarios |
| Licencia de contratista | CSLB | Con costo | Límite de $1,000 |
| Empleadores y salario mínimo | EDD y DIR | Gratis | Prueba ABC |
| Préstamos | Bancos, cooperativas, CDFI, micropréstamos de la SBA | Según crédito | Licencia en el DFPI |
| Seguro médico | Covered California, Medi-Cal, clínicas comunitarias | Según ingreso | Consejeros certificados |
| Fraudes | ReportFraud.ftc.gov; IC3 del FBI | Gratis | Guarda evidencia |
| Robo de identidad | IdentityTheft.gov | Gratis | Plan de recuperación |
| Marca | USPTO; registro estatal | Con costo | Solo uspto.gov |
| Retiro | ssa.gov; CalSavers | Gratis | Tu cuenta en my Social Security |
| Dudas migratorias | Abogados u organizaciones acreditadas por el Departamento de Justicia | Gratis o con costo | Nunca «notarios» |

---

## Preguntas frecuentes

**¿Puedo tomar el curso si declaro con ITIN o aún no declaro?** Sí. El curso explica cómo funciona el sistema. Nunca te preguntamos tu situación.

**¿Tengo que dar datos reales de mi negocio?** No. Usa números inventados.

**¿El curso me dice si abrir una LLC?** Te explica qué protege y cuánto cuesta. La decisión la tomas con tu preparador o un abogado.

**¿Me recomiendan un banco, un procesador o una plataforma?** No. Te enseñamos a comparar.

**¿Qué hago si me llaman «del IRS»?** Cuelga y entra tú a irs.gov (M5 U04).

**¿Qué hago si me pagan de más y piden la diferencia?** No regreses nada: es fraude (M4 U03).

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo del programa. No es una licencia.

**¿Qué hago si un dato cambió?** Confírmalo en el sitio oficial y usa la información vigente.


## Referencias

Fuentes usadas en el curso, consultadas el 29 de septiembre de 2026.

### Instituciones

- **I01** IRS: EIN, ITIN (W-7), impuesto por cuenta propia, Schedule C y SE, pagos estimados (1040-ES), 1099-NEC y 1099-K, tarifa por milla, límites de retiro, VITA, IP PIN.
- **I02** SBA: estructuras de negocio, micropréstamos, SBDC y SCORE.
- **I03** Franchise Tax Board de California: impuesto mínimo de LLC e impuesto estatal.
- **I04** Secretary of State de California: LLC, declaración de información, disolución, marcas estatales.
- **I05** CDTFA: seller's permit y sales tax.
- **I06** CalGold: permisos por ciudad y giro.
- **I07** CSLB: licencia de contratista.
- **I08** EDD y DIR: empleadores, salario mínimo, prueba ABC, seguro de incapacidad.
- **I09** DFPI: licencias de prestamistas y divulgación de financiamiento comercial.
- **I10** CFPB, FTC e IC3: apps de pago, cofirmar, fraudes.
- **I11** FDIC y NCUA: seguro de depósitos.
- **I12** Covered California, DHCS y HealthCare.gov.
- **I13** USPTO: marcas.
- **I14** SSA: créditos y estimado de retiro.
- **I15** CalSavers.
- **I16** California Courts: reclamos menores.

### Leyes y disposiciones

- **L01** One Big Beautiful Bill Act (4 de julio de 2025): umbrales de 1099 y QBI permanente.
- **L02** Código de Rentas Internas: impuesto por cuenta propia y deducciones del negocio.
- **L03** Assembly Bill 2622 de California (límite de $1,000 para trabajos sin licencia).
- **L04** Ley de divulgación de financiamiento comercial de California.

### Comunicados y medios consultados

- **M01** IRS Notice 2026-10 e Internal Revenue Bulletin 2026-29 (tarifa por milla).
- **M02** Comunicado del IRS sobre límites de 401(k) e IRA para 2026.
- **M03** Tarifas publicadas de procesadores de pago (2026).


# Parte 12. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. ¿Tu negocio gana o solo vende?

**Caso 1. El mes de Lupita.** Lupita vendió más que nunca en diciembre por los tamales, pero pagó más ingredientes y ayuda. **¿Qué hace para saber si ganó?**

- ✔ Resta todos los costos del mes a sus ventas.
- Celebra: vendió más que nunca este mes.
- Cuenta solo lo que queda en su cuenta.

**Caso 2. Los pedidos de Daniela.** Daniela vendió 90 aretes en un mes, pero pagó envíos que no cobró. **¿Qué revisa?**

- ✔ Calcula cuánto le queda por pieza.
- Vende más aretes para compensar los envíos.
- Sube el precio de todo sin hacer cuentas antes.

**Caso 3. Las horas de Javier.** Javier cobra bien cada trabajo de pintura, pero pasa muchas horas manejando y cotizando sin cobrar. **¿Qué hace?**

- ✔ Calcula su ganancia por hora con traslados.
- Acepta más trabajos lejos para ganar más.
- Deja de cobrar las cotizaciones para competir.

## M1 U02. Separa el dinero del negocio y de tu casa

**Caso 1. La cuenta de Lupita.** Lupita recibe cobros del negocio y su sueldo en la misma cuenta. **¿Qué hace?**

- ✔ Abre una cuenta solo para el negocio.
- Sigue igual y separa todo en abril.
- Pide a sus clientes que paguen en efectivo.

**Caso 2. El material de Javier.** Javier compra pintura con la tarjeta de débito de su casa. **¿Qué hace?**

- ✔ La paga del negocio y guarda el recibo.
- La deja como gasto de su casa.
- La paga en efectivo sin guardar el recibo.

**Caso 3. El efectivo de Don Ramón.** Don Ramón guarda en su casa el efectivo del food truck durante semanas. **¿Qué hace?**

- ✔ Cuenta, anota y deposita seguido.
- Sigue guardándolo en casa por comodidad.
- Lo usa para gastos de la casa y luego repone.

## M1 U03. Págate un sueldo

**Caso 1. La buena semana de Lupita.** Lupita vendió el triple la semana de Navidad. **¿Qué hace?**

- ✔ Se paga lo normal y aparta el excedente.
- Saca todo lo extra para la casa esa semana.
- Se sube el sueldo desde esa semana.

**Caso 2. Los meses de Javier.** Javier gana $6,000 en verano y $2,000 en invierno. **¿Qué hace?**

- ✔ Se paga con base en su promedio.
- Se paga más en verano y nada en invierno.
- Espera a fin de año para ver cuánto sacar.

**Caso 3. Los impuestos de Daniela.** Daniela gasta toda su ganancia y no ha apartado para impuestos. **¿Qué hace desde hoy?**

- ✔ Aparta un % de cada ganancia para impuestos.
- Espera a abril para ver cuánto debe.
- Pide un préstamo cuando llegue la cuenta.

## M1 U04. Registros en 10 minutos al día

**Caso 1. Las capturas de Daniela.** Daniela tiene cientos de capturas de pagos del año. **¿Qué hace?**

- ✔ Pasa cada pago a su hoja el mismo día.
- Guarda las capturas y las suma en abril.
- Borra las capturas viejas para liberar espacio.

**Caso 2. Las millas de Javier.** Javier maneja a cotizar trabajos todos los días y no anota nada. **¿Qué hace?**

- ✔ Anota fecha, destino, motivo y millas.
- Calcula las millas a ojo en abril.
- Guarda solo los recibos de gasolina.

**Caso 3. La app de Don Ramón.** Una app gratuita pide a Don Ramón su número de Seguro Social y la contraseña de su banco para «hacer sus cuentas». **¿Qué hace?**

- ✔ No da su contraseña y elige otra opción.
- Se la da porque la app es gratis.
- Le da solo su número de Seguro Social.

## M2 U01. Costos fijos y variables

**Caso 1. Los aretes de Daniela.** Daniela cree que gana $19 por par porque el material cuesta $6 y los vende en $25. **¿Qué le falta sumar?**

- ✔ Empaque, envío, comisión y fijos.
- Nada: ya sabe que gana $19 por par.
- Solo el costo del envío de cada pedido.

**Caso 2. La hora de Javier.** Javier cobra $35 la hora, pero no sabe si le alcanza. **¿Qué calcula?**

- ✔ Su costo por hora con fijos y sueldo.
- Lo que cobran otros pintores por hora.
- El precio de su herramienta más cara.

**Caso 3. El seguro de Don Ramón.** Don Ramón paga el seguro del food truck una vez al año y nunca lo cuenta en sus costos. **¿Qué hace?**

- ✔ Lo divide entre 12 y lo suma a sus fijos.
- Lo paga cuando llega y no lo cuenta.
- Lo suma completo al mes en que lo paga.

## M2 U02. ¿Cuánto cobrar?

**Caso 1. El precio de Javier.** Javier cobra lo mismo que otros pintores, aunque sus costos son mayores. **¿Qué hace?**

- ✔ Calcula su costo y pone precio con margen.
- Cobra lo mismo que los demás pintores.
- Baja su tarifa para ganar más clientes.

**Caso 2. La oferta de Daniela.** Daniela quiere bajar sus aretes a $15 para vender más. **¿Qué revisa?**

- ✔ Que $15 cubra su costo y deje margen.
- Nada: bajar siempre aumenta la ganancia.
- Solo lo que cobra la tienda más barata.

**Caso 3. El aumento de Lupita.** La masa y la carne subieron y los tamales de Lupita ya casi no dejan. **¿Qué hace?**

- ✔ Recalcula su costo y avisa del aumento.
- Hace tamales más pequeños sin avisar.
- Espera a que los precios bajen solos.

## M2 U03. Tu punto de equilibrio

**Caso 1. El espacio de Don Ramón.** Le suben a Don Ramón $400 al mes el espacio donde se estaciona. **¿Qué hace?**

- ✔ Recalcula su equilibrio y meta diaria.
- Sigue igual: $400 no es mucho.
- Da más crédito para vender más ese mes.

**Caso 2. Los tamales de Lupita.** Lupita vende 6 docenas por semana y su equilibrio es de 8. **¿Qué hace?**

- ✔ Sube ventas, precio o baja costos.
- Sigue igual hasta fin de año.
- Pide un préstamo para cubrir la diferencia.

**Caso 3. El local de Daniela.** Daniela quiere rentar un pequeño local por $900 al mes. **¿Qué calcula antes?**

- ✔ Cuánto tendría que vender de más.
- Nada: un local siempre vende más.
- Solo si el local tiene buena ubicación.

## M2 U04. Inventario y merma

**Caso 1. La oferta a Don Ramón.** El proveedor ofrece a Don Ramón una caja gratis si compra 10 de un producto que vende poco. **¿Qué hace?**

- ✔ Compra solo lo que vende a tiempo.
- Compra las 10 cajas por el regalo.
- Compra 20 para que le regalen dos.

**Caso 2. Los ingredientes de Lupita.** Lupita tira chiles y hojas cada semana. **¿Qué hace?**

- ✔ Anota lo que tira y compra menos.
- Compra más para tener variedad.
- Sigue igual; la merma es normal.

**Caso 3. Los collares de Daniela.** Daniela tiene 50 collares de un modelo que no se vendió. **¿Qué hace?**

- ✔ Los ofrece con descuento y no repite.
- Los guarda por si vuelven a venderse.
- Compra más del mismo modelo más barato.

## M3 U01. Ganar no es tener efectivo

**Caso 1. El pago tardío a Javier.** El contratista le paga a Javier a 30 días y él necesita material ya. **¿Qué hace?**

- ✔ Pide depósito y plazo a su proveedor.
- Pide un adelanto rápido sobre sus ventas.
- Deja el trabajo hasta que le paguen.

**Caso 2. La compra de Don Ramón.** Don Ramón quiere comprar de una vez todos los insumos de un festival y se quedaría sin efectivo dos semanas. **¿Qué hace?**

- ✔ Compra en partes o con plazo.
- Compra todo de una vez por el precio.
- Usa su tarjeta personal para todo.

**Caso 3. El adelanto de Daniela.** A Daniela le faltan $300 para pagar a su proveedor y una app le ofrece un adelanto sobre sus ventas futuras. **¿Qué hace antes?**

- ✔ Revisa su reserva y pide plazo.
- Acepta el adelanto porque es rápido.
- Paga con la tarjeta de su casa.

## M3 U02. Crédito a clientes, facturas y cobranza

**Caso 1. Los pedidos de Lupita.** Un cliente de Lupita pide 20 docenas para una boda y promete pagar después. **¿Qué hace?**

- ✔ Pide 50% de depósito y todo por escrito.
- Entrega todo y confía en que le paguen.
- Le pide que pague en efectivo después.

**Caso 2. La factura de Javier.** Una factura de Javier de $1,200 lleva 45 días de atraso. **¿Qué hace?**

- ✔ Recuerda por escrito y usa reclamos menores.
- Publica el nombre del cliente en redes.
- Deja de hablarle hasta que pague.

**Caso 3. El cliente de Don Ramón.** Una oficina le pide a Don Ramón comida cada viernes y pagar a fin de mes. **¿Qué hace?**

- ✔ Acepta con acuerdo, factura y límite.
- Acepta sin límite por ser una oficina.
- Rechaza el cliente por miedo a no cobrar.

## M3 U03. Tu reserva y las temporadas bajas

**Caso 1. El invierno de Don Ramón.** Don Ramón sabe que enero y febrero son flojos. **¿Qué hace en verano?**

- ✔ Aparta un % de cada venta.
- Gasta lo del verano y ve qué pasa en enero.
- Compra más inventario para el invierno.

**Caso 2. El efectivo de Lupita.** Lupita guarda su reserva en efectivo en su cocina. **¿Qué hace?**

- ✔ La pasa a una cuenta de ahorro asegurada.
- La deja en la cocina; está a la mano.
- La presta a una vecina para que crezca.

**Caso 3. La tarifa de Daniela.** Daniela tiene una LLC y paga una tarifa anual al estado. **¿Qué hace desde enero?**

- ✔ Divide entre 12 y lo aparta cada mes.
- Pide prestado cuando llegue la tarifa.
- La paga con la reserva de impuestos.

## M4 U01. Efectivo, tarjeta, apps o link de pago

**Caso 1. El lector de Don Ramón.** A Don Ramón le ofrecen un lector «gratis» con contrato de dos años. **¿Qué hace?**

- ✔ Calcula el costo total y lee el contrato.
- Lo acepta porque el lector es gratis.
- Rechaza cualquier lector por costoso.

**Caso 2. Los cobros de Lupita.** Lupita cobra sus pedidos en su app personal de pagos. **¿Qué hace?**

- ✔ Usa la opción de negocio conectada.
- Sigue en su app personal; nadie se da cuenta.
- Pide a todos que paguen en efectivo.

**Caso 3. El link de Daniela.** Daniela quiere cobrar con link a clientes que no conoce. **¿Qué revisa?**

- ✔ Comisión, depósito y contracargos.
- Solo el diseño del link de pago.
- Nada: los links siempre son seguros.

## M4 U02. Cobros por apps y transferencias seguras

**Caso 1. La captura de Daniela.** Un cliente manda a Daniela una captura y pide que envíe ya. **¿Qué hace?**

- ✔ Envía cuando el pago esté disponible.
- Envía con la captura para no perder la venta.
- Pide una segunda captura y envía.

**Caso 2. El correo a Lupita.** Lupita recibe un correo de «su app de pagos»: el pago de un cliente está detenido hasta que ella pague $50. **¿Qué hace?**

- ✔ No paga y revisa dentro de la app.
- Paga los $50 para liberar el pago.
- Responde el correo con sus datos.

**Caso 3. El código de Javier.** Un supuesto cliente le pide a Javier el código que le llegó «para confirmar su identidad». **¿Qué hace?**

- ✔ No da el código; basta su usuario.
- Da el código para recibir el pago.
- Da el código si es cliente frecuente.

## M4 U03. Fraudes al vender

**Caso 1. El cheque de Javier.** Un cliente manda a Javier un cheque de $2,500 por un trabajo de $1,500 y pide $1,000 de vuelta. **¿Qué hace?**

- ✔ No lo deposita y pide el monto exacto.
- Lo deposita y regresa $1,000 cuando aparezca.
- Regresa la mitad mientras revisa.

**Caso 2. El pedido de Daniela.** Un desconocido pide a Daniela 40 collares con envío urgente a otro estado y paga con link. **¿Qué hace?**

- ✔ Desconfía y verifica antes de enviar.
- Envía rápido para no perder la venta.
- Envía la mitad y espera el resto.

**Caso 3. El proveedor de Don Ramón.** Un correo «de su proveedor de carne» pide pagar la factura a una cuenta nueva. **¿Qué hace?**

- ✔ Llama al número que ya tenía.
- Paga a la nueva cuenta para no atrasarse.
- Responde el correo para confirmar.

## M5 U01. ¿Dueño único, LLC u otra forma?

**Caso 1. La LLC de Javier.** Un sitio le cobra a Javier $299 por abrir una LLC «obligatoria». **¿Qué hace?**

- ✔ Compara costos y usa el sitio oficial.
- Paga los $299 porque es obligatoria.
- Abre tres LLC para separar sus trabajos.

**Caso 2. El nombre de Lupita.** Lupita vende como «Tamales Lupita» y es dueña única. **¿Qué hace?**

- ✔ Registra su nombre comercial en el condado.
- Usa el nombre sin registrar nada.
- Abre una corporación para usar el nombre.

**Caso 3. La cuenta de la LLC de Daniela.** Daniela tiene una LLC, pero cobra en su cuenta personal. **¿Qué hace?**

- ✔ Abre una cuenta solo de la LLC.
- Sigue igual; la LLC la protege siempre.
- Cierra la LLC para no complicarse.

## M5 U02. Números y permisos: EIN, ITIN y licencias

**Caso 1. El EIN de Lupita.** Un sitio cobra a Lupita $150 por tramitar su EIN. **¿Qué hace?**

- ✔ Lo tramita gratis en irs.gov con su ITIN.
- Paga los $150 para ahorrar tiempo.
- Usa el EIN de una amiga.

**Caso 2. El trabajo grande de Javier.** A Javier le ofrecen remodelar un baño por $4,000. **¿Qué revisa?**

- ✔ Que necesita licencia de la CSLB.
- Nada: divide el trabajo en partes.
- Solo que el cliente le pague en efectivo.

**Caso 3. El notario de Don Ramón.** Un «notario» ofrece a Don Ramón arreglar sus papeles migratorios y sus permisos por $2,000. **¿Qué hace?**

- ✔ Busca un abogado u organización acreditada.
- Le paga al notario porque habla español.
- Le paga la mitad para empezar.

## M5 U03. Tus impuestos federales como dueño

**Caso 1. La sorpresa de Daniela.** Daniela debe más de $2,000 al IRS y no apartó nada. **¿Qué hace desde hoy?**

- ✔ Aparta 25% y guarda recibos.
- Espera a abril y paga lo que pueda.
- Deja de declarar para no deber.

**Caso 2. Los recibos de Javier.** Javier no guarda los recibos de pintura porque «el IRS no los pide». **¿Qué hace?**

- ✔ Los guarda para demostrar deducciones.
- Los tira porque nadie los pide.
- Guarda solo los de más de $600.

**Caso 3. La ganancia pequeña de Lupita.** Lupita ganó $3,000 limpios en el año y cree que no tiene que declarar. **¿Qué revisa?**

- ✔ Revisa que desde $400 debe declarar.
- No declara porque ganó poco.
- Declara solo si recibió un 1099.

## M5 U04. Pagos trimestrales y formularios 1099

**Caso 1. El 1099 de Javier.** Javier recibió un 1099-NEC por $6,000 de un contratista. **¿Qué hace?**

- ✔ Lo incluye en su declaración.
- Lo ignora porque ya lo reportó el cliente.
- Le pide al cliente que lo cancele.

**Caso 2. La llamada a Don Ramón.** Una llamada «del IRS» exige a Don Ramón pagar hoy con tarjetas de regalo. **¿Qué hace?**

- ✔ Cuelga y revisa su cuenta en irs.gov.
- Compra las tarjetas para evitar el arresto.
- Da sus datos para aclarar el caso.

**Caso 3. Las ventas de Daniela.** Daniela vendió $9,000 en una plataforma y no recibió 1099-K. **¿Qué hace?**

- ✔ Declara esas ventas.
- No las declara porque no llegó 1099-K.
- Declara solo la mitad de lo vendido.

## M5 U05. El impuesto sobre ventas (sales tax)

**Caso 1. La comida de Lupita.** Lupita no sabe si su comida lleva impuesto. **¿Qué hace?**

- ✔ Consulta al CDTFA y lo separa al cobrar.
- No cobra nada porque es comida.
- Cobra 7.25% a todo por si acaso.

**Caso 2. La tienda en línea de Daniela.** Daniela vende en una plataforma grande y también por su página. **¿Qué revisa?**

- ✔ Que en su página le toca cobrarlo a ella.
- Nada: la plataforma cobra por todas sus ventas.
- Que no debe cobrar impuesto en ningún lado.

**Caso 3. Los servicios de Javier.** Javier cree que debe cobrar sales tax por pintar. **¿Qué revisa?**

- ✔ Que muchos servicios no llevan y consulta.
- Cobra sales tax por cada hora de trabajo.
- Cobra impuesto solo a clientes nuevos.

## M6 U01. ¿Necesitas crédito?

**Caso 1. El equipo de Don Ramón.** Don Ramón calcula que el préstamo se paga solo, pero con ventas optimistas. **¿Qué hace?**

- ✔ Revisa un escenario prudente.
- Firma: las cuentas salen con ventas altas.
- Pide más para comprar también una camioneta.

**Caso 2. Las pérdidas de Lupita.** Lupita pierde dinero desde hace tres meses y le ofrecen un préstamo. **¿Qué hace?**

- ✔ Corrige precio y costos primero.
- Toma el préstamo para aguantar unos meses.
- Pide un préstamo más grande para crecer.

**Caso 3. El contrato de Javier.** Javier tiene un contrato firmado y necesita material para cumplirlo. **¿Qué revisa primero?**

- ✔ Si el cliente da depósito.
- El préstamo más rápido que encuentre.
- Cuánto le prestan como máximo.

## M6 U02. Opciones de crédito y cómo verificarlas

**Caso 1. El mensaje a Lupita.** Un mensaje ofrece a Lupita $5,000 si deposita $200 de cuota de apertura. **¿Qué hace?**

- ✔ No deposita y busca opciones verificadas.
- Deposita $200 porque la oferta es buena.
- Deposita solo si le mandan contrato.

**Caso 2. El adelanto de Don Ramón.** Una empresa ofrece a Don Ramón $10,000 a cambio de 15% de sus ventas diarias. **¿Qué hace?**

- ✔ Calcula el costo total y compara.
- Acepta porque le dan el dinero hoy.
- Acepta y pide $20,000 de una vez.

**Caso 3. El préstamo de Daniela.** Daniela tiene ITIN y cree que ningún lugar le prestará. **¿Qué hace?**

- ✔ Busca cooperativas y CDFI con ITIN.
- Pide un adelanto sobre ventas; no piden papeles.
- Pide prestado a un prestamista informal.

## M6 U03. El costo total: APR, cuotas y garantías

**Caso 1. Las dos ofertas de Don Ramón.** Don Ramón compara un préstamo con APR de 14% contra un adelanto con factor de 1.35. **¿Qué hace?**

- ✔ Pide el total a pagar y compara.
- Elige el adelanto porque es más rápido.
- Elige el pago diario más bajo.

**Caso 2. La garantía de Javier.** Un préstamo para una camioneta pide a Javier poner su casa en garantía. **¿Qué hace?**

- ✔ Busca otra opción sin arriesgar su casa.
- Acepta: la camioneta lo vale.
- Pone la casa y pide un monto mayor.

**Caso 3. El pago extra de Daniela.** Daniela tuvo un buen mes y quiere adelantar pagos de su préstamo. **¿Qué pregunta?**

- ✔ Si hay penalización y que vaya al capital.
- Nada: adelantar siempre ahorra igual.
- Que el pago se aplique a intereses futuros.

## M6 U04. No mezcles deudas y cuida con ser cofirmante

**Caso 1. La tarjeta de Daniela.** Daniela debe $4,500 en su tarjeta personal por material. **¿Qué hace?**

- ✔ Deja de usarla y la paga del negocio.
- Paga el mínimo y sigue comprando.
- Saca otra tarjeta para pagar la primera.

**Caso 2. El cofirmante.** El sobrino de Don Ramón le pide ser cofirmante de un auto de $520 al mes. **¿Qué hace?**

- ✔ No acepta y le ayuda a buscar otra opción.
- Acepta porque es familia.
- Acepta y le pide que no se atrase.

**Caso 3. El préstamo a la comadre.** La comadre de Lupita le pide $400 del dinero del negocio. **¿Qué hace?**

- ✔ Presta de su sueldo, por escrito.
- Presta de la cuenta del negocio.
- Presta con la tarjeta del negocio.

## M7 U01. Tu salud si trabajas por tu cuenta

**Caso 1. La espalda de Javier.** Javier no tiene seguro médico y trabaja por su cuenta. **¿Qué hace?**

- ✔ Revisa el mercado y Medi-Cal.
- Espera a ver si se vuelve a lastimar.
- Paga consultas privadas cuando pase algo.

**Caso 2. El cambio de Lupita.** Lupita dejó su trabajo de medio tiempo y perdió su seguro del empleador en junio. **¿Qué hace?**

- ✔ Revisa si puede inscribirse por ese cambio.
- Espera a noviembre sin seguro.
- Compra un seguro que encontró en redes.

**Caso 3. El ingreso de Daniela.** Daniela recibe ayuda para su prima y sus ventas subieron mucho. **¿Qué hace?**

- ✔ Actualiza su ingreso estimado.
- No dice nada hasta declarar.
- Cancela el seguro para no deber.

## M7 U02. Seguros para tu negocio

**Caso 1. El incendio del food truck.** El seguro personal de Don Ramón no cubrió el incendio de su food truck. **¿Qué hace?**

- ✔ Contrata un seguro comercial completo.
- Sigue con su seguro personal de auto.
- Deja de ir a ferias para no arriesgarse.

**Caso 2. El contratista de Javier.** Un contratista pide a Javier su certificado de seguro para darle trabajo. **¿Qué hace?**

- ✔ Contrata responsabilidad civil y pide su COI.
- Le dice al contratista que no hace falta.
- Pide prestado el certificado de un amigo.

**Caso 3. El ayudante de Lupita.** Lupita contratará a un ayudante como empleado. **¿Qué revisa?**

- ✔ Que necesita compensación al trabajador.
- Nada: es solo medio tiempo.
- Que basta con su seguro de casa.

## M7 U03. Fraudes a negocios

**Caso 1. La carta de Daniela.** Una carta «oficial» cobra a Daniela $243 por un certificado de su LLC. **¿Qué hace?**

- ✔ Revisa el remitente y verifica en el sitio oficial.
- Paga los $243 para evitar la multa.
- Llama al número que viene en la carta.

**Caso 2. La llamada a Lupita.** Alguien «del departamento de salud» exige a Lupita pagar una multa por teléfono hoy. **¿Qué hace?**

- ✔ Cuelga y llama al número oficial.
- Paga la multa para no perder el permiso.
- Da los datos de su tarjeta para aclarar.

**Caso 3. El correo del proveedor.** Un correo del proveedor de Javier dice que cambió de cuenta. **¿Qué hace?**

- ✔ Llama al número que ya tenía.
- Paga a la nueva cuenta para no atrasarse.
- Responde el correo para confirmar.

## M7 U04. Tu marca y tu nombre

**Caso 1. La marca de Daniela.** Una tienda dice a Daniela que «Luna Morena» es su marca. **¿Qué hace?**

- ✔ Verifica en la USPTO y decide.
- Ignora el mensaje porque llegó primero.
- Registra su cuenta de redes como prueba.

**Caso 2. El nombre del food truck.** Don Ramón quiere pintar un nombre nuevo en su food truck. **¿Qué hace antes?**

- ✔ Busca en la USPTO y en su estado.
- Pinta el nombre y luego revisa.
- Pregunta a sus clientes si les gusta.

**Caso 3. El correo a Javier.** Javier recibe un correo que cobra $1,200 por «proteger su marca internacionalmente». **¿Qué hace?**

- ✔ Revisa el dominio y no paga.
- Paga para proteger su marca afuera.
- Paga la mitad y pide factura.

## M8 U01. Contratar ayuda

**Caso 1. La vecina de Lupita.** Lupita quiere pagar a su vecina en efectivo «como contratista» para trabajar en su cocina con su horario. **¿Qué hace?**

- ✔ Se registra como empleadora.
- Le paga en efectivo como contratista.
- Le pide que trabaje gratis unos meses.

**Caso 2. El ayudante de Javier.** Javier quiere que un ayudante le ayude en un trabajo de pintura de $3,000. **¿Qué revisa?**

- ✔ Que necesita licencia y compensación.
- Nada: el ayudante es su primo.
- Solo que el ayudante tenga ITIN.

**Caso 3. El diseñador de Daniela.** Daniela contrata a un diseñador independiente para su logo por $400. **¿Qué hace?**

- ✔ Pide su W-9 y guarda la factura.
- Le envía un W-2 como empleado.
- No guarda nada porque fue poco.

## M8 U02. Vender en línea y en plataformas

**Caso 1. El precio en plataforma.** Daniela vende igual en la plataforma que en su página. **¿Qué revisa?**

- ✔ Que cubra comisiones, envío y anuncios.
- Nada: el precio debe ser igual en todos lados.
- Solo el costo del envío del pedido.

**Caso 2. El 1099-K de Daniela.** Daniela recibió un 1099-K por $24,000 brutos. **¿Qué hace?**

- ✔ Declara y resta costos con sus registros.
- Declara los $24,000 como ganancia.
- No declara porque la plataforma ya reportó.

**Caso 3. Los anuncios de Lupita.** Lupita paga $100 al mes en anuncios y no sabe si le traen ventas. **¿Qué hace?**

- ✔ Mide ventas y ganancia de los anuncios.
- Sube a $300 al mes para vender más.
- Los quita sin revisar nada.

## M8 U03. Tus números del mes

**Caso 1. El margen de Don Ramón.** El margen de Don Ramón bajó cinco puntos. **¿Qué hace?**

- ✔ Revisa costos y ajusta.
- Vende más para compensar el margen.
- Sigue igual; un mes no dice nada.

**Caso 2. Las ventas de Daniela.** Las ventas de Daniela bajaron en enero frente a diciembre. **¿Con qué compara?**

- ✔ Con enero del año pasado.
- Con el mejor mes del año.
- Con diciembre de este año.

**Caso 3. El ticket de Lupita.** Lupita tiene muchos clientes, pero cada uno compra poco. **¿Qué prueba?**

- ✔ Un combo o bebida para subir el ticket.
- Abre más horas para tener más clientes.
- Baja precios para que compren más.

## M9 U01. Tu retiro si trabajas por tu cuenta

**Caso 1. El retiro de Don Ramón.** Don Ramón no sabe cuánto recibiría del Seguro Social. **¿Qué hace?**

- ✔ Revisa su estimado en ssa.gov.
- Supone que no le tocará nada.
- Pregunta en su banco cuánto recibirá.

**Caso 2. La SEP de Javier.** Javier ganó bien este año y quiere pagar menos impuestos y ahorrar. **¿Qué revisa?**

- ✔ Revisa SEP IRA o Solo 401(k).
- Compra equipo que no necesita para deducir.
- Espera a retirarse para pensarlo.

**Caso 3. El ahorro de Daniela.** Daniela tiene 27 años y cree que es muy pronto para el retiro. **¿Qué hace?**

- ✔ Empieza con una aportación pequeña.
- Espera a ganar más para empezar.
- Invierte todo en su inventario.

## M9 U02. Si el negocio cambia o si faltas

**Caso 1. La enfermedad de Lupita.** La hija de Lupita no sabía cómo seguir con los pedidos. **¿Qué prepara Lupita?**

- ✔ Una carpeta con proveedores y cuentas.
- Le escribe sus contraseñas a su hija.
- Nada: no volverá a enfermarse.

**Caso 2. La LLC de Daniela.** Daniela dejará de vender y ya no usará su LLC. **¿Qué hace?**

- ✔ La disuelve formalmente.
- Deja de usarla sin avisar.
- Cancela solo la cuenta del banco.

**Caso 3. El food truck de Don Ramón.** Don Ramón quiere que su hija se quede con el food truck en unos años. **¿Qué hace?**

- ✔ Un acuerdo por escrito y su testamento.
- Se lo dice de palabra a su hija.
- Espera a retirarse para pensarlo.

## M9 U03. Tu plan de una página

**Caso 1. La hoja de Daniela.** A Daniela le faltan su cuenta de retiro y su marca. **¿Qué hace?**

- ✔ Las pone como metas del trimestre.
- Hace todo esta misma semana.
- Las deja para el año próximo.

**Caso 2. Las prioridades de Javier.** Javier tiene muchas tareas pendientes y no sabe por dónde empezar. **¿Qué hace?**

- ✔ Separar dinero, impuestos y precio.
- Registrar su marca primero.
- Pedir un préstamo para ordenarse.

**Caso 3. La revisión de Don Ramón.** Don Ramón hizo su plan hace tres meses y no lo ha revisado. **¿Qué hace?**

- ✔ Pone fecha fija y actualiza.
- Hace un plan nuevo desde cero.
- Lo deja; ya sabe lo que tiene que hacer.

# Parte 13. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** Vendes $3,000 y tus costos son $2,200. ¿Cuánto ganas?

- ✔ $800
- $3,000
- $5,200

*¡Correcto! $3,000 menos $2,200.*

**M1 U01 P2.** ¿Qué es la ganancia?

- Todo lo que cobras a tus clientes en el mes, en efectivo y por apps
- ✔ Lo que queda después de pagar todos los costos
- Lo que hay en tu cuenta al cerrar

*¡Correcto! Ventas menos costos.*

**M1 U01 P3.** Tus ventas y tus costos son iguales. ¿Qué pasa?

- Ganas poco, pero el negocio sí te deja algo
- Pierdes dinero cada mes
- ✔ Sales tablas: trabajas gratis

*¡Correcto! No queda nada para ti.*

**M1 U02 P1.** ¿Desde dónde pagas el material del negocio?

- Desde tu cuenta de la casa
- ✔ Desde la cuenta del negocio
- Desde lo que haya ese día en tu cartera o en la caja

*¡Correcto! Cada bolsa paga lo suyo.*

**M1 U02 P2.** Usas $200 del negocio para una emergencia de tu casa. ¿Qué haces?

- Lo olvidas, total es tu negocio
- Lo cubres con tu tarjeta de crédito y te olvidas del tema
- ✔ Lo anotas como préstamo y lo devuelves

*¡Correcto! Así no se pierde.*

**M1 U02 P3.** ¿Hasta cuánto asegura el FDIC por persona, por banco y por tipo de cuenta?

- ✔ $250,000
- $25,000
- Todo lo que tengas, sin límite

*¡Correcto! Por persona, banco y tipo de cuenta.*

**M1 U03 P1.** Tu ganancia es $2,000 y apartas 25% para impuestos. ¿Cuánto apartas?

- $250
- $2,000
- ✔ $500

*¡Correcto! 25% de $2,000.*

**M1 U03 P2.** Tuviste una semana excelente. ¿Qué haces?

- ✔ Te pagas tu sueldo y apartas el excedente
- Sacas todo lo extra para la casa porque te lo ganaste
- Te subes el sueldo desde ese día

*¡Correcto! El excedente se aparta.*

**M1 U03 P3.** ¿Por qué apartas impuestos como dueño?

- ✔ Porque nadie te los retiene
- Porque el banco te lo pide al abrir la cuenta
- No hace falta: se pagan solos

*¡Correcto! Los pagas tú.*

**M1 U04 P1.** ¿Qué es lo mínimo que anotas cada día?

- Solo las ventas grandes
- Lo que recuerdes el domingo
- ✔ Fecha, ventas y gastos

*¡Correcto! Con eso basta.*

**M1 U04 P2.** ¿Qué necesitas para deducir millas?

- ✔ Un registro de cada viaje
- Solo el recibo de gasolina del mes
- Nada, se calcula solo

*¡Correcto! Sin registro no hay deducción.*

**M1 U04 P3.** Una app te pide la contraseña de tu banco. ¿Qué haces?

- Se la das si es gratis y tiene buenas reseñas
- ✔ No se la das y eliges otra herramienta
- Le das solo tu número de Seguro Social

*¡Correcto! Pide de más.*

## Módulo 2

**M2 U01 P1.** ¿Cuál de estos es un costo variable?

- La suscripción de tu tienda en línea
- ✔ El empaque de cada pedido
- Tu plan de teléfono

*¡Correcto! Sube con cada venta.*

**M2 U01 P2.** Tus fijos son $600 y vendes 200 piezas al mes. ¿Cuánto fijo le toca a cada pieza?

- ✔ $3
- $30
- $600

*¡Correcto! $600 entre 200.*

**M2 U01 P3.** ¿Tu sueldo es un costo del negocio?

- No, es ganancia
- Solo si te sobra algo al final del mes
- ✔ Sí, es un costo fijo

*¡Correcto! Sin él trabajas gratis.*

**M2 U02 P1.** Tu costo es $35. ¿Cuál es el precio mínimo para un margen de 30% sobre el precio?

- $45.50
- $35
- ✔ $50

*¡Correcto! $35 entre 0.70.*

**M2 U02 P2.** ¿Cuándo nunca debes vender?

- ✔ Por debajo de tu costo
- Más caro que la competencia
- Con garantía por escrito para tu cliente

*¡Correcto! Pierdes con cada venta.*

**M2 U02 P3.** Tus materiales subieron. ¿Qué haces?

- Usas material más barato sin avisar a tus clientes
- ✔ Recalculas tu costo y avisas del nuevo precio
- Esperas a que bajen solos

*¡Correcto! Con aviso y claridad.*

**M2 U03 P1.** Fijos de $3,000 y cada venta te deja 50%. ¿Punto de equilibrio?

- $1,500
- ✔ $6,000
- $3,500

*¡Correcto! $3,000 entre 0.50.*

**M2 U03 P2.** Vendes menos que tu punto de equilibrio. ¿Qué pasa?

- Ganas poco
- Estás igual
- ✔ Pierdes dinero

*¡Correcto! No cubres tus costos.*

**M2 U03 P3.** ¿Qué baja tu punto de equilibrio?

- ✔ Bajar costos fijos
- Rentar un local más grande en una mejor zona
- Dar más crédito a tus clientes

*¡Correcto! Necesitas vender menos.*

**M2 U04 P1.** ¿Qué es la merma?

- El descuento que te da el proveedor por volumen
- ✔ Lo que se echa a perder o ya no puedes vender
- La mercancía nueva

*¡Correcto! Dinero tirado.*

**M2 U04 P2.** Tienes 30 piezas que no se venden. ¿Qué haces?

- ✔ Las ofreces con descuento
- Compras más para exhibir
- Las guardas por si acaso

*¡Correcto! Dinero parado.*

**M2 U04 P3.** ¿Cuándo conviene una oferta de «lleva más»?

- Siempre
- Si el proveedor es de confianza y te da buen precio
- ✔ Si vendes todo antes de que caduque

*¡Correcto! Si no, sale cara.*

## Módulo 3

**M3 U01 P1.** Tienes $600, cobrarás $900 y pagarás $1,700 esta semana. ¿Cómo terminas?

- Con $200 de sobra
- Con $3,200
- ✔ Con $200 de faltante

*¡Correcto! $600 más $900 menos $1,700.*

**M3 U01 P2.** ¿Qué mejora tu flujo?

- Pagar antes a tus proveedores para que te traten mejor
- ✔ Pedir depósito en trabajos grandes
- Dar más plazo a tus clientes

*¡Correcto! Cobras antes.*

**M3 U01 P3.** Tu calendario muestra un hueco en tres semanas. ¿Qué haces?

- ✔ Buscas soluciones desde hoy
- Esperas a ver si se arregla
- Pides un adelanto rápido el día que falte

*¡Correcto! Actúa antes.*

**M3 U02 P1.** ¿Qué es vender a crédito para tu negocio?

- Una venta ya cobrada
- ✔ Un préstamo sin intereses a tu cliente
- Una ganancia extra

*¡Correcto! Dinero que no ha regresado.*

**M3 U02 P2.** Un cliente no ha pagado y pide otro pedido. ¿Qué haces?

- Le entregas para no perderlo
- Publicas su nombre en tus redes para presionarlo
- ✔ No le das más crédito hasta que pague

*¡Correcto! Regla clara.*

**M3 U02 P3.** ¿Qué pides en un pedido grande?

- ✔ Un depósito y el acuerdo por escrito
- Solo su número de teléfono
- Nada: la confianza basta

*¡Correcto! Te protege.*

**M3 U03 P1.** Costos fijos de $1,500 al mes. ¿Reserva para 3 meses?

- $500
- $1,500
- ✔ $4,500

*¡Correcto! $1,500 por 3.*

**M3 U03 P2.** ¿Dónde conviene guardar la reserva?

- ✔ En una cuenta de ahorro asegurada
- En efectivo en tu casa, donde siempre la tienes a la mano
- En más inventario

*¡Correcto! Protegida y disponible.*

**M3 U03 P3.** Tu seguro cuesta $1,200 al año. ¿Cuánto apartas al mes?

- $120
- ✔ $100
- $1,200

*¡Correcto! $1,200 entre 12.*

## Módulo 4

**M4 U01 P1.** Cobras $5,000 al mes con tarjeta y la comisión es 3%. ¿Cuánto pagas?

- ✔ $150
- $500
- $15

*¡Correcto! 3% de $5,000.*

**M4 U01 P2.** ¿Los cobros por apps de pago son ingreso del negocio?

- No, si son menos de $600
- ✔ Sí, llegue por donde llegue
- Solo si recibes un formulario 1099-K

*¡Correcto! Todo ingreso se declara.*

**M4 U01 P3.** Opción A: 2.6% sin cargo mensual. Opción B: 2.3% más $30 al mes. Vendes $4,000 con tarjeta. ¿Cuál es más barata, sin contar cuotas fijas?

- ✔ La A: $104
- La B: $122
- Cuestan igual

*¡Correcto! $104 contra $92 más $30.*

**M4 U02 P1.** ¿Cuándo entregas un pedido pagado por app?

- Cuando te mandan la captura
- Cuando el cliente te jura por teléfono que ya pagó
- ✔ Cuando el dinero está disponible en tu cuenta

*¡Correcto! La captura no es prueba.*

**M4 U02 P2.** ¿Qué compartes para que te paguen?

- ✔ Tu usuario o correo de cobro
- Tu contraseña
- El código que te llegó por mensaje

*¡Correcto! Basta para cobrar.*

**M4 U02 P3.** Un correo dice que tu pago está detenido hasta que pagues una «actualización». ¿Qué es?

- Un trámite normal de la app
- ✔ Un fraude: revisa dentro de la app
- Un cargo de tu banco

*¡Correcto! Las apps no cobran así.*

**M4 U03 P1.** Te pagan de más con un cheque y piden la diferencia. ¿Qué haces?

- Regresas la diferencia en cuanto el cheque aparece disponible
- ✔ No regresas nada y pides el monto exacto
- Regresas la mitad

*¡Correcto! Es el fraude del cheque.*

**M4 U03 P2.** Tu proveedor te escribe que cambió de cuenta. ¿Qué haces?

- Pagas a la nueva cuenta
- Respondes al mismo correo para confirmar
- ✔ Llamas al número que ya tenías

*¡Correcto! Confirma por otro medio.*

**M4 U03 P3.** ¿Cuál es una señal de fraude al vender?

- ✔ Prisa, compra grande y envío a otra dirección
- Un cliente que pregunta por tallas, colores y tiempos de envío
- Un pago disponible por el monto exacto

*¡Correcto! La prisa es un gancho.*

## Módulo 5

**M5 U01 P1.** ¿Qué forma de negocio empieza sin trámite de empresa?

- ✔ Dueño único
- LLC
- Corporación

*¡Correcto! Empiezas al vender.*

**M5 U01 P2.** Tu LLC en California no tuvo ventas este año. ¿Paga el impuesto mínimo?

- No, si no vendió
- Solo si ganó más de $10,000
- ✔ Sí, $800 mientras exista

*¡Correcto! Aunque no venda.*

**M5 U01 P3.** ¿Qué hace que una LLC pierda protección?

- Tener seguro
- ✔ Mezclar el dinero de la LLC con el tuyo
- Tener una cuenta propia de la LLC

*¡Correcto! La separación se rompe.*

**M5 U02 P1.** ¿Dónde sacas tu EIN?

- En un sitio privado que cobra una tarifa
- ✔ Gratis en irs.gov
- En tu banco

*¡Correcto! Es gratuito.*

**M5 U02 P2.** ¿Para qué sirve el ITIN?

- ✔ Para declarar impuestos si no puedes tener SSN
- Para trabajar como empleado
- Para votar

*¡Correcto! Número fiscal del IRS.*

**M5 U02 P3.** En California, ¿cuándo necesitas licencia de la CSLB?

- Nunca para trabajos pequeños de pintura o reparación
- Solo si tienes empleados de tiempo completo
- ✔ En trabajos de más de $1,000 o que requieren permiso

*¡Correcto! Regla vigente desde 2025.*

**M5 U03 P1.** ¿Cuál es la tasa del impuesto sobre el trabajo por cuenta propia?

- ✔ 15.3%
- 7.65%
- 2.5%

*¡Correcto! Seguro Social y Medicare.*

**M5 U03 P2.** Ganaste $350 limpios en el año con tu negocio. ¿Pagas impuesto por cuenta propia?

- Sí, siempre, aunque ganes poco
- Sí, si vendiste por apps
- ✔ No, porque es menos de $400

*¡Correcto! El mínimo es $400.*

**M5 U03 P3.** ¿Qué necesitas para deducir un gasto?

- Recordarlo
- ✔ Que sea del negocio y tener prueba
- Que sea mayor de $600

*¡Correcto! Ordinario, necesario y con prueba.*

**M5 U04 P1.** ¿Cuál es una fecha de pago estimado de 2026?

- ✔ 15 de junio
- 31 de diciembre
- 1 de marzo

*¡Correcto! Segundo pago estimado.*

**M5 U04 P2.** No recibiste 1099-K por tus ventas en una plataforma. ¿Qué haces?

- No declaras esas ventas
- Declaras solo si vendiste más de $600
- ✔ Las declaras igual

*¡Correcto! Todo ingreso se declara.*

**M5 U04 P3.** Te llaman «del IRS» para pagar hoy con tarjetas de regalo. ¿Qué es?

- ✔ Un fraude
- Un cobro urgente real
- Un nuevo método del IRS para pagos pequeños

*¡Correcto! El IRS no cobra así.*

**M5 U05 P1.** ¿Cuál es la tasa estatal base de sales tax en California?

- 16%
- 0%
- ✔ 7.25%

*¡Correcto! Más tasas locales.*

**M5 U05 P2.** Vendes $1,000 en productos con una tasa de 9%. ¿Cuánto impuesto cobras?

- ✔ $90
- $9
- $900

*¡Correcto! 9% de $1,000.*

**M5 U05 P3.** ¿Qué haces con el sales tax que cobras?

- Lo usas para comprar material
- ✔ Lo separas y lo entregas al estado
- Lo guardas como reserva del negocio

*¡Correcto! Es del estado.*

## Módulo 6

**M6 U01 P1.** La ganancia extra es $300 al mes y el pago es $400. ¿Qué pasa?

- El crédito se paga solo
- ✔ Te faltan $100 al mes
- Ganas $100

*¡Correcto! Pago mayor que ganancia.*

**M6 U01 P2.** ¿Para qué es más sano un crédito del negocio?

- Para pagar gastos de la casa este mes
- Para cubrir las pérdidas de los últimos meses
- ✔ Para algo que genere ventas

*¡Correcto! Puede pagarse solo.*

**M6 U01 P3.** ¿Qué haces antes de pedir crédito para un pedido?

- ✔ Revisas si el cliente puede dar depósito
- Pides el monto máximo
- Firmas rápido el primer crédito para no perder la oferta del día

*¡Correcto! Alternativa sin intereses.*

**M6 U02 P1.** Te piden una cuota para liberar tu préstamo. ¿Qué es?

- Un trámite normal
- Una comisión de apertura de ley
- ✔ Una señal de fraude

*¡Correcto! Nunca pagues por adelantado.*

**M6 U02 P2.** ¿Dónde verificas a un prestamista en California?

- ✔ En el DFPI
- En sus redes sociales
- En las reseñas de su app

*¡Correcto! Regulador del estado.*

**M6 U02 P3.** ¿Hasta cuánto prestan los microcréditos de la SBA?

- $5,000
- ✔ $50,000
- Sin límite

*¡Correcto! A través de intermediarios.*

**M6 U03 P1.** Dos créditos de igual monto y plazo: APR 12% y APR 30%. ¿Cuál es más barato?

- ✔ El de 12%
- El de 30%
- Cuestan igual

*¡Correcto! Menor APR.*

**M6 U03 P2.** Un adelanto de $5,000 con factor de 1.4. ¿Cuánto pagas en total?

- $5,400
- $1,400
- ✔ $7,000

*¡Correcto! $5,000 por 1.4.*

**M6 U03 P3.** ¿Qué es una garantía personal?

- Que el préstamo no se cobra si el negocio cierra
- ✔ Que pagas tú si el negocio no paga
- Un seguro gratuito

*¡Correcto! Respondes con tus bienes.*

**M6 U04 P1.** ¿Cuándo es aceptable usar tu tarjeta personal para el negocio?

- Si pagas el mínimo cada mes
- Siempre que el negocio lo necesite, aunque no pagues el total
- ✔ Si pagas el total cada mes y guardas recibos

*¡Correcto! Sin intereses.*

**M6 U04 P2.** Si eres cofirmante y el deudor no paga, ¿qué pasa?

- ✔ Te pueden cobrar a ti
- Nada, solo firmaste
- El banco perdona la deuda

*¡Correcto! Respondes por la deuda.*

**M6 U04 P3.** ¿De dónde prestas a un familiar?

- De la cuenta del negocio
- ✔ De tu sueldo o tu ahorro, por escrito
- Con la tarjeta del negocio

*¡Correcto! Sin afectar el negocio.*

## Módulo 7

**M7 U01 P1.** ¿Dónde revisas seguro médico en California si trabajas por tu cuenta?

- ✔ En Covered California y Medi-Cal
- Solo con tu banco
- En el IRS

*¡Correcto! Opciones oficiales.*

**M7 U01 P2.** Perdiste el seguro de tu trabajo a mitad de año. ¿Qué puedes revisar?

- Nada, esperas a noviembre
- ✔ Si ese cambio te permite inscribirte ya
- Un préstamo para consultas

*¡Correcto! Cambio de vida.*

**M7 U01 P3.** Recibes ayuda para tu prima y tu ingreso sube. ¿Qué haces?

- No haces nada hasta el próximo año
- Cancelas el seguro
- ✔ Actualizas tu ingreso estimado

*¡Correcto! Evita deber al declarar.*

**M7 U02 P1.** Un cliente se resbala en tu puesto. ¿Qué seguro ayuda?

- Seguro de vida
- ✔ Responsabilidad civil general
- Seguro de auto personal

*¡Correcto! Daños a terceros.*

**M7 U02 P2.** ¿Qué es el deducible?

- ✔ La parte del daño que pagas tú
- Lo que paga la aseguradora
- El precio de la póliza

*¡Correcto! Tu parte.*

**M7 U02 P3.** Tienes un empleado en California. ¿Qué seguro es obligatorio?

- Seguro de vida para el empleado
- Seguro de equipo
- ✔ Compensación al trabajador

*¡Correcto! Obligatorio con empleados.*

**M7 U03 P1.** Una carta cobra por un «certificado» de tu LLC con amenaza de multa. ¿Qué haces primero?

- Pagas para evitar la multa
- Llamas al número de la carta
- ✔ Revisas el remitente y verificas en el sitio oficial

*¡Correcto! Verifica antes de pagar.*

**M7 U03 P2.** ¿Con qué nunca paga una autoridad real?

- ✔ Con tarjetas de regalo
- Con cheque
- En su sitio oficial

*¡Correcto! Señal de fraude.*

**M7 U03 P3.** ¿Dónde reportas un fraude a tu negocio?

- En las reseñas de la empresa
- ✔ En ReportFraud.ftc.gov
- En ningún lado

*¡Correcto! Reporte oficial.*

**M7 U04 P1.** ¿Dónde buscas si un nombre ya es marca federal?

- ✔ En la USPTO
- En redes sociales
- En un buscador de internet

*¡Correcto! Buscador oficial.*

**M7 U04 P2.** ¿Tu cuenta de redes te da derecho exclusivo sobre el nombre en todo el país?

- Sí, si tiene muchos seguidores
- Sí, si la abriste primero
- ✔ No

*¡Correcto! Solo el registro.*

**M7 U04 P3.** ¿De qué dominio vienen los avisos reales de la USPTO?

- De cualquier correo con «marca» en el asunto
- ✔ De uspto.gov
- De un despacho que te escribe primero

*¡Correcto! Dominio oficial.*

## Módulo 8

**M8 U01 P1.** Alguien trabaja en tu local, con tu horario y tus instrucciones. ¿Qué suele ser?

- ✔ Un empleado
- Un contratista independiente
- Un socio

*¡Correcto! Tú controlas el trabajo.*

**M8 U01 P2.** ¿Qué seguro es obligatorio en California si tienes empleados?

- Seguro de vida para cada empleado
- ✔ Compensación al trabajador
- Seguro de auto

*¡Correcto! Obligatorio.*

**M8 U01 P3.** Pagas $2,500 en el año a un diseñador independiente. ¿Qué le envías?

- Un W-2
- Nada
- ✔ Un 1099-NEC

*¡Correcto! Desde $2,000 en 2026.*

**M8 U02 P1.** ¿Cuándo envía una plataforma el 1099-K?

- Siempre, desde la primera venta
- ✔ Con más de $20,000 y más de 200 transacciones
- Solo si lo pides

*¡Correcto! Umbral vigente.*

**M8 U02 P2.** Tu 1099-K muestra $24,000 brutos. ¿Cuánto declaras como ganancia?

- $24,000 completos
- Nada, ya lo reportó la plataforma
- ✔ Los cobros menos devoluciones, comisiones y costos

*¡Correcto! Se restan costos.*

**M8 U02 P3.** ¿Quién suele cobrar el sales tax de ventas en plataformas grandes?

- ✔ La plataforma
- Nadie
- Tu cliente directamente al estado

*¡Correcto! Facilitador de mercado.*

**M8 U03 P1.** Ventas de $6,000 en 400 ventas. ¿Ticket promedio?

- $2,400
- $150
- ✔ $15

*¡Correcto! $6,000 entre 400.*

**M8 U03 P2.** Tu margen bajó. ¿Qué revisas primero?

- ✔ Precios y costos de lo que vendes
- El color de tu logo
- Tu límite de la tarjeta

*¡Correcto! El margen depende de ellos.*

**M8 U03 P3.** Tu negocio tiene temporadas. ¿Con qué comparas julio?

- Con junio
- ✔ Con julio del año pasado
- Con enero

*¡Correcto! Misma temporada.*

## Módulo 9

**M9 U01 P1.** ¿Dónde revisas tu historial del Seguro Social?

- En tu banco
- ✔ En ssa.gov
- En el IRS

*¡Correcto! Sitio oficial.*

**M9 U01 P2.** ¿Cuánto puedes aportar a una IRA en 2026 si tienes menos de 50 años?

- $72,000
- $24,500
- ✔ $7,500

*¡Correcto! Límite de 2026.*

**M9 U01 P3.** ¿Por qué el negocio no basta como retiro?

- ✔ Depende de que puedas trabajar
- Porque los negocios pequeños no pagan impuestos
- Porque es pequeño

*¡Correcto! Tu salud cambia.*

**M9 U02 P1.** Cierras tu negocio con LLC en California. ¿Qué haces?

- Nada: solo dejas de vender hasta que vuelvas
- Cancelas tu cuenta del banco y listo
- ✔ La disuelves formalmente para no seguir pagando el mínimo

*¡Correcto! El mínimo sigue corriendo.*

**M9 U02 P2.** ¿Qué no debe ir escrito en tu carpeta del negocio?

- ✔ Tus contraseñas
- La lista de proveedores
- Las fechas de pago

*¡Correcto! Riesgo de robo.*

**M9 U02 P3.** ¿Cómo pasas el negocio a un familiar?

- De palabra
- ✔ Con un acuerdo por escrito
- Sin avisar a nadie

*¡Correcto! Evita conflictos.*

**M9 U03 P1.** ¿Cada cuánto revisas tu plan de una página?

- ✔ Cada tres meses
- Una vez en la vida
- Cada día

*¡Correcto! Revisión trimestral.*

**M9 U03 P2.** ¿Por dónde empiezas si te faltan muchas cosas?

- Por registrar tu marca
- ✔ Por separar el dinero y apartar impuestos
- Por pedir un préstamo para ordenar todo de una vez

*¡Correcto! La base de todo.*

**M9 U03 P3.** ¿Qué compartes en la comunidad?

- Tus montos, cuentas y ventas reales del mes
- Tu número de Seguro Social
- ✔ Tu plan sin datos personales

*¡Correcto! Sin datos.*
