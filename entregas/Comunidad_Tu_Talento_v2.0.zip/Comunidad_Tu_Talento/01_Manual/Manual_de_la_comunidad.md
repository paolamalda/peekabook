# Comunidad Tu Talento: manual de la comunidad

# Parte 1. Comunidad y canales


### 1. Espacio de la comunidad en Moodle

Un curso aparte, **"Comunidad Tu Talento"** (nombre corto `DT-TALENTO-MX-ES-COM`), con:

- Un foro **"Dudas de la comunidad"** (foro de uso general).
- Un foro **"Avisos"** (solo el equipo publica).
- La descripción: "Aquí resolvemos dudas entre la comunidad. No compartas RFC, CURP, números de cuenta, montos reales ni capturas de tus estados de cuenta. Los casos personales se atienden por mensaje privado o se canalizan a un profesional."

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Talento" y agregarla con el método de inscripción "Sincronización de cohortes" en el curso del programa y en la comunidad.

### 2. Canal de WhatsApp

- Nombre: "Tu Talento · Desarrolla Talento".
- Contenido: avisos del curso, fechas del SAT, alertas de fraude, recordatorios (reportes de crédito sin costo, Mes del Testamento, declaración anual) y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles.

### 3. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial se publican **solo** en el canal y en el foro de avisos, nunca en lecciones, actividades, autoevaluaciones ni constancia:

- Agencia de marca personal y redes (servicio propio).
- Despachos contables especializados en la industria creativa (referido).
- Agentes de seguros y planes de retiro (referido).

Cada publicación debe decir: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 4. Reglas de moderación

1. Borrar publicaciones con datos personales o capturas de cuentas y avisar en privado.
2. No permitir que participantes promuevan productos financieros, préstamos o inversiones.
3. Reportar de inmediato cualquier mensaje que parezca fraude (M9).
4. Canalizar casos fiscales, legales o de deudas complejas a PRODECON, CONDUSEF o un profesional.


# Parte 2. Guía de moderación


Para el equipo que modera los foros y el canal. Versión 1 · Septiembre de 2026.

### 1. Principios

1. **Proteger datos personales** antes que cualquier otra cosa.
2. **Educar, no asesorar:** explicamos y canalizamos; no resolvemos casos fiscales, legales o de inversión concretos.
3. **Cero venta dentro de la comunidad**, salvo el foro de referencias comerciales, siempre con aviso.
4. **Tono del curso:** tuteo cálido, español de México, sin culpas ni juicios.

### 2. Tiempos de respuesta

| Tipo | Meta |
|---|---|
| Publicación con datos personales | Retirar en menos de 2 horas hábiles |
| Alerta de fraude | Revisar el mismo día y fijar si es relevante |
| Duda general | Responder en 48 horas hábiles |
| Mensaje privado | Responder en 48 horas hábiles |

### 3. Qué hacer en cada caso

| Situación | Acción | Mensaje privado sugerido |
|---|---|---|
| Publica RFC, CURP, cuenta o captura | Editar o retirar la publicación | "Retiramos tu publicación porque tenía datos personales. Puedes volver a preguntar con números inventados o redondeados." |
| Ofrece préstamos, inversiones o productos | Retirar y advertir | "En la comunidad no se permiten ofertas de productos, préstamos ni inversiones. Revisa las reglas en el capítulo 2." |
| Recomienda un gestor o despacho de "limpieza" | Retirar y explicar | "Nadie puede borrar información correcta del Buró; las reclamaciones no tienen costo (M7 U07 y M7 U09)." |
| Caso fiscal concreto | Responder con lo general y canalizar | "Tu caso depende de tus números. Te sugerimos PRODECON (sin costo) o tu contador. La lección M2 U01 explica el tema." |
| Caso legal o de contrato | Responder con lo general y canalizar | "Revisa M3 U01 y consulta a un abogado del medio; si eres agremiado, a la ANDA." |
| Deudas graves o cobranza abusiva | Responder con pasos y canalizar | "Revisa M8 U04; puedes quejarte en el REDECO de CONDUSEF. CONDUSEF también orienta sin costo." |
| Se queja de llamadas o mensajes de publicidad | Responder con pasos | "Inscribe sin costo tus números en el REPEP de Profeco (tiendas y servicios) y en el REUS de CONDUSEF (bancos). Si siguen después del plazo, denuncia con número, fecha y hora (M9 U08)." |
| Alguien cobra por "inscribirte" en el REPEP o el REUS o por "vincular tu línea" | Retirar y alertar | "Estos trámites no tienen costo y se hacen solo en los sitios oficiales o en la tienda de tu compañía. Es un fraude (M9 U08)." |
| Fraude en curso | Responder de inmediato | "Bloquea tus tarjetas con tu banco, reclama por escrito, reporta al 088 y a CONDUSEF (M9 U09)." |
| Crisis emocional o riesgo | Responder con empatía y canalizar | "Lamentamos lo que vives. Si estás en riesgo, llama al 911. También puedes buscar apoyo en la Línea de la Vida (800 911 2000)." |
| Conflicto entre participantes | Recordar reglas; si sigue, suspender | "Te pedimos mantener el respeto. Es la regla 2 de la comunidad." |

### 4. Respuestas tipo

**Duda que ya está en el curso:**
"¡Buena pregunta! Lo explicamos en [lección]. En corto: [resumen de 2 líneas]. Si después de leerla sigues con dudas, cuéntanos qué parte."

**Dato que cambia:**
"Este dato cambia con el tiempo. Al [fecha] era [dato] según [fuente]. Confírmalo en [institución oficial] antes de decidir."

**Petición de recomendación de marca:**
"No recomendamos instituciones ni productos. Te dejamos cómo comparar: [lección M5]. Si quieres, comparte las opciones que ves, sin datos personales, y te ayudamos a revisar qué preguntar."

### 5. Qué nunca hacemos

- Pedir datos personales por foro o mensaje.
- Recomendar una institución, un producto o una persona fuera del foro de referencias.
- Prometer resultados ("te van a devolver", "te van a quitar del Buró").
- Publicar referencias sin el aviso de referencia comercial.

### 6. Escalamiento

1. Moderación responde o canaliza.
2. Coordinación del programa revisa casos repetidos, quejas sobre referencias y suspensiones.
3. Si un contenido del curso resulta incorrecto o desactualizado, se registra para la siguiente versión.

### 7. Métricas mensuales

| Métrica | Para qué |
|---|---|
| Personas activas y nuevas | Saber si la comunidad crece |
| Dudas publicadas y respondidas en 48 horas | Calidad de atención |
| Temas más preguntados | Mejorar lecciones y elegir temas de la sesión |
| Publicaciones retiradas por datos o venta | Ajustar reglas y avisos |
| Alertas de fraude | Detectar tendencias |
| Retos cumplidos en Logros | Participación |
| Clics en referencias comerciales | Transparencia interna |

