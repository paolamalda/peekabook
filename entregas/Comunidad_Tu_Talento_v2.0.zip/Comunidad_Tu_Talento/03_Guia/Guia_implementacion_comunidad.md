# Comunidad Tu Talento: guía de implementación

# Parte 1. Crear la comunidad en Moodle, paso a paso


Vas a crear el curso **Comunidad Tu Talento** en academia.desarrollatalento.com. Es un espacio aparte del curso *Tu Talento, Tu Marca, Tu Futuro* (DT-TALENTO-MX-ES). No toques otros cursos.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `DT-TALENTO-MX-ES-COM`. Si existe, detente y pregunta.
2. Pregunta a la persona:
   - la fecha y el enlace de la primera sesión mensual (Zoom, Meet u otra herramienta que ella use);
   - el enlace del canal de WhatsApp;
   - si quiere inscribir a las personas con una cohorte (la crea la persona administradora del sitio) o de forma manual.
   Si no tiene esos datos, deja el texto "[por definir]" y repórtalo.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Comunidad Tu Talento |
| Nombre corto | DT-TALENTO-MX-ES-COM |
| Visibilidad | **Mostrar** |
| Inscripción | Autoinscripción con la clave que te dé la persona («[por definir]» si no la tienes) |
| Formato | Temas, 4 secciones |
| Seguimiento de finalización | No |
| Mostrar calificaciones | No |
| Resumen | "El espacio de la comunidad de Tu Talento, Tu Marca, Tu Futuro: dudas, avisos, alertas de fraude, logros y sesiones en vivo." |

### 2. Secciones y actividades

#### General · Bienvenida

1. Ya existe el foro **Avisos** (foro de noticias). Configúralo:
   - Nombre: `Avisos`.
   - Descripción: "Fechas del SAT e IMSS, recordatorios, retos del mes y sesiones en vivo. Solo publica el equipo."
   - Suscripción: forzosa.
2. **Libro** `Guía de la comunidad`: formato de capítulo "Nada". Menú del libro > Importar capítulo > `1_libro/Comunidad_libro_Moodle.zip`, "Cada archivo HTML representa un capítulo" (6 capítulos).
3. **URL** `Canal de avisos en WhatsApp`: enlace que te dé la persona; abrir en ventana nueva. Descripción: "Solo publica el equipo; nadie ve tu número. Las dudas se resuelven en los foros."

#### Sección 1 · Participa

Crea estos foros. En **todos**:

- Número máximo de archivos adjuntos: **0**.
- Tamaño máximo de archivo adjunto: no se permite subir archivos.
- Calificación: ninguna. Evaluaciones (ratings): desactivadas.
- Modo de grupo: sin grupos.
- Suscripción: opcional.
- Copia la advertencia al inicio de cada descripción: "No publiques RFC, CURP, números de cuenta, contraseñas, montos reales ni capturas de tus documentos."

| Nombre | Tipo de foro | Descripción (después de la advertencia) |
|---|---|---|
| Lo que quiero lograr | Foro para uso general | "En una frase, qué quieres lograr este año. Sin nombre completo, datos personales ni montos reales." |
| Dudas: mi dinero, el SAT, contratos y regalías | Foro estándar que aparece en un formato similar a un blog | "Módulos 1 a 3. Usa la plantilla del capítulo 3 de la guía." |
| Dudas: crédito, Buró y deudas | Foro estándar que aparece en un formato similar a un blog | "Módulos 4 a 8. Usa la plantilla del capítulo 3 de la guía." |
| Dudas: fraudes, protección y futuro | Foro estándar que aparece en un formato similar a un blog | "Módulos 9 a 11. Usa la plantilla del capítulo 3 de la guía." |
| Alertas de fraude | Foro para uso general | "Avisa de falsos castings, mensajes o páginas falsas y apps sospechosas. Si ya te afectó, sigue M9 U09." |
| Logros | Foro para uso general | "Comparte tus avances y los retos del mes que cumpliste." |

Si en tu versión de Moodle el tipo "similar a un blog" no aparece con ese nombre, usa "Foro para uso general" y repórtalo.

#### Sección 2 · Sesiones en vivo

1. **Página** `Sesión mensual de dudas`: copia el contenido del capítulo 5 (primera parte) y agrega la fecha y el enlace que te dio la persona.
2. **Consulta** (Choice) `¿Qué tema quieres en la próxima sesión?`:
   - Opciones: "Sueldo fijo y fondo de sequía", "Régimen fiscal e IVA", "Contratos y regalías", "Buró y Círculo de Crédito", "Salir de deudas", "Fraudes", "IMSS y seguros", "Retiro y AFORE".
   - Permitir actualizar la respuesta: sí. Mostrar resultados: después de responder. Privacidad: publicar resultados anónimos.
3. **Encuesta** (Feedback) `Encuesta de la comunidad`, anónima, con estas preguntas:
   - Opción múltiple: "¿Qué tan útil te resulta la comunidad?" (Muy útil / Útil / Poco útil / Nada útil).
   - Opción múltiple: "¿Qué espacio usas más?" (Avisos / Foros de dudas / Alertas / Logros / Sesiones / Canal de WhatsApp).
   - Texto largo: "¿Qué tema te gustaría que agregáramos al curso?"
   - Texto largo: "¿Qué mejorarías de la comunidad?"

#### Sección 3 · Referencias comerciales

1. **Etiqueta** con este texto: "Referencias comerciales. Aquí publicamos servicios con acuerdo comercial. Desarrolla Talento puede recibir una comisión. Usarlos es voluntario y no afecta tu acceso, tus puntos ni tu constancia. Compara siempre con al menos otra opción (capítulo 6 de la guía)."
2. **Foro** `Referencias comerciales`, tipo "Foro de noticias" o, si no se puede agregar otro, "Foro para uso general" con esta restricción: en *Permisos* del foro, quita a Estudiante la capacidad `mod/forum:startdiscussion` y `mod/forum:replypost`. Si no puedes cambiar permisos, detente y pregunta.

### 3. Enlazar desde el curso principal

En el curso **DT-TALENTO-MX-ES**, sección General, agrega una **URL** `Comunidad Tu Talento` al curso nuevo, con la descripción: "Dudas, avisos, alertas de fraude, logros y sesiones en vivo."

### 4. Inscripción

- Si la persona creó la cohorte "Tu Talento": en ambos cursos, *Participantes > Métodos de inscripción > Agregar método > Sincronización de cohortes*, cohorte "Tu Talento", rol Estudiante.
- Si no: activa la **Autoinscripción** con la clave que te dé la persona («[por definir]» si no la tienes) y repórtalo.
- Agrega al equipo de moderación con rol **Profesor sin permiso de edición** (o Profesor, si lo pide la persona).

### 5. Revisión (con rol de estudiante)

- No se pueden adjuntar archivos en los foros.
- El estudiante puede publicar en Lo que quiero lograr, Dudas, Alertas y Logros.
- El estudiante no puede publicar en Avisos ni en Referencias comerciales.
- El libro muestra 6 capítulos.
- La consulta y la encuesta funcionan.

### 6. Reporte

Enlace del curso; lista de foros con su configuración; estado de la consulta y la encuesta; método de inscripción; lo que quedó "[por definir]"; capturas de la página principal del curso y de un foro con la advertencia.

El curso queda **visible**, con inscripción por clave.


# Parte 2. Calendario editorial


Cuatro publicaciones al mes: un recordatorio de fechas, un reto, una alerta o consejo, y el aviso de la sesión mensual. Las referencias comerciales van aparte, como máximo dos al mes.

| Mes | Semana 1 · Fechas | Semana 2 · Reto del mes | Semana 3 · Consejo o alerta | Semana 4 · Sesión |
|---|---|---|---|---|
| Enero | Cuesta de enero: tu fondo de sequía | Calcula tu ganancia real | Préstamos por app en enero: verifica en el SIPRES | Sesión: sueldo fijo e ingresos variables |
| Febrero | Nueva UMA desde el 1 de febrero | Págate un sueldo fijo un mes; inscríbete en el REPEP y el REUS | Falsos castings de inicio de año | Sesión: régimen fiscal |
| Marzo | Junta tus facturas para la anual | Pide tu reporte sin costo | Mensajes falsos del SAT sobre la anual | Sesión: deducciones personales |
| Abril | Declaración anual: fecha límite | Haz tu inventario de deudas | Saldo a favor: cuida tu CLABE | Sesión: declaración anual |
| Mayo | Revisa tu AFORE | Verificación en dos pasos | Robo de cuentas de redes | Sesión: AFORE y retiro |
| Junio | Reporte sin costo de medio año | Verifica una institución en el SIPRES | Apps "montadeudas" | Sesión: Buró y Círculo |
| Julio | Revisión de medio año del plan | Aparta tu primer mes de fondo | Inversiones milagro | Sesión: salir de deudas |
| Agosto | Revisa tus seguros | Busca tu AFORE con tu CURP | Seguros que te agregan sin pedir | Sesión: IMSS Modalidad 10 |
| Septiembre | Mes del Testamento | Agenda tu testamento | Gestores de AFORE | Sesión: testamento y beneficiarios |
| Octubre | Revisa tu reserva de nombre y tu marca | Busca tu nombre en el IMPI | Contratos "a perpetuidad" | Sesión: contratos y regalías |
| Noviembre | Buen Fin: suma tus mensualidades | Suma tus meses sin intereses | Páginas falsas de ofertas; llamadas de "promociones": REPEP y REUS | Sesión: meses sin intereses |
| Diciembre | Reparte tus pagos de fin de año | Tu plan de una página | Fraudes de fin de año y regalos | Sesión: plan del próximo año |

### Avisos extra de 2026

| Cuándo | Aviso |
|---|---|
| Octubre a diciembre de 2026 | Vincula tu línea de celular con tu CURP antes de la fecha de tu terminación (plazo final: 31 de diciembre de 2026) y revisa que no haya líneas a tu nombre que no reconozcas (M9 U08). |
| Cada dos años desde tu inscripción | Renueva tu inscripción en el REUS (M9 U08). |

**Ejemplo de alerta de la semana 3 (noviembre), para la parte de llamadas:**
"📵 ¿Te llaman para venderte de todo? Inscribe sin costo tus números en el REPEP de Profeco (tiendas y servicios) y en el REUS de CONDUSEF (bancos). Nadie te debe cobrar por hacerlo. Paso a paso en M9 U08."

### Formato para el canal de WhatsApp

- Máximo 5 líneas.
- Un solo enlace, siempre al curso, al foro o a un sitio oficial.
- Sin datos personales ni cifras de casos reales.

### Plantillas

**Fechas:**
"📅 Recordatorio: [qué] antes del [fecha]. Si tienes dudas, revisa [lección] o pregunta en el foro. Confirma siempre en [institución oficial]."

**Reto del mes:**
"🎯 Reto de [mes]: [reto]. Te toma [tiempo]. Cuando lo cumplas, compártelo en Logros (sin datos personales)."

**Alerta:**
"⚠️ Alerta: circulan [tipo de fraude]. Señales: [2 señales]. Si te llega, no respondas y repórtalo al 088 y a CONDUSEF. Más en [lección M9]."

**Sesión:**
"🎙️ Sesión de dudas: [tema], [fecha y hora]. Deja tu pregunta en el foro con la plantilla. Enlace: [enlace]."

**Referencia comercial (máximo 2 al mes):**
"💼 Referencia comercial: [servicio]. [Qué ofrece en una línea]. Desarrolla Talento puede recibir una comisión si lo contratas. Compara con al menos otra opción; usarlo es voluntario y no afecta tu acceso ni tu constancia."

