# Tu Negocio, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Perfil | Reto principal |
|---|---|---|
| **Rosa** (44) | Tiene una fonda en Iztapalapa, Ciudad de México, con su hija los fines de semana. Cobra en efectivo y por transferencia; da fiado a clientes de la colonia | Saca del cajón para la casa y no sabe si su fonda gana |
| **Toño** (35) | Electricista y técnico en Monterrey. Trabaja por su cuenta; una constructora le pide factura para contratarlo | Formalizarse sin saber qué régimen le toca ni cuánto pagará |
| **Mariana** (28) | Vende ropa y accesorios por redes sociales y en una plataforma de comercio en línea desde Guadalajara | Precios que no cubren envíos ni comisiones; retenciones de la plataforma; clientes que «ya pagaron» |
| **Don Pepe** (61) | Tiene una tienda de abarrotes en Oaxaca desde hace 25 años. Le ofrecen crédito para ampliar y su sobrino le pide que sea su aval | Crédito, retiro y qué pasa con la tienda si él falta |

Son personajes inventados; cualquier parecido con personas reales es coincidencia.

---

## 2. Mapa de módulos

| Módulo | Lecciones | Resultado |
|---|---|---|
| M1 Tu negocio y tu casa: dinero separado | 4 | Dinero separado, sueldo fijo y registros al día |
| M2 Costos y precio | 4 | Costos calculados, precio con margen y punto de equilibrio |
| M3 Flujo de efectivo | 3 | Calendario de entradas y salidas, política de fiado y reserva |
| M4 Cobrar y vender sin perder | 3 | Formas de cobro comparadas y protocolo contra fraudes al vender |
| M5 Formalízate sin miedo | 5 | RFC, régimen, facturas y declaraciones en orden |
| M6 Crédito para tu negocio | 4 | Decidir si necesitas crédito, cuánto cuesta y cómo no mezclarlo |
| M7 Protege tu negocio | 4 | Seguridad social, seguros, fraudes a negocios y marca |
| M8 Crecer con orden | 3 | Reglas para contratar, vender en línea y medir |
| M9 Tu futuro | 3 | Retiro, plan de continuidad y plan de una página |

**Insignias:** Dinero separado (M1), Precio justo (M2), Flujo bajo control (M3 y M4), Negocio formal (M5), Crédito inteligente (M6), Negocio protegido (M7), Crecer con orden (M8 y M9) y Plan completo (curso).

---

## 3. Lecciones

# Parte 2. Módulo 1. Tu negocio y tu casa: dinero separado

## M1 U01. ¿Tu negocio gana o solo vende?

**Lo que lograrás:** Distinguir entre ventas y ganancia, y calcular si tu negocio gana, pierde o apenas sale.

**Para empezar:** Rosa vende unos 30,000 pesos al mes en su fonda y siente que le va bien. Pero a fin de mes no le alcanza para la renta de su casa. En esta lección verás por qué vender mucho no siempre es ganar.

### Lo esencial (5 minutos)

#### Vender no es ganar

Las ventas son lo que cobras. La ganancia es lo que queda después de pagar todo lo que te costó vender: insumos, renta, gas, luz, ayuda y comisiones.



#### La cuenta de Rosa en un mes

- Ventas: **30,000**
- Insumos (carne, verduras, tortillas): **14,000**
- Renta, gas, luz, agua y ayuda de su hija: **9,500**
- Ganancia del negocio: **6,500**
Rosa creía que ganaba 30,000. En realidad le quedan 6,500, y de ahí también saca para su casa.


#### Tres resultados posibles

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ganas | Ventas mayores que todos los costos. | Puedes pagarte y ahorrar. |
| Sales tablas | Ventas iguales a los costos. | Trabajas gratis. |
| Pierdes | Costos mayores que las ventas. | Pones de tu bolsa. |

#### Un caso en un minuto

Rosa anotó durante un mes todo lo que compraba para la fonda. Descubrió que el gas y las tortillas eran casi 3,000 pesos que nunca contaba. Ahora sabe que su ganancia real es de 6,500.

> **Idea clave:** no midas tu negocio por lo que vendes, sino por lo que te queda después de pagar todo.



#### Comprueba lo que entendiste

1. ¿Qué diferencia hay entre ventas y ganancia?
*Respuesta:* Las ventas son lo que cobras; la ganancia es lo que queda después de pagar todos los costos.

2. Si vendes 20,000 y gastas 20,000, ¿cuánto ganas?
*Respuesta:* Nada: sales tablas y trabajas gratis.


#### Para recordar

- Ventas menos costos es ganancia.
- Cuenta todos los costos, también los chicos.
- Vender mucho no siempre es ganar.



### Profundiza (5 minutos más)

#### Costos que se olvidan

| Costo | Por qué se olvida |
|---|---|
| Gas y luz del local o de tu casa | Se pagan cada mes o cada dos meses |
| Bolsas, desechables, servilletas | Son montos chicos que se suman |
| Comisiones de cobro | Se descuentan solas |
| Pasajes o gasolina para surtir | Se pagan de tu bolsa |
| Lo que se echa a perder | No se ve como gasto |



#### Tu tiempo también cuesta

Si trabajas 60 horas a la semana y el negocio te deja 6,500 al mes, ganas unos 27 pesos por hora. Compararlo con lo que ganarías en un empleo te ayuda a decidir qué mejorar: precios, costos o ventas.



#### Casos


**Caso 1. El mes de Rosa**

Rosa vendió más que nunca en diciembre, pero pagó más insumos y el aguinaldo de su hija.
- *¿Qué hace para saber si ganó?* Resta todos los costos del mes a sus ventas antes de celebrar.


**Caso 2. Los pedidos de Mariana**

Mariana vendió 80 blusas en un mes, pero pagó envíos que no cobró.
- *¿Qué revisa?* Cuánto le queda por blusa después de producto, envío y comisión.


**Caso 3. Las horas de Toño**

Toño cobra bien cada trabajo, pero pasa muchas horas en traslados que no cobra.
- *¿Qué hace?* Calcula cuánto gana por hora contando traslados y ajusta su tarifa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Medir por ventas | Crees que ganas | Resta todos los costos |
| Olvidar costos chicos | Ganancia inflada | Anótalos un mes |
| No contar tu tiempo | Trabajas barato | Calcula por hora |
| Celebrar un mes bueno | Gastas de más | Revisa varios meses |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Mariana y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Vendes 25,000 y tus costos son 19,000. ¿Cuánto ganas? a) 6,000 · b) 25,000 · c) 44,000
2. ¿Qué es la ganancia? a) Todo lo que cobras a tus clientes en el mes, en efectivo y transferencia · b) Lo que queda después de pagar todos los costos · c) Lo que hay en el cajón al cerrar
3. Tus ventas y tus costos son iguales. ¿Qué pasa? a) Ganas poco, pero el negocio sí te deja algo · b) Pierdes dinero cada mes · c) Sales tablas: trabajas gratis
**Respuestas:** 1-a: 25,000 menos 19,000. 2-b: ventas menos costos. 3-c: no queda nada para ti.



#### Ponlo en práctica

Vendes 18,000 al mes. Gastas 8,000 en insumos, 3,500 en renta y servicios y 500 en comisiones. ¿Cuánto ganas?
**Respuesta:** 18,000 menos 12,000: 6,000.



#### A tu plan

Esta semana anota todas tus ventas y todo lo que gastas en el negocio, aunque sea poco.



### Para saber más

- **Finanzas para tu negocio** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores» y «finanzas del negocio».

### Palabras clave

- *Ventas:* todo lo que cobras a tus clientes, antes de restar lo que te costó.
- *Ganancia:* lo que queda de las ventas después de pagar todos los costos del negocio.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U02. Separa el dinero del negocio y de tu casa

**Lo que lograrás:** Separar el dinero del negocio del de tu casa con una cuenta o caja aparte y reglas claras.

**Para empezar:** Rosa toma del cajón de la fonda para el mandado, el camión y la escuela de su hijo. Al final de la semana no sabe cuánto vendió ni cuánto sacó. En esta lección verás cómo separar sin complicarte.

### Lo esencial (5 minutos)

#### Dos bolsas, dos dueños

El negocio y tu casa son dos bolsas distintas. Si tomas del negocio para la casa sin anotar, nunca sabrás si tu negocio gana. La regla es simple: **el dinero del negocio solo sale del negocio para pagar cosas del negocio o tu sueldo.**



#### Cómo separar

1. Abre una cuenta solo para el negocio o usa una caja aparte.
2. Todo lo que cobras entra ahí: efectivo y transferencias.
3. Paga insumos, renta y servicios del negocio solo desde ahí.
4. Para tu casa, págate un sueldo fijo (M1 U03); no saques «de a poquito».



#### Qué va en cada bolsa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Del negocio | Insumos, renta del local, gas, comisiones. | Salen de la cuenta del negocio. |
| De tu casa | Mandado, escuela, renta de tu casa. | Salen de tu sueldo. |
| Mezclados | Sacar del cajón para todo. | No sabes si ganas. |
| Cobros al celular personal | Se pierden entre tus gastos. | Usa una cuenta aparte. |

#### Un caso en un minuto

Rosa abrió una cuenta de débito solo para la fonda y pidió a sus clientes que le transfieran ahí. El efectivo lo guarda en una caja y lo deposita cada lunes. Ya sabe cuánto vende cada semana.

> **Idea clave:** separa el dinero y págate un sueldo; así sabrás si tu negocio gana y tu casa tendrá un ingreso fijo.



#### Comprueba lo que entendiste

1. ¿Para qué sirve separar el dinero?
*Respuesta:* Para saber si tu negocio gana y no gastar sin darte cuenta el dinero del negocio.

2. ¿Cómo pasas dinero del negocio a tu casa?
*Respuesta:* Con un sueldo fijo, no sacando del cajón.


#### Para recordar

- Dos bolsas: negocio y casa.
- Todo cobro entra al negocio.
- A tu casa, solo tu sueldo.



### Profundiza (5 minutos más)

#### ¿Cuenta personal o de negocio?

Si aún no estás formalizada, puedes usar una segunda cuenta de débito a tu nombre solo para el negocio. Si ya tienes RFC con actividad, algunos bancos ofrecen cuentas para persona física con actividad empresarial. Compara comisiones y saldo mínimo; el IPAB protege los depósitos en bancos hasta 400,000 UDIS por persona y por banco.



#### El efectivo

Si cobras mucho en efectivo, cuenta la caja al cerrar y anota el total. Deposita seguido: menos efectivo guardado es menos riesgo de robo o de «préstamos» a la casa.



#### Si tienes que tomar prestado

Si un día necesitas dinero del negocio para una emergencia de tu casa, anótalo como préstamo y devuélvelo. Así no se te pierde en las cuentas.



#### Casos


**Caso 1. El cajón de Rosa**

Rosa toma 200 del cajón para el mandado.
- *¿Qué hace para no perder la cuenta?* Lo anota como parte de su sueldo o como préstamo que devolverá.


**Caso 2. Las transferencias de Mariana**

Mariana recibe los pagos en la misma cuenta donde le deposita su pareja para la casa.
- *¿Qué hace?* Abre una cuenta solo para las ventas y da esa a sus clientes.


**Caso 3. La herramienta de Toño**

Toño compra una pinza para su trabajo con la tarjeta de su casa.
- *¿Qué hace?* Registra la compra como gasto del negocio y la paga desde la cuenta del negocio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sacar del cajón | No sabes si ganas | Sueldo fijo |
| Una sola cuenta | Todo se mezcla | Cuenta aparte |
| Préstamos sin anotar | Hoyos en la caja | Anota y devuelve |
| Mucho efectivo guardado | Riesgo de robo | Deposita seguido |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Mariana y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Desde dónde pagas los insumos? a) Desde tu cuenta personal · b) Desde la cuenta o caja del negocio · c) Desde lo que haya ese día en tu cartera o en la caja
2. Sacas 500 del negocio para una emergencia de tu casa. ¿Qué haces? a) Lo olvidas, total es tu negocio · b) Lo cubres con la tarjeta de crédito y te olvidas del tema · c) Lo anotas como préstamo y lo devuelves
3. ¿Qué hace más fácil saber cuánto vendes? a) Que los cobros entren a una cuenta del negocio · b) Guardar todo el efectivo en casa · c) Recibir pagos en varias cuentas personales y de familiares
**Respuestas:** 1-b: cada bolsa paga lo suyo. 2-c: así no se pierde. 3-a: todo queda registrado.



#### Ponlo en práctica

En una semana entraron a la cuenta del negocio 7,200 y pagaste 4,100 de insumos. ¿Cuánto queda en el negocio?
**Respuesta:** 7,200 menos 4,100: 3,100.



#### A tu plan

Elige esta semana tu cuenta o caja del negocio y avisa a tus clientes a dónde transferir.



### Para saber más

- **Cuentas y comisiones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «Buró de Entidades Financieras» y comparativos de cuentas.
- **Seguro de depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** «seguro de depósitos».

### Palabras clave

- *Cuenta del negocio:* cuenta o caja que usas solo para cobrar y pagar cosas del negocio.

### Fuentes

CONDUSEF · IPAB, consultados el 29 de septiembre de 2026.

---

## M1 U03. Págate un sueldo

**Lo que lograrás:** Fijar un sueldo para ti que el negocio pueda pagar y dejar el resto trabajando en el negocio.

**Para empezar:** Rosa ya separó el dinero, pero ahora no sabe cuánto puede llevar a su casa. Algunas semanas saca mucho y otras nada. En esta lección verás cómo fijar un sueldo.

### Lo esencial (5 minutos)

#### Tú también eres trabajadora del negocio

Si trabajas en tu negocio, mereces un sueldo. Fijo, en la misma fecha, como si fueras empleada. Así tu casa tiene un ingreso estable y el negocio conserva lo que necesita.



#### Cómo fijarlo

1. Calcula tu ganancia promedio de los últimos 3 meses.
2. Toma una parte (por ejemplo, 70%) como sueldo; el resto se queda para reserva y crecimiento.
3. Págalo cada semana o quincena, siempre el mismo día.
4. Revísalo cada 3 meses: si la ganancia sube, sube tu sueldo.



#### El sueldo de Rosa

- Ganancia promedio al mes: **6,500**
× 70% | Parte para su sueldo
- Sueldo mensual (unos 1,140 por semana): **4,550**
Los 1,950 restantes se quedan en la fonda para la reserva.


#### Un caso en un minuto

Rosa se paga 1,100 cada lunes. Si en una semana vendió poco, igual se paga, porque la reserva lo cubre. Si vendió mucho, no saca más: el excedente se queda en la fonda.

> **Idea clave:** un sueldo fijo protege a tu casa de los altibajos del negocio y protege al negocio de tus gastos.



#### Comprueba lo que entendiste

1. ¿De dónde sale tu sueldo?
*Respuesta:* De la ganancia promedio del negocio, no de las ventas.

2. ¿Qué haces con lo que sobra?
*Respuesta:* Se queda en el negocio para reserva y crecimiento.


#### Para recordar

- Sueldo fijo, misma fecha.
- Basado en la ganancia promedio.
- Revísalo cada 3 meses.



### Profundiza (5 minutos más)

#### Si la ganancia no alcanza

Si tu ganancia no alcanza para un sueldo digno, no es un problema de ahorro: es un problema de precio, costos o ventas. Los módulos 2 y 3 te ayudan a encontrar dónde mejorar.



#### Tu sueldo en números

| Dato | Monto |
|---|---|
| Ganancia de hace 3 meses | |
| Ganancia de hace 2 meses | |
| Ganancia del mes pasado | |
| Promedio | |
| Sueldo (70% del promedio) | |



#### Si trabajan varias personas de la familia

Si tu hija o tu pareja trabajan en el negocio, acuerden un pago para cada una. Trabajar gratis «porque es familia» genera conflictos y esconde el costo real (M8 U01).



#### Casos


**Caso 1. La buena semana de Rosa**

Rosa vendió el doble en la semana de fiestas.
- *¿Qué hace?* Se paga su sueldo normal y deja el excedente en la reserva.


**Caso 2. El sueldo de Toño**

Toño cobra por trabajo y hay meses de 30,000 y otros de 8,000.
- *¿Qué hace?* Se paga un sueldo con base en su promedio y guarda lo de los meses buenos.


**Caso 3. La hija de Rosa**

La hija de Rosa ayuda los fines de semana sin pago fijo.
- *¿Qué hacen?* Acuerdan un pago por día y lo cuentan como costo de la fonda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sacar según las ventas | Casa inestable | Sueldo fijo |
| No pagarte | No sabes tu costo | Págate |
| Sacar el excedente | Negocio sin reserva | Déjalo en el negocio |
| Familia sin pago | Conflictos | Acuerdo claro |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Toño y la hija de Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu ganancia promedio es 10,000 al mes. Con 70%, ¿cuál es tu sueldo? a) 10,000 · b) 3,000 · c) 7,000
2. Tuviste una semana excelente. ¿Qué haces? a) Te pagas tu sueldo y dejas el resto en el negocio · b) Sacas todo lo extra para la casa porque te lo ganaste · c) Te subes el sueldo desde ese día
3. ¿Cada cuánto revisas tu sueldo? a) Cada día · b) Cada 3 meses · c) Solo si el negocio cierra
**Respuestas:** 1-c: 70% de 10,000. 2-a: el excedente es reserva. 3-b: con el promedio.



#### Ponlo en práctica

Tu ganancia fue 8,000, 9,500 y 7,500 en tres meses. ¿Cuál es tu promedio y tu sueldo con 70%?
**Respuesta:** Promedio 8,333; sueldo unos 5,833 al mes.



#### A tu plan

Calcula tu ganancia promedio y fija tu sueldo y tu día de pago.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto» y «herramientas».

### Palabras clave

- *Sueldo del dueño:* cantidad fija que el negocio te paga cada semana o quincena por tu trabajo.
- *Excedente:* lo que sobra después de pagar costos y tu sueldo.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M1 U04. Registros en 10 minutos al día

**Lo que lograrás:** Llevar un registro sencillo de ventas y gastos, y hacer un corte cada semana.

**Para empezar:** Mariana guarda los pagos en capturas de pantalla y los gastos en la memoria. Cuando quiere saber cuánto ganó en el mes, no puede. En esta lección verás cómo llevar tus registros en 10 minutos al día.

### Lo esencial (5 minutos)

#### Qué anotar

Cada día anota: fecha, cuánto vendiste (efectivo y transferencias) y cuánto gastaste y en qué. Con eso basta para empezar. Un registro al día vale más que uno perfecto que nunca haces.



#### Elige tu herramienta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Libreta | Sencilla y barata. | Súmala cada semana. |
| Hoja de cálculo | Suma sola. | En el celular o la computadora. |
| App de registro | Reportes y gráficas. | Revisa qué datos pide. |
| Solo capturas | Se pierden. | No suman. |

#### Tu corte semanal

1. Suma las ventas de la semana.
2. Suma los gastos del negocio.
3. Resta: esa es tu ganancia de la semana.
4. Compara con el saldo de la cuenta y la caja.



#### Un caso en un minuto

Mariana hizo una hoja con tres columnas: fecha, entra y sale. Cada noche le dedica 10 minutos. El domingo hace su corte: sabe cuánto vendió y cuánto le quedó.

> **Idea clave:** anota cada día y haz un corte cada semana; sin registros no hay decisiones.



#### Comprueba lo que entendiste

1. ¿Qué anotas cada día?
*Respuesta:* Fecha, ventas y gastos con su concepto.

2. ¿Qué haces en el corte semanal?
*Respuesta:* Sumas ventas y gastos, calculas la ganancia y lo comparas con tu cuenta y caja.


#### Para recordar

- Diario: fecha, entra, sale.
- Semanal: corte.
- Sencillo es mejor que perfecto.



### Profundiza (5 minutos más)

#### Tu registro

| Fecha | Concepto | Entra | Sale |
|---|---|---|---|
| | | | |
| | | | |
| **Total de la semana** | | | |



#### Cuida tus datos

Si usas una app, revisa qué datos te pide y quién la ofrece. No subas fotos de tu INE ni de tus tarjetas para «registrar» tu negocio. Protege tu hoja con contraseña.



#### Guarda comprobantes

Guarda tickets y facturas de lo que compras en un sobre o una carpeta por mes. Te servirán para saber tus costos y, si te formalizas, para tus declaraciones (M5).



#### Casos


**Caso 1. Las capturas de Mariana**

Mariana tiene 200 capturas de pagos del mes.
- *¿Qué hace?* Pasa cada pago a su hoja de registro el mismo día y borra la confusión.


**Caso 2. El corte de Rosa**

El corte semanal de Rosa dice 3,000 de ganancia, pero en la caja hay 1,800.
- *¿Qué revisa?* Si hubo gastos o retiros sin anotar y los registra.


**Caso 3. La app de Don Pepe**

Una app gratuita pide a Don Pepe foto de su INE y de su tarjeta para registrar sus ventas.
- *¿Qué hace?* No la usa y elige una libreta o una hoja de cálculo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Anotar de memoria | Se olvidan gastos | Diario |
| Solo capturas | No suman | Pásalas al registro |
| Nunca hacer corte | No sabes si ganas | Semanal |
| Apps que piden de más | Robo de datos | Revisa antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Rosa y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es lo mínimo que anotas cada día? a) Solo las ventas grandes · b) Lo que recuerdes el domingo · c) Fecha, ventas y gastos
2. Tu corte y tu caja no cuadran. ¿Qué haces? a) Buscas gastos o retiros sin anotar · b) Ajustas el corte para que cuadre con lo que hay en la caja · c) Lo ignoras si es poco
3. Una app te pide tu INE y foto de tu tarjeta. ¿Qué haces? a) La usas si es gratis y tiene buenas reseñas en la tienda · b) No la usas y eliges otra herramienta · c) Mandas solo la tarjeta
**Respuestas:** 1-c: con eso basta. 2-a: así encuentras el hoyo. 3-b: pide de más.



#### Ponlo en práctica

En una semana vendiste 1,200, 900, 1,500, 1,100 y 1,300, y gastaste 2,800. ¿Cuál fue tu ganancia?
**Respuesta:** Ventas 6,000 menos 2,800: 3,200.



#### A tu plan

Elige tu herramienta y anota tus ventas y gastos todos los días de esta semana.



### Para saber más

- **Herramientas para tu negocio** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores».

### Palabras clave

- *Registro:* lista de lo que entra y sale del negocio, con fecha y concepto.
- *Corte:* suma de ventas y gastos de un periodo para saber cuánto ganaste.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 3. Módulo 2. Costos y precio

## M2 U01. Costos fijos y variables

**Lo que lograrás:** Separar tus costos en fijos y variables y calcular cuánto te cuesta cada producto o servicio.

**Para empezar:** Mariana compra cada blusa en 180 y la vende en 300. Cree que gana 120 por blusa. Pero no ha contado la renta de su bodeguita, el internet ni las bolsas. En esta lección verás cuánto le cuesta de verdad cada blusa.

### Lo esencial (5 minutos)

#### Dos tipos de costos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fijos | Los pagas vendas o no: renta, internet, sueldos. | Cada mes igual. |
| Variables | Suben si vendes más: insumos, empaques, comisiones, envíos. | Por cada venta. |
| Tu sueldo | Es un costo fijo más. | No lo olvides. |
| Sin clasificar | No sabes cuánto te cuesta vender. | Ordénalos. |

#### Tu costo por unidad

El costo por unidad suma lo que gastas en cada pieza (variable) más la parte que le toca de tus costos fijos.



#### La blusa de Mariana

- Blusa de proveedor: **180**
- Bolsa, etiqueta y empaque: **25**
- Parte de sus fijos (3,000 al mes ÷ 100 blusas): **30**
- Costo real por blusa: **235**
Mariana no gana 120 por blusa, sino 65, y todavía falta la comisión de cobro.


#### Un caso en un minuto

Rosa calculó que cada comida corrida le cuesta 42 pesos en insumos y 18 de su parte de fijos: 60. La vende en 85. Ahora sabe que le quedan 25 por comida.

> **Idea clave:** suma a cada producto lo que gastas en él y la parte que le toca de tus costos fijos.



#### Comprueba lo que entendiste

1. ¿Qué es un costo fijo?
*Respuesta:* Uno que pagas aunque no vendas, como la renta o tu sueldo.

2. ¿Cómo repartes los fijos por unidad?
*Respuesta:* Divides los costos fijos del mes entre las unidades que vendes al mes.


#### Para recordar

- Fijos: vendas o no.
- Variables: por cada venta.
- Costo por unidad = variable + parte de fijos.



### Profundiza (5 minutos más)

#### Tus costos del mes

| Costo | Fijo o variable | Monto al mes |
|---|---|---|
| Renta | Fijo | |
| Luz, gas, agua, internet | Fijo | |
| Tu sueldo y ayudantes | Fijo | |
| Insumos o mercancía | Variable | |
| Empaques y envíos | Variable | |
| Comisiones de cobro | Variable | |



#### Servicios: tu hora cuesta

Si vendes servicios, como Toño, tu costo principal es tu tiempo. Divide tus costos fijos y tu sueldo entre las horas que trabajas al mes: ese es tu costo por hora. Suma material, traslados y herramienta que se desgasta.



#### Casos


**Caso 1. La blusa de Mariana**

Mariana cree que gana 120 por blusa porque la compra en 180 y la vende en 300.
- *¿Qué le falta sumar?* Empaque, envío, comisión y su parte de costos fijos.


**Caso 2. La hora de Toño**

Toño cobra 250 la hora, pero no sabe si le alcanza.
- *¿Qué calcula?* Su costo por hora con sus costos fijos, su sueldo y sus horas trabajadas.


**Caso 3. La luz de Rosa**

El recibo de luz de Rosa llega cada dos meses y nunca lo cuenta.
- *¿Qué hace?* Lo divide entre dos y lo suma a sus costos fijos de cada mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar solo el insumo | Precio bajo | Suma los fijos |
| Olvidar tu sueldo | Trabajas gratis | Es un costo fijo |
| Ignorar pagos bimestrales | Sorpresas | Divide entre dos |
| No contar el tiempo | Servicio barato | Costo por hora |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Toño y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál de estos es un costo variable? a) La renta del local · b) El empaque de cada pedido · c) El internet
2. Tus fijos son 4,000 y vendes 200 piezas al mes. ¿Cuánto fijo le toca a cada pieza? a) 20 · b) 200 · c) 4,000
3. ¿Tu sueldo es un costo del negocio? a) No, es ganancia · b) Solo si te sobra · c) Sí, es un costo fijo
**Respuestas:** 1-b: sube con cada venta. 2-a: 4,000 entre 200. 3-c: sin él trabajas gratis.



#### Ponlo en práctica

Un pastel te cuesta 140 de ingredientes y 20 de caja. Tus fijos son 3,600 al mes y vendes 60 pasteles. ¿Cuál es el costo por pastel?
**Respuesta:** 140 más 20 más 60 (3,600 entre 60): 220.



#### A tu plan

Haz tu lista de costos del mes, sepáralos en fijos y variables y calcula el costo de tu producto principal.



### Para saber más

- **Emprendedores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «costos» y «emprendedores».

### Palabras clave

- *Costo fijo:* gasto que pagas vendas o no, como la renta o tu sueldo.
- *Costo variable:* gasto que sube con cada venta, como insumos o empaques.
- *Costo por unidad:* lo que te cuesta producir o vender una pieza, un platillo o un servicio, contando costos variables y una parte de los fijos.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M2 U02. ¿Cuánto cobrar?

**Lo que lograrás:** Poner un precio que cubra tus costos, deje un margen y tenga sentido para tus clientes y frente a la competencia.

**Para empezar:** Toño cobra lo mismo que su compadre porque «así se cobra en la colonia». Pero su compadre no tiene camioneta ni herramienta nueva. En esta lección verás cómo poner tu propio precio.

### Lo esencial (5 minutos)

#### Tres miradas para tu precio

Tu precio se revisa desde tres lados: **tu costo** (el piso, nunca cobres menos), **la competencia** (qué cobran otros por algo parecido) y **el valor para tu cliente** (qué problema le resuelves, rapidez, calidad, garantía).



#### Precio con margen

- Costo real por blusa: **235**
- Margen sobre el precio: **30%**
- Precio mínimo (235 ÷ 0.70): **336**
Al precio se le suma la comisión de cobro (M4 U01) si Mariana cobra con tarjeta.


#### Tu precio frente a otros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Más barato que todos | Muchas ventas, poca ganancia. | Riesgo de perder. |
| Parecido | Compites por servicio y calidad. | Muestra por qué tú. |
| Más caro | Necesitas explicar el valor. | Garantía, rapidez, calidad. |
| Debajo de tu costo | Pierdes con cada venta. | Nunca. |

#### Un caso en un minuto

Toño calculó su costo por hora en 210. Cobraba 250 y apenas le quedaba. Subió a 320 e incluyó garantía de 30 días. Perdió un cliente, pero ganó más con los demás.

> **Idea clave:** tu costo es el piso; el margen es lo que te permite crecer; la competencia y el valor te dicen hasta dónde subir.



#### Comprueba lo que entendiste

1. ¿Qué es el piso de tu precio?
*Respuesta:* Tu costo por unidad: nunca cobras menos.

2. ¿Qué es el margen?
*Respuesta:* La parte del precio que queda después de cubrir el costo.


#### Para recordar

- Costo = piso.
- Margen = crecimiento.
- Competencia y valor = techo.



### Profundiza (5 minutos más)

#### Margen y sobreprecio no son lo mismo

Si a un costo de 100 le sumas 30%, cobras 130 y tu margen es de 23% (30 entre 130). Para tener un margen de 30%, divide el costo entre 0.70: 143. Conviene calcular el margen sobre el precio.



#### Envíos y comisiones

Si vendes en línea o cobras con tarjeta, el envío, la comisión de la plataforma y la de la terminal son costos variables. Súmalos al costo o cóbralos aparte, con claridad: la comisión de tarjeta no se le carga al cliente como recargo (M4 U01).



#### Subir precios sin perder clientes

Avisa con anticipación, explica el porqué (insumos, calidad) y mantén una opción económica si puedes. Los clientes suelen aceptar un aumento claro mejor que un producto más pequeño sin aviso.



#### Casos


**Caso 1. El precio de Toño**

Toño cobra lo mismo que su compadre, aunque sus costos son mayores.
- *¿Qué hace?* Calcula su costo por hora y pone un precio con margen, explicando su garantía.


**Caso 2. La oferta de Mariana**

Mariana quiere bajar sus blusas a 250 para vender más que la competencia.
- *¿Qué revisa?* Que 250 cubra su costo real con envío y comisión antes de bajar.


**Caso 3. El aumento de Rosa**

La tortilla y la carne subieron y la comida corrida de Rosa ya casi no deja.
- *¿Qué hace?* Recalcula su costo, avisa a sus clientes y sube el precio con anticipación.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Copiar el precio | No cubres tus costos | Calcula el tuyo |
| Vender bajo costo | Pierdes con cada venta | Costo = piso |
| Confundir margen y sobreprecio | Ganas menos | Divide entre 0.70 |
| Subir sin avisar | Clientes molestos | Avisa y explica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Mariana y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu costo es 70. ¿Cuál es el precio mínimo para un margen de 30% sobre el precio? a) 91 · b) 70 · c) 100
2. ¿Cuándo nunca debes vender? a) Por debajo de tu costo · b) Más caro que la competencia · c) Con garantía
3. Tus insumos subieron. ¿Qué haces? a) Bajas la porción sin avisar · b) Recalculas tu costo y avisas del nuevo precio · c) Esperas a que bajen solos y mantienes tus precios de siempre
**Respuestas:** 1-c: 70 entre 0.70. 2-a: pierdes con cada venta. 3-b: con aviso y claridad.



#### Ponlo en práctica

Un servicio te cuesta 400. Quieres un margen de 25% sobre el precio. ¿Cuánto cobras?
**Respuesta:** 400 entre 0.75: unos 533.



#### A tu plan

Revisa el precio de tu producto principal: ¿cubre tu costo y deja margen? Ajusta si no.



### Para saber más

- **Derechos del consumidor y precios** (Profeco · español): https://www.gob.mx/profeco — **Qué buscar:** «exhibición de precios».

### Palabras clave

- *Margen:* parte del precio que queda después de cubrir el costo.
- *Precio piso:* el precio mínimo que cubre tu costo.

### Fuentes

Profeco · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M2 U03. Tu punto de equilibrio

**Lo que lograrás:** Calcular cuánto necesitas vender al mes para cubrir todos tus costos.

**Para empezar:** Don Pepe paga 12,000 al mes de renta, luz, su sueldo y el de su ayudante. Quiere saber cuánto debe vender para no perder. En esta lección verás cómo calcularlo.

### Lo esencial (5 minutos)

#### Qué es

El punto de equilibrio es lo que necesitas vender para que tus ventas cubran todos tus costos. Por debajo pierdes; por arriba ganas.



#### La fórmula

Divide tus **costos fijos** entre lo que te deja cada peso de venta después de los variables (tu margen de contribución).



#### La tienda de Don Pepe

- Costos fijos al mes: **12,000**
÷ 20% | Lo que le deja cada venta después de pagar la mercancía
- Ventas mínimas al mes (unos 2,000 al día): **60,000**
Si vende menos de 60,000, pierde; si vende más, gana.


#### Un caso en un minuto

Don Pepe vende en promedio 2,300 al día: 69,000 al mes. Está 9,000 arriba de su punto de equilibrio: eso le deja 1,800 de ganancia (20% de 9,000) además de su sueldo.

> **Idea clave:** conoce la venta mínima de cada día; es tu meta para no perder.



#### Comprueba lo que entendiste

1. ¿Qué pasa si vendes menos que tu punto de equilibrio?
*Respuesta:* Pierdes dinero ese mes.

2. ¿Qué necesitas para calcularlo?
*Respuesta:* Tus costos fijos y lo que te deja cada venta después de los variables.


#### Para recordar

- Fijos ÷ margen de contribución.
- Tu meta diaria para no perder.
- Arriba ganas, abajo pierdes.



### Profundiza (5 minutos más)

#### En unidades

Si vendes un producto principal, calcula en piezas: fijos entre lo que te deja cada pieza. Rosa tiene 9,500 de fijos y cada comida le deja 43 (85 menos 42 de insumos): necesita unas 221 comidas al mes, unas 9 al día.



#### Tu punto de equilibrio

| Dato | Monto |
|---|---|
| Costos fijos al mes (incluye tu sueldo) | |
| Lo que te deja cada venta (%) o cada pieza | |
| Punto de equilibrio al mes | |
| Meta al día (entre días que abres) | |



#### Cómo bajarlo

Baja costos fijos, sube el precio o mejora lo que te deja cada venta (comprar mejor, reducir merma). Cada mejora baja la venta mínima que necesitas.



#### Casos


**Caso 1. La renta de Don Pepe**

Le suben la renta a Don Pepe 2,000 al mes.
- *¿Qué hace?* Recalcula su punto de equilibrio y su meta diaria.


**Caso 2. Las comidas de Rosa**

Rosa vende 7 comidas al día y su equilibrio es de 9.
- *¿Qué hace?* Busca subir ventas, precio o bajar costos para no perder.


**Caso 3. El local de Mariana**

Mariana quiere rentar un local de 6,000 al mes.
- *¿Qué calcula antes?* Cuánto tendría que vender de más para cubrir la nueva renta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No conocer tu mínimo | Pierdes sin saber | Calcula tu equilibrio |
| Olvidar tu sueldo en los fijos | Equilibrio falso | Inclúyelo |
| No recalcular | Metas viejas | Cada cambio de costos |
| Rentar sin calcular | Deudas | Calcula antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Rosa y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Fijos de 10,000 y cada venta te deja 25%. ¿Punto de equilibrio? a) 2,500 · b) 40,000 · c) 12,500
2. Vendes menos que tu punto de equilibrio. ¿Qué pasa? a) Ganas poco · b) Estás igual · c) Pierdes dinero
3. ¿Qué baja tu punto de equilibrio? a) Bajar costos fijos · b) Rentar un local más grande · c) Dar más fiado
**Respuestas:** 1-b: 10,000 entre 0.25. 2-c: no cubres tus costos. 3-a: necesitas vender menos.



#### Ponlo en práctica

Tus fijos son 8,000 y cada pieza te deja 40. ¿Cuántas piezas necesitas vender al mes?
**Respuesta:** 8,000 entre 40: 200 piezas.



#### A tu plan

Calcula tu punto de equilibrio y escribe tu meta de venta diaria donde la veas.



### Para saber más

- **Emprendedores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «punto de equilibrio».

### Palabras clave

- *Punto de equilibrio:* ventas mínimas para cubrir todos tus costos: ni ganas ni pierdes.
- *Margen de contribución:* lo que queda de cada venta después de pagar sus costos variables, para cubrir los fijos.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M2 U04. Inventario y merma

**Lo que lograrás:** Comprar lo que se vende, reducir lo que se pierde y no tener dinero parado en mercancía.

**Para empezar:** Don Pepe tiene en la bodega cajas de productos que nadie compra y cada semana tira pan y fruta. En esta lección verás cuánto le cuesta y cómo reducirlo.

### Lo esencial (5 minutos)

#### El inventario es dinero

Tu inventario es dinero convertido en productos. Si no se vende, es dinero parado; si se echa a perder, es dinero tirado. A lo que se pierde se le llama merma.



#### Tres tipos de producto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Rota rápido | Se vende cada día. | Nunca te falte. |
| Rota lento | Se vende de vez en cuando. | Compra poco. |
| Parado | No se vende. | Liquídalo y no vuelvas a comprar. |
| Merma | Se echa a perder. | Mídela y redúcela. |

#### Cómo reducir la merma

1. Anota una semana lo que tiras o no vendes.
2. Compra más seguido y en menor cantidad lo perecedero.
3. Primero en entrar, primero en salir: acomoda lo viejo adelante.
4. Vende a precio especial antes de que se eche a perder.



#### Un caso en un minuto

Don Pepe anotó la merma de pan y fruta: 1,400 pesos al mes. Empezó a pedir pan dos veces al día en menos cantidad y a vender la fruta madura en bolsas a mitad de precio. Redujo la merma a 500.

> **Idea clave:** compra lo que rota, mide lo que tiras y no dejes tu dinero parado en la bodega.



#### Comprueba lo que entendiste

1. ¿Por qué el inventario parado es un problema?
*Respuesta:* Es dinero que no puedes usar para otra cosa.

2. ¿Qué es primero en entrar, primero en salir?
*Respuesta:* Vender primero lo más viejo para que no se eche a perder.


#### Para recordar

- Inventario = dinero.
- Mide tu merma.
- Compra lo que rota.



### Profundiza (5 minutos más)

#### Tu merma de la semana

| Producto | Cantidad perdida | Costo |
|---|---|---|
| | | |
| | | |
| **Total** | | |



#### Las ofertas del proveedor

«Si llevas 10 cajas te regalo una» solo conviene si vendes las 11 antes de que se echen a perder o de que necesites ese dinero. Una oferta que se queda en la bodega sale cara.



#### La merma en el precio

Si siempre pierdes algo, inclúyelo en tu costo. Si de 100 panes tiras 5, cada pan vendido debe cubrir el costo de 100 entre 95.



#### Casos


**Caso 1. La oferta a Don Pepe**

El proveedor ofrece a Don Pepe una caja gratis si compra 10 de un producto que vende poco.
- *¿Qué hace?* Compra solo lo que vende en el tiempo de caducidad, aunque pierda el regalo.


**Caso 2. Las verduras de Rosa**

Rosa tira verdura cada viernes.
- *¿Qué hace?* Anota lo que tira y compra menos cantidad y más seguido.


**Caso 3. El inventario de Mariana**

Mariana tiene 40 blusas de un modelo que no se vendió.
- *¿Qué hace?* Las ofrece con descuento para recuperar el dinero y no vuelve a comprar ese modelo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comprar por oferta | Dinero parado | Compra lo que rota |
| No medir la merma | Pierdes sin saber | Anota una semana |
| Guardar lo que no se vende | Ocupa espacio y dinero | Liquídalo |
| No acomodar | Se echa a perder | Lo viejo adelante |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Rosa y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es la merma? a) El descuento que te da el proveedor · b) Lo que se echa a perder o ya no puedes vender · c) La mercancía nueva
2. Tienes 30 piezas que no se venden. ¿Qué haces? a) Las ofreces con descuento · b) Compras más para exhibir · c) Las guardas por si acaso
3. ¿Cuándo conviene una oferta de «lleva más»? a) Siempre · b) Si el proveedor es de confianza y te da buen precio · c) Si vendes todo antes de que caduque
**Respuestas:** 1-b: dinero tirado. 2-a: dinero parado. 3-c: si no, sale cara.



#### Ponlo en práctica

Compras 100 piezas a 10 y tiras 10. ¿Cuánto te cuesta cada pieza que vendes?
**Respuesta:** 1,000 entre 90: unos 11.11.



#### A tu plan

Anota esta semana lo que tiras o no vendes y decide qué dejar de comprar.



### Para saber más

- **Emprendedores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «inventario».

### Palabras clave

- *Inventario:* mercancía o insumos que compraste y todavía no vendes.
- *Merma:* mercancía que se echa a perder, se rompe o se pierde y ya no puedes vender.
- *Rotación:* qué tan rápido se vende un producto.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 4. Módulo 3. Flujo de efectivo

## M3 U01. Ganar no es tener efectivo

**Lo que lograrás:** Entender el flujo de efectivo y hacer un calendario sencillo de entradas y salidas para no quedarte sin dinero.

**Para empezar:** Toño terminó una instalación de 24,000 para la constructora, pero le pagarán en 30 días. Mientras, tiene que pagar material, gasolina y su renta. En esta lección verás por qué ganar no es lo mismo que tener dinero.

### Lo esencial (5 minutos)

#### Qué es el flujo

El flujo de efectivo es el dinero que de verdad entra y sale, y **cuándo**. Puedes tener ganancia en papel y no tener efectivo para pagar esta semana, porque te pagan tarde o porque compraste de golpe.



#### Qué afecta tu flujo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Te pagan tarde | Crédito a clientes o fiado. | El dinero llega después. |
| Compras grandes | Inventario o herramienta. | Sale mucho de golpe. |
| Pagos fijos | Renta, sueldos, impuestos. | Siempre llegan. |
| Anticipos | Cobras antes de trabajar. | Mejora tu flujo. |

#### Tu calendario de 4 semanas

1. Escribe cuánto dinero tienes hoy en el negocio.
2. Anota, por semana, lo que esperas cobrar.
3. Anota, por semana, lo que tienes que pagar.
4. Suma y resta: si alguna semana queda en negativo, actúa antes.



#### Un caso en un minuto

Toño vio en su calendario que en la semana 2 le faltarían 3,500. Pidió a la constructora un anticipo de 30% para el siguiente trabajo y pagó el material con él.

> **Idea clave:** mira tus próximas cuatro semanas: el problema de efectivo se resuelve antes, no el día que no alcanza.



#### Comprueba lo que entendiste

1. ¿Por qué puedes ganar y no tener efectivo?
*Respuesta:* Porque te pagan después o porque pagas antes de cobrar.

2. ¿Para qué sirve el calendario?
*Respuesta:* Para ver antes las semanas en que faltará dinero.


#### Para recordar

- Flujo = cuándo entra y sale.
- Calendario de 4 semanas.
- Actúa antes de que falte.



### Profundiza (5 minutos más)

#### Tu calendario

| | Semana 1 | Semana 2 | Semana 3 | Semana 4 |
|---|---|---|---|---|
| Saldo inicial | | | | |
| + Cobros esperados | | | | |
| − Pagos | | | | |
| = Saldo final | | | | |



#### Anticipos y plazos

Pide anticipo en trabajos grandes (30% a 50% es común). Si un cliente paga a 30 días, negocia con tu proveedor un plazo parecido. Cada día que cobras antes o pagas después mejora tu flujo.



#### Crédito caro para tapar huecos

Si el calendario muestra un hueco, no lo tapes con préstamos rápidos de apps o «gota a gota»: su costo se come tu ganancia y el cobro puede ser agresivo. Revisa primero anticipos, plazos y tu reserva (M3 U03).



#### Casos


**Caso 1. El pago tardío a Toño**

La constructora le paga a Toño a 30 días y él necesita material ya.
- *¿Qué hace?* Pide un anticipo y negocia plazo con su proveedor.


**Caso 2. La compra grande de Don Pepe**

Don Pepe quiere surtir para diciembre en octubre y se quedaría sin efectivo dos semanas.
- *¿Qué hace?* Revisa su calendario y compra en partes según vaya vendiendo.


**Caso 3. El préstamo de la app**

A Mariana le faltan 2,000 para pagar a su proveedor y una app le presta al momento.
- *¿Qué hace antes?* Revisa su reserva y pide plazo al proveedor antes de un crédito caro.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo la ganancia | Te quedas sin efectivo | Mira el flujo |
| No pedir anticipos | Financias al cliente | Anticipo |
| Comprar todo de golpe | Hueco de efectivo | En partes |
| Tapar con crédito caro | Pierdes ganancia | Reserva y plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Don Pepe y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tienes 3,000, cobrarás 5,000 y pagarás 9,000 esta semana. ¿Cómo terminas? a) Con 1,000 de sobra · b) Con 17,000 · c) Con 1,000 de faltante
2. ¿Qué mejora tu flujo? a) Pagar antes a tus proveedores para que te traten mejor · b) Pedir anticipo en trabajos grandes · c) Dar más plazo a tus clientes
3. Tu calendario muestra un hueco en tres semanas. ¿Qué haces? a) Buscas soluciones desde hoy · b) Esperas a ver si se arregla · c) Pides un préstamo rápido el día que falte
**Respuestas:** 1-c: 3,000 más 5,000 menos 9,000. 2-b: cobras antes. 3-a: actúa antes.



#### Ponlo en práctica

Saldo inicial 4,000. Semana 1: cobras 6,000 y pagas 7,500. Semana 2: cobras 3,000 y pagas 6,000. ¿Cómo terminas cada semana?
**Respuesta:** Semana 1: 2,500. Semana 2: 2,500 más 3,000 menos 6,000: faltan 500.



#### A tu plan

Haz tu calendario de las próximas cuatro semanas y marca las semanas con riesgo.



### Para saber más

- **Simuladores y finanzas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «flujo de efectivo» y «emprendedores».

### Palabras clave

- *Flujo de efectivo:* el dinero que realmente entra y sale del negocio, y cuándo.
- *Anticipo:* parte del pago que el cliente da antes de que hagas el trabajo.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U02. Fiado, crédito a clientes y cobranza

**Lo que lograrás:** Poner reglas para dar fiado o crédito a clientes, registrar lo que te deben y cobrar con respeto.

**Para empezar:** Rosa tiene 4,800 pesos en fiado de vecinos y conocidos. No quiere perder clientes, pero ese dinero le hace falta para surtir. En esta lección verás cómo poner reglas.

### Lo esencial (5 minutos)

#### El fiado es un préstamo

Cuando das fiado, prestas tu dinero sin intereses. Puede ayudarte a mantener clientes, pero si crece sin control, te deja sin efectivo.



#### Reglas para el fiado

1. Un límite por persona (por ejemplo, 300).
2. Un plazo: la quincena o la semana.
3. Un límite total para el negocio (por ejemplo, 2,000).
4. Todo anotado: nombre, fecha, monto y abonos.
5. Si no paga, no hay más fiado hasta que liquide.



#### Cómo cobrar con respeto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Recuerda la fecha | Un mensaje amable antes del día. | Sin presión. |
| Muestra tu registro | Lo que debe y lo que abonó. | Claridad. |
| Acepta abonos | Mejor poco que nada. | Anota cada abono. |
| Exhibir o amenazar | Nunca: es ilegal y pierdes clientes. | No. |

#### Un caso en un minuto

Rosa hizo una libreta de fiado con límite de 300 por persona y 2,000 en total. Puso un letrero discreto: «Fiado hasta la quincena». Recuperó 3,100 en un mes con recordatorios amables.

> **Idea clave:** el fiado es un préstamo sin intereses; ponle límite, plazo y registro.



#### Comprueba lo que entendiste

1. ¿Por qué el fiado afecta tu flujo?
*Respuesta:* Porque es dinero tuyo que todavía no regresa.

2. ¿Qué regla aplicas si alguien no paga?
*Respuesta:* No hay más fiado hasta que liquide.


#### Para recordar

- Límite por persona y total.
- Plazo y registro.
- Cobra con respeto.



### Profundiza (5 minutos más)

#### Tu libreta de fiado

| Nombre | Fecha | Monto | Abonos | Debe |
|---|---|---|---|---|
| | | | | |
| | | | | |



#### Crédito a empresas

Si vendes a empresas, como Toño, pon por escrito el plazo de pago (por ejemplo, 15 o 30 días), pide anticipo y entrega factura a tiempo: muchas empresas no pagan sin factura correcta. Si una empresa se atrasa, recuerda por escrito antes de seguir trabajando.



#### Cobrar sin romper la ley

No exhibas a los deudores, no los amenaces ni los contactes a horas inapropiadas. Además de dañar tu negocio, puede traerte problemas legales. Si la deuda es grande, un acuerdo por escrito o un juicio de cuantía menor son opciones formales.



#### Casos


**Caso 1. El fiado de Rosa**

Un cliente de Rosa debe 900 y pide más.
- *¿Qué hace?* No le da más hasta que abone y le propone pagos pequeños.


**Caso 2. La empresa de Toño**

Una empresa le debe a Toño un trabajo de hace 45 días.
- *¿Qué hace?* Recuerda por escrito con la factura y no empieza otro trabajo sin anticipo.


**Caso 3. El vecino de Don Pepe**

Don Pepe no anota el fiado porque «se acuerda».
- *¿Qué hace?* Empieza una libreta con nombre, fecha, monto y abonos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Fiado sin límite | Te quedas sin efectivo | Límite y plazo |
| No anotar | Discusiones | Libreta |
| Exhibir al deudor | Pierdes clientes y es ilegal | Cobra con respeto |
| Seguir trabajando sin cobrar | Crece la deuda | Anticipo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Toño y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el fiado para tu negocio? a) Una venta ya cobrada · b) Un préstamo sin intereses · c) Una ganancia extra
2. Un cliente no ha pagado y pide más. ¿Qué haces? a) Le das más para no perderlo · b) Lo exhibes en un letrero para que otros clientes sí paguen · c) No le das más hasta que abone
3. ¿Qué debe tener tu registro de fiado? a) Nombre, fecha, monto y abonos · b) Solo el nombre · c) Solo el total del mes
**Respuestas:** 1-b: dinero que no ha regresado. 2-c: regla clara. 3-a: sin discusiones.



#### Ponlo en práctica

Tienes un límite total de fiado de 2,500. Hoy te deben 1,900. ¿Cuánto fiado más puedes dar?
**Respuesta:** 600.



#### A tu plan

Escribe tus reglas de fiado (límite, plazo, registro) y suma cuánto te deben hoy.



### Para saber más

- **Cobranza** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cobranza» y «derechos».

### Palabras clave

- *Fiado:* venta que el cliente paga después, sin intereses, basada en la confianza.
- *Abono:* pago parcial de una deuda.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M3 U03. Tu reserva y las temporadas bajas

**Lo que lograrás:** Formar una reserva para el negocio y prepararte para los meses flojos y los gastos anuales.

**Para empezar:** Mariana vende mucho en noviembre y diciembre, pero en enero y febrero casi nada. El año pasado tuvo que pedir prestado para pagar a su proveedor. En esta lección verás cómo prepararte.

### Lo esencial (5 minutos)

#### Qué es la reserva

La reserva del negocio es el colchón del negocio: dinero para pagar costos fijos y tu sueldo cuando vendes menos o cuando surge un imprevisto. Es distinta de tu fondo de emergencia personal.



#### La reserva de Mariana

- Costos fijos al mes (con su sueldo): **5,000**
× 3 | Meses de colchón
- Meta de reserva: **15,000**
Aparta un porcentaje de cada venta hasta llegar a la meta.


#### Dónde guardarla

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta aparte en un banco | Protegida por el IPAB. | Disponible. |
| Cetes o BONDDIA | Gana algo y la sacas pronto. | Liquidez. |
| Efectivo en el local | Riesgo de robo o gasto. | Evítalo. |
| En mercancía | No es reserva. | No puedes usarla. |

#### Un caso en un minuto

Mariana aparta 10% de cada venta de octubre a diciembre en una cuenta aparte. En enero usa la reserva para pagar su bodeguita y su sueldo sin pedir prestado.

> **Idea clave:** en los meses buenos, aparta para los flojos; la reserva evita deudas caras.



#### Comprueba lo que entendiste

1. ¿Para qué sirve la reserva?
*Respuesta:* Para pagar costos fijos y tu sueldo en meses flojos o imprevistos.

2. ¿Cuánto es una meta razonable?
*Respuesta:* De uno a tres meses de costos fijos.


#### Para recordar

- Reserva = colchón del negocio.
- Aparta un % de cada venta.
- Cuenta aparte o Cetes.



### Profundiza (5 minutos más)

#### Tus gastos anuales del negocio

| Gasto | Mes | Monto | Aparta al mes |
|---|---|---|---|
| Permiso o licencia | | | |
| Mantenimiento o equipo | | | |
| Seguro del negocio | | | |
| Aguinaldo de ayudantes | Diciembre | | |



#### Tu mapa del año

Revisa tus ventas de cada mes del año pasado. Marca los meses altos y bajos. Planea las compras y la reserva según ese mapa, no según el mes actual.



#### Qué no es reserva

Los ahorros para tu casa, la mercancía y el fiado no son reserva. No uses opciones que el curso no recomienda para guardar tu reserva: prefiere bancos protegidos por el IPAB o Cetes.



#### Casos


**Caso 1. El enero de Mariana**

Mariana sabe que enero es flojo.
- *¿Qué hace en diciembre?* Aparta un porcentaje de cada venta en una cuenta aparte.


**Caso 2. La caja de Don Pepe**

Don Pepe guarda su reserva en una caja en la tienda.
- *¿Qué hace?* La pasa a una cuenta bancaria o a Cetes.


**Caso 3. El aguinaldo en la fonda**

Rosa tiene que dar aguinaldo a su ayudante en diciembre.
- *¿Qué hace desde enero?* Divide el monto entre 12 y lo aparta cada mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin reserva | Deudas caras | Aparta cada venta |
| Reserva en efectivo | Robo o gasto | Cuenta o Cetes |
| Olvidar gastos anuales | Sorpresas | Divide entre 12 |
| Mezclar con tu ahorro personal | No sabes cuánto hay | Separada |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Don Pepe y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Costos fijos de 6,000 al mes. ¿Reserva para 3 meses? a) 2,000 · b) 6,000 · c) 18,000
2. ¿Dónde conviene guardar la reserva? a) En una cuenta aparte en un banco o en Cetes · b) En la caja del local, donde siempre la tienes a la mano · c) En más mercancía
3. Un permiso cuesta 3,600 al año. ¿Cuánto apartas al mes? a) 360 · b) 300 · c) 3,600
**Respuestas:** 1-c: 6,000 por 3. 2-a: protegida y disponible. 3-b: 3,600 entre 12.



#### Ponlo en práctica

Vendes 40,000 en diciembre y apartas 10%. ¿Cuánto va a la reserva?
**Respuesta:** 4,000.



#### A tu plan

Fija tu meta de reserva y el porcentaje de cada venta que apartarás desde esta semana.



### Para saber más

- **Cetes y BONDDIA** (Cetesdirecto · español): https://www.cetesdirecto.com — **Qué buscar:** «BONDDIA».
- **Seguro de depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** «seguro de depósitos».

### Palabras clave

- *Reserva del negocio:* dinero apartado para cubrir los costos fijos del negocio en meses flojos o imprevistos.
- *Temporada baja:* meses en que tu negocio vende menos.

### Fuentes

Cetesdirecto · IPAB, consultados el 29 de septiembre de 2026.

---


# Parte 5. Módulo 4. Cobrar y vender sin perder

## M4 U01. Efectivo, transferencia, terminal o link de pago

**Lo que lograrás:** Comparar las formas de cobro por su costo, rapidez y seguridad, y elegir las que convienen a tu negocio.

**Para empezar:** A Rosa le ofrecen una terminal para cobrar con tarjeta. Sus clientes se la piden, pero no sabe cuánto le cobrarán ni cuándo le depositan. En esta lección verás cómo comparar.

### Lo esencial (5 minutos)

#### Formas de cobro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Efectivo | Sin comisión. | Riesgo de robo y billetes falsos. |
| Transferencia (SPEI) | Sin comisión en la mayoría de cuentas. | Confírmala en tu app. |
| Terminal | Cobras con tarjeta. | Comisión por cobro. |
| Link de pago | Cobras a distancia. | Comisión; revisa contracargos. |

#### Lo que cuesta cobrar con tarjeta

- Cobros con tarjeta al mes: **10,000**
× 3.5% | Comisión con IVA (aprox.)
- Costo al mes: **350**
Si la terminal te trae ventas que no tendrías, puede convenir; súmalo a tus costos variables.


#### Antes de contratar una terminal, pregunta

1. Comisión por cobro, con IVA, para débito y crédito.
2. Renta mensual, venta mínima o costo del aparato.
3. En cuántos días depositan y a qué cuenta.
4. Qué pasa con los contracargos y quién los paga.



#### Un caso en un minuto

Rosa comparó tres terminales: una sin renta y 3.5% de comisión, otra con renta de 200 y 2.5%. Con 8,000 al mes en tarjeta, la primera le cuesta 280 y la segunda 400. Eligió la primera.

> **Idea clave:** compara el costo total al mes con tus ventas reales, no solo el porcentaje.



#### Comprueba lo que entendiste

1. ¿Qué preguntas antes de contratar una terminal?
*Respuesta:* Comisión con IVA, renta o mínimo, días de depósito y contracargos.

2. ¿Puedes cargar la comisión al cliente?
*Respuesta:* No como recargo por pagar con tarjeta: inclúyela en tu precio.


#### Para recordar

- Compara costo total.
- Pregunta depósito y contracargos.
- La comisión va en tu precio.



### Profundiza (5 minutos más)

#### Compara tus opciones

| Dato | Opción A | Opción B | Opción C |
|---|---|---|---|
| Comisión con IVA | | | |
| Renta o mínimo al mes | | | |
| Días de depósito | | | |
| Costo total con tus ventas | | | |



#### Recargos por pagar con tarjeta

CONDUSEF señala que el comercio no debe cobrar un recargo al cliente por pagar con tarjeta. Si tu margen es pequeño, ajusta tu precio para todos o fija un monto mínimo de compra con tarjeta que avises con claridad.



#### Efectivo seguro

Si cobras mucho en efectivo: cuenta en privado, deposita seguido, varía horarios y rutas, y revisa billetes grandes. Menos efectivo en el local es menos riesgo.



#### Casos


**Caso 1. La terminal de Rosa**

A Rosa le ofrecen una terminal con renta mensual y comisión baja.
- *¿Qué hace?* Calcula el costo total con sus ventas reales y lo compara con otras opciones.


**Caso 2. El recargo de Don Pepe**

Don Pepe quiere cobrar 5% extra a quien pague con tarjeta.
- *¿Qué hace?* Incluye el costo en su precio o fija un mínimo avisado, sin recargo.


**Caso 3. El link de Mariana**

Mariana quiere cobrar con link a clientes que no conoce.
- *¿Qué revisa?* Comisión, días de depósito y quién paga si hay contracargo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el porcentaje | Costo oculto | Costo total |
| Cobrar recargo | Queja del cliente | En el precio |
| No preguntar depósito | Hueco de flujo | Días de depósito |
| Mucho efectivo guardado | Robo | Deposita seguido |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Don Pepe y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 6,000 al mes con tarjeta y la comisión es 3%. ¿Cuánto pagas? a) 180 · b) 600 · c) 30
2. ¿Qué haces con la comisión de la terminal? a) La cobras aparte a quien paga con tarjeta · b) La incluyes en tu precio · c) Le pides al cliente que pague en efectivo siempre
3. Terminal A: 3.5% sin renta. Terminal B: 2.5% más 150 de renta. Vendes 10,000 con tarjeta. ¿Cuál es más barata? a) La A: 350 · b) La B: 400 · c) Cuestan igual
**Respuestas:** 1-a: 3% de 6,000. 2-b: sin recargo. 3-a: 350 contra 250 más 150.



#### Ponlo en práctica

Con la terminal B (2.5% más 150 de renta), ¿a partir de cuántas ventas al mes es más barata que la A (3.5% sin renta)?
**Respuesta:** Cuando la diferencia de 1% supera los 150: más de 15,000 al mes.



#### A tu plan

Anota cuánto cobras al mes con tarjeta y compara al menos dos opciones de terminal con tus números.



### Para saber más

- **Terminales y cobros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «terminal punto de venta» y «comisiones».
- **Transferencias** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «SPEI».

### Palabras clave

- *Terminal punto de venta:* aparato o app para cobrar con tarjeta.
- *Link de pago:* enlace que envías a tu cliente para que pague con tarjeta a distancia.
- *Contracargo:* cuando el banco del cliente le regresa un pago con tarjeta porque lo desconoce o lo reclama.

### Fuentes

CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M4 U02. Cobros con CoDi, QR y transferencias seguras

**Lo que lograrás:** Cobrar por transferencia o código QR confirmando cada pago en tu app y cuidando tu cuenta.

**Para empezar:** Mariana entrega pedidos cuando el cliente le manda la captura de la transferencia. Una vez la captura era falsa y perdió un vestido de 900. En esta lección verás cómo confirmar cada pago.

### Lo esencial (5 minutos)

#### Cobrar por transferencia o QR

Con una transferencia SPEI o un código QR (como CoDi o el de tu banco), el dinero llega a tu cuenta en segundos, casi siempre sin comisión. Pero **la captura del cliente no es prueba de pago**.



#### Antes de entregar, confirma

1. Abre tu app del banco y revisa que el dinero **ya esté en tu cuenta**.
2. Revisa monto, nombre y hora.
3. Si tienes duda, consulta el CEP en el sitio de Banxico.
4. Solo entonces entrega.

> **Dato vigente:** el CEP se descarga en el sitio de Banco de México con fecha, clave de rastreo o referencia, banco emisor, banco receptor, cuenta y monto; confirma que la transferencia SPEI se liquidó. Consultado el 29 de septiembre de 2026 a través de Banco de México.



#### Cuida tu cuenta de cobro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Alertas | Aviso de cada depósito. | Confirmas al instante. |
| Tu límite de transferencias | Ajústalo a lo que pagas. | Menos riesgo. |
| Comparte solo la CLABE | Nunca NIP, códigos ni contraseñas. | Para cobrar basta la CLABE. |
| Captura como prueba | Se falsifica fácil. | No es prueba. |

#### Un caso en un minuto

Mariana activó las alertas de su app. Ahora solo entrega cuando le llega la notificación del banco. Dos clientes con capturas falsas desaparecieron cuando les dijo que esperaría el depósito.

> **Idea clave:** entrega solo cuando el dinero esté en tu cuenta, no cuando te manden una captura.



#### Comprueba lo que entendiste

1. ¿Por qué una captura no es prueba de pago?
*Respuesta:* Porque se puede falsificar o ser de una transferencia que no se completó.

2. ¿Qué dato compartes para cobrar?
*Respuesta:* Solo tu CLABE o tu código QR; nunca NIP, contraseñas ni códigos.


#### Para recordar

- Revisa en tu app antes de entregar.
- CEP si hay duda.
- Solo la CLABE.



### Profundiza (5 minutos más)

#### Tu límite de transferencias

Desde 2026, cada persona puede fijar en su banco un límite para sus transferencias desde la app. Para tu cuenta de cobro, el límite de salida puede ser bajo: así, si alguien entra a tu app, no puede vaciarla.

> **Dato vigente:** si no fijas tu límite de transferencias (Monto Transaccional del Usuario, MTU), el banco aplica uno de 1,500 UDIS; puedes ajustarlo en tu app. Obligatorio desde el 1 de enero de 2026. Consultado el 29 de septiembre de 2026 a través de la CNBV.



#### Transferencias «programadas»

Algunas capturas falsas muestran transferencias «en proceso» o «programadas». Si el dinero no está en tu cuenta, no está pagado.



#### Casos


**Caso 1. La captura de Mariana**

Un cliente manda a Mariana una captura y pide que envíe ya.
- *¿Qué hace?* Revisa su app y envía solo cuando el depósito aparezca.


**Caso 2. La transferencia «en proceso»**

Un cliente de Toño dice que la transferencia está «en proceso» y quiere que empiece.
- *¿Qué hace?* Espera a que el dinero llegue o consulta el CEP.


**Caso 3. El código de Rosa**

Alguien que dice ser cliente le pide a Rosa el código que le llegó «para pagarle».
- *¿Qué hace?* No da el código: para pagarle solo necesita su CLABE.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar capturas | Pierdes mercancía | Revisa tu app |
| Dar códigos «para cobrar» | Te vacían la cuenta | Solo la CLABE |
| Sin alertas | No ves los depósitos | Actívalas |
| Límite alto en cuenta de cobro | Más riesgo | Bájalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Toño y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo entregas un pedido pagado por transferencia? a) Cuando te mandan la captura · b) Cuando el cliente te jura por teléfono que ya pagó · c) Cuando el dinero aparece en tu cuenta
2. ¿Qué necesitas dar para que te paguen? a) Tu CLABE o tu QR · b) Tu NIP · c) El código que te llegó por mensaje
3. ¿Qué es el CEP? a) Una captura del cliente · b) El comprobante de Banxico que confirma la transferencia · c) Un tipo de tarjeta
**Respuestas:** 1-c: la captura no es prueba. 2-a: basta para cobrar. 3-b: confirma que se liquidó.



#### Ponlo en práctica

Recibes 12 pedidos al día por transferencia. Si revisar cada uno en tu app toma 30 segundos, ¿cuánto tiempo al día te cuesta confirmar?
**Respuesta:** 6 minutos al día.



#### A tu plan

Activa las alertas de depósito en tu app y ajusta el límite de transferencias de tu cuenta de cobro.



### Para saber más

- **Comprobante Electrónico de Pago (CEP)** (Banco de México · español): https://www.banxico.org.mx/cep — **Qué buscar:** «descarga tu CEP».
- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes financieros».

### Palabras clave

- *SPEI:* sistema de pagos de Banco de México para transferencias entre bancos, casi al instante.
- *CEP:* Comprobante Electrónico de Pago que emite Banxico cuando una transferencia se liquida.
- *CLABE:* número de 18 dígitos para recibir transferencias.

### Fuentes

Banco de México · CNBV · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M4 U03. Fraudes al vender

**Lo que lograrás:** Reconocer los fraudes más comunes contra quien vende y tener un protocolo para no caer.

**Para empezar:** A Don Pepe le llamó alguien «del proveedor» para cobrarle un pedido por adelantado a otra cuenta. A Mariana le escribió un cliente que «le depositó de más» y pide que le regrese la diferencia. En esta lección verás estos y otros fraudes.

### Lo esencial (5 minutos)

#### Fraudes frecuentes al vender

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comprobante falso | Captura o ticket alterado. | Revisa tu app. |
| «Te deposité de más» | Te piden regresar la diferencia. | El pago original no existe o se revierte. |
| Tarjeta robada | Compra grande con link, prisa por el envío. | Contracargo. |
| Cambio de cuenta del proveedor | «Ahora deposita a esta otra cuenta». | Confirma por otro medio. |

#### Tu protocolo

1. Entrega solo con el dinero en tu cuenta.
2. Nunca regreses «excedentes» sin confirmar el depósito en tu app, y regrésalos solo a la misma cuenta de origen.
3. Ante cambios de cuenta de un proveedor, llama al número que ya tenías.
4. Desconfía de la prisa, las compras grandes de desconocidos y los envíos a otra dirección.



#### Un caso en un minuto

Mariana revisó su app: no había ningún depósito «de más». Le dijo al cliente que devolvería cualquier excedente cuando apareciera en su cuenta, a la misma cuenta de origen. El cliente dejó de escribir.

> **Idea clave:** prisa, excedentes y cambios de cuenta son señales de fraude; confirma en tu app y por un medio que tú elijas.



#### Comprueba lo que entendiste

1. ¿Qué haces si te dicen que te depositaron de más?
*Respuesta:* Revisas tu app; si el excedente está, lo devuelves solo a la cuenta de origen.

2. ¿Qué haces si un proveedor cambia de cuenta?
*Respuesta:* Confirmas llamando al número que ya tenías.


#### Para recordar

- Prisa = alerta.
- Confirma en tu app.
- Cambios de cuenta: llama tú.



### Profundiza (5 minutos más)

#### Contracargos

Si cobras con tarjeta y el titular desconoce la compra, su banco puede regresarle el dinero y tu proveedor de pagos te lo descuenta. Guarda pruebas de entrega (guía de paquetería, firma, fotos) y evita envíos grandes a desconocidos con pagos a distancia.



#### Si ya te pasó

Guarda capturas, mensajes y números. Reporta a tu banco o proveedor de pagos, reclama por escrito y guarda el folio. Si hubo engaño, denuncia ante la fiscalía y al 088. Avisa a otros vendedores en la comunidad, sin datos personales.

> **Antes de actuar, verifica:** cualquier cambio de datos de pago de un proveedor por un medio que tú elijas, y nunca con el número o enlace que venga en el mismo mensaje.



#### Casos


**Caso 1. El «depósito de más»**

Un cliente dice a Mariana que le depositó 2,000 de más y pide que se los regrese.
- *¿Qué hace?* Revisa su app y solo devuelve un excedente real a la cuenta de origen.


**Caso 2. El proveedor de Don Pepe**

Una llamada «del proveedor» pide a Don Pepe pagar un pedido a una cuenta nueva.
- *¿Qué hace?* Cuelga y llama al número del proveedor que ya tenía.


**Caso 3. El pedido grande de Toño**

Un desconocido pide a Toño material por 15,000 con link de pago y envío urgente a otra ciudad.
- *¿Qué hace?* Desconfía, pide confirmación y no envía sin verificar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Devolver excedentes sin revisar | Pierdes dinero | Revisa tu app |
| Pagar a cuentas nuevas | Proveedor falso | Llama al número conocido |
| Envíos urgentes a desconocidos | Contracargo | Verifica |
| No guardar pruebas | No puedes reclamar | Guarda todo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Don Pepe y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un cliente dice que te depositó de más. ¿Qué haces primero? a) Le regresas la diferencia de inmediato para quedar bien · b) Revisas tu app para ver si el excedente existe · c) Le das su número de cuenta a otro cliente
2. Tu proveedor te escribe que cambió de cuenta. ¿Qué haces? a) Pagas a la nueva cuenta · b) Respondes al mismo mensaje · c) Llamas al número que ya tenías
3. ¿Cuál es una señal de fraude al vender? a) Prisa y compra grande de un desconocido · b) Un cliente que pregunta por tallas, colores y tiempos de envío · c) Un pago que ya está en tu cuenta
**Respuestas:** 1-b: casi nunca existe. 2-c: confirma por otro medio. 3-a: la prisa es un gancho.



#### Ponlo en práctica

En un año, tres capturas falsas te costaron 900, 1,200 y 650. ¿Cuánto habrías evitado revisando tu app?
**Respuesta:** 2,750.



#### A tu plan

Escribe tu protocolo contra fraudes en una tarjeta y pégala donde cobras.



### Para saber más

- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes financieros».
- **Denuncia** (Guardia Nacional · español): 088 — **Qué buscar:** fraude y delitos en línea.

### Palabras clave

- *Excedente falso:* engaño en el que te piden regresar un pago de más que no existe.
- *Suplantación de proveedor:* fraude en el que alguien se hace pasar por tu proveedor para que pagues a otra cuenta.

### Fuentes

CONDUSEF · Guardia Nacional, consultados el 29 de septiembre de 2026.

---


# Parte 6. Módulo 5. Formalízate sin miedo

## M5 U01. ¿Por qué formalizarte y por dónde empezar?

**Lo que lograrás:** Conocer los beneficios y costos de formalizarte y los primeros pasos: RFC, e.firma, buzón tributario y permisos locales.

**Para empezar:** Toño perdió un contrato con una constructora porque no podía facturar. Le da miedo inscribirse en el SAT: cree que le cobrarán mucho y que lo van a multar. En esta lección verás qué gana y qué cuesta formalizarse.

### Lo esencial (5 minutos)

#### Lo que ganas al formalizarte

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Puedes facturar | Vendes a empresas y gobierno. | Más clientes. |
| Acceso a crédito | Con historial de ingresos. | Tasas más bajas. |
| Seguridad social | Con IMSS voluntario (M7 U01). | Salud y retiro. |
| Tranquilidad | Sin miedo a revisiones. | Crecer sin esconderte. |

#### Primeros pasos con el SAT

1. Inscríbete en el RFC con tu CURP, en el sitio del SAT o con cita.
2. Tramita tu e.firma en una oficina del SAT, con cita.
3. Activa tu buzón tributario con un correo y un celular tuyos.
4. Elige tu actividad y régimen (M5 U02) y genera tu contraseña.



#### También cuenta lo local

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Licencia o aviso del municipio | Según tu giro y ubicación. | Pregunta en tu alcaldía o municipio. |
| Protección Civil | Para locales con público. | Revisa requisitos. |
| Aviso sanitario | Para comida y alimentos. | COFEPRIS o salud estatal. |
| Gestores que cobran de más | El trámite del RFC es gratis. | No pagues por él. |

#### Un caso en un minuto

Toño sacó cita en el SAT, se inscribió en RESICO y tramitó su e.firma sin pagar a nadie. Una semana después emitió su primera factura a la constructora.

> **Idea clave:** formalizarte abre clientes, crédito y seguridad social; los trámites del SAT son gratuitos y puedes empezar por el RFC.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta inscribirte en el RFC?
*Respuesta:* Nada: es gratuito.

2. ¿Para qué sirve la e.firma?
*Respuesta:* Para trámites del SAT y para facturar.


#### Para recordar

- RFC, e.firma y buzón: gratis.
- Permisos locales según giro.
- Sin gestores para el RFC.



### Profundiza (5 minutos más)

#### Beneficios y costos

| Beneficio | Costo |
|---|---|
| Facturar y vender a empresas | Pagar impuestos |
| Crédito con mejores condiciones | Presentar declaraciones |
| Seguridad social voluntaria | Cuota del IMSS |
| Sin riesgo de multas por no registrarte | Tiempo o un contador |



#### Tus claves son solo tuyas

Tu contraseña del SAT y tu e.firma son como tu firma autógrafa. No las compartas por WhatsApp ni las dejes con un gestor. Si un contador te ayuda, que use su propio acceso o tu autorización formal, y cambia tu contraseña si dejas de trabajar con él.



#### Ayuda gratuita

El SAT atiende con cita y por teléfono. PRODECON orienta gratis y te defiende ante el SAT si tienes un problema. En la comunidad del curso también hay sesiones de dudas.

> **Antes de actuar, verifica:** los requisitos y citas en el sitio oficial del SAT (sat.gob.mx); desconfía de páginas o personas que cobran por sacarte el RFC.



#### Casos


**Caso 1. El contrato de Toño**

Una constructora pide factura a Toño para contratarlo.
- *¿Qué hace?* Se inscribe en el RFC, tramita su e.firma y elige régimen.


**Caso 2. El gestor de Rosa**

Un gestor ofrece a Rosa sacarle el RFC por 1,500.
- *¿Qué hace?* Lo tramita ella gratis en el SAT, con cita.


**Caso 3. La contraseña de Mariana**

Su contadora le pide a Mariana su e.firma por WhatsApp.
- *¿Qué hace?* No la manda; pregunta por una forma formal y segura de autorizarla.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por el RFC | Gasto innecesario | Es gratis |
| Compartir e.firma | Te suplantan | Solo tú |
| No activar el buzón | No ves avisos | Actívalo |
| Olvidar lo local | Clausura | Pregunta en tu municipio |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Rosa y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cobra el SAT por inscribirte en el RFC? a) Depende del gestor · b) Nada · c) 1,500
2. ¿Dónde recibes avisos oficiales del SAT? a) Por WhatsApp de un número desconocido · b) En redes sociales · c) En tu buzón tributario
3. ¿Qué haces con tu e.firma? a) La guardas solo tú · b) La compartes con quien te ayude · c) La subes a una nube pública
**Respuestas:** 1-b: es gratuito. 2-c: canal oficial. 3-a: es tu firma.



#### Ponlo en práctica

Un gestor cobra 1,500 por el RFC y 800 por la e.firma. ¿Cuánto te ahorras haciéndolo tú?
**Respuesta:** 2,300.



#### A tu plan

Revisa qué necesitas para tu RFC en el sitio del SAT y pregunta en tu municipio qué permisos requiere tu giro.



### Para saber más

- **Inscripción al RFC** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «inscripción en el RFC con CURP».
- **Orientación gratuita** (PRODECON · español): https://www.gob.mx/prodecon — **Qué buscar:** «asesoría».

### Palabras clave

- *RFC:* Registro Federal de Contribuyentes: tu clave para el SAT.
- *e.firma:* firma electrónica del SAT; sirve para trámites y para facturar.
- *Buzón tributario:* buzón en el sitio del SAT donde recibes avisos y notificaciones oficiales.

### Fuentes

SAT · PRODECON, consultados el 29 de septiembre de 2026.

---

## M5 U02. RESICO: el régimen para empezar

**Lo que lograrás:** Conocer el Régimen Simplificado de Confianza (RESICO) para personas físicas, sus tasas, límites y cuándo conviene otro régimen.

**Para empezar:** Toño cobra unos 22,000 al mes. Le dijeron que en RESICO paga «muy poquito». Pero también compra mucho material. En esta lección verás cómo funciona y cuándo conviene.

### Lo esencial (5 minutos)

#### Qué es

El RESICO para personas físicas es un régimen del SAT en el que pagas ISR con una tasa baja **sobre lo que cobras** (sin IVA), sin restar gastos.

> **Dato vigente:** en RESICO de personas físicas, la tasa mensual va de 1% a 2.5% según lo que cobras en el mes: hasta 25,000, 1%; hasta 50,000, 1.1%; hasta 83,333.33, 1.5%; hasta 208,333.33, 2%; y más, hasta 3.5 millones al año, 2.5%. Si facturas a una empresa (persona moral), te retiene 1.25%. Sin cambios de tasa en 2026. Consultado el 29 de septiembre de 2026 a través del SAT y la Ley del ISR (arts. 113-E y 113-J).



#### El ISR de Toño en un mes

- Lo que cobró (sin IVA): **22,000**
× 1% | Tasa por cobrar hasta 25,000
- ISR del mes: **220**
Si la constructora le retuvo 1.25% (275 de un trabajo), lo resta de su pago.


#### Lo que debes saber

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tasa baja | De 1% a 2.5%. | Sobre lo que cobras. |
| Sin deducciones | No restas gastos del negocio. | Aunque compres mucho. |
| Límite | 3.5 millones al año. | Si lo rebasas, cambias. |
| No pueden entrar | Socios de empresas, asimilados y otros casos. | Revisa tu caso. |

#### Un caso en un minuto

Toño gasta en material 40% de lo que cobra. Aun así, en RESICO paga 1% sobre sus cobros; en el régimen de actividad empresarial podría deducir el material, pero con tasas más altas. Su contador le mostró que RESICO le conviene por ahora.

> **Idea clave:** RESICO cobra poco y es sencillo, pero no permite deducir; compara con un contador si tus gastos son muy altos.



#### Comprueba lo que entendiste

1. ¿Sobre qué pagas en RESICO?
*Respuesta:* Sobre lo que cobras, sin IVA y sin restar gastos.

2. ¿Cuánto te retiene una empresa si le facturas?
*Respuesta:* 1.25% de ISR.


#### Para recordar

- 1% a 2.5% sobre cobros.
- Sin deducciones.
- Hasta 3.5 millones al año.



### Profundiza (5 minutos más)

#### RESICO contra actividad empresarial

| | RESICO | Actividad empresarial |
|---|---|---|
| Tasa | 1% a 2.5% sobre cobros | Tarifa progresiva sobre ganancia (hasta 35%) |
| Deducciones | No | Sí, con factura |
| Complejidad | Baja | Mayor |
| Conviene si | Gastos bajos o medianos | Gastos muy altos o ganancia baja |



#### Declaración anual

La ley pide declaración anual, pero la Resolución Miscelánea Fiscal libera de presentarla a quien estuvo en RESICO todo el año, presentó todos sus pagos mensuales, no rebasó 3.5 millones y no tuvo otros ingresos. Revisa tu caso cada año.

> **Dato vigente:** la regla 3.13.7 de la Resolución Miscelánea Fiscal 2026 exime de la declaración anual a quien cumple esas condiciones. Consultado el 29 de septiembre de 2026 a través del SAT.



#### Cuidado con salir del régimen

Si no presentas pagos, rebasas el límite o tienes ingresos que lo impiden, el SAT puede cambiarte de régimen. Presenta tus pagos a tiempo y revisa si otros ingresos te afectan.



#### Casos


**Caso 1. El régimen de Toño**

Toño cobra 22,000 al mes y gasta 40% en material.
- *¿Qué hace?* Compara RESICO con actividad empresarial con un contador antes de elegir.


**Caso 2. La retención de la constructora**

La constructora retiene a Toño 1.25% en su factura.
- *¿Qué hace con esa retención?* La resta de su pago mensual de ISR.


**Caso 3. El socio de Mariana**

Mariana es socia de una pequeña empresa de su familia.
- *¿Qué revisa?* Si ser socia le impide entrar a RESICO.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que se deducen gastos | Pagas lo mismo | No hay deducciones |
| Olvidar la retención | Pagas doble | Réstala |
| No presentar pagos | Te sacan del régimen | Paga a tiempo |
| Elegir sin comparar | Pagas de más | Revisa con contador |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobras 40,000 en un mes en RESICO. ¿Tasa? a) 1% · b) 2.5% · c) 1.1%
2. ¿Puedes deducir gastos del negocio en RESICO? a) No · b) Sí, todos · c) Solo la gasolina
3. ¿Cuál es el límite de ingresos de RESICO? a) 300,000 al año · b) 3.5 millones al año · c) No tiene límite
**Respuestas:** 1-c: de 25,000 a 50,000. 2-a: se paga sobre cobros. 3-b: límite anual.



#### Ponlo en práctica

Cobras 60,000 en un mes. ¿Cuánto ISR pagas en RESICO?
**Respuesta:** 1.5% de 60,000: 900.



#### A tu plan

Suma lo que cobras en un mes típico y ubica tu tasa en RESICO.



### Para saber más

- **RESICO personas físicas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «Régimen Simplificado de Confianza personas físicas».

### Palabras clave

- *RESICO:* Régimen Simplificado de Confianza: pagas ISR con una tasa baja sobre lo que cobras, sin deducir gastos.
- *Retención:* impuesto que tu cliente descuenta de tu pago y entrega al SAT por ti.
- *ISR:* impuesto sobre la renta.

### Fuentes

SAT · Ley del ISR · Resolución Miscelánea Fiscal 2026, consultados el 29 de septiembre de 2026.

---

## M5 U03. Facturar sin miedo

**Lo que lograrás:** Emitir facturas CFDI 4.0 correctas, hacer la factura global y saber cuándo y cómo cancelar.

**Para empezar:** Toño emitió su primera factura, pero la constructora se la rechazó porque el código postal del cliente no coincidía. En esta lección verás qué datos pide la factura y cómo evitar errores.

### Lo esencial (5 minutos)

#### Qué es una factura

Una factura (CFDI) prueba una venta ante el SAT. Puedes emitirla gratis en el portal del SAT o con un proveedor de facturación.



#### Datos que te pide tu cliente

1. RFC.
2. Nombre o razón social exactos, como en su constancia de situación fiscal.
3. Código postal fiscal.
4. Régimen fiscal.
5. Uso del CFDI (para qué la usará).



#### Tipos de factura

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| A un cliente | Con sus datos. | Por cada venta que te pidan. |
| Global | Público en general. | Ventas sin factura de un periodo. |
| Con complemento de pago | Si te pagan en parcialidades o después. | Cuando cobras. |
| Con datos «aproximados» | Te la rechazan. | Datos exactos. |

#### Un caso en un minuto

Toño pidió a la constructora su constancia de situación fiscal y copió los datos exactos. Su factura corregida se aceptó. Guardó una plantilla con los datos para las siguientes.

> **Idea clave:** pide la constancia de tu cliente y copia sus datos exactos; las ventas sin factura van en una factura global.



#### Comprueba lo que entendiste

1. ¿De dónde tomas los datos de tu cliente?
*Respuesta:* De su constancia de situación fiscal.

2. ¿Qué es la factura global?
*Respuesta:* La que agrupa las ventas a público en general que no facturaste.


#### Para recordar

- Datos exactos de la constancia.
- Factura global para público en general.
- Portal del SAT gratis.



### Profundiza (5 minutos más)

#### La factura global

Las ventas a clientes que no piden factura se reportan en una factura global a «público en general», con la periodicidad que te corresponda (diaria, semanal, quincenal, mensual o bimestral según tu régimen). Así tus ingresos quedan completos.



#### Cancelar una factura

Puedes cancelar una factura con error y emitir otra. En muchos casos el cliente debe aceptar la cancelación, y hay plazos: se puede cancelar a más tardar en el mes en que debes presentar la declaración anual del año en que la emitiste. Cancela pronto y avisa a tu cliente.



#### Cuidado con facturas falsas

Nunca compres facturas para «bajar impuestos» ni vendas tu RFC para que otros facturen: el SAT publica listas de contribuyentes con operaciones simuladas y las consecuencias son graves.

> **Antes de actuar, verifica:** las reglas de factura global y cancelación en el sitio del SAT; cambian con la Resolución Miscelánea de cada año.



#### Casos


**Caso 1. La factura rechazada de Toño**

La constructora rechazó la factura de Toño por el código postal.
- *¿Qué hace?* Pide la constancia, cancela y emite una nueva con datos exactos.


**Caso 2. Las ventas de mostrador de Rosa**

Casi ningún cliente de Rosa le pide factura.
- *¿Qué hace con esas ventas?* Las incluye en su factura global a público en general.


**Caso 3. La oferta de facturas**

Alguien ofrece a Don Pepe facturas de gastos «para pagar menos».
- *¿Qué hace?* Las rechaza: son ilegales y pueden traerle problemas graves.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Datos aproximados | Rechazo | Constancia |
| No hacer factura global | Ingresos incompletos | Periodicidad |
| Cancelar tarde | Fuera de plazo | Cancela pronto |
| Comprar facturas | Delito fiscal | Nunca |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Rosa y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿De dónde tomas los datos para facturar? a) De la constancia de situación fiscal del cliente · b) De lo que el cliente te dicte por teléfono o por mensaje · c) De una factura vieja
2. ¿Qué haces con las ventas a quien no pidió factura? a) No las reportas · b) Las facturas a tu nombre · c) Las incluyes en la factura global
3. Te ofrecen facturas de gastos para pagar menos impuestos. ¿Qué haces? a) Compras pocas · b) Las rechazas · c) Preguntas el precio
**Respuestas:** 1-a: datos exactos. 2-c: público en general. 3-b: son ilegales.



#### Ponlo en práctica

En una semana vendiste 4,800 a público en general y 2,000 con factura a un cliente. ¿Cuánto va en la factura global?
**Respuesta:** 4,800.



#### A tu plan

Entra al portal de facturación del SAT o a tu proveedor y guarda una plantilla con los datos de tu cliente principal.



### Para saber más

- **Factura electrónica** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «genera tu factura» y «factura global».

### Palabras clave

- *Factura (CFDI):* Comprobante Fiscal Digital por Internet: documento del SAT que prueba una venta.
- *Constancia de situación fiscal:* documento del SAT con tu RFC, nombre, régimen y código postal fiscal.
- *Factura global:* factura que agrupa las ventas a público en general de un periodo.

### Fuentes

SAT, consultado el 29 de septiembre de 2026.

---

## M5 U04. El IVA de tu negocio

**Lo que lograrás:** Saber qué ventas llevan IVA, cómo se calcula lo que pagas y qué IVA puedes acreditar.

**Para empezar:** Rosa pensaba que el IVA era un impuesto que ella pagaba de su bolsa. Ahora que se formalizó, no sabe si su comida lleva IVA ni cuánto. En esta lección verás cómo funciona.

### Lo esencial (5 minutos)

#### El IVA lo paga tu cliente

El IVA lo cobras a tu cliente y lo entregas al SAT. Del IVA que cobraste restas el IVA que pagaste en tus compras del negocio con factura (lo acreditas). Pagas la diferencia.



#### Tasas más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 16% | Servicios, ropa, comida preparada. | La tasa general. |
| 0% | Alimentos no preparados y medicinas, entre otros. | Tasa cero. |
| 8% | Frontera norte y sur, con estímulo. | Requisitos. |
| «Sin IVA» por costumbre | Si tu venta lleva IVA, se cobra. | Revisa tu giro. |

#### El IVA de Rosa en un mes

- IVA cobrado (16% de 20,000 de comida preparada): **3,200**
- IVA de compras con factura (gas, desechables): **400**
- IVA a pagar: **2,800**
Las tortillas y verduras que compra llevan tasa 0%: no tienen IVA que acreditar.


#### Un caso en un minuto

Rosa pensaba que el IVA se le iba de su ganancia. Revisó sus precios: incluyen el IVA. Cada mes separa el 16% del precio (13.8% de lo que cobra) en su cuenta del negocio para pagarlo.

> **Idea clave:** el IVA no es tuyo: es de tu cliente para el SAT; sepáralo de tus ventas desde que cobras.



#### Comprueba lo que entendiste

1. ¿Quién paga el IVA?
*Respuesta:* Tu cliente; tú lo cobras y lo entregas al SAT.

2. ¿Qué IVA puedes restar?
*Respuesta:* El que pagaste en compras del negocio con factura.


#### Para recordar

- IVA cobrado menos IVA acreditable.
- 16% general, 0% algunos productos.
- Sepáralo al cobrar.



### Profundiza (5 minutos más)

#### IVA incluido en tu precio

Si tu precio ya incluye IVA, divide entre 1.16 para saber la venta sin IVA. Una comida de 85 con IVA incluido son 73.28 de venta y 11.72 de IVA.



#### Facturas de tus compras

Para acreditar IVA necesitas factura a tu RFC y que el gasto sea del negocio. Pide factura de gas, luz, internet, material y equipo.



#### Si vendes en plataformas

Las plataformas digitales retienen IVA a quien vende por ellas (M8 U02). Esa retención se resta de tu IVA a pagar.

> **Antes de actuar, verifica:** la tasa de IVA de tus productos y servicios con el SAT o con un contador; algunos alimentos y servicios tienen reglas especiales.



#### Casos


**Caso 1. Los precios de Rosa**

Rosa no sabe si su precio de 85 incluye IVA.
- *¿Qué hace?* Divide entre 1.16 para saber cuánto es IVA y lo separa al cobrar.


**Caso 2. Las compras de Toño**

Toño compra material sin pedir factura.
- *¿Qué hace?* Pide factura a su RFC para poder acreditar el IVA.


**Caso 3. La tienda de Don Pepe**

Don Pepe vende refrescos, pan y frutas.
- *¿Qué revisa?* Qué productos llevan 16% y cuáles 0%.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que el IVA es tuyo | Te lo gastas | Sepáralo |
| No pedir factura | Pagas más IVA | Factura a tu RFC |
| Aplicar 16% a todo | Precio alto | Revisa tasas |
| Olvidar retenciones | Pagas doble | Réstalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Toño y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Cobraste 1,600 de IVA y pagaste 500 en compras con factura. ¿Cuánto pagas? a) 2,100 · b) 1,100 · c) 1,600
2. Un precio de 116 incluye IVA. ¿Cuánto es la venta sin IVA? a) 116 · b) 16 · c) 100
3. ¿Qué necesitas para acreditar el IVA de una compra? a) Factura a tu RFC · b) El ticket · c) Una foto del producto
**Respuestas:** 1-b: 1,600 menos 500. 2-c: 116 entre 1.16. 3-a: con factura.



#### Ponlo en práctica

Vendes 30,000 más IVA al mes y compras 10,000 más IVA con factura. ¿Cuánto IVA pagas?
**Respuesta:** 4,800 menos 1,600: 3,200.



#### A tu plan

Revisa qué tasa de IVA llevan tus productos y cuánto IVA separas cada mes.



### Para saber más

- **IVA** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «IVA» y «tasa 0%».

### Palabras clave

- *IVA:* impuesto al valor agregado: lo cobras a tu cliente y lo entregas al SAT, menos el IVA que pagaste en tus compras.
- *Acreditar:* restar el IVA que pagaste en tus compras del IVA que cobraste.
- *Tasa 0%:* productos que llevan IVA, pero con tasa cero.

### Fuentes

SAT · Ley del IVA, consultados el 29 de septiembre de 2026.

---

## M5 U05. Tus declaraciones

**Lo que lograrás:** Conocer tu calendario de pagos mensuales, la declaración anual y cuándo conviene buscar un contador.

**Para empezar:** Toño ya factura, pero no sabe cuándo pagar ni qué pasa si se atrasa. Le llegó un mensaje «del SAT» con un enlace. En esta lección verás tu calendario y cómo cuidarte.

### Lo esencial (5 minutos)

#### Tu calendario

1. **Cada mes**, a más tardar el día 17 del mes siguiente: pago de ISR (RESICO) e IVA.
2. **Cada año**: declaración anual si te corresponde (abril para personas físicas).
3. **Siempre**: revisa tu buzón tributario.



#### Cómo hacerlo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tú, en el portal del SAT | En RESICO, el SAT prellena con tus facturas. | Revisa antes de enviar. |
| Con un contador | Si tienes empleados, varios ingresos o muchos gastos. | Pide cotización y contrato. |
| A destiempo | Recargos y actualización. | Paga a tiempo. |
| Enlaces de mensajes «del SAT» | Casi siempre son fraude. | Entra tú a sat.gob.mx. |

#### Un caso en un minuto

Toño puso una alarma el día 10 de cada mes. Entra al portal del SAT, revisa lo prellenado con sus facturas, resta la retención de la constructora y paga en línea. Le toma 20 minutos.

> **Idea clave:** declara cada mes a tiempo, revisa lo prellenado y entra al SAT tú mismo, nunca desde un enlace.



#### Comprueba lo que entendiste

1. ¿Hasta cuándo presentas tu pago mensual?
*Respuesta:* A más tardar el día 17 del mes siguiente.

2. ¿Qué haces si te llega un mensaje «del SAT» con un enlace?
*Respuesta:* No lo abres; entras tú al sitio oficial y revisas tu buzón.


#### Para recordar

- Día 17 de cada mes.
- Revisa lo prellenado.
- SAT solo en sat.gob.mx.



### Profundiza (5 minutos más)

#### Elegir un contador

Pregunta qué incluye (declaraciones, facturas, nómina), cuánto cobra al mes y cómo te entrega los acuses. Pide un contrato sencillo. Que use tu autorización formal y no tu e.firma por mensaje. Pide siempre copia de tus acuses de declaración.



#### Si te atrasaste

Presenta cuanto antes: los recargos crecen cada mes. Si no puedes pagar todo, el SAT tiene opciones de pago en parcialidades. PRODECON orienta gratis si tienes una diferencia con el SAT.



#### Si tienes 0 ventas en un mes

En muchos casos igual debes presentar tu declaración en ceros. Revisa tu caso en el portal: no presentar puede sacarte de RESICO.

> **Antes de actuar, verifica:** fechas y obligaciones en el calendario oficial del SAT; pueden cambiar con la Resolución Miscelánea de cada año.



#### Casos


**Caso 1. El mensaje de Toño**

A Toño le llega un mensaje «del SAT» con un enlace para evitar una multa.
- *¿Qué hace?* No abre el enlace y revisa su buzón en sat.gob.mx.


**Caso 2. El mes sin ventas de Mariana**

Mariana no vendió nada en febrero.
- *¿Qué hace?* Revisa si debe presentar su declaración en ceros y la presenta.


**Caso 3. El atraso de Rosa**

Rosa no presentó dos meses.
- *¿Qué hace?* Presenta cuanto antes y, si no puede pagar todo, revisa el pago en parcialidades.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Enlaces de mensajes | Fraude | Entra tú |
| No presentar en ceros | Te sacan del régimen | Revisa tu caso |
| Dejar pasar atrasos | Recargos | Presenta pronto |
| Contador sin acuses | No sabes qué presentó | Pide copias |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Mariana y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Hasta qué día presentas el pago de marzo? a) 30 de marzo · b) 1 de abril · c) 17 de abril
2. Te llega un correo «del SAT» con un enlace. ¿Qué haces? a) Entras tú a sat.gob.mx y revisas tu buzón · b) Abres el enlace para evitar la multa · c) Lo reenvías a tu contador para que lo abra
3. ¿Qué pides siempre a tu contador? a) Tu contraseña de vuelta · b) Copia de tus acuses · c) Que no te diga cuánto pagaste
**Respuestas:** 1-c: día 17 del mes siguiente. 2-a: canal oficial. 3-b: así sabes qué presentó.



#### Ponlo en práctica

Cobras 20,000 al mes en RESICO todo el año. ¿Cuánto ISR pagas en el año, sin retenciones?
**Respuesta:** 1% de 20,000 por 12: 2,400.



#### A tu plan

Pon un recordatorio mensual antes del día 17 y revisa tu buzón tributario una vez al mes.



### Para saber más

- **Declaraciones** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «declaraciones RESICO» y «calendario fiscal».
- **Defensa del contribuyente** (PRODECON · español): https://www.gob.mx/prodecon — **Qué buscar:** «asesoría y quejas».

### Palabras clave

- *Declaración mensual:* pago de impuestos del mes que se presenta en el portal del SAT.
- *Acuse:* comprobante de que presentaste una declaración.
- *Recargos:* cobro extra por pagar impuestos tarde.

### Fuentes

SAT · PRODECON, consultados el 29 de septiembre de 2026.

---


# Parte 7. Módulo 6. Crédito para tu negocio

## M6 U01. ¿Necesitas crédito?

**Lo que lograrás:** Distinguir el crédito que ayuda a crecer del que solo tapa problemas, y decidir con números si te conviene.

**Para empezar:** A Don Pepe le ofrecen un crédito de 80,000 para ampliar su tienda y poner un refrigerador más. Se emociona, pero no sabe si la tienda podrá pagarlo. En esta lección verás cómo decidir.

### Lo esencial (5 minutos)

#### Para qué pides

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Para crecer | Equipo o mercancía que genera ventas. | Puede pagarse solo. |
| Para capital de trabajo | Temporadas o pedidos grandes. | Si ya tienes el cliente. |
| Para tapar pérdidas | El negocio no gana. | Agranda el problema. |
| Para gastos de la casa | Con crédito del negocio. | Mezcla. |

#### La pregunta clave

¿Cuánto más ganarás con lo que compras con el crédito? Si la ganancia extra al mes es **mayor** que el pago mensual, el crédito puede pagarse solo. Si no, lo pagarás de tu sueldo o de tu reserva.



#### El refrigerador de Don Pepe

- Ganancia extra al mes esperada (bebidas frías): **3,500**
- Pago mensual del crédito: **2,900**
- Lo que le queda: **600**
Si las ventas extra fueran la mitad, le faltarían 1,150 cada mes.


#### Un caso en un minuto

Don Pepe hizo cuentas con un escenario prudente: solo la mitad de las ventas esperadas. Le faltarían 1,150 al mes. Decidió pedir menos: un refrigerador más pequeño con un pago de 1,500.

> **Idea clave:** pide crédito para algo que genere ventas y haz cuentas con un escenario prudente.



#### Comprueba lo que entendiste

1. ¿Cuándo puede pagarse solo un crédito?
*Respuesta:* Cuando la ganancia extra que genera es mayor que el pago mensual.

2. ¿Por qué no pedir crédito para tapar pérdidas?
*Respuesta:* Porque el negocio no gana y la deuda agranda el problema.


#### Para recordar

- Crédito para crecer, no para tapar.
- Ganancia extra mayor que el pago.
- Escenario prudente.



### Profundiza (5 minutos más)

#### Decide con números

| Dato | Escenario esperado | Escenario prudente (mitad) |
|---|---|---|
| Ventas extra al mes | | |
| Ganancia extra al mes | | |
| Pago mensual del crédito | | |
| Diferencia | | |



#### Antes de pedir, revisa alternativas

Anticipos de clientes, plazo con proveedores, vender inventario parado o usar parte de la reserva pueden resolver sin crédito. Si el problema es de precio o costos (M2), el crédito no lo arregla.



#### Casos


**Caso 1. El refrigerador de Don Pepe**

Don Pepe calcula que el crédito se paga solo, pero con ventas optimistas.
- *¿Qué hace?* Revisa un escenario prudente antes de firmar.


**Caso 2. Las pérdidas de Rosa**

La fonda de Rosa pierde dinero desde hace tres meses y le ofrecen un crédito.
- *¿Qué hace?* Primero corrige precio y costos; no usa crédito para tapar pérdidas.


**Caso 3. El pedido de Toño**

Toño tiene un contrato firmado y necesita material para cumplirlo.
- *¿Qué revisa primero?* Si puede pedir anticipo al cliente antes de pedir crédito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Crédito para tapar pérdidas | Deuda mayor | Corrige el negocio |
| Cuentas optimistas | No alcanza | Escenario prudente |
| Pedir de más | Pagos altos | Lo necesario |
| No revisar alternativas | Intereses innecesarios | Anticipos y plazos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Rosa y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. La ganancia extra es 2,000 al mes y el pago es 2,500. ¿Qué pasa? a) El crédito se paga solo · b) Te faltan 500 al mes · c) Ganas 500
2. ¿Para qué es más sano un crédito del negocio? a) Para pagar gastos de la casa · b) Para cubrir pérdidas · c) Para algo que genere ventas
3. ¿Qué haces antes de pedir un crédito para un pedido? a) Revisas si el cliente puede dar anticipo · b) Pides el monto máximo · c) Firmas rápido el primer crédito para no perder la oferta del día
**Respuestas:** 1-b: pago mayor que ganancia. 2-c: puede pagarse solo. 3-a: alternativa sin intereses.



#### Ponlo en práctica

Una máquina te dejaría 4,000 al mes de ganancia extra. En un escenario prudente, la mitad. El pago es 1,800. ¿Te conviene?
**Respuesta:** Prudente: 2,000 menos 1,800: te quedan 200. Conviene, con poco margen.



#### A tu plan

Si piensas pedir crédito, llena la tabla con un escenario esperado y uno prudente.



### Para saber más

- **Simuladores de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador de crédito PyME».

### Palabras clave

- *Capital de trabajo:* dinero para operar el día a día: mercancía, insumos y pagos.
- *Escenario prudente:* cálculo con ventas menores a las esperadas.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---

## M6 U02. Opciones de crédito y cómo verificarlas

**Lo que lograrás:** Conocer las opciones de crédito para pequeños negocios y verificar que quien presta esté autorizado.

**Para empezar:** A Rosa le llegó un mensaje: «Crédito para tu negocio sin Buró, solo manda tu INE y un depósito de 500 para activarlo». En esta lección verás las opciones reales y cómo detectar fraudes.

### Lo esencial (5 minutos)

#### Opciones que puedes revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Banco | Créditos para persona física con actividad o PyME. | Piden historial y RFC. |
| Programas públicos y banca de desarrollo | Algunos con garantías o tasas preferentes. | A través de bancos. |
| Crédito de proveedores | Pagas la mercancía a 15 o 30 días. | Muchas veces sin intereses. |
| Apps «sin Buró» | Costos muy altos o fraude. | Verifica antes. |

#### Verifica antes de pedir

1. Busca el nombre en el SIPRES de CONDUSEF.
2. Revisa el padrón de la CNBV y el Buró de Entidades Financieras.
3. Compara el costo total (M6 U03).
4. Nunca pagues por adelantado para «liberar» un crédito.



#### Un caso en un minuto

Rosa buscó la «financiera» del mensaje en el SIPRES: no existía. Borró el mensaje. Luego preguntó en su banco por un crédito para negocio y comparó el costo con el de su proveedor de insumos, que le daba 15 días sin intereses.

> **Idea clave:** verifica en CONDUSEF y la CNBV; quien te pide dinero por adelantado para darte un crédito es un fraude.



#### Comprueba lo que entendiste

1. ¿Dónde verificas a quien presta?
*Respuesta:* En el SIPRES de CONDUSEF y el padrón de la CNBV.

2. ¿Qué haces si te piden un depósito para liberar un crédito?
*Respuesta:* No depositas: es fraude.


#### Para recordar

- Verifica en SIPRES y CNBV.
- Crédito de proveedores primero.
- Nunca pagues por adelantado.



### Profundiza (5 minutos más)

#### «Montadeudas» y préstamos gota a gota

Algunas apps y prestamistas informales cobran intereses altísimos, acceden a tus contactos y cobran con amenazas. El préstamo «gota a gota» (pagos diarios, cobradores en moto) es ilegal y peligroso. Si te amenazan, denuncia al 088 y a la fiscalía, y reporta la app a CONDUSEF.



#### Sobre ciertas entidades

Este curso no recomienda SOFIPO, SOCAP ni SOFOM. Si te ofrecen crédito, compara primero con bancos, programas públicos y proveedores, y verifica siempre en CONDUSEF.



#### Qué te pedirán

RFC, comprobante de domicilio, identificación, estados de cuenta del negocio y, a veces, declaraciones. Por eso separar tu dinero (M1) y formalizarte (M5) te abren mejores opciones.

> **Antes de actuar, verifica:** a la institución en el SIPRES de CONDUSEF y su nombre exacto; los fraudes usan nombres parecidos a los reales.



#### Casos


**Caso 1. El mensaje a Rosa**

Un mensaje ofrece a Rosa crédito «sin Buró» si deposita 500 para activarlo.
- *¿Qué hace?* No deposita y verifica en CONDUSEF; es señal de fraude.


**Caso 2. El proveedor de Don Pepe**

El proveedor de Don Pepe ofrece 30 días para pagar sin intereses.
- *¿Qué hace?* Lo aprovecha si puede vender la mercancía en ese plazo.


**Caso 3. La app de Mariana**

Una app presta a Mariana en minutos, pero pide acceso a sus contactos.
- *¿Qué hace?* No la usa y busca opciones verificadas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar para «liberar» | Fraude | Nunca |
| No verificar | Entidad falsa | SIPRES |
| Apps con acceso a contactos | Cobranza abusiva | Evítalas |
| Ignorar al proveedor | Pagas intereses | Plazo sin intereses |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Don Pepe y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden un depósito para liberar tu crédito. ¿Qué es? a) Un trámite normal · b) Una comisión de apertura · c) Una señal de fraude
2. ¿Dónde verificas si una entidad está registrada? a) En el SIPRES de CONDUSEF · b) En sus redes sociales · c) En las reseñas de la app
3. ¿Qué opción suele no cobrar intereses si pagas a tiempo? a) Las apps sin Buró · b) El crédito de proveedores · c) El préstamo gota a gota
**Respuestas:** 1-c: nunca pagues por adelantado. 2-a: registro oficial. 3-b: plazo para pagar.



#### Ponlo en práctica

Tu proveedor te da 30 días para pagar 10,000 de mercancía sin intereses. Vendes la mercancía en 20 días con 25% de margen sobre el precio. ¿Cuánto vendes y cuánto te queda después de pagarle?
**Respuesta:** Vendes 13,333; pagas 10,000 y te quedan 3,333.



#### A tu plan

Pregunta a tus proveedores si te dan plazo para pagar y verifica en SIPRES cualquier oferta de crédito que recibas.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES».
- **Padrón de entidades** (CNBV · español): https://www.gob.mx/cnbv — **Qué buscar:** «padrón de entidades supervisadas».

### Palabras clave

- *SIPRES:* Sistema de Registro de Prestadores de Servicios Financieros de CONDUSEF.
- *Montadeudas:* prestamistas o apps que cobran con amenazas y costos abusivos.
- *Crédito de proveedores:* plazo que te da un proveedor para pagar la mercancía.

### Fuentes

CONDUSEF · CNBV, consultados el 29 de septiembre de 2026.

---

## M6 U03. El costo total: CAT, comisiones y garantías

**Lo que lograrás:** Comparar créditos por su costo total, leer la tabla de pagos y entender las garantías que te piden.

**Para empezar:** A Don Pepe le ofrecen dos créditos de 50,000: uno con «tasa de 2% mensual» y otro con «pagos fijos de 2,600». No sabe cuál es más barato. En esta lección verás cómo compararlos.

### Lo esencial (5 minutos)

#### El CAT

El CAT suma intereses y comisiones en un solo porcentaje anual. Sirve para comparar créditos del mismo monto y plazo: **menor CAT, más barato.**



#### Lo que realmente pagas

- Pago mensual: **2,600**
× 24 | Meses
- Total a pagar por 50,000: **62,400**
Le cuesta 12,400 más de lo que recibe, antes de comisiones y seguros.


#### Compara con estas preguntas

1. ¿Cuál es el CAT sin IVA?
2. ¿Cuánto pagaré en total?
3. ¿Qué comisiones hay: apertura, pago tardío, pago anticipado?
4. ¿Qué garantía piden: aval, prenda, obligado solidario?
5. ¿Puedo pagar antes sin penalización?



#### Un caso en un minuto

Don Pepe pidió a ambos la tabla de pagos. El de «2% mensual» cobraba comisión de apertura de 3% y seguro: su total era 64,300. El de pagos fijos: 62,400. Eligió el segundo y preguntó por el pago anticipado.

> **Idea clave:** compara el total a pagar y el CAT, no la tasa mensual ni el pago más bajo.



#### Comprueba lo que entendiste

1. ¿Qué es el CAT?
*Respuesta:* El costo anual total de un crédito, con intereses y comisiones.

2. ¿Qué comparas entre dos créditos?
*Respuesta:* El total a pagar y el CAT, con el mismo monto y plazo.


#### Para recordar

- Menor CAT, más barato.
- Total a pagar.
- Pregunta comisiones y garantías.



### Profundiza (5 minutos más)

#### Compara dos créditos

| Dato | Crédito A | Crédito B |
|---|---|---|
| Monto | | |
| Plazo | | |
| Pago mensual | | |
| Total a pagar | | |
| CAT sin IVA | | |
| Comisiones | | |
| Garantía | | |



#### Garantías

Una garantía asegura el pago: puede ser un bien (tu camioneta, tu equipo), un aval u obligado solidario, o una garantía de un programa público. Si no pagas, pueden cobrarse con esa garantía. No pongas en garantía tu casa para un negocio que no ha probado que gana.



#### Pagos anticipados

Pagar antes reduce intereses. Pregunta si hay penalización y pide que el pago se aplique a capital.



#### Casos


**Caso 1. Las dos ofertas de Don Pepe**

Don Pepe compara «2% mensual» contra «pagos fijos de 2,600».
- *¿Qué hace?* Pide la tabla de pagos y compara el total y el CAT.


**Caso 2. La garantía de Toño**

Un crédito para herramienta pide a Toño poner su casa en garantía.
- *¿Qué hace?* Busca otra opción o un monto menor sin arriesgar su casa.


**Caso 3. El pago extra de Mariana**

Mariana tuvo un buen mes y quiere adelantar pagos.
- *¿Qué pregunta?* Si hay penalización y que el pago se aplique a capital.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Comparar tasa mensual | Engaño | Total y CAT |
| Ver solo el pago | Plazo largo caro | Total a pagar |
| Casa en garantía | Riesgo de perderla | Evítalo |
| No preguntar comisiones | Costo oculto | Pregunta todo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Toño y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Dos créditos de igual monto y plazo: CAT 45% y CAT 60%. ¿Cuál es más barato? a) El de 45% · b) El de 60% · c) Cuestan igual
2. Pagas 3,000 al mes por 18 meses. ¿Total? a) 18,000 · b) 3,018 · c) 54,000
3. ¿Qué pides al pagar antes? a) Que se aplique a intereses futuros · b) Que se aplique a capital · c) Que te den otro crédito
**Respuestas:** 1-a: menor CAT. 2-c: 3,000 por 18. 3-b: reduce intereses.



#### Ponlo en práctica

Te prestan 40,000 y pagarás 2,200 durante 24 meses. ¿Cuánto pagas de más?
**Respuesta:** 52,800 menos 40,000: 12,800.



#### A tu plan

Si tienes una oferta de crédito, pide la tabla de pagos y llena la tabla comparativa.



### Para saber más

- **Simulador y CAT** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «CAT» y «simulador de crédito».

### Palabras clave

- *CAT:* Costo Anual Total: indicador que suma intereses y comisiones para comparar créditos.
- *Garantía:* bien o persona que respalda el pago de un crédito.
- *Obligado solidario:* persona que responde por la deuda igual que tú.

### Fuentes

CONDUSEF · Banco de México, consultados el 29 de septiembre de 2026.

---

## M6 U04. No mezcles deudas y cuida con el aval

**Lo que lograrás:** Evitar usar deudas personales para el negocio, prestar a la familia con reglas y entender el riesgo de ser aval.

**Para empezar:** Mariana paga su mercancía con su tarjeta de crédito personal y ya debe 38,000. Y a Don Pepe su sobrino le pide que sea su aval para un crédito de auto. En esta lección verás los riesgos.

### Lo esencial (5 minutos)

#### Mezclas peligrosas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tarjeta personal para mercancía | Intereses altos si no pagas el total. | Deuda escondida. |
| Préstamos a familia | Sin reglas, no regresan. | Dinero del negocio. |
| Ser aval | Si no paga, pagas tú. | Afecta tu historial. |
| Deudas separadas y registradas | Sabes cuánto debe el negocio. | Control. |

#### La tarjeta personal

Usar tu tarjeta para el negocio puede servir si pagas el total cada mes (sin intereses). Si solo pagas el mínimo, la deuda crece con intereses altos y se mezcla con tus gastos personales.



#### Ser aval

Un aval responde por la deuda si el deudor no paga. Aparece en tu historial y te pueden cobrar a ti. **Solo sé aval de una deuda que podrías pagar tú sin poner en riesgo tu casa ni tu negocio.**



#### Un caso en un minuto

Don Pepe calculó el pago del auto del sobrino: 6,500 al mes. No podría pagarlo si el sobrino fallara. Le dijo que no con cariño y le ayudó a buscar un auto más barato que pudiera pagar solo.

> **Idea clave:** registra las deudas del negocio aparte, presta con reglas y solo sé aval si podrías pagar tú.



#### Comprueba lo que entendiste

1. ¿Cuándo sirve la tarjeta personal para el negocio?
*Respuesta:* Solo si pagas el total cada mes y lo registras.

2. ¿Qué arriesgas al ser aval?
*Respuesta:* Pagar tú la deuda y dañar tu historial.


#### Para recordar

- Tarjeta: total cada mes.
- Préstamos a familia con reglas.
- Aval: solo si podrías pagar.



### Profundiza (5 minutos más)

#### Si ya mezclaste

Haz una lista de las deudas que usaste para el negocio. Págalas primero con el dinero del negocio, empezando por la de mayor costo. No sigas comprando mercancía con la tarjeta mientras la pagas.



#### Préstamos a familiares

Si prestas del negocio, que sea de tu reserva o de tu sueldo, por escrito, con monto y fechas. Si no podrías perder ese dinero, no lo prestes.



#### Cómo decir que no

«Te quiero ayudar, pero no puedo arriesgar la tienda. Busquemos otra forma.» Decir que no a ser aval protege a tu familia y a tu negocio.



#### Casos


**Caso 1. La tarjeta de Mariana**

Mariana debe 38,000 en su tarjeta personal por mercancía.
- *¿Qué hace?* Deja de usarla para mercancía y la paga con el dinero del negocio.


**Caso 2. El aval de Don Pepe**

El sobrino de Don Pepe le pide ser aval de un auto de 6,500 al mes.
- *¿Qué hace?* No acepta porque no podría pagarlo y le ayuda a buscar otra opción.


**Caso 3. El préstamo a la comadre**

La comadre de Rosa le pide 3,000 de la fonda.
- *¿Qué hace?* Presta solo de su sueldo o reserva, por escrito y con fechas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar el mínimo | Deuda crece | Paga el total |
| Aval sin calcular | Pagas tú | Solo si podrías |
| Prestar del negocio | Sin efectivo | De tu sueldo, por escrito |
| Seguir usando la tarjeta | No sale | Congélala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Don Pepe y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo es aceptable usar tu tarjeta personal para el negocio? a) Si pagas el mínimo · b) Siempre que el negocio lo necesite, aunque no pagues el total · c) Si pagas el total cada mes y lo registras
2. Si eres aval y el deudor no paga, ¿qué pasa? a) Te pueden cobrar a ti · b) Nada, solo firmaste · c) El banco perdona la deuda
3. ¿De dónde prestas a un familiar? a) De la caja del negocio · b) De tu sueldo o tu reserva, por escrito · c) Con la tarjeta del negocio
**Respuestas:** 1-c: sin intereses. 2-a: respondes por la deuda. 3-b: sin afectar el negocio.



#### Ponlo en práctica

Debes 38,000 con 60% de interés anual y pagas 1,500 al mes. ¿Cuánto interés te cobran el primer mes, aproximadamente?
**Respuesta:** 60% entre 12 es 5% al mes: unos 1,900. Tu pago no cubre ni los intereses.



#### A tu plan

Haz una lista de las deudas que usaste para el negocio y un plan para pagarlas.



### Para saber más

- **Aval y obligado solidario** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «aval» y «tarjeta de crédito».

### Palabras clave

- *Aval:* persona que se compromete a pagar si el deudor no paga.
- *Pago mínimo:* lo menos que puedes pagar de tu tarjeta; la deuda casi no baja.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 8. Módulo 7. Protege tu negocio

## M7 U01. IMSS para personas independientes (Modalidad 10)

**Lo que lograrás:** Conocer la incorporación voluntaria al IMSS para personas que trabajan por su cuenta: qué cubre, cuánto cuesta y cómo inscribirte.

**Para empezar:** Toño se cayó de una escalera y estuvo tres semanas sin trabajar. No tenía servicio médico ni ingreso. En esta lección verás cómo protegerte con el IMSS aunque trabajes por tu cuenta.

### Lo esencial (5 minutos)

#### Qué es

La Modalidad 10 permite a las personas trabajadoras independientes inscribirse al IMSS y pagar su propia cuota. Tienes derechos parecidos a los de un empleado.



#### Qué cubre

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Servicio médico | Para ti y tus beneficiarios. | Consultas, cirugías, maternidad. |
| Incapacidades | Pago si no puedes trabajar por enfermedad o accidente. | Protege tu ingreso. |
| Retiro | Ahorro en tu AFORE y semanas cotizadas. | Para tu pensión. |
| Vivienda (opcional) | Aportar 5% a Infonavit. | Acceso a crédito. |

#### Cómo inscribirte

En el sitio del IMSS para personas trabajadoras independientes: registras tus datos, eliges tu ingreso, la calculadora te da la cuota y pagas mensual, semestral o anual.



#### Un caso en un minuto

Toño se inscribió cotizando con un ingreso cercano a lo que gana. Paga unos 3,000 al mes. Cuando se lastimó la mano meses después, tuvo atención y un pago por incapacidad.

> **Idea clave:** si trabajas por tu cuenta, el IMSS voluntario te da salud, incapacidades y retiro; calcula tu cuota en el sitio oficial.



#### Comprueba lo que entendiste

1. ¿Qué cubre la Modalidad 10?
*Respuesta:* Servicio médico, incapacidades, retiro y, si quieres, vivienda.

2. ¿Dónde calculas tu cuota?
*Respuesta:* En la calculadora del sitio del IMSS.


#### Para recordar

- Salud, incapacidades y retiro.
- Cuota según ingreso registrado.
- Trámite oficial en el IMSS.



### Profundiza (5 minutos más)

#### Qué ingreso registrar

Si registras un ingreso muy bajo, pagas poco, pero tus incapacidades y tu pensión serán bajas. Si registras cerca de lo que ganas, pagas más y te protege mejor. Elige lo que puedas pagar cada mes sin fallar.



#### Modalidad 10 y Modalidad 40

La 10 es para quien trabaja por su cuenta hoy y da servicio médico. La 40 es para quien ya no cotiza y quiere mejorar su pensión de Ley 73, y no incluye servicio médico. Son distintas.



#### Gestores

La inscripción se hace en el sitio del IMSS. Desconfía de quien cobra por «darte de alta» o te ofrece cotizar a través de empresas que no conoces.

> **Antes de actuar, verifica:** la cuota con la calculadora oficial del IMSS; el salario mínimo y la UMA cambian cada año.



#### Casos


**Caso 1. El accidente de Toño**

Toño trabaja por su cuenta y no tiene servicio médico.
- *¿Qué hace?* Revisa la Modalidad 10 en el IMSS y calcula su cuota.


**Caso 2. El ingreso registrado de Mariana**

Mariana quiere registrar el ingreso más bajo posible.
- *¿Qué considera?* Que sus incapacidades y pensión serán más bajas; elige lo que pueda pagar.


**Caso 3. El gestor de Rosa**

Un gestor ofrece a Rosa darla de alta en el IMSS a través de una empresa.
- *¿Qué hace?* Se inscribe ella en el sitio oficial del IMSS.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin seguridad social | Sin ingreso si enfermas | Modalidad 10 |
| Confundir con la 40 | Sin servicio médico | Son distintas |
| Registrar muy bajo | Protección baja | Equilibrio |
| Usar gestores | Riesgo de fraude | Sitio oficial |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Toño, Mariana y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué incluye la Modalidad 10 que no incluye la 40? a) Retiro · b) Semanas cotizadas · c) Servicio médico
2. ¿Qué pasa si registras un ingreso muy bajo? a) Pagas poco, pero tu protección es menor · b) Pagas poco y tu protección es exactamente la misma que con uno alto · c) No te aceptan
3. ¿Dónde te inscribes? a) Con un gestor · b) En el sitio del IMSS · c) En tu banco
**Respuestas:** 1-c: la 10 da servicio médico. 2-a: incapacidad y pensión más bajas. 3-b: trámite oficial.



#### Ponlo en práctica

Pagas 2,600 al mes de Modalidad 10. ¿Cuánto pagas al año?
**Respuesta:** 31,200.



#### A tu plan

Entra a la calculadora del IMSS para personas independientes y calcula tu cuota con tu ingreso.



### Para saber más

- **Personas trabajadoras independientes** (IMSS · español): https://www.imss.gob.mx/personas-trabajadoras-independientes — **Qué buscar:** «calculadora».

### Palabras clave

- *Modalidad 10:* incorporación voluntaria al IMSS para personas trabajadoras independientes, con servicio médico, incapacidades y retiro.
- *Incapacidad:* pago del IMSS cuando no puedes trabajar por enfermedad o accidente.
- *UMA:* Unidad de Medida y Actualización; referencia para cuotas y multas.

### Fuentes

IMSS · Ley del Seguro Social, consultados el 29 de septiembre de 2026.

---

## M7 U02. Seguros para tu negocio

**Lo que lograrás:** Identificar los riesgos de tu negocio y conocer los seguros que los cubren y qué preguntar antes de contratar.

**Para empezar:** Una noche se metieron a la tienda de Don Pepe y se llevaron mercancía y el refrigerador. Perdió unos 60,000 y no tenía seguro. En esta lección verás qué seguros existen para negocios pequeños.

### Lo esencial (5 minutos)

#### Riesgos y seguros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Incendio y daños | Local, equipo y mercancía. | Seguro de daños o para pyme. |
| Robo | Mercancía y efectivo con violencia. | Cobertura de robo. |
| Responsabilidad civil | Si un cliente se lastima o dañas algo ajeno. | Muy útil en oficios. |
| Accidentes personales | Si tú te lastimas. | Complementa el IMSS. |

#### Antes de contratar, pregunta

1. ¿Qué cubre y qué no (exclusiones)?
2. ¿Cuál es el deducible?
3. ¿Hasta cuánto paga (suma asegurada)?
4. ¿Qué medidas de seguridad exigen (chapas, alarma)?
5. ¿Cómo se reclama y en cuántos días pagan?



#### Un caso en un minuto

Don Pepe cotizó un paquete para pequeño comercio con incendio, robo y responsabilidad civil. Le costaba 450 al mes. Revisó que cubriera el refrigerador y la mercancía, y que no exigiera alarma que no tenía.

> **Idea clave:** identifica lo que no podrías reponer y asegúralo; lee exclusiones y deducible antes de firmar.



#### Comprueba lo que entendiste

1. ¿Qué cubre la responsabilidad civil?
*Respuesta:* Daños que causes a otras personas o sus bienes.

2. ¿Qué revisas antes de firmar?
*Respuesta:* Exclusiones, deducible, suma asegurada y requisitos.


#### Para recordar

- Asegura lo que no podrías reponer.
- Exclusiones y deducible.
- Requisitos de seguridad.



### Profundiza (5 minutos más)

#### Tus riesgos

| Riesgo | ¿Podrías pagarlo tú? | ¿Seguro? |
|---|---|---|
| Robo de mercancía | | |
| Incendio del local | | |
| Un cliente se lastima | | |
| Tú te lastimas | | |



#### Verifica la aseguradora

Busca a la aseguradora en la CNSF y en el Buró de Entidades Financieras de CONDUSEF. Pide la póliza completa antes de pagar y guarda tus facturas de equipo y mercancía: te las pedirán al reclamar.



#### Suma asegurada baja

Si aseguras por menos de lo que vale lo asegurado, la aseguradora puede pagarte en proporción. Actualiza la suma asegurada cuando compres equipo o crezca tu inventario.



#### Casos


**Caso 1. El robo en la tienda**

Don Pepe no quiere volver a perder 60,000 por un robo.
- *¿Qué hace?* Cotiza un seguro para pequeño comercio y revisa exclusiones y requisitos.


**Caso 2. La instalación de Toño**

Toño instala cableado en casas y podría causar un daño.
- *¿Qué revisa?* Un seguro de responsabilidad civil para su oficio.


**Caso 3. Las facturas de Rosa**

Rosa compró una estufa industrial y no guardó la factura.
- *¿Qué hace desde ahora?* Guarda facturas de equipo para poder reclamar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin seguro | Pérdida total | Asegura lo esencial |
| No leer exclusiones | No te pagan | Lee antes |
| Suma asegurada baja | Pago proporcional | Actualízala |
| Sin facturas | Reclamo difícil | Guárdalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Toño y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Un cliente se resbala en tu local. ¿Qué seguro ayuda? a) Seguro de auto · b) Responsabilidad civil · c) Seguro de vida
2. ¿Qué es el deducible? a) La parte del daño que pagas tú · b) Lo que paga la aseguradora · c) El precio de la póliza
3. ¿Dónde verificas a la aseguradora? a) En su publicidad · b) En redes sociales · c) En la CNSF y CONDUSEF
**Respuestas:** 1-b: daños a terceros. 2-a: tu parte. 3-c: registros oficiales.



#### Ponlo en práctica

Un robo te causa 40,000 de daño y el deducible es 10%. ¿Cuánto paga la aseguradora?
**Respuesta:** 36,000.



#### A tu plan

Llena tu tabla de riesgos y cotiza al menos dos seguros para lo que no podrías reponer.



### Para saber más

- **Aseguradoras autorizadas** (CNSF · español): https://www.gob.mx/cnsf — **Qué buscar:** «instituciones autorizadas».
- **Seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro para pyme».

### Palabras clave

- *Deducible:* parte del daño que pagas tú antes de que pague el seguro.
- *Responsabilidad civil:* obligación de pagar los daños que causas a otras personas.
- *Exclusión:* lo que el seguro no cubre.

### Fuentes

CNSF · CONDUSEF, consultados el 29 de septiembre de 2026.

---

## M7 U03. Fraudes a negocios

**Lo que lograrás:** Reconocer los fraudes y extorsiones que sufren los negocios y responder con un protocolo.

**Para empezar:** A Rosa le llamó un «inspector del SAT» diciendo que clausurarían su fonda si no depositaba 5,000 hoy. A Don Pepe le llamaron «del cártel» exigiendo una cuota. En esta lección verás cómo reconocer estos engaños y qué hacer.

### Lo esencial (5 minutos)

#### Fraudes frecuentes a negocios

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Autoridad falsa | «SAT», «Protección Civil» o «Salud» piden depósito para no clausurar. | Las autoridades no cobran así. |
| Extorsión telefónica | Amenazas, cobro de piso falso, «ya te estamos vigilando». | Cuelga y denuncia. |
| Proveedor falso | Cambio de cuenta o pedido que nunca llega. | Confirma por otro medio. |
| Facturas falsas | Te las ofrecen o usan tu RFC. | Revisa tu buzón. |

#### Tu protocolo

1. Cuelga. No negocies ni des datos.
2. Verifica por tu cuenta: la autoridad real notifica por escrito o en tu buzón tributario.
3. Nunca deposites para evitar una clausura o una amenaza.
4. Denuncia al 089 (denuncia anónima) o al 088, y a la fiscalía.
5. Avisa a tu equipo y a los negocios vecinos.



#### Un caso en un minuto

Rosa colgó y revisó su buzón tributario: no había nada. Llamó al número oficial del SAT y le confirmaron que no cobran por teléfono. Denunció el número y avisó a otras fondas de la colonia.

> **Idea clave:** ninguna autoridad cobra por teléfono ni pide depósitos para evitar clausuras; cuelga, verifica y denuncia.



#### Comprueba lo que entendiste

1. ¿Cómo notifica el SAT?
*Respuesta:* Por escrito o en tu buzón tributario, nunca pidiendo depósitos por teléfono.

2. ¿Qué haces ante una amenaza por teléfono?
*Respuesta:* Cuelgas, no das datos y denuncias.


#### Para recordar

- Cuelga y verifica.
- Nunca depositar.
- Denuncia y avisa.



### Profundiza (5 minutos más)

#### Extorsión telefónica

La mayoría de las extorsiones por teléfono son engaños desde lejos: usan datos de redes sociales para parecer creíbles. No confirmes nombres ni horarios, no des datos de tu familia y cuelga. Si la amenaza es presencial o persistente, denuncia ante la fiscalía y busca apoyo de las autoridades.



#### Tu RFC y tus facturas

Revisa en el portal del SAT las facturas emitidas a tu nombre. Si aparecen facturas que no hiciste, cambia tu contraseña, revisa tu e.firma y presenta una queja ante el SAT o PRODECON.



#### Menos datos en redes

Evita publicar horarios de depósito, montos de venta, fotos de tu caja o de tu familia en el negocio. Los extorsionadores usan esa información.



#### Casos


**Caso 1. El «inspector» de Rosa**

Un «inspector del SAT» exige a Rosa un depósito de 5,000 para no clausurar.
- *¿Qué hace?* Cuelga, revisa su buzón tributario y denuncia el número.


**Caso 2. La llamada a Don Pepe**

Alguien llama a Don Pepe exigiendo una cuota semanal.
- *¿Qué hace?* No negocia, cuelga y denuncia al 089 o al 088.


**Caso 3. Las facturas de Toño**

Toño ve en el SAT facturas emitidas a su nombre que no hizo.
- *¿Qué hace?* Cambia su contraseña, revisa su e.firma y presenta queja ante el SAT.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Depositar por miedo | Pierdes dinero y te vuelven a llamar | Nunca |
| Negociar | Dan más datos | Cuelga |
| Publicar de más | Te estudian | Cuida tus redes |
| No denunciar | Siguen con otros | 089 o 088 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Don Pepe y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te llaman «del SAT» para pedir un depósito hoy. ¿Qué haces? a) Depositas para evitar la clausura · b) Pides el número de cuenta por mensaje · c) Cuelgas y revisas tu buzón tributario
2. ¿Qué no debes hacer ante una extorsión telefónica? a) Negociar o dar datos · b) Colgar · c) Denunciar
3. Aparecen facturas a tu nombre que no emitiste. ¿Qué haces? a) Las ignoras · b) Cambias tu contraseña y presentas queja ante el SAT · c) Esperas a la declaración anual para ver si se corrigen solas
**Respuestas:** 1-c: no cobran por teléfono. 2-a: les das información. 3-b: protege tu RFC.



#### Ponlo en práctica

Tres negocios de tu calle recibieron la misma llamada falsa del «SAT». Si cada uno hubiera depositado 5,000, ¿cuánto habrían perdido en total?
**Respuesta:** 15,000.



#### A tu plan

Escribe tu protocolo contra extorsión y fraudes, y compártelo con quien te ayuda en el negocio.



### Para saber más

- **Fraudes y suplantación del SAT** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «evita ser víctima de fraude».
- **Denuncia anónima** (089) y **Guardia Nacional** (088).

### Palabras clave

- *Extorsión:* amenaza para obtener dinero.
- *Suplantación de autoridad:* fraude en el que alguien se hace pasar por el SAT u otra autoridad.

### Fuentes

SAT · Guardia Nacional · Secretariado Ejecutivo del Sistema Nacional de Seguridad Pública, consultados el 29 de septiembre de 2026.

---

## M7 U04. Tu marca y tu nombre

**Lo que lograrás:** Saber cuándo conviene registrar tu marca, cómo buscar si ya existe y cómo hacerlo sin gestores abusivos.

**Para empezar:** Mariana vende con el nombre «Luna Morena» desde hace dos años. Una tienda en línea le escribió diciendo que la marca es suya y que debe dejar de usarla. En esta lección verás cómo proteger tu nombre.

### Lo esencial (5 minutos)

#### Qué es una marca registrada

Registrar tu marca en el IMPI te da el derecho exclusivo de usarla en México para ciertos productos o servicios (clases). Sin registro, otra persona puede registrarla antes.



#### Pasos

1. Busca en MarcaNET (IMPI) si el nombre ya está registrado o en trámite.
2. Identifica la clase de tus productos o servicios.
3. Presenta la solicitud en línea y paga la tarifa.
4. Da seguimiento y responde requerimientos.

> **Dato vigente:** el registro de marca en el IMPI cuesta 2,695.18 pesos más IVA por clase, dura 10 años y debe declararse su uso a los 3 años. Consultado el 29 de septiembre de 2026 a través de la tarifa del IMPI.



#### Cuándo conviene

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu nombre ya vende | Clientes te buscan por él. | Protégelo. |
| Vendes en línea | Más visible, más riesgo de copia. | Regístralo. |
| Solo empiezas | Busca que esté libre. | Regístralo cuando puedas. |
| Gestor con «garantía» | Nadie garantiza el registro. | Desconfía. |

#### Un caso en un minuto

Mariana buscó en MarcaNET: «Luna Morena» estaba registrada por la tienda para ropa. Consultó en el IMPI y decidió cambiar a un nombre libre, que registró a tiempo antes de crecer más.

> **Idea clave:** busca en MarcaNET antes de invertir en un nombre y regístralo cuando empiece a vender.



#### Comprueba lo que entendiste

1. ¿Dónde buscas si una marca existe?
*Respuesta:* En MarcaNET del IMPI.

2. ¿Qué es una clase?
*Respuesta:* El grupo de productos o servicios que cubre tu registro.


#### Para recordar

- Busca en MarcaNET.
- Registra por clase.
- 10 años, declara uso a los 3.



### Profundiza (5 minutos más)

#### Gestores y correos falsos

Después de registrar, pueden llegarte cartas o correos cobrando por «publicar» o «proteger» tu marca en registros internacionales. No son del IMPI. Paga solo en los canales oficiales.



#### Nombre de usuario y dominio

Tu cuenta de redes y tu dominio no son marca registrada. Te ayudan a vender, pero no te protegen si alguien registra el nombre en el IMPI.



#### Si te reclaman

Si alguien dice que tu nombre es su marca, verifica en MarcaNET antes de responder. Si su registro es real y cubre tus productos, lo más prudente suele ser cambiar de nombre. Consulta al IMPI o a una persona experta antes de firmar acuerdos.



#### Casos


**Caso 1. La marca de Mariana**

Una tienda dice a Mariana que «Luna Morena» es su marca.
- *¿Qué hace?* Verifica en MarcaNET y, si el registro es real, cambia de nombre.


**Caso 2. El nombre de la fonda**

Rosa quiere poner un letrero grande con un nombre nuevo.
- *¿Qué hace antes?* Busca en MarcaNET que el nombre esté libre.


**Caso 3. El correo a Toño**

Toño recibe un correo que cobra por «publicar su marca internacionalmente».
- *¿Qué hace?* No paga y verifica con el IMPI.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No buscar antes | Pierdes el nombre | MarcaNET |
| Creer que la cuenta de redes protege | Te lo quitan | Registra |
| Pagar correos falsos | Fraude | Canales oficiales |
| Olvidar declarar uso | Se puede cancelar | A los 3 años |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Rosa y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde buscas si un nombre ya es marca? a) En MarcaNET del IMPI · b) En redes sociales · c) En un buscador de internet
2. ¿Tu cuenta de redes te da derecho exclusivo sobre el nombre? a) Sí, si tiene muchos seguidores · b) Sí, si la abriste primero · c) No
3. ¿Cuánto dura un registro de marca? a) 1 año · b) 10 años · c) Para siempre sin trámites
**Respuestas:** 1-a: buscador oficial. 2-c: solo el registro en el IMPI. 3-b: y se renueva.



#### Ponlo en práctica

Registras tu marca en dos clases. ¿Cuánto pagas sin IVA?
**Respuesta:** 2,695.18 por 2: 5,390.36.



#### A tu plan

Busca en MarcaNET el nombre de tu negocio.



### Para saber más

- **MarcaNET** (IMPI · español): https://www.gob.mx/impi — **Qué buscar:** «MarcaNET» y «registro de marca en línea».

### Palabras clave

- *Marca:* nombre, logotipo o combinación que distingue tu producto o servicio.
- *IMPI:* Instituto Mexicano de la Propiedad Industrial: registra marcas en México.
- *Clase:* grupo de productos o servicios que cubre un registro de marca.

### Fuentes

IMPI, consultado el 29 de septiembre de 2026.

---


# Parte 9. Módulo 8. Crecer con orden

## M8 U01. Contratar ayuda

**Lo que lograrás:** Calcular el costo real de contratar a una persona, conocer tus obligaciones básicas y hacer acuerdos claros, también con familiares.

**Para empezar:** A Rosa ya no le alcanza el tiempo. Quiere contratar a una ayudante de lunes a sábado y le ofrece 1,800 a la semana. No sabe si eso es todo lo que le costará. En esta lección verás el costo real.

### Lo esencial (5 minutos)

#### El sueldo no es todo

Contratar a una persona cuesta más que su sueldo: hay prestaciones que marca la ley (aguinaldo, vacaciones y prima vacacional, días de descanso) y, si está registrada, cuotas del IMSS e impuestos sobre nómina de tu estado.

> **Dato vigente:** el salario mínimo general en 2026 es de 315.04 pesos diarios (9,582.47 al mes) y de 440.87 en la zona libre de la frontera norte. Nadie puede recibir menos por una jornada completa. Consultado el 29 de septiembre de 2026 a través de CONASAMI.



#### Lo que cuesta además del sueldo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aguinaldo | Al menos 15 días de salario al año. | En diciembre. |
| Vacaciones y prima | Días pagados de descanso y 25% extra. | Crecen con la antigüedad. |
| IMSS | Cuotas de patrón y trabajador. | Salud y retiro. |
| «Sin prestaciones» | Te expone a demandas. | Acuerdo legal. |

#### La ayudante de Rosa (aproximado)

- Sueldo al mes (1,800 por semana): **7,800**
- Prestaciones y cuotas repartidas por mes (aprox.): **1,500**
- Costo real al mes: **9,300**
Rosa necesita vender más o subir precios para cubrir este nuevo costo fijo (M2 U03).


#### Un caso en un minuto

Rosa sumó el costo real y recalculó su punto de equilibrio: necesitaba 4 comidas más al día. Con la ayudante podía abrir en la noche. Contrató y registró a la ayudante en el IMSS con apoyo de un contador.

> **Idea clave:** calcula el costo real de contratar, recalcula tu punto de equilibrio y haz un acuerdo legal por escrito.



#### Comprueba lo que entendiste

1. ¿Qué cuesta además del sueldo?
*Respuesta:* Aguinaldo, vacaciones y prima, cuotas del IMSS e impuesto sobre nómina.

2. ¿Qué recalculas antes de contratar?
*Respuesta:* Tu punto de equilibrio con el nuevo costo fijo.


#### Para recordar

- Sueldo + prestaciones + cuotas.
- Recalcula tu equilibrio.
- Acuerdo por escrito.



### Profundiza (5 minutos más)

#### Familiares que ayudan

Si tu hija o tu sobrino trabajan contigo de forma regular, acuerden por escrito horario, pago y tareas. Aunque sea familia, el trabajo tiene valor y un acuerdo claro evita conflictos.



#### Contrato y registro

Un contrato por escrito, el alta en el IMSS y los recibos de nómina te protegen a ti y a la persona. Si no sabes cómo hacerlo, un contador puede ayudarte; el IMSS tiene guías para patrones nuevos.



#### Servicios por proyecto

Si solo necesitas ayuda puntual (un diseño, una reparación), puedes contratar un servicio por proyecto con factura. No confundas: si la persona trabaja para ti con horario y de forma subordinada, es una relación laboral.

> **Antes de actuar, verifica:** tus obligaciones como patrón con el IMSS, el SAT y tu estado; las cuotas y el impuesto sobre nómina cambian cada año.



#### Casos


**Caso 1. La ayudante de Rosa**

Rosa quiere contratar a una ayudante por 1,800 a la semana.
- *¿Qué calcula antes?* El costo real con prestaciones y su nuevo punto de equilibrio.


**Caso 2. El sobrino de Don Pepe**

El sobrino de Don Pepe atiende la tienda en las tardes sin acuerdo.
- *¿Qué hacen?* Acuerdan por escrito horario, pago y tareas.


**Caso 3. El diseño de Mariana**

Mariana necesita un logotipo nuevo una sola vez.
- *¿Qué hace?* Contrata el servicio por proyecto con factura.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el sueldo | Te falta dinero | Costo real |
| Sin contrato | Conflictos y demandas | Por escrito |
| Familia sin pago | Tensiones | Acuerdo claro |
| Menos del mínimo | Ilegal | Salario mínimo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Don Pepe y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es un costo de contratar además del sueldo? a) El aguinaldo · b) Tu renta personal · c) La luz de tu casa
2. ¿Qué recalculas antes de contratar? a) Tu declaración anual · b) Tu punto de equilibrio · c) Tu límite de transferencias
3. Tu sobrino trabaja contigo cada tarde. ¿Qué conviene? a) No pagarle porque es familia · b) Pagarle cuando sobre algo al final de cada mes · c) Un acuerdo por escrito con pago y horario
**Respuestas:** 1-a: es prestación de ley. 2-b: nuevo costo fijo. 3-c: evita conflictos.



#### Ponlo en práctica

Una persona gana 400 al día. ¿Cuánto es su aguinaldo mínimo?
**Respuesta:** 15 días por 400: 6,000.



#### A tu plan

Si piensas contratar, calcula el costo real y tu nuevo punto de equilibrio antes de decidir.



### Para saber más

- **Salario mínimo** (CONASAMI · español): https://www.gob.mx/conasami — **Qué buscar:** «salarios mínimos 2026».
- **Patrones** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «registro patronal».

### Palabras clave

- *Prestaciones:* derechos de la persona trabajadora además del sueldo, como aguinaldo y vacaciones.
- *Relación laboral:* trabajo subordinado, con horario y pago, que genera obligaciones para el patrón.

### Fuentes

CONASAMI · IMSS · Ley Federal del Trabajo, consultados el 29 de septiembre de 2026.

---

## M8 U02. Vender en línea y en plataformas

**Lo que lograrás:** Calcular el costo real de vender en línea y en plataformas, y entender las retenciones de ISR e IVA.

**Para empezar:** Mariana vende una bolsa en 500 en una plataforma. Después de la comisión, el envío y las retenciones, le depositan mucho menos. En esta lección verás cuánto te queda de verdad.

### Lo esencial (5 minutos)

#### Lo que se descuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión de la plataforma | Un porcentaje por venta. | Cambia por categoría. |
| Envío | Lo pagas tú o tu cliente. | Inclúyelo en el precio. |
| Retención de ISR | La plataforma la entrega al SAT. | Se acredita. |
| Retención de IVA | Depende de si diste tu RFC. | 8% o 16%. |

#### La bolsa de Mariana

- Precio sin IVA (500 ÷ 1.16): **431**
- Comisión de la plataforma (13% del precio): **65**
- Retención de ISR (2.5% de 431): **11**
- Antes de envío, costo del producto y retención de IVA: **355**
La retención de IVA (34.50 con RFC) se resta del IVA que ella debe; si no dio su RFC, le retienen el doble.


#### Un caso en un minuto

Mariana registró su RFC en la plataforma y recalculó su precio con la comisión y el envío. Subió la bolsa a 560 y ofreció envío gratis a partir de dos piezas.

> **Idea clave:** registra tu RFC en la plataforma y calcula tu precio con comisión, envío y retenciones.



#### Comprueba lo que entendiste

1. ¿Por qué conviene registrar tu RFC en la plataforma?
*Respuesta:* Porque la retención de IVA es de 8% en lugar de 16%.

2. ¿Qué haces con las retenciones?
*Respuesta:* Las restas de tus pagos de impuestos.


#### Para recordar

- Comisión + envío + retenciones.
- RFC registrado en la plataforma.
- Precio con todo incluido.



### Profundiza (5 minutos más)

#### Retenciones y tus declaraciones

La plataforma te da un comprobante de retenciones (CFDI de retenciones). Si vendes también fuera de la plataforma o rebasas ciertos montos, las retenciones se restan en tu pago mensual. Revisa con el SAT o un contador si en tu caso las retenciones pueden considerarse pago definitivo.



#### Reputación y devoluciones

En plataformas, las calificaciones venden. Describe bien el producto, envía a tiempo y responde rápido. Calcula cuánto te cuestan las devoluciones y súmalo al precio.



#### Redes sociales

Vender por redes no tiene comisión de plataforma, pero sí riesgos: capturas falsas (M4 U02), clientes que no recogen y más trabajo de atención. Cobra antes de enviar y usa guías rastreables.

> **Antes de actuar, verifica:** las tasas de retención vigentes en el SAT y las comisiones en la plataforma; cambian con frecuencia.



#### Casos


**Caso 1. El RFC de Mariana**

La plataforma le retiene a Mariana 16% de IVA porque no registró su RFC.
- *¿Qué hace?* Registra su RFC en la plataforma para que la retención sea de 8%.


**Caso 2. El precio en línea**

Mariana vende igual en la plataforma que en su tienda de redes.
- *¿Qué revisa?* Que el precio en la plataforma cubra comisión, envío y retenciones.


**Caso 3. Las retenciones de Toño**

Toño vende servicios por una app y no sabe qué hacer con lo que le retienen.
- *¿Qué hace?* Descarga sus comprobantes de retenciones y los resta en su pago.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mismo precio en todos lados | Pierdes en plataforma | Precio por canal |
| Sin RFC en la plataforma | Retención doble | Regístralo |
| Olvidar retenciones | Pagas doble | Réstalas |
| Enviar sin cobrar | Pierdes producto | Cobra antes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana y Toño. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pasa si no registras tu RFC en la plataforma? a) No te retienen nada · b) Te retienen 16% de IVA en lugar de 8% · c) Te cierran la cuenta y ya no puedes volver a vender ahí
2. Vendes 1,000 sin IVA en una plataforma. ¿Cuánto ISR te retienen en 2026? a) 25 · b) 10 · c) 160
3. ¿Qué haces con las retenciones de la plataforma? a) Las olvidas · b) Las pagas otra vez completas en tu declaración mensual · c) Las restas en tus pagos de impuestos
**Respuestas:** 1-b: sin RFC, doble. 2-a: 2.5% de 1,000. 3-c: ya se pagaron por ti.



#### Ponlo en práctica

Vendes 20,000 sin IVA al mes en una plataforma con RFC registrado. ¿Cuánto te retienen de ISR y de IVA?
**Respuesta:** ISR 2.5%: 500. IVA 8%: 1,600.



#### A tu plan

Si vendes en plataformas, revisa que tu RFC esté registrado y calcula cuánto te queda por producto.



### Para saber más

- **Plataformas digitales** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «plataformas tecnológicas personas físicas».

### Palabras clave

- *Plataforma digital:* sitio o app que conecta a vendedores y compradores y cobra una comisión.
- *CFDI de retenciones:* comprobante de lo que te retuvieron.

### Fuentes

SAT · Ley del ISR · Ley del IVA, consultados el 29 de septiembre de 2026.

---

## M8 U03. Tus números del mes

**Lo que lograrás:** Revisar cada mes cinco números de tu negocio y tomar decisiones con ellos.

**Para empezar:** Don Pepe siente que la tienda va «más o menos». Su sobrino le propone revisar cinco números cada mes. En esta lección verás cuáles son y qué dicen.

### Lo esencial (5 minutos)

#### Tus cinco números

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ventas | Cuánto vendiste. | Compara con el mes anterior. |
| Margen | Qué % te queda después de lo que vendes. | ¿Sube o baja? |
| Ganancia | Ventas menos todos los costos. | La que importa. |
| Flujo | Efectivo al final del mes. | ¿Alcanza para el siguiente? |

#### El quinto: ticket promedio

El ticket promedio es lo que gasta cada cliente en promedio. Si sube, vendes más sin necesitar más clientes.



#### El ticket de Don Pepe

- Ventas del mes: **69,000**
÷ 2,300 | Número de ventas
- Ticket promedio: **30**
Si cada cliente comprara 5 pesos más, vendería 11,500 más al mes.


#### Un caso en un minuto

Don Pepe notó que su margen bajó de 22% a 19%: un proveedor subió precios y él no ajustó. Cambió de proveedor en tres productos y puso cerca de la caja productos de compra rápida. El siguiente mes su ticket subió a 33.

> **Idea clave:** cinco números al mes te dicen qué mejorar: ventas, margen, ganancia, flujo y ticket promedio.



#### Comprueba lo que entendiste

1. ¿Qué es el ticket promedio?
*Respuesta:* Lo que gasta cada cliente en promedio: ventas entre número de ventas.

2. ¿Qué haces si tu margen baja?
*Respuesta:* Revisas precios y costos: proveedores, merma y precio.


#### Para recordar

- Cinco números al mes.
- Compara con el mes anterior.
- Una decisión por número.



### Profundiza (5 minutos más)

#### Tu tablero del mes

| Número | Mes anterior | Este mes | Decisión |
|---|---|---|---|
| Ventas | | | |
| Margen | | | |
| Ganancia | | | |
| Efectivo al cierre | | | |
| Ticket promedio | | | |



#### Compara con el mismo mes del año pasado

Si tu negocio tiene temporadas, compara diciembre con diciembre, no con noviembre. Así sabes si de verdad creces.



#### Una decisión a la vez

No cambies todo el mismo mes. Elige una mejora (precio, proveedor, horario), aplícala y mide el siguiente mes.



#### Casos


**Caso 1. El margen de Don Pepe**

El margen de Don Pepe bajó tres puntos.
- *¿Qué hace?* Revisa qué costos subieron y ajusta proveedores o precios.


**Caso 2. Las ventas de Mariana**

Las ventas de Mariana bajaron en febrero frente a enero.
- *¿Con qué compara?* Con febrero del año pasado, por la temporada.


**Caso 3. El ticket de Rosa**

Rosa tiene muchos clientes, pero cada uno gasta poco.
- *¿Qué prueba?* Una opción de postre o bebida para subir el ticket promedio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mirar solo ventas | Ganancia escondida | Cinco números |
| Comparar mal | Conclusiones falsas | Mismo mes del año pasado |
| Cambiar todo junto | No sabes qué funcionó | Una a la vez |
| No anotar decisiones | Se olvidan | Tablero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Mariana y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Ventas de 30,000 en 600 ventas. ¿Ticket promedio? a) 18,000 · b) 500 · c) 50
2. Tu margen bajó. ¿Qué revisas primero? a) Precios y costos de lo que vendes · b) El color del letrero · c) Tu límite de transferencias
3. Tu negocio tiene temporadas. ¿Con qué comparas diciembre? a) Con noviembre · b) Con diciembre del año pasado · c) Con enero
**Respuestas:** 1-c: 30,000 entre 600. 2-a: el margen depende de ellos. 3-b: misma temporada.



#### Ponlo en práctica

Tienes 1,500 ventas al mes. Si tu ticket promedio sube de 40 a 44, ¿cuánto más vendes al mes?
**Respuesta:** 4 por 1,500: 6,000.



#### A tu plan

Llena tu tablero con los números del mes pasado y elige una decisión para este mes.



### Para saber más

- **Emprendedores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores».

### Palabras clave

- *Ticket promedio:* lo que gasta en promedio cada cliente por compra: ventas entre número de ventas.
- *Tablero:* tabla con los números clave del negocio cada mes.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 10. Módulo 9. Tu futuro

## M9 U01. Tu retiro si trabajas por tu cuenta

**Lo que lograrás:** Conocer cómo ahorrar para tu retiro si trabajas por tu cuenta: AFORE, aportaciones voluntarias, PPR y ahorro propio.

**Para empezar:** Don Pepe tiene 61 años. Trabajó 8 años en una empresa antes de abrir la tienda y no sabe si tiene AFORE. Piensa que «la tienda es su pensión». En esta lección verás tus opciones.

### Lo esencial (5 minutos)

#### El negocio no es tu retiro

Tu negocio depende de que tú trabajes. Si te enfermas o te cansas, puede dejar de dar. Por eso necesitas un ahorro para el retiro **aparte** del negocio.



#### Tus opciones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu AFORE | Si cotizaste alguna vez, ya tienes una. | Localízala. |
| Aportaciones voluntarias | Desde la app de tu AFORE o en tiendas. | Desde 50 pesos. |
| PPR | Plan personal de retiro. | Deducible en régimen general, no en RESICO. |
| Solo el negocio | Depende de tu salud. | Riesgoso. |

#### Empieza hoy

1. Localiza tu AFORE en e-SAR con tu CURP.
2. Revisa tus semanas cotizadas en el IMSS.
3. Programa una aportación voluntaria fija cada mes.
4. Si te inscribes a la Modalidad 10 (M7 U01), sumas semanas y ahorro.



#### Un caso en un minuto

Don Pepe localizó su AFORE: tenía 85,000 de sus años de empleado. Ahora aporta 1,000 al mes de manera voluntaria y revisa con el IMSS si puede sumar semanas.

> **Idea clave:** separa tu retiro de tu negocio; localiza tu AFORE y aporta algo fijo cada mes.



#### Comprueba lo que entendiste

1. ¿Por qué el negocio no es suficiente para tu retiro?
*Respuesta:* Porque depende de que tú puedas trabajar.

2. ¿Dónde localizas tu AFORE?
*Respuesta:* En e-SAR, con tu CURP.


#### Para recordar

- Retiro aparte del negocio.
- Localiza tu AFORE.
- Aportación fija cada mes.



### Profundiza (5 minutos más)

#### PPR y deducciones

Un Plan Personal de Retiro (PPR) puede ser deducible en la declaración anual, con límites. Pero si estás en RESICO, esa deducción no aplica a tus ingresos del régimen. Compara comisiones y rendimiento antes de elegir.

> **Dato vigente:** las aportaciones a PPR y las complementarias de retiro son deducibles hasta 10% de los ingresos acumulables, con un máximo de 5 UMA anuales (213,973.20 pesos en 2026), en el régimen general; no aplican a los ingresos de RESICO. Consultado el 29 de septiembre de 2026 a través de la Ley del ISR (arts. 151-V y 185).



#### Ahorro propio

Además de la AFORE, puedes ahorrar en Cetes a plazos largos. Lo importante es que sea dinero que no tocas para el negocio.



#### Si piensas vender o pasar el negocio

Vender o traspasar el negocio puede darte un capital para el retiro, pero no es seguro. Tómalo como un extra, no como tu único plan.



#### Casos


**Caso 1. La AFORE de Don Pepe**

Don Pepe no sabe si tiene AFORE.
- *¿Qué hace?* La localiza en e-SAR con su CURP y revisa su saldo.


**Caso 2. El PPR de Toño**

Toño está en RESICO y le ofrecen un PPR «para deducir».
- *¿Qué revisa?* Que en RESICO la deducción no aplica y compara comisiones.


**Caso 3. El ahorro de Mariana**

Mariana tiene 28 años y cree que es muy pronto para el retiro.
- *¿Qué hace?* Empieza con una aportación voluntaria pequeña y fija.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| El negocio como pensión | Sin ingreso si falla | Ahorro aparte |
| No buscar tu AFORE | Dinero olvidado | e-SAR |
| PPR «para deducir» en RESICO | No aplica | Revisa |
| Empezar tarde | Menos ahorro | Empieza pequeño |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pepe, Toño y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde localizas tu AFORE? a) En tu banco · b) En e-SAR con tu CURP · c) En el SAT
2. Estás en RESICO. ¿Puedes deducir un PPR de esos ingresos? a) Sí, todo · b) Sí, hasta 5 UMA · c) No
3. ¿Por qué el negocio no basta como retiro? a) Depende de que puedas trabajar · b) Porque los negocios pequeños no pagan impuestos · c) Porque es pequeño
**Respuestas:** 1-b: sistema oficial. 2-c: RESICO no permite deducciones. 3-a: tu salud cambia.



#### Ponlo en práctica

Aportas 500 al mes a tu AFORE durante 20 años, sin contar rendimientos. ¿Cuánto aportaste?
**Respuesta:** 500 por 240 meses: 120,000.



#### A tu plan

Localiza tu AFORE y fija una aportación voluntaria mensual.



### Para saber más

- **Localiza tu AFORE** (e-SAR · español): https://www.e-sar.com.mx — **Qué buscar:** «localiza tu AFORE».
- **Aportaciones voluntarias** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «ahorro voluntario».

### Palabras clave

- *AFORE:* administradora de tu cuenta de ahorro para el retiro.
- *Aportación voluntaria:* dinero que tú agregas a tu cuenta de retiro.
- *PPR:* plan personal de retiro, con posibles beneficios fiscales.

### Fuentes

CONSAR · e-SAR · Ley del ISR, consultados el 29 de septiembre de 2026.

---

## M9 U02. Si el negocio cambia o si faltas

**Lo que lograrás:** Prepararte para cerrar, pausar o pasar tu negocio, y dejar en orden la información por si faltas.

**Para empezar:** Rosa se enfermó dos semanas y su hija no sabía a qué proveedor pagarle, dónde estaba la cuenta ni cómo facturar. En esta lección verás cómo preparar a tu negocio para cambios.

### Lo esencial (5 minutos)

#### Tres situaciones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pausar | Temporada, enfermedad, mudanza. | Suspensión de actividades en el SAT. |
| Cerrar | El negocio ya no da. | Cierre ordenado. |
| Pasar | A un familiar o a otra persona. | Acuerdo por escrito. |
| Si faltas | Nadie sabe qué hacer. | Deja la información en orden. |

#### Tu carpeta del negocio

1. Lista de proveedores, clientes y contactos.
2. Cuentas del negocio y quién puede operarlas (sin contraseñas escritas).
3. Deudas, créditos y pagos pendientes.
4. RFC, régimen, contador y fechas de declaración.
5. Seguros y beneficiarios.



#### Un caso en un minuto

Rosa armó una carpeta con los datos de proveedores, cuentas, fechas de pago y el contacto de su contador. Autorizó a su hija como cotitular de la cuenta del negocio. La siguiente vez que faltó, la fonda siguió abriendo.

> **Idea clave:** deja en una carpeta lo que alguien necesitaría para seguir o cerrar tu negocio sin ti.



#### Comprueba lo que entendiste

1. ¿Qué haces en el SAT si pausas el negocio?
*Respuesta:* Presentas un aviso de suspensión de actividades.

2. ¿Qué va en tu carpeta del negocio?
*Respuesta:* Proveedores, cuentas, deudas, datos fiscales, seguros y contactos.


#### Para recordar

- Pausar, cerrar o pasar con orden.
- Carpeta del negocio.
- Nunca contraseñas por escrito.



### Profundiza (5 minutos más)

#### Suspender o cerrar ante el SAT

Si dejas de tener actividad, presenta el aviso de suspensión de actividades en el SAT: así no se te acumulan obligaciones. Antes, liquida pendientes, cancela o termina facturas y presenta tus declaraciones al día.



#### Pasar el negocio

Si un familiar seguirá con el negocio, acuerden por escrito cuándo, en qué condiciones y qué pasa con el equipo, la mercancía y las deudas. El local rentado y los permisos pueden requerir trámites nuevos.



#### Testamento y beneficiarios

El equipo, la mercancía y el dinero del negocio son parte de tu patrimonio. Un testamento y beneficiarios actualizados en cuentas, seguros y AFORE evitan problemas a tu familia.

> **Antes de actuar, verifica:** los requisitos de suspensión y cierre en el SAT, y consulta a un notario para testamento o traspaso.



#### Casos


**Caso 1. La enfermedad de Rosa**

La hija de Rosa no sabía cómo seguir con la fonda.
- *¿Qué prepara Rosa?* Una carpeta con proveedores, cuentas, pagos y contactos.


**Caso 2. La pausa de Mariana**

Mariana dejará de vender seis meses por maternidad.
- *¿Qué hace en el SAT?* Presenta el aviso de suspensión de actividades.


**Caso 3. La tienda de Don Pepe**

Don Pepe quiere que su hija se quede con la tienda en unos años.
- *¿Qué hace?* Hace un acuerdo por escrito y revisa su testamento.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo en tu cabeza | Nadie puede seguir | Carpeta |
| Contraseñas escritas | Robo de cuentas | Cotitular o autorización |
| Dejar de vender sin aviso | Obligaciones acumuladas | Suspensión |
| Pasar de palabra | Conflictos familiares | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Mariana y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Dejarás de vender seis meses. ¿Qué haces en el SAT? a) Nada: solo dejas de declarar hasta que vuelvas a vender · b) Cancelas tu RFC · c) Presentas un aviso de suspensión de actividades
2. ¿Qué no debe ir escrito en tu carpeta del negocio? a) Tus contraseñas · b) La lista de proveedores · c) Las fechas de pago
3. ¿Cómo pasas el negocio a un familiar? a) De palabra · b) Con un acuerdo por escrito · c) Sin avisar a nadie
**Respuestas:** 1-c: así no se acumulan obligaciones. 2-a: riesgo de robo. 3-b: evita conflictos.



#### Ponlo en práctica

Tienes 5 proveedores con pagos semanales de 1,200, 800, 2,500, 600 y 900. ¿Cuánto debe tener listo quien te sustituya cada semana?
**Respuesta:** 6,000.



#### A tu plan

Arma tu carpeta del negocio y dile a una persona de confianza dónde está.



### Para saber más

- **Suspensión de actividades** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «aviso de suspensión de actividades».
- **Testamento** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «testamento».

### Palabras clave

- *Suspensión de actividades:* aviso al SAT de que dejas de tener actividad por un tiempo.
- *Cotitular:* otra persona con derechos sobre una cuenta.

### Fuentes

SAT, consultado el 29 de septiembre de 2026.

---

## M9 U03. Tu plan de una página

**Lo que lograrás:** Reunir en una hoja las decisiones del curso: dinero, precio, flujo, formalidad, protección y futuro.

**Para empezar:** Mariana aprendió mucho, pero lo tiene en notas sueltas. Quiere una hoja que pueda pegar junto a su computadora. En esta lección armarás tu plan de una página.

### Lo esencial (5 minutos)

#### Por qué una sola hoja

Una hoja te obliga a elegir lo importante. La pegas donde la veas y la revisas cada tres meses.



#### Tu plan de una página

| Tema | Mi decisión |
|---|---|
| Dinero separado | Cuenta del negocio: ___ · Mi sueldo: ___ cada ___ |
| Precio | Costo de mi producto principal: ___ · Precio: ___ · Margen: ___ |
| Punto de equilibrio | ___ al mes · ___ al día |
| Flujo | Reserva meta: ___ · % que aparto: ___ · Reglas de fiado: ___ |
| Cobro | Formas de cobro: ___ · Protocolo contra fraudes: sí / no |
| Formalidad | RFC y régimen: ___ · Día de declarar: ___ |
| Crédito | ¿Necesito? ___ · Total a pagar: ___ |
| Protección | IMSS: ___ · Seguro: ___ · Marca: ___ |
| Números del mes | Revisión el día ___ |
| Futuro | AFORE: ___ · Aportación: ___ · Carpeta del negocio: sí / no |



#### Revisa cada tres meses

Pon una fecha fija. Actualiza números, revisa si cumpliste y cambia una decisión si hace falta.



#### Un caso en un minuto

Mariana llenó su hoja en una tarde. Descubrió que le faltaban dos cosas: registrar su marca y su aportación a la AFORE. Las puso como metas del próximo trimestre.

> **Idea clave:** tu plan cabe en una hoja; revísalo cada tres meses y mejora una cosa a la vez.



#### Comprueba lo que entendiste

1. ¿Cada cuánto revisas tu plan?
*Respuesta:* Cada tres meses.

2. ¿Qué haces si falta algo?
*Respuesta:* Lo pones como meta del próximo trimestre.


#### Para recordar

- Una hoja.
- Donde la veas.
- Revisión trimestral.



### Profundiza (5 minutos más)

#### Prioriza

Si te faltan muchas cosas, empieza por: 1) separar el dinero y pagarte un sueldo, 2) precio con margen, 3) reserva, 4) protección de salud. Lo demás puede esperar unos meses.



#### Compártelo

Comparte tu plan con alguien de confianza o en la comunidad (sin datos personales ni montos reales). Decirlo en voz alta ayuda a cumplirlo.



#### Casos


**Caso 1. La hoja de Mariana**

A Mariana le faltan la marca y la AFORE.
- *¿Qué hace?* Las pone como metas del próximo trimestre.


**Caso 2. Las prioridades de Toño**

Toño tiene muchas tareas pendientes y no sabe por dónde empezar.
- *¿Qué hace?* Empieza por separar el dinero, el precio y la reserva.


**Caso 3. La revisión de Don Pepe**

Don Pepe hizo su plan hace tres meses y no lo ha revisado.
- *¿Qué hace?* Pone una fecha fija y actualiza sus números.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Notas sueltas | Se olvidan | Una hoja |
| Querer todo junto | Te abrumas | Prioriza |
| No revisar | Se queda viejo | Cada tres meses |
| Guardarlo en un cajón | No lo ves | Pégalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Toño y Don Pepe. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cada cuánto revisas tu plan de una página? a) Cada tres meses · b) Una vez en la vida · c) Cada día
2. ¿Por dónde empiezas si te faltan muchas cosas? a) Por registrar tu marca · b) Por separar el dinero y pagarte un sueldo · c) Por pedir un crédito para ordenar todo de una vez
3. ¿Qué compartes en la comunidad? a) Tus montos, cuentas y ventas reales del mes · b) Tu RFC · c) Tu plan sin datos personales
**Respuestas:** 1-a: revisión trimestral. 2-b: la base de todo. 3-c: sin datos.



#### Ponlo en práctica

Revisas tu plan cada tres meses. ¿Cuántas revisiones haces en dos años?
**Respuesta:** 8.



#### A tu plan

Llena tu plan de una página y pon la fecha de tu primera revisión.



### Para saber más

- **Emprendedores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores».

### Palabras clave

- *Plan de una página:* resumen de las decisiones de tu negocio en una hoja.
- *Revisión trimestral:* revisión de tu plan cada tres meses.

### Fuentes

CONDUSEF, consultado el 29 de septiembre de 2026.

---


# Parte 11. Materiales de apoyo

## Bienvenida

**Tu Negocio, Tu Dinero, Tu Futuro** es un programa de educación financiera para personas que emprenden o trabajan por su cuenta en México.

Aquí aprenderás a separar el dinero del negocio y de tu casa, poner precio, cuidar tu flujo, cobrar sin perder, formalizarte sin miedo, usar el crédito con cuidado, proteger tu negocio y pensar en tu futuro.

No necesitas saber de finanzas ni de contabilidad. Cada lección parte de una situación real de negocio y termina con una acción que puedes hacer esta semana.

Versión 1.0 · Septiembre de 2026.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos por lección |
| **¿Qué harías?** | Una actividad por lección: tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todas las lecciones del módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 a 15 minutos |

### Elige tu ruta en cada lección

- **Ruta rápida (5 min):** lee *Lo esencial* y pasa a *Practica*.
- **Ruta completa (10 min):** suma *Profundiza*, con casos, errores frecuentes y más datos.

Las **palabras en color** muestran su significado al pasar el cursor o al tocarlas en el teléfono. Las respuestas están ocultas: intenta primero y luego toca para verlas.

### Los personajes

- **Rosa** (44): tiene una fonda en Iztapalapa y da fiado a los vecinos.
- **Toño** (35): electricista y técnico en Monterrey; una constructora le pide factura.
- **Mariana** (28): vende ropa y accesorios por redes y en una plataforma desde Guadalajara.
- **Don Pepe** (61): tiene una tienda de abarrotes en Oaxaca desde hace 25 años.

### Tres reglas del programa

1. **Nunca te pediremos datos personales ni fiscales**: RFC, contraseñas del SAT, e.firma, números de cuenta ni montos reales de tu negocio. Si alguien lo hace en nombre del programa, es un fraude.
2. **No te vendemos nada.** En las lecciones no hay recomendaciones de bancos, terminales, plataformas ni créditos.
3. **Orientación, no asesoría.** Te explicamos las reglas generales; tu caso fiscal lo revisas con el SAT o con un contador.

### Los datos cambian

Tasas, montos y reglas cambian, sobre todo en impuestos, cada enero. Los datos del programa se consultaron el **29 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa la información vigente en el **SAT**, el **IMSS**, **CONDUSEF** o el sitio oficial de la institución.

### Tu cuaderno del negocio

Este libro se puede imprimir. Usa las tablas de las lecciones y la hoja de tu plan (M9 U03) como cuaderno de trabajo. Si quieres, usa números inventados: lo importante es aprender a hacer las cuentas.

### Puntos, niveles e insignias

Ganas puntos al completar cada actividad. Hay seis niveles (Idea, Arranque, En marcha, Formal, En crecimiento y Consolidado) y ocho insignias: Dinero separado, Precio justo, Flujo bajo control, Negocio formal, Crédito inteligente, Negocio protegido, Crecer con orden y Plan completo. Nadie ve tu nombre en una tabla de posiciones.

### Constancia

Al aprobar las nueve autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión** con código de verificación. Es un reconocimiento educativo del programa; no es una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados para que practiques sin compartir información de tu negocio. Los montos están en pesos. Resuelve cada caso antes de abrir la clave.

### E1. La fonda de Rosa (Módulos 1 y 2)

**Datos.** Rosa vende 32,000 al mes. Gasta 15,000 en insumos (variables) y tiene 9,000 de costos fijos: renta, gas, luz y el pago de su hija. Todavía no se paga un sueldo: saca del cajón unos 5,000 al mes para su casa. Vende unas 380 comidas al mes a 85.

**Tareas.**

1. ¿Cuánto gana la fonda antes de su sueldo?
2. Si se paga 70% de esa ganancia como sueldo, ¿cuánto es?
3. ¿Cuánto le cuesta cada comida en insumos?
4. ¿Cuánto le deja cada comida después de insumos y cuántas necesita vender al mes para cubrir sus fijos?

**Clave.**

- 32,000 menos 15,000 menos 9,000: 8,000.
- 70% de 8,000: 5,600 al mes.
- 15,000 entre 380: unos 39.50.
- 85 menos 39.50: unos 45.50 por comida; 9,000 entre 45.50: unas 198 comidas al mes.

### E2. El flujo de Toño (Módulos 3 y 4)

**Datos.** Toño tiene 5,000 en la cuenta del negocio. Firmó un trabajo de 30,000 que le pagarán a 30 días. Necesita 12,000 de material ahora. Cobra otros trabajos pequeños por 4,000 a la semana y paga 2,500 a la semana de gastos. Un cliente nuevo le manda una captura de transferencia por 8,000 para empezar ya.

**Tareas.**

1. Sin anticipo, ¿le alcanza para el material?
2. Si pide 40% de anticipo, ¿cuánto recibe y cómo queda?
3. ¿Qué hace con la captura del cliente nuevo?
4. ¿Qué le conviene pedir a su proveedor?

**Clave.**

- 5,000 más 4,000 menos 2,500 son 6,500: le faltan 5,500 para el material.
- 40% de 30,000: 12,000. Con eso paga el material y conserva su saldo.
- Revisa su app; solo empieza cuando el depósito aparezca en su cuenta.
- Plazo de 15 o 30 días para pagar el material.

### E3. La formalización de Mariana (Módulos 5 y 8)

**Datos.** Mariana vende 45,000 al mes sin IVA: 30,000 en una plataforma y 15,000 por redes. Se inscribió en RESICO y registró su RFC en la plataforma.

**Tareas.**

1. ¿Qué tasa de ISR le corresponde en RESICO por lo que cobra en el mes?
2. ¿Cuánto ISR le retiene la plataforma en 2026?
3. ¿Cuánto IVA le retiene la plataforma?
4. ¿Qué pasaría con la retención de IVA si no hubiera registrado su RFC?

**Clave.**

- De 25,000 a 50,000: 1.1%, unos 495 de ISR en el mes.
- 2.5% de 30,000: 750 (se resta en su pago mensual, según su caso).
- 8% de 30,000: 2,400.
- Le retendrían 16%: 4,800.

### E4. El crédito de Don Pepe (Módulos 6, 7 y 9)

**Datos.** Don Pepe recibe dos ofertas por 60,000 a 24 meses: la A con pagos de 3,300 y la B con pagos de 3,100 más una comisión de apertura de 4%. Espera 4,000 al mes de ganancia extra con un refrigerador. Tiene 61 años y 85,000 en su AFORE. Su sobrino le pide ser aval de un auto de 6,500 al mes.

**Tareas.**

1. ¿Cuánto paga en total con cada oferta?
2. Con un escenario prudente (mitad de la ganancia extra), ¿se paga solo el crédito?
3. ¿Le conviene ser aval?
4. ¿Qué dos acciones de futuro puede empezar este mes?

**Clave.**

- A: 3,300 por 24: 79,200. B: 3,100 por 24 son 74,400, más 2,400 de comisión: 76,800. La B es más barata.
- 2,000 de ganancia extra contra 3,100 de pago: no. Debe pedir menos o esperar.
- No: no podría pagar 6,500 al mes si el sobrino falla.
- Aportación voluntaria fija a su AFORE y su carpeta del negocio.


## Prácticas de cálculo

Resuelve cada práctica mostrando el procedimiento. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Ventas 22,000; insumos 10,000; renta y servicios 5,500. ¿Ganancia? |
| P02 | M1 U03 | Ganancia promedio 9,000. ¿Sueldo con 70%? |
| P03 | M2 U01 | Insumos 55 por pieza, fijos 6,000 al mes, 300 piezas. ¿Costo por pieza? |
| P04 | M2 U02 | Costo 160. ¿Precio para un margen de 20% sobre el precio? |
| P05 | M2 U03 | Fijos 15,000; cada venta deja 30%. ¿Punto de equilibrio? |
| P06 | M3 U02 | Límite de fiado 3,000; hoy te deben 2,350. ¿Cuánto más puedes dar? |
| P07 | M3 U03 | Fijos 7,500 al mes. ¿Reserva de dos meses? |
| P08 | M4 U01 | 12,000 al mes con tarjeta y comisión de 3.2%. ¿Costo al mes? |
| P09 | M5 U02 | Cobras 70,000 en un mes en RESICO. ¿ISR? |
| P10 | M5 U04 | IVA cobrado 4,000; IVA acreditable 1,300. ¿IVA a pagar? |
| P11 | M6 U03 | 3,500 al mes por 18 meses por un crédito de 50,000. ¿Cuánto pagas de más? |
| P12 | M7 U04 | Registro de marca en tres clases. ¿Costo sin IVA? |
| P13 | M8 U02 | 15,000 sin IVA en una plataforma, con RFC registrado. ¿Retenciones de ISR e IVA? |
| P14 | M8 U03 | Ventas 48,000 en 1,600 ventas. ¿Ticket promedio? |

### Respuestas

- **P01:** 22,000 menos 15,500: 6,500.
- **P02:** 6,300.
- **P03:** 55 más 20 (6,000 entre 300): 75.
- **P04:** 160 entre 0.80: 200.
- **P05:** 15,000 entre 0.30: 50,000.
- **P06:** 650.
- **P07:** 15,000.
- **P08:** 384.
- **P09:** 1.5% de 70,000: 1,050.
- **P10:** 2,700.
- **P11:** 63,000 menos 50,000: 13,000.
- **P12:** 2,695.18 por 3: 8,085.54.
- **P13:** ISR 2.5%: 375. IVA 8%: 1,200.
- **P14:** 30.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu negocio y tu casa: dinero separado

- **Corte:** suma de ventas y gastos de un periodo para saber cuánto ganaste.
- **Cuenta del negocio:** cuenta o caja que usas solo para cobrar y pagar cosas del negocio.
- **Excedente:** lo que sobra después de pagar costos y tu sueldo.
- **Ganancia:** lo que queda de las ventas después de pagar todos los costos del negocio.
- **Registro:** lista de lo que entra y sale del negocio, con fecha y concepto.
- **Sueldo del dueño:** cantidad fija que el negocio te paga cada semana o quincena por tu trabajo.
- **Ventas:** todo lo que cobras a tus clientes, antes de restar lo que te costó.

### Costos y precio

- **Costo fijo:** gasto que pagas vendas o no, como la renta o tu sueldo.
- **Costo por unidad:** lo que te cuesta producir o vender una pieza, un platillo o un servicio, contando costos variables y una parte de los fijos.
- **Costo variable:** gasto que sube con cada venta, como insumos o empaques.
- **Inventario:** mercancía o insumos que compraste y todavía no vendes.
- **Margen de contribución:** lo que queda de cada venta después de pagar sus costos variables, para cubrir los fijos.
- **Margen:** parte del precio que queda después de cubrir el costo.
- **Merma:** mercancía que se echa a perder, se rompe o se pierde y ya no puedes vender.
- **Precio piso:** el precio mínimo que cubre tu costo.
- **Punto de equilibrio:** ventas mínimas para cubrir todos tus costos: ni ganas ni pierdes.
- **Rotación:** qué tan rápido se vende un producto.

### Flujo de efectivo

- **Abono:** pago parcial de una deuda.
- **Anticipo:** parte del pago que el cliente da antes de que hagas el trabajo.
- **Fiado:** venta que el cliente paga después, sin intereses, basada en la confianza.
- **Flujo de efectivo:** el dinero que realmente entra y sale del negocio, y cuándo.
- **Reserva del negocio:** dinero apartado para cubrir los costos fijos del negocio en meses flojos o imprevistos.
- **Temporada baja:** meses en que tu negocio vende menos.

### Cobrar y vender sin perder

- **CEP:** Comprobante Electrónico de Pago que emite Banxico cuando una transferencia se liquida.
- **CLABE:** número de 18 dígitos para recibir transferencias.
- **Contracargo:** cuando el banco del cliente le regresa un pago con tarjeta porque lo desconoce o lo reclama.
- **Excedente falso:** engaño en el que te piden regresar un pago de más que no existe.
- **Link de pago:** enlace que envías a tu cliente para que pague con tarjeta a distancia.
- **SPEI:** sistema de pagos de Banco de México para transferencias entre bancos, casi al instante.
- **Suplantación de proveedor:** fraude en el que alguien se hace pasar por tu proveedor para que pagues a otra cuenta.
- **Terminal punto de venta:** aparato o app para cobrar con tarjeta.

### Formalízate sin miedo

- **Acreditar:** restar el IVA que pagaste en tus compras del IVA que cobraste.
- **Acuse:** comprobante de que presentaste una declaración.
- **Buzón tributario:** buzón en el sitio del SAT donde recibes avisos y notificaciones oficiales.
- **Constancia de situación fiscal:** documento del SAT con tu RFC, nombre, régimen y código postal fiscal.
- **Declaración mensual:** pago de impuestos del mes que se presenta en el portal del SAT.
- **e.firma:** firma electrónica del SAT; sirve para trámites y para facturar.
- **Factura (CFDI):** Comprobante Fiscal Digital por Internet: documento del SAT que prueba una venta.
- **Factura global:** factura que agrupa las ventas a público en general de un periodo.
- **ISR:** impuesto sobre la renta.
- **IVA:** impuesto al valor agregado: lo cobras a tu cliente y lo entregas al SAT, menos el IVA que pagaste en tus compras.
- **Recargos:** cobro extra por pagar impuestos tarde.
- **RESICO:** Régimen Simplificado de Confianza: pagas ISR con una tasa baja sobre lo que cobras, sin deducir gastos.
- **Retención:** impuesto que tu cliente descuenta de tu pago y entrega al SAT por ti.
- **RFC:** Registro Federal de Contribuyentes: tu clave para el SAT.
- **Tasa 0%:** productos que llevan IVA, pero con tasa cero.

### Crédito para tu negocio

- **Aval:** persona que se compromete a pagar si el deudor no paga.
- **Capital de trabajo:** dinero para operar el día a día: mercancía, insumos y pagos.
- **CAT:** Costo Anual Total: indicador que suma intereses y comisiones para comparar créditos.
- **Crédito de proveedores:** plazo que te da un proveedor para pagar la mercancía.
- **Escenario prudente:** cálculo con ventas menores a las esperadas.
- **Garantía:** bien o persona que respalda el pago de un crédito.
- **Montadeudas:** prestamistas o apps que cobran con amenazas y costos abusivos.
- **Obligado solidario:** persona que responde por la deuda igual que tú.
- **Pago mínimo:** lo menos que puedes pagar de tu tarjeta; la deuda casi no baja.
- **SIPRES:** Sistema de Registro de Prestadores de Servicios Financieros de CONDUSEF.

### Protege tu negocio

- **Clase:** grupo de productos o servicios que cubre un registro de marca.
- **Deducible:** parte del daño que pagas tú antes de que pague el seguro.
- **Exclusión:** lo que el seguro no cubre.
- **Extorsión:** amenaza para obtener dinero.
- **IMPI:** Instituto Mexicano de la Propiedad Industrial: registra marcas en México.
- **Incapacidad:** pago del IMSS cuando no puedes trabajar por enfermedad o accidente.
- **Marca:** nombre, logotipo o combinación que distingue tu producto o servicio.
- **Modalidad 10:** incorporación voluntaria al IMSS para personas trabajadoras independientes, con servicio médico, incapacidades y retiro.
- **Responsabilidad civil:** obligación de pagar los daños que causas a otras personas.
- **Suplantación de autoridad:** fraude en el que alguien se hace pasar por el SAT u otra autoridad.
- **UMA:** Unidad de Medida y Actualización; referencia para cuotas y multas.

### Crecer con orden

- **CFDI de retenciones:** comprobante de lo que te retuvieron.
- **Plataforma digital:** sitio o app que conecta a vendedores y compradores y cobra una comisión.
- **Prestaciones:** derechos de la persona trabajadora además del sueldo, como aguinaldo y vacaciones.
- **Relación laboral:** trabajo subordinado, con horario y pago, que genera obligaciones para el patrón.
- **Tablero:** tabla con los números clave del negocio cada mes.
- **Ticket promedio:** lo que gasta en promedio cada cliente por compra: ventas entre número de ventas.

### Tu futuro

- **AFORE:** administradora de tu cuenta de ahorro para el retiro.
- **Aportación voluntaria:** dinero que tú agregas a tu cuenta de retiro.
- **Cotitular:** otra persona con derechos sobre una cuenta.
- **Plan de una página:** resumen de las decisiones de tu negocio en una hoja.
- **PPR:** plan personal de retiro, con posibles beneficios fiscales.
- **Revisión trimestral:** revisión de tu plan cada tres meses.
- **Suspensión de actividades:** aviso al SAT de que dejas de tener actividad por un tiempo.


## Dónde encontrar ayuda

Cada opción tiene una función distinta. Todas las de esta tabla son oficiales y, salvo que se indique, gratuitas. Información consultada el 29 de septiembre de 2026; confírmala en el sitio oficial de cada institución.

| Necesidad | Dónde | Costo | Qué verificar |
|---|---|---|---|
| RFC, e.firma, RESICO, facturas y declaraciones | SAT: sat.gob.mx, citas y MarcaSAT 55 627 22 728 | Gratis | Entra tú al sitio oficial |
| Problemas o dudas con el SAT | PRODECON: orientación, quejas y defensa | Gratis | Lleva tus acuses |
| Seguridad social como independiente | IMSS: personas trabajadoras independientes (Modalidad 10) | Cuota según ingreso | Calculadora oficial |
| Registrar trabajadores | IMSS: registro patronal | Gratis el trámite | Guías para patrones |
| Verificar a quien presta o asegura | SIPRES y Buró de Entidades Financieras (CONDUSEF); padrón (CNBV); CNSF | Gratis | Nombre legal exacto |
| Reclamar a un banco o terminal | UNE de la institución y CONDUSEF: 55 5340 0999 u 800 999 8080 | Gratis | Folio de tu reclamación |
| Comprobar una transferencia | CEP en banxico.org.mx/cep | Gratis | Clave de rastreo |
| Registrar tu marca | IMPI y MarcaNET | Con costo por clase | Solo canales oficiales |
| Fraudes y delitos en línea | 088 de la Guardia Nacional y fiscalía de tu estado | Gratis | Guarda evidencia |
| Extorsión o cobro de piso | 089 (denuncia anónima) y 911 | Gratis | No negocies |
| Derechos de tus clientes | Profeco | Gratis | Exhibición de precios |
| Localizar tu AFORE | e-SAR con tu CURP; CONSAR | Gratis | CURP |
| Permisos del negocio | Tu alcaldía o municipio; Protección Civil; salud estatal | Variable | Pregunta en ventanilla oficial |

### Guion para pedir información

"Tengo un negocio de [giro] y quiero entender [tema] antes de decidir. ¿Qué documentos necesito? ¿Tiene costo? ¿Cuánto tarda? ¿Me lo pueden dar por escrito?"

---

## Preguntas frecuentes

**¿Necesito tener un negocio formal para tomar el curso?** No. El curso sirve si eres informal, si estás por formalizarte o si ya lo estás.

**¿Tengo que dar datos reales de mi negocio?** No. Puedes usar números inventados. Nunca te pediremos RFC, contraseñas, e.firma ni números de cuenta.

**¿El curso me dice qué régimen fiscal elegir?** Te explica cómo funcionan y cuándo conviene cada uno. La decisión de tu caso la revisas con el SAT o un contador.

**¿Me recomiendan un banco, una terminal o una plataforma?** No. Te enseñamos a comparar costos y verificar. En las lecciones no hay recomendaciones comerciales.

**¿Qué hago si me llama «el SAT» para cobrarme?** Cuelga, entra tú a sat.gob.mx y revisa tu buzón tributario (M7 U03).

**¿Qué hago si un cliente me manda una captura de pago?** Revisa tu app; entrega solo cuando el dinero esté en tu cuenta (M4 U02).

**¿Puedo presentar mi negocio en la comunidad?** Sí, en el foro «Presenta tu negocio», una vez al mes, sin datos personales y sin ofrecer productos financieros.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo del programa, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Qué hago si un dato cambió?** Confírmalo en el SAT, el IMSS, CONDUSEF o el sitio oficial y usa la información vigente.


## Referencias

Estas son las fuentes que usamos en el curso, para que puedas verificarlas. Consultadas el 29 de septiembre de 2026.

### Instituciones

- **I01** SAT: RFC, e.firma, buzón tributario, RESICO, facturación CFDI 4.0, declaraciones, plataformas digitales, suspensión de actividades.
- **I02** PRODECON: orientación y defensa del contribuyente.
- **I03** IMSS: personas trabajadoras independientes (Modalidad 10) y registro patronal.
- **I04** CONDUSEF: SIPRES, Buró de Entidades Financieras, simuladores, reclamaciones, fraudes.
- **I05** CNBV: padrón de entidades supervisadas y Monto Transaccional del Usuario.
- **I06** Banco de México: SPEI, CEP y CoDi.
- **I07** IPAB: seguro de depósitos.
- **I08** Cetesdirecto: Cetes y BONDDIA.
- **I09** CNSF: aseguradoras autorizadas.
- **I10** IMPI: MarcaNET y tarifas de registro de marca.
- **I11** CONSAR y e-SAR: AFORE y aportaciones voluntarias.
- **I12** CONASAMI: salarios mínimos 2026.
- **I13** INEGI: UMA 2026.
- **I14** Profeco: derechos del consumidor.
- **I15** Guardia Nacional (088) y denuncia anónima (089).

### Leyes y disposiciones

- **L01** Ley del Impuesto sobre la Renta: arts. 113-A (plataformas), 113-E a 113-J (RESICO), 151 y 185 (deducciones y retiro).
- **L02** Ley del IVA: art. 18-J (retenciones de plataformas).
- **L03** Resolución Miscelánea Fiscal 2026: reglas 3.13.7 y 3.13.34 de RESICO.
- **L04** Ley del Seguro Social: incorporación voluntaria de personas trabajadoras independientes.
- **L05** Ley Federal del Trabajo: salario mínimo, aguinaldo y vacaciones.
- **L06** Ley de la Propiedad Industrial y tarifas del IMPI.

### Comunicados y medios consultados

- **M01** Notas informativas sobre las reformas fiscales 2026 a plataformas digitales (ISR 2.5% e IVA).
- **M02** Notas informativas sobre RESICO de personas físicas en 2026.
- **M03** Comparativos de comisiones de terminales punto de venta y links de pago en México (2026).
- **M04** Notas informativas sobre la Modalidad 10 del IMSS en 2026.
- **M05** CONDUSEF: cifras de asuntos por posible fraude en 2025.


# Parte 12. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. ¿Tu negocio gana o solo vende?

**Caso 1. El mes de Rosa.** Rosa vendió más que nunca en diciembre, pero pagó más insumos y el aguinaldo de su hija. **¿Qué hace para saber si ganó?**

- ✔ Resta todos los costos del mes a sus ventas.
- Celebra: vendió más que nunca este mes.
- Cuenta solo lo que queda en el cajón.

**Caso 2. Los pedidos de Mariana.** Mariana vendió 80 blusas en un mes, pero pagó envíos que no cobró. **¿Qué revisa?**

- ✔ Calcula cuánto le queda por blusa.
- Vende más blusas para compensar los envíos.
- Sube el precio de todo sin hacer cuentas antes.

**Caso 3. Las horas de Toño.** Toño cobra bien cada trabajo, pero pasa muchas horas en traslados que no cobra. **¿Qué hace?**

- ✔ Calcula su ganancia por hora con traslados.
- Acepta más trabajos lejos para ganar más.
- Deja de cobrar traslados para ser competitivo.

## M1 U02. Separa el dinero del negocio y de tu casa

**Caso 1. El cajón de Rosa.** Rosa toma 200 del cajón para el mandado. **¿Qué hace para no perder la cuenta?**

- ✔ Lo anota como sueldo o préstamo.
- Lo toma; total, la fonda es suya.
- Lo repone de la caja la semana siguiente sin anotar.

**Caso 2. Las transferencias de Mariana.** Mariana recibe los pagos en la misma cuenta donde le deposita su pareja para la casa. **¿Qué hace?**

- ✔ Abre una cuenta solo para ventas.
- Sigue igual y separa todo a fin de año.
- Pide a su pareja que deposite en efectivo.

**Caso 3. La herramienta de Toño.** Toño compra una pinza para su trabajo con la tarjeta de su casa. **¿Qué hace?**

- ✔ La registra y la paga desde el negocio.
- La deja como gasto de su casa.
- La paga en efectivo del cajón sin anotarla.

## M1 U03. Págate un sueldo

**Caso 1. La buena semana de Rosa.** Rosa vendió el doble en la semana de fiestas. **¿Qué hace?**

- ✔ Se paga lo normal y guarda el excedente.
- Saca todo lo extra para la casa esa semana.
- Se sube el sueldo desde esa semana.

**Caso 2. El sueldo de Toño.** Toño cobra por trabajo y hay meses de 30,000 y otros de 8,000. **¿Qué hace?**

- ✔ Se paga con base en su promedio.
- Se paga más en los meses buenos y nada en los malos.
- Espera a fin de año para ver cuánto sacar.

**Caso 3. La hija de Rosa.** La hija de Rosa ayuda los fines de semana sin pago fijo. **¿Qué hacen?**

- ✔ Acuerdan un pago por día.
- Sigue sin pago porque es familia.
- Le da lo que sobre al final del mes.

## M1 U04. Registros en 10 minutos al día

**Caso 1. Las capturas de Mariana.** Mariana tiene 200 capturas de pagos del mes. **¿Qué hace?**

- ✔ Pasa cada pago a su hoja el mismo día.
- Guarda las capturas y las suma a fin de año.
- Borra las capturas viejas para liberar espacio.

**Caso 2. El corte de Rosa.** El corte semanal de Rosa dice 3,000 de ganancia, pero en la caja hay 1,800. **¿Qué revisa?**

- ✔ Busca gastos o retiros sin anotar.
- Ajusta el corte para que cuadre con la caja.
- Lo ignora porque la diferencia es pequeña.

**Caso 3. La app de Don Pepe.** Una app gratuita pide a Don Pepe foto de su INE y de su tarjeta para registrar sus ventas. **¿Qué hace?**

- ✔ No la usa y elige libreta u hoja.
- La usa porque es gratis y fácil.
- Manda solo la foto de su INE para probarla.

## M2 U01. Costos fijos y variables

**Caso 1. La blusa de Mariana.** Mariana cree que gana 120 por blusa porque la compra en 180 y la vende en 300. **¿Qué le falta sumar?**

- ✔ Empaque, envío, comisión y fijos.
- Nada: ya sabe que gana 120 por blusa.
- Solo el costo del envío de cada pedido.

**Caso 2. La hora de Toño.** Toño cobra 250 la hora, pero no sabe si le alcanza. **¿Qué calcula?**

- ✔ Su costo por hora con fijos y sueldo.
- Lo que cobra su compadre por hora.
- El precio de la herramienta más cara que tiene.

**Caso 3. La luz de Rosa.** El recibo de luz de Rosa llega cada dos meses y nunca lo cuenta. **¿Qué hace?**

- ✔ Lo divide entre dos y lo suma a sus fijos.
- Lo paga cuando llega y no lo cuenta.
- Lo suma completo al mes en que llega.

## M2 U02. ¿Cuánto cobrar?

**Caso 1. El precio de Toño.** Toño cobra lo mismo que su compadre, aunque sus costos son mayores. **¿Qué hace?**

- ✔ Calcula su costo y pone un precio con margen.
- Cobra lo mismo que su compadre.
- Baja su tarifa para ganar más clientes.

**Caso 2. La oferta de Mariana.** Mariana quiere bajar sus blusas a 250 para vender más que la competencia. **¿Qué revisa?**

- ✔ Que 250 cubra su costo real.
- Nada: bajar siempre aumenta la ganancia.
- Solo lo que cobra la competencia más barata.

**Caso 3. El aumento de Rosa.** La tortilla y la carne subieron y la comida corrida de Rosa ya casi no deja. **¿Qué hace?**

- ✔ Recalcula su costo y avisa del aumento.
- Sirve porciones más pequeñas sin avisar.
- Espera a que los precios bajen solos.

## M2 U03. Tu punto de equilibrio

**Caso 1. La renta de Don Pepe.** Le suben la renta a Don Pepe 2,000 al mes. **¿Qué hace?**

- ✔ Recalcula su equilibrio y meta diaria.
- Sigue igual: 2,000 no es mucho.
- Da más fiado para vender más ese mes.

**Caso 2. Las comidas de Rosa.** Rosa vende 7 comidas al día y su equilibrio es de 9. **¿Qué hace?**

- ✔ Sube ventas, precio o baja costos.
- Sigue igual hasta fin de año.
- Pide un crédito para cubrir la diferencia.

**Caso 3. El local de Mariana.** Mariana quiere rentar un local de 6,000 al mes. **¿Qué calcula antes?**

- ✔ Cuánto tendría que vender de más.
- Nada: un local siempre vende más.
- Solo si el local tiene buena ubicación.

## M2 U04. Inventario y merma

**Caso 1. La oferta a Don Pepe.** El proveedor ofrece a Don Pepe una caja gratis si compra 10 de un producto que vende poco. **¿Qué hace?**

- ✔ Compra solo lo que vende a tiempo.
- Compra las 10 cajas por el regalo.
- Compra 20 para que le regalen dos.

**Caso 2. Las verduras de Rosa.** Rosa tira verdura cada viernes. **¿Qué hace?**

- ✔ Anota lo que tira y compra menos.
- Compra más para tener variedad.
- Sigue igual; la merma es normal.

**Caso 3. El inventario de Mariana.** Mariana tiene 40 blusas de un modelo que no se vendió. **¿Qué hace?**

- ✔ Las ofrece con descuento y no repite.
- Las guarda por si vuelven a ponerse de moda.
- Compra más del mismo modelo más barato.

## M3 U01. Ganar no es tener efectivo

**Caso 1. El pago tardío a Toño.** La constructora le paga a Toño a 30 días y él necesita material ya. **¿Qué hace?**

- ✔ Pide anticipo y plazo a su proveedor.
- Pide un préstamo rápido en una app.
- Deja el trabajo hasta que le paguen.

**Caso 2. La compra grande de Don Pepe.** Don Pepe quiere surtir para diciembre en octubre y se quedaría sin efectivo dos semanas. **¿Qué hace?**

- ✔ Compra en partes según vende.
- Compra todo en octubre por el precio.
- Pide prestado para surtir de una vez.

**Caso 3. El préstamo de la app.** A Mariana le faltan 2,000 para pagar a su proveedor y una app le presta al momento. **¿Qué hace antes?**

- ✔ Revisa su reserva y pide plazo.
- Toma el préstamo porque es rápido.
- Paga con la tarjeta de su casa.

## M3 U02. Fiado, crédito a clientes y cobranza

**Caso 1. El fiado de Rosa.** Un cliente de Rosa debe 900 y pide más. **¿Qué hace?**

- ✔ No le da más hasta que abone.
- Le da más para no perder al cliente.
- Pone su nombre en un letrero de deudores.

**Caso 2. La empresa de Toño.** Una empresa le debe a Toño un trabajo de hace 45 días. **¿Qué hace?**

- ✔ Recuerda por escrito y pide anticipo.
- Sigue trabajando para no perder al cliente.
- Deja de hablarle hasta que pague.

**Caso 3. El vecino de Don Pepe.** Don Pepe no anota el fiado porque «se acuerda». **¿Qué hace?**

- ✔ Empieza una libreta de fiado.
- Sigue confiando en su memoria.
- Deja de dar fiado a todos sin avisar.

## M3 U03. Tu reserva y las temporadas bajas

**Caso 1. El enero de Mariana.** Mariana sabe que enero es flojo. **¿Qué hace en diciembre?**

- ✔ Aparta un % de cada venta.
- Gasta lo de diciembre y ve qué pasa en enero.
- Compra más mercancía para enero.

**Caso 2. La caja de Don Pepe.** Don Pepe guarda su reserva en una caja en la tienda. **¿Qué hace?**

- ✔ La pasa a un banco o a Cetes.
- La deja en la caja; está a la mano.
- La presta a un vecino para que crezca.

**Caso 3. El aguinaldo en la fonda.** Rosa tiene que dar aguinaldo a su ayudante en diciembre. **¿Qué hace desde enero?**

- ✔ Aparta la doceava parte cada mes.
- Pide prestado en diciembre.
- Paga el aguinaldo con la reserva de enero.

## M4 U01. Efectivo, transferencia, terminal o link de pago

**Caso 1. La terminal de Rosa.** A Rosa le ofrecen una terminal con renta mensual y comisión baja. **¿Qué hace?**

- ✔ Calcula el costo total con sus ventas.
- La contrata porque la comisión es baja.
- Rechaza cualquier terminal por costosa.

**Caso 2. El recargo de Don Pepe.** Don Pepe quiere cobrar 5% extra a quien pague con tarjeta. **¿Qué hace?**

- ✔ Lo incluye en el precio o fija un mínimo.
- Cobra 5% extra a quien pague con tarjeta.
- Deja de aceptar tarjetas desde mañana.

**Caso 3. El link de Mariana.** Mariana quiere cobrar con link a clientes que no conoce. **¿Qué revisa?**

- ✔ Comisión, depósito y contracargos.
- Solo el diseño del link de pago.
- Nada: los links siempre son seguros.

## M4 U02. Cobros con CoDi, QR y transferencias seguras

**Caso 1. La captura de Mariana.** Un cliente manda a Mariana una captura y pide que envíe ya. **¿Qué hace?**

- ✔ Envía cuando el depósito aparezca.
- Envía con la captura para no perder la venta.
- Pide una segunda captura y envía.

**Caso 2. La transferencia «en proceso».** Un cliente de Toño dice que la transferencia está «en proceso» y quiere que empiece. **¿Qué hace?**

- ✔ Espera el depósito o consulta el CEP.
- Empieza el trabajo para quedar bien.
- Pide la captura y empieza de inmediato.

**Caso 3. El código de Rosa.** Alguien que dice ser cliente le pide a Rosa el código que le llegó «para pagarle». **¿Qué hace?**

- ✔ No da el código; basta su CLABE.
- Da el código para recibir el pago.
- Da el código solo si es cliente frecuente.

## M4 U03. Fraudes al vender

**Caso 1. El «depósito de más».** Un cliente dice a Mariana que le depositó 2,000 de más y pide que se los regrese. **¿Qué hace?**

- ✔ Revisa su app y solo devuelve lo real.
- Devuelve los 2,000 para quedar bien.
- Devuelve la mitad mientras revisa.

**Caso 2. El proveedor de Don Pepe.** Una llamada «del proveedor» pide a Don Pepe pagar un pedido a una cuenta nueva. **¿Qué hace?**

- ✔ Cuelga y llama al número conocido.
- Paga a la nueva cuenta para no atrasarse.
- Pide la nueva cuenta por mensaje.

**Caso 3. El pedido grande de Toño.** Un desconocido pide a Toño material por 15,000 con link de pago y envío urgente a otra ciudad. **¿Qué hace?**

- ✔ Desconfía y verifica antes de enviar.
- Envía rápido para no perder la venta.
- Envía la mitad y espera el resto.

## M5 U01. ¿Por qué formalizarte y por dónde empezar?

**Caso 1. El contrato de Toño.** Una constructora pide factura a Toño para contratarlo. **¿Qué hace?**

- ✔ Se inscribe en el RFC y elige régimen.
- Rechaza el contrato para no pagar impuestos.
- Pide a un amigo que facture por él.

**Caso 2. El gestor de Rosa.** Un gestor ofrece a Rosa sacarle el RFC por 1,500. **¿Qué hace?**

- ✔ Lo tramita ella gratis en el SAT.
- Paga al gestor para ahorrar tiempo.
- Pide al gestor que use su RFC.

**Caso 3. La contraseña de Mariana.** Su contadora le pide a Mariana su e.firma por WhatsApp. **¿Qué hace?**

- ✔ No la manda y pide una vía formal.
- La manda porque confía en ella.
- La manda y cambia la contraseña después.

## M5 U02. RESICO: el régimen para empezar

**Caso 1. El régimen de Toño.** Toño cobra 22,000 al mes y gasta 40% en material. **¿Qué hace?**

- ✔ Compara regímenes con un contador.
- Elige RESICO sin revisar sus gastos.
- No se inscribe hasta tener más clientes.

**Caso 2. La retención de la constructora.** La constructora retiene a Toño 1.25% en su factura. **¿Qué hace con esa retención?**

- ✔ La resta de su pago mensual.
- La ignora porque ya pagó la empresa.
- Paga su ISR completo sin restarla.

**Caso 3. El socio de Mariana.** Mariana es socia de una pequeña empresa de su familia. **¿Qué revisa?**

- ✔ Si ser socia le impide entrar.
- Nada: RESICO es para todas.
- Solo cuánto vende al mes.

## M5 U03. Facturar sin miedo

**Caso 1. La factura rechazada de Toño.** La constructora rechazó la factura de Toño por el código postal. **¿Qué hace?**

- ✔ Pide la constancia y factura de nuevo.
- Le pide a la constructora que la acepte así.
- Cambia el código postal a mano en el PDF.

**Caso 2. Las ventas de mostrador de Rosa.** Casi ningún cliente de Rosa le pide factura. **¿Qué hace con esas ventas?**

- ✔ Las incluye en su factura global.
- No las reporta porque nadie las pidió.
- Las factura a su propio RFC.

**Caso 3. La oferta de facturas.** Alguien ofrece a Don Pepe facturas de gastos «para pagar menos». **¿Qué hace?**

- ✔ Las rechaza: son ilegales.
- Compra pocas para no llamar la atención.
- Pregunta cuánto cuestan antes de decidir.

## M5 U04. El IVA de tu negocio

**Caso 1. Los precios de Rosa.** Rosa no sabe si su precio de 85 incluye IVA. **¿Qué hace?**

- ✔ Divide entre 1.16 y separa el IVA.
- Cobra 16% extra sobre su precio actual.
- No cobra IVA porque es fonda.

**Caso 2. Las compras de Toño.** Toño compra material sin pedir factura. **¿Qué hace?**

- ✔ Pide factura a su RFC.
- Sigue sin factura para ahorrar tiempo.
- Pide factura a nombre de su cliente.

**Caso 3. La tienda de Don Pepe.** Don Pepe vende refrescos, pan y frutas. **¿Qué revisa?**

- ✔ Qué lleva 16% y qué 0%.
- Aplica 16% a todos los productos.
- No cobra IVA a nada de la tienda.

## M5 U05. Tus declaraciones

**Caso 1. El mensaje de Toño.** A Toño le llega un mensaje «del SAT» con un enlace para evitar una multa. **¿Qué hace?**

- ✔ Revisa su buzón en sat.gob.mx.
- Abre el enlace para evitar la multa.
- Responde el mensaje con sus datos.

**Caso 2. El mes sin ventas de Mariana.** Mariana no vendió nada en febrero. **¿Qué hace?**

- ✔ Revisa si declara en ceros y presenta.
- No hace nada porque no vendió.
- Cancela su RFC para no declarar.

**Caso 3. El atraso de Rosa.** Rosa no presentó dos meses. **¿Qué hace?**

- ✔ Presenta ya y revisa parcialidades.
- Espera a tener todo para pagar junto.
- Deja pasar el año y declara todo en abril.

## M6 U01. ¿Necesitas crédito?

**Caso 1. El refrigerador de Don Pepe.** Don Pepe calcula que el crédito se paga solo, pero con ventas optimistas. **¿Qué hace?**

- ✔ Revisa un escenario prudente.
- Firma: las cuentas salen con ventas altas.
- Pide más para ampliar también la bodega.

**Caso 2. Las pérdidas de Rosa.** La fonda de Rosa pierde dinero desde hace tres meses y le ofrecen un crédito. **¿Qué hace?**

- ✔ Corrige precio y costos primero.
- Toma el crédito para aguantar unos meses.
- Pide un crédito más grande para crecer.

**Caso 3. El pedido de Toño.** Toño tiene un contrato firmado y necesita material para cumplirlo. **¿Qué revisa primero?**

- ✔ Si el cliente da anticipo.
- El crédito más rápido que encuentre.
- Cuánto le prestan como máximo.

## M6 U02. Opciones de crédito y cómo verificarlas

**Caso 1. El mensaje a Rosa.** Un mensaje ofrece a Rosa crédito «sin Buró» si deposita 500 para activarlo. **¿Qué hace?**

- ✔ No deposita y verifica en CONDUSEF.
- Deposita 500 porque la oferta es buena.
- Deposita solo si le mandan contrato.

**Caso 2. El proveedor de Don Pepe.** El proveedor de Don Pepe ofrece 30 días para pagar sin intereses. **¿Qué hace?**

- ✔ Lo aprovecha si vende a tiempo.
- Lo rechaza por miedo a deber.
- Pide 90 días para comprar el triple.

**Caso 3. La app de Mariana.** Una app presta a Mariana en minutos, pero pide acceso a sus contactos. **¿Qué hace?**

- ✔ No la usa y busca opciones verificadas.
- La usa solo una vez por la urgencia.
- Le da acceso pero borra sus contactos.

## M6 U03. El costo total: CAT, comisiones y garantías

**Caso 1. Las dos ofertas de Don Pepe.** Don Pepe compara «2% mensual» contra «pagos fijos de 2,600». **¿Qué hace?**

- ✔ Pide tabla de pagos y compara total y CAT.
- Elige el de 2% porque suena más barato.
- Elige el de pago mensual más bajo.

**Caso 2. La garantía de Toño.** Un crédito para herramienta pide a Toño poner su casa en garantía. **¿Qué hace?**

- ✔ Busca otra opción sin arriesgar su casa.
- Acepta: la herramienta lo vale.
- Pone la casa y pide un monto mayor.

**Caso 3. El pago extra de Mariana.** Mariana tuvo un buen mes y quiere adelantar pagos. **¿Qué pregunta?**

- ✔ Si hay penalización y que vaya a capital.
- Nada: adelantar siempre ahorra igual.
- Que el pago se aplique a intereses futuros.

## M6 U04. No mezcles deudas y cuida con el aval

**Caso 1. La tarjeta de Mariana.** Mariana debe 38,000 en su tarjeta personal por mercancía. **¿Qué hace?**

- ✔ Deja de usarla y la paga del negocio.
- Paga el mínimo y sigue comprando.
- Saca otra tarjeta para pagar la primera.

**Caso 2. El aval de Don Pepe.** El sobrino de Don Pepe le pide ser aval de un auto de 6,500 al mes. **¿Qué hace?**

- ✔ No acepta y le ayuda a buscar otra opción.
- Acepta porque es familia.
- Acepta y le pide que no se atrase.

**Caso 3. El préstamo a la comadre.** La comadre de Rosa le pide 3,000 de la fonda. **¿Qué hace?**

- ✔ Presta de su sueldo, por escrito.
- Presta de la caja de la fonda.
- Presta con la tarjeta del negocio.

## M7 U01. IMSS para personas independientes (Modalidad 10)

**Caso 1. El accidente de Toño.** Toño trabaja por su cuenta y no tiene servicio médico. **¿Qué hace?**

- ✔ Revisa la Modalidad 10 y su cuota.
- Espera a ver si se vuelve a lastimar.
- Paga consultas privadas cuando pase algo.

**Caso 2. El ingreso registrado de Mariana.** Mariana quiere registrar el ingreso más bajo posible. **¿Qué considera?**

- ✔ Que su protección será más baja.
- Nada: la protección es la misma.
- Que así paga menos y gana más pensión.

**Caso 3. El gestor de Rosa.** Un gestor ofrece a Rosa darla de alta en el IMSS a través de una empresa. **¿Qué hace?**

- ✔ Se inscribe en el sitio del IMSS.
- Acepta al gestor para ahorrar tiempo.
- Da sus datos al gestor para probar.

## M7 U02. Seguros para tu negocio

**Caso 1. El robo en la tienda.** Don Pepe no quiere volver a perder 60,000 por un robo. **¿Qué hace?**

- ✔ Cotiza un seguro y revisa exclusiones.
- Compra una alarma y no contrata nada.
- Contrata el primer seguro que le ofrezcan.

**Caso 2. La instalación de Toño.** Toño instala cableado en casas y podría causar un daño. **¿Qué revisa?**

- ✔ Un seguro de responsabilidad civil.
- Un seguro de vida para su familia.
- Nada: tiene mucho cuidado al trabajar.

**Caso 3. Las facturas de Rosa.** Rosa compró una estufa industrial y no guardó la factura. **¿Qué hace desde ahora?**

- ✔ Guarda facturas de equipo.
- Pide una factura nueva si hay robo.
- Guarda solo las fotos del equipo.

## M7 U03. Fraudes a negocios

**Caso 1. El «inspector» de Rosa.** Un «inspector del SAT» exige a Rosa un depósito de 5,000 para no clausurar. **¿Qué hace?**

- ✔ Cuelga, revisa su buzón y denuncia.
- Deposita para evitar la clausura.
- Pide al «inspector» que venga mañana.

**Caso 2. La llamada a Don Pepe.** Alguien llama a Don Pepe exigiendo una cuota semanal. **¿Qué hace?**

- ✔ No negocia, cuelga y denuncia.
- Paga la primera cuota para ganar tiempo.
- Negocia una cuota más baja.

**Caso 3. Las facturas de Toño.** Toño ve en el SAT facturas emitidas a su nombre que no hizo. **¿Qué hace?**

- ✔ Cambia contraseña y presenta queja.
- Las ignora porque no las hizo él.
- Espera a la declaración anual para ver.

## M7 U04. Tu marca y tu nombre

**Caso 1. La marca de Mariana.** Una tienda dice a Mariana que «Luna Morena» es su marca. **¿Qué hace?**

- ✔ Verifica en MarcaNET y decide.
- Ignora el mensaje porque llegó primero.
- Registra su cuenta de redes como prueba.

**Caso 2. El nombre de la fonda.** Rosa quiere poner un letrero grande con un nombre nuevo. **¿Qué hace antes?**

- ✔ Busca en MarcaNET antes.
- Manda hacer el letrero y luego revisa.
- Pregunta a los vecinos si les gusta.

**Caso 3. El correo a Toño.** Toño recibe un correo que cobra por «publicar su marca internacionalmente». **¿Qué hace?**

- ✔ No paga y verifica con el IMPI.
- Paga para proteger su marca afuera.
- Paga la mitad y pide factura.

## M8 U01. Contratar ayuda

**Caso 1. La ayudante de Rosa.** Rosa quiere contratar a una ayudante por 1,800 a la semana. **¿Qué calcula antes?**

- ✔ El costo real y su equilibrio.
- Solo si la ayudante acepta 1,800.
- Nada: el sueldo es todo el costo.

**Caso 2. El sobrino de Don Pepe.** El sobrino de Don Pepe atiende la tienda en las tardes sin acuerdo. **¿Qué hacen?**

- ✔ Acuerdan horario y pago por escrito.
- Sigue igual porque es familia.
- Le paga cuando sobre algo al mes.

**Caso 3. El diseño de Mariana.** Mariana necesita un logotipo nuevo una sola vez. **¿Qué hace?**

- ✔ Contrata el servicio con factura.
- Contrata a alguien de tiempo completo.
- Le pide a su sobrino que lo haga gratis.

## M8 U02. Vender en línea y en plataformas

**Caso 1. El RFC de Mariana.** La plataforma le retiene a Mariana 16% de IVA porque no registró su RFC. **¿Qué hace?**

- ✔ Registra su RFC en la plataforma.
- Deja de vender en la plataforma.
- Sube precios para cubrir el 16%.

**Caso 2. El precio en línea.** Mariana vende igual en la plataforma que en su tienda de redes. **¿Qué revisa?**

- ✔ Que cubra comisión, envío y retenciones.
- Nada: el precio debe ser igual en todos lados.
- Solo el costo del envío del pedido.

**Caso 3. Las retenciones de Toño.** Toño vende servicios por una app y no sabe qué hacer con lo que le retienen. **¿Qué hace?**

- ✔ Descarga sus comprobantes y los resta.
- Las ignora; ya se pagaron por él.
- Paga su ISR completo sin restar nada.

## M8 U03. Tus números del mes

**Caso 1. El margen de Don Pepe.** El margen de Don Pepe bajó tres puntos. **¿Qué hace?**

- ✔ Revisa costos y ajusta.
- Vende más para compensar el margen.
- Sigue igual; un mes no dice nada.

**Caso 2. Las ventas de Mariana.** Las ventas de Mariana bajaron en febrero frente a enero. **¿Con qué compara?**

- ✔ Con febrero del año pasado.
- Con el mejor mes del año.
- Con enero de este año.

**Caso 3. El ticket de Rosa.** Rosa tiene muchos clientes, pero cada uno gasta poco. **¿Qué prueba?**

- ✔ Una bebida o postre para subir el ticket.
- Abre más horas para tener más clientes.
- Baja precios para que compren más.

## M9 U01. Tu retiro si trabajas por tu cuenta

**Caso 1. La AFORE de Don Pepe.** Don Pepe no sabe si tiene AFORE. **¿Qué hace?**

- ✔ La localiza en e-SAR con su CURP.
- Supone que no tiene y no busca.
- Pregunta en su banco si la tiene.

**Caso 2. El PPR de Toño.** Toño está en RESICO y le ofrecen un PPR «para deducir». **¿Qué revisa?**

- ✔ Que en RESICO no deduce y compara.
- Lo contrata para deducir este año.
- Nada: todos los PPR son iguales.

**Caso 3. El ahorro de Mariana.** Mariana tiene 28 años y cree que es muy pronto para el retiro. **¿Qué hace?**

- ✔ Empieza con una aportación pequeña.
- Espera a ganar más para empezar.
- Invierte todo en su inventario.

## M9 U02. Si el negocio cambia o si faltas

**Caso 1. La enfermedad de Rosa.** La hija de Rosa no sabía cómo seguir con la fonda. **¿Qué prepara Rosa?**

- ✔ Una carpeta con proveedores y cuentas.
- Le escribe sus contraseñas a su hija.
- Nada: no volverá a enfermarse.

**Caso 2. La pausa de Mariana.** Mariana dejará de vender seis meses por maternidad. **¿Qué hace en el SAT?**

- ✔ Presenta la suspensión de actividades.
- Deja de declarar sin avisar.
- Cancela su RFC para no pagar.

**Caso 3. La tienda de Don Pepe.** Don Pepe quiere que su hija se quede con la tienda en unos años. **¿Qué hace?**

- ✔ Un acuerdo por escrito y su testamento.
- Se lo dice de palabra a su hija.
- Espera a retirarse para pensarlo.

## M9 U03. Tu plan de una página

**Caso 1. La hoja de Mariana.** A Mariana le faltan la marca y la AFORE. **¿Qué hace?**

- ✔ Las pone como metas del trimestre.
- Hace todo esta misma semana.
- Las deja para el año próximo.

**Caso 2. Las prioridades de Toño.** Toño tiene muchas tareas pendientes y no sabe por dónde empezar. **¿Qué hace?**

- ✔ Separar dinero, precio y reserva.
- Registrar su marca primero.
- Pedir un crédito para ordenarse.

**Caso 3. La revisión de Don Pepe.** Don Pepe hizo su plan hace tres meses y no lo ha revisado. **¿Qué hace?**

- ✔ Pone fecha fija y actualiza.
- Hace un plan nuevo desde cero.
- Lo deja; ya sabe lo que tiene que hacer.

# Parte 13. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** Vendes 25,000 y tus costos son 19,000. ¿Cuánto ganas?

- ✔ 6,000
- 25,000
- 44,000

*¡Correcto! 25,000 menos 19,000.*

**M1 U01 P2.** ¿Qué es la ganancia?

- Todo lo que cobras a tus clientes en el mes, en efectivo y transferencia
- ✔ Lo que queda después de pagar todos los costos
- Lo que hay en el cajón al cerrar

*¡Correcto! Ventas menos costos.*

**M1 U01 P3.** Tus ventas y tus costos son iguales. ¿Qué pasa?

- Ganas poco, pero el negocio sí te deja algo
- Pierdes dinero cada mes
- ✔ Sales tablas: trabajas gratis

*¡Correcto! No queda nada para ti.*

**M1 U02 P1.** ¿Desde dónde pagas los insumos?

- Desde tu cuenta personal
- ✔ Desde la cuenta o caja del negocio
- Desde lo que haya ese día en tu cartera o en la caja

*¡Correcto! Cada bolsa paga lo suyo.*

**M1 U02 P2.** Sacas 500 del negocio para una emergencia de tu casa. ¿Qué haces?

- Lo olvidas, total es tu negocio
- Lo cubres con la tarjeta de crédito y te olvidas del tema
- ✔ Lo anotas como préstamo y lo devuelves

*¡Correcto! Así no se pierde.*

**M1 U02 P3.** ¿Qué hace más fácil saber cuánto vendes?

- ✔ Que los cobros entren a una cuenta del negocio
- Guardar todo el efectivo en casa
- Recibir pagos en varias cuentas personales y de familiares

*¡Correcto! Todo queda registrado.*

**M1 U03 P1.** Tu ganancia promedio es 10,000 al mes. Con 70%, ¿cuál es tu sueldo?

- 10,000
- 3,000
- ✔ 7,000

*¡Correcto! 70% de 10,000.*

**M1 U03 P2.** Tuviste una semana excelente. ¿Qué haces?

- ✔ Te pagas tu sueldo y dejas el resto en el negocio
- Sacas todo lo extra para la casa porque te lo ganaste
- Te subes el sueldo desde ese día

*¡Correcto! El excedente es reserva.*

**M1 U03 P3.** ¿Cada cuánto revisas tu sueldo?

- Cada día
- ✔ Cada 3 meses
- Solo si el negocio cierra

*¡Correcto! Con el promedio.*

**M1 U04 P1.** ¿Qué es lo mínimo que anotas cada día?

- Solo las ventas grandes
- Lo que recuerdes el domingo
- ✔ Fecha, ventas y gastos

*¡Correcto! Con eso basta.*

**M1 U04 P2.** Tu corte y tu caja no cuadran. ¿Qué haces?

- ✔ Buscas gastos o retiros sin anotar
- Ajustas el corte para que cuadre con lo que hay en la caja
- Lo ignoras si es poco

*¡Correcto! Así encuentras el hoyo.*

**M1 U04 P3.** Una app te pide tu INE y foto de tu tarjeta. ¿Qué haces?

- La usas si es gratis y tiene buenas reseñas en la tienda
- ✔ No la usas y eliges otra herramienta
- Mandas solo la tarjeta

*¡Correcto! Pide de más.*

## Módulo 2

**M2 U01 P1.** ¿Cuál de estos es un costo variable?

- La renta del local
- ✔ El empaque de cada pedido
- El internet

*¡Correcto! Sube con cada venta.*

**M2 U01 P2.** Tus fijos son 4,000 y vendes 200 piezas al mes. ¿Cuánto fijo le toca a cada pieza?

- ✔ 20
- 200
- 4,000

*¡Correcto! 4,000 entre 200.*

**M2 U01 P3.** ¿Tu sueldo es un costo del negocio?

- No, es ganancia
- Solo si te sobra
- ✔ Sí, es un costo fijo

*¡Correcto! Sin él trabajas gratis.*

**M2 U02 P1.** Tu costo es 70. ¿Cuál es el precio mínimo para un margen de 30% sobre el precio?

- 91
- 70
- ✔ 100

*¡Correcto! 70 entre 0.70.*

**M2 U02 P2.** ¿Cuándo nunca debes vender?

- ✔ Por debajo de tu costo
- Más caro que la competencia
- Con garantía

*¡Correcto! Pierdes con cada venta.*

**M2 U02 P3.** Tus insumos subieron. ¿Qué haces?

- Bajas la porción sin avisar
- ✔ Recalculas tu costo y avisas del nuevo precio
- Esperas a que bajen solos y mantienes tus precios de siempre

*¡Correcto! Con aviso y claridad.*

**M2 U03 P1.** Fijos de 10,000 y cada venta te deja 25%. ¿Punto de equilibrio?

- 2,500
- ✔ 40,000
- 12,500

*¡Correcto! 10,000 entre 0.25.*

**M2 U03 P2.** Vendes menos que tu punto de equilibrio. ¿Qué pasa?

- Ganas poco
- Estás igual
- ✔ Pierdes dinero

*¡Correcto! No cubres tus costos.*

**M2 U03 P3.** ¿Qué baja tu punto de equilibrio?

- ✔ Bajar costos fijos
- Rentar un local más grande
- Dar más fiado

*¡Correcto! Necesitas vender menos.*

**M2 U04 P1.** ¿Qué es la merma?

- El descuento que te da el proveedor
- ✔ Lo que se echa a perder o ya no puedes vender
- La mercancía nueva

*¡Correcto! Dinero tirado.*

**M2 U04 P2.** Tienes 30 piezas que no se venden. ¿Qué haces?

- ✔ Las ofreces con descuento
- Compras más para exhibir
- Las guardas por si acaso

*¡Correcto! Dinero parado.*

**M2 U04 P3.** ¿Cuándo conviene una oferta de «lleva más»?

- Siempre
- Si el proveedor es de confianza y te da buen precio
- ✔ Si vendes todo antes de que caduque

*¡Correcto! Si no, sale cara.*

## Módulo 3

**M3 U01 P1.** Tienes 3,000, cobrarás 5,000 y pagarás 9,000 esta semana. ¿Cómo terminas?

- Con 1,000 de sobra
- Con 17,000
- ✔ Con 1,000 de faltante

*¡Correcto! 3,000 más 5,000 menos 9,000.*

**M3 U01 P2.** ¿Qué mejora tu flujo?

- Pagar antes a tus proveedores para que te traten mejor
- ✔ Pedir anticipo en trabajos grandes
- Dar más plazo a tus clientes

*¡Correcto! Cobras antes.*

**M3 U01 P3.** Tu calendario muestra un hueco en tres semanas. ¿Qué haces?

- ✔ Buscas soluciones desde hoy
- Esperas a ver si se arregla
- Pides un préstamo rápido el día que falte

*¡Correcto! Actúa antes.*

**M3 U02 P1.** ¿Qué es el fiado para tu negocio?

- Una venta ya cobrada
- ✔ Un préstamo sin intereses
- Una ganancia extra

*¡Correcto! Dinero que no ha regresado.*

**M3 U02 P2.** Un cliente no ha pagado y pide más. ¿Qué haces?

- Le das más para no perderlo
- Lo exhibes en un letrero para que otros clientes sí paguen
- ✔ No le das más hasta que abone

*¡Correcto! Regla clara.*

**M3 U02 P3.** ¿Qué debe tener tu registro de fiado?

- ✔ Nombre, fecha, monto y abonos
- Solo el nombre
- Solo el total del mes

*¡Correcto! Sin discusiones.*

**M3 U03 P1.** Costos fijos de 6,000 al mes. ¿Reserva para 3 meses?

- 2,000
- 6,000
- ✔ 18,000

*¡Correcto! 6,000 por 3.*

**M3 U03 P2.** ¿Dónde conviene guardar la reserva?

- ✔ En una cuenta aparte en un banco o en Cetes
- En la caja del local, donde siempre la tienes a la mano
- En más mercancía

*¡Correcto! Protegida y disponible.*

**M3 U03 P3.** Un permiso cuesta 3,600 al año. ¿Cuánto apartas al mes?

- 360
- ✔ 300
- 3,600

*¡Correcto! 3,600 entre 12.*

## Módulo 4

**M4 U01 P1.** Cobras 6,000 al mes con tarjeta y la comisión es 3%. ¿Cuánto pagas?

- ✔ 180
- 600
- 30

*¡Correcto! 3% de 6,000.*

**M4 U01 P2.** ¿Qué haces con la comisión de la terminal?

- La cobras aparte a quien paga con tarjeta
- ✔ La incluyes en tu precio
- Le pides al cliente que pague en efectivo siempre

*¡Correcto! Sin recargo.*

**M4 U01 P3.** Terminal A: 3.5% sin renta. Terminal B: 2.5% más 150 de renta. Vendes 10,000 con tarjeta. ¿Cuál es más barata?

- ✔ La A: 350
- La B: 400
- Cuestan igual

*¡Correcto! 350 contra 250 más 150.*

**M4 U02 P1.** ¿Cuándo entregas un pedido pagado por transferencia?

- Cuando te mandan la captura
- Cuando el cliente te jura por teléfono que ya pagó
- ✔ Cuando el dinero aparece en tu cuenta

*¡Correcto! La captura no es prueba.*

**M4 U02 P2.** ¿Qué necesitas dar para que te paguen?

- ✔ Tu CLABE o tu QR
- Tu NIP
- El código que te llegó por mensaje

*¡Correcto! Basta para cobrar.*

**M4 U02 P3.** ¿Qué es el CEP?

- Una captura del cliente
- ✔ El comprobante de Banxico que confirma la transferencia
- Un tipo de tarjeta

*¡Correcto! Confirma que se liquidó.*

**M4 U03 P1.** Un cliente dice que te depositó de más. ¿Qué haces primero?

- Le regresas la diferencia de inmediato para quedar bien
- ✔ Revisas tu app para ver si el excedente existe
- Le das su número de cuenta a otro cliente

*¡Correcto! Casi nunca existe.*

**M4 U03 P2.** Tu proveedor te escribe que cambió de cuenta. ¿Qué haces?

- Pagas a la nueva cuenta
- Respondes al mismo mensaje
- ✔ Llamas al número que ya tenías

*¡Correcto! Confirma por otro medio.*

**M4 U03 P3.** ¿Cuál es una señal de fraude al vender?

- ✔ Prisa y compra grande de un desconocido
- Un cliente que pregunta por tallas, colores y tiempos de envío
- Un pago que ya está en tu cuenta

*¡Correcto! La prisa es un gancho.*

## Módulo 5

**M5 U01 P1.** ¿Cuánto cobra el SAT por inscribirte en el RFC?

- Depende del gestor
- ✔ Nada
- 1,500

*¡Correcto! Es gratuito.*

**M5 U01 P2.** ¿Dónde recibes avisos oficiales del SAT?

- Por WhatsApp de un número desconocido
- En redes sociales
- ✔ En tu buzón tributario

*¡Correcto! Canal oficial.*

**M5 U01 P3.** ¿Qué haces con tu e.firma?

- ✔ La guardas solo tú
- La compartes con quien te ayude
- La subes a una nube pública

*¡Correcto! Es tu firma.*

**M5 U02 P1.** Cobras 40,000 en un mes en RESICO. ¿Tasa?

- 1%
- 2.5%
- ✔ 1.1%

*¡Correcto! De 25,000 a 50,000.*

**M5 U02 P2.** ¿Puedes deducir gastos del negocio en RESICO?

- ✔ No
- Sí, todos
- Solo la gasolina

*¡Correcto! Se paga sobre cobros.*

**M5 U02 P3.** ¿Cuál es el límite de ingresos de RESICO?

- 300,000 al año
- ✔ 3.5 millones al año
- No tiene límite

*¡Correcto! Límite anual.*

**M5 U03 P1.** ¿De dónde tomas los datos para facturar?

- ✔ De la constancia de situación fiscal del cliente
- De lo que el cliente te dicte por teléfono o por mensaje
- De una factura vieja

*¡Correcto! Datos exactos.*

**M5 U03 P2.** ¿Qué haces con las ventas a quien no pidió factura?

- No las reportas
- Las facturas a tu nombre
- ✔ Las incluyes en la factura global

*¡Correcto! Público en general.*

**M5 U03 P3.** Te ofrecen facturas de gastos para pagar menos impuestos. ¿Qué haces?

- Compras pocas
- ✔ Las rechazas
- Preguntas el precio

*¡Correcto! Son ilegales.*

**M5 U04 P1.** Cobraste 1,600 de IVA y pagaste 500 en compras con factura. ¿Cuánto pagas?

- 2,100
- ✔ 1,100
- 1,600

*¡Correcto! 1,600 menos 500.*

**M5 U04 P2.** Un precio de 116 incluye IVA. ¿Cuánto es la venta sin IVA?

- 116
- 16
- ✔ 100

*¡Correcto! 116 entre 1.16.*

**M5 U04 P3.** ¿Qué necesitas para acreditar el IVA de una compra?

- ✔ Factura a tu RFC
- El ticket
- Una foto del producto

*¡Correcto! Con factura.*

**M5 U05 P1.** ¿Hasta qué día presentas el pago de marzo?

- 30 de marzo
- 1 de abril
- ✔ 17 de abril

*¡Correcto! Día 17 del mes siguiente.*

**M5 U05 P2.** Te llega un correo «del SAT» con un enlace. ¿Qué haces?

- ✔ Entras tú a sat.gob.mx y revisas tu buzón
- Abres el enlace para evitar la multa
- Lo reenvías a tu contador para que lo abra

*¡Correcto! Canal oficial.*

**M5 U05 P3.** ¿Qué pides siempre a tu contador?

- Tu contraseña de vuelta
- ✔ Copia de tus acuses
- Que no te diga cuánto pagaste

*¡Correcto! Así sabes qué presentó.*

## Módulo 6

**M6 U01 P1.** La ganancia extra es 2,000 al mes y el pago es 2,500. ¿Qué pasa?

- El crédito se paga solo
- ✔ Te faltan 500 al mes
- Ganas 500

*¡Correcto! Pago mayor que ganancia.*

**M6 U01 P2.** ¿Para qué es más sano un crédito del negocio?

- Para pagar gastos de la casa
- Para cubrir pérdidas
- ✔ Para algo que genere ventas

*¡Correcto! Puede pagarse solo.*

**M6 U01 P3.** ¿Qué haces antes de pedir un crédito para un pedido?

- ✔ Revisas si el cliente puede dar anticipo
- Pides el monto máximo
- Firmas rápido el primer crédito para no perder la oferta del día

*¡Correcto! Alternativa sin intereses.*

**M6 U02 P1.** Te piden un depósito para liberar tu crédito. ¿Qué es?

- Un trámite normal
- Una comisión de apertura
- ✔ Una señal de fraude

*¡Correcto! Nunca pagues por adelantado.*

**M6 U02 P2.** ¿Dónde verificas si una entidad está registrada?

- ✔ En el SIPRES de CONDUSEF
- En sus redes sociales
- En las reseñas de la app

*¡Correcto! Registro oficial.*

**M6 U02 P3.** ¿Qué opción suele no cobrar intereses si pagas a tiempo?

- Las apps sin Buró
- ✔ El crédito de proveedores
- El préstamo gota a gota

*¡Correcto! Plazo para pagar.*

**M6 U03 P1.** Dos créditos de igual monto y plazo: CAT 45% y CAT 60%. ¿Cuál es más barato?

- ✔ El de 45%
- El de 60%
- Cuestan igual

*¡Correcto! Menor CAT.*

**M6 U03 P2.** Pagas 3,000 al mes por 18 meses. ¿Total?

- 18,000
- 3,018
- ✔ 54,000

*¡Correcto! 3,000 por 18.*

**M6 U03 P3.** ¿Qué pides al pagar antes?

- Que se aplique a intereses futuros
- ✔ Que se aplique a capital
- Que te den otro crédito

*¡Correcto! Reduce intereses.*

**M6 U04 P1.** ¿Cuándo es aceptable usar tu tarjeta personal para el negocio?

- Si pagas el mínimo
- Siempre que el negocio lo necesite, aunque no pagues el total
- ✔ Si pagas el total cada mes y lo registras

*¡Correcto! Sin intereses.*

**M6 U04 P2.** Si eres aval y el deudor no paga, ¿qué pasa?

- ✔ Te pueden cobrar a ti
- Nada, solo firmaste
- El banco perdona la deuda

*¡Correcto! Respondes por la deuda.*

**M6 U04 P3.** ¿De dónde prestas a un familiar?

- De la caja del negocio
- ✔ De tu sueldo o tu reserva, por escrito
- Con la tarjeta del negocio

*¡Correcto! Sin afectar el negocio.*

## Módulo 7

**M7 U01 P1.** ¿Qué incluye la Modalidad 10 que no incluye la 40?

- Retiro
- Semanas cotizadas
- ✔ Servicio médico

*¡Correcto! La 10 da servicio médico.*

**M7 U01 P2.** ¿Qué pasa si registras un ingreso muy bajo?

- ✔ Pagas poco, pero tu protección es menor
- Pagas poco y tu protección es exactamente la misma que con uno alto
- No te aceptan

*¡Correcto! Incapacidad y pensión más bajas.*

**M7 U01 P3.** ¿Dónde te inscribes?

- Con un gestor
- ✔ En el sitio del IMSS
- En tu banco

*¡Correcto! Trámite oficial.*

**M7 U02 P1.** Un cliente se resbala en tu local. ¿Qué seguro ayuda?

- Seguro de auto
- ✔ Responsabilidad civil
- Seguro de vida

*¡Correcto! Daños a terceros.*

**M7 U02 P2.** ¿Qué es el deducible?

- ✔ La parte del daño que pagas tú
- Lo que paga la aseguradora
- El precio de la póliza

*¡Correcto! Tu parte.*

**M7 U02 P3.** ¿Dónde verificas a la aseguradora?

- En su publicidad
- En redes sociales
- ✔ En la CNSF y CONDUSEF

*¡Correcto! Registros oficiales.*

**M7 U03 P1.** Te llaman «del SAT» para pedir un depósito hoy. ¿Qué haces?

- Depositas para evitar la clausura
- Pides el número de cuenta por mensaje
- ✔ Cuelgas y revisas tu buzón tributario

*¡Correcto! No cobran por teléfono.*

**M7 U03 P2.** ¿Qué no debes hacer ante una extorsión telefónica?

- ✔ Negociar o dar datos
- Colgar
- Denunciar

*¡Correcto! Les das información.*

**M7 U03 P3.** Aparecen facturas a tu nombre que no emitiste. ¿Qué haces?

- Las ignoras
- ✔ Cambias tu contraseña y presentas queja ante el SAT
- Esperas a la declaración anual para ver si se corrigen solas

*¡Correcto! Protege tu RFC.*

**M7 U04 P1.** ¿Dónde buscas si un nombre ya es marca?

- ✔ En MarcaNET del IMPI
- En redes sociales
- En un buscador de internet

*¡Correcto! Buscador oficial.*

**M7 U04 P2.** ¿Tu cuenta de redes te da derecho exclusivo sobre el nombre?

- Sí, si tiene muchos seguidores
- Sí, si la abriste primero
- ✔ No

*¡Correcto! Solo el registro en el IMPI.*

**M7 U04 P3.** ¿Cuánto dura un registro de marca?

- 1 año
- ✔ 10 años
- Para siempre sin trámites

*¡Correcto! Y se renueva.*

## Módulo 8

**M8 U01 P1.** ¿Qué es un costo de contratar además del sueldo?

- ✔ El aguinaldo
- Tu renta personal
- La luz de tu casa

*¡Correcto! Es prestación de ley.*

**M8 U01 P2.** ¿Qué recalculas antes de contratar?

- Tu declaración anual
- ✔ Tu punto de equilibrio
- Tu límite de transferencias

*¡Correcto! Nuevo costo fijo.*

**M8 U01 P3.** Tu sobrino trabaja contigo cada tarde. ¿Qué conviene?

- No pagarle porque es familia
- Pagarle cuando sobre algo al final de cada mes
- ✔ Un acuerdo por escrito con pago y horario

*¡Correcto! Evita conflictos.*

**M8 U02 P1.** ¿Qué pasa si no registras tu RFC en la plataforma?

- No te retienen nada
- ✔ Te retienen 16% de IVA en lugar de 8%
- Te cierran la cuenta y ya no puedes volver a vender ahí

*¡Correcto! Sin RFC, doble.*

**M8 U02 P2.** Vendes 1,000 sin IVA en una plataforma. ¿Cuánto ISR te retienen en 2026?

- ✔ 25
- 10
- 160

*¡Correcto! 2.5% de 1,000.*

**M8 U02 P3.** ¿Qué haces con las retenciones de la plataforma?

- Las olvidas
- Las pagas otra vez completas en tu declaración mensual
- ✔ Las restas en tus pagos de impuestos

*¡Correcto! Ya se pagaron por ti.*

**M8 U03 P1.** Ventas de 30,000 en 600 ventas. ¿Ticket promedio?

- 18,000
- 500
- ✔ 50

*¡Correcto! 30,000 entre 600.*

**M8 U03 P2.** Tu margen bajó. ¿Qué revisas primero?

- ✔ Precios y costos de lo que vendes
- El color del letrero
- Tu límite de transferencias

*¡Correcto! El margen depende de ellos.*

**M8 U03 P3.** Tu negocio tiene temporadas. ¿Con qué comparas diciembre?

- Con noviembre
- ✔ Con diciembre del año pasado
- Con enero

*¡Correcto! Misma temporada.*

## Módulo 9

**M9 U01 P1.** ¿Dónde localizas tu AFORE?

- En tu banco
- ✔ En e-SAR con tu CURP
- En el SAT

*¡Correcto! Sistema oficial.*

**M9 U01 P2.** Estás en RESICO. ¿Puedes deducir un PPR de esos ingresos?

- Sí, todo
- Sí, hasta 5 UMA
- ✔ No

*¡Correcto! RESICO no permite deducciones.*

**M9 U01 P3.** ¿Por qué el negocio no basta como retiro?

- ✔ Depende de que puedas trabajar
- Porque los negocios pequeños no pagan impuestos
- Porque es pequeño

*¡Correcto! Tu salud cambia.*

**M9 U02 P1.** Dejarás de vender seis meses. ¿Qué haces en el SAT?

- Nada: solo dejas de declarar hasta que vuelvas a vender
- Cancelas tu RFC
- ✔ Presentas un aviso de suspensión de actividades

*¡Correcto! Así no se acumulan obligaciones.*

**M9 U02 P2.** ¿Qué no debe ir escrito en tu carpeta del negocio?

- ✔ Tus contraseñas
- La lista de proveedores
- Las fechas de pago

*¡Correcto! Riesgo de robo.*

**M9 U02 P3.** ¿Cómo pasas el negocio a un familiar?

- De palabra
- ✔ Con un acuerdo por escrito
- Sin avisar a nadie

*¡Correcto! Evita conflictos.*

**M9 U03 P1.** ¿Cada cuánto revisas tu plan de una página?

- ✔ Cada tres meses
- Una vez en la vida
- Cada día

*¡Correcto! Revisión trimestral.*

**M9 U03 P2.** ¿Por dónde empiezas si te faltan muchas cosas?

- Por registrar tu marca
- ✔ Por separar el dinero y pagarte un sueldo
- Por pedir un crédito para ordenar todo de una vez

*¡Correcto! La base de todo.*

**M9 U03 P3.** ¿Qué compartes en la comunidad?

- Tus montos, cuentas y ventas reales del mes
- Tu RFC
- ✔ Tu plan sin datos personales

*¡Correcto! Sin datos.*
