# Comunidad Tu Trabajo: contenido

## Bienvenida a la comunidad

**Comunidad Tu Trabajo** es el espacio de quienes toman el programa *Tu Trabajo, Tu Familia, Tu Futuro*. Es un complemento del curso: aquí resuelves dudas, compartes avances, te enteras de fechas importantes y te alertas de fraudes junto con otras trabajadoras del hogar.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas, recordatorios, sesiones y alertas. Solo publica el equipo. |
| **Lo que quiero lograr** | En una frase, qué quieres lograr. Sin datos personales. |
| **Foros de dudas** | Tres foros por tema: ingreso, derechos y ahorro; familia y deudas; salud, fraudes y futuro. |
| **Alertas de fraude** | Avisa de llamadas, mensajes, falsos trabajos o apps sospechosas. |
| **Logros** | Celebra tus avances: apartaste tu ahorro, nombraste beneficiarias, pediste tu aumento. |
| **Sesiones de acompañamiento** | Sesiones en grupo por la tarde o en domingo para repasar cada módulo. |
| **Referencias comerciales** | Servicios con acuerdo comercial, separados y señalados. Son opcionales. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar y apoyarnos entre compañeras.
- **No es** asesoría legal personalizada. Para tu caso concreto te orientamos hacia la PROFEDET, el IMSS u otra institución.
- **No es** un lugar para vender productos, ofrecer préstamos, organizar tandas ni ofrecer trabajos.

### Cómo reconocer al equipo

El equipo **nunca** te pide datos personales, contraseñas, códigos, fotos de tu INE ni datos de las casas donde trabajas. Nunca te ofrece préstamos ni trabajos con depósito. Si alguien lo hace en nombre de la comunidad, es un fraude: repórtalo en **Alertas de fraude**.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Si quieres, comparte en **Lo que quiero lograr** qué te gustaría lograr, en una frase y sin datos personales.
3. Revisa las fechas de las sesiones (capítulo 5).
4. Cuando tengas una duda, usa la plantilla del capítulo 3.


## Reglas y privacidad

Estas reglas protegen tu información, la de tus compañeras y la de las familias donde trabajan.

### Tus datos

- **Nunca publiques** números de cuenta o tarjeta, NIP, contraseñas, códigos, CURP, INE, montos reales ni capturas.
- Si quieres dar un ejemplo, usa **números inventados o redondeados**: «cobro unos 500 por día».
- Los foros no permiten adjuntar archivos, para evitar que se compartan documentos por error.

### Las casas donde trabajas

- No publiques nombres, direcciones, fotos ni detalles de las familias con quienes trabajas.
- Si tienes un problema laboral, cuéntalo sin nombres y te orientamos hacia la PROFEDET o la procuraduría de tu estado.

### Respeto

- Sin burlas, juicios ni culpas: a cualquiera la pueden engañar y cualquiera puede tener deudas.
- Sin discusiones personales ni publicaciones sobre otras personas con nombre y apellido.

### Lo que no se permite

1. Vender productos o servicios, ofrecer préstamos o invitar a tandas, inversiones o «negocios».
2. Ofrecer trabajos o agencias que pidan depósito.
3. Recomendar gestores o coyotes para pensiones, becas o el IMSS.
4. Publicar enlaces de sitios no oficiales para trámites.
5. Hacerse pasar por el equipo, por una institución o por otra persona.

### Si algo te parece fraude

Publícalo en **Alertas de fraude** sin datos personales, o escribe en privado al equipo. Si ya te afectó: guarda capturas, avisa a tu banco, reporta al 088 y denuncia (M5 U03 y M7).

### Qué hace el equipo

- Retira publicaciones con datos personales o de las familias empleadoras y te avisa en privado.
- Retira publicaciones que venden, prestan u ofrecen trabajos.
- Responde dudas generales y canaliza los casos personales.


## Cómo preguntar y pedir apoyo

Una pregunta clara recibe una respuesta útil más rápido.

### Plantilla

**Módulo o tema:** (por ejemplo, M2 aguinaldo)
**Mi situación, sin datos personales:** (por ejemplo, «trabajo un día a la semana en tres casas»)
**Lo que ya revisé:** (por ejemplo, «leí la lección M2 U01»)
**Mi duda concreta:** (una pregunta, no cinco)

### Lo que la comunidad puede y no puede resolver

| Sí | No |
|---|---|
| Dudas sobre lo que explica el curso | Revisar tu caso laboral con nombres |
| Cómo calcular tu aguinaldo o tu tarifa | Decirte con qué banco, app o aseguradora contratar |
| A qué institución acudir | Hacer trámites por ti |
| Cómo reconocer un fraude | Operar tu banca o tu celular |

### Pedir apoyo de forma segura

- Para dudas con tu celular o tu banca, el equipo te explica en una sesión; tú haces los pasos.
- Nunca compartas tu pantalla con desconocidos ni instales apps que te pidan para «ayudarte».

### Responder a otras

Puedes compartir tu experiencia: di que es tu experiencia, no una regla; no recomiendes marcas ni personas; si no estás segura, remite a la lección o a la institución oficial.


## Tu calendario del año

Fechas y recordatorios que importan para tu dinero, tu familia y tu trabajo. En **Avisos** y en el canal te recordamos cada una a tiempo.

| Mes | Recordatorio | Lección |
|---|---|---|
| Enero | Nuevo salario mínimo: pide el ajuste de tu tarifa con números | M2 U02 |
| Enero | Empieza a apartar para diciembre | M3 U04 |
| Febrero | Divide los útiles de agosto entre las semanas que faltan | M3 U04 |
| Marzo | Revisa las cuotas del Seguro de Salud para la Familia del IMSS | M6 U02 |
| Abril | Pide tu reporte de crédito sin costo | M5 U05 |
| Mayo | Revisa tu Afore y tus beneficiarias | M8 U02 · M8 U04 |
| Junio | Chequeo en tu centro de salud | M6 U03 |
| Julio | Calcula tus vacaciones y platícalas | M2 U01 |
| Agosto | Revisa las fechas de registro de becas | M8 U03 |
| Septiembre | Mes del Testamento: aprovecha los descuentos | M8 U05 |
| Octubre | Calcula tu aguinaldo en cada casa | M2 U01 |
| Noviembre | Cuidado con fraudes de fin de año y falsos premios | M7 U01 |
| Diciembre | Aguinaldo: una parte a tu fondo; revisa tu plan de una página | M3 U03 · M9 U04 |

Las fechas oficiales pueden cambiar. Confírmalas en el sitio de cada institución.


## Sesiones de acompañamiento y retos

### Sesiones de acompañamiento

Una sesión en grupo por módulo o cada dos semanas, por la tarde entre semana o en domingo, presencial o por videollamada. La fecha y el lugar o enlace se publican en **Avisos** y en el canal.

- Duración: 60 minutos.
- Repasamos el módulo, resolvemos dudas generales y hacemos un ejercicio con números inventados.
- Nunca se usa tu banca real frente al grupo ni se te pide tu celular.
- Puedes llevar a tu hija o a tu persona de confianza.

### Retos del mes

Cada mes proponemos un reto corto en **Avisos**. Cuando lo cumplas, compártelo en **Logros**, sin datos personales.

| Mes | Reto |
|---|---|
| 1 | Anota un mes de lo que cobras en cada casa (M1 U01) |
| 2 | Reparte tu pago en tres sobres (M1 U02) |
| 3 | Calcula tu aguinaldo y tus vacaciones (M2 U01) |
| 4 | Manda tu acuerdo por mensaje a una casa (M2 U03) |
| 5 | Junta dos semanas de fondo (M3 U03) |
| 6 | Llena tu mapa de apoyo a la familia (M4 U01) |
| 7 | Haz tu lista de deudas y elige tu orden (M5 U01 · M5 U04) |
| 8 | Consulta tu NSS o calcula el seguro de tu familia (M6 U01 · M6 U02) |
| 9 | Nombra beneficiarias en tu cuenta y tu Afore (M8 U04) |
| 10 | Pon candados a tu celular (M7 U03) |
| 11 | Ofrece un servicio extra (M9 U02) |
| 12 | Llena tu plan de una página con tu compromiso (M9 U04) |

### Encuesta de la comunidad

Dos veces al año te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima.


## Cómo funcionan las referencias comerciales

Queremos que sepas exactamente qué es contenido del programa y qué es una oferta comercial.

### Dónde aparecen

- **Solo** en el foro **Referencias comerciales** y en el canal de WhatsApp.
- **Nunca** en las lecciones, las actividades, las autoevaluaciones, las insignias, la constancia ni las sesiones de acompañamiento.

### Qué dicen siempre

> **Referencia comercial:** Desarrolla Talento puede recibir una comisión si contratas este servicio. Compara con al menos otra opción. Usarlo es voluntario y no afecta tu acceso, tus puntos ni tu constancia.

### Antes de contratar cualquier servicio

- Verifica la institución en el SIPRES de la CONDUSEF o en la PROFECO (M5 U03 y M6 U05).
- Pide la propuesta por escrito y espera un día antes de decidir.
- Compara con al menos otra opción.

### Qué nunca verás

- Préstamos.
- Recomendaciones de SOFIPO, SOCAP ni SOFOM.
- Ofertas de trabajo o agencias que pidan depósito.
- Presión para decidir.

