# Your Business, Your Money, Your Future · U.S.: full content

Version 1.3 · Desarrolla Talento. Everything participants see: lessons, support book, H5P activities and question bank.

# Part 1. Characters

| Character | Profile | Main challenge |
|---|---|---|
| **Lupita** (41) | Sells tamales and catering orders from home in Los Angeles; files with an ITIN; her niece helps | Mixed accounts; doesn't know which permits she needs or whether she can get them with her ITIN |
| **Javier** (38) | Painter and handyman in Fresno; works for contractors and homeowners | Taxes not set aside, 1099s, CSLB license, insurance clients ask for |
| **Daniela** (27) | Sells jewelry on social media and a platform from San José; has an LLC | 1099-K, sales tax, fees, personal credit card debt, trademark |
| **Don Ramón** (60) | Has run a food truck in Sacramento for 12 years | Seasons, expensive credit, insurance, retirement and who will carry on the business |

These characters are fictional; any resemblance to real people is coincidental.

---

## 2. Module map

| Module | Lessons | Outcome |
|---|---|---|
| M1 Your business and your home: separate money | 6 | Separate money, tax account, fixed salary, records, online betting and your money in your name |
| M2 Costs and price | 4 | Costs calculated, price with margin and break-even point |
| M3 Cash flow | 4 | Cash-flow calendar, customer credit, reserve and inflation |
| M4 Get paid and sell without losing | 3 | Payment methods compared and anti-scam plan |
| M5 Formalize and handle taxes without fear | 5 | Structure, EIN and ITIN, permits, federal taxes, estimated payments and sales tax |
| M6 Credit for your business | 5 | Decide whether you need credit, compare by APR, don't mix and know what you sign for others or your LLC |
| M7 Protect your business | 7 | Health insurance, business insurance, scams (including AI), trademark, identity, unwanted calls and disasters |
| M8 Grow in an orderly way | 6 | Hire correctly, sell on platforms, measure, look after your energy, business plan and surroundings |
| M9 Your future | 3 | Social Security and retirement, continuity plan and one-page plan |

**Badges:** Separate money (M1), Fair price (M2), Cash flow under control (M3 and M4), Formal business (M5), Smart credit (M6), Protected business (M7), Orderly growth (M8 and M9) and Full plan (course).

---

## 3. Lessons

# Part 2. Module 1. Your business and your home: separate money

## M1 U01. Is your business making money or just selling?

**What you will be able to do:** Tell the difference between sales and profit, and figure out whether your business makes money, loses money or just breaks even.

**To start:** Lupita sells tamales and catering orders in Los Angeles: about $4,000 a month. It feels like business is good, but at the end of the month she can't cover her rent. In this lesson you'll see why selling a lot isn't always the same as making money.

### The essentials (5 minutes)

#### Selling isn't earning

Sales are what you charge. Profit is what's left after you pay everything it cost you to sell: ingredients, packaging, gas, mileage, fees and help.



#### Lupita's month

- Sales: **$4,000**
- Ingredients and packaging: **$1,700**
- Gas, mileage, fees and her niece's help: **$900**
- Business profit: **$1,400**
Lupita thought she made $4,000. She actually keeps $1,400, and her taxes also come out of that (M5).


#### Three possible results

| Type | Description | What it means for you |
|---|---|---|
| You make money | Sales are higher than all costs. | You can pay yourself and save. |
| You break even | Sales equal costs. | You work without pay. |
| You lose money | Costs are higher than sales. | You pay out of pocket. |

#### A case in one minute

Lupita kept every receipt for a month. She found that delivery gas and corn husks were almost $400 she never counted. Now she knows her real profit is $1,400.

> **Key idea:** don't measure your business by what you sell, but by what you keep after paying everything.



#### Check your understanding

1. What is the difference between sales and profit?
*Answer:* Sales are what you charge; profit is what's left after paying all costs.

2. If you sell $2,000 and spend $2,000, how much do you earn?
*Answer:* Nothing: you break even and work without pay.


#### Remember

- Sales minus costs is profit.
- Count every cost, even the small ones.
- Your taxes also come out of profit.



### Go deeper (5 more minutes)

#### Costs people forget

| Cost | Why it gets forgotten |
|---|---|
| Gas and delivery miles | You pay them out of pocket |
| Packaging, bags, labels | Small amounts that add up |
| App and card fees | They are taken out automatically |
| Your phone and internet | You also use them at home |
| What goes bad | It doesn't look like an expense |



#### Your time costs too

If you work 50 hours a week and the business leaves you $1,400 a month, you earn about $7 an hour: less than minimum wage. Comparing helps you decide what to improve: prices, costs or sales.



#### Cases


**Case 1. Lupita's month**

Lupita sold more than ever in December thanks to tamales, but she paid more for ingredients and help.
- *What does she do to know whether she made money?* She subtracts all the month's costs from her sales before celebrating.


**Case 2. Daniela's orders**

Daniela sold 90 pairs of earrings in a month, but paid for shipping she didn't charge.
- *What does she check?* How much she keeps per piece after materials, shipping and fees.


**Case 3. Javier's hours**

Javier charges well for each painting job, but spends many unpaid hours driving and giving estimates.
- *What does he do?* He figures out how much he earns per hour, counting travel, and adjusts his rate.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Measuring by sales | You think you earn | Subtract all costs |
| Forgetting small costs | Inflated profit | Keep receipts for a month |
| Not counting your time | You work cheap | Figure it per hour |
| Forgetting taxes | April surprise | Set some aside (M5) |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Daniela and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You sell $3,000 and your costs are $2,200. How much do you earn? a) $800 · b) $3,000 · c) $5,200
2. What is profit? a) Everything you charge customers in the month, in cash and through apps · b) What's left after paying all costs · c) What's in your account at closing
3. Your sales and costs are the same. What happens? a) You earn a little, but the business does leave you something · b) You lose money every month · c) You break even: you work without pay
**Answers:** 1-a: $3,000 minus $2,200. 2-b: sales minus costs. 3-c: nothing is left for you.



#### Put it into practice

You sell $2,500 a month. You spend $1,100 on materials, $300 on gas and $100 on fees. How much do you earn?
**Answer:** $2,500 minus $1,500: $1,000.



#### Your plan

This week, write down all your sales and keep every business receipt, even small ones.



### Learn more

- **Plan your business** (SBA · English and Spanish): https://www.sba.gov | What to look for: "plan your business".

### Key words

- *Sales:* everything you charge your customers, before subtracting what it cost you.
- *Profit:* what is left from sales after paying all the business costs.

### Sources

U.S. Small Business Administration (SBA), accessed September 29, 2026.

---

## M1 U02. Keep business money separate from home money

**What you will be able to do:** Separate business money from household money with a separate account and clear rules.

**To start:** Lupita gets paid by Zelle and in cash into the same account where her part-time paycheck lands. She pays rent and ingredients from there. In this lesson you'll see how to separate without making it complicated.

### The essentials (5 minutes)

#### Two pockets, two owners

Your business and your home are two different pockets. If you mix them, you'll never know whether your business makes money, and at tax time it will be hard to prove your expenses. The rule: **business money only goes out for business things or for your salary.**



#### How to separate

1. Open a checking account just for the business (it can be in your name).
2. All payments go in there: cash, cards and payment apps.
3. Pay business materials, permits and gas only from there.
4. For your home, pay yourself a fixed salary (M1 U03).



#### What goes in each pocket

| Type | Description | What it means for you |
|---|---|---|
| Business | Ingredients, materials, fees, permits. | Paid from the business account. |
| Home | Rent, food, school. | Paid from your salary. |
| Mixed | Everything in one account. | You don't know if you earn. |
| Payments to your personal app | They get lost among your expenses. | Use a business account. |

> **Current fact:** the FDIC insures deposits at banks up to $250,000 per depositor, per bank, per ownership category; the NCUA protects the same at credit unions. Accessed September 29, 2026 through the FDIC and NCUA.

#### A case in one minute

Lupita opened a second checking account at a credit union, with no monthly fee, and linked her payment app to it. Now she knows how much she sells each week.

> **Key idea:** separate the money and pay yourself a salary; you'll know whether your business makes money and your expenses will be ready for taxes.



#### Check your understanding

1. Why separate the money?
*Answer:* To know whether your business makes money and to have proof of your expenses for taxes.

2. How do you move money from the business to your home?
*Answer:* With a fixed salary, not by paying household bills from the business.


#### Remember

- Two pockets: business and home.
- Every payment goes into the business.
- Only your salary goes home.



### Go deeper (5 more minutes)

#### Personal or business account?

If you work as a sole proprietor, you can use a second personal account just for the business. Many business accounts ask for an EIN or business documents (M5 U02). Compare monthly fees, minimum balance and how many transactions are included. Some banks and credit unions open accounts with an ITIN.



#### Cash

If you collect a lot of cash, count it at closing, write down the total and deposit it often. Cash is also income you must report.



#### If you have to borrow

If one day you use business money for a household emergency, write it down as a loan and pay it back.



#### Cases


**Case 1. Lupita's account**

Lupita receives business payments and her paycheck in the same account.
- *What does she do?* She opens an account just for the business and links her payments there.


**Case 2. Javier's supplies**

Javier buys paint with his household debit card.
- *What does he do?* He pays from the business account and keeps the receipt.


**Case 3. Don Ramón's cash**

Don Ramón keeps the food truck's cash at home for weeks.
- *What does he do?* He counts it, writes it down and deposits it often in the business account.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| One single account | Everything gets mixed | Separate account |
| Paying home bills from the business | You don't know if you earn | Fixed salary |
| Cash not written down | Unrecorded income | Write down and deposit |
| Loans not written down | Holes in the books | Write down and repay |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you pay business materials from? a) Your household account · b) The business account · c) Whatever you have that day in your wallet or cash box
2. You use $200 from the business for a household emergency. What do you do? a) Forget it, it's your business anyway · b) Cover it with your credit card and forget about it · c) Write it down as a loan and pay it back
3. How much does the FDIC insure per depositor, per bank, per ownership category? a) $250,000 · b) $25,000 · c) Everything you have, no limit
**Answers:** 1-b: each pocket pays its own. 2-c: that way it doesn't get lost. 3-a: per depositor, bank and category.



#### Put it into practice

In one week $900 came into the business account and you paid $520 for materials. How much is left in the business?
**Answer:** $380.



#### Your plan

This week, choose your business account and link your payment apps to it.



### Learn more

- **Deposit insurance** (FDIC · English and Spanish): https://www.fdic.gov | What to look for: "deposit insurance".
- **Bank accounts** (CFPB · English): https://www.consumerfinance.gov | What to look for: "checking accounts".

### Key words

- *Business account:* an account you use only to collect and pay for business things.
- *FDIC:* federal agency that insures bank deposits.

### Sources

FDIC · NCUA · CFPB, accessed September 29, 2026.

---

## M1 U03. Pay yourself a salary

**What you will be able to do:** Set a salary for yourself that the business can afford, setting money aside for taxes first.

**To start:** Lupita already separated her money, but she doesn't know how much to take home. Some weeks she takes a lot and others nothing, and she worries about what she'll owe in taxes. In this lesson you'll see how to set a salary.

### The essentials (5 minutes)

#### You work for your business too

If you work in your business, you deserve a fixed owner's salary, on the same date. That way your home has a steady income and the business keeps what it needs.



#### How to set it

1. Figure out your average profit for the last 3 months.
2. Set aside taxes first (a practical rule: 25% to 30% of profit; M5 U03).
3. From what's left, take part as your salary and leave the rest as a reserve.
4. Pay it on the same day and review it every 3 months.



#### Lupita's salary

- Average monthly profit: **$1,400**
- Set aside for taxes (25%): **$350**
- Business reserve: **$150**
- Monthly salary (about $225 a week): **$900**


#### A case in one minute

Lupita transfers $225 every Monday from the business account to hers. She keeps the tax money in a savings account to make her quarterly payments (M5 U04).

> **Key idea:** taxes first, then reserve, then your fixed salary; that way neither your home nor the IRS catches you off guard.



#### Check your understanding

1. Where does your salary come from?
*Answer:* From average profit, after setting aside taxes and a reserve.

2. Why set aside taxes first?
*Answer:* Because as an owner nobody withholds taxes for you: you pay them yourself.


#### Remember

- Taxes, reserve, salary.
- Based on average profit.
- Review it every 3 months.



### Go deeper (5 more minutes)

#### If you are a sole proprietor

As a sole proprietor, your "salary" is not a business expense for the IRS: you pay taxes on all the profit, whether you take it out or not. That's why setting taxes aside is so important. If you have an LLC or another structure, the rules may change (M5 U01).



#### Your salary in numbers

| Item | Amount |
|---|---|
| Average profit, 3 months | |
| Taxes (25% to 30%) | |
| Reserve | |
| Monthly salary | |
| Weekly salary | |



#### If family helps

If your niece or your partner works in the business, agree on pay. If they are employees, payroll rules apply (M8 U01).



#### Cases


**Case 1. Lupita's great week**

Lupita sold three times as much in Christmas week.
- *What does she do?* She pays herself her usual salary and sets the extra aside for taxes and the reserve.


**Case 2. Javier's months**

Javier earns $6,000 in summer and $2,000 in winter.
- *What does he do?* He pays himself a salary based on his average and saves what he earns in good months.


**Case 3. Daniela's taxes**

Daniela spends all her profit and hasn't set anything aside for taxes.
- *What does she do from today on?* She sets a percentage of each profit aside in an account for taxes.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Spending everything | IRS debt | Set taxes aside |
| Taking money based on sales | Unstable home | Fixed salary |
| Not paying yourself | You don't know your cost | Pay yourself |
| Thinking your salary lowers taxes | Surprise | You pay on profit |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Javier and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Your profit is $2,000 and you set aside 25% for taxes. How much is that? a) $250 · b) $2,000 · c) $500
2. You had an excellent week. What do you do? a) Pay yourself your salary and set the extra aside · b) Take all the extra home because you earned it · c) Raise your salary starting that day
3. Why do you set aside taxes as an owner? a) Because nobody withholds them for you · b) Because the bank asks you to when you open the account · c) There's no need: they pay themselves
**Answers:** 1-c: 25% of $2,000. 2-a: the extra gets set aside. 3-a: you pay them yourself.



#### Put it into practice

Your profit was $1,800, $2,100 and $1,500 over three months. You set aside 25% for taxes and $200 for the reserve. What is your monthly salary?
**Answer:** Average $1,800; minus $450 and $200: $1,150.



#### Your plan

Figure out your average profit, open an account for taxes and set your salary and payday.



### Learn more

- **Self-employment tax** (IRS · English and Spanish): https://www.irs.gov | What to look for: "self-employment tax".

### Key words

- *Owner's salary:* a fixed amount you transfer from the business to yourself every week or two weeks.
- *Sole proprietor:* a person who owns a business in their own name, without creating a separate company.

### Sources

IRS · SBA, accessed September 29, 2026.

---

## M1 U04. Records in 10 minutes a day

**What you will be able to do:** Keep a simple record of sales and expenses, keep receipts and do a weekly check.

**To start:** Daniela sells jewelry on Instagram and in an online store. She keeps payments in screenshots and expenses in her head. In April she didn't know what to report. In this lesson you'll see how to keep your records.

### The essentials (5 minutes)

#### What to write down

Every day write down: date, how much you sold (cash, card, apps) and how much you spent and on what. Keep the receipts. The IRS asks you to be able to **prove** your income and expenses.



#### Choose your tool

| Type | Description | What it means for you |
|---|---|---|
| Notebook | Simple. | Add it up every week. |
| Spreadsheet | Adds up by itself. | On your phone or computer. |
| Bookkeeping app | Connects your account and gives reports. | Check cost and data. |
| Screenshots only | They get lost. | They don't add up. |

#### Your weekly check

1. Add up the week's sales.
2. Add up business expenses.
3. Subtract: that's your profit for the week.
4. Compare it with the business account balance.



#### A case in one minute

Daniela made a sheet with date, item, money in and money out, and a digital folder for receipt photos. Every Sunday she does her weekly check. In January her year will be ready to file.

> **Key idea:** write things down every day, keep receipts and check every week; without records there are no decisions and no correct tax return.



#### Check your understanding

1. What do you write down every day?
*Answer:* Date, sales and expenses with what they were for.

2. Why keep receipts?
*Answer:* To prove your business expenses to the IRS.


#### Remember

- Daily: date, in, out.
- Receipts kept.
- Weekly check.



### Go deeper (5 more minutes)

#### Your record

| Date | Item | In | Out |
|---|---|---|---|
| | | | |
| | | | |
| **Week total** | | | |



#### Business miles

If you use your car for the business, write down the date, destination, purpose and miles of each trip. You can deduct them with the IRS standard mileage rate (M5 U03). No log, no deduction.

> **Current fact:** the IRS standard mileage rate for business use is 72.5 cents per mile from January to June 2026 and 76 cents per mile from July 1, 2026. Accessed September 29, 2026 through the IRS (Notice 2026-10 and Internal Revenue Bulletin 2026-29).



#### How long to keep them

The IRS recommends keeping your records and receipts at least 3 years after you file your return, and longer in some cases.



#### Cases


**Case 1. Daniela's screenshots**

Daniela has hundreds of payment screenshots from the year.
- *What does she do?* She moves each payment to her sheet the same day and keeps receipts in a folder.


**Case 2. Javier's miles**

Javier drives to give estimates every day and doesn't write anything down.
- *What does he do?* He writes down the date, destination, purpose and miles of each trip.


**Case 3. Don Ramón's app**

A no-cost app asks Don Ramón for his Social Security number and his bank password to "do his books."
- *What does he do?* He doesn't give his password and chooses a trusted tool or a spreadsheet.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Writing from memory | Expenses get forgotten | Daily |
| No receipts | You can't deduct | Keep them |
| No mileage log | You lose the deduction | Log each trip |
| Giving passwords | Theft | Never |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What's the minimum you write down every day? a) Only the big sales · b) Whatever you remember on Sunday · c) Date, sales and expenses
2. What do you need to deduct miles? a) A log of each trip · b) Only the month's gas receipt · c) Nothing, it's calculated automatically
3. An app asks for your bank password. What do you do? a) Give it if the app costs nothing and has good reviews · b) Don't give it and choose another tool · c) Give only your Social Security number
**Answers:** 1-c: that's enough. 2-a: no log, no deduction. 3-b: it asks for too much.



#### Put it into practice

You drove 300 business miles in August 2026. How much could you deduct with the standard rate?
**Answer:** 300 times 76 cents: $228.



#### Your plan

Choose your tool, create a receipts folder and write down your sales, expenses and miles this week.



### Learn more

- **Recordkeeping for small businesses** (IRS · English): https://www.irs.gov | What to look for: "recordkeeping".

### Key words

- *Record:* a list of what comes in and goes out of the business, with date and item.
- *Weekly check:* adding up sales and expenses for a period to know how much you earned.
- *Standard mileage rate:* the amount the IRS lets you deduct for each business mile driven.

### Sources

IRS, accessed September 29, 2026.

---

## M1 U05. Online betting: business money isn't for gambling

**What you will be able to do:** Recognize how online betting and casinos put your business at risk, know the rules in California and where to get help.

**To start:** Javier started betting $20 on games between jobs. One month he used $600 from the business account "to win it back" and couldn't cover the paint for a job. In this lesson you'll see how to protect your business money.

### The essentials (5 minutes)

#### Why it's a risk for your business

Betting apps, online casinos and "sweepstakes casinos" are one tap away, all day, with bonuses and alerts. If business money and your own money are mixed, it's easy to take from the business account without noticing. In the long run, the house always wins.



#### Warning signs

| Type | Description | What it means for you |
|---|---|---|
| Chasing losses | You bet more to "win it back." | The main trap. |
| Using business money | Or what you set aside for taxes. | You put your work at risk. |
| Betting on credit | Card or advances. | Guaranteed debt. |
| Limit and personal account | Only from your salary, with a cap. | Control. |

> **Current fact:** online sports betting is not legal in California, and since January 1, 2026, online sweepstakes casinos are also banned under AB 831. Rules vary by state. Accessed September 29, 2026 through legal sources and specialized media.

#### A case in one minute

Javier put the $600 back into the business account, deleted the apps and told his brother. Now his tax money and business money are in separate accounts and his salary is fixed.

> **Key idea:** business money and tax money are never for betting; chasing losses or betting on credit means it's already a problem.



#### Check your understanding

1. Where should betting money never come from?
*Answer:* The business, your tax account, loans or cards.

2. Is online sports betting legal in California?
*Answer:* No, and online sweepstakes casinos have been banned since 2026.


#### Remember

- Never from the business or taxes.
- Never on credit.
- Cap, pause and help.



### Go deeper (5 more minutes)

#### Winnings are taxable too

Gambling winnings are income for the IRS even if you don't get a form. One more reason to keep records and not mix them with the business.



#### Getting help

Compulsive gambling is a health problem. The national helpline 1-800-GAMBLER costs nothing and available 24 hours a day. California also offers no-cost treatment for residents.

> **Before you act, check:** your state's rules; what's legal in one state may not be in another, and unlicensed sites don't protect you if they don't pay.



#### Cases


**Case 1. Javier's account**

Javier lost money betting and wants to use $300 of his tax money.
- *What does he do?* He doesn't touch that money, stops betting and gets help.


**Case 2. Daniela's sweepstakes casino**

A "sweepstakes casino" app offers Daniela bonus coins if she buys a package.
- *What does she check?* That they've been banned in California since 2026 and that the money doesn't come from the business.


**Case 3. Don Ramón's helper**

Don Ramón's helper asks for an advance to bet on the game.
- *What does he do?* He doesn't give it for betting and shares where to get help.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Taking from the business | Short for work | Only from your salary |
| Using tax money | IRS debt | Separate account |
| Betting on credit | Debt | Never |
| Unlicensed sites | They don't pay | Check your state |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Daniela and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where can betting money come from, if you choose to bet? a) The business account · b) Your salary, with a cap · c) What you set aside for taxes
2. What about gambling winnings? a) They are income you report · b) They are never taxed · c) They're only reported above $10,000
3. Where do you get help with gambling in the U.S.? a) In the betting app itself · b) At 1-800-GAMBLER · c) From whoever lends you money to bet
**Answers:** 1-b: never from the business. 2-a: all income is reported. 3-b: at no cost, 24 hours a day.



#### Put it into practice

You bet $20 a day, 25 days a month. How much is that a month and a year?
**Answer:** $500 a month; $6,000 a year.



#### Your plan

Separate your tax account and, if you bet, set a cap that comes only from your salary.



### Learn more

- **Gambling help** (National Council on Problem Gambling · English and Spanish): 1-800-GAMBLER.
- **Gambling income** (IRS · English): https://www.irs.gov | What to look for: "gambling income and losses".

### Key words

- *Sweepstakes casino:* a site that simulates betting with virtual coins redeemable for money; banned in California since 2026.
- *Compulsive gambling:* when you can't stop betting even though it causes problems.

### Sources

IRS · National Council on Problem Gambling · California AB 831 (2025), accessed September 29, 2026.

---

## M1 U06. Your business, your decisions: your money in your name

**What you will be able to do:** Recognize your skills as the base of your business, keep accounts and records in your name, decide about your income and recognize when someone controls your money.

**To start:** Lupita cooks every day, but her partner collects the orders in his own app and decides how the money is spent. When she wanted to buy an industrial pot, he said there was no money. In this lesson you'll see how to keep your decisions and your money in your name.

### The essentials (5 minutes)

#### What you know how to do is capital too

| Type | Description | What it means for you |
|---|---|---|
| Productive | Cooking, selling, repairing, sewing. | What you offer. |
| Social | Listening, persuading, teaching. | How you serve. |
| Financial | Running tandas, finding deals, paying on time. | How you manage. |
| Organizing | Planning parties, finding support. | How you operate. |

#### Your money in your name

1. A business account in your name that you manage; many banks and credit unions accept an ITIN (M1 U02).
2. Your payment apps linked to your account, not someone else's.
3. Your records and your fixed salary, decided by you (M1 U03 and M1 U04).
4. Written agreements if family members work with you (M8 U01).



#### When someone controls your money

If someone takes your income, keeps you from working, demands an account of every dollar or uses your name to borrow, it is economic abuse. It isn't a money-management problem: it's abuse, and help is available in English and Spanish, regardless of immigration status.



#### A case in one minute

Lupita opened a business account in her name at a credit union with her ITIN and linked her payment app to it. Her records showed the pot would pay for itself in three months. Now she decides the business purchases, and household spending is agreed together.

> **Key idea:** your skills are your business's capital; keep your account, your payments and your decisions in your name, and if someone controls your money, get help.



#### Check your understanding

1. Whose name should your business account be in?
*Answer:* Yours, and you manage it.

2. What is economic abuse?
*Answer:* When someone controls, withholds or uses your money to dominate you.


#### Remember

- Your skills count.
- Account and payments in your name.
- Controlled money = get help.



### Go deeper (5 more minutes)

#### Talking about money without fighting

Agree on what belongs to the business and what belongs to the household, with numbers in hand. Your fixed salary (M1 U03) is what you bring home; the rest belongs to the business.



#### Where to get help

The National Domestic Violence Hotline costs nothing, 24 hours a day, in English and Spanish: call 1-800-799-7233 or text START to 88788. In an emergency, call 911.

> **Before you act, check:** that your account, your EIN or ITIN and your contracts are in your name and that no one else has your passwords.



#### Cases


**Case 1. Lupita's app**

Lupita's partner collects the orders in his own app and decides everything.
- *What does she do?* She opens a business account in her name and links her payments to it.


**Case 2. Daniela's list**

Daniela thinks she has nothing to offer besides selling jewelry.
- *What does she do?* She lists her skills and finds new services.


**Case 3. The loan in Javier's name**

Javier's brother asks for his Social Security number or EIN to get a loan "for the business."
- *What does he do?* He doesn't lend his numbers: the debt would be his.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Payments in someone else's name | You don't decide | In your name |
| Not valuing what you know | You miss options | Skills list |
| Lending your numbers | Your debt | No |
| Staying quiet about abuse | It gets worse | Get help |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Daniela and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Whose name do you link your business payments to? a) Your partner's, who knows more · b) Yours · c) A trusted customer's
2. Someone takes what you earn and keeps you from working. What is it? a) Economic abuse · b) A money-management problem · c) Normal between partners
3. A relative asks for your EIN to get a loan. What happens if you lend it? a) Nothing · b) The debt is your relative's · c) The debt and the history are yours
**Answers:** 1-b: you decide. 2-a: no-cost help is available. 3-c: your name is on the line.



#### Put it into practice

An industrial pot costs $450 and saves you $150 a month. In how many months does it pay for itself?
**Answer:** In 3 months.



#### Your plan

List your skills and check that your business account and payments are in your name.



### Learn more

- **National Domestic Violence Hotline** (English and Spanish): 1-800-799-7233 · https://www.thehotline.org.
- **Economic abuse** (CFPB · English and Spanish): https://www.consumerfinance.gov | What to look for: "economic abuse".

### Key words

- *Economic abuse:* when another person controls, withholds or uses your money or property to dominate you.
- *Economic autonomy:* being able to earn, keep and decide about your own money.

### Sources

National Domestic Violence Hotline · CFPB, accessed September 30, 2026.

---


# Part 3. Module 2. Costs and price

## M2 U01. Fixed and variable costs

**What you will be able to do:** Split your costs into fixed and variable and figure out how much each product or service really costs you.

**To start:** Daniela spends $6 on materials for each pair of earrings and sells them for $25. She thinks she makes $19 a pair. But she hasn't counted the online store fee, shipping or her monthly subscription. In this lesson you'll see what each pair really costs.

### The essentials (5 minutes)

#### Two kinds of costs

| Type | Description | What it means for you |
|---|---|---|
| Fixed | You pay them whether you sell or not: subscriptions, insurance, phone, permits. | Same each month. |
| Variable | They go up when you sell more: materials, packaging, fees, shipping. | Per sale. |
| Your salary | One more fixed cost. | Don't forget it. |
| Unsorted | You don't know what it costs to sell. | Sort them. |

#### Your cost per unit

Cost per unit adds what you spend on each piece (variable) plus its share of your fixed costs.



#### Daniela's earrings

- Materials: **$6**
- Packaging, shipping and fee: **$5**
- Share of fixed costs ($360 a month ÷ 120 pairs): **$3**
- Real cost per pair: **$14**
Daniela doesn't make $19 a pair but $11, and her taxes come out of that.


#### A case in one minute

Lupita figured out that each dozen tamales costs her $14 in ingredients and $4 as her share of fixed costs: $18. She sells it for $30. Now she knows she keeps $12 a dozen.

> **Key idea:** add to each product what you spend on it plus its share of your fixed costs.



#### Check your understanding

1. What is a fixed cost?
*Answer:* One you pay even if you don't sell, such as a subscription, insurance or your salary.

2. How do you spread fixed costs per unit?
*Answer:* Divide the month's fixed costs by the units you sell in a month.


#### Remember

- Fixed: sell or not.
- Variable: per sale.
- Cost per unit = variable + share of fixed.



### Go deeper (5 more minutes)

#### Your monthly costs

| Cost | Fixed or variable | Monthly amount |
|---|---|---|
| Rent or commercial kitchen | Fixed | |
| Phone, internet, subscriptions | Fixed | |
| Insurance and permits (divided by 12) | Fixed | |
| Your salary and helpers | Fixed | |
| Materials or ingredients | Variable | |
| Packaging and shipping | Variable | |
| Card and app fees | Variable | |



#### Services: your hour has a cost

If you sell services, like Javier, your main cost is your time. Divide your fixed costs and salary by the hours you actually bill in a month: that's your cost per hour. Add materials, miles and tool wear.



#### Cases


**Case 1. Daniela's earrings**

Daniela thinks she makes $19 a pair because materials cost $6 and she sells them for $25.
- *What is she missing?* Packaging, shipping, fees and her share of fixed costs.


**Case 2. Javier's hour**

Javier charges $35 an hour, but doesn't know if it's enough.
- *What does he calculate?* His cost per hour with his fixed costs, salary and billed hours.


**Case 3. Don Ramón's insurance**

Don Ramón pays the food truck insurance once a year and never counts it in his costs.
- *What does he do?* He divides it by 12 and adds it to his monthly fixed costs.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Counting only materials | Low price | Add fixed costs |
| Forgetting your salary | You work without pay | It's a fixed cost |
| Ignoring yearly payments | Surprises | Divide by 12 |
| Not counting time | Cheap service | Cost per hour |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which of these is a variable cost? a) Your online store subscription · b) The packaging for each order · c) Your phone plan
2. Your fixed costs are $600 and you sell 200 pieces a month. How much fixed cost goes to each piece? a) $3 · b) $30 · c) $600
3. Is your salary a business cost? a) No, it's profit · b) Only if something is left at the end of the month · c) Yes, it's a fixed cost
**Answers:** 1-b: it goes up with each sale. 2-a: $600 divided by 200. 3-c: without it you work without pay.



#### Put it into practice

A cake costs you $18 in ingredients and $2 for the box. Your fixed costs are $400 a month and you sell 50 cakes. What is the cost per cake?
**Answer:** $18 plus $2 plus $8 ($400 divided by 50): $28.



#### Your plan

List your monthly costs, split them into fixed and variable and figure out the cost of your main product.



### Learn more

- **Calculate your startup costs** (SBA · English): https://www.sba.gov | What to look for: "calculate your startup costs".

### Key words

- *Fixed cost:* an expense you pay whether you sell or not, like a subscription or your salary.
- *Variable cost:* an expense that goes up with each sale, like materials or packaging.
- *Cost per unit:* what it costs you to make or sell one piece, dish or service, counting variable costs and a share of fixed costs.

### Sources

SBA, accessed September 29, 2026.

---

## M2 U02. How much should you charge?

**What you will be able to do:** Set a price that covers your costs, leaves a margin and makes sense for your customers and against the competition.

**To start:** Javier charges the same as other painters in his area because "that's the going rate." But he has insurance, a truck and new tools. In this lesson you'll see how to set your own price.

### The essentials (5 minutes)

#### Three ways to look at your price

Check your price from three sides: **your cost** (the floor, never charge less), **the competition** (what others charge for something similar) and **the value to your customer** (speed, quality, guarantee, insurance).



#### Price with a margin

- Real cost per pair of earrings: **$14**
- For a 30% margin on price: **0.70**
- Minimum price: **$20**
Daniela sells at $25: her margin is 44%. She has room for promotions without losing.


#### Your price against others

| Type | Description | What it means for you |
|---|---|---|
| Cheapest of all | Lots of sales, little profit. | Risk of losing. |
| Similar | You compete on service and quality. | Show why you. |
| More expensive | You need to explain the value. | Insurance, guarantee, speed. |
| Below your cost | You lose on every sale. | Never. |

#### A case in one minute

Javier figured out his cost per hour is $32. He charged $35 and barely kept anything. He raised it to $45 and his estimates now say he has liability insurance and a 30-day guarantee. He lost one customer, but earned more with the rest.

> **Key idea:** your cost is the floor; your margin lets you grow and pay taxes; competition and value tell you how high you can go.



#### Check your understanding

1. What is the floor for your price?
*Answer:* Your cost per unit: you never charge less.

2. What is margin?
*Answer:* The part of the price left after covering the cost.


#### Remember

- Cost = floor.
- Margin = growth.
- Competition and value = ceiling.



### Go deeper (5 more minutes)

#### Margin and markup are not the same

If you add 30% to a $100 cost, you charge $130 and your margin is 23% ($30 divided by $130). For a 30% margin, divide the cost by 0.70: $143.



#### Shipping, fees and sales tax

Shipping, platform fees and card fees are variable costs: add them to the cost or charge them clearly. Sales tax is not part of your price: it's charged separately and belongs to the state (M5 U05).



#### Raising prices without losing customers

Give notice ahead of time, explain why (materials, quality) and keep a budget option if you can.



#### Cases


**Case 1. Javier's price**

Javier charges the same as other painters, even though his costs are higher.
- *What does he do?* He figures out his cost per hour and sets a price with margin, explaining his insurance and guarantee.


**Case 2. Daniela's sale**

Daniela wants to drop her earrings to $15 to sell more.
- *What does she check?* That $15 covers her real cost of $14 and leaves margin for taxes.


**Case 3. Lupita's price increase**

Masa and meat went up and Lupita's tamales barely make money.
- *What does she do?* She recalculates her cost, tells her customers and raises the price with notice.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Copying prices | You don't cover your costs | Figure your own |
| Selling below cost | You lose on every sale | Cost = floor |
| Counting sales tax as profit | You owe the state | It's separate |
| Raising without notice | Upset customers | Give notice and explain |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Daniela and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Your cost is $35. What is the minimum price for a 30% margin on price? a) $45.50 · b) $35 · c) $50
2. When should you never sell? a) Below your cost · b) Higher than the competition · c) With a written guarantee for your customer
3. Your materials went up. What do you do? a) Use cheaper materials without telling your customers · b) Recalculate your cost and announce the new price · c) Wait for prices to drop on their own
**Answers:** 1-c: $35 divided by 0.70. 2-a: you lose on every sale. 3-b: with notice and clarity.



#### Put it into practice

A service costs you $120. You want a 25% margin on price. How much do you charge?
**Answer:** $120 divided by 0.75: $160.



#### Your plan

Check the price of your main product: does it cover your cost and leave a margin? Adjust it if not.



### Learn more

- **Pricing** (SBA · English): https://www.sba.gov | What to look for: "pricing".

### Key words

- *Margin:* the part of the price left after covering the cost.
- *Floor price:* the minimum price that covers your cost.

### Sources

SBA, accessed September 29, 2026.

---

## M2 U03. Your break-even point

**What you will be able to do:** Figure out how much you need to sell each month to cover all your costs.

**To start:** Every month Don Ramón pays for his food truck spot, insurance, the county permit, his salary and his helper's: $6,000. He wants to know how much he must sell not to lose money. In this lesson you'll see how to calculate it.

### The essentials (5 minutes)

#### What it is

The break-even point is what you need to sell so your sales cover all your costs. Below it you lose; above it you earn.



#### The formula

Divide your **fixed costs** by what each dollar of sales leaves after variable costs (your contribution margin).



#### Don Ramón's food truck

- Monthly fixed costs: **$6,000**
- What each sale leaves after ingredients and fees: **60%**
- Minimum monthly sales (about $400 a day, 25 days): **$10,000**
If he sells less than $10,000, he loses; if he sells more, he earns.


#### A case in one minute

Don Ramón averages $480 a day: $12,000 a month. He is $2,000 above his break-even point: that leaves him $1,200 of profit (60% of $2,000) on top of his salary, before taxes.

> **Key idea:** know your minimum daily sales; it's your target so you don't lose.



#### Check your understanding

1. What happens if you sell less than your break-even point?
*Answer:* You lose money that month.

2. What do you need to calculate it?
*Answer:* Your fixed costs and what each sale leaves after variable costs.


#### Remember

- Fixed ÷ contribution margin.
- Your daily target so you don't lose.
- Above you earn, below you lose.



### Go deeper (5 more minutes)

#### In units

If you sell one main product, calculate in pieces. Lupita has $500 in fixed costs and each dozen leaves her $16 ($30 minus $14 in ingredients): she needs about 32 dozen a month, about 8 a week.



#### Your break-even point

| Item | Amount |
|---|---|
| Monthly fixed costs (including your salary) | |
| What each sale leaves (%) or each piece | |
| Monthly break-even point | |
| Daily target (divided by working days) | |



#### How to lower it

Lower fixed costs, raise the price or improve what each sale leaves (buy better, reduce waste, negotiate fees).



#### Cases


**Case 1. Don Ramón's spot**

Don Ramón's parking spot goes up $400 a month.
- *What does he do?* He recalculates his break-even point and daily target.


**Case 2. Lupita's tamales**

Lupita sells 6 dozen a week and her break-even is 8.
- *What does she do?* She looks to raise sales or price, or lower costs, so she doesn't lose.


**Case 3. Daniela's shop**

Daniela wants to rent a small shop for $900 a month.
- *What does she calculate first?* How much more she would need to sell to cover the new rent.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not knowing your minimum | You lose without knowing | Calculate your break-even |
| Leaving your salary out of fixed costs | False break-even | Include it |
| Not recalculating | Old targets | Every cost change |
| Renting without calculating | Debt | Calculate first |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Fixed costs of $3,000 and each sale leaves 50%. Break-even point? a) $1,500 · b) $6,000 · c) $3,500
2. You sell less than your break-even point. What happens? a) You earn a little · b) You're even · c) You lose money
3. What lowers your break-even point? a) Lowering fixed costs · b) Renting a bigger place in a better area · c) Giving customers more credit
**Answers:** 1-b: $3,000 divided by 0.50. 2-c: you don't cover your costs. 3-a: you need to sell less.



#### Put it into practice

Your fixed costs are $1,200 and each piece leaves you $8. How many pieces do you need to sell each month?
**Answer:** $1,200 divided by $8: 150 pieces.



#### Your plan

Calculate your break-even point and write your daily sales target where you can see it.



### Learn more

- **Break-even point** (SBA · English): https://www.sba.gov | What to look for: "break-even point".

### Key words

- *Break-even point:* minimum sales to cover all your costs: you neither earn nor lose.
- *Contribution margin:* what is left of each sale after paying its variable costs, to cover fixed costs.

### Sources

SBA, accessed September 29, 2026.

---

## M2 U04. Inventory and waste

**What you will be able to do:** Buy what sells, reduce what gets lost and avoid tying up money in merchandise.

**To start:** Don Ramón throws out meat and tortillas every week, and Daniela has boxes of a necklace style nobody buys. In this lesson you'll see what it costs them and how to reduce it.

### The essentials (5 minutes)

#### Inventory is money

Your inventory is money turned into products. If it doesn't sell, it's money sitting still; if it goes bad, it's money thrown away. What gets lost is called waste.



#### Three kinds of products

| Type | Description | What it means for you |
|---|---|---|
| Fast movers | Sell every day. | Never run out. |
| Slow movers | Sell now and then. | Buy a little. |
| Stuck | Don't sell. | Clear it out and don't rebuy. |
| Waste | Goes bad. | Measure and reduce it. |

#### How to reduce waste

1. For one week, write down what you throw out or don't sell.
2. Buy perishables more often and in smaller amounts.
3. First in, first out: use the oldest first.
4. Sell at a special price before it goes bad, if health rules allow it.



#### A case in one minute

Don Ramón wrote down his waste: $350 a month. He started buying meat twice a week in smaller amounts and prepping for his busy days. He cut waste to $120.

> **Key idea:** buy what moves, measure what you throw out and don't leave your money sitting still.



#### Check your understanding

1. Why is stuck inventory a problem?
*Answer:* It's money you can't use for anything else.

2. What is first in, first out?
*Answer:* Using or selling the oldest first so it doesn't go bad.


#### Remember

- Inventory = money.
- Measure your waste.
- Buy what moves.



### Go deeper (5 more minutes)

#### Your weekly waste

| Product | Amount lost | Cost |
|---|---|---|
| | | |
| **Total** | | |



#### Volume deals

"Buy 10 cases and get one at no cost" only pays off if you sell all 11 before they go bad or before you need that money.



#### Inventory and taxes

The cost of the merchandise you sell is subtracted on your return as cost of goods sold. Keep track of what you buy and what you have at the end of the year.



#### Cases


**Case 1. The deal for Don Ramón**

The supplier offers Don Ramón a no-cost case if he buys 10 of a product that sells slowly.
- *What does he do?* He buys only what he can sell before it expires, even if he loses the no-cost case.


**Case 2. Lupita's ingredients**

Lupita throws out chiles and husks every week.
- *What does she do?* She writes down what she throws out and buys less, more often.


**Case 3. Daniela's necklaces**

Daniela has 50 necklaces in a style that didn't sell.
- *What does she do?* She offers them at a discount to recover the money and doesn't rebuy that style.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Buying because of a deal | Money tied up | Buy what moves |
| Not measuring waste | You lose without knowing | Log one week |
| Keeping what doesn't sell | Takes space and money | Clear it out |
| No inventory records | Wrong tax return | Log purchases |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is waste? a) The volume discount your supplier gives you · b) What goes bad or can no longer be sold · c) New merchandise
2. You have 30 pieces that don't sell. What do you do? a) Offer them at a discount · b) Buy more to display · c) Keep them just in case
3. When does a "buy more" deal pay off? a) Always · b) If the supplier is trustworthy and gives you a good price · c) If you sell it all before it expires
**Answers:** 1-b: money thrown away. 2-a: money sitting still. 3-c: otherwise it's expensive.



#### Put it into practice

You buy 100 pieces at $2 and throw out 10. What does each piece you sell cost you?
**Answer:** $200 divided by 90: about $2.22.



#### Your plan

This week, write down what you throw out or don't sell and decide what to stop buying.



### Learn more

- **Cost of goods sold** (IRS · English): https://www.irs.gov | What to look for: "cost of goods sold".

### Key words

- *Inventory:* merchandise or supplies you bought and haven't sold yet.
- *Waste:* merchandise that spoils, breaks or gets lost and can no longer be sold.
- *Turnover:* how fast a product sells.

### Sources

IRS · SBA, accessed September 29, 2026.

---


# Part 4. Module 3. Cash flow

## M3 U01. Profit isn't cash

**What you will be able to do:** Understand cash flow and build a simple calendar of money in and out so you don't run short.

**To start:** Javier finished painting a house for a contractor for $4,500, but he'll be paid in 30 days. Meanwhile he has to pay for paint, gas and his quarterly tax payment. In this lesson you'll see why making a profit isn't the same as having money.

### The essentials (5 minutes)

#### What cash flow is

Cash flow is the money that really comes in and goes out, and **when**. You can have a profit on paper and not have cash to pay this week, because you get paid late or because you bought a lot at once.



#### What affects your cash flow

| Type | Description | What it means for you |
|---|---|---|
| Late payments | Net-30 invoices or customers who fall behind. | Money arrives later. |
| Big purchases | Materials or equipment. | A lot goes out at once. |
| Fixed payments | Insurance, permits, quarterly taxes. | They always come. |
| Deposits | You get paid before working. | Improves your cash flow. |

#### Your 4-week calendar

1. Write down how much money the business has today.
2. Write down, by week, what you expect to collect.
3. Write down, by week, what you have to pay (include quarterly taxes).
4. Add and subtract: if any week goes negative, act ahead of time.



#### A case in one minute

Javier's calendar showed he would be $700 short in week 3 because of his tax payment. He asked for a 30% deposit on the next job and arranged 30-day terms with the paint store.

> **Key idea:** look at your next four weeks: cash problems get solved ahead of time, not on the day money runs out.



#### Check your understanding

1. Why can you make a profit and have no cash?
*Answer:* Because you get paid later or pay before you collect.

2. What is the calendar for?
*Answer:* To see ahead of time the weeks when money will be short.


#### Remember

- Cash flow = when it comes in and goes out.
- 4-week calendar.
- Act before it runs out.



### Go deeper (5 more minutes)

#### Your calendar

| | Week 1 | Week 2 | Week 3 | Week 4 |
|---|---|---|---|---|
| Starting balance | | | | |
| + Expected payments | | | | |
| − Payments out | | | | |
| = Ending balance | | | | |



#### Deposits and terms

Ask for a deposit on big jobs, in writing. If a customer pays in 30 days, ask your supplier for similar terms. Check your state's rules on deposits: in California, for example, home improvement contracts limit the down payment.



#### Expensive credit to plug holes

If your calendar shows a gap, don't plug it with credit card cash advances, payday loans or advances on future sales (merchant cash advances): their cost eats your profit (M6).



#### Cases


**Case 1. Javier's late payment**

The contractor pays Javier in 30 days and he needs materials now.
- *What does he do?* He asks for a deposit and negotiates terms with his supplier.


**Case 2. Don Ramón's purchase**

Don Ramón wants to buy all the supplies for a festival at once, which would leave him without cash for two weeks.
- *What does he do?* He checks his calendar and buys in parts or on terms.


**Case 3. Daniela's advance**

Daniela is $300 short to pay her supplier and an app offers her an advance on future sales.
- *What does she do first?* She checks her reserve and asks the supplier for more time before using expensive credit.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Looking only at profit | You run out of cash | Look at cash flow |
| Not asking for deposits | You finance the customer | Written deposit |
| Forgetting quarterly taxes | Gap | Put them on the calendar |
| Plugging with expensive credit | You lose profit | Reserve and terms |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Don Ramón and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You have $600, will collect $900 and will pay $1,700 this week. How do you end? a) $200 left over · b) $3,200 · c) $200 short
2. What improves your cash flow? a) Paying suppliers early so they treat you better · b) Asking for deposits on big jobs · c) Giving customers more time
3. Your calendar shows a gap in three weeks. What do you do? a) Look for solutions starting today · b) Wait and see if it fixes itself · c) Get a quick advance the day it runs out
**Answers:** 1-c: $600 plus $900 minus $1,700. 2-b: you collect earlier. 3-a: act ahead of time.



#### Put it into practice

Starting balance $800. Week 1: you collect $1,200 and pay $1,500. Week 2: you collect $600 and pay $1,200. How do you end each week?
**Answer:** Week 1: $500. Week 2: $500 plus $600 minus $1,200: $100 short.



#### Your plan

Build your calendar for the next four weeks and mark the risky weeks.



### Learn more

- **Manage your finances** (SBA · English): https://www.sba.gov | What to look for: "manage your finances" and "cash flow".

### Key words

- *Cash flow:* the money that actually comes into and goes out of the business, and when.
- *Deposit:* part of the payment the customer makes before you do the work.

### Sources

SBA · Contractors State License Board (CSLB), accessed September 29, 2026.

---

## M3 U02. Customer credit, invoices and collections

**What you will be able to do:** Set rules for selling on credit, send clear invoices and collect respectfully and within the law.

**To start:** Lupita has $650 owed by customers who ordered food for parties and will "pay later." Javier has a $1,200 invoice that is 45 days late. In this lesson you'll see how to set rules and collect.

### The essentials (5 minutes)

#### Selling on credit is lending

When you deliver before you get paid, you lend your money no-interest. It can help you sell more, but if it grows without control, it leaves you without cash.



#### Clear rules

1. For big orders, ask for a deposit (for example, 50%).
2. Put the price, delivery date and payment date in writing.
3. Send an invoice the same day you deliver.
4. Keep a list of who owes you, how much and since when.
5. If someone doesn't pay, no more credit until they pay in full.



#### How to collect respectfully

| Type | Description | What it means for you |
|---|---|---|
| Remind them of the date | A friendly message before the day. | No pressure. |
| Resend the invoice | With the amount and date. | Clarity. |
| Accept partial payments | Something is better than nothing. | Log each payment. |
| Shaming or threatening | Never: it hurts your business and may be illegal. | No. |

#### A case in one minute

Lupita now asks for a 50% deposit on party orders and the rest at delivery. She no longer has balances older than a week.

> **Key idea:** selling on credit is lending; ask for a deposit, put everything in writing and invoice the same day.



#### Check your understanding

1. What do you put in writing for a big order?
*Answer:* Price, delivery date, deposit and payment date.

2. When do you send the invoice?
*Answer:* The same day you deliver.


#### Remember

- Deposit on big orders.
- Everything in writing.
- Invoice the same day.



### Go deeper (5 more minutes)

#### Who owes you

| Customer | Invoice date | Amount | Payments | Owes | Days late |
|---|---|---|---|---|---|
| | | | | | |



#### If they don't pay

First, remind them in writing. Then send a formal letter with a deadline. For small amounts, your county's small claims court is an option without a lawyer; in California the limit for individuals is $12,500 (check with the court). If you work in construction in California, look into a mechanics lien early: it has strict deadlines.



#### What not to do

Don't post debtors on social media, don't threaten them and don't contact their family or workplace. Besides hurting your business, it can get you into legal trouble.



#### Cases


**Case 1. Lupita's orders**

A customer orders 20 dozen for a wedding and promises to pay later.
- *What does she do?* She asks for a 50% deposit and puts the price and payment date in writing.


**Case 2. Javier's invoice**

A $1,200 invoice from Javier is 45 days late.
- *What does he do?* He reminds in writing, sends a letter with a deadline and considers small claims court.


**Case 3. Don Ramón's customer**

An office wants food from Don Ramón every Friday and to pay at the end of the month.
- *What does he do?* He agrees with a written arrangement, invoices each delivery and sets a limit.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| No deposit | You lose if they cancel | Ask for a deposit |
| Verbal agreements | Arguments | In writing |
| Invoicing late | You get paid late | Same day |
| Shaming debtors | Legal trouble | Collect respectfully |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is selling on credit for your business? a) A sale already collected · b) An no-interest loan to your customer · c) Extra profit
2. A customer hasn't paid and places another order. What do you do? a) Deliver so you don't lose them · b) Post their name on your social media to pressure them · c) No more credit until they pay
3. What do you ask for on a big order? a) A deposit and a written agreement · b) Only their phone number · c) Nothing: trust is enough
**Answers:** 1-b: money that hasn't come back. 2-c: clear rule. 3-a: it protects you.



#### Put it into practice

A $480 order with a 50% deposit. How much do you collect up front and how much at delivery?
**Answer:** $240 and $240.



#### Your plan

Write your customer credit rules and list who owes you today.



### Learn more

- **Small claims** (California Courts · English and Spanish): https://www.courts.ca.gov | What to look for: "small claims".

### Key words

- *Invoice:* a document with what you sold, the amount and the payment due date.
- *Small claims court:* a court for collecting small amounts without a lawyer.

### Sources

California Courts · SBA, accessed September 29, 2026.

---

## M3 U03. Your reserve and slow seasons

**What you will be able to do:** Build a business reserve and prepare for slow months, taxes and yearly expenses.

**To start:** Don Ramón's food truck sells a lot in summer and at fairs, but almost nothing in January and February. Last year he used his credit card to pay his insurance. In this lesson you'll see how to prepare.

### The essentials (5 minutes)

#### What the reserve is

The business reserve is the business's cushion: money to pay fixed costs and your salary when you sell less or something unexpected happens. It's different from your personal emergency fund and your tax account.



#### Don Ramón's reserve

- Monthly fixed costs (with his salary): **$6,000**
- Months of cushion: **2**
- Reserve goal: **$12,000**
Set aside a percentage of each sale in the good months until you reach the goal.


#### Where to keep it

| Type | Description | What it means for you |
|---|---|---|
| Separate savings account | Insured by the FDIC or NCUA. | Available. |
| High-yield savings account | Insured and earns more interest. | Check fees. |
| Cash at home or in the truck | Risk of theft or spending. | Avoid it. |
| Your credit card | Not a reserve: it's debt. | Avoid it. |

#### A case in one minute

Don Ramón sets aside 10% of each sale from May to October in a savings account. In January he pays his insurance and salary from the reserve, without using the card.

> **Key idea:** in good months, set money aside for slow ones; a reserve keeps you away from expensive debt.



#### Check your understanding

1. What is the reserve for?
*Answer:* To pay fixed costs and your salary in slow months or emergencies.

2. Is it the same as your tax account?
*Answer:* No: taxes are set aside in another account.


#### Remember

- Reserve = the business's cushion.
- Set aside a % of each sale.
- Separate from taxes.



### Go deeper (5 more minutes)

#### Your yearly business expenses

| Expense | Month | Amount | Set aside monthly |
|---|---|---|---|
| License and permits | | | |
| Insurance | | | |
| Annual LLC fee (if you have one) | | | |
| Maintenance or equipment | | | |



#### Your map of the year

Check last year's sales for each month. Mark the high and low months. Plan purchases and your reserve based on that map.



#### What isn't a reserve

Your household savings, inventory, money owed to you and your card limit are not a reserve.



#### Cases


**Case 1. Don Ramón's winter**

Don Ramón knows January and February are slow.
- *What does he do in summer?* He sets aside a percentage of each sale in a savings account.


**Case 2. Lupita's cash**

Lupita keeps her reserve in cash in her kitchen.
- *What does she do?* She moves it to an insured savings account.


**Case 3. Daniela's fee**

Daniela has an LLC and pays a yearly fee to the state.
- *What does she do starting in January?* She divides the amount by 12 and sets it aside each month.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| No reserve | Expensive debt | Set aside from each sale |
| Reserve in cash | Theft or spending | Insured account |
| Mixing it with taxes | Short in April | Separate accounts |
| Using the card as a reserve | Interest | A real reserve |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Fixed costs of $1,500 a month. Reserve for 3 months? a) $500 · b) $1,500 · c) $4,500
2. Where should you keep the reserve? a) In an insured savings account · b) In cash at home, where you always have it handy · c) In more inventory
3. Your insurance costs $1,200 a year. How much do you set aside monthly? a) $120 · b) $100 · c) $1,200
**Answers:** 1-c: $1,500 times 3. 2-a: protected and available. 3-b: $1,200 divided by 12.



#### Put it into practice

You sell $15,000 in July and set aside 10%. How much goes to the reserve?
**Answer:** $1,500.



#### Your plan

Set your reserve goal and the percentage of each sale you'll set aside starting this week.



### Learn more

- **Savings and deposit insurance** (FDIC · English): https://www.fdic.gov | What to look for: "deposit insurance".

### Key words

- *Business reserve:* money set aside to cover the business's fixed costs in slow months or emergencies.
- *Slow season:* months when your business sells less.

### Sources

FDIC · NCUA, accessed September 29, 2026.

---

## M3 U04. Inflation, interest rates and compound interest in your business

**What you will be able to do:** Understand how inflation raises your costs and erodes your cash, when and how to adjust prices, and how compound interest grows your reserve or your debt.

**To start:** Don Ramón has sold his burrito at the same price for a year, but meat, tortillas and gas went up. He sells the same amount and keeps less. In this lesson you'll see how to protect your margin.

### The essentials (5 minutes)

#### Inflation raises your costs

With inflation, your supplies, rent and gas go up. If your prices stay the same, your margin shrinks even if you sell the same amount.

> **Current fact:** the Federal Reserve's long-run inflation goal is 2% a year; the Bureau of Labor Statistics (BLS) publishes the Consumer Price Index (CPI) every month. Accessed September 30, 2026 through the Federal Reserve and the BLS.



#### Don Ramón's margin

Here's how the margin on one burrito changed.
- Sale price: **12**
- Cost after the increases (was 6.50): **8**
- Margin per item (was 5.50): **4**
He sells the same, but earns almost 30% less per item.


#### Review costs and prices every quarter

Every three months, compare your costs with last quarter. If they went up, recalculate your price (M2 U02) and your break-even point (M2 U03). Raise prices a little and tell your customers, instead of one big jump.



#### A case in one minute

Don Ramón reviewed his five best-selling dishes: four had higher costs. He raised prices a dollar, updated his menu board and recovered his margin without losing customers.

> **Key idea:** inflation raises your costs; review costs and prices every quarter and protect your margin.



#### Check your understanding

1. What happens to your margin if your costs rise and your prices don't?
*Answer:* It shrinks.

2. How often do you review costs and prices?
*Answer:* Every three months.


#### Remember

- Inflation raises your costs.
- Review every quarter.
- Small, announced changes.



### Go deeper (5 more minutes)

#### Your reserve loses value too

A business reserve kept in cash loses buying power with inflation. Keep it in an insured savings account that pays interest and is still available (M3 U03).



#### Rates and your loans

When the Federal Reserve raises its rate, card and loan rates usually go up. If your loan has a variable rate, your payment can change. Prefer a fixed rate or calculate the payment with a higher rate.



#### $10,000 at 10% a year, compounded

| Year | In your reserve | In a debt |
|---|---|---|
| 1 | $11,000 | you owe $11,000 |
| 3 | $13,310 | you owe $13,310 |
| 5 | $16,105 | you owe $16,105 |

> **Before you act, check:** last year's CPI at the BLS and whether your loan rate is fixed or variable.



#### Cases


**Case 1. Don Ramón's burrito**

The burrito's cost went from $6.50 to $8 and Don Ramón still sells it for $12.
- *What does he do?* He reviews his costs and raises the price a little, telling his customers.


**Case 2. Lupita's reserve**

Lupita has kept her business reserve in cash for two years.
- *What does she do?* She moves it to an insured savings account that pays interest and stays available.


**Case 3. Javier's credit line**

Javier is offered a variable-rate credit line for a van.
- *What does he do?* He calculates the payment with a higher rate or looks for a fixed rate.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Frozen prices | Margin slips away | Review every quarter |
| Reserve in cash | Loses value | Insured account |
| Variable rate without math | Payment rises | Calculate higher |
| Raising all at once | You lose customers | Small and announced |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Your costs rise and your price doesn't. What happens? a) Your margin shrinks · b) You earn more · c) Nothing, you sell the same
2. What happens to a reserve kept in cash for years? a) It grows on its own · b) It stays just as useful · c) It loses buying power
3. Your loan has a variable rate. What do you do? a) Nothing, rates always fall · b) Calculate the payment with a higher rate · c) Take another loan to cover it
**Answers:** 1-a: that's why you review prices. 2-c: inflation wears it down. 3-b: be ready in case it rises.



#### Put it into practice

A supply went from $40 to $46. By what percentage did it rise?
**Answer:** 15% (6 divided by 40).



#### Your plan

Write down the cost of your five best-selling items and check it again in three months.



### Learn more

- **Consumer Price Index** (BLS · English): https://www.bls.gov/cpi.
- **Monetary policy** (Federal Reserve · English): https://www.federalreserve.gov | What to look for: "inflation target".

### Key words

- *Inflation:* a general rise in prices over time.
- *Margin:* what you keep per item after its cost.
- *Variable rate:* an interest rate that can change during the loan.

### Sources

Federal Reserve · BLS, accessed September 30, 2026.

---


# Part 5. Module 4. Get paid and sell without losing

## M4 U01. Cash, card, apps or payment link

**What you will be able to do:** Compare ways to get paid by cost, speed, protection and security, and choose the ones that suit your business.

**To start:** Don Ramón's customers want to pay by card and with apps. He's offered a "at no cost" card reader, but he doesn't know what he'll be charged or when he'll get the deposits. In this lesson you'll see how to compare.

### The essentials (5 minutes)

#### Ways to get paid

| Type | Description | What it means for you |
|---|---|---|
| Cash | No fee. | Theft risk; also reportable income. |
| Payment apps (Zelle, business profiles in apps) | Fast; some charge for business accounts. | Little protection if there's fraud. |
| Card reader | You take cards. | Fee per payment. |
| Payment link or online invoice | You get paid remotely. | Fee; check chargebacks. |

> **Current fact:** payment processors commonly charge between 2.6% and 3.5% per card payment, plus a flat fee of a few cents per transaction; remote payments usually cost more than in-person ones. Accessed September 29, 2026 through processors' published rates.

#### What taking cards costs

- Card payments per month: **$8,000**
- Approximate fee: **2.9%**
- Monthly cost: **$232**
Add it to your variable costs; it's also a deductible business expense.


#### Before you sign up, ask

1. Fee per payment in person, remote and keyed in.
2. Monthly fee, device cost and minimum contract.
3. How many days until deposit and whether instant deposit costs extra.
4. What happens with chargebacks and how much each one costs.



#### A case in one minute

Don Ramón compared two options: one with no monthly fee at 2.6% plus 15 cents; another with $30 a month at 2.3%. With $8,000 a month and 800 payments, the first costs him about $328 and the second $214. He chose the second.

> **Key idea:** compare the total monthly cost with your real sales, not just the percentage.



#### Check your understanding

1. What do you ask before signing up for a card reader?
*Answer:* Fees, monthly charge, contract, deposit days and chargebacks.

2. Why are payment apps risky?
*Answer:* Because if you're paid from a stolen account or tricked, there's almost no protection.


#### Remember

- Compare total cost.
- Ask about deposits and chargebacks.
- Fees are a business cost.



### Go deeper (5 more minutes)

#### Compare your options

| Item | Option A | Option B | Option C |
|---|---|---|---|
| In-person fee | | | |
| Flat fee per payment | | | |
| Monthly charge | | | |
| Deposit days | | | |
| Total cost with your sales | | | |



#### Card surcharges

Some states limit or ban charging a fee for paying by card, and card networks have their own rules. The simplest thing is to include the cost in your price. If you want to offer a cash discount, check your state's rules.



#### Personal apps for business payments

Many payment apps prohibit using personal accounts for business payments and may close them. Use the business option or an account linked to your business account. Remember: everything you collect is income, however it arrives.



#### Cases


**Case 1. Don Ramón's reader**

Don Ramón is offered a "at no cost" reader with a two-year contract.
- *What does he do?* He calculates the total cost with his sales and reads the contract before signing.


**Case 2. Lupita's payments**

Lupita collects her orders in her personal payment app.
- *What does she do?* She uses the business option or an account linked to her business account.


**Case 3. Daniela's link**

Daniela wants to charge customers she doesn't know with a payment link.
- *What does she check?* Fee, deposit days and who pays if there's a chargeback.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Looking only at the percentage | Hidden cost | Total cost |
| Long contracts unread | Penalty | Read first |
| Personal apps for business | Account closed | Business option |
| Thinking apps aren't reportable | IRS problems | It's all income |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You take $5,000 a month in cards and the fee is 3%. How much do you pay? a) $150 · b) $500 · c) $15
2. Are payments through apps business income? a) No, if they're under $600 · b) Yes, however they arrive · c) Only if you receive a Form 1099-K
3. Option A: 2.6% with no monthly fee. Option B: 2.3% plus $30 a month. You take $4,000 in cards. Which is cheaper, not counting flat fees? a) A: $104 · b) B: $122 · c) They cost the same
**Answers:** 1-a: 3% of $5,000. 2-b: all income is reported. 3-a: $104 versus $92 plus $30.



#### Put it into practice

With option B (2.3% plus $30 a month), above what monthly sales is it cheaper than A (2.6% with no fee)?
**Answer:** When 0.3% of sales is more than $30: over $10,000 a month.



#### Your plan

Write down how much you take in cards each month and compare at least two options with your numbers.



### Learn more

- **Payment apps** (CFPB · English): https://www.consumerfinance.gov | What to look for: "payment apps".

### Key words

- *Payment processor:* a company that lets you take card payments and charges a fee.
- *Chargeback:* when the customer's bank reverses a card payment because it is disputed or not recognized.

### Sources

CFPB · processors' published rates, accessed September 29, 2026.

---

## M4 U02. Safe app and transfer payments

**What you will be able to do:** Get paid through apps and transfers by confirming each payment and protecting your account.

**To start:** Daniela ships orders when the customer sends a screenshot of the payment. Once the screenshot was fake and she lost an $80 necklace. In this lesson you'll see how to confirm every payment.

### The essentials (5 minutes)

#### A screenshot isn't proof

Payment apps and transfers arrive fast, but **the customer's screenshot is not proof of payment**: it can be faked or show a "pending" payment that never arrives.



#### Before you deliver, confirm

1. Open your app or bank and check that the money is **already available**.
2. Check amount, name and date.
3. Don't accept "I sent it, check your email": fake emails imitate the apps.
4. Only then deliver.



#### Protect your payment account

| Type | Description | What it means for you |
|---|---|---|
| Alerts | Notice for each payment received. | You confirm instantly. |
| Two-step verification | Password plus code. | Less account theft. |
| Share only your payment username or email | Never codes or passwords. | That's all you need to get paid. |
| Screenshot as proof | Easy to fake. | It isn't proof. |

#### A case in one minute

Daniela turned on alerts in her app and her bank. Now she ships only when she sees the payment available. Two customers with fake screenshots disappeared when she said she'd wait.

> **Key idea:** deliver only when the money is available in your account, not when you get a screenshot or an email.



#### Check your understanding

1. Why isn't a screenshot proof of payment?
*Answer:* Because it can be faked or show a payment that didn't go through.

2. What do you share to get paid?
*Answer:* Only your payment username, email or phone; never codes or passwords.


#### Remember

- Check your app before delivering.
- Alerts and two-step verification.
- Never share codes.



### Go deeper (5 more minutes)

#### The verification code

If someone asks for the code you got by text "to verify you're real" or "to send you the payment," it's a scam: with that code they get into your account or open one in your name.



#### Fake "pending payment" emails

Some emails imitate payment apps and say the payment is "on hold" until you pay for a "business account upgrade." Real apps don't work that way: always check inside the app.



#### If you send money by mistake

Person-to-person app payments are usually like cash: once sent, they're hard to get back. Double-check who you're paying, especially suppliers.



#### Cases


**Case 1. Daniela's screenshot**

A customer sends Daniela a screenshot and asks her to ship now.
- *What does she do?* She checks her app and ships only when the payment is available.


**Case 2. Lupita's email**

Lupita gets an email from "her payment app": a customer's payment is on hold until she pays $50.
- *What does she do?* She doesn't pay and checks inside the app; it's a scam.


**Case 3. Javier's code**

A supposed customer asks Javier for the code he received "to confirm his identity."
- *What does he do?* He doesn't share it: to pay him, they only need his payment username.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Accepting screenshots | You lose merchandise | Check your app |
| Sharing codes | Your account gets stolen | Never |
| Believing emails | You pay a scam | Check in the app |
| No alerts | You don't see payments | Turn them on |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Lupita and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. When do you deliver an order paid through an app? a) When they send you the screenshot · b) When the customer swears on the phone they already paid · c) When the money is available in your account
2. What do you share to get paid? a) Your payment username or email · b) Your password · c) The code you got by text
3. An email says your payment is on hold until you pay for an "upgrade." What is it? a) A normal app procedure · b) A scam: check inside the app · c) A bank fee
**Answers:** 1-c: a screenshot isn't proof. 2-a: that's enough to get paid. 3-b: apps don't charge that way.



#### Put it into practice

You get 10 app orders a day. If checking each one takes 30 seconds, how much time a day does confirming take?
**Answer:** 5 minutes a day.



#### Your plan

Turn on payment-received alerts and two-step verification in your app and your bank.



### Learn more

- **Payment app scams** (FTC · English and Spanish): https://consumer.ftc.gov | What to look for: "payment apps" and "scams".

### Key words

- *Two-step verification:* signing in with a password plus a code or approval on your phone.
- *Pending payment:* a payment that isn't available yet and may never arrive.

### Sources

FTC · CFPB, accessed September 29, 2026.

---

## M4 U03. Scams when you sell

**What you will be able to do:** Recognize the most common scams against sellers and have a plan so you don't fall for them.

**To start:** A customer sent Javier a $2,500 check for a $1,500 job and asked for $1,000 back by Zelle. Daniela got a big order with rush shipping to another state. In this lesson you'll see these and other scams.

### The essentials (5 minutes)

#### Common scams against sellers

| Type | Description | What it means for you |
|---|---|---|
| Overpayment check | They overpay and ask for the difference back. | The check bounces days later. |
| Fake screenshot | A payment that doesn't exist. | Check your app. |
| Stolen card | Big rush purchase to another address. | Chargeback. |
| Fake supplier | "We changed accounts, pay here." | Confirm another way. |

#### Your plan

1. Deliver only when the money is available in your account.
2. Never send back "extra" from a payment; if someone overpaid, cancel and have them pay the correct amount.
3. Wait until a check truly clears: "available" doesn't always mean it has been paid.
4. If a supplier changes accounts, call the number you already had.
5. Be wary of rush, big orders from strangers and shipping to another address.



#### A case in one minute

Javier didn't deposit the $2,500 check. He asked the customer for payment of the exact amount and the customer disappeared. His bank confirmed it was a known scam.

> **Key idea:** never send back money from an overpayment; rush, extra money and changed accounts are signs of a scam.



#### Check your understanding

1. What do you do if someone overpays and asks for the difference?
*Answer:* Send nothing back; ask for payment of the correct amount.

2. Does "available" in your account mean the check is good?
*Answer:* Not always: the bank can charge you back if it bounces days later.


#### Remember

- Never send back overpayments.
- Wait for the check to clear.
- Changed accounts: you call.



### Go deeper (5 more minutes)

#### Chargebacks

If you take a card and the cardholder doesn't recognize the purchase, their bank can refund them and your processor deducts it from you. Keep proof of delivery and avoid big shipments to strangers with remote payments.



#### If it already happened

Save screenshots, messages and numbers. Tell your bank or payment processor. Report it at ReportFraud.ftc.gov and, if you lost money online, at the FBI's IC3 (ic3.gov). Warn other businesses in the community, without personal data.

> **Before you act, check:** any change to a supplier's payment details by calling the number you already had, never the number or link in the same message.



#### Cases


**Case 1. Javier's check**

A customer sends Javier a $2,500 check for a $1,500 job and asks for $1,000 back.
- *What does he do?* He doesn't deposit it or send anything back; he asks for payment of the exact amount.


**Case 2. Daniela's order**

A stranger orders 40 necklaces from Daniela with rush shipping to another state and pays by link.
- *What does she do?* She is wary, verifies and doesn't ship without confirming.


**Case 3. Don Ramón's supplier**

An email "from his meat supplier" asks him to pay the invoice to a new account.
- *What does he do?* He calls the supplier's number he already had before paying.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Sending back overpayments | You lose money | Never |
| Trusting "available" | Check bounces | Wait |
| Rush shipping to strangers | Chargeback | Verify |
| Paying new accounts | Fake supplier | You call |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Daniela and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You're overpaid by check and asked for the difference. What do you do? a) Send the difference as soon as the check shows as available · b) Send nothing back and ask for the exact amount · c) Send back half
2. Your supplier writes that they changed accounts. What do you do? a) Pay the new account · b) Reply to the same email to confirm · c) Call the number you already had
3. What is a sign of a scam when selling? a) Rush, a big purchase and shipping to another address · b) A customer asking about sizes, colors and shipping times · c) A payment available for the exact amount
**Answers:** 1-b: it's the overpayment scam. 2-c: confirm another way. 3-a: rush is a hook.



#### Put it into practice

In one year, three scams cost you $80, $150 and $1,000. How much would your plan have saved?
**Answer:** $1,230.



#### Your plan

Write your anti-scam plan on a card and put it where you take payments.



### Learn more

- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov.
- **Internet crime** (FBI IC3 · English): https://www.ic3.gov | What to look for: "file a complaint".

### Key words

- *Overpayment scam:* a scam in which you're overpaid with a fake check and asked to send back the difference.
- *Supplier impersonation:* a scam in which someone poses as your supplier so you pay another account.

### Sources

FTC · FBI IC3, accessed September 29, 2026.

---


# Part 6. Module 5. Formalize and handle taxes without fear

## M5 U01. Sole proprietor, LLC or something else?

**What you will be able to do:** Learn the most common ways to set up a small business, what they protect and what they cost, so you can decide with information.

**To start:** Javier was told he "has to open an LLC" to work with contractors. A website charges $299 to do it. He doesn't know if he needs one. In this lesson you'll see the options.

### The essentials (5 minutes)

#### The most common forms

| Type | Description | What it means for you |
|---|---|---|
| Sole proprietor | You start when you sell; no company paperwork. | You are personally responsible. |
| LLC | A company registered in your state. | Separates your personal assets from business debts, if you run it properly. |
| Partnership | Two or more owners. | Written agreement. |
| Corporation | More paperwork and rules. | For larger businesses. |

#### The key question

An LLC can protect your home and savings if the business has debts or lawsuits, but it costs money every year and requires keeping everything separate. For many new businesses, being a sole proprietor with good insurance is enough at first.

> **Current fact:** in California, an LLC pays an $800 minimum annual tax to the Franchise Tax Board, even with no income, until it is formally dissolved; it also files a Statement of Information every two years with the Secretary of State. Accessed September 29, 2026 through the California Franchise Tax Board and Secretary of State.



#### A case in one minute

Javier did the math: an LLC would cost him at least $800 a year in California. He decided to start as a sole proprietor with liability insurance (M7 U02) and revisit the LLC when he grows. If he opens one, he'll do it on the state's official site, without paying $299 to a middleman.

> **Key idea:** an LLC protects, but it costs; compare it with your risk and your insurance, and do the paperwork on official sites.



#### Check your understanding

1. What does an LLC protect?
*Answer:* Your personal assets against business debts or lawsuits, if you run it properly.

2. What is the minimum yearly cost of an LLC in California?
*Answer:* The $800 minimum annual tax.


#### Remember

- Sole proprietor: simple, no separation.
- LLC: protects, but costs.
- Paperwork on official sites.



### Go deeper (5 more minutes)

#### Business name (DBA)

If as a sole proprietor you use a name different from your own ("Tamales Lupita"), in California you register a Fictitious Business Name (DBA) with your county. It isn't a company: it only registers the name.



#### For the LLC to protect you

Use a bank account only for the LLC, sign contracts in the LLC's name and don't mix money. If you mix, a judge may disregard the separation.



#### Watch out for middlemen

Many websites charge to form an LLC or get an EIN, things you can do yourself on official sites. Letters that imitate the government also arrive charging for "certificates" or "annual reports." Always check the sender.

> **Before you act, check:** your state's rules and costs on the Secretary of State's site; if you have questions, talk to an accountant or a no-cost SBA center (SBDC).



#### Cases


**Case 1. Javier's LLC**

A website charges Javier $299 to open a "required" LLC.
- *What does he do?* He compares costs and risks, and if he opens one, he uses the state's official site.


**Case 2. Lupita's name**

Lupita sells as "Tamales Lupita" and is a sole proprietor.
- *What does she do?* She registers her fictitious business name with her county.


**Case 3. Daniela's LLC account**

Daniela has an LLC, but takes payments in her personal account.
- *What does she do?* She opens an account just for the LLC and stops mixing.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Opening an LLC without doing the math | $800 every year | Compare |
| Paying middlemen | Unnecessary cost | Official site |
| Mixing money in the LLC | You lose protection | Separate account |
| Skipping the DBA | Trouble with banks | Register your name |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which business form starts without company paperwork? a) Sole proprietor · b) LLC · c) Corporation
2. Your California LLC had no sales this year. Does it pay the minimum tax? a) No, if it didn't sell · b) Only if it earned over $10,000 · c) Yes, $800 while it exists
3. What makes an LLC lose its protection? a) Having insurance · b) Mixing LLC money with yours · c) Having its own LLC account
**Answers:** 1-a: you start when you sell. 2-c: even with no sales. 3-b: the separation breaks.



#### Put it into practice

You keep an LLC in California for 3 years. What is the minimum you pay in annual tax?
**Answer:** $800 times 3: $2,400.



#### Your plan

Write down your business's current form and the risk that worries you; check your state's rules.



### Learn more

- **Choose a business structure** (SBA · English): https://www.sba.gov | What to look for: "business structure".
- **LLCs in California** (Secretary of State · English): https://bizfileonline.sos.ca.gov | What to look for: "LLC".

### Key words

- *LLC:* limited liability company: a company registered in a state that separates your personal assets from the business's debts.
- *Sole proprietor:* a person who owns a business in their own name, without creating a separate company.
- *DBA:* the fictitious business name you operate under.

### Sources

SBA · California Franchise Tax Board · California Secretary of State, accessed September 29, 2026.

---

## M5 U02. Numbers and permits: EIN, ITIN and licenses

**What you will be able to do:** Know which tax number to use, how to get a no-cost EIN and which licenses and permits your business may need.

**To start:** Lupita wants to sell tamales at a market and they ask for her "license, health permit and seller's permit." She doesn't know where to start or whether she can do it with her ITIN. In this lesson you'll see the most common numbers and permits.

### The essentials (5 minutes)

#### Your tax numbers

| Type | Description | What it means for you |
|---|---|---|
| SSN or ITIN | Your personal tax number. | The ITIN lets you file if you don't have an SSN. |
| EIN | Your business's number with the IRS. | At no cost on irs.gov. |
| Seller's permit (California) | To sell taxable products. | From the CDTFA, at no cost. |
| Sites that charge for an EIN | The process costs nothing. | Don't pay. |

#### The EIN

An EIN identifies your business. You need it if you have employees or certain kinds of LLC, and it's useful for opening accounts and giving to customers instead of your SSN. You get it no-cost on the IRS website; the person applying needs an SSN or ITIN.



#### Permits you may need

1. **Business license** from your city or county.
2. **Seller's permit** from the CDTFA if you sell products (M5 U05).
3. **Health permit** from the county if you sell food (for example, a Cottage Food Operation or a food truck permit).
4. **Professional license** if your trade requires one (for example, the CSLB for construction).

> **Current fact:** in California, construction or repair jobs over $1,000 in total (labor and materials), or that require a permit, need a Contractors State License Board (CSLB) license. Accessed September 29, 2026 through the CSLB (AB 2622, effective January 1, 2025).



#### A case in one minute

Lupita got her EIN no-cost at irs.gov with her ITIN, requested her seller's permit from the CDTFA at no cost and registered as a Cottage Food Operation with her county health department. Now she can sell at the market.

> **Key idea:** the EIN and the seller's permit cost nothing on official sites; check with your city and county which licenses your trade needs.



#### Check your understanding

1. How much does an EIN cost?
*Answer:* Nothing: it costs nothing at irs.gov.

2. What permit do you need in California to sell taxable products?
*Answer:* A seller's permit from the CDTFA.


#### Remember

- No-cost EIN at irs.gov.
- Seller's permit at no cost.
- Licenses by city and trade.



### Go deeper (5 more minutes)

#### The ITIN

The ITIN is an IRS number for people who must file taxes and can't get an SSN. With it you can report your business income and apply for an EIN. You apply with Form W-7, directly or through a Certifying Acceptance Agent (CAA). Filing your income builds a history that can help you with credit and other processes.



#### Your immigration status

This course does not give immigration advice. If you have questions about how your status affects your business, talk to an immigration attorney or an organization accredited by the Department of Justice. Beware of "notarios" who offer immigration services.



#### Find what your city requires

CalGold (calgold.ca.gov) shows the permits usually required in California by city and type of business. In other states, look for your state's small business office or your local SBDC.



#### Cases


**Case 1. Lupita's EIN**

A website charges Lupita $150 to get her EIN.
- *What does she do?* She gets it no-cost at irs.gov with her ITIN.


**Case 2. Javier's big job**

Javier is offered a $4,000 bathroom remodel.
- *What does he check?* That in California he needs a CSLB license for jobs over $1,000.


**Case 3. Don Ramón's notario**

A "notario" offers to fix Don Ramón's immigration papers and permits for $2,000.
- *What does he do?* He doesn't pay and looks for an attorney or accredited organization.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying for an EIN | Unnecessary cost | irs.gov |
| Selling without permits | Fines or shutdown | Check with your city |
| Big jobs without a license | Fines and no pay | Check the CSLB |
| Trusting "notarios" | Fraud | Attorney or accredited organization |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you get your EIN? a) From a private site that charges a fee · b) At no cost on irs.gov · c) At your bank
2. What is the ITIN for? a) Filing taxes if you can't get an SSN · b) Working as an employee · c) Voting
3. In California, when do you need a CSLB license? a) Never for small painting or repair jobs · b) Only if you have full-time employees · c) For jobs over $1,000 or that require a permit
**Answers:** 1-b: it costs nothing. 2-a: IRS tax number. 3-c: rule in effect since 2025.



#### Put it into practice

A website charges you $150 for the EIN and $100 for the seller's permit. How much do you save by doing it yourself?
**Answer:** $250.



#### Your plan

Look up in CalGold (or your state's office) which licenses your type of business needs in your city.



### Learn more

- **Apply for an EIN** (IRS · English and Spanish): https://www.irs.gov | What to look for: "employer identification number".
- **ITIN** (IRS · English and Spanish): https://www.irs.gov | What to look for: "ITIN Form W-7".
- **Permits in California** (CalGold · English): https://www.calgold.ca.gov | What to look for: your city and type of business.

### Key words

- *EIN:* employer identification number: your business costs nothing number with the IRS.
- *ITIN:* individual taxpayer identification number, for people who can't get an SSN.
- *Seller's permit:* a California permit to sell products and collect sales tax.

### Sources

IRS · CDTFA · CSLB · CalGold, accessed September 29, 2026.

---

## M5 U03. Your federal taxes as an owner

**What you will be able to do:** Understand the two federal taxes a sole proprietor pays, which expenses are deductible and how much to set aside.

**To start:** Daniela made $14,000 in profit in her first year selling jewelry. In April she found out she owed the IRS more than $2,000 and hadn't set anything aside. In this lesson you'll see why and how to prepare.

### The essentials (5 minutes)

#### Two taxes on your profit

| Type | Description | What it means for you |
|---|---|---|
| Self-employment tax | Social Security and Medicare. | 15.3% of almost all your profit. |
| Income tax | Based on your total income and family. | Can be 0% or more. |
| Business deductions | Ordinary and necessary expenses. | They lower your profit. |
| 20% deduction (QBI) | On business profit, with limits. | Lowers your income tax. |

> **Current fact:** self-employment tax is 15.3% (12.4% Social Security and 2.9% Medicare) on 92.35% of your net profit; you pay it if you earn $400 or more. The Social Security portion applies up to $184,500 in 2026. The 20% qualified business income (QBI) deduction became permanent starting in 2026. Accessed September 29, 2026 through the IRS and the One Big Beautiful Bill Act.

#### Daniela's self-employment tax

- Net profit for the year: **$14,000**
- Tax base: **92.35%**
- Rate: **15.3%**
- Self-employment tax (approx.): **$1,978**
Depending on her total income, she may also owe income tax.


#### A case in one minute

Daniela didn't know that as an owner she pays the full Social Security and Medicare. This year she sets aside 25% of each profit in a separate account and keeps her receipts to deduct materials, shipping and fees.

> **Key idea:** as an owner you pay 15.3% for Social Security and Medicare, plus income tax; set aside 25% to 30% of your profit and deduct your expenses with receipts.



#### Check your understanding

1. What two federal taxes does a sole proprietor pay on profit?
*Answer:* Self-employment tax and income tax.

2. From what profit do you pay self-employment tax?
*Answer:* From $400 of net profit a year.


#### Remember

- 15.3% self-employment tax.
- Plus income tax.
- Deductions with receipts.



### Go deeper (5 more minutes)

#### Commonly deducted expenses

| Expense | What you need |
|---|---|
| Materials, ingredients, merchandise | Receipts |
| App and card fees | Statements |
| Business miles (standard rate) | Mileage log |
| Part of your phone and internet | Estimate of business use |
| Home office (space used only for business) | Measurements and IRS rules |
| Business insurance, licenses, permits | Receipts |



#### Schedule C

As a sole proprietor, you report sales and expenses on Schedule C of your return (Form 1040) and figure self-employment tax on Schedule SE. Half of the self-employment tax is subtracted from your income.



#### No-cost or low-cost help

VITA programs help people with moderate incomes at no cost, although not all of them handle businesses with complex expenses. As your business grows, an accountant or a preparer with a PTIN saves you mistakes. Your state (in California, the Franchise Tax Board) also charges income tax.

> **Before you act, check:** your situation with a tax preparer; the rules change every year and depend on your family and other income.



#### Cases


**Case 1. Daniela's surprise**

Daniela owes the IRS more than $2,000 and didn't set anything aside.
- *What does she do from today on?* She sets aside 25% of each profit and keeps receipts to deduct.


**Case 2. Javier's receipts**

Javier doesn't keep his paint receipts because "the IRS doesn't ask for them."
- *What does he do?* He keeps them: without receipts he can't prove his deductions.


**Case 3. Lupita's small profit**

Lupita made $3,000 in profit for the year and thinks she doesn't have to file.
- *What does she check?* That with $400 or more of profit she must file and pay self-employment tax.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not setting aside | IRS debt | 25% to 30% |
| No receipts | You lose deductions | Keep them |
| Thinking small profits aren't reported | Penalties | From $400 |
| Forgetting state tax | Double surprise | Check your state |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Javier and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is the self-employment tax rate? a) 15.3% · b) 7.65% · c) 2.5%
2. You made $350 in business profit this year. Do you pay self-employment tax? a) Yes, always, even if you earn little · b) Yes, if you sold through apps · c) No, because it's under $400
3. What do you need to deduct an expense? a) To remember it · b) That it's for the business and you have proof · c) That it's over $600
**Answers:** 1-a: Social Security and Medicare. 2-c: the minimum is $400. 3-b: ordinary, necessary and with proof.



#### Put it into practice

Your net profit is $20,000. About how much is your self-employment tax?
**Answer:** $20,000 times 92.35% times 15.3%: about $2,826.



#### Your plan

Open an account for taxes and decide what percentage of each profit you'll set aside.



### Learn more

- **Self-employment tax** (IRS · English and Spanish): https://www.irs.gov | What to look for: "self-employment tax".
- **No-cost VITA help** (IRS · English and Spanish): https://www.irs.gov | What to look for: "VITA".

### Key words

- *Self-employment tax:* Social Security and Medicare paid by people who work for themselves.
- *Deduction:* an expense subtracted from your income to figure your taxes.
- *QBI:* a deduction of up to 20% on a business's qualified profit.

### Sources

IRS · One Big Beautiful Bill Act (2025), accessed September 29, 2026.

---

## M5 U04. Quarterly payments and 1099 forms

**What you will be able to do:** Know the estimated tax dates, the 1099 forms you may receive or send and how to protect yourself from fake "IRS" scams.

**To start:** Javier got a 1099 form from a contractor and didn't know what it was. He also got a call "from the IRS" saying he'd be arrested if he didn't pay with gift cards. In this lesson you'll see your calendar and how to protect yourself.

### The essentials (5 minutes)

#### Estimated payments

Since nobody withholds taxes for you, the IRS expects you to pay during the year with estimated payments if you expect to owe $1,000 or more. If you don't, you may pay penalties.

> **Current fact:** the estimated tax due dates for tax year 2026 are April 15, June 15 and September 15, 2026, and January 15, 2027. Accessed September 29, 2026 through the IRS (Form 1040-ES).



#### The 1099 forms

| Type | Description | What it means for you |
|---|---|---|
| 1099-NEC | A business paid you for services. | From $2,000 for 2026 payments. |
| 1099-K | A platform or processor reports your payments. | Over $20,000 and over 200 transactions. |
| All income is reported | Whether or not you get a 1099. | Always. |
| "No 1099, no reporting" | Common mistake. | Not true. |

> **Current fact:** starting with 2026 payments, Form 1099-NEC is sent when a business pays you $2,000 or more in the year (previously $600). Form 1099-K is sent by platforms and processors when your payments exceed $20,000 and 200 transactions. All income is reported even if you don't receive a form. Accessed September 29, 2026 through the IRS and the One Big Beautiful Bill Act.

#### A case in one minute

Javier understood that the 1099-NEC only reports what he already earned. Now he pays every quarter with IRS Direct Pay using what he sets aside. The "IRS" call was a scam: the IRS doesn't call to demand gift cards.

> **Key idea:** pay your taxes every quarter and report all your income; the IRS never demands gift cards or threatens arrest by phone.



#### Check your understanding

1. When should you make estimated payments?
*Answer:* If you expect to owe the IRS $1,000 or more for the year.

2. Do you report income if you didn't get a 1099?
*Answer:* Yes: all income is reported.


#### Remember

- April, June, September and January.
- All income is reported.
- The IRS doesn't ask for gift cards.



### Go deeper (5 more minutes)

#### How much to pay each quarter

A practical approach: take what you set aside (25% to 30% of the quarter's profit) and pay it through IRS Direct Pay or your IRS online account. Your tax preparer can calculate it more precisely with Form 1040-ES. In California, the FTB also expects estimated payments of state tax.



#### Fake "IRS" scams

The IRS usually contacts you first by mail. It doesn't call to demand immediate payment, doesn't ask for gift cards, crypto or transfers to people, and doesn't threaten you with police. If in doubt, go to irs.gov yourself or call the official number.



#### Your Identity Protection PIN

The IRS offers an Identity Protection PIN (IP PIN) to stop someone from filing a return with your SSN or ITIN. Request it at irs.gov.



#### Cases


**Case 1. Javier's 1099**

Javier received a $6,000 1099-NEC from a contractor.
- *What does he do?* He includes it on his return with the rest of his income.


**Case 2. Don Ramón's call**

A call "from the IRS" demands that Don Ramón pay today with gift cards.
- *What does he do?* He hangs up and checks his account at irs.gov; it's a scam.


**Case 3. Daniela's sales**

Daniela sold $9,000 on a platform and didn't receive a 1099-K.
- *What does she do?* She reports those sales: all income is reported.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not paying quarterly | Penalties | Pay every quarter |
| Waiting for the 1099 | You don't report income | Report everything |
| Paying with gift cards | Scam | Never |
| Answering "IRS" calls | Theft | Go to irs.gov yourself |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Don Ramón and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which is a 2026 estimated payment date? a) June 15 · b) December 31 · c) March 1
2. You didn't get a 1099-K for your platform sales. What do you do? a) Don't report those sales · b) Report only if you sold more than $600 · c) Report them anyway
3. Someone calls "from the IRS" to be paid today with gift cards. What is it? a) A scam · b) A real urgent collection · c) A new IRS method for small payments
**Answers:** 1-a: second estimated payment. 2-c: all income is reported. 3-a: the IRS doesn't collect that way.



#### Put it into practice

Your profit for the quarter was $5,000 and you set aside 25%. How much is your estimated payment?
**Answer:** $1,250.



#### Your plan

Put the four estimated payment dates on your calendar and request your IP PIN at irs.gov.



### Learn more

- **Estimated taxes** (IRS · English and Spanish): https://www.irs.gov | What to look for: "estimated taxes 1040-ES".
- **Tax scams** (IRS · English and Spanish): https://www.irs.gov | What to look for: "scams".

### Key words

- *Estimated payments:* tax payments you make each quarter on what you're earning.
- *1099-NEC:* a form that reports payments for services to independent workers.
- *1099-K:* a form that reports payments through platforms and payment processors.
- *IP PIN:* an IRS number that protects your return from identity theft.

### Sources

IRS · One Big Beautiful Bill Act (2025), accessed September 29, 2026.

---

## M5 U05. Sales tax

**What you will be able to do:** Know which sales carry sales tax, how it's collected and how it's sent to the state.

**To start:** Lupita sells food at a market and at parties. Someone told her she has to charge sales tax; someone else told her food doesn't have it. In this lesson you'll see how it works, using California as the example.

### The essentials (5 minutes)

#### The tax isn't yours

Sales tax is collected from your customer and sent to the state. It's not part of your profit: set it aside as soon as you collect it. Each state has its own rules; some have no sales tax.

> **Current fact:** in California, the base statewide sales tax rate is 7.25%, and many cities and counties add local rates. Selling taxable products requires a seller's permit from the CDTFA, which costs nothing. Accessed September 29, 2026 through the CDTFA.



#### Is it taxable? (California, in general)

| Type | Description | What it means for you |
|---|---|---|
| Products: clothing, jewelry, goods | Yes, in general. | Seller's permit. |
| Hot food or food eaten on site | Yes, in general. | Special rules. |
| Cold food to go | Often not. | Check your case. |
| Many services (painting, cleaning) | Generally not. | Check materials. |

#### Tax on one of Daniela's sales

- Price of a necklace: **$50**
- Total rate in her city (example): **9.25%**
- Tax she collects and sends to the state: **$4.63**


#### A case in one minute

Lupita checked with the CDTFA: her hot food at the market is taxable; cold tamales to go generally aren't. Now she sets the tax she collects aside in her tax account and files her return when the CDTFA tells her.

> **Key idea:** sales tax belongs to the state, not you; find out which sales are taxable, charge it separately and set it aside.



#### Check your understanding

1. Whose is the sales tax you collect?
*Answer:* The state's; you collect it and send it in.

2. What do you need in California to sell taxable products?
*Answer:* A seller's permit from the CDTFA.


#### Remember

- It belongs to the state.
- Depends on the product and the state.
- Set it aside when you collect.



### Go deeper (5 more minutes)

#### If you sell on platforms

In most states, large online marketplaces collect and send sales tax for you on sales made through them (they're called "marketplace facilitators"). Your direct sales through your own site or social media are still your responsibility.



#### Sales tax returns

The CDTFA assigns you a filing frequency (yearly, quarterly or monthly) based on how much you sell. File even if you had no sales in the period, if they tell you to.



#### Fairs and events

If you sell at fairs or temporary events, you may need a temporary permit or to report sales for the event location. Ask the organizer and the CDTFA.

> **Before you act, check:** which products are taxable and your city's rate on the CDTFA's site (or your state's); food rules are special.



#### Cases


**Case 1. Lupita's food**

Lupita doesn't know whether her food is taxable.
- *What does she do?* She checks with the CDTFA which sales are taxable and sets the tax aside when she collects.


**Case 2. Daniela's online store**

Daniela sells on a large platform and on her own site.
- *What does she check?* That the platform collects tax on its sales, but she must collect it on her own site.


**Case 3. Javier's services**

Javier thinks he must charge sales tax for painting.
- *What does he check?* That many services aren't taxable, and he checks his case with the CDTFA.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking the tax is yours | You spend it | Set it aside |
| Applying it to everything | High prices | Check your product |
| Forgetting direct sales | Debt with the state | Collect it |
| Not filing | Penalties | By your frequency |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Daniela and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is California's base statewide sales tax rate? a) 16% · b) 0% · c) 7.25%
2. You sell $1,000 in products at a 9% rate. How much tax do you collect? a) $90 · b) $9 · c) $900
3. What do you do with the sales tax you collect? a) Use it to buy materials · b) Set it aside and send it to the state · c) Keep it as a business reserve
**Answers:** 1-c: plus local rates. 2-a: 9% of $1,000. 3-b: it belongs to the state.



#### Put it into practice

You sell $2,400 in the quarter at a 9.5% rate. How much tax do you owe?
**Answer:** $228.



#### Your plan

Check whether your sales are taxable in your state and, if so, get your permit.



### Learn more

- **Seller's permit and rates** (CDTFA · English and Spanish): https://www.cdtfa.ca.gov | What to look for: "seller's permit" and "tax rates".

### Key words

- *Sales tax:* a tax you collect from your customer and send to the state.
- *Marketplace facilitator:* a platform that collects and sends sales tax for the sellers on it.

### Sources

CDTFA, accessed September 29, 2026.

---


# Part 7. Module 6. Credit for your business

## M6 U01. Do you need credit?

**What you will be able to do:** Tell apart credit that helps you grow from credit that only plugs holes, and decide with numbers whether it's worth it.

**To start:** Don Ramón is offered $15,000 to buy a second set of kitchen equipment and open longer hours. He's excited, but doesn't know whether the food truck can pay it back. In this lesson you'll see how to decide.

### The essentials (5 minutes)

#### What you borrow for

| Type | Description | What it means for you |
|---|---|---|
| To grow | Equipment or merchandise that brings sales. | It can pay for itself. |
| For working capital | Seasons or big orders. | If you already have the customer. |
| To cover losses | The business isn't making money. | It makes the problem bigger. |
| For household expenses | With business credit. | Mixing. |

#### The key question

How much more will you earn with what you buy on credit? If the extra monthly profit is **greater** than the monthly payment, the credit can pay for itself. If not, you'll pay it from your salary or reserve.



#### Don Ramón's equipment

- Expected extra monthly profit: **$700**
- Monthly loan payment: **$480**
- What he keeps: **$220**
If extra sales were half as much, he'd be $130 short each month.


#### A case in one minute

Don Ramón ran the numbers with a cautious scenario: only half the expected sales. He'd be $130 short a month. He decided to borrow $8,000 for smaller equipment, with a $260 payment.

> **Key idea:** borrow for something that brings in sales and run the numbers with a cautious scenario.



#### Check your understanding

1. When can a loan pay for itself?
*Answer:* When the extra profit it brings is greater than the monthly payment.

2. Why not borrow to cover losses?
*Answer:* Because the business isn't making money and the debt makes the problem bigger.


#### Remember

- Credit to grow, not to plug holes.
- Extra profit greater than the payment.
- Cautious scenario.



### Go deeper (5 more minutes)

#### Decide with numbers

| Item | Expected scenario | Cautious scenario (half) |
|---|---|---|
| Extra monthly sales | | |
| Extra monthly profit | | |
| Monthly payment | | |
| Difference | | |



#### Before borrowing, check alternatives

Customer deposits, supplier terms, selling stuck inventory or using part of your reserve can solve it without credit. If the problem is price or costs (M2), credit won't fix it.



#### Cases


**Case 1. Don Ramón's equipment**

Don Ramón figures the loan pays for itself, but with optimistic sales.
- *What does he do?* He checks a cautious scenario before signing.


**Case 2. Lupita's losses**

Lupita has been losing money for three months and is offered a loan.
- *What does she do?* She fixes price and costs first; she doesn't use credit to cover losses.


**Case 3. Javier's contract**

Javier has a signed contract and needs materials to complete it.
- *What does he check first?* Whether he can ask the customer for a deposit before borrowing.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Credit to cover losses | Bigger debt | Fix the business |
| Optimistic math | It doesn't add up | Cautious scenario |
| Borrowing too much | High payments | Only what you need |
| Not checking alternatives | Unnecessary interest | Deposits and terms |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Extra profit is $300 a month and the payment is $400. What happens? a) The loan pays for itself · b) You're $100 short each month · c) You earn $100
2. What is business credit healthiest for? a) Paying household bills this month · b) Covering the losses of the last few months · c) Something that brings in sales
3. What do you do before borrowing for an order? a) Check whether the customer can pay a deposit · b) Ask for the maximum amount · c) Quickly sign the first offer so you don't lose the day's deal
**Answers:** 1-b: payment higher than profit. 2-c: it can pay for itself. 3-a: an no-interest alternative.



#### Put it into practice

Equipment would bring $600 a month in extra profit. In a cautious scenario, half that. The payment is $250. Is it worth it?
**Answer:** Cautious: $300 minus $250: you keep $50. It's worth it, with a small margin.



#### Your plan

If you're thinking of borrowing, fill in the table with an expected and a cautious scenario.



### Learn more

- **Business loans** (SBA · English): https://www.sba.gov | What to look for: "loans".

### Key words

- *Working capital:* money to run day to day: merchandise, supplies and payments.
- *Cautious scenario:* a calculation with lower sales than expected.

### Sources

SBA, accessed September 29, 2026.

---

## M6 U02. Credit options and how to check them

**What you will be able to do:** Learn the credit options for small businesses, including ones that accept an ITIN, and spot expensive or fake loans.

**To start:** Lupita got a message: "Business loan with no credit check. Deposit a $200 opening fee and get $5,000 today." In this lesson you'll see the real options and how to spot scams.

### The essentials (5 minutes)

#### Options you can look at

| Type | Description | What it means for you |
|---|---|---|
| Banks and credit unions | Loans and lines of credit. | They ask for history. |
| CDFIs and nonprofit microlenders | Small loans; some accept an ITIN. | With coaching. |
| SBA microloans | Through intermediaries; all owners must be citizens. | Up to $50,000. |
| Merchant cash advances (MCA) | Daily payments; very expensive. | Avoid them. |

> **Current fact:** the SBA microloan program offers loans of up to $50,000 through nonprofit intermediary organizations, which often also provide coaching. Since April 1, 2026, all business owners must be U.S. citizens or nationals; people with an ITIN, green card or visa can look for CDFIs that lend their own funds. Accessed September 30, 2026 through the SBA (policy notice 5000-877232).

#### Check before you apply

1. Look up the lender's exact name and official website.
2. In California, check its license with the DFPI; in other states, with the state financial regulator.
3. Ask for the total cost in writing (M6 U03).
4. Never pay up front to "release" a loan.



#### A case in one minute

Lupita deleted the message: asking for an up-front fee is a sign of a scam. She found a CDFI in her area that works with ITINs; it offered her a $3,000 microloan with no-cost business classes.

> **Key idea:** compare banks, credit unions and CDFIs; anyone who asks for money up front to give you a loan is a scammer.



#### Check your understanding

1. What are CDFIs?
*Answer:* Community development financial institutions that lend to small businesses, sometimes with an ITIN.

2. What do you do if you're asked for a fee to release a loan?
*Answer:* Don't pay: it's a scam.


#### Remember

- Banks, credit unions, CDFIs, SBA.
- Check the license.
- Never pay up front.



### Go deeper (5 more minutes)

#### Merchant cash advances and payday loans

A merchant cash advance gives you money in exchange for a percentage of your daily sales. It isn't presented as a loan or with an APR, and its cost can be extremely high. Payday loans are also very expensive. Avoid them or compare very carefully.



#### Credit with an ITIN

Some banks, credit unions and CDFIs offer accounts, secured cards and loans with an ITIN. Filing your taxes and keeping an orderly business account help you prove your income.



#### What they'll ask for

ID, tax returns, business account statements, licenses and sometimes a business plan. That's why separating your money (M1) and filing (M5) open better options.

> **Before you act, check:** the lender's license with your state regulator (in California, the DFPI) and compare the total cost in writing.



#### Cases


**Case 1. The message to Lupita**

A message offers Lupita $5,000 if she deposits a $200 opening fee.
- *What does she do?* She doesn't deposit and looks for verified options; it's a scam.


**Case 2. Don Ramón's advance**

A company offers Don Ramón $10,000 in exchange for 15% of his daily sales.
- *What does he do?* He figures out the total cost and compares it with a bank, credit union or CDFI loan.


**Case 3. Daniela's loan**

Daniela has an ITIN and thinks nobody will lend to her.
- *What does she do?* She looks for credit unions and CDFIs that work with ITINs.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying to "release" | Scam | Never |
| Not checking the license | Illegal lender | State regulator |
| Taking merchant advances | Extremely high cost | Compare |
| Thinking an ITIN means no options | You miss healthy credit | Look for CDFIs |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Don Ramón and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You're asked for a fee to release your loan. What is it? a) A normal procedure · b) A legally required opening fee · c) A sign of a scam
2. Where do you check a lender in California? a) With the DFPI · b) On its social media · c) In its app reviews
3. Up to how much do SBA microloans lend? a) $5,000 · b) $50,000 · c) No limit
**Answers:** 1-c: never pay up front. 2-a: the state regulator. 3-b: through intermediaries.



#### Put it into practice

An advance gives you $10,000 and charges you $13,500 in 6 months. How much extra do you pay?
**Answer:** $3,500 in just 6 months.



#### Your plan

Look for a credit union or CDFI in your area and ask what they offer small businesses.



### Learn more

- **Microloans** (SBA · English): https://www.sba.gov | What to look for: "microloans".
- **Check a license** (DFPI · English): https://dfpi.ca.gov | What to look for: "search licensees".
- **CDFIs** (CDFI Fund · English): https://www.cdfifund.gov | What to look for: "CDFI locator".

### Key words

- *CDFI:* a community development financial institution that lends to people and businesses with less access.
- *Merchant cash advance (MCA):* money in exchange for a percentage of your future sales; very expensive.
- *Credit union:* a nonprofit financial institution owned by its members.

### Sources

SBA · DFPI · CDFI Fund, accessed September 29, 2026.

---

## M6 U03. The total cost: APR, fees and guarantees

**What you will be able to do:** Compare credit by its total cost, understand APR and "factor rate," and review the guarantees.

**To start:** Don Ramón is offered two options for $10,000: a 12-month credit union loan at 14% APR, and an advance with a "factor of 1.35." They sound similar, but they're not. In this lesson you'll see how to compare them.

### The essentials (5 minutes)

#### APR

The APR sums up the yearly cost of credit with interest and certain fees. It's for comparing credit: **lower APR, cheaper.** If someone won't give you the APR, ask for the total you'll repay.



#### What you actually pay

- Advance received: **$10,000**
- Factor rate: **1.35**
- Total to repay in 6 months: **$13,500**
The credit union loan, at 14% APR over 12 months, costs about $775 in total interest.


#### Compare with these questions

1. What is the APR?
2. How much will I pay in total?
3. What fees are there: origination, late payment, prepayment?
4. What guarantee do they ask for: personal guarantee, equipment, home?
5. Can I pay early without a penalty?



#### A case in one minute

Don Ramón asked for everything in writing. The advance would cost him $3,500 in six months; the credit union, about $775 in a year. He chose the credit union even though approval took two weeks longer.

> **Key idea:** compare APR and total repayment, not the daily payment or how fast you get the money.



#### Check your understanding

1. What is APR?
*Answer:* The yearly cost of credit with interest and certain fees.

2. What do you do if they won't give you the APR?
*Answer:* Ask for the total repayment in writing and compare.


#### Remember

- Lower APR, cheaper.
- Total repayment.
- Ask about fees and guarantees.



### Go deeper (5 more minutes)

#### Compare two offers

| Item | Offer A | Offer B |
|---|---|---|
| Amount | | |
| Term | | |
| Payment (monthly, weekly or daily) | | |
| Total repayment | | |
| APR | | |
| Fees | | |
| Guarantee | | |



#### Guarantees

Many business loans require your personal guarantee: if the business doesn't pay, you do, even if you have an LLC. Some ask for property as collateral. Don't put your home up as collateral for a business that hasn't proven it makes money.



#### California disclosure

California requires many commercial lenders to disclose the estimated cost in writing, including an APR, on loans and advances of up to $500,000. Ask for it.



#### Cases


**Case 1. Don Ramón's two offers**

Don Ramón compares a loan at 14% APR with an advance at a 1.35 factor.
- *What does he do?* He asks for each one's total repayment in writing and compares them.


**Case 2. Javier's guarantee**

A loan for a truck asks Javier to put his home up as collateral.
- *What does he do?* He looks for another option or a smaller amount without risking his home.


**Case 3. Daniela's extra payment**

Daniela had a good month and wants to pay ahead on her loan.
- *What does she ask?* Whether there's a penalty and that the payment goes to principal.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Comparing the daily payment | Misleading | APR and total |
| Choosing the fastest | High cost | Compare |
| Home as collateral | Risk of losing it | Avoid it |
| Not reading the personal guarantee | You pay | Read first |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Javier and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Two offers with the same amount and term: 12% APR and 30% APR. Which is cheaper? a) The 12% one · b) The 30% one · c) They cost the same
2. A $5,000 advance with a 1.4 factor. How much do you repay in total? a) $5,400 · b) $1,400 · c) $7,000
3. What is a personal guarantee? a) The loan isn't collected if the business closes · b) You pay if the business doesn't · c) No-cost insurance
**Answers:** 1-a: lower APR. 2-c: $5,000 times 1.4. 3-b: you answer with your assets.



#### Put it into practice

You borrow $6,000 and will pay $290 for 24 months. How much extra do you pay?
**Answer:** $6,960 minus $6,000: $960.



#### Your plan

If you have a credit offer, ask for the APR and total repayment in writing and fill in the table.



### Learn more

- **Small business lending** (CFPB · English): https://www.consumerfinance.gov | What to look for: "small business lending".
- **Commercial financing disclosures** (DFPI · English): https://dfpi.ca.gov | What to look for: "commercial financing disclosures".

### Key words

- *APR:* annual percentage rate: the yearly cost of credit, with interest and certain fees.
- *Factor rate:* the number you multiply an advance by to get the total repayment.
- *Personal guarantee:* a promise that you'll pay if the business doesn't.

### Sources

CFPB · DFPI, accessed September 29, 2026.

---

## M6 U04. Don't mix debts, and be careful about cosigning

**What you will be able to do:** Avoid using personal debt for the business, lend to family with rules and understand the risk of cosigning.

**To start:** Daniela pays for her materials with her personal credit card and already owes $4,500. And Don Ramón's nephew asks him to cosign a car loan. In this lesson you'll see the risks.

### The essentials (5 minutes)

#### Dangerous mixes

| Type | Description | What it means for you |
|---|---|---|
| Personal card for the business | High interest if you don't pay in full. | Hidden debt. |
| Loans to family | Without rules, they don't come back. | Business money. |
| Cosigning | If they don't pay, you do. | Hurts your credit. |
| Separate, recorded debts | You know what the business owes. | Control. |

#### The personal card

Using your card for the business can work if you pay in full each month (no interest) and keep receipts. If you only pay the minimum, the debt grows at more than 20% interest a year and mixes with your personal spending.



#### Cosigning

A cosigner is responsible for the debt if the borrower doesn't pay. It shows up on your credit report. **Only sign for a debt you could pay yourself without putting your business at risk.**



#### A case in one minute

Don Ramón figured out the nephew's car payment: $520 a month. He couldn't pay it if the nephew fell behind. He kindly said no and helped him find a cheaper car he could pay on his own.

> **Key idea:** record business debts separately, lend with rules and only cosign if you could pay it yourself.



#### Check your understanding

1. When does a personal card work for the business?
*Answer:* Only if you pay in full each month and keep receipts.

2. What do you risk by cosigning?
*Answer:* Paying the debt yourself and hurting your credit.


#### Remember

- Card: pay in full every month.
- Family loans with rules.
- Cosign only if you could pay.



### Go deeper (5 more minutes)

#### If you already mixed

List the debts you used for the business. Pay them first with business money, starting with the highest interest. Stop buying materials with the card while you pay it down.



#### Business credit

A card in the business's name, used carefully and paid in full, helps separate expenses. Check your personal credit report at no cost every year at AnnualCreditReport.com.



#### How to say no

"I want to help you, but I can't risk my business. Let's find another way." Saying no protects your family and your business.



#### Cases


**Case 1. Daniela's card**

Daniela owes $4,500 on her personal card for materials.
- *What does she do?* She stops using it for the business and pays it off with business money.


**Case 2. The cosigner**

Don Ramón's nephew asks him to cosign a $520-a-month car loan.
- *What does he do?* He doesn't accept because he couldn't pay it, and helps him find another option.


**Case 3. The loan to a friend**

Lupita's close friend asks her for $400 of business money.
- *What does she do?* She lends only from her salary or savings, in writing and with dates.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying the minimum | Debt grows | Pay in full |
| Signing without doing the math | You pay | Only if you could |
| Lending from the business | No cash | From your salary, in writing |
| Not checking your credit | Uncorrected errors | No-cost report |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Don Ramón and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. When is it acceptable to use your personal card for the business? a) If you pay the minimum each month · b) Whenever the business needs it, even if you don't pay in full · c) If you pay in full each month and keep receipts
2. If you cosign and the borrower doesn't pay, what happens? a) They can collect from you · b) Nothing, you only signed · c) The bank forgives the debt
3. Where do you lend to a relative from? a) The business account · b) Your salary or savings, in writing · c) The business card
**Answers:** 1-c: no interest. 2-a: you're responsible for the debt. 3-b: without affecting the business.



#### Put it into practice

You owe $4,500 at 24% annual interest. About how much interest are you charged the first month?
**Answer:** 24% divided by 12 is 2% a month: about $90.



#### Your plan

List the debts you used for the business and make a plan to pay them off.



### Learn more

- **Cosigning a loan** (FTC · English and Spanish): https://consumer.ftc.gov | What to look for: "cosigning a loan".
- **No-cost credit report** (AnnualCreditReport.com · English): https://www.annualcreditreport.com.

### Key words

- *Cosigner:* a person who signs a loan and agrees to pay it if the borrower doesn't.
- *Minimum payment:* the least you can pay on your card; the debt barely goes down.

### Sources

FTC · CFPB, accessed September 29, 2026.

---

## M6 U05. Cosigner, guarantor, authorized user and reference: what are you signing?

**What you will be able to do:** Tell apart cosigner, guarantor, authorized user and reference, know what you can be charged in each case and decide before signing for another person or for your business.

**To start:** Don Ramón's son asks him to cosign a car loan, the bank asks Daniela for a personal guarantee on her LLC's loan, and a collector called Javier about a coworker's debt. In this lesson you'll see what each role means.

### The essentials (5 minutes)

#### Each role, a responsibility

| Type | Description | What it means for you |
|---|---|---|
| Cosigner | You sign the loan: if they don't pay, you owe all of it. | It shows on your credit report. |
| Guarantor (personal guarantee) | You pay with your money if the business or person doesn't. | Common on LLC loans. |
| Authorized user | You use someone else's card. | Generally not responsible for the debt. |
| Reference | You only give your contact details. | You can't be charged. |

#### Your business's personal guarantee

Even with an LLC, many lenders ask for a personal guarantee. If you sign it, the LLC no longer separates that debt from your personal assets. Read it before signing and negotiate a limit if you can.



#### Being a reference isn't being a cosigner

When someone applies for a card, a loan or a rental, they're asked for references. Being a reference doesn't obligate you to pay anything. If you didn't sign the loan, the debt isn't yours.

> **Current fact:** the federal Fair Debt Collection Practices Act (FDCPA) only lets a collector contact other people to find out how to locate you, and forbids telling them you owe a debt. A cosigner may have to pay the full amount, plus late fees or collection costs. Accessed September 30, 2026 through the CFPB and the FTC.



#### A case in one minute

Don Ramón read that as a cosigner he'd owe the whole car if his son stopped paying, and that it would show on his report. He chose to help his son save a bigger down payment instead. Javier learned that, as a reference, he can't be charged anything.

> **Key idea:** cosigners and guarantors pay if the other person or the business doesn't; a reference only gives their details. Read what you're signing and sign only if you could pay that debt.



#### Check your understanding

1. Can you be charged if you were only a reference?
*Answer:* No. You only gave your details; you didn't sign the loan.

2. What happens if you sign a personal guarantee for your LLC?
*Answer:* You pay with your own money if the business doesn't.


#### Remember

- Cosigner and guarantor: pay if the other doesn't.
- Reference: details only; you're not charged.
- Sign only if you could pay.



### Go deeper (5 more minutes)

#### What are you signing?

| Role | Do you sign? | Can you be charged? | Does it affect your report? |
|---|---|---|---|
| Cosigner | Yes, the loan | Yes, all of it | Yes |
| Co-borrower | Yes, and you're an owner | Yes, all of it | Yes |
| Guarantor (personal guarantee) | Yes, the guarantee | Yes, if the other doesn't pay | It may appear |
| Authorized user | No | Generally no | It may appear |
| Reference | No | No | No |



#### How to say no

Asking you to cosign is asking you to take on a debt. You can say: "I want to help, but I can't sign a debt I couldn't pay." Offer other help: saving a down payment, comparing loans or building credit with a secured card.



#### If a collector calls you as a reference

If a collector pressures you to pay a debt for which you were only a reference, don't pay or share extra details. Write down the name, date and time and submit it to the CFPB.

> **Before you act, check:** what the document you're asked to sign says and what role you have in it.



#### Cases


**Case 1. Don Ramón's son's car**

Don Ramón's son asks him to cosign a car loan.
- *What does Don Ramón do?* He signs only if he could pay all of it; if not, he offers to help with the down payment.


**Case 2. Daniela's LLC**

The bank asks Daniela for a personal guarantee on her LLC's loan.
- *What does she do?* She reads it, understands she's responsible with her own money and negotiates a limit before signing.


**Case 3. The call to Javier**

A collector calls Javier to collect a coworker's debt for which he was only a reference.
- *What does he do?* He doesn't pay, writes down the details and complains to the CFPB.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Signing without reading | Someone else's debt | Read your role |
| Thinking the LLC always protects you | You pay with your money | Check the guarantee |
| Thinking a reference pays | You pay what you don't owe | It doesn't obligate you |
| Cosigning out of pressure | You end up paying | Only if you could pay |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Daniela and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You gave your name and phone as a reference for a friend's loan. Can you be charged? a) Yes, half · b) Yes, if he doesn't pay · c) No, you only gave your details
2. Who must pay everything if the borrower doesn't? a) The cosigner · b) The reference · c) The seller
3. A collector pressures you to pay a debt for which you're only a reference. What do you do? a) Pay so they stop calling · b) Don't pay and complain to the CFPB · c) Give them your friend's family's details
**Answers:** 1-c: a reference isn't obligated. 2-a: they signed the loan. 3-b: they can't charge you.



#### Put it into practice

You're asked to cosign a $12,000 loan. If the other person stops paying halfway, how much could you be charged, not counting interest?
**Answer:** About $6,000: what's left to pay, plus late fees or collection costs.



#### Your plan

Before signing for someone or for your business, ask what role you have and decide only if you could pay that debt.



### Learn more

- **Cosigning a loan** (FTC · English and Spanish): https://consumer.ftc.gov | What to look for: "cosigning a loan".
- **Debt collection and complaints** (CFPB · English and Spanish): https://www.consumerfinance.gov | What to look for: "debt collection" and "submit a complaint".

### Key words

- *Cosigner:* a person who signs the loan and must pay it if the borrower doesn't.
- *Personal guarantee:* a promise to pay with your own money and property if the business doesn't.
- *Authorized user:* a person who uses someone else's card; generally not responsible for the debt.
- *Reference:* a person who only gives their details; not obligated to pay.

### Sources

CFPB · FTC, accessed September 30, 2026.

---


# Part 8. Module 7. Protect your business

## M7 U01. Your health when you work for yourself

**What you will be able to do:** Learn the health insurance options for self-employed people and how to protect your income if you get sick.

**To start:** Javier hurt his back carrying a ladder and couldn't work for two weeks. He had no health insurance and paid for the urgent care visit out of pocket. In this lesson you'll see your options.

### The essentials (5 minutes)

#### Health insurance options

| Type | Description | What it means for you |
|---|---|---|
| Health insurance marketplace (in California, Covered California) | Plans for people without job-based insurance. | There may be help paying the premium, based on income. |
| Medi-Cal (California's Medicaid) | For low incomes. | Eligibility depends on income and situation. |
| Community clinics | Sliding-scale fees. | Basic care. |
| No insurance | An emergency can cost thousands. | High risk. |

#### When to enroll

The marketplace has an open enrollment period every year (in fall and winter). Outside that period, you can only enroll if you have a qualifying life event, such as losing other coverage or moving. In California, Covered California and Medi-Cal offer help in Spanish and English.



#### A case in one minute

Javier checked Covered California with his estimated business income. He qualified for help with the premium and chose a plan with low-cost visits. He also keeps a small reserve for his deductible.

> **Key idea:** if you work for yourself, check the marketplace, Medi-Cal and community clinics; an emergency without insurance can cost you your business.



#### Check your understanding

1. When do you enroll in the marketplace?
*Answer:* During each year's open enrollment or after a qualifying life event.

2. What is Medi-Cal?
*Answer:* California's health program for people with low incomes.


#### Remember

- Marketplace every year.
- Medi-Cal by income.
- Community clinics.



### Go deeper (5 more minutes)

#### Health insurance and your taxes

If you're self-employed and pay for your own health insurance, in many cases you can deduct the premiums on your return. If you get help with the premium, it's adjusted at tax time based on your actual income: report changes on time.



#### If you can't work

As an owner you don't get employer disability pay. Your reserve (M3 U03) and, if you can afford it, disability or accident insurance protect your income. In California, sole proprietors can voluntarily join state disability insurance (EDD Elective Coverage); check costs and requirements.



#### Information and immigration status

Eligibility rules for health programs depend on your situation. Talk with a certified Covered California enroller or a community clinic; the information you give for health coverage has privacy protections.

> **Before you act, check:** eligibility and costs with Covered California (or your state's marketplace) and Medi-Cal; they change every year.



#### Cases


**Case 1. Javier's back**

Javier has no health insurance and works for himself.
- *What does he do?* He checks the marketplace and Medi-Cal with his estimated income.


**Case 2. Lupita's change**

Lupita left her part-time job and lost her employer coverage in June.
- *What does she do?* She checks whether that change lets her enroll outside open enrollment.


**Case 3. Daniela's income**

Daniela gets help with her premium and her sales went up a lot.
- *What does she do?* She updates her estimated income to avoid owing at tax time.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| No insurance | Medical debt | Check options |
| Waiting until you're sick | Outside enrollment | Enroll on time |
| Not reporting income changes | Debt at tax time | Update it |
| No reserve for the deductible | Surprise | Set aside |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Javier, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you look for health insurance in California if you're self-employed? a) Covered California and Medi-Cal · b) Only at your bank · c) At the IRS
2. You lost your job-based coverage mid-year. What can you check? a) Nothing, you wait for November · b) Whether that change lets you enroll now · c) A loan for doctor visits
3. You get help with your premium and your income goes up. What do you do? a) Nothing until next year · b) Cancel the insurance · c) Update your estimated income
**Answers:** 1-a: official options. 2-b: qualifying life event. 3-c: avoids owing at tax time.



#### Put it into practice

Your premium is $180 a month and your deductible is $1,500. How much could you pay in a year if you use the whole deductible?
**Answer:** $2,160 in premiums plus $1,500: $3,660.



#### Your plan

Check your health insurance options and write down the date of the next open enrollment.



### Learn more

- **Covered California** (English and Spanish): https://www.coveredca.com | What to look for: "self-employed".
- **Medi-Cal** (DHCS · English): https://www.dhcs.ca.gov | What to look for: "Medi-Cal".
- **Health insurance marketplace** (HealthCare.gov · English): https://www.healthcare.gov.

### Key words

- *Premium:* what you pay each month for your insurance.
- *Deductible:* what you pay before the insurance starts paying.
- *Open enrollment:* the time of year to buy or change your health insurance.

### Sources

Covered California · DHCS · HealthCare.gov · EDD, accessed September 29, 2026.

---

## M7 U02. Insurance for your business

**What you will be able to do:** Identify your business's risks and learn which insurance covers them and what to ask before buying.

**To start:** Don Ramón's food truck had a small fryer fire. His personal auto insurance didn't cover it because it was a business vehicle. In this lesson you'll see what insurance exists for small businesses.

### The essentials (5 minutes)

#### Risks and insurance

| Type | Description | What it means for you |
|---|---|---|
| General liability | If a customer gets hurt or you damage someone's property. | Many clients require it. |
| Commercial auto | Vehicles you use for the business. | Personal auto may not cover it. |
| Property and equipment | Fire, theft, damage. | Space, equipment, inventory. |
| Workers' compensation | Required in California if you have employees. | On-the-job injuries. |

#### Before you buy, ask

1. What does it cover and not cover (exclusions)?
2. What is the deductible?
3. How much does it pay at most (limit)?
4. Does it cover business use of my vehicle?
5. How do I file a claim and how long until they pay?



#### A case in one minute

Don Ramón bought a food truck package with commercial auto, liability and equipment. It costs $210 a month. Fair organizers now accept him because he shows them his certificate of insurance.

> **Key idea:** insure what you couldn't replace and what your clients ask for; your personal insurance almost never covers the business.



#### Check your understanding

1. What does general liability cover?
*Answer:* Damage you cause to other people or their property.

2. Does your personal auto insurance cover business use?
*Answer:* Often not; check or buy commercial auto.


#### Remember

- General liability.
- Commercial auto.
- Workers' comp if you have employees.



### Go deeper (5 more minutes)

#### Your risks

| Risk | Could you pay it yourself? | Insurance? |
|---|---|---|
| A customer gets hurt | | |
| Crash with the business vehicle | | |
| Equipment theft or fire | | |
| An employee gets hurt | | |



#### The certificate of insurance

Many contractors, markets and events ask for a certificate of insurance (COI) before letting you work. Having one opens doors to clients and can justify a better price.



#### Check the insurer

Check the agent and the insurer with your state's Department of Insurance (in California, the CDI). Ask for the full policy and keep receipts for your equipment.



#### Cases


**Case 1. The food truck fire**

Don Ramón's personal insurance didn't cover his food truck fire.
- *What does he do?* He buys commercial insurance with auto, liability and equipment.


**Case 2. Javier's contractor**

A contractor asks Javier for his certificate of insurance before giving him work.
- *What does he do?* He buys general liability and requests his certificate.


**Case 3. Lupita's helper**

Lupita will hire a helper as an employee.
- *What does she check?* That in California she needs workers' compensation insurance.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking personal insurance covers it | No payout | Commercial insurance |
| No certificate | You lose clients | Have it ready |
| Employees without workers' comp | Fines and lawsuits | Required |
| Not checking the agent | Fraud | Department of Insurance |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Javier and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. A customer slips at your stand. Which insurance helps? a) Life insurance · b) General liability · c) Personal auto insurance
2. What is the deductible? a) The part of the damage you pay · b) What the insurer pays · c) The price of the policy
3. You have one employee in California. Which insurance is required? a) Life insurance for the employee · b) Equipment insurance · c) Workers' compensation
**Answers:** 1-b: damage to others. 2-a: your share. 3-c: required with employees.



#### Put it into practice

A theft causes $6,000 in damage and the deductible is $1,000. How much does the insurer pay?
**Answer:** $5,000.



#### Your plan

Fill in your risk table and get quotes on at least two policies for what you couldn't replace.



### Learn more

- **Business insurance** (SBA · English): https://www.sba.gov | What to look for: "business insurance".
- **Check agents** (California Department of Insurance · English and Spanish): https://www.insurance.ca.gov | What to look for: "check a license".

### Key words

- *General liability:* insurance that pays for damage you cause to other people or their property.
- *Workers' compensation:* insurance that covers employees' on-the-job injuries.
- *Certificate of insurance (COI):* a document that proves you have insurance.

### Sources

SBA · California Department of Insurance, accessed September 29, 2026.

---

## M7 U03. Scams against businesses

**What you will be able to do:** Recognize the scams small businesses face and respond with a plan.

**To start:** Daniela got an "official" letter charging her $243 for an "LLC certificate," threatening a penalty. Lupita got a call from someone "from the health department" to collect a fine over the phone. In this lesson you'll see how to recognize these tricks.

### The essentials (5 minutes)

#### Common scams against businesses

| Type | Description | What it means for you |
|---|---|---|
| Letters that imitate the government | They charge for certificates or reports you don't need or that cost less. | Check the sender. |
| Fake authority by phone | "Health dept.," "IRS" or "police" demand immediate payment. | Hang up and check. |
| Fake supplier email | Changed bank account. | Call the number you already had. |
| Fake trademark notices | They charge for private "registries." | Only the USPTO. |

#### Your plan

1. Don't pay in a hurry: real authorities give you time and notify in writing.
2. Check the sender: fine print that says "we are not a government agency."
3. Verify by going to the official site yourself or calling the official number.
4. Never pay with gift cards, crypto or transfers to individuals.
5. Report it at ReportFraud.ftc.gov and warn other businesses.



#### A case in one minute

Daniela read the fine print: "This is not a government document." On the Secretary of State's site she saw that her Statement of Information costs $20 and she had already filed it. She threw the letter away and warned the community.

> **Key idea:** no authority collects by phone or demands immediate payment with gift cards; check the official site before paying any letter.



#### Check your understanding

1. How do you recognize a letter imitating the government?
*Answer:* By fine print saying it's not from the government, a high charge and urgency.

2. What do you do if someone calls to collect a fine?
*Answer:* Hang up and check with the official number.


#### Remember

- No rush.
- Check the sender.
- You verify.



### Go deeper (5 more minutes)

#### Your email and business accounts

Many scams start when someone gets into your email. Use different passwords, two-step verification and check your email's forwarding rules. If a supplier "changes banks," confirm by phone.



#### Extortion

If someone threatens you to collect "protection" or calls saying they have a relative, hang up, reach your relative another way and call 911 or local police. Don't share your hours or photos of your cash register on social media.



#### Business identity theft

Check your record with the Secretary of State from time to time: if someone changes your LLC's details, they could get credit in your name. Report identity theft at IdentityTheft.gov.



#### Cases


**Case 1. Daniela's letter**

An "official" letter charges Daniela $243 for an LLC certificate.
- *What does she do?* She checks the sender and verifies on the Secretary of State's site before paying.


**Case 2. The call to Lupita**

Someone "from the health department" demands Lupita pay a fine by phone today.
- *What does she do?* She hangs up and calls the health department's official number.


**Case 3. The supplier's email**

An email from Javier's supplier says they changed accounts.
- *What does he do?* He calls the supplier's number he already had before paying.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying letters without checking | You lose money | Read the fine print |
| Paying by phone | Scam | You verify |
| Gift cards | Sure scam | Never |
| No two-step on email | Accounts stolen | Turn it on |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Lupita and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. A letter charges you for an LLC "certificate" and threatens a penalty. What do you do first? a) Pay to avoid the penalty · b) Call the number on the letter · c) Check the sender and verify on the official site
2. What does a real authority never accept as payment? a) Gift cards · b) Checks · c) Payment on its official site
3. Where do you report a scam against your business? a) In the company's reviews · b) At ReportFraud.ftc.gov · c) Nowhere
**Answers:** 1-c: verify before paying. 2-a: sign of a scam. 3-b: official report.



#### Put it into practice

Three businesses on your street got the same $243 letter. If all of them paid, how much would they lose?
**Answer:** $729.



#### Your plan

Turn on two-step verification on your email and write your anti-scam plan.



### Learn more

- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov.
- **Identity theft** (FTC · English and Spanish): https://www.identitytheft.gov.
- **California businesses** (Secretary of State · English): https://bizfileonline.sos.ca.gov | What to look for: your business.

### Key words

- *Government-imitation letter:* mail from a private company that looks official in order to charge you for services.
- *Two-step verification:* signing in with a password plus a code or approval on your phone.

### Sources

FTC · California Secretary of State, accessed September 29, 2026.

---

## M7 U04. Your brand and your name

**What you will be able to do:** Know when it pays to register your trademark, how to search whether it already exists and how to do it without abusive middlemen.

**To start:** Daniela has sold jewelry as "Luna Morena" for two years. A shop in another state wrote to say the trademark is theirs. In this lesson you'll see how to protect your name.

### The essentials (5 minutes)

#### What a registered trademark is

Registering your trademark with the USPTO gives you nationwide rights for certain products or services (classes). Using a name gives you some local rights, but federal registration protects much more.



#### Steps

1. Search the USPTO trademark search to see whether the name already exists.
2. Identify the class of your products or services.
3. File the application online and pay the fee.
4. Respond on time to USPTO requests.

> **Current fact:** the USPTO base trademark application fee is $350 per class; extra charges may apply if the description isn't from the ID Manual or information is missing. Accessed September 29, 2026 through the USPTO (fees in effect since January 18, 2025).



#### When it pays

| Type | Description | What it means for you |
|---|---|---|
| Your name already sells | Customers look for you by it. | Protect it. |
| You sell online to other states | More visible, more risk. | Federal registration. |
| You only sell in your city | A state registration may be enough. | Cheaper. |
| Notices charging to "register" | Not from the USPTO. | Be wary. |

#### A case in one minute

Daniela searched the USPTO: "Luna Morena" had been registered for jewelry before her. She switched to an available name and registered it in one class. Now she can grow online without worry.

> **Key idea:** search the USPTO before investing in a name and register it once you start selling beyond your area.



#### Check your understanding

1. Where do you search whether a trademark exists?
*Answer:* In the USPTO trademark search.

2. How much is the base application per class?
*Answer:* $350.


#### Remember

- Search the USPTO.
- Register by class.
- Only the USPTO registers federal trademarks.



### Go deeper (5 more minutes)

#### Fake notices and emails

After you apply for your trademark, your information is public. You'll get letters and emails that look like they're from the USPTO charging to "publish" or "monitor" your trademark. Only trust communications from uspto.gov domains.



#### Usernames and domains

Your social media account and your domain are not registered trademarks. They help you sell, but they don't protect you if someone registers the name.



#### If someone claims your name

If someone says your name is their trademark, check the USPTO before replying. If their registration is real and covers your products, changing your name is usually the wisest move. Some universities have no-cost intellectual property law clinics.



#### Cases


**Case 1. Daniela's brand**

A shop tells Daniela that "Luna Morena" is their trademark.
- *What does she do?* She checks the USPTO and, if the registration is real, changes her name.


**Case 2. The food truck name**

Don Ramón wants to paint a new name on his food truck.
- *What does he do first?* He searches the USPTO and his state to make sure the name is available.


**Case 3. The email to Javier**

Javier gets an email charging $1,200 to "protect his brand internationally."
- *What does he do?* He checks that it isn't from uspto.gov and doesn't pay.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not searching first | You lose the name | USPTO |
| Thinking social media protects you | It gets taken | Register |
| Paying fake notices | Scam | Only uspto.gov |
| Free-form descriptions unchecked | Extra fees | Use the ID Manual |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Don Ramón and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you search whether a name is already a federal trademark? a) The USPTO · b) Social media · c) An internet search engine
2. Does your social media account give you exclusive nationwide rights to the name? a) Yes, if it has many followers · b) Yes, if you opened it first · c) No
3. Which domain do real USPTO notices come from? a) Any email with "trademark" in the subject · b) uspto.gov · c) A law firm that writes to you first
**Answers:** 1-a: official search. 2-c: only registration does. 3-b: official domain.



#### Put it into practice

You register your trademark in two classes at the base fee. How much do you pay?
**Answer:** $700.



#### Your plan

Search your business name at the USPTO and in your state's registry.



### Learn more

- **Trademark search** (USPTO · English): https://www.uspto.gov | What to look for: "trademark search".
- **California trademarks** (Secretary of State · English): https://www.sos.ca.gov | What to look for: "trademarks".

### Key words

- *Trademark:* a name, logo or combination that identifies your product or service.
- *USPTO:* United States Patent and Trademark Office: it registers trademarks at the federal level.
- *Class:* the group of products or services a trademark registration covers.

### Sources

USPTO · California Secretary of State, accessed September 29, 2026.

---

## M7 U05. Identity theft and unwanted calls

**What you will be able to do:** Protect your identity with a credit freeze, fraud alerts and your no-cost reports, know what to do if someone uses your data and register your number so you don't get sales calls.

**To start:** Don Ramón was turned down for credit because his report showed a card he never opened. He also gets ten calls a day offering "loans for his food truck." In this lesson you'll see how to stop both.

### The essentials (5 minutes)

#### What identity theft is

Identity theft happens when someone uses your SSN or ITIN, your name or your documents to open cards, take out loans or file a tax return in your name. As a business owner, your personal information is on many forms: protect it.



#### Your locks

| Type | Description | What it means for you |
|---|---|---|
| Credit freeze | Nobody opens new credit in your name. | At no cost at all 3 bureaus. |
| Fraud alert | Lenders must verify it's you. | Lasts one year. |
| Your credit reports | At no cost every week at AnnualCreditReport.com. | Check what you don't recognize. |
| IRS IP PIN | Nobody files with your number (M5 U04). | At no cost. |

> **Current fact:** freezing and unfreezing your credit costs nothing at Equifax, Experian and TransUnion (you must ask all three); an initial fraud alert costs nothing, lasts one year and you only need to ask one bureau; and you can see your reports no-cost every week at AnnualCreditReport.com. Accessed September 29, 2026 through the FTC.

#### Stop the calls

Register your number on the National Do Not Call Registry at donotcall.gov. It costs nothing and never expires. After you register, sales calls that keep coming are usually illegal or scams.

> **Current fact:** the National Do Not Call Registry costs nothing, your number shows up the next day, companies have up to 31 days to stop calling and your registration never expires. Accessed September 29, 2026 through the FTC (donotcall.gov).



#### A case in one minute

Don Ramón pulled his reports, found the fake card, reported it at IdentityTheft.gov and froze his credit at all three bureaus. He registered his cell phone at donotcall.gov. When he needs a loan, he'll lift the freeze for a few days, at no cost.

> **Key idea:** freeze your credit, check your reports and register your number; if someone uses your data, report it at IdentityTheft.gov.



#### Check your understanding

1. What does a credit freeze do?
*Answer:* It stops anyone from opening new credit in your name; it costs nothing and you can lift it when you need to.

2. Where do you report identity theft?
*Answer:* At IdentityTheft.gov, which gives you a recovery plan.


#### Remember

- Freeze at all 3 bureaus.
- No-cost weekly reports.
- donotcall.gov costs nothing.



### Go deeper (5 more minutes)

#### If someone already used your data

1. Report it at IdentityTheft.gov: you get a step-by-step plan and letters for companies.
2. Call the fraud department of the company where the account was opened and ask them to close it.
3. Place a fraud alert or freeze your credit.
4. Check your reports and dispute what you don't recognize.
5. If your number was used for taxes, follow the IRS instructions and get your IP PIN.



#### If you have an ITIN

If you have a credit history under an ITIN, ask each bureau how to request a freeze or alert with your ITIN; some requests need extra documents. The IRS IP PIN is also available to people who file with an ITIN.



#### What the registry doesn't cover

The Do Not Call Registry doesn't stop debt collection calls, surveys, charities, political calls or companies you already do business with. It doesn't stop scammers either. Your phone carrier offers no-cost tools to block suspicious calls; use them.

> **Before you act, check:** that you're on donotcall.gov, AnnualCreditReport.com or IdentityTheft.gov; some sites imitate these names and charge for what's at no cost.



#### Cases


**Case 1. Don Ramón's card**

Don Ramón's report shows a card he never opened.
- *What does he do?* He reports it at IdentityTheft.gov and freezes his credit at all three bureaus.


**Case 2. Lupita's calls**

Lupita gets sales calls every day.
- *What does she do?* She registers her number at donotcall.gov and turns on her carrier's call blocking.


**Case 3. Daniela's site**

A website charges Daniela $30 for "her official credit report."
- *What does she do?* She doesn't pay and goes to AnnualCreditReport.com, where it costs nothing.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Freezing at only one bureau | Credit still gets opened | All three |
| Paying for reports | Unnecessary cost | AnnualCreditReport.com |
| Not reporting the theft | You're billed for others' debts | IdentityTheft.gov |
| Thinking the registry stops scams | You fall for them | Hang up and check |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. How much does a credit freeze cost? a) $10 per bureau · b) Nothing · c) It's at no cost only if your identity was already stolen
2. Where do you report identity theft? a) At IdentityTheft.gov · b) At the bank where you have your account · c) On social media
3. How long does your Do Not Call registration last? a) One year · b) Five years · c) It never expires
**Answers:** 1-b: it costs nothing at all three bureaus. 2-a: it gives you a recovery plan. 3-c: it never expires.



#### Put it into practice

You register your number on May 1. By what date at the latest should sales calls stop?
**Answer:** Within 31 days: June 1.



#### Your plan

This week freeze your credit at all three bureaus, check your reports and register your cell phone at donotcall.gov.



### Learn more

- **Identity theft** (FTC · English and Spanish): https://www.identitytheft.gov.
- **Credit freezes and fraud alerts** (FTC · English): https://consumer.ftc.gov | What to look for: "credit freeze".
- **No-cost credit reports** (AnnualCreditReport.com · English): https://www.annualcreditreport.com.
- **Do Not Call Registry** (FTC · English and Spanish): https://www.donotcall.gov.

### Key words

- *Identity theft:* using your information to pose as you and open accounts, get credit or file tax returns.
- *Credit freeze:* a no-cost block so nobody can open new credit in your name.
- *Fraud alert:* a notice on your report so lenders verify your identity before giving credit.
- *National Do Not Call Registry:* a no-cost federal registry so companies don't call you with sales pitches.

### Sources

FTC · IRS, accessed September 29, 2026.

---

## M7 U06. AI scams: fake voices, videos and messages

**What you will be able to do:** Recognize scams that use voices, videos or messages made with artificial intelligence against your business and family, and protect yourself with simple rules.

**To start:** Don Ramón got a call from "his meat supplier," in the supplier's own voice, asking him to pay the invoice to a new account by Zelle. It was a cloned voice. In this lesson you'll see how to spot it.

### The essentials (5 minutes)

#### What they can imitate

With a few seconds of audio or some photos from your social media, artificial intelligence can imitate the voice of a relative, supplier or customer; create fake videos of celebrities "recommending" investments; or write emails identical to your bank's or the IRS's.



#### Your rules

| Type | Description | What it means for you |
|---|---|---|
| Account changes | Confirm by calling the number you already had. | Never through the same message. |
| Code word | With your family and main suppliers. | If they don't say it, it's not them. |
| Urgency | "Pay today by Zelle or lose the order." | Sign of a scam. |
| Celebrity investing | Fake video. | Not real. |

#### A case in one minute

Don Ramón hung up and called the supplier's number he had saved. They hadn't changed accounts. Now he confirms any change in payment details by phone, and his family has a code word for emergencies.

> **Key idea:** a familiar voice or face is no longer proof; confirm any request for money through a channel you choose.



#### Check your understanding

1. What do you do if a supplier asks you to pay a new account?
*Answer:* Confirm by calling the number you already had, never through the same message.

2. Does a familiar voice prove it's that person?
*Answer:* No: it may be cloned.


#### Remember

- The voice may be fake.
- Confirm another way.
- Code word.



### Go deeper (5 more minutes)

#### Less material to copy

Avoid posting long audio clips of your voice, make your personal accounts private and don't post your hours or photos of your cash register. The less data, the less believable the scam.



#### Your customers are targets too

If someone poses as your business to ask for payments, post on your social media and website your only payment method. Report it at ReportFraud.ftc.gov.

> **Before you act, check:** any request for money, account change or "recommended" investment through a channel you choose.



#### Cases


**Case 1. Don Ramón's supplier**

A voice identical to his supplier's asks Don Ramón to pay a new account by Zelle.
- *What does he do?* He hangs up and confirms by calling the number he already had.


**Case 2. Javier's video**

Javier sees a video of a famous businessman promising to double his money with crypto.
- *What does he do?* He doesn't invest: it's a fake video and a scam.


**Case 3. Daniela's customers**

Someone uses Daniela's photo and voice to ask her customers for deposits.
- *What does she do?* She posts her only payment method on her social media and reports it to the FTC.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Trusting the voice | You pay a scammer | Confirm |
| Changing accounts by message | You lose the payment | You call |
| Believing celebrity videos | You lose everything | It's fake |
| Not warning customers | More victims | Official channels |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Javier and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Your supplier, in their own voice, asks you to pay a new account. What do you do? a) Pay: it's their voice · b) Confirm by calling the number you already had · c) Ask for the account by message
2. A celebrity recommends an investment that doubles your money in a video. What is it? a) Almost certainly a fake video and a scam · b) A safe investment · c) A bank promotion
3. Where do you report an AI scam in the U.S.? a) In the video's comments · b) Nowhere · c) At ReportFraud.ftc.gov
**Answers:** 1-b: confirm another way. 2-a: nobody doubles money. 3-c: official report.



#### Put it into practice

A $2,500 invoice and one minute to confirm by phone. What costs you more if you get it wrong?
**Answer:** The $2,500; confirming costs one minute.



#### Your plan

This week agree on a code word with your family and post your only payment method on your social media.



### Learn more

- **Voice cloning scams** (FTC · English and Spanish): https://consumer.ftc.gov | What to look for: "voice cloning".
- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov.

### Key words

- *Artificial intelligence:* programs that imitate voices, faces or text very realistically.
- *Cloned voice:* a computer-made imitation of a person's voice.

### Sources

FTC, accessed September 29, 2026.

---

## M7 U07. If disaster strikes: your business ready

**What you will be able to do:** Prepare your business for a fire, earthquake or flood with backed-up records, insurance, a reserve and a plan to get back to work, and know the federal help available.

**To start:** A wildfire forced an evacuation where Don Ramón parks his food truck. He lost a week of sales and inventory, and didn't know if his insurance covered it. In this lesson you'll see how to prepare.

### The essentials (5 minutes)

#### Your disaster plan

| Type | Description | What it means for you |
|---|---|---|
| Digital backup | Records, receipts and contacts in the cloud. | For taxes and insurance. |
| Photos of equipment and inventory | With dates. | To file claims. |
| Insurance with the right coverage | Flood and earthquake are usually separate. | Ask. |
| Reserve in an account | Not all in cash. | Available. |

#### Federal help

In declared disaster areas, FEMA offers assistance to individuals and the SBA offers low-interest loans to households and businesses. The IRS usually gives extra time to file and pay taxes.

> **Current fact:** SBA disaster loans go up to $500,000 to repair a primary residence, $100,000 for personal property and $2 million for businesses (physical damage or working capital); the rate is no more than 4% if you can't get credit elsewhere. Accessed September 29, 2026 through the SBA.



#### A case in one minute

Don Ramón backs up his receipts and equipment photos in the cloud every week. He reviewed his policy and added business interruption coverage. His reserve is in an account. He knows that if a disaster is declared, he can apply for help at DisasterAssistance.gov and the SBA.

> **Key idea:** backups, photos, the right coverage and a reserve in an account; if a disaster is declared, federal help costs nothing on official sites.



#### Check your understanding

1. What does basic home or business insurance usually not cover?
*Answer:* Flood and earthquake, which are usually separate policies or coverages.

2. What does the SBA offer after a disaster?
*Answer:* Low-interest loans for households and businesses.


#### Remember

- Backups and photos.
- The right coverage.
- FEMA, SBA and IRS: official sites.



### Go deeper (5 more minutes)

#### The IRS in a disaster

When the government declares a disaster area, the IRS usually postpones filing and payment deadlines, including estimated payments. Check the IRS disaster relief page before paying penalties.



#### Scams after a disaster

Fake FEMA inspectors, contractors who want payment up front and fake charities show up. FEMA doesn't charge to help you or ask for payment to register. In California, check a contractor's license with the CSLB.

> **Before you act, check:** what your policy covers (flood, earthquake, business interruption) and apply for help only at DisasterAssistance.gov, sba.gov and irs.gov.



#### Cases


**Case 1. Don Ramón's policy**

Don Ramón doesn't know if his insurance covers sales lost to an evacuation.
- *What does he do?* He asks his agent about business interruption coverage.


**Case 2. Lupita's inspector**

Someone claiming to be from FEMA asks Lupita for $100 to "speed up" her aid.
- *What does she do?* She doesn't pay: FEMA doesn't charge; she reports it.


**Case 3. Javier's shop**

After an earthquake, Javier can't make his estimated payment on time.
- *What does he check?* Whether the IRS postponed the deadlines for his area.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Everything on paper | You lose it | Backup |
| Assuming insurance covers everything | No payout | Check coverage |
| Paying for aid | Scam | It's at no cost |
| Paying penalties without checking | You overpay | IRS relief |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita and Javier. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is usually left out of basic insurance? a) Robbery · b) Flood and earthquake · c) Fire
2. Someone from "FEMA" asks for $100 to speed up your aid. What is it? a) A scam: FEMA doesn't charge · b) A normal procedure · c) An SBA fee
3. Up to how much does the SBA lend a business after a disaster? a) $50,000 · b) $500,000 · c) $2 million
**Answers:** 1-b: usually separate. 2-a: aid costs nothing. 3-c: physical damage or working capital.



#### Put it into practice

Your equipment is worth $18,000 and the deductible is 10%. How much would you pay?
**Answer:** $1,800.



#### Your plan

This week take photos of your equipment and inventory, back them up and ask what your insurance covers.



### Learn more

- **Disaster assistance** (FEMA · English and Spanish): https://www.disasterassistance.gov.
- **Disaster loans** (SBA · English): https://www.sba.gov | What to look for: "disaster assistance".
- **Disaster tax relief** (IRS · English): https://www.irs.gov | What to look for: "disaster relief".

### Key words

- *Business interruption:* coverage that pays lost income when you can't work because of covered damage.
- *Disaster area:* an area declared by the government where federal help is activated.

### Sources

FEMA · SBA · IRS · CSLB, accessed September 29, 2026.

---


# Part 9. Module 8. Grow in an orderly way

## M8 U01. Hiring help

**What you will be able to do:** Figure out the real cost of hiring, tell the difference between an employee and an independent contractor, and know your basic obligations.

**To start:** Lupita can't keep up with weekend orders anymore. She wants her neighbor to help and to pay her $15 an hour in cash "as a contractor." In this lesson you'll see why that can get her in trouble.

### The essentials (5 minutes)

#### Employee or contractor?

An independent contractor decides how to do the work and has their own business. If you set the schedule, say how to do it and the work is a core part of your business, it's generally an **employee**. California uses a strict test (the ABC test): most people who help on a regular basis are employees.

> **Current fact:** California's minimum wage is $16.90 an hour in 2026 (the federal minimum is $7.25, and many cities have a higher one). Accessed September 29, 2026 through the California Department of Industrial Relations and the U.S. Department of Labor.



#### What an employee costs beyond wages

| Type | Description | What it means for you |
|---|---|---|
| Payroll taxes | Social Security, Medicare, unemployment. | You withhold and pay. |
| Workers' compensation | Required in California. | Insurance. |
| Paid sick days | California law. | They accrue. |
| "Contractor" for convenience | High fines for misclassification. | Classify correctly. |

#### Lupita's helper (approximate)

- Monthly wages (20 hours a week at $16.90): **$1,352**
- Payroll taxes and insurance (approx.): **$250**
- Real monthly cost: **$1,602**
Lupita recalculates her break-even point (M2 U03) before hiring.


#### A case in one minute

Lupita saw her neighbor would be an employee: working in her kitchen, on her schedule, with her recipes. She used a payroll service to register with the EDD, pay minimum wage and get workers' comp. She raised her weekend prices to cover it.

> **Key idea:** classify your help correctly, pay at least minimum wage and figure the real cost before hiring.



#### Check your understanding

1. What defines an independent contractor?
*Answer:* Having their own business and deciding how to do the work.

2. What is California's minimum wage in 2026?
*Answer:* $16.90 an hour.


#### Remember

- Employee or contractor: it isn't chosen for convenience.
- Minimum wage.
- Real cost with taxes and insurance.



### Go deeper (5 more minutes)

#### If you have employees

You need an EIN, to register with your state's employment agency (in California, the EDD), withhold and pay payroll taxes, carry workers' comp and verify each person's employment eligibility with Form I-9. A payroll service or accountant can do it for you.



#### Real contractors

If you hire another business for a one-time job (a design, a repair), ask for their W-9 and, if you pay them $2,000 or more in the year, send them a 1099-NEC.



#### Family who helps

There are special rules for minor children of a sole proprietor and for spouses. If family helps regularly, review the rules with a tax preparer.

> **Before you act, check:** classification and your employer obligations with the EDD, DIR and IRS; rules change by state and city.



#### Cases


**Case 1. Lupita's neighbor**

Lupita wants to pay her neighbor in cash "as a contractor" to work in her kitchen on her schedule.
- *What does she do?* She recognizes the neighbor would be an employee and registers as an employer.


**Case 2. Javier's helper**

Javier wants a helper on a $3,000 painting job.
- *What does he check?* That with helpers he needs a CSLB license and workers' comp.


**Case 3. Daniela's designer**

Daniela hires an independent designer for her logo for $400.
- *What does she do?* She asks for a W-9 and keeps the invoice; no 1099 is needed under $2,000 for the year.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| "Contractor" for convenience | High fines | Classify correctly |
| Less than minimum wage | Illegal | Minimum wage |
| No workers' comp | Lawsuits | Required |
| Looking only at wages | You come up short | Real cost |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Javier and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Someone works at your place, on your schedule and following your instructions. What are they usually? a) An employee · b) An independent contractor · c) A partner
2. Which insurance is required in California if you have employees? a) Life insurance for each employee · b) Workers' compensation · c) Auto insurance
3. You pay an independent designer $2,500 in the year. What do you send them? a) A W-2 · b) Nothing · c) A 1099-NEC
**Answers:** 1-a: you control the work. 2-b: required. 3-c: from $2,000 in 2026.



#### Put it into practice

Someone works 15 hours a week at $16.90. What are their wages over 4 weeks?
**Answer:** 60 hours times $16.90: $1,014.



#### Your plan

If you're thinking of hiring, decide whether it would be an employee or a contractor and figure the real cost.



### Learn more

- **Employee or contractor** (DIR · English): https://www.dir.ca.gov | What to look for: "ABC test".
- **Employers** (EDD · English): https://edd.ca.gov | What to look for: "employer registration".
- **Minimum wage** (DIR · English): https://www.dir.ca.gov | What to look for: "minimum wage".

### Key words

- *Independent contractor:* a person who has their own business, decides how to do the work and works for several clients.
- *Payroll taxes:* taxes the employer withholds and pays for its employees.
- *ABC test:* California's test to determine whether someone is an employee or a contractor.

### Sources

DIR · EDD · IRS · U.S. Department of Labor, accessed September 29, 2026.

---

## M8 U02. Selling online and on platforms

**What you will be able to do:** Figure out the real cost of selling online and on platforms, and understand the 1099-K and sales tax on platforms.

**To start:** Daniela sells a necklace for $40 in an online store. After selling, payment and ad fees, plus shipping, she keeps much less. In this lesson you'll see what you really keep.

### The essentials (5 minutes)

#### What gets taken out

| Type | Description | What it means for you |
|---|---|---|
| Selling fee | A percentage per sale. | Varies by platform. |
| Payment fee | For processing the payment. | Percentage plus a flat fee. |
| Ads | If you pay to show up more. | Measure whether it pays. |
| Shipping | You or your customer pays it. | Build it into the price. |

#### Daniela's necklace

- Price: **$40**
- Selling and payment fees (approx.): **$5**
- Shipping: **$5**
- Materials and packaging: **$10**
- Before her fixed costs and taxes: **$20**


#### A case in one minute

Daniela figured out what she keeps per channel. On one platform she kept $20; on her own site, $26, but she sells less. She raised her platform price to $44 and offers no-cost shipping on her site for two or more pieces.

> **Key idea:** set your price by channel, with all fees and shipping, and report everything you sell.



#### Check your understanding

1. What fees do platforms charge?
*Answer:* Selling, payment and, if you use them, ad fees.

2. Do you report your sales even if you don't get a 1099-K?
*Answer:* Yes, all income is reported.


#### Remember

- Fees + shipping + ads.
- Price by channel.
- Everything is reported.



### Go deeper (5 more minutes)

#### The 1099-K

If your payments on a platform exceed $20,000 and 200 transactions in the year, you'll get a 1099-K. It shows gross payments: subtract refunds, fees and costs on your Schedule C. Even if you don't get one, report everything.



#### Sales tax on platforms

In most states, large platforms collect and send the sales tax on sales made through them. On your own site or social media sales, it's up to you (M5 U05).



#### Reviews and returns

Ratings sell. Describe well, ship on time and respond quickly. Figure out what returns cost you and build it into the price.

> **Before you act, check:** each platform's current fees; they change often.



#### Cases


**Case 1. The platform price**

Daniela charges the same on the platform as on her own site.
- *What does she check?* That the platform price covers fees, shipping and ads.


**Case 2. Daniela's 1099-K**

Daniela got a 1099-K for $24,000 gross.
- *What does she do?* She reports the payments and subtracts refunds, fees and costs using her records.


**Case 3. Lupita's ads**

Lupita pays $100 a month for ads and doesn't know if they bring sales.
- *What does she do?* She measures how many sales come from the ads and how much they leave her.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Same price everywhere | You lose on the platform | Price by channel |
| Reporting the 1099-K without subtracting costs | You overpay | Use your records |
| Not reporting without a 1099-K | IRS trouble | Report everything |
| Unmeasured ads | Spending with no return | Measure |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. When does a platform send a 1099-K? a) Always, from the first sale · b) With over $20,000 and over 200 transactions · c) Only if you ask for it
2. Your 1099-K shows $24,000 gross. How much do you report as profit? a) The full $24,000 · b) Nothing, the platform already reported it · c) Payments minus refunds, fees and costs
3. Who usually collects sales tax on large platform sales? a) The platform · b) Nobody · c) Your customer, directly to the state
**Answers:** 1-b: current threshold. 2-c: costs are subtracted. 3-a: marketplace facilitator.



#### Put it into practice

You sell 60 pieces at $30 in a month; the platform charges 12% in total and shipping is $4 a piece. How much do you keep before materials?
**Answer:** $1,800 minus $216 minus $240: $1,344.



#### Your plan

Figure out how much you keep per product on each channel where you sell.



### Learn more

- **Form 1099-K** (IRS · English and Spanish): https://www.irs.gov | What to look for: "Form 1099-K".

### Key words

- *Platform:* a site or app that connects sellers and buyers and charges a fee.
- *Gross payments:* the total collected before subtracting fees, refunds and costs.

### Sources

IRS · CDTFA, accessed September 29, 2026.

---

## M8 U03. Your monthly numbers

**What you will be able to do:** Review five numbers about your business each month and make decisions with them.

**To start:** Don Ramón feels the food truck is doing "so-so." His daughter suggests checking five numbers every month. In this lesson you'll see what they are and what they tell you.

### The essentials (5 minutes)

#### Your five numbers

| Type | Description | What it means for you |
|---|---|---|
| Sales | How much you sold. | Compare with last month. |
| Margin | The % you keep after what you sell. | Going up or down? |
| Profit | Sales minus all costs. | The one that matters. |
| Cash at month-end | What you have at the end of the month. | Is it enough? |

#### The fifth: average ticket

The average ticket is what each customer spends on average. If it goes up, you sell more without needing more customers.



#### Don Ramón's ticket

- Monthly sales: **$12,000**
- Number of sales: **1,000**
- Average ticket: **$12**
If each customer spent $1.50 more, he'd sell $1,500 more a month.


#### A case in one minute

Don Ramón saw his margin drop from 60% to 55%: meat went up and he didn't adjust. He changed suppliers and offered a combo with a drink. The next month his ticket rose to $13.40.

> **Key idea:** five numbers a month tell you what to improve: sales, margin, profit, cash and average ticket.



#### Check your understanding

1. What is the average ticket?
*Answer:* What each customer spends on average: sales divided by number of sales.

2. What do you do if your margin drops?
*Answer:* Check prices and costs: suppliers, waste and price.


#### Remember

- Five numbers a month.
- Compare with last month.
- One decision per number.



### Go deeper (5 more minutes)

#### Your monthly dashboard

| Number | Last month | This month | Decision |
|---|---|---|---|
| Sales | | | |
| Margin | | | |
| Profit | | | |
| Cash at month-end | | | |
| Average ticket | | | |



#### Compare with the same month last year

If your business is seasonal, compare July with July, not with June.



#### One decision at a time

Choose one improvement (price, supplier, hours), apply it and measure the next month.



#### Cases


**Case 1. Don Ramón's margin**

Don Ramón's margin dropped five points.
- *What does he do?* He checks which costs went up and adjusts suppliers or prices.


**Case 2. Daniela's sales**

Daniela's sales fell in January compared with December.
- *What does she compare with?* With January of last year, because of the season.


**Case 3. Lupita's ticket**

Lupita has many customers, but each one buys little.
- *What does she try?* A combo or a drink to raise the average ticket.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Looking only at sales | Hidden profit | Five numbers |
| Comparing wrong | False conclusions | Same month last year |
| Changing everything at once | You don't know what worked | One at a time |
| Not writing down decisions | They get forgotten | Dashboard |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Daniela and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Sales of $6,000 from 400 sales. Average ticket? a) $2,400 · b) $150 · c) $15
2. Your margin dropped. What do you check first? a) Prices and costs of what you sell · b) The color of your logo · c) Your card limit
3. Your business is seasonal. What do you compare July with? a) June · b) July last year · c) January
**Answers:** 1-c: $6,000 divided by 400. 2-a: margin depends on them. 3-b: same season.



#### Put it into practice

You have 800 sales a month. If your average ticket goes from $10 to $11, how much more do you sell a month?
**Answer:** $800.



#### Your plan

Fill in your dashboard with last month's numbers and choose one decision for this month.



### Learn more

- **No-cost business advice** (SBA · English): https://www.sba.gov | What to look for: "Small Business Development Centers" (SBDC) and SCORE.

### Key words

- *Average ticket:* what each customer spends on average per purchase: sales divided by number of sales.
- *Dashboard:* a table with the business's key numbers each month.

### Sources

SBA, accessed September 29, 2026.

---

## M8 U04. Stress, business and family

**What you will be able to do:** Recognize the stress of running a business, separate work time from rest and talk about money at home without fighting.

**To start:** Lupita cooks Monday to Sunday, answers orders until midnight and argues with her husband about money. She feels that if she rests, she'll lose customers. In this lesson you'll see how to take care of your energy and your business.

### The essentials (5 minutes)

#### Warning signs

| Type | Description | What it means for you |
|---|---|---|
| You sleep badly | You think about bills and orders all night. | Your health suffers. |
| Fights at home | Every money talk becomes an argument. | Nobody decides. |
| Avoiding your numbers | You don't want to see sales or taxes. | Deciding blind. |
| Hours and rest | Fixed days and hours. | Better decisions. |

#### Four habits

1. Posted order hours; outside them, an automatic reply.
2. One day off a week.
3. A 20-minute money talk at home every week, with numbers.
4. Your fixed salary (M1 U03): your home doesn't depend on the business's day-to-day.



#### A case in one minute

Lupita set order hours from 8 to 6 and an automatic reply. She takes Mondays off. Every Sunday she and her husband review the household budget and her fixed salary. She sleeps better and makes fewer mistakes on orders.

> **Key idea:** your business needs you to be well; set hours, one day off and a weekly money talk lower the stress.



#### Check your understanding

1. What helps you stop answering orders at midnight?
*Answer:* Posted hours and an automatic reply.

2. Why does a fixed salary help at home?
*Answer:* Because your family doesn't depend on each day's sales.


#### Remember

- Posted hours.
- One day off.
- Weekly money talk.



### Go deeper (5 more minutes)

#### If the stress doesn't go down

If you haven't slept for weeks, feel there's no way out or think about hurting yourself, call or text 988: the Suicide & Crisis Lifeline costs nothing, 24 hours a day, in English and Spanish.



#### Family in the business

If your family works with you, keep business talks separate from home talks and agree on clear pay (M8 U01). That way a bad sales day doesn't become a family fight.



#### Cases


**Case 1. Lupita's orders**

Lupita answers orders until midnight and never rests.
- *What does she do?* She posts order hours and turns on an automatic reply.


**Case 2. Daniela's sales**

Daniela doesn't want to look at her numbers because sales were low.
- *What does she do?* She reviews her numbers calmly and decides on one action.


**Case 3. Don Ramón's family**

Don Ramón and his daughter argue about the food truck at dinner.
- *What do they do?* They set one time for the business and another for home.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Working with no rest | Mistakes and illness | Day off |
| Avoiding the numbers | Deciding blind | Review |
| Mixing business and dinner | Fights | Separate times |
| Keeping stress quiet | It gets worse | Ask for help |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Daniela and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Customers message you at midnight. What do you do? a) Always answer so you don't lose them · b) Post your hours and an automatic reply · c) Turn off your phone for a week
2. Sales were low this month. What do you do with your numbers? a) Review them calmly and decide on one action · b) Don't look so you don't worry · c) Delete them
3. You haven't slept for weeks and feel there's no way out. Who do you call? a) Nobody, you tough it out · b) Someone who'll lend you money · c) 988
**Answers:** 1-b: clear limits. 2-a: decide with data. 3-c: no-cost help 24 hours.



#### Put it into practice

You work 7 days of 11 hours. If you take one day off, how many hours do you get back each week?
**Answer:** 11 hours.



#### Your plan

Post your order hours and choose your day off.



### Learn more

- **988 Suicide & Crisis Lifeline** (English and Spanish): call or text 988.

### Key words

- *Financial stress:* constant worry about money that affects your sleep, health or relationships.

### Sources

988 Suicide & Crisis Lifeline, accessed September 29, 2026.

---

## M8 U05. Your one-page business plan and how to pitch it

**What you will be able to do:** Summarize your business in a one-page plan, pitch it in two minutes to a bank, a program or a mentor, and know no-cost support and financing options without falling for scams.

**To start:** Daniela wants a microloan to buy seasonal inventory, and they ask for "a business plan and a short pitch." She has never made one. In this lesson you'll build yours.

### The essentials (5 minutes)

#### Your one-page business plan

| Question | Your answer |
|---|---|
| What problem do you solve and for whom? | |
| What do you sell and at what price? | |
| What does it cost you and what do you keep? | |
| How much do you sell a month and what's your break-even point? | |
| Who is your competition and why do customers choose you? | |
| What do you need (money, equipment, training) and for what? | |
| How would you repay it or what result would you deliver? | |



#### Your two-minute pitch

1. The problem and who you solve it for.
2. What you sell and why customers choose you.
3. Your numbers: sales, margin and break-even point.
4. What you need and how you'd use it.
5. How you'd repay it or what you'd achieve.



#### No-cost support

The SBA has Small Business Development Centers (SBDCs), Women's Business Centers and SCORE volunteer mentors, with no-cost advice, often in Spanish too. They help you build your plan and find financing, including microloans from community development financial institutions (CDFIs).



#### A case in one minute

Daniela booked a no-cost appointment with an SBDC. With her advisor she filled in her page using her records and practiced her pitch. She got a microloan from a CDFI with a payment schedule that fit her cash flow.

> **Key idea:** your plan fits on one page and your pitch in two minutes; with numbers from your records and no-cost advice, seek financing from verified sources, and if you hear no, ask what to improve.



#### Check your understanding

1. What numbers go in your pitch?
*Answer:* Sales, margin and break-even point.

2. Where do you get no-cost help with your plan?
*Answer:* At an SBDC, a Women's Business Center or SCORE.


#### Remember

- One page, seven questions.
- Two minutes, five parts.
- No-cost advice; no one charges to "guarantee" a loan.



### Go deeper (5 more minutes)

#### Crowdfunding

In donation or reward crowdfunding, people contribute in exchange for a product or to support you. If you offer investors a share of your business, it must go through a funding portal registered with the SEC. Check fees and what you promise.



#### Fake loans and grants

No one should charge you up front to "approve" a loan or give you a government grant. The SBA doesn't call to ask for payments. Look up programs at sba.gov.

> **Before you act, check:** that the program is on an official site (.gov) and that the lender is a registered institution or a certified CDFI.



#### Cases


**Case 1. Daniela's microloan**

Daniela is asked for a business plan and a short pitch.
- *What does she do?* She gets no-cost help at an SBDC and fills in her plan with her records.


**Case 2. Javier's "grant"**

A caller offers Javier a federal grant if he pays a $300 processing fee.
- *What does he do?* He doesn't pay: grants don't charge fees; he searches sba.gov.


**Case 3. Lupita's "no"**

The bank turned down Lupita's loan for a bigger kitchen.
- *What does she do?* She asks why, improves her records and looks for a CDFI.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Plan without numbers | Not convincing | Your records |
| Long pitch | You lose attention | Two minutes |
| Paying up front | Scam | Official site |
| Giving up after one no | You miss the chance | Ask what to improve |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Javier and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What comes first in your pitch? a) The problem you solve and for whom · b) What you need · c) Your whole life story
2. You're asked for $300 to "approve" a federal grant. What is it? a) A normal fee · b) A deposit · c) A scam
3. Your loan is denied. What do you do? a) Take an expensive cash advance · b) Ask why and get help to try again · c) Stop trying
**Answers:** 1-a: that's how they understand your business. 2-c: no one charges for a grant. 3-b: a no teaches you too.



#### Put it into practice

You sell $6,000 a month with a 30% margin. How much do you keep to cover your fixed costs?
**Answer:** $1,800.



#### Your plan

Fill in your one-page business plan and book a no-cost appointment with an SBDC or SCORE.



### Learn more

- **Business counseling** (SBA · English and Spanish): https://www.sba.gov | What to look for: "SBDC", "Women's Business Center" and "SCORE".
- **Certified CDFIs** (CDFI Fund · English): https://www.cdfifund.gov.

### Key words

- *Business plan:* a summary of what you sell, to whom, what you earn and what you need.
- *CDFI:* a community development financial institution that lends to businesses traditional banks don't serve.
- *Mentor:* an experienced person who advises you at no cost.

### Sources

SBA · SCORE · CDFI Fund · SEC, accessed September 30, 2026.

---

## M8 U06. Your business and its surroundings: competition, economy, community and rule changes

**What you will be able to do:** Keep track of what happens around your business (competition, prices, rates, laws and your community), get information from reliable sources and adjust your plan in time.

**To start:** Two new food trucks arrived on Don Ramón's street, the county health permit went up and an IRS rule changed. Don Ramón found out late about all of it. In this lesson you'll see how to stay informed without getting overwhelmed.

### The essentials (5 minutes)

#### What you watch

| Type | Description | What it means for you |
|---|---|---|
| Competition | Who arrives, what they sell and at what price. | What makes you different. |
| Economy | Inflation and interest rates. | Your costs and loans. |
| Laws and rules | IRS, state, county and city. | Deadlines and obligations. |
| Your community | Road work, events, seasons. | Opportunities and risks. |

#### Reliable sources

For taxes and rules: official IRS, state, county and city websites. For the economy: the Federal Reserve and the BLS. To learn: the SBA, SBDCs and Hispanic chambers of commerce. Social media rumors are not a source.



#### A case in one minute

Don Ramón set aside 15 minutes every Monday to check competitors' prices and county notices. Facing the new trucks, he added phone orders for nearby offices and changed his hours. His sales recovered in three months.

> **Key idea:** watch competition, the economy, laws and your community through reliable sources, and adjust your plan in time.



#### Check your understanding

1. Where do you confirm a tax rule change?
*Answer:* On the official IRS or state website.

2. What do you do if new competition arrives?
*Answer:* See what makes you different and adjust your offer.


#### Remember

- Four things to watch.
- Official sources.
- 15 minutes a week.



### Go deeper (5 more minutes)

#### Your business has an impact too

Your business creates jobs, buys from local suppliers and shares the street with your neighbors. Taking care of trash, noise and fair treatment also protects your reputation and your customers.



#### Keep learning

Figure out what you still need to know (taxes, online sales, costs) and look for no-cost training: SBDCs, SCORE, public libraries and community colleges. If you have staff, share what you learn.

> **Before you act, check:** any law or procedure change on the official site and, if it affects you, ask your tax preparer.



#### Cases


**Case 1. The new trucks**

Two food trucks arrived on Don Ramón's street.
- *What does he do?* He sees what makes him different and adjusts his service and hours.


**Case 2. Javier's warning**

A group chat says "the IRS now taxes every Zelle payment."
- *What does he do?* He checks the IRS website and his tax preparer before acting.


**Case 3. Lupita's road work**

The city will repair Lupita's street for a month.
- *What does she do?* She plans with her reserve and tells customers how to pick up.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Finding out late | You lose sales | 15 minutes a week |
| Believing rumors | Bad decisions | Official source |
| Competing only on price | Margin slips away | What makes you different |
| Ignoring the community | You lose reputation | Good neighbor |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Javier and Lupita. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. New competition arrives on your street. What do you do? a) Cut prices even at a loss · b) See what makes you different and adjust your offer · c) Close
2. Social media says an IRS rule changed. What do you do? a) Check the IRS website and your tax preparer · b) Stop accepting app payments · c) Share it with all your customers
3. Where do you check inflation? a) In a bank ad · b) In a social media group · c) At the BLS
**Answers:** 1-b: compete with what sets you apart. 2-a: confirm first. 3-c: official source.



#### Put it into practice

You review your surroundings 15 minutes every week. How many hours is that a year?
**Answer:** 13 hours (15 × 52 = 780 minutes).



#### Your plan

Set aside 15 minutes a week to check competition, official notices and your costs.



### Learn more

- **Small business taxes** (IRS · English and Spanish): https://www.irs.gov.
- **Consumer Price Index** (BLS · English): https://www.bls.gov/cpi.
- **Training** (SBA · English and Spanish): https://www.sba.gov.

### Key words

- *Surroundings:* what happens around your business and affects it: competition, economy, laws and community.
- *Reputation:* what your customers and neighbors think of your business.

### Sources

IRS · BLS · Federal Reserve · SBA, accessed September 30, 2026.

---


# Part 10. Module 9. Your future

## M9 U01. Your retirement when you work for yourself

**What you will be able to do:** Learn how to save for retirement when you're self-employed: Social Security, IRAs, SEP IRAs and Solo 401(k)s.

**To start:** Don Ramón is 60. He thinks "the food truck is his retirement," but he doesn't know how much he'd get from Social Security or whether it's enough. In this lesson you'll see your options.

### The essentials (5 minutes)

#### Your business isn't your retirement

Your business depends on you working. If you get sick or tired, it may stop paying. That's why you need retirement savings **separate** from the business.



#### Social Security

The self-employment tax you pay (M5 U03) counts toward your Social Security. To qualify for a retirement benefit, you generally need 40 credits (about 10 years of work). Check your record and estimate in my Social Security (ssa.gov).

> **Current fact:** in 2026 you earn one Social Security credit for every $1,890 in earnings, up to 4 credits a year ($7,560). Accessed September 29, 2026 through the Social Security Administration (SSA).



#### Retirement accounts for the self-employed

| Type | Description | What it means for you |
|---|---|---|
| Traditional or Roth IRA | For anyone with earnings. | Up to $7,500 in 2026 ($8,600 at 50 or older). |
| SEP IRA | Easy for owners to open. | Up to 25% of adjusted profit, maximum $72,000. |
| Solo 401(k) | For owners with no employees. | $24,500 as the employee plus the business's contribution, maximum $72,000. |
| Only the business | Depends on your health. | Risky. |

> **Current fact:** for 2026, the IRA contribution limit is $7,500 ($8,600 at age 50 or older); a SEP IRA allows up to 25% of compensation and a maximum of $72,000; and a Solo 401(k) allows $24,500 as the employee and $72,000 in total, not counting age-based catch-up contributions. Accessed September 29, 2026 through the IRS.

#### A case in one minute

Don Ramón checked his account at ssa.gov: he has 52 credits and an estimate of $1,300 a month at 67. He opened an IRA and contributes $300 a month. He knows that each year he waits to claim, his monthly benefit goes up.

> **Key idea:** keep your retirement separate from your business; check your Social Security and put something into a retirement account every month.



#### Check your understanding

1. How many credits do you generally need for a Social Security retirement benefit?
*Answer:* 40 credits.

2. Which retirement account can anyone with earnings open?
*Answer:* A traditional or Roth IRA.


#### Remember

- Retirement separate from the business.
- Check ssa.gov.
- A fixed contribution every month.



### Go deeper (5 more minutes)

#### Tax advantages

Contributions to a traditional IRA, SEP or Solo 401(k) can lower your taxes today; with a Roth you pay taxes today and withdraw without taxes in retirement, if you follow the rules. Withdrawing before age 59½ usually carries a penalty. Ask your preparer which one fits you.



#### If you file with an ITIN

Earnings are recorded with Social Security under a Social Security number. If you currently file with an ITIN, ask the SSA or a professional how your earnings might be recognized in the future. Some institutions open IRAs with an ITIN.



#### CalSavers

In California, CalSavers is the state retirement savings program. Employers with employees and no other plan must offer it, and it's also open to self-employed people.



#### Cases


**Case 1. Don Ramón's retirement**

Don Ramón doesn't know how much he'd get from Social Security.
- *What does he do?* He checks his record and estimate at ssa.gov.


**Case 2. Javier's SEP**

Javier did well this year and wants to pay less tax and save.
- *What does he look at?* Opening a SEP IRA or Solo 401(k) with his tax preparer.


**Case 3. Daniela's savings**

Daniela is 27 and thinks it's too early for retirement.
- *What does she do?* She starts with a small, fixed IRA contribution.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| The business as a pension | No income if it fails | Separate savings |
| Not checking ssa.gov | Surprises | Check your record |
| Withdrawing early | Penalties | Let it grow |
| Starting late | Less savings | Start small |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Javier and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you check your Social Security record? a) At your bank · b) At ssa.gov · c) At the IRS
2. How much can you put in an IRA in 2026 if you're under 50? a) $72,000 · b) $24,500 · c) $7,500
3. Why isn't the business enough for retirement? a) It depends on you being able to work · b) Because small businesses don't pay taxes · c) Because it's small
**Answers:** 1-b: official site. 2-c: 2026 limit. 3-a: your health changes.



#### Put it into practice

You put $200 a month in an IRA for 25 years, not counting returns. How much did you contribute?
**Answer:** $200 times 300 months: $60,000.



#### Your plan

Create your ssa.gov account, check your estimate and set a monthly retirement contribution.



### Learn more

- **my Social Security** (SSA · English and Spanish): https://www.ssa.gov | What to look for: "my Social Security".
- **Retirement plans for self-employed people** (IRS · English): https://www.irs.gov | What to look for: "retirement plans for self-employed".
- **CalSavers** (English and Spanish): https://www.calsavers.com | What to look for: "self-employed".

### Key words

- *Social Security credit:* a unit you earn from your earnings; you need 40 for a retirement benefit.
- *IRA:* an individual retirement account with tax benefits.
- *SEP IRA:* a retirement account for business owners and their employees.

### Sources

SSA · IRS · CalSavers, accessed September 29, 2026.

---

## M9 U02. If the business changes or you're not there

**What you will be able to do:** Prepare to close, pause or hand over your business, and leave your information in order in case you're not there.

**To start:** Lupita was sick for three weeks and her daughter didn't know which supplier to pay, where the accounts were or how to collect on orders. In this lesson you'll see how to prepare your business for changes.

### The essentials (5 minutes)

#### Three situations

| Type | Description | What it means for you |
|---|---|---|
| Pause | Season, illness, move. | Give notice and get organized. |
| Close | The business no longer pays. | Formal closing. |
| Hand over | To a relative or someone else. | Written agreement. |
| If you're not there | Nobody knows what to do. | Leave your information in order. |

#### Your business folder

1. List of suppliers, customers and contacts.
2. Business accounts and who can operate them (no written passwords).
3. Debts, loans and pending payments.
4. Tax numbers, permits, tax preparer and dates.
5. Insurance and beneficiaries.



#### A case in one minute

Lupita put together a folder with suppliers, accounts, payment dates and her preparer's contact. She added her daughter as an authorized user on the business account. The next time she was out, orders kept going.

> **Key idea:** put in one folder what someone would need to keep your business running, or to close it, without you.



#### Check your understanding

1. What goes in your business folder?
*Answer:* Suppliers, accounts, debts, tax information, permits, insurance and contacts.

2. Why not write down passwords?
*Answer:* Because if someone finds the folder, they can steal your accounts.


#### Remember

- Pause, close or hand over in an orderly way.
- Business folder.
- Never written passwords.



### Go deeper (5 more minutes)

#### Closing properly

File your last return and mark it as final if it applies, cancel your seller's permit and licenses and, if you have an LLC, formally dissolve it: in California, if you don't, the $800 minimum tax keeps running every year.



#### Handing over the business

If a relative will continue the business, agree in writing on when, under what conditions and what happens with equipment, inventory and debts. Permits and licenses are almost always in your name and must be applied for again.



#### Will and beneficiaries

The business's equipment, inventory and money are part of your estate. A will or living trust and up-to-date beneficiaries on accounts, IRAs and insurance spare your family long proceedings. There cost nothing or low-cost legal clinics.

> **Before you act, check:** the steps to close with the IRS, your state and your city, and talk to an attorney about a will or transfer.



#### Cases


**Case 1. Lupita's illness**

Lupita's daughter didn't know how to keep orders going.
- *What does Lupita prepare?* A folder with suppliers, accounts, payments and contacts.


**Case 2. Daniela's LLC**

Daniela will stop selling and won't use her LLC anymore.
- *What does she do?* She formally dissolves it so she doesn't keep paying $800 a year.


**Case 3. Don Ramón's food truck**

Don Ramón wants his daughter to take over the food truck in a few years.
- *What does he do?* He makes a written agreement and reviews his will or trust.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Everything in your head | Nobody can continue | Folder |
| Written passwords | Account theft | Authorizations |
| Leaving the LLC open | $800 a year | Dissolve it |
| Handing over by word of mouth | Family conflict | In writing |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Lupita, Daniela and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You close your California LLC business. What do you do? a) Nothing: you just stop selling until you come back · b) Close the bank account and that's it · c) Formally dissolve it so you stop owing the minimum
2. What should not be written in your business folder? a) Your passwords · b) The list of suppliers · c) The payment dates
3. How do you hand the business over to a relative? a) By word of mouth · b) With a written agreement · c) Without telling anyone
**Answers:** 1-c: the minimum keeps running. 2-a: theft risk. 3-b: avoids conflict.



#### Put it into practice

You forget to dissolve your California LLC for 3 years with no activity. How much minimum tax could you owe, not counting penalties?
**Answer:** $2,400.



#### Your plan

Put together your business folder and tell someone you trust where it is.



### Learn more

- **Closing a business** (IRS · English): https://www.irs.gov | What to look for: "closing a business".
- **Dissolving an LLC** (California Secretary of State · English): https://bizfileonline.sos.ca.gov | What to look for: "dissolution".

### Key words

- *Living trust:* a legal document to pass on your assets without long court proceedings.
- *Dissolution:* the formal process to close a company.

### Sources

IRS · California Secretary of State · Franchise Tax Board, accessed September 29, 2026.

---

## M9 U03. Your one-page plan

**What you will be able to do:** Bring together on one page the decisions from the course: money, price, cash flow, formality, protection and future.

**To start:** Daniela learned a lot, but it's in scattered notes. She wants one page she can pin next to her worktable. In this lesson you'll put together your one-page plan.

### The essentials (5 minutes)

#### Why one page

One page forces you to choose what matters. You pin it where you can see it and review it every three months.



#### Your one-page plan

| Topic | My decision |
|---|---|
| Separate money | Business account: ___ · Tax account: ___ · My salary: ___ |
| Price | Cost of my main product: ___ · Price: ___ · Margin: ___ |
| Break-even point | ___ a month · ___ a day |
| Cash flow | Reserve goal: ___ · % I set aside: ___ · Credit rules: ___ |
| Getting paid | Payment methods: ___ · Anti-scam plan: yes / no |
| Formality | Structure: ___ · EIN and permits: ___ · Estimated payment dates: ___ |
| Credit | Do I need it? ___ · APR and total repayment: ___ |
| Protection | Health insurance: ___ · Business insurance: ___ · Trademark: ___ |
| Monthly numbers | Review on day ___ |
| Future | Social Security checked: yes / no · Retirement account: ___ · Folder: yes / no |
| My commitment | Goal: ___ · Amount: ___ every ___ · Witness: ___ · Reminder: day ___ |



#### Review every three months

Set a fixed date, for example alongside your estimated payments. Update the numbers, check whether you followed through and change one decision if needed.



#### A case in one minute

Daniela filled in her page in one afternoon. Two things were missing: her retirement account and checking her trademark. She made them goals for next quarter.



#### Your commitment

Choose one goal for the quarter with a name ("two-month reserve for winter"), how much you'll set aside and how often. Tell someone you trust or your community group. Set up an automatic transfer on the day you get paid and a monthly reminder with your goal's name.

> **Key idea:** your plan fits on one page; review it every three months, improve one thing at a time and keep your commitment with a name, a witness and a reminder.



#### Check your understanding

1. How often do you review your plan?
*Answer:* Every three months.

2. What do you do if something is missing?
*Answer:* Make it a goal for next quarter.


#### Remember

- One page.
- Where you can see it.
- Quarterly review.



### Go deeper (5 more minutes)

#### Prioritize

If a lot is missing, start with: 1) separating money and setting aside taxes, 2) a price with margin, 3) a reserve, 4) health and business insurance. The rest can wait a few months.



#### Share it

Share your plan with someone you trust or in the community (with no personal data or real amounts). A no-cost adviser from an SBDC or SCORE can also review it with you.



#### Why it works

Studies in several countries found that naming a goal, committing to someone and getting a monthly reminder with that goal helps people save more. Setting money aside automatically, before you see it, also helps.



#### Cases


**Case 1. Daniela's page**

Daniela is missing her retirement account and her trademark.
- *What does she do?* She makes them goals for next quarter.


**Case 2. Javier's priorities**

Javier has many pending tasks and doesn't know where to start.
- *What does he do?* He starts by separating money, setting aside taxes and his price.


**Case 3. Don Ramón's review**

Don Ramón made his plan three months ago and hasn't reviewed it.
- *What does he do?* He sets a fixed date and updates his numbers.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Scattered notes | They get forgotten | One page |
| Wanting everything at once | You get overwhelmed | Prioritize |
| Not reviewing | It gets outdated | Every three months |
| Keeping it in a drawer | You don't see it | Pin it up |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Javier and Don Ramón. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. How often do you review your one-page plan? a) Every three months · b) Once in a lifetime · c) Every day
2. Where do you start if a lot is missing? a) Registering your trademark · b) Separating money and setting aside taxes · c) Taking out a loan to get everything organized at once
3. What do you share in the community? a) Your real amounts, accounts and monthly sales · b) Your Social Security number · c) Your plan with no personal data
**Answers:** 1-a: quarterly review. 2-b: the foundation. 3-c: no data.



#### Put it into practice

You review your plan every three months. How many reviews do you do in two years?
**Answer:** 8.



#### Your plan

Fill in your one-page plan and set the date of your first review.



### Learn more

- **No-cost advice** (SBA · English): https://www.sba.gov | What to look for: "SBDC" and "SCORE".

### Key words

- *One-page plan:* a summary of your business decisions on one page.
- *Quarterly review:* reviewing your plan every three months.

### Sources

SBA, accessed September 29, 2026 · Innovations for Poverty Action and J-PAL, "Nudges for Financial Health."

---

## M9 U04. If you're not there: beneficiary accounts, your home, digital access and taxes

**What you will be able to do:** Complete your succession plan in the U.S.: beneficiary accounts, transfer on death deed, small estates, the business's digital access, taxes when inheriting, and what you own in Mexico.

**To start:** Don Ramón has his food truck, a business account, a house in Sacramento and land in Michoacán. His daughter believes that if he dies "the IRS takes half" and the house will spend years in court. In this lesson you'll see what's true and what to prepare.

### The essentials (5 minutes)

#### Passing things on without court

| Type | Description | What it means for you |
|---|---|---|
| Payable-on-death (POD) accounts | Bank and credit union accounts. | They pass directly. |
| Transfer-on-death (TOD) investments | Brokerage accounts and IRAs. | They pass directly. |
| Transfer on death deed | In California, for your home. | Avoids probate. |
| Living trust or will | For everything else. | With a lawyer. |
| Digital | Accounts, platforms, social media. | Who has access. |

#### Taxes when inheriting

Heirs **don't pay federal tax** for receiving an inheritance. The federal estate tax only applies to estates over 15 million dollars per person in 2026, and California has no inheritance tax. If your heirs sell what they inherit, the gain is measured from its value when you died, which usually lowers the tax.

> **Current fact:** the federal estate tax only applies to estates over 15 million dollars per person in 2026; California has no inheritance tax. Accessed September 30, 2026 through the IRS and specialized media.



#### If you own something in Mexico

Receiving an inheritance in Mexico pays no income tax (ISR), but putting land or a house in your name does cost money (state tax and notary). If your heirs live in the U.S. and receive a foreign inheritance of more than 100,000 dollars, they must report it to the IRS on Form 3520, even though they owe no tax; the penalty for not filing can reach 25% of the value. Mexican consulates offer notary services, including wills.



#### A case in one minute

Don Ramón named his daughter as POD beneficiary on his accounts, reviewed a transfer on death deed for his home with a lawyer, made a will at the consulate for the land in Michoacán and wrote down who can access the business accounts.

> **Key idea:** with beneficiaries on your accounts, a transfer on death deed for your home and a will or living trust, your family avoids court; inheriting pays no federal tax except for huge estates, but a large foreign inheritance is reported on Form 3520.



#### Check your understanding

1. Do heirs pay federal tax?
*Answer:* No; the estate tax only applies to estates over 15 million.

2. What is Form 3520?
*Answer:* A report to the IRS of foreign inheritances or gifts over 100,000 dollars.


#### Remember

- POD and TOD on your accounts.
- Transfer on death deed for your home.
- Form 3520 if you inherit from abroad.



### Go deeper (5 more minutes)

#### Your succession map

| Asset | How it passes without court |
|---|---|
| Bank or credit union account | POD beneficiary |
| Investment account or IRA | TOD or named beneficiary |
| House in California | Transfer on death deed or living trust |
| Equipment and business | Will or living trust, partner agreement |
| House or land in Mexico | Will (notary or consulate); succession list if ejido land |
| Digital accounts | Access instructions stored safely |



#### Small estates

If what you leave is small, California has a small estate affidavit that avoids probate. The limit changes every few years: ask the court or a lawyer.



#### Cases


**Case 1. Half for the IRS**

Don Ramón's daughter thinks the IRS will take half of the inheritance.
- *What does she learn?* That heirs pay no federal tax, except on huge estates.


**Case 2. The land in Michoacán**

Lupita's nephew, who lives in Los Angeles, will inherit land in Mexico worth 120,000 dollars.
- *What does he do?* He files Form 3520 with the IRS even though he owes no tax.


**Case 3. Daniela's account**

Daniela has no beneficiary on her business account.
- *What does she do?* She names a POD beneficiary at her bank.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing the IRS takes half | Needless fear | Only huge estates |
| Not naming beneficiaries | Long probate | POD and TOD |
| Not reporting foreign inheritances | High penalties | Form 3520 |
| Leaving land in Mexico without a will | Family fights | Notary or consulate |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Don Ramón, Lupita's nephew and Daniela. Choose the best decision in each; if you miss, you can try again. Earn experience points.



#### Quiz

1. Does someone who inherits 200,000 dollars pay federal tax? a) Yes, 40% · b) No · c) Yes, 10%
2. What keeps a bank account out of court? a) Changing the password · b) Withdrawing it all in cash · c) Naming a POD beneficiary
3. You inherit land in Mexico worth 150,000 dollars. What do you do with the IRS? a) File Form 3520 · b) Nothing · c) Pay 30% tax
**Answers:** 1-b: the estate tax is for huge estates. 2-c: it passes directly. 3-a: it's an information report.



#### Put it into practice

If you don't file Form 3520 for a 120,000-dollar inheritance, what would the maximum 25% penalty be?
**Answer:** 25% of 120,000: 30,000 dollars.



#### Your plan

Check whether your accounts have a POD or TOD beneficiary and list what you own in Mexico.



### Learn more

- **Gifts and inheritances from abroad** (IRS · English): https://www.irs.gov | What to look for: "Form 3520" and "gifts from foreign person".
- **Small estates and transfer on death deeds** (California Courts · English and Spanish): https://selfhelp.courts.ca.gov | What to look for: "small estate" and "transfer on death deed".
- **Consular notary services** (Mexican Ministry of Foreign Affairs · Spanish): https://www.gob.mx/sre | What to look for: "testamento en consulado".

### Key words

- *POD and TOD:* beneficiary designation on an account that passes directly when you die.
- *Probate:* court process to distribute the property of someone who died.
- *Form 3520:* IRS report of foreign inheritances or gifts over 100,000 dollars.

### Sources

IRS · California Courts · Mexican Ministry of Foreign Affairs · SAT, accessed September 30, 2026.

---


# Part 11. Support materials

## Welcome

**Your Business, Your Money, Your Future · U.S.** is a financial well-being program for Latino entrepreneurs and self-employed people in the United States.

Here you'll learn to separate business and household money, set prices, manage your cash flow, get paid without losing, formalize and pay your taxes without fear, use credit carefully, protect your business and plan for your future.

You don't need to know about finance or taxes. Each lesson starts from a real situation and ends with an action you can take this week. We use federal rules and California examples; if you live in another state, we tell you what to check.

Version 1.2 · September 2026. Also available in Spanish.

### How each module works

| Part | What you'll find | Time |
|---|---|---|
| **Lesson book** | Each lesson starts with a cover page where you choose your path. | 5 or 10 minutes per lesson |
| **What would you do?** | One activity per lesson: three situations to choose the best decision. | 3 minutes |
| **Module self-assessment** | Questions from all the module's lessons. You pass with 70% and can try as many times as you want. | 10 to 15 minutes |

### Choose your path in each lesson

- **Quick path (5 min):** read *The essentials* and go to *Practice*.
- **Full path (10 min):** add *Go deeper*, with cases, common mistakes and more facts.

### The characters

- **Lupita** (41): sells tamales and catering orders from home in Los Angeles.
- **Javier** (38): painter and handyman in Fresno.
- **Daniela** (27): sells jewelry on social media and a platform from San José.
- **Don Ramón** (60): runs a food truck in Sacramento.

### Three program rules

1. **We will never ask for your personal or tax data or your immigration status**: no SSN, ITIN, EIN, passwords or account numbers. If someone asks in the program's name, it's a scam.
2. **We don't sell you anything.** Lessons contain no recommendations of banks, processors, platforms or loans.
3. **Orientation, not advice.** Review your tax situation with a tax preparer or CPA, and immigration questions with an attorney or accredited organization.

### Facts change

Limits, rates and rules change every year. The program's facts were checked on **September 29, 2026**, and each one names its source. Before deciding, check the **IRS**, your state or the institution's official site.

### Points, levels and badges

You earn points for each completed activity. There are six levels (Idea, Launch, Up and running, Formal, Growing and Established) and eight badges. Nobody sees your name on a leaderboard.

### Certificate

When you pass all nine self-assessments you get the **Full plan** badge and your **certificate of completion** with a verification code. It's educational recognition from the program; it's not a license or an official accreditation.


## Case studies

The cases use made-up data. Amounts are in dollars. Solve each case before opening the key.

### E1. Lupita's tamales (Modules 1 and 2)

**Data.** Lupita sells $4,200 a month. She spends $1,800 on ingredients and packaging (variable) and has $700 in fixed costs. She sells about 140 dozen a month at $30. She sets nothing aside for taxes.

**Tasks.**

1. How much does she earn before taxes?
2. If she sets aside 25% for taxes, how much is that?
3. How much does each dozen cost her in ingredients?
4. How much does each dozen leave after ingredients, and how many does she need to sell a month to cover fixed costs?

**Key.**

- $4,200 minus $1,800 minus $700: $1,700.
- 25% of $1,700: $425.
- $1,800 divided by 140: about $12.86.
- $30 minus $12.86: about $17.14; $700 divided by $17.14: about 41 dozen.

### E2. Javier's quarter (Modules 3 and 4)

**Data.** Javier has $900 in the business account. He finished a $4,500 job that will be paid in 30 days. He needs $1,200 of paint now and his $1,100 estimated payment is due in three weeks. A new customer sends a $2,500 check for a $1,500 job and asks for $1,000 back.

**Tasks.**

1. Can he cover the paint and the estimated payment without collecting?
2. Which two actions improve his cash flow?
3. What does he do with the check?
4. When is his next estimated payment due if it's August 2026?

**Key.**

- $900 against $2,300: he's $1,400 short.
- Ask for a deposit on the next job and terms at the paint store.
- He doesn't deposit it or send anything back; he asks for the exact payment. It's the overpayment scam.
- September 15, 2026.

### E3. Daniela's taxes (Modules 5 and 8)

**Data.** Daniela sold $30,000 in the year: $22,000 on a platform (over 200 transactions) and $8,000 on her own site. Her costs and fees totaled $14,000. Her net profit was $16,000.

**Tasks.**

1. Does she get a 1099-K from the platform?
2. Does she report her own site's sales?
3. About how much is her self-employment tax?
4. Who collects sales tax on her platform sales, and who on her site's sales?

**Key.**

- Yes: over $20,000 and over 200 transactions.
- Yes: all income is reported.
- $16,000 times 92.35% times 15.3%: about $2,261.
- In general, the platform collects on its sales; she collects on her site.

### E4. Don Ramón's food truck (Modules 6, 7 and 9)

**Data.** Don Ramón gets two offers for $10,000: a 12-month credit union loan with $898 payments and a 6-month advance with a 1.35 factor. He's 60, has 52 Social Security credits and no retirement savings. His personal auto insurance doesn't cover the food truck.

**Tasks.**

1. How much does he repay with each offer?
2. Which is better?
3. What insurance does he need?
4. Which two retirement actions can he start this month?

**Key.**

- Loan: $898 times 12: $10,776. Advance: $13,500.
- The credit union loan: $2,724 less.
- Commercial insurance with auto, liability and equipment.
- Check his estimate at ssa.gov and open an IRA with a fixed contribution.


## Calculation practice

Solve each exercise showing your work. Answers are at the end.

| Key | Lesson | Exercise |
|---|---|---|
| P01 | M1 U01 | Sales $3,200; materials $1,400; gas and fees $500. Profit? |
| P02 | M1 U03 | Average profit $2,400; 25% for taxes and $200 reserve. Salary? |
| P03 | M1 U04 | 450 business miles in March 2026. Deduction at the standard rate? |
| P04 | M2 U01 | Materials $7 per piece, fixed costs $500 a month, 250 pieces. Cost per piece? |
| P05 | M2 U02 | Cost $48. Price for a 20% margin on price? |
| P06 | M2 U03 | Fixed costs $4,500; each sale leaves 45%. Break-even point? |
| P07 | M4 U01 | $6,000 a month in cards at 2.9%. Monthly cost? |
| P08 | M5 U03 | Net profit $25,000. Approximate self-employment tax? |
| P09 | M5 U04 | Quarterly profit $6,000; you set aside 25%. Estimated payment? |
| P10 | M5 U05 | $3,000 in sales at a 9.5% rate. Sales tax? |
| P11 | M6 U03 | $8,000 advance at a 1.3 factor. Total repayment? |
| P12 | M7 U04 | Trademark in three classes at the base fee. Cost? |
| P13 | M8 U01 | 25 hours a week at $16.90 for 4 weeks. Wages? |
| P14 | M9 U01 | $5,000 in earnings in 2026. How many Social Security credits? |

### Answers

- **P01:** $3,200 minus $1,900: $1,300.
- **P02:** $2,400 minus $600 minus $200: $1,600.
- **P03:** 450 times 72.5 cents: $326.25.
- **P04:** $7 plus $2: $9.
- **P05:** $48 divided by 0.80: $60.
- **P06:** $4,500 divided by 0.45: $10,000.
- **P07:** $174.
- **P08:** $25,000 times 92.35% times 15.3%: about $3,532.
- **P09:** $1,500.
- **P10:** $285.
- **P11:** $10,400.
- **P12:** $1,050.
- **P13:** 100 hours times $16.90: $1,690.
- **P14:** $5,000 divided by $1,890: 2 credits.


## Glossary

Plain-language definitions of the course words, grouped by module.

### Your business and your home: separate money

- **Business account:** an account you use only to collect and pay for business things.
- **Compulsive gambling:** when you can't stop betting even though it causes problems.
- **Economic abuse:** when another person controls, withholds or uses your money or property to dominate you.
- **Economic autonomy:** being able to earn, keep and decide about your own money.
- **FDIC:** federal agency that insures bank deposits.
- **Owner's salary:** a fixed amount you transfer from the business to yourself every week or two weeks.
- **Profit:** what is left from sales after paying all the business costs.
- **Record:** a list of what comes in and goes out of the business, with date and item.
- **Sales:** everything you charge your customers, before subtracting what it cost you.
- **Sole proprietor:** a person who owns a business in their own name, without creating a separate company.
- **Standard mileage rate:** the amount the IRS lets you deduct for each business mile driven.
- **Sweepstakes casino:** a site that simulates betting with virtual coins redeemable for money; banned in California since 2026.
- **Weekly check:** adding up sales and expenses for a period to know how much you earned.

### Costs and price

- **Break-even point:** minimum sales to cover all your costs: you neither earn nor lose.
- **Contribution margin:** what is left of each sale after paying its variable costs, to cover fixed costs.
- **Cost per unit:** what it costs you to make or sell one piece, dish or service, counting variable costs and a share of fixed costs.
- **Fixed cost:** an expense you pay whether you sell or not, like a subscription or your salary.
- **Floor price:** the minimum price that covers your cost.
- **Inventory:** merchandise or supplies you bought and haven't sold yet.
- **Margin:** the part of the price left after covering the cost.
- **Turnover:** how fast a product sells.
- **Variable cost:** an expense that goes up with each sale, like materials or packaging.
- **Waste:** merchandise that spoils, breaks or gets lost and can no longer be sold.

### Cash flow

- **Business reserve:** money set aside to cover the business's fixed costs in slow months or emergencies.
- **Cash flow:** the money that actually comes into and goes out of the business, and when.
- **Deposit:** part of the payment the customer makes before you do the work.
- **Inflation:** a general rise in prices over time.
- **Invoice:** a document with what you sold, the amount and the payment due date.
- **Slow season:** months when your business sells less.
- **Small claims court:** a court for collecting small amounts without a lawyer.
- **Variable rate:** an interest rate that can change during the loan.

### Get paid and sell without losing

- **Chargeback:** when the customer's bank reverses a card payment because it is disputed or not recognized.
- **Overpayment scam:** a scam in which you're overpaid with a fake check and asked to send back the difference.
- **Payment processor:** a company that lets you take card payments and charges a fee.
- **Pending payment:** a payment that isn't available yet and may never arrive.
- **Supplier impersonation:** a scam in which someone poses as your supplier so you pay another account.
- **Two-step verification:** signing in with a password plus a code or approval on your phone.

### Formalize and handle taxes without fear

- **1099-K:** a form that reports payments through platforms and payment processors.
- **1099-NEC:** a form that reports payments for services to independent workers.
- **DBA:** the fictitious business name you operate under.
- **Deduction:** an expense subtracted from your income to figure your taxes.
- **EIN:** employer identification number: your business costs nothing number with the IRS.
- **Estimated payments:** tax payments you make each quarter on what you're earning.
- **IP PIN:** an IRS number that protects your return from identity theft.
- **ITIN:** individual taxpayer identification number, for people who can't get an SSN.
- **LLC:** limited liability company: a company registered in a state that separates your personal assets from the business's debts.
- **Marketplace facilitator:** a platform that collects and sends sales tax for the sellers on it.
- **QBI:** a deduction of up to 20% on a business's qualified profit.
- **Sales tax:** a tax you collect from your customer and send to the state.
- **Self-employment tax:** Social Security and Medicare paid by people who work for themselves.
- **Seller's permit:** a California permit to sell products and collect sales tax.

### Credit for your business

- **APR:** annual percentage rate: the yearly cost of credit, with interest and certain fees.
- **Authorized user:** a person who uses someone else's card; generally not responsible for the debt.
- **Cautious scenario:** a calculation with lower sales than expected.
- **CDFI:** a community development financial institution that lends to people and businesses with less access.
- **Cosigner:** a person who signs a loan and agrees to pay it if the borrower doesn't.
- **Credit union:** a nonprofit financial institution owned by its members.
- **Factor rate:** the number you multiply an advance by to get the total repayment.
- **Merchant cash advance (MCA):** money in exchange for a percentage of your future sales; very expensive.
- **Minimum payment:** the least you can pay on your card; the debt barely goes down.
- **Personal guarantee:** a promise that you'll pay if the business doesn't.
- **Reference:** a person who only gives their details; not obligated to pay.
- **Working capital:** money to run day to day: merchandise, supplies and payments.

### Protect your business

- **Artificial intelligence:** programs that imitate voices, faces or text very realistically.
- **Business interruption:** coverage that pays lost income when you can't work because of covered damage.
- **Certificate of insurance (COI):** a document that proves you have insurance.
- **Class:** the group of products or services a trademark registration covers.
- **Cloned voice:** a computer-made imitation of a person's voice.
- **Credit freeze:** a no-cost block so nobody can open new credit in your name.
- **Deductible:** what you pay before the insurance starts paying.
- **Disaster area:** an area declared by the government where federal help is activated.
- **Fraud alert:** a notice on your report so lenders verify your identity before giving credit.
- **General liability:** insurance that pays for damage you cause to other people or their property.
- **Government-imitation letter:** mail from a private company that looks official in order to charge you for services.
- **Identity theft:** using your information to pose as you and open accounts, get credit or file tax returns.
- **National Do Not Call Registry:** a no-cost federal registry so companies don't call you with sales pitches.
- **Open enrollment:** the time of year to buy or change your health insurance.
- **Premium:** what you pay each month for your insurance.
- **Trademark:** a name, logo or combination that identifies your product or service.
- **USPTO:** United States Patent and Trademark Office: it registers trademarks at the federal level.
- **Workers' compensation:** insurance that covers employees' on-the-job injuries.

### Grow in an orderly way

- **ABC test:** California's test to determine whether someone is an employee or a contractor.
- **Average ticket:** what each customer spends on average per purchase: sales divided by number of sales.
- **Business plan:** a summary of what you sell, to whom, what you earn and what you need.
- **Dashboard:** a table with the business's key numbers each month.
- **Financial stress:** constant worry about money that affects your sleep, health or relationships.
- **Gross payments:** the total collected before subtracting fees, refunds and costs.
- **Independent contractor:** a person who has their own business, decides how to do the work and works for several clients.
- **Mentor:** an experienced person who advises you at no cost.
- **Payroll taxes:** taxes the employer withholds and pays for its employees.
- **Platform:** a site or app that connects sellers and buyers and charges a fee.
- **Reputation:** what your customers and neighbors think of your business.
- **Surroundings:** what happens around your business and affects it: competition, economy, laws and community.

### Your future

- **Dissolution:** the formal process to close a company.
- **Form 3520:** IRS report of foreign inheritances or gifts over 100,000 dollars.
- **IRA:** an individual retirement account with tax benefits.
- **Living trust:** a legal document to pass on your assets without long court proceedings.
- **One-page plan:** a summary of your business decisions on one page.
- **POD and TOD:** beneficiary designation on an account that passes directly when you die.
- **Probate:** court process to distribute the property of someone who died.
- **Quarterly review:** reviewing your plan every three months.
- **SEP IRA:** a retirement account for business owners and their employees.
- **Social Security credit:** a unit you earn from your earnings; you need 40 for a retirement benefit.


## Where to get help

All options in this table are official or nonprofit. Information checked on September 29, 2026; confirm it on the official site.

| Need | Where | Cost | What to check |
|---|---|---|---|
| EIN, ITIN, estimated payments, 1099s | IRS: irs.gov | No cost | Go to the official site yourself |
| Preparing your return | VITA (moderate income); preparers with a PTIN; CPA | Paid or no-cost | That they sign and give you a copy |
| Business advice | SBDC and SCORE (SBA) | No-cost or low cost | Advisers from the official network |
| Permits in California | CalGold; your city and county | Varies | Official offices |
| Seller's permit and sales tax | CDTFA | Permit at no cost | Your city's rate |
| LLC and business name | Secretary of State; your county (DBA) | Paid | No middlemen |
| Contractor license | CSLB | Paid | $1,000 limit |
| Employers and minimum wage | EDD and DIR | No cost | ABC test |
| Loans | Banks, credit unions, CDFIs; SBA microloans (citizen owners only) | Depends on credit | License with the DFPI |
| Health insurance | Covered California, Medi-Cal, community clinics | Based on income | Certified enrollers |
| Scams | ReportFraud.ftc.gov; FBI IC3 | No cost | Keep evidence |
| Identity theft | IdentityTheft.gov | No cost | Recovery plan |
| Freeze your credit and see your reports | Equifax, Experian and TransUnion; AnnualCreditReport.com | No cost | At all three bureaus |
| Sales calls | Do Not Call Registry (donotcall.gov) | No cost | Never expires |
| Disasters | DisasterAssistance.gov (FEMA), sba.gov and irs.gov | No cost | Nobody charges to register you |
| Compulsive gambling | 1-800-GAMBLER | No cost | 24 hours |
| Emotional crisis | 988 Lifeline (call or text) | No cost | 24 hours, English and Spanish |
| Trademark | USPTO; state registry | Paid | Only uspto.gov |
| Retirement | ssa.gov; CalSavers | No cost | Your my Social Security account |
| Immigration questions | Attorneys or organizations accredited by the Department of Justice | Paid or no-cost | Never "notarios" |
| Business plan and financing | SBDCs, SCORE and Women's Business Centers (sba.gov); certified CDFIs | No cost | No one charges to "approve" a loan or grant |
| Economic abuse | National Domestic Violence Hotline: 1-800-799-7233 or text START to 88788 | No cost | 24 hours, English and Spanish |

---

## Frequently asked questions

**Can I take the course if I file with an ITIN or don't file yet?** Yes. The course explains how the system works. We never ask about your situation.

**Do I have to give real data about my business?** No. Use made-up numbers.

**Does the course tell me whether to open an LLC?** It explains what it protects and what it costs. You decide with your preparer or an attorney.

**Do you recommend a bank, processor or platform?** No. We teach you how to compare.

**What do I do if someone calls "from the IRS"?** Hang up and go to irs.gov yourself (M5 U04).

**What do I do if I'm overpaid and asked to send back the difference?** Don't send anything back: it's a scam (M4 U03).

**Is the certificate official?** It's educational recognition from the program. It isn't a license.

**What if a fact has changed?** Confirm it on the official site and use the current information.


## References

Sources used in the course, accessed September 29, 2026.

### Institutions

- **I01** IRS: EIN, ITIN (W-7), self-employment tax, Schedules C and SE, estimated payments (1040-ES), 1099-NEC and 1099-K, mileage rate, retirement limits, VITA, IP PIN.
- **I02** SBA: business structures, microloans, SBDC and SCORE.
- **I03** California Franchise Tax Board: LLC minimum tax and state tax.
- **I04** California Secretary of State: LLCs, Statement of Information, dissolution, state trademarks.
- **I05** CDTFA: seller's permit and sales tax.
- **I06** CalGold: permits by city and business type.
- **I07** CSLB: contractor license.
- **I08** EDD and DIR: employers, minimum wage, ABC test, disability insurance.
- **I09** DFPI: lender licenses and commercial financing disclosure.
- **I10** CFPB, FTC and IC3: payment apps, cosigning, fraud.
- **I11** FDIC and NCUA: deposit insurance.
- **I12** Covered California, DHCS and HealthCare.gov.
- **I13** USPTO: trademarks.
- **I14** SSA: credits and retirement estimate.
- **I15** CalSavers.
- **I16** California Courts: small claims.
- **I17** FTC: credit freezes, fraud alerts, IdentityTheft.gov and the National Do Not Call Registry; AnnualCreditReport.com.
- **I18** FEMA, SBA (disaster loans) and IRS (disaster relief).
- **I19** National Council on Problem Gambling (1-800-GAMBLER) and the 988 Suicide & Crisis Lifeline.

### Laws and rules

- **L01** One Big Beautiful Bill Act (July 4, 2025): 1099 thresholds and permanent QBI.
- **L02** Internal Revenue Code: self-employment tax and business deductions.
- **L03** California Assembly Bill 2622 ($1,000 limit for unlicensed work).
- **L04** California commercial financing disclosure law.

### Releases and media consulted

- **M01** IRS Notice 2026-10 and Internal Revenue Bulletin 2026-29 (mileage rate).
- **M02** IRS release on 2026 401(k) and IRA limits.
- **M03** Processors' published rates (2026).
- **M04** Federal Reserve and BLS: inflation goal and CPI; SBA, SCORE, CDFI Fund and SEC (crowdfunding).
- **M05** National Domestic Violence Hotline and CFPB (economic abuse); Innovations for Poverty Action and J-PAL, *Nudges for Financial Health*.


# Part 12. H5P activities "What would you do?"

One per lesson. The option marked ✔ is correct; on the platform options appear in random order.

## M1 U01. Is your business making money or just selling?

**Case 1. Lupita's month.** Lupita sold more than ever in December thanks to tamales, but she paid more for ingredients and help. **What does she do to know whether she made money?**

- ✔ Subtracts all the month's costs from her sales.
- Celebrates: she sold more than ever this month.
- Counts only what is left in her account.

**Case 2. Daniela's orders.** Daniela sold 90 pairs of earrings in a month, but paid for shipping she didn't charge. **What does she check?**

- ✔ Figures out how much she keeps per piece.
- Sells more earrings to make up for shipping.
- Raises every price without doing the math first.

**Case 3. Javier's hours.** Javier charges well for each painting job, but spends many unpaid hours driving and giving estimates. **What does he do?**

- ✔ Figures his hourly earnings including travel.
- Takes more jobs far away to earn more.
- Stops charging for estimates to compete.

## M1 U02. Keep business money separate from home money

**Case 1. Lupita's account.** Lupita receives business payments and her paycheck in the same account. **What does she do?**

- ✔ Opens an account just for the business.
- Keeps going and sorts it all out in April.
- Asks her customers to pay in cash.

**Case 2. Javier's supplies.** Javier buys paint with his household debit card. **What does he do?**

- ✔ Pays from the business and keeps the receipt.
- Leaves it as a household expense.
- Pays in cash without keeping the receipt.

**Case 3. Don Ramón's cash.** Don Ramón keeps the food truck's cash at home for weeks. **What does he do?**

- ✔ Counts it, logs it and deposits it often.
- Keeps it at home because it's convenient.
- Uses it for household bills and repays later.

## M1 U03. Pay yourself a salary

**Case 1. Lupita's great week.** Lupita sold three times as much in Christmas week. **What does she do?**

- ✔ Pays herself as usual and sets the extra aside.
- Takes all the extra home that week.
- Raises her salary starting that week.

**Case 2. Javier's months.** Javier earns $6,000 in summer and $2,000 in winter. **What does he do?**

- ✔ Pays himself based on his average.
- Pays himself more in summer and nothing in winter.
- Waits until year-end to see what to take.

**Case 3. Daniela's taxes.** Daniela spends all her profit and hasn't set anything aside for taxes. **What does she do from today on?**

- ✔ Sets aside a % of each profit for taxes.
- Waits until April to see what she owes.
- Takes out a loan when the bill arrives.

## M1 U04. Records in 10 minutes a day

**Case 1. Daniela's screenshots.** Daniela has hundreds of payment screenshots from the year. **What does she do?**

- ✔ Moves each payment to her sheet the same day.
- Keeps the screenshots and adds them up in April.
- Deletes old screenshots to make space.

**Case 2. Javier's miles.** Javier drives to give estimates every day and doesn't write anything down. **What does he do?**

- ✔ Logs date, destination, purpose and miles.
- Estimates his miles by eye in April.
- Keeps only his gas receipts.

**Case 3. Don Ramón's app.** A no-cost app asks Don Ramón for his Social Security number and his bank password to "do his books." **What does he do?**

- ✔ Doesn't give his password and picks another tool.
- Gives it because the app costs nothing.
- Gives only his Social Security number.

## M1 U05. Online betting: business money isn't for gambling

**Case 1. Javier's account.** Javier lost money betting and wants to use $300 of his tax money. **What does he do?**

- ✔ Doesn't touch that money and gets help.
- Uses the $300 and puts it back later.
- Bets double to win it back fast.

**Case 2. Daniela's sweepstakes casino.** A "sweepstakes casino" app offers Daniela bonus coins if she buys a package. **What does she check?**

- ✔ Checks that it's banned and keeps business money out.
- Buys the package: the coins cost nothing.
- Buys it with the business card.

**Case 3. Don Ramón's helper.** Don Ramón's helper asks for an advance to bet on the game. **What does he do?**

- ✔ Doesn't give it and shares where to get help.
- Gives it as a salary advance.
- Lends it with interest.

## M1 U06. Your business, your decisions: your money in your name

**Case 1. Lupita's app.** Lupita's partner collects the orders in his own app and decides everything. **What does she do?**

- ✔ Opens an account in her name and links her payments.
- Lets her partner keep collecting everything.
- Hides the cash in the kitchen.

**Case 2. Daniela's list.** Daniela thinks she has nothing to offer besides selling jewelry. **What does she do?**

- ✔ Lists her skills.
- Sticks to the jewelry she already sells.
- Copies what her competitors sell.

**Case 3. The loan in Javier's name.** Javier's brother asks for his Social Security number or EIN to get a loan "for the business." **What does he do?**

- ✔ Doesn't lend his numbers: the debt would be his.
- Lends them: he's family.
- Lends them if his brother signs a receipt.

## M2 U01. Fixed and variable costs

**Case 1. Daniela's earrings.** Daniela thinks she makes $19 a pair because materials cost $6 and she sells them for $25. **What is she missing?**

- ✔ Packaging, shipping, fees and fixed costs.
- Nothing: she knows she makes $19 a pair.
- Only the shipping cost of each order.

**Case 2. Javier's hour.** Javier charges $35 an hour, but doesn't know if it's enough. **What does he calculate?**

- ✔ His cost per hour with fixed costs and salary.
- What other painters charge per hour.
- The price of his most expensive tool.

**Case 3. Don Ramón's insurance.** Don Ramón pays the food truck insurance once a year and never counts it in his costs. **What does he do?**

- ✔ Divides it by 12 and adds it to fixed costs.
- Pays it when it comes and doesn't count it.
- Adds all of it to the month he pays it.

## M2 U02. How much should you charge?

**Case 1. Javier's price.** Javier charges the same as other painters, even though his costs are higher. **What does he do?**

- ✔ Figures his cost and sets a price with margin.
- Charges the same as the other painters.
- Lowers his rate to win more customers.

**Case 2. Daniela's sale.** Daniela wants to drop her earrings to $15 to sell more. **What does she check?**

- ✔ That $15 covers her cost and leaves margin.
- Nothing: lowering prices always raises profit.
- Only what the cheapest shop charges.

**Case 3. Lupita's price increase.** Masa and meat went up and Lupita's tamales barely make money. **What does she do?**

- ✔ Recalculates her cost and announces the increase.
- Makes smaller tamales without telling anyone.
- Waits for prices to drop on their own.

## M2 U03. Your break-even point

**Case 1. Don Ramón's spot.** Don Ramón's parking spot goes up $400 a month. **What does he do?**

- ✔ Recalculates his break-even and daily target.
- Keeps going: $400 isn't much.
- Gives more credit to sell more that month.

**Case 2. Lupita's tamales.** Lupita sells 6 dozen a week and her break-even is 8. **What does she do?**

- ✔ Raises sales or price, or lowers costs.
- Keeps going until the end of the year.
- Takes out a loan to cover the difference.

**Case 3. Daniela's shop.** Daniela wants to rent a small shop for $900 a month. **What does she calculate first?**

- ✔ How much more she'd need to sell.
- Nothing: a shop always sells more.
- Only whether the shop is in a good location.

## M2 U04. Inventory and waste

**Case 1. The deal for Don Ramón.** The supplier offers Don Ramón a no-cost case if he buys 10 of a product that sells slowly. **What does he do?**

- ✔ Buys only what he can sell in time.
- Buys the 10 cases for the no-cost one.
- Buys 20 to get two no-cost cases.

**Case 2. Lupita's ingredients.** Lupita throws out chiles and husks every week. **What does she do?**

- ✔ Logs what she throws out and buys less.
- Buys more to have variety.
- Keeps going; waste is normal.

**Case 3. Daniela's necklaces.** Daniela has 50 necklaces in a style that didn't sell. **What does she do?**

- ✔ Offers them at a discount and doesn't rebuy.
- Keeps them in case they sell again.
- Buys more of the same style cheaper.

## M3 U01. Profit isn't cash

**Case 1. Javier's late payment.** The contractor pays Javier in 30 days and he needs materials now. **What does he do?**

- ✔ Asks for a deposit and supplier terms.
- Takes a quick advance on his sales.
- Stops the job until he gets paid.

**Case 2. Don Ramón's purchase.** Don Ramón wants to buy all the supplies for a festival at once, which would leave him without cash for two weeks. **What does he do?**

- ✔ Buys in parts or on terms.
- Buys everything at once for the price.
- Uses his personal card for all of it.

**Case 3. Daniela's advance.** Daniela is $300 short to pay her supplier and an app offers her an advance on future sales. **What does she do first?**

- ✔ Checks her reserve and asks for more time.
- Takes the advance because it's fast.
- Pays with her household card.

## M3 U02. Customer credit, invoices and collections

**Case 1. Lupita's orders.** A customer orders 20 dozen for a wedding and promises to pay later. **What does she do?**

- ✔ Asks for 50% down and puts it in writing.
- Delivers everything and trusts they'll pay.
- Asks them to pay in cash later.

**Case 2. Javier's invoice.** A $1,200 invoice from Javier is 45 days late. **What does he do?**

- ✔ Reminds in writing and uses small claims.
- Posts the customer's name on social media.
- Stops talking to them until they pay.

**Case 3. Don Ramón's customer.** An office wants food from Don Ramón every Friday and to pay at the end of the month. **What does he do?**

- ✔ Agrees in writing, invoices and sets a limit.
- Agrees with no limit since it's an office.
- Turns the customer down for fear of not getting paid.

## M3 U03. Your reserve and slow seasons

**Case 1. Don Ramón's winter.** Don Ramón knows January and February are slow. **What does he do in summer?**

- ✔ Sets aside a % of each sale.
- Spends the summer money and sees what happens.
- Buys more inventory for winter.

**Case 2. Lupita's cash.** Lupita keeps her reserve in cash in her kitchen. **What does she do?**

- ✔ Moves it to an insured savings account.
- Leaves it in the kitchen; it's handy.
- Lends it to a neighbor so it grows.

**Case 3. Daniela's fee.** Daniela has an LLC and pays a yearly fee to the state. **What does she do starting in January?**

- ✔ Divides it by 12 and sets it aside monthly.
- Borrows when the fee comes due.
- Pays it from her tax savings.

## M3 U04. Inflation, interest rates and compound interest in your business

**Case 1. Don Ramón's burrito.** The burrito's cost went from $6.50 to $8 and Don Ramón still sells it for $12. **What does he do?**

- ✔ Reviews costs and raises prices a little, with notice.
- Leaves it the same so he won't lose customers.
- Doubles the price all at once.

**Case 2. Lupita's reserve.** Lupita has kept her business reserve in cash for two years. **What does she do?**

- ✔ Moves it to an insured, available account.
- Keeps it in cash so it's at hand.
- Invests it in whatever rose most last year.

**Case 3. Javier's credit line.** Javier is offered a variable-rate credit line for a van. **What does he do?**

- ✔ Calculates the payment with a higher rate.
- Signs: rates always go down.
- Opens another line in case it rises.

## M4 U01. Cash, card, apps or payment link

**Case 1. Don Ramón's reader.** Don Ramón is offered a "at no cost" reader with a two-year contract. **What does he do?**

- ✔ Figures the total cost and reads the contract.
- Accepts because the reader costs nothing.
- Rejects any reader as too expensive.

**Case 2. Lupita's payments.** Lupita collects her orders in her personal payment app. **What does she do?**

- ✔ Uses the linked business option.
- Stays on her personal app; nobody will notice.
- Asks everyone to pay in cash.

**Case 3. Daniela's link.** Daniela wants to charge customers she doesn't know with a payment link. **What does she check?**

- ✔ Fee, deposit time and chargebacks.
- Only the design of the payment link.
- Nothing: links are always safe.

## M4 U02. Safe app and transfer payments

**Case 1. Daniela's screenshot.** A customer sends Daniela a screenshot and asks her to ship now. **What does she do?**

- ✔ Ships when the payment is available.
- Ships on the screenshot so she doesn't lose the sale.
- Asks for a second screenshot and ships.

**Case 2. Lupita's email.** Lupita gets an email from "her payment app": a customer's payment is on hold until she pays $50. **What does she do?**

- ✔ Doesn't pay and checks inside the app.
- Pays the $50 to release the payment.
- Replies to the email with her details.

**Case 3. Javier's code.** A supposed customer asks Javier for the code he received "to confirm his identity." **What does he do?**

- ✔ Doesn't share it; his username is enough.
- Shares the code to get paid.
- Shares it if it's a regular customer.

## M4 U03. Scams when you sell

**Case 1. Javier's check.** A customer sends Javier a $2,500 check for a $1,500 job and asks for $1,000 back. **What does he do?**

- ✔ Doesn't deposit it and asks for the exact amount.
- Deposits it and sends $1,000 back when it shows.
- Sends back half while he checks.

**Case 2. Daniela's order.** A stranger orders 40 necklaces from Daniela with rush shipping to another state and pays by link. **What does she do?**

- ✔ Is wary and verifies before shipping.
- Ships fast so she doesn't lose the sale.
- Ships half and waits for the rest.

**Case 3. Don Ramón's supplier.** An email "from his meat supplier" asks him to pay the invoice to a new account. **What does he do?**

- ✔ Calls the number he already had.
- Pays the new account so he isn't late.
- Replies to the email to confirm.

## M5 U01. Sole proprietor, LLC or something else?

**Case 1. Javier's LLC.** A website charges Javier $299 to open a "required" LLC. **What does he do?**

- ✔ Compares costs and uses the official site.
- Pays the $299 because it's required.
- Opens three LLCs to separate his jobs.

**Case 2. Lupita's name.** Lupita sells as "Tamales Lupita" and is a sole proprietor. **What does she do?**

- ✔ Registers her business name with the county.
- Uses the name without registering anything.
- Forms a corporation to use the name.

**Case 3. Daniela's LLC account.** Daniela has an LLC, but takes payments in her personal account. **What does she do?**

- ✔ Opens an account just for the LLC.
- Keeps going; the LLC always protects her.
- Closes the LLC to keep it simple.

## M5 U02. Numbers and permits: EIN, ITIN and licenses

**Case 1. Lupita's EIN.** A website charges Lupita $150 to get her EIN. **What does she do?**

- ✔ Gets it no-cost at irs.gov with her ITIN.
- Pays the $150 to save time.
- Uses a friend's EIN.

**Case 2. Javier's big job.** Javier is offered a $4,000 bathroom remodel. **What does he check?**

- ✔ That he needs a CSLB license.
- Nothing: he splits the job into parts.
- Only that the client pays in cash.

**Case 3. Don Ramón's notario.** A "notario" offers to fix Don Ramón's immigration papers and permits for $2,000. **What does he do?**

- ✔ Looks for an attorney or accredited group.
- Pays the notario because he speaks Spanish.
- Pays half to get started.

## M5 U03. Your federal taxes as an owner

**Case 1. Daniela's surprise.** Daniela owes the IRS more than $2,000 and didn't set anything aside. **What does she do from today on?**

- ✔ Sets aside 25% and keeps receipts.
- Waits until April and pays what she can.
- Stops filing so she won't owe.

**Case 2. Javier's receipts.** Javier doesn't keep his paint receipts because "the IRS doesn't ask for them." **What does he do?**

- ✔ Keeps them to prove deductions.
- Throws them out because nobody asks.
- Keeps only the ones over $600.

**Case 3. Lupita's small profit.** Lupita made $3,000 in profit for the year and thinks she doesn't have to file. **What does she check?**

- ✔ Checks that from $400 she must file.
- Doesn't file because she earned little.
- Files only if she got a 1099.

## M5 U04. Quarterly payments and 1099 forms

**Case 1. Javier's 1099.** Javier received a $6,000 1099-NEC from a contractor. **What does he do?**

- ✔ Includes it on his return.
- Ignores it because the client already reported it.
- Asks the client to cancel it.

**Case 2. Don Ramón's call.** A call "from the IRS" demands that Don Ramón pay today with gift cards. **What does he do?**

- ✔ Hangs up and checks his account at irs.gov.
- Buys the cards to avoid arrest.
- Gives his details to clear things up.

**Case 3. Daniela's sales.** Daniela sold $9,000 on a platform and didn't receive a 1099-K. **What does she do?**

- ✔ Reports those sales.
- Doesn't report them since no 1099-K came.
- Reports only half of what she sold.

## M5 U05. Sales tax

**Case 1. Lupita's food.** Lupita doesn't know whether her food is taxable. **What does she do?**

- ✔ Checks with the CDTFA and sets tax aside.
- Charges nothing because it's food.
- Charges 7.25% on everything just in case.

**Case 2. Daniela's online store.** Daniela sells on a large platform and on her own site. **What does she check?**

- ✔ That she must collect it on her own site.
- Nothing: the platform collects on all her sales.
- That she doesn't need to collect tax anywhere.

**Case 3. Javier's services.** Javier thinks he must charge sales tax for painting. **What does he check?**

- ✔ That many services aren't taxable, and checks.
- Charges sales tax on every hour of work.
- Charges tax only to new customers.

## M6 U01. Do you need credit?

**Case 1. Don Ramón's equipment.** Don Ramón figures the loan pays for itself, but with optimistic sales. **What does he do?**

- ✔ Checks a cautious scenario.
- Signs: the numbers work with high sales.
- Borrows more to buy a truck too.

**Case 2. Lupita's losses.** Lupita has been losing money for three months and is offered a loan. **What does she do?**

- ✔ Fixes price and costs first.
- Takes the loan to get through a few months.
- Borrows more to grow.

**Case 3. Javier's contract.** Javier has a signed contract and needs materials to complete it. **What does he check first?**

- ✔ Whether the client will pay a deposit.
- The fastest loan he can find.
- The maximum they'll lend him.

## M6 U02. Credit options and how to check them

**Case 1. The message to Lupita.** A message offers Lupita $5,000 if she deposits a $200 opening fee. **What does she do?**

- ✔ Doesn't deposit and looks for verified options.
- Deposits $200 because the offer is good.
- Deposits only if they send a contract.

**Case 2. Don Ramón's advance.** A company offers Don Ramón $10,000 in exchange for 15% of his daily sales. **What does he do?**

- ✔ Figures the total cost and compares.
- Accepts because he gets the money today.
- Accepts and asks for $20,000 at once.

**Case 3. Daniela's loan.** Daniela has an ITIN and thinks nobody will lend to her. **What does she do?**

- ✔ Looks for credit unions and CDFIs with ITINs.
- Takes a sales advance; they don't ask for papers.
- Borrows from an informal lender.

## M6 U03. The total cost: APR, fees and guarantees

**Case 1. Don Ramón's two offers.** Don Ramón compares a loan at 14% APR with an advance at a 1.35 factor. **What does he do?**

- ✔ Asks for the total repayment and compares.
- Picks the advance because it's faster.
- Picks the lowest daily payment.

**Case 2. Javier's guarantee.** A loan for a truck asks Javier to put his home up as collateral. **What does he do?**

- ✔ Looks for another option without risking his home.
- Accepts: the truck is worth it.
- Puts up the house and asks for more.

**Case 3. Daniela's extra payment.** Daniela had a good month and wants to pay ahead on her loan. **What does she ask?**

- ✔ Whether there's a penalty and that it goes to principal.
- Nothing: paying early always saves the same.
- That the payment goes to future interest.

## M6 U04. Don't mix debts, and be careful about cosigning

**Case 1. Daniela's card.** Daniela owes $4,500 on her personal card for materials. **What does she do?**

- ✔ Stops using it and pays it from the business.
- Pays the minimum and keeps buying.
- Gets another card to pay the first.

**Case 2. The cosigner.** Don Ramón's nephew asks him to cosign a $520-a-month car loan. **What does he do?**

- ✔ Says no and helps him find another option.
- Says yes because he's family.
- Says yes and asks him not to fall behind.

**Case 3. The loan to a friend.** Lupita's close friend asks her for $400 of business money. **What does she do?**

- ✔ Lends from her salary, in writing.
- Lends from the business account.
- Lends with the business card.

## M6 U05. Cosigner, guarantor, authorized user and reference: what are you signing?

**Case 1. Don Ramón's son's car.** Don Ramón's son asks him to cosign a car loan. **What does Don Ramón do?**

- ✔ Signs only if he could pay; if not, helps with the down payment.
- Signs: it's his son and he trusts him.
- Signs and asks to keep the car title.

**Case 2. Daniela's LLC.** The bank asks Daniela for a personal guarantee on her LLC's loan. **What does she do?**

- ✔ Reads it, understands the risk and negotiates a limit.
- Signs: the LLC protects her from everything.
- Asks her mother to sign it for her.

**Case 3. The call to Javier.** A collector calls Javier to collect a coworker's debt for which he was only a reference. **What does he do?**

- ✔ Doesn't pay, writes down the details and complains to the CFPB.
- Pays so they stop calling.
- Gives the collector his coworker's address.

## M7 U01. Your health when you work for yourself

**Case 1. Javier's back.** Javier has no health insurance and works for himself. **What does he do?**

- ✔ Checks the marketplace and Medi-Cal.
- Waits to see if he gets hurt again.
- Pays for private visits when something happens.

**Case 2. Lupita's change.** Lupita left her part-time job and lost her employer coverage in June. **What does she do?**

- ✔ Checks whether that change lets her enroll.
- Waits until November with no coverage.
- Buys a plan she found on social media.

**Case 3. Daniela's income.** Daniela gets help with her premium and her sales went up a lot. **What does she do?**

- ✔ Updates her estimated income.
- Says nothing until tax time.
- Cancels the plan so she won't owe.

## M7 U02. Insurance for your business

**Case 1. The food truck fire.** Don Ramón's personal insurance didn't cover his food truck fire. **What does he do?**

- ✔ Buys a full commercial policy.
- Keeps his personal auto insurance.
- Stops going to fairs to avoid risk.

**Case 2. Javier's contractor.** A contractor asks Javier for his certificate of insurance before giving him work. **What does he do?**

- ✔ Buys general liability and requests his COI.
- Tells the contractor it isn't needed.
- Borrows a friend's certificate.

**Case 3. Lupita's helper.** Lupita will hire a helper as an employee. **What does she check?**

- ✔ That she needs workers' compensation.
- Nothing: it's only part-time.
- That her homeowner's policy is enough.

## M7 U03. Scams against businesses

**Case 1. Daniela's letter.** An "official" letter charges Daniela $243 for an LLC certificate. **What does she do?**

- ✔ Checks the sender and verifies on the official site.
- Pays the $243 to avoid the penalty.
- Calls the number on the letter.

**Case 2. The call to Lupita.** Someone "from the health department" demands Lupita pay a fine by phone today. **What does she do?**

- ✔ Hangs up and calls the official number.
- Pays the fine so she doesn't lose her permit.
- Gives her card details to clear it up.

**Case 3. The supplier's email.** An email from Javier's supplier says they changed accounts. **What does he do?**

- ✔ Calls the number he already had.
- Pays the new account so he isn't late.
- Replies to the email to confirm.

## M7 U04. Your brand and your name

**Case 1. Daniela's brand.** A shop tells Daniela that "Luna Morena" is their trademark. **What does she do?**

- ✔ Checks the USPTO and decides.
- Ignores the message because she was first.
- Registers her social media account as proof.

**Case 2. The food truck name.** Don Ramón wants to paint a new name on his food truck. **What does he do first?**

- ✔ Searches the USPTO and his state.
- Paints the name and checks later.
- Asks his customers whether they like it.

**Case 3. The email to Javier.** Javier gets an email charging $1,200 to "protect his brand internationally." **What does he do?**

- ✔ Checks the domain and doesn't pay.
- Pays to protect his brand abroad.
- Pays half and asks for an invoice.

## M7 U05. Identity theft and unwanted calls

**Case 1. Don Ramón's card.** Don Ramón's report shows a card he never opened. **What does he do?**

- ✔ Reports it and freezes at all three bureaus.
- Pays the card off to clean up his report.
- Freezes at one bureau and waits.

**Case 2. Lupita's calls.** Lupita gets sales calls every day. **What does she do?**

- ✔ Registers at donotcall.gov and blocks calls.
- Changes her number every time they call.
- Answers and asks to be taken off the list.

**Case 3. Daniela's site.** A website charges Daniela $30 for "her official credit report." **What does she do?**

- ✔ Doesn't pay and uses AnnualCreditReport.com.
- Pays the $30 because it says it's official.
- Gives her SSN to see if it's real.

## M7 U06. AI scams: fake voices, videos and messages

**Case 1. Don Ramón's supplier.** A voice identical to his supplier's asks Don Ramón to pay a new account by Zelle. **What does he do?**

- ✔ Hangs up and confirms with the number he had.
- Pays: it's his supplier's voice.
- Asks for the new account by message.

**Case 2. Javier's video.** Javier sees a video of a famous businessman promising to double his money with crypto. **What does he do?**

- ✔ Doesn't invest: it's a fake video.
- Invests a little to try it.
- Invests if the video has lots of views.

**Case 3. Daniela's customers.** Someone uses Daniela's photo and voice to ask her customers for deposits. **What does she do?**

- ✔ Posts her payment method and reports to the FTC.
- Deletes her social media and waits.
- Asks customers to pay another account.

## M7 U07. If disaster strikes: your business ready

**Case 1. Don Ramón's policy.** Don Ramón doesn't know if his insurance covers sales lost to an evacuation. **What does he do?**

- ✔ Asks about business interruption coverage.
- Assumes insurance covers everything.
- Cancels the insurance to save money.

**Case 2. Lupita's inspector.** Someone claiming to be from FEMA asks Lupita for $100 to "speed up" her aid. **What does she do?**

- ✔ Doesn't pay and reports it.
- Pays the $100 to secure the aid.
- Pays half now and the rest later.

**Case 3. Javier's shop.** After an earthquake, Javier can't make his estimated payment on time. **What does he check?**

- ✔ Checks whether the IRS postponed deadlines.
- Pays the penalty without checking.
- Stops paying taxes that year.

## M8 U01. Hiring help

**Case 1. Lupita's neighbor.** Lupita wants to pay her neighbor in cash "as a contractor" to work in her kitchen on her schedule. **What does she do?**

- ✔ Registers as an employer.
- Pays her in cash as a contractor.
- Asks her to work without pay for a few months.

**Case 2. Javier's helper.** Javier wants a helper on a $3,000 painting job. **What does he check?**

- ✔ That he needs a license and workers' comp.
- Nothing: the helper is his cousin.
- Only that the helper has an ITIN.

**Case 3. Daniela's designer.** Daniela hires an independent designer for her logo for $400. **What does she do?**

- ✔ Asks for a W-9 and keeps the invoice.
- Sends him a W-2 as an employee.
- Keeps nothing because it was a small amount.

## M8 U02. Selling online and on platforms

**Case 1. The platform price.** Daniela charges the same on the platform as on her own site. **What does she check?**

- ✔ That it covers fees, shipping and ads.
- Nothing: the price should be the same everywhere.
- Only the shipping cost of the order.

**Case 2. Daniela's 1099-K.** Daniela got a 1099-K for $24,000 gross. **What does she do?**

- ✔ Reports and subtracts costs with her records.
- Reports the $24,000 as profit.
- Doesn't report because the platform already did.

**Case 3. Lupita's ads.** Lupita pays $100 a month for ads and doesn't know if they bring sales. **What does she do?**

- ✔ Measures the sales and profit from the ads.
- Raises it to $300 a month to sell more.
- Drops them without checking anything.

## M8 U03. Your monthly numbers

**Case 1. Don Ramón's margin.** Don Ramón's margin dropped five points. **What does he do?**

- ✔ Checks costs and adjusts.
- Sells more to make up for the margin.
- Keeps going; one month says nothing.

**Case 2. Daniela's sales.** Daniela's sales fell in January compared with December. **What does she compare with?**

- ✔ With January of last year.
- With the best month of the year.
- With December of this year.

**Case 3. Lupita's ticket.** Lupita has many customers, but each one buys little. **What does she try?**

- ✔ A combo or drink to raise the ticket.
- Opens longer hours to get more customers.
- Lowers prices so people buy more.

## M8 U04. Stress, business and family

**Case 1. Lupita's orders.** Lupita answers orders until midnight and never rests. **What does she do?**

- ✔ Posts hours and an automatic reply.
- Always answers so she doesn't lose customers.
- Turns off her phone for a week.

**Case 2. Daniela's sales.** Daniela doesn't want to look at her numbers because sales were low. **What does she do?**

- ✔ Reviews her numbers and decides one action.
- Doesn't look so she won't worry.
- Cuts prices without checking anything.

**Case 3. Don Ramón's family.** Don Ramón and his daughter argue about the food truck at dinner. **What do they do?**

- ✔ They set one time for each topic.
- They talk business at every meal.
- They stop talking about the business.

## M8 U05. Your one-page business plan and how to pitch it

**Case 1. Daniela's microloan.** Daniela is asked for a business plan and a short pitch. **What does she do?**

- ✔ Gets help at an SBDC and uses her records.
- Improvises on the day of the bank meeting.
- Asks someone to make up the numbers.

**Case 2. Javier's "grant".** A caller offers Javier a federal grant if he pays a $300 processing fee. **What does he do?**

- ✔ Doesn't pay and searches sba.gov.
- Pays to secure the grant.
- Pays half now and half on approval.

**Case 3. Lupita's "no".** The bank turned down Lupita's loan for a bigger kitchen. **What does she do?**

- ✔ Asks why, improves and looks for a CDFI.
- Takes an expensive cash advance.
- Stops trying for good.

## M8 U06. Your business and its surroundings: competition, economy, community and rule changes

**Case 1. The new trucks.** Two food trucks arrived on Don Ramón's street. **What does he do?**

- ✔ Sees what makes him different and adjusts his service.
- Cuts all his prices even at a loss.
- Closes before he loses more.

**Case 2. Javier's warning.** A group chat says "the IRS now taxes every Zelle payment." **What does he do?**

- ✔ Checks with the IRS and his preparer.
- Stops accepting app payments.
- Forwards it to all his customers.

**Case 3. Lupita's road work.** The city will repair Lupita's street for a month. **What does she do?**

- ✔ Plans with her reserve and tells her customers.
- Closes for a month without notice.
- Takes a loan to hold on.

## M9 U01. Your retirement when you work for yourself

**Case 1. Don Ramón's retirement.** Don Ramón doesn't know how much he'd get from Social Security. **What does he do?**

- ✔ Checks his estimate at ssa.gov.
- Assumes he won't get anything.
- Asks his bank how much he'll get.

**Case 2. Javier's SEP.** Javier did well this year and wants to pay less tax and save. **What does he look at?**

- ✔ Looks at a SEP IRA or Solo 401(k).
- Buys equipment he doesn't need to deduct it.
- Waits until he retires to think about it.

**Case 3. Daniela's savings.** Daniela is 27 and thinks it's too early for retirement. **What does she do?**

- ✔ Starts with a small contribution.
- Waits until she earns more to start.
- Puts everything into her inventory.

## M9 U02. If the business changes or you're not there

**Case 1. Lupita's illness.** Lupita's daughter didn't know how to keep orders going. **What does Lupita prepare?**

- ✔ A folder with suppliers and accounts.
- Writes her passwords down for her daughter.
- Nothing: she won't get sick again.

**Case 2. Daniela's LLC.** Daniela will stop selling and won't use her LLC anymore. **What does she do?**

- ✔ Formally dissolves it.
- Stops using it without telling anyone.
- Closes only the bank account.

**Case 3. Don Ramón's food truck.** Don Ramón wants his daughter to take over the food truck in a few years. **What does he do?**

- ✔ A written agreement and his will.
- Tells his daughter by word of mouth.
- Waits until he retires to think about it.

## M9 U03. Your one-page plan

**Case 1. Daniela's page.** Daniela is missing her retirement account and her trademark. **What does she do?**

- ✔ Makes them goals for next quarter.
- Does everything this same week.
- Leaves them for next year.

**Case 2. Javier's priorities.** Javier has many pending tasks and doesn't know where to start. **What does he do?**

- ✔ Separating money, taxes and price.
- Registering his trademark first.
- Taking out a loan to get organized.

**Case 3. Don Ramón's review.** Don Ramón made his plan three months ago and hasn't reviewed it. **What does he do?**

- ✔ Sets a fixed date and updates.
- Makes a new plan from scratch.
- Drops it; he knows what to do.

## M9 U04. If you're not there: beneficiary accounts, your home, digital access and taxes

**Case 1. Half for the IRS.** Don Ramón's daughter thinks the IRS will take half of the inheritance. **What does she learn?**

- ✔ That heirs pay no federal tax, except on huge estates.
- That it's better to sell everything first so the IRS gets nothing.
- That it's better not to tell the IRS anything about the inheritance.

**Case 2. The land in Michoacán.** Lupita's nephew, who lives in Los Angeles, will inherit land in Mexico worth 120,000 dollars. **What does he do?**

- ✔ He files Form 3520 with the IRS even though he owes no tax.
- He reports nothing because the land is in Mexico, not in the U.S.
- He sells the land quickly so he doesn't have to report anything.

**Case 3. Daniela's account.** Daniela has no beneficiary on her business account. **What does she do?**

- ✔ She names a POD beneficiary at her bank.
- She gives her password to her mom in case something happens someday.
- She closes the account and keeps the business money in cash.

# Part 13. Question bank

The option marked ✔ is correct; the feedback is below it.

## Module 1

**M1 U01 P1.** You sell $3,000 and your costs are $2,200. How much do you earn?

- ✔ $800
- $3,000
- $5,200

*Correct! $3,000 minus $2,200.*

**M1 U01 P2.** What is profit?

- Everything you charge customers in the month, in cash and through apps
- ✔ What's left after paying all costs
- What's in your account at closing

*Correct! Sales minus costs.*

**M1 U01 P3.** Your sales and costs are the same. What happens?

- You earn a little, but the business does leave you something
- You lose money every month
- ✔ You break even: you work without pay

*Correct! Nothing is left for you.*

**M1 U02 P1.** Where do you pay business materials from?

- Your household account
- ✔ The business account
- Whatever you have that day in your wallet or cash box

*Correct! Each pocket pays its own.*

**M1 U02 P2.** You use $200 from the business for a household emergency. What do you do?

- Forget it, it's your business anyway
- Cover it with your credit card and forget about it
- ✔ Write it down as a loan and pay it back

*Correct! That way it doesn't get lost.*

**M1 U02 P3.** How much does the FDIC insure per depositor, per bank, per ownership category?

- ✔ $250,000
- $25,000
- Everything you have, no limit

*Correct! Per depositor, bank and category.*

**M1 U03 P1.** Your profit is $2,000 and you set aside 25% for taxes. How much is that?

- $250
- $2,000
- ✔ $500

*Correct! 25% of $2,000.*

**M1 U03 P2.** You had an excellent week. What do you do?

- ✔ Pay yourself your salary and set the extra aside
- Take all the extra home because you earned it
- Raise your salary starting that day

*Correct! The extra gets set aside.*

**M1 U03 P3.** Why do you set aside taxes as an owner?

- ✔ Because nobody withholds them for you
- Because the bank asks you to when you open the account
- There's no need: they pay themselves

*Correct! You pay them yourself.*

**M1 U04 P1.** What's the minimum you write down every day?

- Only the big sales
- Whatever you remember on Sunday
- ✔ Date, sales and expenses

*Correct! That's enough.*

**M1 U04 P2.** What do you need to deduct miles?

- ✔ A log of each trip
- Only the month's gas receipt
- Nothing, it's calculated automatically

*Correct! No log, no deduction.*

**M1 U04 P3.** An app asks for your bank password. What do you do?

- Give it if the app costs nothing and has good reviews
- ✔ Don't give it and choose another tool
- Give only your Social Security number

*Correct! It asks for too much.*

**M1 U05 P1.** Where can betting money come from, if you choose to bet?

- The business account
- ✔ Your salary, with a cap
- What you set aside for taxes

*Correct! Never from the business.*

**M1 U05 P2.** What about gambling winnings?

- ✔ They are income you report
- They are never taxed
- They're only reported above $10,000

*Correct! All income is reported.*

**M1 U05 P3.** Where do you get help with gambling in the U.S.?

- In the betting app itself
- ✔ At 1-800-GAMBLER
- From whoever lends you money to bet

*Correct! At no cost, 24 hours a day.*

**M1 U06 P1.** Whose name do you link your business payments to?

- Your partner's, who knows more
- ✔ Yours
- A trusted customer's

*Correct! You decide.*

**M1 U06 P2.** Someone takes what you earn and keeps you from working. What is it?

- ✔ Economic abuse
- A money-management problem
- Normal between partners

*Correct! No-cost help is available.*

**M1 U06 P3.** A relative asks for your EIN to get a loan. What happens if you lend it?

- Nothing
- The debt is your relative's
- ✔ The debt and the history are yours

*Correct! Your name is on the line.*

## Module 2

**M2 U01 P1.** Which of these is a variable cost?

- Your online store subscription
- ✔ The packaging for each order
- Your phone plan

*Correct! It goes up with each sale.*

**M2 U01 P2.** Your fixed costs are $600 and you sell 200 pieces a month. How much fixed cost goes to each piece?

- ✔ $3
- $30
- $600

*Correct! $600 divided by 200.*

**M2 U01 P3.** Is your salary a business cost?

- No, it's profit
- Only if something is left at the end of the month
- ✔ Yes, it's a fixed cost

*Correct! Without it you work without pay.*

**M2 U02 P1.** Your cost is $35. What is the minimum price for a 30% margin on price?

- $45.50
- $35
- ✔ $50

*Correct! $35 divided by 0.70.*

**M2 U02 P2.** When should you never sell?

- ✔ Below your cost
- Higher than the competition
- With a written guarantee for your customer

*Correct! You lose on every sale.*

**M2 U02 P3.** Your materials went up. What do you do?

- Use cheaper materials without telling your customers
- ✔ Recalculate your cost and announce the new price
- Wait for prices to drop on their own

*Correct! With notice and clarity.*

**M2 U03 P1.** Fixed costs of $3,000 and each sale leaves 50%. Break-even point?

- $1,500
- ✔ $6,000
- $3,500

*Correct! $3,000 divided by 0.50.*

**M2 U03 P2.** You sell less than your break-even point. What happens?

- You earn a little
- You're even
- ✔ You lose money

*Correct! You don't cover your costs.*

**M2 U03 P3.** What lowers your break-even point?

- ✔ Lowering fixed costs
- Renting a bigger place in a better area
- Giving customers more credit

*Correct! You need to sell less.*

**M2 U04 P1.** What is waste?

- The volume discount your supplier gives you
- ✔ What goes bad or can no longer be sold
- New merchandise

*Correct! Money thrown away.*

**M2 U04 P2.** You have 30 pieces that don't sell. What do you do?

- ✔ Offer them at a discount
- Buy more to display
- Keep them just in case

*Correct! Money sitting still.*

**M2 U04 P3.** When does a "buy more" deal pay off?

- Always
- If the supplier is trustworthy and gives you a good price
- ✔ If you sell it all before it expires

*Correct! Otherwise it's expensive.*

## Module 3

**M3 U01 P1.** You have $600, will collect $900 and will pay $1,700 this week. How do you end?

- $200 left over
- $3,200
- ✔ $200 short

*Correct! $600 plus $900 minus $1,700.*

**M3 U01 P2.** What improves your cash flow?

- Paying suppliers early so they treat you better
- ✔ Asking for deposits on big jobs
- Giving customers more time

*Correct! You collect earlier.*

**M3 U01 P3.** Your calendar shows a gap in three weeks. What do you do?

- ✔ Look for solutions starting today
- Wait and see if it fixes itself
- Get a quick advance the day it runs out

*Correct! Act ahead of time.*

**M3 U02 P1.** What is selling on credit for your business?

- A sale already collected
- ✔ An no-interest loan to your customer
- Extra profit

*Correct! Money that hasn't come back.*

**M3 U02 P2.** A customer hasn't paid and places another order. What do you do?

- Deliver so you don't lose them
- Post their name on your social media to pressure them
- ✔ No more credit until they pay

*Correct! Clear rule.*

**M3 U02 P3.** What do you ask for on a big order?

- ✔ A deposit and a written agreement
- Only their phone number
- Nothing: trust is enough

*Correct! It protects you.*

**M3 U03 P1.** Fixed costs of $1,500 a month. Reserve for 3 months?

- $500
- $1,500
- ✔ $4,500

*Correct! $1,500 times 3.*

**M3 U03 P2.** Where should you keep the reserve?

- ✔ In an insured savings account
- In cash at home, where you always have it handy
- In more inventory

*Correct! Protected and available.*

**M3 U03 P3.** Your insurance costs $1,200 a year. How much do you set aside monthly?

- $120
- ✔ $100
- $1,200

*Correct! $1,200 divided by 12.*

**M3 U04 P1.** Your costs rise and your price doesn't. What happens?

- ✔ Your margin shrinks
- You earn more
- Nothing, you sell the same

*Correct! That's why you review prices.*

**M3 U04 P2.** What happens to a reserve kept in cash for years?

- It grows on its own
- It stays just as useful
- ✔ It loses buying power

*Correct! Inflation wears it down.*

**M3 U04 P3.** Your loan has a variable rate. What do you do?

- Nothing, rates always fall
- ✔ Calculate the payment with a higher rate
- Take another loan to cover it

*Correct! Be ready in case it rises.*

## Module 4

**M4 U01 P1.** You take $5,000 a month in cards and the fee is 3%. How much do you pay?

- ✔ $150
- $500
- $15

*Correct! 3% of $5,000.*

**M4 U01 P2.** Are payments through apps business income?

- No, if they're under $600
- ✔ Yes, however they arrive
- Only if you receive a Form 1099-K

*Correct! All income is reported.*

**M4 U01 P3.** Option A: 2.6% with no monthly fee. Option B: 2.3% plus $30 a month. You take $4,000 in cards. Which is cheaper, not counting flat fees?

- ✔ A: $104
- B: $122
- They cost the same

*Correct! $104 versus $92 plus $30.*

**M4 U02 P1.** When do you deliver an order paid through an app?

- When they send you the screenshot
- When the customer swears on the phone they already paid
- ✔ When the money is available in your account

*Correct! A screenshot isn't proof.*

**M4 U02 P2.** What do you share to get paid?

- ✔ Your payment username or email
- Your password
- The code you got by text

*Correct! That's enough to get paid.*

**M4 U02 P3.** An email says your payment is on hold until you pay for an "upgrade." What is it?

- A normal app procedure
- ✔ A scam: check inside the app
- A bank fee

*Correct! Apps don't charge that way.*

**M4 U03 P1.** You're overpaid by check and asked for the difference. What do you do?

- Send the difference as soon as the check shows as available
- ✔ Send nothing back and ask for the exact amount
- Send back half

*Correct! It's the overpayment scam.*

**M4 U03 P2.** Your supplier writes that they changed accounts. What do you do?

- Pay the new account
- Reply to the same email to confirm
- ✔ Call the number you already had

*Correct! Confirm another way.*

**M4 U03 P3.** What is a sign of a scam when selling?

- ✔ Rush, a big purchase and shipping to another address
- A customer asking about sizes, colors and shipping times
- A payment available for the exact amount

*Correct! Rush is a hook.*

## Module 5

**M5 U01 P1.** Which business form starts without company paperwork?

- ✔ Sole proprietor
- LLC
- Corporation

*Correct! You start when you sell.*

**M5 U01 P2.** Your California LLC had no sales this year. Does it pay the minimum tax?

- No, if it didn't sell
- Only if it earned over $10,000
- ✔ Yes, $800 while it exists

*Correct! Even with no sales.*

**M5 U01 P3.** What makes an LLC lose its protection?

- Having insurance
- ✔ Mixing LLC money with yours
- Having its own LLC account

*Correct! The separation breaks.*

**M5 U02 P1.** Where do you get your EIN?

- From a private site that charges a fee
- ✔ At no cost on irs.gov
- At your bank

*Correct! It costs nothing.*

**M5 U02 P2.** What is the ITIN for?

- ✔ Filing taxes if you can't get an SSN
- Working as an employee
- Voting

*Correct! IRS tax number.*

**M5 U02 P3.** In California, when do you need a CSLB license?

- Never for small painting or repair jobs
- Only if you have full-time employees
- ✔ For jobs over $1,000 or that require a permit

*Correct! Rule in effect since 2025.*

**M5 U03 P1.** What is the self-employment tax rate?

- ✔ 15.3%
- 7.65%
- 2.5%

*Correct! Social Security and Medicare.*

**M5 U03 P2.** You made $350 in business profit this year. Do you pay self-employment tax?

- Yes, always, even if you earn little
- Yes, if you sold through apps
- ✔ No, because it's under $400

*Correct! The minimum is $400.*

**M5 U03 P3.** What do you need to deduct an expense?

- To remember it
- ✔ That it's for the business and you have proof
- That it's over $600

*Correct! Ordinary, necessary and with proof.*

**M5 U04 P1.** Which is a 2026 estimated payment date?

- ✔ June 15
- December 31
- March 1

*Correct! Second estimated payment.*

**M5 U04 P2.** You didn't get a 1099-K for your platform sales. What do you do?

- Don't report those sales
- Report only if you sold more than $600
- ✔ Report them anyway

*Correct! All income is reported.*

**M5 U04 P3.** Someone calls "from the IRS" to be paid today with gift cards. What is it?

- ✔ A scam
- A real urgent collection
- A new IRS method for small payments

*Correct! The IRS doesn't collect that way.*

**M5 U05 P1.** What is California's base statewide sales tax rate?

- 16%
- 0%
- ✔ 7.25%

*Correct! Plus local rates.*

**M5 U05 P2.** You sell $1,000 in products at a 9% rate. How much tax do you collect?

- ✔ $90
- $9
- $900

*Correct! 9% of $1,000.*

**M5 U05 P3.** What do you do with the sales tax you collect?

- Use it to buy materials
- ✔ Set it aside and send it to the state
- Keep it as a business reserve

*Correct! It belongs to the state.*

## Module 6

**M6 U01 P1.** Extra profit is $300 a month and the payment is $400. What happens?

- The loan pays for itself
- ✔ You're $100 short each month
- You earn $100

*Correct! Payment higher than profit.*

**M6 U01 P2.** What is business credit healthiest for?

- Paying household bills this month
- Covering the losses of the last few months
- ✔ Something that brings in sales

*Correct! It can pay for itself.*

**M6 U01 P3.** What do you do before borrowing for an order?

- ✔ Check whether the customer can pay a deposit
- Ask for the maximum amount
- Quickly sign the first offer so you don't lose the day's deal

*Correct! An no-interest alternative.*

**M6 U02 P1.** You're asked for a fee to release your loan. What is it?

- A normal procedure
- A legally required opening fee
- ✔ A sign of a scam

*Correct! Never pay up front.*

**M6 U02 P2.** Where do you check a lender in California?

- ✔ With the DFPI
- On its social media
- In its app reviews

*Correct! The state regulator.*

**M6 U02 P3.** Up to how much do SBA microloans lend?

- $5,000
- ✔ $50,000
- No limit

*Correct! Through intermediaries.*

**M6 U03 P1.** Two offers with the same amount and term: 12% APR and 30% APR. Which is cheaper?

- ✔ The 12% one
- The 30% one
- They cost the same

*Correct! Lower APR.*

**M6 U03 P2.** A $5,000 advance with a 1.4 factor. How much do you repay in total?

- $5,400
- $1,400
- ✔ $7,000

*Correct! $5,000 times 1.4.*

**M6 U03 P3.** What is a personal guarantee?

- The loan isn't collected if the business closes
- ✔ You pay if the business doesn't
- No-cost insurance

*Correct! You answer with your assets.*

**M6 U04 P1.** When is it acceptable to use your personal card for the business?

- If you pay the minimum each month
- Whenever the business needs it, even if you don't pay in full
- ✔ If you pay in full each month and keep receipts

*Correct! No interest.*

**M6 U04 P2.** If you cosign and the borrower doesn't pay, what happens?

- ✔ They can collect from you
- Nothing, you only signed
- The bank forgives the debt

*Correct! You're responsible for the debt.*

**M6 U04 P3.** Where do you lend to a relative from?

- The business account
- ✔ Your salary or savings, in writing
- The business card

*Correct! Without affecting the business.*

**M6 U05 P1.** You gave your name and phone as a reference for a friend's loan. Can you be charged?

- Yes, half
- Yes, if he doesn't pay
- ✔ No, you only gave your details

*Correct! A reference isn't obligated.*

**M6 U05 P2.** Who must pay everything if the borrower doesn't?

- ✔ The cosigner
- The reference
- The seller

*Correct! They signed the loan.*

**M6 U05 P3.** A collector pressures you to pay a debt for which you're only a reference. What do you do?

- Pay so they stop calling
- ✔ Don't pay and complain to the CFPB
- Give them your friend's family's details

*Correct! They can't charge you.*

## Module 7

**M7 U01 P1.** Where do you look for health insurance in California if you're self-employed?

- ✔ Covered California and Medi-Cal
- Only at your bank
- At the IRS

*Correct! Official options.*

**M7 U01 P2.** You lost your job-based coverage mid-year. What can you check?

- Nothing, you wait for November
- ✔ Whether that change lets you enroll now
- A loan for doctor visits

*Correct! Qualifying life event.*

**M7 U01 P3.** You get help with your premium and your income goes up. What do you do?

- Nothing until next year
- Cancel the insurance
- ✔ Update your estimated income

*Correct! Avoids owing at tax time.*

**M7 U02 P1.** A customer slips at your stand. Which insurance helps?

- Life insurance
- ✔ General liability
- Personal auto insurance

*Correct! Damage to others.*

**M7 U02 P2.** What is the deductible?

- ✔ The part of the damage you pay
- What the insurer pays
- The price of the policy

*Correct! Your share.*

**M7 U02 P3.** You have one employee in California. Which insurance is required?

- Life insurance for the employee
- Equipment insurance
- ✔ Workers' compensation

*Correct! Required with employees.*

**M7 U03 P1.** A letter charges you for an LLC "certificate" and threatens a penalty. What do you do first?

- Pay to avoid the penalty
- Call the number on the letter
- ✔ Check the sender and verify on the official site

*Correct! Verify before paying.*

**M7 U03 P2.** What does a real authority never accept as payment?

- ✔ Gift cards
- Checks
- Payment on its official site

*Correct! Sign of a scam.*

**M7 U03 P3.** Where do you report a scam against your business?

- In the company's reviews
- ✔ At ReportFraud.ftc.gov
- Nowhere

*Correct! Official report.*

**M7 U04 P1.** Where do you search whether a name is already a federal trademark?

- ✔ The USPTO
- Social media
- An internet search engine

*Correct! Official search.*

**M7 U04 P2.** Does your social media account give you exclusive nationwide rights to the name?

- Yes, if it has many followers
- Yes, if you opened it first
- ✔ No

*Correct! Only registration does.*

**M7 U04 P3.** Which domain do real USPTO notices come from?

- Any email with "trademark" in the subject
- ✔ uspto.gov
- A law firm that writes to you first

*Correct! Official domain.*

**M7 U05 P1.** How much does a credit freeze cost?

- $10 per bureau
- ✔ Nothing
- It's at no cost only if your identity was already stolen

*Correct! It costs nothing at all three bureaus.*

**M7 U05 P2.** Where do you report identity theft?

- ✔ At IdentityTheft.gov
- At the bank where you have your account
- On social media

*Correct! It gives you a recovery plan.*

**M7 U05 P3.** How long does your Do Not Call registration last?

- One year
- Five years
- ✔ It never expires

*Correct! It never expires.*

**M7 U06 P1.** Your supplier, in their own voice, asks you to pay a new account. What do you do?

- Pay: it's their voice
- ✔ Confirm by calling the number you already had
- Ask for the account by message

*Correct! Confirm another way.*

**M7 U06 P2.** A celebrity recommends an investment that doubles your money in a video. What is it?

- ✔ Almost certainly a fake video and a scam
- A safe investment
- A bank promotion

*Correct! Nobody doubles money.*

**M7 U06 P3.** Where do you report an AI scam in the U.S.?

- In the video's comments
- Nowhere
- ✔ At ReportFraud.ftc.gov

*Correct! Official report.*

**M7 U07 P1.** What is usually left out of basic insurance?

- Robbery
- ✔ Flood and earthquake
- Fire

*Correct! Usually separate.*

**M7 U07 P2.** Someone from "FEMA" asks for $100 to speed up your aid. What is it?

- ✔ A scam: FEMA doesn't charge
- A normal procedure
- An SBA fee

*Correct! Aid costs nothing.*

**M7 U07 P3.** Up to how much does the SBA lend a business after a disaster?

- $50,000
- $500,000
- ✔ $2 million

*Correct! Physical damage or working capital.*

## Module 8

**M8 U01 P1.** Someone works at your place, on your schedule and following your instructions. What are they usually?

- ✔ An employee
- An independent contractor
- A partner

*Correct! You control the work.*

**M8 U01 P2.** Which insurance is required in California if you have employees?

- Life insurance for each employee
- ✔ Workers' compensation
- Auto insurance

*Correct! Required.*

**M8 U01 P3.** You pay an independent designer $2,500 in the year. What do you send them?

- A W-2
- Nothing
- ✔ A 1099-NEC

*Correct! From $2,000 in 2026.*

**M8 U02 P1.** When does a platform send a 1099-K?

- Always, from the first sale
- ✔ With over $20,000 and over 200 transactions
- Only if you ask for it

*Correct! Current threshold.*

**M8 U02 P2.** Your 1099-K shows $24,000 gross. How much do you report as profit?

- The full $24,000
- Nothing, the platform already reported it
- ✔ Payments minus refunds, fees and costs

*Correct! Costs are subtracted.*

**M8 U02 P3.** Who usually collects sales tax on large platform sales?

- ✔ The platform
- Nobody
- Your customer, directly to the state

*Correct! Marketplace facilitator.*

**M8 U03 P1.** Sales of $6,000 from 400 sales. Average ticket?

- $2,400
- $150
- ✔ $15

*Correct! $6,000 divided by 400.*

**M8 U03 P2.** Your margin dropped. What do you check first?

- ✔ Prices and costs of what you sell
- The color of your logo
- Your card limit

*Correct! Margin depends on them.*

**M8 U03 P3.** Your business is seasonal. What do you compare July with?

- June
- ✔ July last year
- January

*Correct! Same season.*

**M8 U04 P1.** Customers message you at midnight. What do you do?

- Always answer so you don't lose them
- ✔ Post your hours and an automatic reply
- Turn off your phone for a week

*Correct! Clear limits.*

**M8 U04 P2.** Sales were low this month. What do you do with your numbers?

- ✔ Review them calmly and decide on one action
- Don't look so you don't worry
- Delete them

*Correct! Decide with data.*

**M8 U04 P3.** You haven't slept for weeks and feel there's no way out. Who do you call?

- Nobody, you tough it out
- Someone who'll lend you money
- ✔ 988

*Correct! No-cost help 24 hours.*

**M8 U05 P1.** What comes first in your pitch?

- ✔ The problem you solve and for whom
- What you need
- Your whole life story

*Correct! That's how they understand your business.*

**M8 U05 P2.** You're asked for $300 to "approve" a federal grant. What is it?

- A normal fee
- A deposit
- ✔ A scam

*Correct! No one charges for a grant.*

**M8 U05 P3.** Your loan is denied. What do you do?

- Take an expensive cash advance
- ✔ Ask why and get help to try again
- Stop trying

*Correct! A no teaches you too.*

**M8 U06 P1.** New competition arrives on your street. What do you do?

- Cut prices even at a loss
- ✔ See what makes you different and adjust your offer
- Close

*Correct! Compete with what sets you apart.*

**M8 U06 P2.** Social media says an IRS rule changed. What do you do?

- ✔ Check the IRS website and your tax preparer
- Stop accepting app payments
- Share it with all your customers

*Correct! Confirm first.*

**M8 U06 P3.** Where do you check inflation?

- In a bank ad
- In a social media group
- ✔ At the BLS

*Correct! Official source.*

## Module 9

**M9 U01 P1.** Where do you check your Social Security record?

- At your bank
- ✔ At ssa.gov
- At the IRS

*Correct! Official site.*

**M9 U01 P2.** How much can you put in an IRA in 2026 if you're under 50?

- $72,000
- $24,500
- ✔ $7,500

*Correct! 2026 limit.*

**M9 U01 P3.** Why isn't the business enough for retirement?

- ✔ It depends on you being able to work
- Because small businesses don't pay taxes
- Because it's small

*Correct! Your health changes.*

**M9 U02 P1.** You close your California LLC business. What do you do?

- Nothing: you just stop selling until you come back
- Close the bank account and that's it
- ✔ Formally dissolve it so you stop owing the minimum

*Correct! The minimum keeps running.*

**M9 U02 P2.** What should not be written in your business folder?

- ✔ Your passwords
- The list of suppliers
- The payment dates

*Correct! Theft risk.*

**M9 U02 P3.** How do you hand the business over to a relative?

- By word of mouth
- ✔ With a written agreement
- Without telling anyone

*Correct! Avoids conflict.*

**M9 U03 P1.** How often do you review your one-page plan?

- ✔ Every three months
- Once in a lifetime
- Every day

*Correct! Quarterly review.*

**M9 U03 P2.** Where do you start if a lot is missing?

- Registering your trademark
- ✔ Separating money and setting aside taxes
- Taking out a loan to get everything organized at once

*Correct! The foundation.*

**M9 U03 P3.** What do you share in the community?

- Your real amounts, accounts and monthly sales
- Your Social Security number
- ✔ Your plan with no personal data

*Correct! No data.*

**M9 U04 P1.** Does someone who inherits 200,000 dollars pay federal tax?

- Yes, 40%
- ✔ No
- Yes, 10%

*Correct! The estate tax is for huge estates.*

**M9 U04 P2.** What keeps a bank account out of court?

- Changing the password
- Withdrawing it all in cash
- ✔ Naming a POD beneficiary

*Correct! It passes directly.*

**M9 U04 P3.** You inherit land in Mexico worth 150,000 dollars. What do you do with the IRS?

- ✔ File Form 3520
- Nothing
- Pay 30% tax

*Correct! It's an information report.*
