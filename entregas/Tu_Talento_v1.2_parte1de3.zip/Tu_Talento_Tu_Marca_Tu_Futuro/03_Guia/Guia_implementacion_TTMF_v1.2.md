# Tu Talento, Tu Marca, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10: instalación, gamificación, comunidad y canales, y mantenimiento de los datos con fecha.

# Parte 1. Instalación en Moodle, paso a paso

Escrita para que Claude (o una persona con rol de administración) la siga en el navegador. El mismo archivo está en `04_Moodle/README_INSTALAR_TU_TALENTO_PARA_CLAUDE.md`.


Vas a crear el curso nuevo **Tu Talento, Tu Marca, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert), ya instalados.

Si en el sitio existen otros cursos (por ejemplo, "Tu Dinero, Tu Familia, Tu Futuro"), **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TTMF-MX`. Si existe, detente y pregunta.
2. Confirma que existen **Certificado personalizado** y **Level Up** en *Administración del sitio > Extensiones > Resumen de extensiones*.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Talento, Tu Marca, Tu Futuro |
| Nombre corto | TTMF-MX |
| Visibilidad | **Ocultar** |
| Formato | Temas, 13 secciones |
| Seguimiento de finalización | Sí |

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Tu dinero real: ingresos variables | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Tu carrera como negocio: régimen fiscal e impuestos | `M2_resumen.html` |
| 3 | Módulo 3. Contratos, representación y regalías | `M3_resumen.html` |
| 4 | Módulo 4. Conoce el sistema financiero mexicano | `M4_resumen.html` |
| 5 | Módulo 5. Compara y elige: instituciones y productos | `M5_resumen.html` |
| 6 | Módulo 6. El crédito es deuda | `M6_resumen.html` |
| 7 | Módulo 7. Buró y Círculo de Crédito | `M7_resumen.html` |
| 8 | Módulo 8. Sal de deudas | `M8_resumen.html` |
| 9 | Módulo 9. No caigas: fraudes y robo de identidad | `M9_resumen.html` |
| 10 | Módulo 10. Protección y prevención | `M10_resumen.html` |
| 11 | Módulo 11. Tu futuro | `M11_resumen.html` |
| 12 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 13 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas RFC, CURP, números de cuenta, contraseñas ni montos reales."

### 3. Libros de lecciones (M1 a M11)

En cada sección de módulo:

1. Crea un libro: nombre `Lecciones del Módulo N`, formato de capítulo "Nada", finalización "Ver".
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba que cada lección tenga su portada primero y 3 subcapítulos sangrados.

| Módulo | Capítulos | Páginas |
|---|---|---|
| M1 | 6 | 24 |
| M2 | 5 | 20 |
| M3 | 6 | 24 |
| M4 | 4 | 16 |
| M5 | 7 | 28 |
| M6 | 6 | 24 |
| M7 | 10 | 40 |
| M8 | 5 | 20 |
| M9 | 9 | 36 |
| M10 | 6 | 24 |
| M11 | 9 | 36 |

### 4. Libro de apoyo

En la sección 12, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos). En la sección General, agrega una **URL** o etiqueta al capítulo 1 ("Bienvenida").

### 5. Glosario

En la sección 12, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_ttmf.gift.txt`. Se crean *Tu Talento/M1* a *M11*, con 219 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Talento/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 | M10 | M11 |
|---|---|---|---|---|---|---|---|---|---|---|
| 18 | 15 | 18 | 12 | 21 | 18 | 30 | 15 | 27 | 18 | 27 |

### 7. Actividades H5P (73)

Archivos en `2_h5p/MN/`, en orden. En cada sección, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones: descarga no, incrustar no, derechos de autor sí.
5. Calificación: seguimiento sí, "calificación más alta". Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P en orden, autoevaluación.

### 8. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion_ttmf.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`), 4 (finalización con las 11 autoevaluaciones) y 5 (constancia con `6_certificado/certificado_fondo.png`).

### 9. Comunidad (opcional, pregunta antes)

Pregunta a la persona si quiere que crees el curso **Comunidad Tu Talento** (`TTMF-COM`, oculto). Tiene su propia carpeta y sus instrucciones: `README_CREAR_COMUNIDAD_PARA_CLAUDE.md`. La cohorte y el canal de WhatsApp los configura la persona.

### 10. Revisión final (con rol de estudiante)

- M1 U01: portada primero, dos botones de ruta, términos en color con su significado, recuadros "Dato vigente" y "Antes de actuar, verifica".
- M7 U06: la tabla de plazos de eliminación se ve completa.
- Una H5P por módulo abre, muestra 3 casos y registra calificación.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 11. Reporte para la persona

Enlace del curso; páginas por libro; H5P por módulo; preguntas por autoevaluación; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de una portada, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **oculto**. La persona decide cuándo mostrarlo.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2 y el complemento Certificado personalizado (mod_customcert), que ya están instalados en el sitio.

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo (11) | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (73) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo (11) | Calificación aprobatoria de 70% |

**Configuración de cada actividad H5P:**

- Opciones de H5P: sin botón de descarga, con botón de derechos de autor e incrustar desactivado.
- Intentos: seguimiento activado y método "Calificación más alta".
- Finalización: "El estudiante debe recibir una calificación".

**Las autoevaluaciones:** usan el banco de 219 preguntas con tres opciones y retroalimentación, en las categorías *Tu Talento/M1* a *M11*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 2,375 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 73 | 1,825 |
| Libros | 11 | 275 |
| Autoevaluaciones | 11 | 275 |
| **Total** | 95 | **2,375** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Casting | 0 | Al entrar |
| 2 | Ensayo | 250 | Durante el Módulo 2 |
| 3 | Llamado | 700 | Durante el Módulo 5 |
| 4 | Estreno | 1,200 | Durante el Módulo 7 |
| 5 | Temporada | 1,700 | Durante el Módulo 9 |
| 6 | Trayectoria | 2,150 | Durante el Módulo 11 |

**Clasificación:** anonimato activado; mostrar solo vecinos cercanos o desactivarla.

### 3. Insignias

*Administración del curso > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_dinero_real.png | Dinero real | Autoevaluación del Módulo 1 | Calculas tu ganancia real, te pagas un sueldo fijo y tienes meta de fondo de sequía. |
| 02_carrera_en_regla.png | Carrera en regla | Autoevaluaciones de los Módulos 2 y 3 | Conoces tu régimen fiscal, tus contratos y a quién acudir por tus regalías. |
| 03_se_elegir.png | Sé elegir | Autoevaluaciones de los Módulos 4 y 5 | Distingues instituciones, las verificas y comparas productos antes de contratar. |
| 04_credito_bajo_control.png | Crédito bajo control | Autoevaluaciones de los Módulos 6, 7 y 8 | Sabes que el crédito es deuda, revisas tu Buró y Círculo y tienes plan de salida. |
| 05_nadie_me_engana.png | Nadie me engaña | Autoevaluación del Módulo 9 | Reconoces fraudes, proteges tu identidad y sabes cómo responder. |
| 06_proteccion_activa.png | Protección activa | Autoevaluación del Módulo 10 | Tienes plan de salud, IMSS, seguros, marca y documentos para tu familia. |
| 07_futuro_en_escena.png | Futuro en escena | Autoevaluación del Módulo 11 | Tu retiro, tu carrera larga y tu plan de una página están escritos. |
| 08_plan_completo.png | Plan completo | Finalización del curso | Concluiste los once módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*: condición de finalización de actividades con **todas** las 11 autoevaluaciones. Opcional: los 11 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado**: nombre "Constancia de conclusión", tamaño A4 horizontal (297 × 210 mm).
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 11 autoevaluaciones, "debe estar completa con calificación aprobatoria".
3. **Editar certificado:**

   | Elemento | Posición aproximada (mm) | Formato |
   |---|---|---|
   | Imagen de fondo | Cubre la página | `6_certificado/certificado_fondo.png` |
   | Nombre del estudiante | X 0, Y 74, ancho 297, centrado | Negrita, 32 pt, color #0B1220 |
   | Fecha (finalización del curso) | X 17, Y 170, ancho 70, centrado | 12 pt, color #E4007C |
   | Código | X 210, Y 170, ancho 70, centrado | 12 pt, color #E4007C |

4. Revisa la **Vista previa en PDF** y compárala con `certificado_muestra.png`. Activa "Verificar certificado".

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos, incluidos los que se anuncian en los canales de la comunidad.


# Parte 3. Comunidad y canales

El curso Comunidad Tu Talento tiene su propia carpeta. Aquí va cómo se conecta con este curso.


### 1. Espacio de la comunidad en Moodle

Un curso aparte, **"Comunidad Tu Talento"** (nombre corto `TTMF-COM`), con:

- Un foro **"Dudas de la comunidad"** (foro de uso general).
- Un foro **"Avisos"** (solo el equipo publica).
- La descripción: "Aquí resolvemos dudas entre la comunidad. No compartas RFC, CURP, números de cuenta, montos reales ni capturas de tus estados de cuenta. Los casos personales se atienden por mensaje privado o se canalizan a un profesional."

Para inscribir al grupo de una vez, la persona administradora del sitio puede crear una **cohorte** "Tu Talento" y agregarla con el método de inscripción "Sincronización de cohortes" en el curso del programa y en la comunidad.

### 2. Canal de WhatsApp

- Nombre: "Tu Talento · Desarrolla Talento".
- Contenido: avisos del curso, fechas del SAT, alertas de fraude, recordatorios (reportes de crédito gratis, Mes del Testamento, declaración anual) y referencias.
- Solo el equipo publica; los seguidores no ven el número de los demás.
- Evitar grupos de conversación de WhatsApp: ahí los números sí son visibles.

### 3. Referencias comerciales (solo en canales)

Los servicios con acuerdo comercial se publican **solo** en el canal y en el foro de avisos, nunca en lecciones, actividades, autoevaluaciones ni constancia:

- Agencia de marca personal y redes (servicio propio).
- Despachos contables especializados en la industria creativa (referido).
- Agentes de seguros y planes de retiro (referido).

Cada publicación debe decir: **"Referencia comercial: Desarrolla Talento puede recibir una comisión. Compara con al menos otra opción. Usar este servicio es voluntario y no afecta tu acceso, tus puntos ni tu constancia."**

### 4. Reglas de moderación

1. Borrar publicaciones con datos personales o capturas de cuentas y avisar en privado.
2. No permitir que participantes promuevan productos financieros, préstamos o inversiones.
3. Reportar de inmediato cualquier mensaje que parezca fraude (M9).
4. Canalizar casos fiscales, legales o de deudas complejas a PRODECON, CONDUSEF o un profesional.


# Parte 4. Mantenimiento de los datos con fecha

Cada cifra de las lecciones va en un recuadro «Dato vigente» con fecha y fuente. La tabla completa está en el manual del programa, sección 6.

| Cuándo | Qué revisar | Lecciones |
|---|---|---|
| Enero | Nueva UMA (se publica en enero y rige desde el 1 de febrero): topes de deducciones, cuotas IMSS, exenciones | M2, M10, M11 |
| Enero | Resolución Miscelánea Fiscal del año (RESICO, declaración anual) | M2 |
| Enero | Salario mínimo y porcentajes de Modalidad 40 (suben cada año hasta 2030) | M10 U02, M11 U03 |
| Enero | Tarifas de INDAUTOR e IMPI | M10 U05 |
| Cada seis meses | Precios de Buró de Crédito y Círculo de Crédito (reportes, score, bloqueo, alertas) | M7 |
| Cada seis meses | Padrón de la CNBV e IPAB para las cuentas del fondo de sequía | M1, M5 |
| Cada año | REPEP, REUS y registro de líneas con CURP | M9 U08 |
| Septiembre | Mes del Testamento | M10 U06 |
| Después de cualquier cambio de contenido | Regenerar libros, H5P y banco y volver a armar esta carpeta | Herramientas del proyecto |
