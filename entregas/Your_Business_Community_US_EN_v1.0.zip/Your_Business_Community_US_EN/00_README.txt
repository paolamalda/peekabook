YOUR BUSINESS COMMUNITY · U.S.
Version 1.0 · United States · English · Desarrolla Talento · September 2026

Companion to the course Your Business, Your Money, Your Future (U.S.): a separate Moodle space for questions by topic, scam alerts, a forum to introduce your business, wins and a monthly live session. Complemented by a WhatsApp channel.

WHAT IS IN THIS FOLDER
----------------------
00_README.txt   This file.
01_Manual/      Teacher manual (launch, routine, live session, answers, log and ready-made texts) and community manual (spaces, channel and moderation).
02_Content/     Book "Community guide" (6 chapters) in .docx and .md.
03_Guide/       Implementation guide: step-by-step setup in Moodle and editorial calendar.
04_Moodle/      Package to install: book, preview and the README for Claude.

CHECKLIST FOR A COMPLETE COURSE
-------------------------------
[ ] Teacher named and teacher manual read
[ ] WhatsApp channel created (only the team posts)
[ ] Date and link for the first monthly session
[ ] Community created with 04_Moodle/README_CREATE_COMMUNITY_FOR_CLAUDE.md
[ ] First posts scheduled with the editorial calendar

KEEP IN MIND
------------
- Personal or tax data (SSN, ITIN, EIN, passwords) and immigration status are never requested.
- In "Introduce your business" each person may post once a month; never loans, investments or financial products.
