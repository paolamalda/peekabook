# Comunidad Tu Talento: contenido

El libro «Guía de la comunidad» que ven las personas participantes, en 6 capítulos.

## Bienvenida a la comunidad

**Comunidad Tu Talento** es el espacio para quienes toman el programa *Tu Talento, Tu Marca, Tu Futuro*: gente de la actuación, el canto, la música, la danza, el modelaje, la creación de contenido, la conducción, la producción y la técnica.

Aquí resuelves dudas, compartes avances, te enteras de fechas importantes y te alertas de fraudes junto con otras personas del medio.

### Qué encuentras aquí

| Espacio | Para qué sirve |
|---|---|
| **Avisos** | Fechas del SAT, recordatorios, sesiones en vivo y cambios en el curso. Solo publica el equipo. |
| **Preséntate** | Di quién eres y qué quieres lograr este año. |
| **Foros de dudas** | Tres foros por tema: dinero y SAT; crédito y deudas; fraudes, protección y futuro. |
| **Alertas de fraude** | Avisa de falsos castings, mensajes falsos o apps sospechosas. |
| **Logros** | Celebra tus avances: pediste tus reportes, pagaste una tarjeta, registraste tu nombre. |
| **Sesión mensual de dudas** | Una sesión en vivo al mes con el equipo. |
| **Referencias comerciales** | Servicios con acuerdo comercial, separados y señalados. Son opcionales. |

### Qué es y qué no es

- **Sí es** un lugar para aprender, preguntar y apoyarnos.
- **No es** asesoría fiscal, legal ni de inversión personalizada. Para tu caso concreto, te orientamos hacia un profesional o una institución gratuita.
- **No es** un lugar para vender productos, ofrecer préstamos ni invitar a inversiones.

### Cómo empezar

1. Lee las reglas (capítulo 2).
2. Preséntate en el foro **Preséntate**.
3. Suscríbete a **Avisos** para recibir las fechas importantes.
4. Cuando tengas una duda, usa la plantilla del capítulo 3.

### Canal de avisos en WhatsApp

Además del foro, hay un canal de WhatsApp con avisos cortos. En el canal solo publica el equipo y los seguidores no ven el número de los demás. Las dudas se resuelven aquí, en el foro.


## Reglas y privacidad

Estas reglas protegen tu información y la de todas las personas de la comunidad.

### Tus datos

- **Nunca publiques** RFC, CURP, número de INE, números de cuenta o tarjeta, contraseñas, códigos, montos reales de tus deudas ni capturas de estados de cuenta o reportes de crédito.
- Si quieres dar un ejemplo, usa **números inventados o redondeados**: "debo unos 50,000 en dos tarjetas".
- Los foros no permiten adjuntar archivos para evitar que se compartan documentos por error.

### Respeto

- Sin burlas, juicios ni culpas. Aquí todos empezamos en algún punto.
- Sin discusiones personales ni publicaciones sobre terceros con nombre y apellido.
- Las críticas a una empresa se hacen con hechos, sin insultos ni datos personales.

### Lo que no se permite

1. Vender productos o servicios, ofrecer préstamos o invitar a inversiones, tandas o grupos de "ganancias".
2. Pedir o compartir contactos de gestores, despachos o personas que "arreglan" el Buró, el SAT o el IMSS.
3. Publicar enlaces acortados o de sitios no oficiales para trámites.
4. Hacerse pasar por el equipo, por una institución o por otra persona.

### Qué hace el equipo de moderación

- Retira publicaciones con datos personales y te avisa en privado.
- Retira publicaciones que venden, prestan o invitan a invertir.
- Responde dudas generales y canaliza los casos personales.
- Puede suspender la participación de quien no respete las reglas.

### Si algo te parece fraude

Publícalo en **Alertas de fraude** sin datos personales, o escribe en privado al equipo. Si ya te afectó, sigue tu plan de respuesta (M9 U09): bloquea, reclama por escrito, reporta al 088 y a CONDUSEF.

### Referencias comerciales

Los servicios con acuerdo comercial solo aparecen en el foro **Referencias comerciales** y en el canal, siempre marcados. Usarlos es voluntario y no afecta tu acceso, tus puntos ni tu constancia.


## Cómo preguntar para recibir una buena respuesta

Una pregunta clara recibe una respuesta útil más rápido.

### Plantilla

**Módulo o tema:** (por ejemplo, M7 Buró y Círculo)
**Mi situación, sin datos personales:** (por ejemplo, "soy músico, facturo en RESICO y una disquera me quiere pagar como asimilado")
**Lo que ya intenté o revisé:** (por ejemplo, "leí la lección M2 U01")
**Mi duda concreta:** (una pregunta, no cinco)

### Ejemplo

**Módulo o tema:** M7, reclamaciones.
**Mi situación:** una tarjeta que liquidé hace un año aparece con saldo en Círculo, no en Buró.
**Lo que ya intenté:** tengo mi carta de liquidación.
**Mi duda concreta:** ¿reclamo solo en Círculo o también al banco?

### Lo que el foro puede y no puede resolver

| Sí | No |
|---|---|
| Dudas sobre lo que explica el curso | Calcular tus impuestos exactos |
| Cómo comparar opciones | Decirte qué banco, seguro o inversión contratar |
| Qué institución te puede ayudar | Revisar tu contrato completo |
| Pasos para reclamar o verificar | Representarte ante el SAT o un juzgado |

Para lo que no se resuelve aquí, revisa **Dónde encontrar ayuda** en el libro de apoyo del curso: PRODECON, CONDUSEF, PROFEDET, IMSS, INDAUTOR, IMPI y más, casi todos gratuitos.

### Responder a otras personas

Puedes compartir tu experiencia. Hazlo así:

- Di que es tu experiencia, no una regla: "a mí me funcionó…".
- No recomiendes marcas, despachos ni personas.
- Si no estás seguro, remite a la lección o a la institución oficial.


## Tu calendario del año

Fechas y recordatorios que importan a quien trabaja por su cuenta en el medio. En **Avisos** y en el canal te recordamos cada una a tiempo.

### Cada mes

| Cuándo | Qué hacer | Lección |
|---|---|---|
| Día 1 y 16 | Pagarte tu sueldo fijo desde tu cuenta concentradora | M1 U02 |
| Antes del día 17 | Declarar ISR e IVA del mes anterior, si te corresponde | M2 U04 |
| Antes del día 20 | Pagar tu cuota de la Modalidad 10 del IMSS, si estás inscrito | M10 U02 |
| Cada fecha límite | Pagar tus tarjetas al menos el mínimo; mejor, el pago para no generar intereses | M6 U02 |
| Cada mes | Revisar tu buzón tributario y tu inventario de deudas | M2 U04 · M6 U04 |

### A lo largo del año

| Mes | Recordatorio | Lección |
|---|---|---|
| Enero | Cuesta de enero: revisa tu fondo de sequía y tu plan de deudas | M1 U03 · M8 U05 |
| Febrero | Entra en vigor el nuevo valor de la UMA (topes de deducciones y cuotas). Inscribe tus números en el REPEP y el REUS si aún no lo haces | M2 U05 · M9 U08 |
| Marzo | Junta tus facturas de deducciones personales para la anual | M2 U05 |
| Abril | Declaración anual de personas físicas, si te corresponde | M2 U05 |
| Mayo | Revisa tu AFORE y actualiza beneficiarios | M11 U02 |
| Junio | Pide tu reporte gratis de una sociedad (por ejemplo, Buró) | M7 U03 |
| Julio | Revisión de medio año de tu plan de una página | M11 U09 |
| Agosto | Revisa tus seguros y la vigencia de tus pólizas | M10 U01 |
| Septiembre | Mes del Testamento: descuentos en notarías | M10 U06 |
| Octubre | Revisa la vigencia de tu reserva de nombre y tu marca | M10 U05 |
| Noviembre | Buen Fin: suma tus mensualidades antes de comprar a meses | M6 U03 |
| Diciembre | Pide tu reporte gratis de la otra sociedad (por ejemplo, Círculo) y planea el reparto de tus pagos de fin de año | M7 U03 · M11 U01 |

### Solo en 2026

| Cuándo | Qué hacer | Lección |
|---|---|---|
| Según la terminación de tu número, a más tardar el 31 de diciembre de 2026 | Vincula tu línea de celular con tu CURP y consulta si hay líneas a tu nombre que no reconoces | M9 U08 |

Además, renueva tu inscripción en el REUS cada dos años.

Las fechas oficiales pueden cambiar. Confírmalas en el sitio del SAT, el IMSS, CONDUSEF o la institución que corresponda.


## Sesiones en vivo y actividades

### Sesión mensual de dudas

Una vez al mes, el equipo responde en vivo las dudas más votadas de la comunidad. La fecha y el enlace se publican en **Avisos** y en el canal.

- Duración: 60 minutos.
- Se responden dudas generales, sin revisar casos personales en público.
- Si quieres que tu duda entre, publícala en el foro de tu tema con la plantilla del capítulo 3.

### Encuesta de temas

Cada mes puedes votar qué tema se trabaja en la siguiente sesión, en la actividad **¿Qué tema quieres en la próxima sesión?**

### Retos del mes

Cada mes proponemos un reto corto en **Avisos**. Cuando lo cumplas, compártelo en **Logros**, sin datos personales.

| Mes | Reto |
|---|---|
| 1 | Calcula tu ganancia real de tu último proyecto |
| 2 | Págate un sueldo fijo durante un mes e inscribe tus números en el REPEP y el REUS |
| 3 | Pide tu reporte gratis en Buró o en Círculo |
| 4 | Haz tu inventario de deudas |
| 5 | Activa la verificación en dos pasos en tu correo y tus redes |
| 6 | Verifica en el SIPRES a una institución con la que tienes un producto |
| 7 | Aparta tu primer mes de fondo de sequía |
| 8 | Busca tu AFORE con tu CURP |
| 9 | Agenda tu testamento |
| 10 | Busca tu nombre artístico en el IMPI |
| 11 | Suma tus mensualidades antes del Buen Fin |
| 12 | Escribe tu plan de una página para el próximo año |

### Encuesta de la comunidad

Dos veces al año te pedimos tu opinión en la actividad **Encuesta de la comunidad**. Es anónima y nos ayuda a mejorar.


## Cómo funcionan las referencias comerciales

Queremos que sepas exactamente qué es educación y qué es una oferta comercial.

### Dónde aparecen

- **Solo** en el foro **Referencias comerciales** y en el canal de WhatsApp.
- **Nunca** en las lecciones, las actividades, las autoevaluaciones, las insignias ni la constancia del curso.

### Qué dicen siempre

Cada publicación incluye este aviso:

> **Referencia comercial:** Desarrolla Talento puede recibir una comisión si contratas este servicio. Compara con al menos otra opción. Usarlo es voluntario y no afecta tu acceso, tus puntos ni tu constancia.

### Qué tipo de servicios se publican

- Servicios propios de Desarrolla Talento, como marca personal y redes.
- Despachos contables especializados en la industria creativa.
- Agentes de seguros y planes de retiro.

### Antes de contratar cualquiera

Aplica lo que aprendiste en el curso:

1. Verifica la autorización: cédula del contador, cédula del agente de seguros en la CNSF, registro de la institución.
2. Pide el costo total por escrito.
3. Compara con al menos otra opción.
4. Recuerda que decir "no" también es una buena decisión.

### Si algo no te pareció correcto

Escríbenos en privado. Si un servicio referido no cumple, lo retiramos de la lista.

