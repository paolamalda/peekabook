# Tu Idea, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Módulo 1. Tu mente y tu dinero

## M1 U01. Mente que crea: el dinero no es solo para guardarlo

**Lo que lograrás:** Distinguir entre guardar, gastar y hacer crecer el dinero, y empezar a pensar en qué puedes crear con lo que tienes.

**Para empezar:** Valeria tiene 16 años y 1,500 pesos guardados en una alcancía desde hace dos años. Su prima usó 1,500 para comprar material, hizo pulseras y ya lleva 4,200 vendidos. En esta lección verás la diferencia.

### Lo esencial (5 minutos)

#### Tres cosas que puedes hacer con el dinero

Con tu dinero puedes hacer tres cosas. **Gastarlo**: se va. **Guardarlo**: se queda quieto y con el tiempo compra menos. O **ponerlo a trabajar**: en una idea que genere más dinero, en aprender algo que te haga ganar más o en una inversión. Guardar es la base; crear es el siguiente paso.



#### Tres formas de usar el dinero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gastar | Lo disfrutas hoy. | Se va. |
| Guardar | Te protege. | Parado, pierde valor. |
| Poner a trabajar | Una idea, aprender o invertir. | Puede crecer. |

#### Lo que hizo la prima de Valeria

- Material para pulseras: **1,500**
- Lo que vendió por cada peso de material: **2.8**
- Ventas en tres meses: **4,200**
Menos el material, le quedaron 2,700 de ganancia para volver a invertir.


#### Un caso en un minuto

Valeria se preguntó: «¿Qué sé hacer que otras personas quieran?». Hace postres muy buenos. Usó 500 de su alcancía para probar, dejó 1,000 como su guardadito y vendió 30 postres en la escuela.

> **Idea clave:** guardar te protege, pero crear te hace crecer; aparta una base para emergencias y pon una parte a trabajar en algo que genere.



#### Comprueba lo que entendiste

1. ¿Qué le pasa al dinero parado mucho tiempo?
*Respuesta:* Pierde valor porque los precios suben.

2. ¿Qué es poner el dinero a trabajar?
*Respuesta:* Usarlo en una idea, en aprender o en una inversión que genere más.


#### Para recordar

- Gastar, guardar o poner a trabajar.
- Guardar es la base.
- Crear es crecer.



### Profundiza (5 minutos más)

#### Mente que guarda y mente que crea

| Mente que solo guarda | Mente que crea |
|---|---|
| «No lo toco para no perderlo» | «¿Qué puedo generar con una parte?» |
| Espera a tener mucho | Empieza con poco y prueba |
| Ve el error como pérdida | Ve el error como aprendizaje |
| Piensa en cuánto tiene | Piensa en cuánto puede generar |



#### Crear con cabeza

Crear no es arriesgarlo todo. La regla: primero un guardadito para imprevistos; luego pruebas con una parte que puedas perder sin problema; y si funciona, reinviertes la ganancia.



#### Casos


**Caso 1. La alcancía de Valeria**

Valeria tiene 1,500 guardados y quiere empezar a vender postres.
- *¿Qué hace?* Deja una base guardada y prueba con una parte que podría perder.


**Caso 2. El ahorro de Emilio**

Emilio guarda todo lo que gana en la taquería en su cajón desde hace un año.
- *¿Qué hace?* Piensa en qué puede aprender o crear con una parte, y guarda el resto en una cuenta.


**Caso 3. El miedo de Naomi**

Naomi quiere vender dibujos, pero le da miedo perder su dinero.
- *¿Qué hace?* Empieza con poco para probar y aprende de lo que salga.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar todo parado | Pierde valor | Pon una parte a trabajar |
| Arriesgarlo todo | Te quedas sin nada | Solo una parte |
| Esperar a tener mucho | Nunca empiezas | Empieza con poco |
| Ver el error como fracaso | Te rindes | Es aprendizaje |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es poner el dinero a trabajar? a) Esconderlo en tu cuarto para no gastarlo · b) Gastarlo en lo que se te antoje · c) Usarlo para generar más
2. Antes de probar una idea, ¿qué haces? a) Pides prestado para empezar en grande · b) Apartas una base para imprevistos · c) Usas todo lo que tienes
3. Inviertes 600 en material y vendes 1,500. ¿Cuánto ganas? a) 1,500 · b) 2,100 · c) 900
**Respuestas:** 1-c: es la idea de crecer. 2-b: crear con cabeza. 3-c: ventas menos material.



#### Ponlo en práctica

Tienes 2,000. Quieres guardar 60% como base y probar una idea con el resto. ¿Cuánto guardas y cuánto usas?
**Respuesta:** Guardas 1,200 y usas 800 para probar.



#### A tu plan

Escribe una cosa que sabes hacer y que otras personas podrían querer.



### Para saber más

- **Emprendimiento para jóvenes** (Gobierno de México · español): https://www.gob.mx — **Qué buscar:** «emprendimiento juvenil» y programas de tu estado.

### Palabras clave

- *Ganancia:* lo que te queda después de restar lo que gastaste para vender.
- *Reinvertir:* volver a usar la ganancia para que tu idea crezca.

### Fuentes

Banco de México, inflación · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M1 U02. ¿De dónde sale el dinero? Tus fuentes de ingreso

**Lo que lograrás:** Identificar las formas de ganar dinero (trabajo, negocio, habilidades, inversión y apoyos) y cuáles puedes empezar a tu edad.

**Para empezar:** Emilio, de 17, trabaja sábados y domingos en una taquería y gana 700 a la semana. Santi, de 18, repara celulares en su casa y este mes ganó 3,200. Los dos quieren ganar más. En esta lección verás de dónde sale el dinero.

### Lo esencial (5 minutos)

#### Fuentes de ingreso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Trabajo | Te pagan por tu tiempo. | Pago fijo o por día. |
| Negocio | Vendes algo o un servicio. | Puedes ganar más, con riesgo. |
| Habilidad | Algo que sabes hacer: reparar, diseñar, enseñar. | Se cobra por proyecto. |
| Inversión | Tu dinero gana dinero. | Necesitas tiempo. |
| Apoyos y becas | Beca Benito Juárez en prepa pública. | Para estudiar. |

#### Tu tiempo tiene precio

Divide lo que ganas entre las horas que trabajas: así sabes cuánto vale tu hora. Con eso puedes comparar un trabajo con una idea propia.



#### La hora de Emilio

- A la semana: **700**
- Horas: **16**
- Por hora: **43.75**
Santi ganó 3,200 en 40 horas: 80 por hora con su habilidad.


#### Un caso en un minuto

Emilio vio que Santi gana casi el doble por hora con una habilidad. Se inscribió a un curso en línea de reparación de bicicletas y empezó a ofrecer el servicio a sus vecinos, sin dejar la taquería.

> **Idea clave:** hay varias formas de ganar dinero; tu hora vale más cuando aprendes una habilidad que otras personas necesitan.



#### Comprueba lo que entendiste

1. ¿Cómo sabes cuánto vale tu hora?
*Respuesta:* Divides lo que ganas entre las horas que trabajas.

2. ¿Qué hace que tu hora valga más?
*Respuesta:* Aprender una habilidad que otras personas necesitan.


#### Para recordar

- Trabajo, negocio, habilidad, inversión y becas.
- Calcula tu hora.
- Aprender sube tu valor.



### Profundiza (5 minutos más)

#### Si tienes 15 a 17 años y trabajas

| La ley dice | Qué significa |
|---|---|
| Desde los 15 años puedes trabajar | Con límites para cuidarte |
| Máximo 6 horas al día | En dos turnos de 3 horas |
| Sin trabajo nocturno ni peligroso | Protege tu salud |
| Tu escuela va primero | El trabajo no debe impedirte estudiar |

> **Dato vigente:** la Ley Federal del Trabajo permite trabajar a partir de los 15 años. Si tienes menos de 18, la jornada máxima es de 6 horas diarias, sin trabajo nocturno ni actividades peligrosas. Consultado el 30 de septiembre de 2026 a través de la Ley Federal del Trabajo y la STPS.



#### Ingresos que no son dinero

Aprender, hacer contactos y tener experiencia también son ganancias: te abren puertas para ganar más después.



#### Casos


**Caso 1. La hora de Emilio**

Emilio gana 43 por hora en la taquería y quiere ganar más.
- *¿Qué hace?* Aprende una habilidad que otras personas necesiten.


**Caso 2. El horario de Naomi**

Le ofrecen a Naomi, de 15, trabajar de 7 de la noche a 2 de la mañana.
- *¿Qué hace?* No acepta: a su edad la ley prohíbe el trabajo nocturno.


**Caso 3. Los clientes de Santi**

Santi tiene más reparaciones de las que puede hacer.
- *¿Qué hace?* Sube un poco su precio y ordena sus horarios.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Solo pensar en un trabajo | Menos opciones | Conoce todas las fuentes |
| No calcular tu hora | No sabes qué conviene | Divide |
| Dejar la escuela por trabajar | Ganas menos después | Estudia primero |
| Aceptar trabajo nocturno siendo menor | Te arriesgas | La ley te protege |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Naomi y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Ganas 900 en 12 horas. ¿Cuánto vale tu hora? a) 108 · b) 900 · c) 75
2. ¿Cuántas horas al día puede trabajar alguien de 16 años? a) Las que le pidan en el trabajo · b) Máximo 6 · c) Máximo 10
3. ¿Qué sube el valor de tu hora? a) Trabajar más horas sin descansar los fines de semana · b) Cobrar menos que los demás · c) Aprender una habilidad que se necesita
**Respuestas:** 1-c: 900 entre 12. 2-b: la ley pone ese límite. 3-c: te pagan más por saber.



#### Ponlo en práctica

Das clases de matemáticas: 3 horas a la semana a 120 la hora. ¿Cuánto ganas al mes (4 semanas)?
**Respuesta:** 3 por 120: 360 por semana; por 4: 1,440 al mes.



#### A tu plan

Calcula cuánto vale tu hora hoy y escribe una habilidad que te gustaría aprender para ganar más.



### Para saber más

- **Trabajo de adolescentes** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** «trabajo adolescente permitido».

### Palabras clave

- *Ingreso:* dinero que recibes por trabajar, vender, invertir o por un apoyo.
- *Habilidad:* algo que sabes hacer bien y que otras personas pueden necesitar.

### Fuentes

Ley Federal del Trabajo · STPS · Programas para el Bienestar, consultados el 30 de septiembre de 2026.

---

## M1 U03. Influencers, antojos y presión: quién decide tus compras

**Lo que lograrás:** Reconocer cómo la publicidad, los influencers, las redes y tus amistades influyen en lo que compras, y decidir tú.

**Para empezar:** Naomi vio a una influencer con unos tenis «que todo mundo trae». Con el código de descuento «solo hoy» costaban 1,900. Los compró con el dinero que le mandan sus papás. A la semana, ya había otros de moda. En esta lección verás quién decide tus compras.

### Lo esencial (5 minutos)

#### Te venden emociones

La publicidad y muchos influencers no te venden un producto: te venden la sensación de pertenecer, verte bien o no quedarte fuera. Si alguien gana dinero cuando compras, su opinión no es neutral.



#### Trucos para que compres

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Solo hoy» | Prisa para que no pienses. | Espera un día. |
| «Todo mundo lo tiene» | Presión de grupo. | Tú decides. |
| Código de influencer | Le pagan si compras. | Es publicidad. |
| Skins y cajas sorpresa | Pagos chiquitos que suman. | Suma el mes. |

#### Los pagos chiquitos de Naomi

- Skin o paquete de juego: **99**
- Veces al mes: **8**
- Al mes: **792**
En un año: 9,504, casi tres pares de tenis.


#### Un caso en un minuto

Naomi puso una regla: si algo le gusta, lo guarda en su lista 7 días. Si lo sigue queriendo y le alcanza, lo compra. La mitad de las cosas ya no las quiso.

> **Idea clave:** si alguien gana cuando compras, su opinión no es neutral. Espera antes de comprar y decide tú, no la presión ni el «solo hoy».



#### Comprueba lo que entendiste

1. ¿Por qué un código de influencer es publicidad?
*Respuesta:* Porque le pagan si compras.

2. ¿Qué es la regla de los 7 días?
*Respuesta:* Esperar una semana antes de comprar algo que no necesitas.


#### Para recordar

- Te venden emociones.
- Quien gana cuando compras no es neutral.
- Espera 7 días.



### Profundiza (5 minutos más)

#### Antes de comprar pregúntate

| Pregunta | Si la respuesta es no |
|---|---|
| ¿Lo necesito o lo quiero por presión? | Espera |
| ¿Lo seguiré usando en un mes? | Espera |
| ¿Cuántas horas de trabajo me cuesta? | Piensa si lo vale |
| ¿Hay algo mejor que puedo hacer con ese dinero? | Ponlo a trabajar |



#### Compras dentro de apps y juegos

Las cajas sorpresa y los paquetes funcionan como apuestas: pagas sin saber qué te toca. Pon un límite al mes y desactiva las compras con un clic.



#### Casos


**Caso 1. Los tenis de Naomi**

Naomi ve unos tenis con código de descuento «solo hoy».
- *¿Qué hace?* Los pone en su lista y espera 7 días antes de decidir.


**Caso 2. Las skins de Emilio**

Emilio gasta en skins casi cada fin de semana.
- *¿Qué hace?* Suma lo que gasta al mes y se pone un límite.


**Caso 3. La salida de Valeria**

Sus amigas quieren ir a un lugar caro y Valeria está ahorrando para su negocio.
- *¿Qué hace?* Propone un plan más barato o va otro día.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que el influencer opina neutral | Compras de más | Es publicidad |
| Comprar por «solo hoy» | Te arrepientes | Espera |
| No sumar pagos chiquitos | Se va mucho dinero | Súmalos al mes |
| Comprar por presión | Gastas en lo que no quieres | Tú decides |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Emilio y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Gastas 79 en un juego 6 veces al mes. ¿Cuánto al año? a) 474 · b) 5,688 · c) 948
2. ¿Por qué un código de descuento de influencer no es opinión neutral? a) Porque es muy famoso y tiene millones de seguidores · b) Porque siempre miente · c) Porque le pagan si compras
3. ¿Qué haces con una oferta «solo hoy»? a) Compras antes de que se acabe · b) Pides prestado · c) Esperas y comparas
**Respuestas:** 1-b: 474 al mes por 12. 2-c: gana con tu compra. 3-c: la prisa es el truco.



#### Ponlo en práctica

Unos audífonos cuestan 1,200 y ganas 50 por hora. ¿Cuántas horas de trabajo te cuestan?
**Respuesta:** 1,200 entre 50: 24 horas.



#### A tu plan

Crea tu lista de 7 días en el celular y anota ahí la próxima cosa que quieras comprar.



### Para saber más

- **Publicidad y compras** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «compras en línea» y «publicidad engañosa».

### Palabras clave

- *Publicidad:* mensaje pagado para que compres algo.
- *Presión de grupo:* cuando haces algo para encajar con tus amistades.

### Fuentes

PROFECO, consultado el 30 de septiembre de 2026.

---

## M1 U04. Tu presupuesto: mesada, beca y lo que ganas

**Lo que lograrás:** Hacer un presupuesto sencillo con lo que recibes (mesada, beca, trabajo o ventas) y repartirlo en gastar, guardar y crear.

**Para empezar:** Santi recibe su beca, gana con las reparaciones y a veces su mamá le da para pasajes. Nunca sabe cuánto tiene y a fin de mes siempre le falta. En esta lección harás tu presupuesto.

### Lo esencial (5 minutos)

#### Lo que entra y lo que sale

Un presupuesto es tu mapa: cuánto te entra al mes y a dónde va. Sin mapa, el dinero se va sin que te des cuenta.



#### Reparte en tres

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gastar | Pasajes, comida, salidas. | Lo de todos los días. |
| Guardar | Tu base para imprevistos. | Primero. |
| Crear | Tu idea, un curso o inversión. | Lo que te hace crecer. |

#### El mes de Santi

- Beca (1,900 cada dos meses): **950**
- Reparaciones: **3,200**
- Pasajes de su mamá: **400**
- Le entra al mes: **4,550**
Aparta 10% para guardar (455) y 20% para crear (910).

> **Dato vigente:** la Beca Benito Juárez para estudiantes de preparatoria pública da 1,900 pesos cada dos meses. Son cinco depósitos al año, en una tarjeta del Banco del Bienestar. Consultado el 30 de septiembre de 2026 a través de Programas para el Bienestar.


#### Un caso en un minuto

Santi anotó un mes lo que le entra y lo que gasta. Ahora el día que cobra aparta primero para guardar y para crear. Con lo de crear compró herramientas y ya repara más rápido.

> **Idea clave:** anota lo que te entra y reparte el mismo día que cobras: guardar y crear primero, gastar con lo que queda.



#### Comprueba lo que entendiste

1. ¿Qué es un presupuesto?
*Respuesta:* Un plan de cuánto te entra y en qué lo usas.

2. ¿Qué apartas primero?
*Respuesta:* Lo de guardar y lo de crear.


#### Para recordar

- Anota lo que entra.
- Guardar y crear primero.
- Gasta lo que queda.



### Profundiza (5 minutos más)

#### Tu presupuesto del mes

| Concepto | Cuánto |
|---|---|
| Beca | |
| Mesada o apoyo | |
| Trabajo o ventas | |
| Total que entra | |
| Guardar (10%) | |
| Crear (20%) | |
| Gastar (el resto) | |



#### Si das dinero en tu casa

Si aportas a tu casa, inclúyelo en tu presupuesto. Ayudar es parte de tu vida; ponerle monto te permite ayudar sin quedarte sin nada.



#### Casos


**Caso 1. El fin de mes de Santi**

Santi no sabe cuánto tiene y a fin de mes le falta.
- *¿Qué hace?* Anota un mes lo que entra y lo que sale, y reparte el día que cobra.


**Caso 2. La beca de Valeria**

Valeria recibe su beca y se la gasta en la primera semana.
- *¿Qué hace?* Divide la beca entre los dos meses y aparta primero.


**Caso 3. El dinero de Naomi**

Los papás de Naomi le mandan dinero cada mes desde Estados Unidos.
- *¿Qué hace?* Lo incluye en su presupuesto y aparta para guardar y crear.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No anotar | No sabes a dónde va | Un mes de registro |
| Gastar primero | No queda nada | Guardar y crear primero |
| Gastar la beca de golpe | Te falta después | Divídela |
| Olvidar lo que das en casa | Te quedas corto | Inclúyelo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Valeria y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Recibes 1,900 de beca cada dos meses. ¿Cuánto es al mes? a) 1,900 · b) 3,800 · c) 950
2. ¿Qué apartas primero cuando cobras? a) Lo de las salidas del fin de semana · b) Lo de gustos y antojos · c) Lo de guardar y crear
3. Te entran 3,000 al mes. ¿Cuánto es 20% para crear? a) 600 · b) 300 · c) 2,000
**Respuestas:** 1-c: 1,900 entre 2. 2-c: primero tú y tu idea. 3-a: 20% de 3,000.



#### Ponlo en práctica

Te entran 2,400 al mes. Guardas 10% y usas 25% para crear. ¿Cuánto te queda para gastar?
**Respuesta:** 10%: 240. 25%: 600. 2,400 menos 840: 1,560.



#### A tu plan

Anota durante un mes todo lo que te entra y todo lo que gastas.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto personal» y «jóvenes».
- **Beca Benito Juárez** (Programas para el Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «Beca Benito Juárez».

### Palabras clave

- *Presupuesto:* plan de cuánto dinero te entra y en qué lo vas a usar.
- *Mesada:* dinero que te dan en tu casa cada semana o mes.

### Fuentes

Programas para el Bienestar · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 2. Módulo 2. Tu cuenta y el dinero digital

## M2 U01. Tu primera cuenta

**Lo que lograrás:** Explicar cómo abrir tu primera cuenta siendo menor de edad, qué revisar (comisiones, protección, límites) y la diferencia entre tarjeta de débito y de crédito.

**Para empezar:** Valeria ya vende postres y guarda el dinero en una caja de zapatos. Su hermano le dijo que abra una cuenta, pero ella tiene 16 y cree que no puede. En esta lección verás cómo.

### Lo esencial (5 minutos)

#### Sí puedes tener cuenta

Siendo menor de edad, muchos bancos te abren una cuenta con tu mamá, papá o tutor como cotitular o autorizando. Al cumplir 18 puedes abrirla solo con tu INE. Tu beca ya llega a una tarjeta del Banco del Bienestar.



#### Qué revisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisiones | Que no cobre por manejo. | Pregunta por la cuenta básica. |
| Protección | Bancos: seguro del IPAB. | Revisa que sea banco. |
| Límites | Algunas cuentas tienen tope de depósitos al mes. | Pregunta. |
| Débito | Gastas tu propio dinero. | No es préstamo. |

#### Débito contra crédito

Con la tarjeta de **débito** pagas con tu dinero: si no tienes, no pasa. Con la de **crédito** el banco te presta y, si no pagas completo, cobras intereses (M6). Empieza con débito.



#### Un caso en un minuto

Valeria fue al banco con su mamá y abrieron una cuenta sin comisiones. Ahora sus clientes le pagan por transferencia y su dinero está protegido.

> **Idea clave:** siendo menor puedes tener cuenta con un adulto; busca una sin comisiones, protegida por el IPAB, y empieza con tarjeta de débito.



#### Comprueba lo que entendiste

1. ¿Puedes tener cuenta siendo menor de edad?
*Respuesta:* Sí, con tu mamá, papá o tutor.

2. ¿Qué diferencia hay entre débito y crédito?
*Respuesta:* Con débito usas tu dinero; con crédito te prestan.


#### Para recordar

- Cuenta con un adulto.
- Sin comisiones y con IPAB.
- Empieza con débito.



### Profundiza (5 minutos más)

#### Preguntas para el banco

| Pregunta | Respuesta que buscas |
|---|---|
| ¿Cobra comisión por manejo? | No |
| ¿Está protegida por el IPAB? | Sí, si es banco |
| ¿Tiene tope de depósitos? | Que alcance para ti |
| ¿Tiene app con alertas? | Sí |

> **Dato vigente:** el IPAB protege los depósitos en bancos hasta 400,000 UDIS por persona y por banco. Consultado el 30 de septiembre de 2026 a través del IPAB.



#### Cuentas en apps

Hay apps que parecen bancos pero no lo son. Revisa en el SIPRES de la CONDUSEF qué tipo de institución es y si sus depósitos tienen protección.



#### Casos


**Caso 1. La caja de zapatos de Valeria**

Valeria guarda lo que vende en una caja y cree que no puede tener cuenta.
- *¿Qué hace?* Va al banco con su mamá y abre una cuenta sin comisiones.


**Caso 2. La app de Emilio**

Una app le ofrece a Emilio «cuenta con rendimientos altísimos».
- *¿Qué hace?* Revisa en el SIPRES qué institución es y si tiene protección.


**Caso 3. La tarjeta de Santi**

Le ofrecen a Santi, que acaba de cumplir 18, una tarjeta de crédito al abrir su cuenta.
- *¿Qué hace?* Empieza con débito y aprende primero cómo funciona el crédito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Guardar todo en efectivo | Se pierde o te lo roban | Cuenta |
| No preguntar comisiones | Te descuentan | Cuenta sin comisión |
| Confundir app con banco | Sin protección | Verifica |
| Empezar con crédito | Deudas | Débito primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tienes 16 años. ¿Cómo abres una cuenta? a) No puedes hasta los 21 · b) Solo por internet sin nadie · c) Con tu mamá, papá o tutor
2. ¿Qué pasa si pagas con débito y no tienes saldo? a) Te prestan · b) No pasa el pago · c) Te cobran intereses
3. ¿Qué protege tus depósitos en un banco? a) La tienda donde compras · b) Tu escuela · c) El IPAB
**Respuestas:** 1-c: te acompañan. 2-b: usas tu dinero. 3-c: seguro de depósitos.



#### Ponlo en práctica

Tu cuenta cobra 80 al mes de manejo. ¿Cuánto pierdes al año?
**Respuesta:** 80 por 12: 960.



#### A tu plan

Pregunta en tu casa si puedes abrir una cuenta sin comisiones con un adulto.



### Para saber más

- **Cuenta básica** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica» y «cuentas para menores».
- **Protección de tus depósitos** (IPAB · español): https://www.gob.mx/ipab — **Qué buscar:** «seguro de depósitos».

### Palabras clave

- *Tarjeta de débito:* tarjeta para pagar con tu propio dinero.
- *IPAB:* seguro que protege tus depósitos en bancos.
- *Cotitular:* otra persona que comparte la cuenta contigo.

### Fuentes

CONDUSEF · IPAB, consultados el 30 de septiembre de 2026.

---

## M2 U02. Pagar y cobrar con el celular

**Lo que lograrás:** Cobrar y pagar por transferencia, QR o número de celular con seguridad, guardar comprobantes y saber qué hacer si te equivocas.

**Para empezar:** Santi cobra sus reparaciones en efectivo y a veces le pagan con billetes falsos. Un cliente le dijo «ya te transferí» pero el dinero nunca llegó. En esta lección verás cómo cobrar seguro.

### Lo esencial (5 minutos)

#### Formas de cobrar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transferencia | A tu CLABE o número de tarjeta. | Queda registro. |
| Código QR | El cliente lo escanea. | Rápido. |
| Número de celular | Si tu banco lo tiene. | Sin CLABE. |
| Efectivo | Útil, pero riesgoso. | Carga poco. |

#### Confirma antes de entregar

Una captura de pantalla se puede falsificar. Antes de entregar, **revisa en tu app que el dinero llegó**. Para pagos grandes puedes pedir el comprobante electrónico de pago (CEP) de Banco de México.



#### Si te equivocas al transferir

Si mandas dinero a la cuenta equivocada, avisa a tu banco de inmediato. No siempre se puede recuperar: revisa el nombre de quien recibe antes de enviar.



#### Un caso en un minuto

Santi imprimió un QR de su cuenta y lo pegó en su mesa. Antes de entregar cada celular revisa su app. Ya no ha perdido ningún pago.

> **Idea clave:** cobra por transferencia o QR, revisa en tu app que el dinero llegó antes de entregar y verifica el nombre antes de enviar.



#### Comprueba lo que entendiste

1. ¿Por qué no confiar en una captura de pantalla?
*Respuesta:* Porque se puede falsificar.

2. ¿Qué revisas antes de enviar dinero?
*Respuesta:* El nombre de quien lo recibe.


#### Para recordar

- Transferencia o QR.
- Revisa en tu app.
- Verifica el nombre antes de enviar.



### Profundiza (5 minutos más)

#### Datos para cobrar y datos que nunca das

| Para cobrar das | Nunca das |
|---|---|
| Tu CLABE | Tu NIP |
| Tu número de celular ligado | Tus contraseñas |
| Tu QR | Los códigos que te llegan |



#### Cuando te piden «devolver» un depósito

Si alguien te deposita «por error» y te pide que le regreses el dinero a otra cuenta, no lo hagas. Puede ser un fraude, o tu cuenta puede usarse como cuenta mula (M7 U03). Avisa a tu banco.



#### Casos


**Caso 1. El «ya te transferí»**

Un cliente le enseña a Santi una captura: «ya te transferí».
- *¿Qué hace?* Revisa en su app que el dinero llegó antes de entregar.


**Caso 2. El error de Naomi**

Naomi mandó 300 a la cuenta equivocada.
- *¿Qué hace?* Avisa a su banco de inmediato y la próxima vez verifica el nombre.


**Caso 3. El depósito de Emilio**

Alguien le depositó a Emilio 2,000 «por error» y le pide devolverlos a otra cuenta.
- *¿Qué hace?* No devuelve nada a otra cuenta y avisa a su banco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confiar en capturas | Te engañan | Revisa tu app |
| No verificar el nombre | Dinero perdido | Revisa antes de enviar |
| Dar tu NIP | Te vacían | Nunca |
| Devolver «depósitos por error» | Fraude | Avisa al banco |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Naomi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces antes de entregar lo que vendiste? a) Aceptas la captura que te enseña el cliente en su celular · b) Revisas en tu app que llegó el dinero · c) Confías en su palabra
2. ¿Qué dato NO das para cobrar? a) Tu CLABE · b) Tu QR · c) Tu NIP
3. Te depositan «por error» y te piden devolver a otra cuenta. ¿Qué haces? a) Lo devuelves rápido · b) Te lo quedas · c) Avisas a tu banco
**Respuestas:** 1-b: una captura se falsifica. 2-c: es secreto. 3-c: puede ser fraude.



#### Ponlo en práctica

Cobras 12 reparaciones de 250 al mes. Si 1 de cada 12 pagos en efectivo fuera falso, ¿cuánto perderías al mes?
**Respuesta:** 250 al mes; en un año, 3,000.



#### A tu plan

Haz tu QR de cobro en tu app o anota tu CLABE para compartirla.



### Para saber más

- **CEP: comprobante electrónico de pago** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «CEP».

### Palabras clave

- *CLABE:* número de 18 dígitos para recibir transferencias.
- *CEP:* comprobante de Banco de México que confirma una transferencia.

### Fuentes

Banco de México · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M2 U03. Compras en línea y dinero de otro país

**Lo que lograrás:** Comprar en línea con seguridad, entender el tipo de cambio cuando pagas o recibes en dólares, y conocer tus derechos como consumidor.

**Para empezar:** Naomi compró una sudadera en una tienda extranjera: decía 25 dólares. En su estado de cuenta vio que le cobraron casi 500 pesos. Y cuando sus papás le mandan dólares, no entiende por qué le llegan distintos pesos cada mes. En esta lección lo verás.

### Lo esencial (5 minutos)

#### El tipo de cambio

El tipo de cambio cambia todos los días. Cuando pagas en dólares, tu banco convierte a pesos y a veces cobra una comisión. Cuando te mandan dólares, recibes pesos según el tipo de cambio de ese día.



#### La sudadera de Naomi

- Dólares: **25**
- Pesos por dólar ese día: **18.50**
- Pesos: **462.50**
Más la comisión de su banco por compra en otra moneda y el envío.


#### Comprar en línea seguro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sitio seguro | Candado y dirección correcta. | Revisa. |
| Opiniones y devoluciones | Lee antes de pagar. | Política clara. |
| Paga con tarjeta o método protegido | Puedes reclamar. | No depósitos a personas. |
| Precios «demasiado buenos» | Muchas veces es fraude. | Desconfía. |

#### Un caso en un minuto

Naomi ahora revisa el total en pesos con envío antes de pagar y compara con tiendas en México. Cuando sus papás le mandan dinero, revisa el tipo de cambio y cuánto le cobran por el envío.

> **Idea clave:** en compras en otra moneda, calcula el total en pesos con comisiones y envío. Compra en sitios seguros y nunca pagues con depósitos a personas.



#### Comprueba lo que entendiste

1. ¿Qué es el tipo de cambio?
*Respuesta:* Cuántos pesos cuesta un dólar u otra moneda en un día.

2. ¿Cómo pagas más seguro en línea?
*Respuesta:* Con tarjeta o un método que te permita reclamar.


#### Para recordar

- El tipo de cambio cambia diario.
- Calcula el total en pesos.
- Sitios seguros, nunca depósitos a personas.



### Profundiza (5 minutos más)

#### Tus derechos al comprar

| Derecho | Qué significa |
|---|---|
| Información clara | Precio total y condiciones antes de pagar |
| Devolución | Según la política y la ley en compras a distancia |
| Garantía | En productos que la tienen |
| Queja | En la PROFECO si una tienda en México no cumple |



#### Dinero que te mandan de otro país

Si te mandan dinero, compara cuánto cobra cada servicio y qué tipo de cambio usa: la diferencia puede ser grande. El costo total es la comisión más lo que se pierde en el tipo de cambio.



#### Casos


**Caso 1. La sudadera de Naomi**

Naomi ve una sudadera de 25 dólares en una tienda extranjera.
- *¿Qué hace?* Calcula el total en pesos con envío y comisión antes de pagar.


**Caso 2. Los tenis baratísimos de Emilio**

Emilio ve unos tenis de marca a 300 pesos en una página que no conoce.
- *¿Qué hace?* Desconfía, revisa opiniones y no paga con depósito a una persona.


**Caso 3. El envío de los papás de Naomi**

A Naomi le llegan distintos pesos cada mes aunque le mandan los mismos dólares.
- *¿Qué hace?* Entiende el tipo de cambio y compara servicios de envío.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el precio en dólares | Pagas más | Total en pesos |
| Pagar con depósito a personas | Sin reclamo | Tarjeta o pago protegido |
| Creer precios «demasiado buenos» | Fraude | Desconfía |
| No comparar envíos de dinero | Pierdes | Compara |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Algo cuesta 40 dólares y el dólar está a 18. ¿Cuánto es en pesos? a) 720 · b) 58 · c) 400
2. ¿Qué forma de pago es más riesgosa en línea? a) Tarjeta de débito o crédito · b) Depósito a la cuenta de una persona · c) Pago en una plataforma con protección
3. ¿Dónde te quejas si una tienda en México no cumple? a) En tu escuela · b) En el banco · c) En la PROFECO
**Respuestas:** 1-a: 40 por 18. 2-b: no puedes reclamar. 3-c: protege al consumidor.



#### Ponlo en práctica

Te mandan 100 dólares. Un servicio usa un tipo de cambio de 18.20 y cobra 0; otro usa 17.60 y cobra 0. ¿Cuánto más recibes con el primero?
**Respuesta:** 1,820 contra 1,760: 60 pesos más.



#### A tu plan

En tu próxima compra en línea, calcula el total en pesos con envío antes de pagar.



### Para saber más

- **Tipo de cambio** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «tipo de cambio».
- **Compras en línea** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «compras en línea» y «Concilianet».

### Palabras clave

- *Tipo de cambio:* cuántos pesos cuesta un dólar u otra moneda en un día.
- *Comisión por conversión:* cargo que cobra tu banco por pagar en otra moneda.

### Fuentes

Banco de México · PROFECO, consultados el 30 de septiembre de 2026.

---

## M2 U04. Las letras chiquitas: términos, suscripciones y contratos

**Lo que lograrás:** Leer lo importante de los términos y condiciones, controlar suscripciones y pruebas sin costo, y saber qué contratos puedes firmar siendo menor.

**Para empezar:** Emilio aceptó una «prueba sin costo» de una app de música. A los 7 días empezó a cobrarle 139 al mes. Lleva cuatro meses pagando algo que no usa. En esta lección verás las letras chiquitas.

### Lo esencial (5 minutos)

#### Aceptar es firmar

Cuando das clic en «Acepto» estás aceptando un contrato. No tienes que leerlo todo, pero sí buscar **cuánto cuesta, cada cuándo cobra, cómo cancelas y qué hacen con tus datos**.



#### Qué buscar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Costo y cuándo cobra | Después de la prueba, ¿cuánto? | Anótalo. |
| Cómo cancelar | ¿Es fácil? | Hazlo antes del cobro. |
| Tus datos | ¿Qué hacen con ellos? | ¿Los venden? |
| Renovación automática oculta | Te cobran sin avisar. | Desconfía. |

#### La suscripción olvidada de Emilio

- Al mes: **139**
- Meses sin usarla: **4**
- Perdidos: **556**
Si no la cancela, en un año serían 1,668.


#### Un caso en un minuto

Emilio canceló la suscripción y puso un recordatorio en su calendario para cada prueba sin costo: un día antes del cobro decide si la quiere.

> **Idea clave:** aceptar es firmar. Antes de dar clic, revisa el costo, cuándo cobra y cómo cancelas. Pon un recordatorio antes de que termine una prueba sin costo.



#### Comprueba lo que entendiste

1. ¿Qué buscas en los términos?
*Respuesta:* Costo, cuándo cobra, cómo cancelas y qué hacen con tus datos.

2. ¿Qué haces con una prueba sin costo?
*Respuesta:* Pones un recordatorio un día antes del cobro.


#### Para recordar

- Aceptar es firmar.
- Costo, cobro y cancelación.
- Recordatorio antes del cobro.



### Profundiza (5 minutos más)

#### Contratos y edad

| Siendo menor de 18 | Necesitas |
|---|---|
| Abrir una cuenta de banco | Un adulto como cotitular o que autorice |
| Firmar un préstamo o una tarjeta de crédito | Ser mayor de edad |
| Contrato de trabajo | Autorización y límites de la ley |
| Registrarte en apps | Muchas piden 18 o permiso |



#### Revisa tus cobros cada mes

Abre tu app del banco y busca cobros que se repiten. Cancela los que no usas desde la misma app o tienda donde te suscribiste.



#### Casos


**Caso 1. La prueba de Emilio**

Emilio aceptó una prueba sin costo y le cobran cada mes.
- *¿Qué hace?* La cancela y pone recordatorios antes de cada cobro.


**Caso 2. El préstamo para Valeria**

Una app le ofrece a Valeria, de 16, un préstamo para su negocio con solo aceptar términos.
- *¿Qué hace?* No acepta: siendo menor no debería firmar un préstamo y es señal de riesgo.


**Caso 3. Los datos de Naomi**

Una app de juegos pide acceso a los contactos y fotos de Naomi.
- *¿Qué hace?* Lee qué hace con sus datos y niega los permisos que no necesita.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar sin leer nada | Cobros sorpresa | Lo importante |
| Olvidar la prueba sin costo | Te cobran | Recordatorio |
| Dar todos los permisos | Tus datos expuestos | Solo lo necesario |
| No revisar cobros | Pagas lo que no usas | Cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué significa dar clic en «Acepto»? a) Nada importante, es solo un trámite · b) Aceptas un contrato · c) Que ya pagaste
2. Pagas 99 al mes por una app que no usas. ¿Cuánto al año? a) 99 · b) 990 · c) 1,188
3. ¿Qué haces antes de que termine una prueba sin costo? a) Decides si la quieres y cancelas si no · b) Esperas a que te cobren · c) Das la tarjeta de otra persona para que le cobren a ella
**Respuestas:** 1-b: es un contrato. 2-c: 99 por 12. 3-a: evitas cobros.



#### Ponlo en práctica

Tienes tres suscripciones: 139, 99 y 69 al mes. Usas solo una de 99. ¿Cuánto ahorras al año si cancelas las otras?
**Respuesta:** 139 más 69: 208 al mes; por 12: 2,496.



#### A tu plan

Revisa tus cobros del último mes y cancela una suscripción que no uses.



### Para saber más

- **Tus derechos como consumidor** (PROFECO · español): https://www.gob.mx/profeco — **Qué buscar:** «suscripciones» y «cargos no reconocidos».

### Palabras clave

- *Términos y condiciones:* reglas de un servicio que aceptas al usarlo.
- *Suscripción:* servicio que se cobra cada mes o cada año hasta que lo cancelas.

### Fuentes

PROFECO · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 3. Módulo 3. Crea: de la idea a tu primera venta

## M3 U01. Encuentra un problema que valga la pena resolver

**Lo que lograrás:** Encontrar ideas de negocio a partir de problemas reales de las personas a tu alrededor y de lo que sabes hacer.

**Para empezar:** Santi quería «poner un negocio», pero no sabía de qué. Un día notó algo en su salón: a tres compañeros se les rompió la pantalla del celular en una semana. Nadie sabía dónde repararla barato. En esta lección buscarás tu idea.

### Lo esencial (5 minutos)

#### Los negocios resuelven problemas

Un negocio funciona cuando resuelve un problema o cumple un deseo por el que alguien está dispuesto a pagar. Empieza por mirar: ¿qué les molesta, les falta o les cuesta trabajo a las personas a tu alrededor?



#### Donde nace una idea

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo que te gusta y sabes hacer | Dibujar, cocinar, reparar, explicar. | Tu ventaja. |
| Lo que otras personas necesitan | En tu escuela, tu calle, tu familia. | El problema. |
| Lo que pagarían | ¿Pagarían por eso? | La prueba. |
| «Lo que está de moda» sin más | Mucha competencia. | Busca tu diferencia. |

#### Tu lista de 10

Durante una semana anota 10 problemas que escuches o veas. Al final, marca los que puedes resolver con lo que sabes o puedes aprender.



#### Un caso en un minuto

Santi anotó problemas toda una semana. Tres tenían que ver con celulares. Aprendió con videos a cambiar pantallas y micas, y ofreció el servicio en su escuela.

> **Idea clave:** una buena idea une lo que sabes hacer con un problema real por el que alguien pagaría.



#### Comprueba lo que entendiste

1. ¿Qué hace un negocio que funciona?
*Respuesta:* Resuelve un problema o cumple un deseo por el que alguien paga.

2. ¿Cómo empiezas a buscar ideas?
*Respuesta:* Anotando problemas que ves a tu alrededor.


#### Para recordar

- Busca problemas reales.
- Une lo que sabes con lo que se necesita.
- Pregunta si pagarían.



### Profundiza (5 minutos más)

#### Ideas que empiezan con poco

| Idea | Qué necesitas | Problema que resuelve |
|---|---|---|
| Postres o botanas | Cocina y empaques | Antojo a buen precio en la escuela |
| Reparación de celulares | Herramientas y práctica | Pantallas rotas |
| Clases o tareas guiadas | Saber una materia | Materias difíciles |
| Diseño o edición | Una app y práctica | Negocios sin redes |
| Pulseras o accesorios | Material | Regalos y estilo |



#### Tu diferencia

Si ya hay alguien que vende lo mismo, pregúntate qué harías distinto: más rápido, más barato, más personalizado o más cerca.



#### Casos


**Caso 1. El negocio de Santi**

Santi quiere poner un negocio pero no sabe de qué.
- *¿Qué hace?* Anota durante una semana problemas reales a su alrededor.


**Caso 2. La moda de Emilio**

Emilio quiere vender lo que está de moda porque «todos lo venden».
- *¿Qué hace?* Busca qué haría distinto o un problema que nadie resuelva.


**Caso 3. Los dibujos de Naomi**

Naomi dibuja muy bien pero cree que eso no es negocio.
- *¿Qué hace?* Busca quién necesita dibujos: invitaciones, logos o regalos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Empezar por el producto | Nadie lo quiere | Empieza por el problema |
| Copiar sin diferencia | Mucha competencia | Tu diferencia |
| Creer que tu talento no vale | No empiezas | Busca quién lo necesita |
| No preguntar | Adivinas | Pregunta si pagarían |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Emilio y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Por dónde empieza una buena idea de negocio? a) Por lo que está de moda en redes · b) Por un problema real · c) Por un préstamo grande
2. ¿Qué une una buena idea? a) Lo que sabes y lo que alguien pagaría · b) Lo que venden tus amigos del salón en el recreo · c) Lo más caro que puedas vender
3. Hay otra persona vendiendo lo mismo en tu escuela. ¿Qué haces? a) Te rindes y mejor no vendes nada · b) Copias igual · c) Buscas tu diferencia
**Respuestas:** 1-b: los negocios resuelven problemas. 2-a: tu ventaja y la necesidad. 3-c: más rápido, cerca o personalizado.



#### Ponlo en práctica

Anotaste 10 problemas y puedes resolver 3. Si 1 de cada 3 ideas funciona, ¿cuántas ideas tendrías que probar para que funcionen 2?
**Respuesta:** 6 ideas.



#### A tu plan

Empieza tu lista de 10 problemas esta semana.



### Para saber más

- **Emprendimiento juvenil** (Instituto Mexicano de la Juventud · español): https://www.gob.mx/imjuve — **Qué buscar:** «emprendimiento» y convocatorias.

### Palabras clave

- *Idea de negocio:* forma de ganar dinero resolviendo un problema o un deseo.
- *Diferencia:* lo que hace que te elijan a ti y no a otra persona.

### Fuentes

Instituto Mexicano de la Juventud, consultado el 30 de septiembre de 2026.

---

## M3 U02. Prueba tu idea con poco dinero

**Lo que lograrás:** Probar una idea antes de gastar mucho: preguntar, hacer pocas piezas, vender por pedido y aprender de los resultados.

**Para empezar:** Emilio quería vender termos personalizados. Su plan: comprar 50 termos y una máquina de 6,000 pesos. Su tía le dijo: «¿Y si primero vendes 10?». En esta lección verás cómo probar sin arriesgar todo.

### Lo esencial (5 minutos)

#### Probar antes de invertir

Antes de gastar mucho, prueba si la gente de verdad compra. Una prueba barata te dice más que cualquier plan en papel. Si no funciona, perdiste poco y aprendiste mucho.



#### Formas de probar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Pregunta a 10 personas | ¿Lo comprarías? ¿A cuánto? | Sin costo. |
| Haz pocas piezas | 5 o 10 para vender. | Poco riesgo. |
| Vende por pedido | Primero el pedido, luego lo haces. | Sin inventario. |
| Comprar todo al inicio | Si no se vende, pierdes. | Evítalo. |

#### La prueba de Emilio

- Termos: **10**
- Costo de cada uno con el diseño en una papelería: **90**
- Inversión de prueba: **900**
En lugar de 6,000 de máquina y 50 termos.


#### Un caso en un minuto

Emilio tomó pedidos de 10 termos con anticipo, los mandó personalizar en una papelería y los vendió en una semana. Supo que sí hay clientes y qué diseños gustan más. Hasta entonces pensará en la máquina.

> **Idea clave:** prueba tu idea con poco dinero (preguntar, pocas piezas o por pedido) antes de invertir en grande.



#### Comprueba lo que entendiste

1. ¿Por qué probar antes de invertir?
*Respuesta:* Para saber si la gente compra sin arriesgar mucho.

2. ¿Qué es vender por pedido?
*Respuesta:* Primero te piden y pagan un anticipo, luego lo haces.


#### Para recordar

- Prueba barato.
- Por pedido, sin inventario.
- Aprende del resultado.



### Profundiza (5 minutos más)

#### Qué aprender de tu prueba

| Pregunta | Qué te dice |
|---|---|
| ¿Cuántas personas compraron? | Si hay demanda |
| ¿Qué eligieron más? | Qué producir |
| ¿Qué te dijeron? | Qué mejorar |
| ¿Cuánto te quedó? | Si vale la pena |



#### Si la prueba no funciona

No fallaste: aprendiste. Cambia algo (precio, producto, a quién le vendes) y prueba otra vez, con poco.



#### Casos


**Caso 1. La máquina de Emilio**

Emilio quiere comprar una máquina de 6,000 para empezar.
- *¿Qué hace?* Prueba primero con 10 piezas por pedido.


**Caso 2. Los postres de Valeria**

Valeria no sabe si sus postres se venderían a 35.
- *¿Qué hace?* Pregunta a 10 compañeros y prueba vender 20.


**Caso 3. La prueba que no salió**

Naomi vendió solo 2 de 10 separadores de libros.
- *¿Qué hace?* Pregunta qué mejorar y prueba otra vez con un cambio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Invertir en grande sin probar | Pierdes mucho | Prueba barato |
| Hacer inventario sin pedidos | Se queda sin vender | Por pedido |
| No preguntar | Adivinas | Pregunta a 10 |
| Rendirte a la primera | No aprendes | Cambia y prueba |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es la forma más barata de probar una idea? a) Comprar mucho inventario · b) Rentar un local · c) Preguntar a 10 personas
2. Tu prueba vendió 2 de 10. ¿Qué haces? a) Cambias algo y pruebas otra vez · b) Pides un préstamo para anunciarte · c) Te rindes para siempre
3. ¿Qué es un anticipo? a) Un regalo del cliente · b) Una parte del pago antes de hacer el producto · c) Una deuda con el banco que pagas cada mes con intereses
**Respuestas:** 1-c: cuesta cero. 2-a: el error enseña. 3-b: te asegura el pedido.



#### Ponlo en práctica

Haces 20 postres con 280 de ingredientes y los vendes a 30. ¿Cuánto ganas si vendes todos?
**Respuesta:** 20 por 30: 600. Menos 280: 320.



#### A tu plan

Diseña tu prueba: qué vas a probar, con cuánto dinero y cómo sabrás si funcionó.



### Para saber más

- **Emprendimiento** (Instituto Mexicano de la Juventud · español): https://www.gob.mx/imjuve — **Qué buscar:** «emprendimiento juvenil».

### Palabras clave

- *Prueba:* forma barata de saber si una idea funciona antes de invertir mucho.
- *Anticipo:* parte del pago que da el cliente antes de que hagas el producto.
- *Inventario:* productos que tienes guardados para vender.

### Fuentes

Instituto Mexicano de la Juventud, consultado el 30 de septiembre de 2026.

---

## M3 U03. Costo, precio y ganancia

**Lo que lograrás:** Calcular el costo de cada producto o servicio, ponerle un precio que deje ganancia y entender la diferencia entre vender y ganar.

**Para empezar:** Valeria vendió 60 postres a 30 en un mes: 1,800. Se sintió rica. Cuando sumó ingredientes, empaques y el gas de su mamá, solo le quedaron 660. En esta lección aprenderás a calcular tu precio.

### Lo esencial (5 minutos)

#### Vender no es ganar

Lo que cobras es tu **venta**. Lo que te queda después de pagar todo lo que usaste es tu ganancia. Para saber si ganas, cuenta todos los costos, incluso los pequeños.



#### El costo de un postre de Valeria

- Ingredientes: **14**
- Empaque: **3**
- Gas y luz: **2**
- Costo de cada postre: **19**
Si lo vende a 30, gana 11 por postre.


#### Cómo poner precio

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Costo más ganancia | Costo por pieza más lo que quieres ganar. | La base. |
| Mira a la competencia | ¿A cuánto se vende algo parecido? | Referencia. |
| Cuenta tu tiempo | Tu trabajo también vale. | No lo regales. |
| Precio por «adivinar» | Puedes perder dinero. | Calcula. |

#### Un caso en un minuto

Valeria calculó su costo de 19, vio que en la escuela venden postres parecidos a 35 y subió su precio a 33. Con las mismas ventas ahora gana 14 por postre.

> **Idea clave:** calcula el costo de cada pieza con todo lo que usas y pon un precio que deje ganancia. Vender mucho no sirve si no ganas.



#### Comprueba lo que entendiste

1. ¿Qué es la ganancia?
*Respuesta:* Lo que te queda después de restar todos los costos a lo que vendiste.

2. ¿Cómo sacas el costo de una pieza?
*Respuesta:* Sumas todo lo que usas para hacerla.


#### Para recordar

- Vender no es ganar.
- Cuenta todos los costos.
- Precio con ganancia.



### Profundiza (5 minutos más)

#### Tu costo por pieza

| Concepto | Costo |
|---|---|
| Material o ingredientes | |
| Empaque | |
| Transporte o envío | |
| Luz, gas, internet (una parte) | |
| Costo total por pieza | |



#### El margen

El margen te ayuda a comparar. Si vendes a 33 y te cuesta 19, tu margen es 14 entre 33: unos 42%.



#### Casos


**Caso 1. El mes de Valeria**

Valeria vendió 1,800 y creyó que ganó 1,800.
- *¿Qué hace?* Resta todos sus costos para saber su ganancia real.


**Caso 2. El precio de Santi**

Santi cobra 150 por cambiar una mica y no sabe si gana.
- *¿Qué hace?* Suma la mica, sus herramientas y su tiempo para calcular su costo.


**Caso 3. La competencia de Emilio**

Otro vendedor ofrece termos más baratos que Emilio.
- *¿Qué hace?* Revisa sus costos y destaca su diferencia antes de bajar precio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Confundir venta con ganancia | Crees que ganas | Resta costos |
| Olvidar los costos chicos | Ganas menos | Súmalos |
| Regalar tu tiempo | Trabajas sin ganar | Cuéntalo |
| Bajar precio sin calcular | Pierdes | Revisa costos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Santi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Vendes 40 pulseras a 50 y cada una te cuesta 22. ¿Cuánto ganas? a) 2,000 · b) 1,120 · c) 880
2. ¿Qué es la ganancia? a) Lo que te queda después de costos · b) Todo lo que cobraste en el mes por tus ventas · c) Lo que te prestan para empezar
3. Tu costo es 20 y vendes a 32. ¿Cuánto ganas por pieza? a) 52 · b) 12 · c) 20
**Respuestas:** 1-b: 40 por 28. 2-a: ventas menos costos. 3-b: 32 menos 20.



#### Ponlo en práctica

Cada termo te cuesta 90 y quieres ganar 60 por termo. ¿A cuánto lo vendes y cuánto ganas si vendes 15?
**Respuesta:** A 150. Ganancia: 15 por 60: 900.



#### A tu plan

Llena tu tabla de costo por pieza y revisa si tu precio te deja ganancia.



### Para saber más

- **Calcula tus costos** (Secretaría de Economía · español): https://www.gob.mx/se — **Qué buscar:** «costos» y «emprendedores».

### Palabras clave

- *Ganancia:* lo que te queda después de restar todos los costos a lo que vendiste.
- *Costo por pieza:* lo que te cuesta hacer cada producto.
- *Margen:* porcentaje de tu precio que es ganancia.

### Fuentes

Secretaría de Economía, consultado el 30 de septiembre de 2026.

---

## M3 U04. Tus primeras ventas: redes, cobro y clientes

**Lo que lograrás:** Presentar tu producto en redes, cobrar y entregar con seguridad, y cuidar a tus clientes para que vuelvan y te recomienden.

**Para empezar:** Naomi publicó sus dibujos en redes y le escribieron 12 personas. Una le pidió su dirección para «pasar por el pedido» y otra le pidió que le fiara. En esta lección verás cómo vender con seguridad.

### Lo esencial (5 minutos)

#### Tu publicación

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Buena foto | Luz natural, fondo limpio. | Muestra el producto. |
| Precio claro | Y qué incluye. | Evita dudas. |
| Cómo pedir y cuándo entregas | Tiempos reales. | Cumple. |
| Tus datos personales | Dirección, escuela, horarios. | Nunca públicos. |

#### Vende seguro

Siendo menor de edad, entrega en lugares públicos y con un adulto, o por envío. Nunca des tu dirección a desconocidos. Cobra por transferencia antes o al entregar y revisa en tu app que llegó.



#### Clientes que vuelven

Un cliente contento vuelve y te recomienda. Cumple lo que prometes, responde rápido y agradece. Pide que compartan tu publicación.



#### Un caso en un minuto

Naomi puso en su perfil: «Pedidos por mensaje, pago por transferencia, entregas en la plaza con mi mamá». No fió a nadie. Tres clientes volvieron el mes siguiente.

> **Idea clave:** vende con buena foto y precio claro, y cobra antes o al entregar. Entrega en lugares públicos con un adulto y cuida a tus clientes para que vuelvan.



#### Comprueba lo que entendiste

1. ¿Dónde entregas siendo menor?
*Respuesta:* En lugares públicos y con un adulto, o por envío.

2. ¿Qué hace que un cliente vuelva?
*Respuesta:* Que cumplas lo que prometes, respondas rápido y agradezcas.


#### Para recordar

- Foto y precio claros.
- Cobra antes o al entregar.
- Entrega segura con un adulto.



### Profundiza (5 minutos más)

#### Fiar o no fiar

| Si fías | Riesgo |
|---|---|
| A desconocidos | Alto: puede no pagar |
| Sin fecha | Se olvida |
| Mucho | Te quedas sin dinero para material |
| Mejor | Cobra antes, o anticipo de la mitad |



#### Respuestas listas

Ten mensajes listos: precio, tiempos, forma de pago y lugar de entrega. Te ahorran tiempo y evitan malentendidos.



#### Casos


**Caso 1. La dirección de Naomi**

Un cliente le pide a Naomi su dirección para pasar por el pedido.
- *¿Qué hace?* No la da; entrega en un lugar público con un adulto.


**Caso 2. El fiado de Valeria**

Un compañero le pide a Valeria que le fíe 5 postres hasta la próxima semana.
- *¿Qué hace?* Le pide pagar antes o al entregar.


**Caso 3. El cliente molesto de Santi**

Un cliente se queja porque la mica quedó con burbujas.
- *¿Qué hace?* Escucha, la cambia y agradece que se lo dijera.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Fotos malas | Nadie compra | Luz y fondo |
| Dar tu dirección | Riesgo | Lugar público |
| Fiar sin control | No te pagan | Cobra antes |
| Ignorar quejas | Pierdes clientes | Escucha y arregla |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Valeria y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Siendo menor, ¿dónde conviene entregar un pedido? a) En tu casa · b) Donde diga el cliente · c) En un lugar público con un adulto
2. ¿Qué pones en tu publicación? a) Foto, precio claro y cómo pedir · b) Tu dirección y tus horarios para que te encuentren · c) El nombre de tu escuela
3. Un cliente se queja con razón. ¿Qué haces? a) Lo bloqueas de todas tus redes · b) Escuchas y lo arreglas · c) Lo ignoras
**Respuestas:** 1-c: por tu seguridad. 2-a: sin datos personales. 3-b: así vuelve.



#### Ponlo en práctica

Fías 8 postres de 33 y solo te pagan 5. ¿Cuánto pierdes?
**Respuesta:** 3 por 33: 99.



#### A tu plan

Prepara tus mensajes listos: precio, tiempos, forma de pago y lugar de entrega.



### Para saber más

- **Seguridad en línea** (Policía Cibernética · español): https://www.gob.mx/sspc — **Qué buscar:** «seguridad en internet para adolescentes».

### Palabras clave

- *Fiar:* entregar ahora y cobrar después.
- *Cliente frecuente:* persona que te compra más de una vez.

### Fuentes

Secretaría de Seguridad y Protección Ciudadana · PROFECO, consultados el 30 de septiembre de 2026.

---

## M3 U05. Punto de equilibrio y el dinero del negocio aparte

**Lo que lograrás:** Calcular cuántas piezas necesitas vender para recuperar lo que invertiste y separar el dinero del negocio de tu dinero personal.

**Para empezar:** Santi compró herramientas por 1,800 para reparar celulares. Gana 60 por cada reparación. No sabe cuándo recuperará lo que invirtió, y usa el mismo dinero para sus salidas y para comprar piezas. En esta lección lo ordenarás.

### Lo esencial (5 minutos)

#### Tu punto de equilibrio

El punto de equilibrio te dice cuántas ventas necesitas para recuperar lo que invertiste. Antes de ese punto estás recuperando; después, ganando.



#### Las herramientas de Santi

- Lo que invirtió: **1,800**
- Ganancia por reparación: **60**
- Reparaciones para recuperar: **30**
Desde la reparación 31, gana.


#### El dinero del negocio aparte

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Una cuenta o sobre del negocio | Ahí entra lo que vendes. | No lo mezcles. |
| Tu sueldo | Te pagas una cantidad fija. | Lo demás se queda. |
| Material y reinversión | Sale del dinero del negocio. | Crece. |
| Usar todo para tus gastos | El negocio se queda sin nada. | Evítalo. |

#### Un caso en un minuto

Santi abrió un apartado en su app solo para el negocio. Cada viernes se paga 300 de sueldo y lo demás lo usa para piezas. En 5 semanas recuperó sus herramientas.

> **Idea clave:** calcula cuántas ventas necesitas para recuperar lo invertido. Separa el dinero del negocio: te pagas un sueldo fijo y lo demás hace crecer tu idea.



#### Comprueba lo que entendiste

1. ¿Qué es el punto de equilibrio?
*Respuesta:* Lo que necesitas vender para recuperar lo invertido.

2. ¿Por qué separar el dinero del negocio?
*Respuesta:* Para saber si ganas y no gastarte lo que necesitas para material.


#### Para recordar

- Inversión entre ganancia por pieza.
- Negocio aparte.
- Sueldo fijo para ti.



### Profundiza (5 minutos más)

#### Tu punto de equilibrio

| Concepto | Tu cifra |
|---|---|
| Lo que invertiste | |
| Ganancia por pieza | |
| Piezas para recuperar | |
| Piezas que vendes por semana | |
| Semanas para recuperar | |



#### La hoja de cálculo del curso

En los materiales de apoyo está el Excel del curso con hojas de costo y precio, punto de equilibrio y flujo de 8 semanas. Úsalo con tus números.



#### Casos


**Caso 1. Las herramientas de Santi**

Santi no sabe cuándo recuperará lo que invirtió.
- *¿Qué hace?* Divide la inversión entre la ganancia por reparación.


**Caso 2. El dinero revuelto de Valeria**

Valeria usa el dinero de los postres para sus salidas y luego no tiene para ingredientes.
- *¿Qué hace?* Separa el dinero del negocio y se paga un sueldo fijo.


**Caso 3. La primera ganancia de Emilio**

Emilio ya recuperó lo que invirtió y quiere gastarse todo lo que sigue.
- *¿Qué hace?* Se paga su sueldo y reinvierte una parte para crecer.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No saber cuándo recuperas | Te desesperas | Calcula |
| Mezclar dinero | No sabes si ganas | Aparte |
| Gastarte todo | El negocio no crece | Sueldo fijo |
| No reinvertir | Te quedas igual | Una parte al negocio |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Valeria y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Inviertes 1,200 y ganas 40 por pieza. ¿Cuántas piezas para recuperar? a) 40 · b) 30 · c) 1,200
2. ¿Qué haces con el dinero del negocio? a) Lo mezclas con el tuyo · b) Lo gastas cada fin de semana con tus amigos del salón · c) Lo separas y te pagas un sueldo fijo
3. Ya recuperaste tu inversión. ¿Qué haces con la ganancia? a) Te pagas tu sueldo y reinviertes una parte · b) Lo gastas todo · c) Cierras el negocio porque ya ganaste lo que querías
**Respuestas:** 1-b: 1,200 entre 40. 2-c: así sabes si ganas. 3-a: así crece.



#### Ponlo en práctica

Inviertes 2,400, ganas 80 por pieza y vendes 10 piezas por semana. ¿En cuántas semanas recuperas?
**Respuesta:** 2,400 entre 80: 30 piezas. Entre 10 por semana: 3 semanas.



#### A tu plan

Calcula tu punto de equilibrio y abre un sobre o apartado solo para tu negocio.



### Para saber más

- **Emprendedores** (Secretaría de Economía · español): https://www.gob.mx/se — **Qué buscar:** «punto de equilibrio».

### Palabras clave

- *Punto de equilibrio:* cantidad que necesitas vender para recuperar lo que invertiste; desde ahí empiezas a ganar.
- *Sueldo fijo:* cantidad que te pagas del negocio cada semana o mes.

### Fuentes

Secretaría de Economía, consultado el 30 de septiembre de 2026.

---


# Parte 4. Módulo 4. Haz crecer lo que empezaste

## M4 U01. Reinvertir: que tu ganancia trabaje

**Lo que lograrás:** Decidir qué parte de la ganancia reinviertes para crecer, qué parte es tu sueldo y qué parte guardas, y revisar tu flujo de dinero.

**Para empezar:** Valeria gana unos 800 al mes con sus postres. Su amiga le dice: «¡Cómprate unos tenis!». Pero con un horno más grande podría hacer el doble. En esta lección decidirás qué hacer con tu ganancia.

### Lo esencial (5 minutos)

#### La ganancia puede crecer

Reinvertir es usar una parte de lo que ganas para producir más, mejor o más rápido. Así tu idea crece sin pedir prestado.



#### Reparte tu ganancia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu sueldo | Una parte fija para ti. | Disfruta tu esfuerzo. |
| Reinversión | Material, herramientas, aprender. | Hace crecer. |
| Reserva | Para meses flojos. | Protege al negocio. |
| Gastarlo todo | El negocio no crece. | Evítalo. |

#### La ganancia de Valeria

- Ganancia del mes: **800**
- Su sueldo: **300**
- Reserva: **100**
- Para reinvertir: **400**
En dos meses junta el horno de 800 sin pedir prestado.


#### Un caso en un minuto

Valeria compró el horno con dos meses de reinversión. Ahora hace el doble de postres en el mismo tiempo y su ganancia subió a 1,500 al mes.

> **Idea clave:** reparte tu ganancia en sueldo, reinversión y reserva; reinvertir es lo que hace crecer tu idea sin deudas.



#### Comprueba lo que entendiste

1. ¿Qué es reinvertir?
*Respuesta:* Usar parte de la ganancia para que el negocio crezca.

2. ¿Para qué sirve la reserva?
*Respuesta:* Para los meses flojos.


#### Para recordar

- Sueldo, reinversión y reserva.
- Crece sin deudas.
- Revisa tu flujo.



### Profundiza (5 minutos más)

#### Flujo de 4 semanas

| Semana | Entra | Sale | Queda |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |



#### En qué reinvertir

Pregúntate: ¿qué me limita hoy? Si es tiempo, una herramienta. Si es calidad, aprender. Si son clientes, dar a conocer tu producto. Reinvierte donde más crece tu ganancia.



#### Casos


**Caso 1. Los tenis o el horno**

Valeria duda entre comprarse tenis o un horno más grande.
- *¿Qué hace?* Reparte su ganancia: su sueldo para ella y una parte para el horno.


**Caso 2. El préstamo de Emilio**

Emilio quiere pedir prestado para crecer rápido.
- *¿Qué hace?* Crece primero con reinversión de su propia ganancia.


**Caso 3. El mes flojo de Santi**

En vacaciones Santi casi no tiene reparaciones y no puede comprar piezas.
- *¿Qué hace?* Usa su reserva y la vuelve a llenar cuando mejora.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar toda la ganancia | No creces | Reinvierte una parte |
| Reinvertir todo | No te pagas | Sueldo fijo |
| Sin reserva | Meses flojos te hunden | Aparta |
| Pedir prestado primero | Deuda | Reinversión |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Ganas 1,000; te pagas 400 y guardas 150 de reserva. ¿Cuánto reinviertes? a) 450 · b) 1,000 · c) 550
2. ¿Qué hace crecer tu negocio sin deudas? a) Gastar la ganancia en ti · b) Reinvertir una parte · c) Pedir prestado
3. ¿Para qué es la reserva del negocio? a) Para meses flojos · b) Para salir con amigos · c) Para prestar a clientes
**Respuestas:** 1-a: 1,000 menos 550. 2-b: tu ganancia trabaja. 3-a: te protege.



#### Ponlo en práctica

Una herramienta de 1,200 te dejaría ganar 300 más al mes. Si reinviertes 400 al mes, ¿en cuántos meses la compras y en cuántos la recuperas?
**Respuesta:** La compras en 3 meses. La recuperas en 4 meses con la ganancia extra.



#### A tu plan

Decide qué porcentaje de tu ganancia será sueldo, reinversión y reserva.



### Para saber más

- **Emprendedores** (Secretaría de Economía · español): https://www.gob.mx/se — **Qué buscar:** «crecer tu negocio».

### Palabras clave

- *Reinvertir:* volver a usar parte de la ganancia en tu negocio para que crezca.
- *Reserva:* dinero del negocio guardado para meses flojos.
- *Flujo:* cuánto dinero entra y sale de tu negocio cada semana.

### Fuentes

Secretaría de Economía, consultado el 30 de septiembre de 2026.

---

## M4 U02. Socios y equipo: acuerdos claros entre amigos

**Lo que lograrás:** Hacer acuerdos por escrito cuando emprendes con amigos: quién pone qué, cómo se reparte la ganancia y qué pasa si alguien se sale.

**Para empezar:** Emilio y su amigo Toño empezaron a vender termos juntos. Toño puso el dinero y Emilio hace los diseños. Ahora discuten: Toño dice que le toca más porque puso el dinero; Emilio, porque trabaja más. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Acuerdos antes, no después

Emprender con amigos puede ser muy bueno: se reparten el trabajo y se animan. Pero sin acuerdos claros, el dinero rompe amistades. Escríbanlo **antes** de empezar.



#### Lo que deben acordar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Quién pone qué | Dinero, trabajo, herramientas. | Todo cuenta. |
| Cómo se reparte | Porcentajes claros. | Por escrito. |
| Quién hace qué | Tareas y tiempos. | Sin suposiciones. |
| Si alguien se sale | Qué se lleva. | Evita peleas. |

#### El reparto de Emilio y Toño

- Ganancia del mes: **1,200**
- Parte de cada uno (acordada): **50%**
- Para cada uno: **600**
Primero le regresan a Toño lo que puso, poco a poco.


#### Un caso en un minuto

Emilio y Toño escribieron su acuerdo en un documento compartido. Primero le regresan a Toño sus 1,500 con una parte de la ganancia. Luego reparten mitad y mitad. Si alguien se sale, se lleva su parte de lo que haya.

> **Idea clave:** si emprendes con amigos, escriban antes quién pone qué, cómo se reparte y qué pasa si alguien se sale.



#### Comprueba lo que entendiste

1. ¿Cuándo se hacen los acuerdos?
*Respuesta:* Antes de empezar.

2. ¿Qué cuenta como aportación?
*Respuesta:* Dinero, trabajo y herramientas.


#### Para recordar

- Por escrito y antes.
- Todo aporte cuenta.
- Qué pasa si alguien se sale.



### Profundiza (5 minutos más)

#### Tu acuerdo en una hoja

| Punto | Qué acordamos |
|---|---|
| Qué pone cada quien | |
| Reparto de ganancia | |
| Quién hace qué | |
| Cómo decidimos | |
| Si alguien se sale | |



#### Siendo menor de edad

Un acuerdo escrito entre amigos ayuda a que todo quede claro, aunque no sea un contrato formal. Para negocios más grandes, contratos o cuentas, se necesita a una persona mayor de edad que los acompañe.



#### Casos


**Caso 1. El pleito de Emilio y Toño**

Emilio y Toño discuten cómo repartir la ganancia.
- *¿Qué hacen?* Escriben un acuerdo con lo que puso cada uno y cómo se reparte.


**Caso 2. El nuevo socio de Valeria**

Una amiga quiere entrar al negocio de postres de Valeria.
- *¿Qué hace?* Acuerdan por escrito qué pone cada una y cómo se reparte.


**Caso 3. El que se sale**

Un amigo de Santi quiere salirse del negocio y llevarse las herramientas.
- *¿Qué hace?* Revisan su acuerdo: se lleva su parte según lo escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo de palabra | Pleitos | Por escrito |
| No contar el trabajo | Injusto | Todo aporte cuenta |
| No acordar salida | Peleas por las cosas | Acuérdenlo |
| Mezclar amistad y dinero sin reglas | Pierdes al amigo | Reglas claras |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuándo conviene escribir el acuerdo con tu socio? a) Cuando haya problemas · b) Antes de empezar · c) Nunca, son amigos
2. ¿Qué cuenta como aportación al negocio? a) Solo el dinero que cada quien puso al inicio · b) Solo las horas de trabajo · c) Dinero, trabajo y herramientas
3. Ganan 900 y acordaron 60% y 40%. ¿Cuánto le toca a cada uno? a) 540 y 360 · b) 450 y 450 · c) 600 y 300
**Respuestas:** 1-b: evita pleitos. 2-c: todo suma. 3-a: 60% de 900 y el resto.



#### Ponlo en práctica

Tu socia puso 1,000 de material y tú 20 horas de trabajo. Acuerdan regresarle primero su dinero con 50% de la ganancia mensual de 800. ¿En cuántos meses recupera?
**Respuesta:** 50% de 800: 400 al mes. 1,000 entre 400: en 3 meses (2.5).



#### A tu plan

Si emprendes con alguien, llenen juntos su acuerdo en una hoja.



### Para saber más

- **Emprender en equipo** (Instituto Mexicano de la Juventud · español): https://www.gob.mx/imjuve — **Qué buscar:** «emprendimiento».

### Palabras clave

- *Socio:* persona que comparte un negocio contigo.
- *Aportación:* lo que cada socio pone: dinero, trabajo o herramientas.

### Fuentes

Instituto Mexicano de la Juventud, consultado el 30 de septiembre de 2026.

---

## M4 U03. Tu marca, tu reputación y tus datos en línea

**Lo que lograrás:** Construir una marca sencilla, cuidar tu reputación digital y proteger tus datos y los de tus clientes.

**Para empezar:** Naomi usa su cuenta personal para vender dibujos: ahí también hay fotos de su escuela y de su casa. Un cliente dejó un comentario grosero y ella contestó enojada. En esta lección cuidarás tu marca.

### Lo esencial (5 minutos)

#### Tu marca

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Nombre y logo sencillos | Fáciles de recordar. | Que digan qué haces. |
| Cuenta aparte del negocio | Sin datos personales. | Protege tu privacidad. |
| Reseñas y respuestas | Con respeto, siempre. | Todos lo ven. |
| Publicar datos de clientes | Nombres, direcciones, pedidos. | Nunca. |

#### Tu huella digital

Lo que publicas se queda. Tus publicaciones, comentarios y fotos forman tu huella digital: clientes, escuelas y trabajos pueden verla después.



#### Responder a una crítica

Respira, agradece, ofrece una solución y, si hace falta, sigue la plática en privado. Una buena respuesta a una queja da más confianza que cero quejas.



#### Un caso en un minuto

Naomi abrió una cuenta solo para su negocio, sin fotos de su casa ni de su escuela. Borró su respuesta enojada y escribió: «Gracias por decirme, ¿qué te gustaría cambiar?». El cliente volvió a comprar.

> **Idea clave:** separa tu cuenta personal de la del negocio, responde con respeto y nunca publiques datos tuyos ni de tus clientes.



#### Comprueba lo que entendiste

1. ¿Qué es la huella digital?
*Respuesta:* Todo lo que queda de ti en internet.

2. ¿Cómo respondes una crítica?
*Respuesta:* Con respeto, agradeciendo y ofreciendo una solución.


#### Para recordar

- Cuenta del negocio aparte.
- Responde con respeto.
- Cuida los datos.



### Profundiza (5 minutos más)

#### Tu cuenta del negocio

| Sí | No |
|---|---|
| Fotos de tus productos | Fotos de tu casa o escuela |
| Precios y cómo pedir | Tu dirección o horarios |
| Opiniones de clientes con permiso | Nombres o datos de clientes |
| Respuestas amables | Peleas públicas |



#### Lo que no es tuyo

No uses logos, personajes ni imágenes de marcas sin permiso: pueden bajarte la cuenta o reclamarte. Crea tus propios diseños.



#### Casos


**Caso 1. La cuenta de Naomi**

Naomi vende desde su cuenta personal con fotos de su casa.
- *¿Qué hace?* Abre una cuenta solo para el negocio, sin datos personales.


**Caso 2. El comentario grosero**

Un cliente deja un comentario grosero en la publicación de Valeria.
- *¿Qué hace?* Responde con respeto y ofrece una solución.


**Caso 3. Los personajes de Emilio**

Emilio quiere vender termos con personajes de una caricatura famosa.
- *¿Qué hace?* Crea sus propios diseños para no usar marcas sin permiso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Vender desde tu cuenta personal | Expones tus datos | Cuenta aparte |
| Pelear en público | Pierdes clientes | Respeto |
| Publicar datos de clientes | Pierdes su confianza | Nunca |
| Usar marcas ajenas | Te bajan la cuenta | Diseños propios |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Valeria y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué publicas en la cuenta de tu negocio? a) Fotos de tus productos · b) Tu dirección para que te encuentren fácil · c) Fotos de tu escuela
2. Te dejan una crítica. ¿Qué haces? a) Respondes enojado · b) Bloqueas a todos los que opinen algo negativo · c) Respondes con respeto y una solución
3. ¿Puedes usar personajes de caricaturas famosas sin permiso? a) Sí, si los dibujas tú · b) No, son de otra persona · c) Sí, siempre que vendas poquito y no te vean
**Respuestas:** 1-a: sin datos personales. 2-c: da confianza. 3-b: tienen dueño.



#### Ponlo en práctica

Tienes 40 clientes y cada uno te recomienda con 2 personas; 1 de cada 4 compra. ¿Cuántos clientes nuevos consigues?
**Respuesta:** 40 por 2: 80 personas; 1 de cada 4: 20 clientes nuevos.



#### A tu plan

Revisa tu cuenta de ventas y quita cualquier dato personal tuyo o de tus clientes.



### Para saber más

- **Seguridad en internet** (Secretaría de Seguridad y Protección Ciudadana · español): https://www.gob.mx/sspc — **Qué buscar:** «seguridad digital para adolescentes».
- **Derechos de autor** (INDAUTOR · español): https://www.gob.mx/indautor — **Qué buscar:** «registro de obra».

### Palabras clave

- *Marca:* nombre, logo y estilo que identifican tu negocio.
- *Huella digital:* todo lo que queda de ti en internet: publicaciones, comentarios y fotos.
- *Derechos de autor:* derechos de quien crea una obra sobre su uso.

### Fuentes

SSPC · INDAUTOR, consultados el 30 de septiembre de 2026.

---

## M4 U04. Crecer en serio: RFC, permisos e impuestos cuando toque

**Lo que lograrás:** Decidir cuándo y cómo formalizar un negocio en México (RFC, régimen de impuestos, permisos) y qué hacer mientras eres menor de edad.

**Para empezar:** A Santi, ya de 18, una tienda le pide factura para contratarlo a reparar los celulares de sus empleados. Nunca ha tramitado su RFC y cree que «le van a quitar todo en impuestos». En esta lección verás qué implica formalizarse.

### Lo esencial (5 minutos)

#### Qué es formalizarte

Formalizarte es registrarte en el SAT con tu RFC, elegir un régimen de impuestos y cumplir los permisos de tu actividad. Te permite dar facturas y vender a empresas.



#### Cuando cumples 18

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| RFC | Con tu CURP en el SAT. | Sin costo. |
| RESICO | Régimen con ISR bajo para personas físicas. | Hasta 3.5 millones al año. |
| Facturas | Te abren clientes que las piden. | Empresas. |
| Gestores que cobran por el RFC | El trámite no tiene costo. | Hazlo tú. |

#### Siendo menor de edad

Mientras seas menor, un negocio pequeño con tus compañeros o vecinos no necesita trámites complicados. Pero sí reglas básicas: higiene si vendes comida y no vender productos prohibidos para menores. Si vendes en tu escuela, pide permiso. Para trámites, un adulto te acompaña.



#### Un caso en un minuto

Santi tramitó su RFC con su CURP en el sitio del SAT, eligió el RESICO y aprendió a emitir su factura desde la app. Firmó con la tienda y ahora tiene un cliente fijo.

> **Idea clave:** a los 18 puedes tramitar tu RFC sin costo, elegir un régimen como el RESICO y facturar. Mientras eres menor, cuida la higiene y las reglas de tu escuela, y pide acompañamiento.



#### Comprueba lo que entendiste

1. ¿Qué te permite formalizarte?
*Respuesta:* Dar facturas y vender a empresas.

2. ¿Cuánto cuesta tramitar tu RFC?
*Respuesta:* No tiene costo.


#### Para recordar

- RFC a los 18, sin costo.
- RESICO para empezar.
- Menor: reglas básicas y un adulto.



### Profundiza (5 minutos más)

#### Impuestos en palabras sencillas

| Impuesto | Qué es |
|---|---|
| ISR | Impuesto sobre lo que ganas |
| IVA | Impuesto que va en el precio de muchas cosas |
| RESICO | Régimen con un ISR bajo sobre lo que cobras |



#### Si vendes comida

Lávate las manos, usa cofia y guantes, cuida la temperatura y etiqueta con ingredientes si alguien tiene alergias. Pregunta en tu escuela qué pueden vender los alumnos.



#### Casos


**Caso 1. La factura de Santi**

Una tienda le pide factura a Santi, que ya tiene 18.
- *¿Qué hace?* Tramita su RFC sin costo y elige el RESICO.


**Caso 2. El gestor de Emilio**

Un gestor le ofrece a Emilio sacarle el RFC por 800.
- *¿Qué hace?* No paga: el trámite en el SAT no tiene costo.


**Caso 3. Los postres en la escuela**

Valeria, de 16, quiere vender postres en su escuela.
- *¿Qué hace?* Pide permiso en la escuela y cuida la higiene.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que te quitan todo | No te formalizas | Conoce el RESICO |
| Pagar gestores | Pierdes dinero | Trámite sin costo |
| Vender comida sin higiene | Enfermas a alguien | Cuida las reglas |
| Hacer trámites sola siendo menor | No te dejan | Con un adulto |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Emilio y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es el RFC? a) Tu clave para pagar impuestos y facturar · b) Una tarjeta del banco · c) Un permiso de la escuela para vender en el recreo y en los eventos
2. ¿Cuánto cuesta tramitar el RFC en el SAT? a) 800 con gestor · b) Depende del estado · c) No tiene costo
3. ¿Qué impuesto va dentro del precio de muchas cosas que compras? a) El RESICO · b) El IVA · c) El RFC
**Respuestas:** 1-a: te identifica ante el SAT. 2-c: lo haces tú. 3-b: está en el precio.



#### Ponlo en práctica

Un producto cuesta 100 antes de IVA. Con IVA de 16%, ¿cuánto pagas?
**Respuesta:** 100 más 16: 116.



#### A tu plan

Si ya tienes 18 y vendes a empresas, revisa en el SAT cómo tramitar tu RFC con tu CURP.



### Para saber más

- **RFC con CURP** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «inscripción al RFC con CURP» y «RESICO».

### Palabras clave

- *RFC:* Registro Federal de Contribuyentes: tu clave para pagar impuestos y facturar.
- *RESICO:* régimen de impuestos con ISR bajo para personas con ingresos de hasta 3.5 millones al año.
- *IVA:* impuesto que va incluido en el precio de muchas cosas.

### Fuentes

SAT, consultado el 30 de septiembre de 2026.

---


# Parte 5. Módulo 5. Pon tu dinero a trabajar

## M5 U01. Ahorra con propósito

**Lo que lograrás:** Ponerle nombre, monto y fecha a tus metas de ahorro, juntar un pequeño fondo para imprevistos y apartar el mismo día que recibes dinero.

**Para empezar:** Naomi «ahorra», pero cada vez que junta algo se lo gasta en lo primero que ve. Emilio quiere una moto de 28,000 y no sabe cuánto tiempo le tomaría. En esta lección le pondrás propósito a tu ahorro.

### Lo esencial (5 minutos)

#### Una meta con nombre

«Ahorrar» a secas no motiva. «Juntar 6,000 para una laptop en 10 meses» sí. Una meta clara tiene **qué**, **cuánto** y **cuándo**.



#### Tus tres ahorros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fondo para imprevistos | Un celular roto, un pasaje urgente. | Primero. |
| Metas | Laptop, curso, viaje, moto. | Con fecha. |
| Para crear o invertir | Tu idea o tu inversión. | Largo plazo. |

#### La moto de Emilio

- Precio de la moto: **28,000**
- Meses: **20**
- Al mes: **1,400**
Con 700 a la semana que gana, aparta 350 cada semana.


#### Un caso en un minuto

Naomi puso un apartado en su app llamado «Tableta para dibujar: 5,000 en 8 meses». Cada vez que le llega dinero, aparta primero 625. Ya lleva la mitad.

> **Idea clave:** ponle nombre, monto y fecha a tu meta. Divide entre el tiempo y aparta el mismo día que recibes dinero. Empieza por un pequeño fondo para imprevistos.



#### Comprueba lo que entendiste

1. ¿Qué tiene una meta clara?
*Respuesta:* Qué, cuánto y cuándo.

2. ¿Cuál ahorro va primero?
*Respuesta:* El fondo para imprevistos.


#### Para recordar

- Qué, cuánto y cuándo.
- Fondo primero.
- Aparta el día que recibes.



### Profundiza (5 minutos más)

#### Tu meta

| Meta | Cuánto | Cuándo | Por semana |
|---|---|---|---|
| | | | |
| | | | |



#### Apartados en tu app

Muchas apps de banco dejan separar tu ahorro en «apartados» o «cajitas» con nombre. Ver el nombre de tu meta te ayuda a no tocarlo.



#### Casos


**Caso 1. El ahorro de Naomi**

Naomi se gasta su ahorro en lo primero que ve.
- *¿Qué hace?* Le pone nombre, monto y fecha a su meta y aparta primero.


**Caso 2. La moto de Emilio**

Emilio no sabe cuánto tardaría en juntar para la moto.
- *¿Qué hace?* Divide el precio entre los meses y aparta cada semana.


**Caso 3. El celular roto de Santi**

A Santi se le rompió el celular y no tenía nada guardado.
- *¿Qué hace?* Junta primero un pequeño fondo para imprevistos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Meta sin fecha | Nunca llega | Ponle fecha |
| Ahorrar lo que sobra | No sobra | Aparta primero |
| Sin fondo para imprevistos | Tocas tu meta | Fondo primero |
| Todo en el mismo lugar | Se revuelve | Apartados con nombre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Emilio y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Quieres 4,800 en 12 meses. ¿Cuánto apartas al mes? a) 480 · b) 400 · c) 1,200
2. ¿Qué tiene una meta clara? a) Solo las ganas de lograrla · b) Un número que suene bonito · c) Qué, cuánto y cuándo
3. ¿Cuál ahorro conviene tener primero? a) Un fondo para imprevistos · b) Para la fiesta de fin de año · c) Ninguno
**Respuestas:** 1-b: 4,800 entre 12. 2-c: así sabes qué hacer. 3-a: te protege.



#### Ponlo en práctica

Quieres un curso de 3,600 y ganas 1,200 al mes. Si apartas 25%, ¿en cuántos meses lo juntas?
**Respuesta:** 25% de 1,200: 300 al mes. 3,600 entre 300: 12 meses.



#### A tu plan

Escribe tu meta con nombre, monto y fecha, y crea su apartado.



### Para saber más

- **Ahorro para jóvenes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «jóvenes» y «ahorro».

### Palabras clave

- *Meta de ahorro:* lo que quieres juntar, cuánto y para cuándo.
- *Fondo para imprevistos:* dinero guardado para gastos que no esperabas.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M5 U02. El interés compuesto y tu mejor aliado: el tiempo

**Lo que lograrás:** Explicar cómo el interés compuesto hace crecer el dinero con el tiempo, por qué empezar joven es una ventaja y cómo la inflación afecta lo que guardas.

**Para empezar:** Santi y su primo empiezan a invertir 500 al mes. Santi empieza a los 18; su primo, a los 28. Los dos paran a los 60. En esta lección verás por qué la diferencia es enorme.

### Lo esencial (5 minutos)

#### Interés sobre interés

Con el interés compuesto, lo que gana tu dinero se suma y el siguiente año también gana. Mientras más tiempo, más crece. Por eso el tiempo es tu mejor aliado.



#### 1,000 al 8% cada año

- Hoy: **1,000**
- Primer año: **1.08**
- Al final del año: **1,080**
En 10 años serían unos 2,159; en 30 años, unos 10,063.


#### Lo que hace crecer tu dinero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tiempo | Mientras antes, mejor. | La mayor ventaja. |
| Aportar seguido | Poco pero cada mes. | Constancia. |
| Rendimiento | Mayor rendimiento, mayor riesgo. | Compara. |
| Inflación | Los precios suben. | Réstala. |

#### Rendimiento real

Si tu dinero gana 7% y los precios suben 4%, en realidad ganas cerca de 3%. A eso se le llama rendimiento real. Guardado bajo el colchón, tu rendimiento real es negativo.

> **Idea clave:** el interés compuesto necesita tiempo; empezar joven, aunque sea con poco, vale más que empezar tarde con mucho. Revisa siempre el rendimiento después de la inflación.



#### Comprueba lo que entendiste

1. ¿Qué es el interés compuesto?
*Respuesta:* Cuando lo que gana tu dinero también empieza a ganar.

2. ¿Qué es el rendimiento real?
*Respuesta:* Lo que ganas después de restar la inflación.


#### Para recordar

- Interés sobre interés.
- El tiempo es tu aliado.
- Resta la inflación.



### Profundiza (5 minutos más)

#### 500 al mes al 7% anual hasta los 60 años (aprox.)

| Empieza a los | Pone en total | Tiene a los 60 |
|---|---|---|
| 18 | 252,000 | Unos 1.5 millones |
| 28 | 192,000 | Unos 700 mil |
| 38 | 132,000 | Unos 300 mil |



#### En las deudas también funciona

El interés compuesto también trabaja en contra en las deudas: si no pagas, los intereses generan más intereses (M6).



#### Casos


**Caso 1. Santi y su primo**

Santi puede empezar a invertir 500 al mes a los 18.
- *¿Qué hace?* Empieza ya, aunque sea con poco, porque el tiempo multiplica.


**Caso 2. El colchón de Emilio**

Emilio guarda sus ahorros en su casa por años.
- *¿Qué hace?* Busca una opción regulada que pague más que la inflación.


**Caso 3. El rendimiento de Valeria**

Una inversión le paga 5% a Valeria y la inflación es 4%.
- *¿Qué hace?* Sabe que su rendimiento real es cerca de 1% y compara opciones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar a tener mucho | Pierdes tiempo | Empieza con poco |
| No aportar seguido | Crece lento | Cada mes |
| Olvidar la inflación | Crees que ganas más | Réstala |
| Guardar años en casa | Pierde valor | Opción regulada |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Emilio y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu dinero gana 9% y la inflación es 4%. ¿Rendimiento real aproximado? a) 13% · b) 5% · c) 9%
2. ¿Qué es lo que más hace crecer el interés compuesto? a) El tiempo · b) Revisar tu saldo diario · c) Cambiar de banco cada mes
3. 1,000 al 10% anual con interés compuesto. ¿Cuánto hay en 2 años? a) 1,200 · b) 1,100 · c) 1,210
**Respuestas:** 1-b: 9 menos 4. 2-a: mientras más tiempo, más crece. 3-c: 1,100 y luego 1,210.



#### Ponlo en práctica

Inviertes 2,000 al 6% anual. ¿Cuánto tienes al final del primer año y del segundo?
**Respuesta:** Primer año: 2,120. Segundo año: 2,247.20.



#### A tu plan

Calcula cuánto tendrías si inviertes 200 al mes desde hoy con el Excel del curso (hoja Meta).



### Para saber más

- **Inflación** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «inflación» y «calculadora de inflación».
- **Calculadora de interés** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simuladores».

### Palabras clave

- *Interés compuesto:* cuando los rendimientos que gana tu dinero también empiezan a ganar rendimientos.
- *Rendimiento real:* lo que gana tu dinero después de restar la inflación.
- *Inflación:* aumento de los precios con el tiempo.

### Fuentes

Banco de México · CONDUSEF, consultados el 30 de septiembre de 2026.

---

## M5 U03. Invertir: riesgo, rendimiento y no poner todo junto

**Lo que lograrás:** Explicar qué es invertir, la relación entre riesgo y rendimiento, por qué diversificar y cómo empezar con instituciones reguladas cuando tengas la edad.

**Para empezar:** Valeria tiene 3,000 de su negocio y un compañero le dice que «invertir es para ricos». Otra le dice que «en tal app ganas 20% al mes». En esta lección verás qué es de verdad invertir.

### Lo esencial (5 minutos)

#### Qué es invertir

Invertir es poner tu dinero en algo que puede crecer: bonos del gobierno, fondos, acciones o tu propio negocio. No es para ricos: hay opciones desde 100 pesos.



#### Riesgo y rendimiento van juntos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bajo riesgo | Cetes y bonos del gobierno. | Rendimiento más bajo. |
| Riesgo medio | Fondos que mezclan inversiones. | Sube y baja. |
| Riesgo alto | Acciones, tu negocio. | Puede ganar o perder mucho. |
| «Ganancia segura y altísima» | No existe. | Fraude. |

#### No pongas todo junto

Diversificar es repartir tu dinero. Si una inversión baja, las otras te protegen.



#### Cómo empezar

Cetesdirecto es la plataforma del gobierno para invertir en bonos desde 100 pesos, sin comisiones. Para abrir tu propia cuenta necesitas ser mayor de edad; mientras, puedes aprender con los simuladores y platicarlo en casa.



#### Un caso en un minuto

Valeria dejó 2,000 en su negocio, su inversión de mayor riesgo. Con su mamá, abrió una cuenta de Cetesdirecto a nombre de ella para invertir 1,000 a su favor. Cuando cumpla 18 abrirá la suya.

> **Idea clave:** a más rendimiento, más riesgo; reparte tu dinero, invierte solo en instituciones reguladas y desconfía de ganancias «seguras y altísimas».



#### Comprueba lo que entendiste

1. ¿Qué relación hay entre riesgo y rendimiento?
*Respuesta:* A más rendimiento posible, más riesgo.

2. ¿Qué es diversificar?
*Respuesta:* Repartir tu dinero en varias inversiones.


#### Para recordar

- Riesgo y rendimiento juntos.
- Diversifica.
- Solo instituciones reguladas.



### Profundiza (5 minutos más)

#### Antes de invertir pregúntate

| Pregunta | Por qué |
|---|---|
| ¿Tengo mi fondo para imprevistos? | Para no sacar la inversión antes |
| ¿Cuándo voy a necesitar el dinero? | Corto plazo, menos riesgo |
| ¿Está regulada la institución? | Verifica en la CONDUSEF o la CNBV |
| ¿Entiendo en qué invierto? | Si no, no inviertas |

> **Dato vigente:** en Cetesdirecto se puede invertir desde 100 pesos, sin comisiones; la cuenta la abren personas mayores de edad. Consultado el 30 de septiembre de 2026 a través de Cetesdirecto.



#### Casos


**Caso 1. El 20% al mes**

A Valeria le ofrecen ganar 20% al mes en una app.
- *¿Qué hace?* Desconfía: esas ganancias no existen y verifica la institución.


**Caso 2. Todo en una sola cosa**

Emilio quiere poner todo su ahorro en una sola acción que vio en redes.
- *¿Qué hace?* Reparte su dinero y deja su fondo aparte.


**Caso 3. La cuenta de Santi**

Santi ya cumplió 18 y quiere empezar a invertir poco.
- *¿Qué hace?* Abre su cuenta en una plataforma regulada, como Cetesdirecto, desde 100 pesos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es solo para ricos | No empiezas | Desde 100 pesos |
| Todo en una sola inversión | Lo pierdes todo | Diversifica |
| Invertir sin entender | Te engañan | Pregunta |
| Creer en ganancias garantizadas | Fraude | No existen |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué inversión suele tener menos riesgo? a) Acciones de una empresa nueva · b) Bonos del gobierno · c) Una app que paga 20% al mes
2. ¿Qué es diversificar? a) Repartir en varias inversiones · b) Poner todo en la que más rendimiento promete · c) Cambiar de banco cada año
3. Te prometen ganancias altísimas y seguras. ¿Qué es? a) Una gran oportunidad · b) Una inversión normal · c) Señal de fraude
**Respuestas:** 1-b: son del gobierno. 2-a: te protege. 3-c: no existen.



#### Ponlo en práctica

Tienes 4,000. Quieres 50% en tu negocio, 30% en bonos y 20% como fondo. ¿Cuánto va a cada uno?
**Respuesta:** Negocio: 2,000. Bonos: 1,200. Fondo: 800.



#### A tu plan

Explora el simulador de Cetesdirecto y anota cuánto ganaría tu dinero en un año.



### Para saber más

- **Cetesdirecto** (Gobierno de México · español): https://www.cetesdirecto.com — **Qué buscar:** «simulador» y «cómo abrir tu cuenta».
- **Invertir** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «inversión» y «fraudes de inversión».

### Palabras clave

- *Invertir:* poner tu dinero en algo que puede crecer con el tiempo, aceptando algún riesgo.
- *Diversificar:* repartir tu dinero en varias inversiones para no perderlo todo si una sale mal.
- *Riesgo:* posibilidad de ganar menos o perder.

### Fuentes

Cetesdirecto · CONDUSEF · CNBV, consultados el 30 de septiembre de 2026.

---

## M5 U04. Cripto, trading, «hazte rico» y apuestas: invertir no es apostar

**Lo que lograrás:** Distinguir invertir de especular y de apostar, reconocer esquemas de «hazte rico rápido» y saber por qué las apuestas en línea son riesgosas y prohibidas para menores.

**Para empezar:** Emilio vio un video: «Con 500 pesos en cripto hice 10 mil en una semana». También apuesta en partidos desde la app de un amigo. Ya perdió 1,800 este mes. En esta lección verás la diferencia entre invertir y apostar.

### Lo esencial (5 minutos)

#### Tres cosas distintas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Invertir | Algo que produce valor con el tiempo. | Años. |
| Especular | Comprar esperando que suba rápido. | Puede caer igual de rápido. |
| Apostar | Juegos de azar. | La casa siempre gana a la larga. |

#### Criptomonedas y trading

Las criptomonedas suben y bajan muchísimo en días. No están respaldadas por un banco central y en México no son moneda de curso legal. El trading de corto plazo se parece más a apostar que a invertir.



#### «Hazte rico rápido»

Cuidado con videos con autos y dinero, cursos caros para «vivir del trading» y grupos que prometen señales seguras o pagan por invitar amigos. Casi siempre ganan ellos con tu dinero. Si ganas por meter gente, es una pirámide.



#### Un caso en un minuto

Emilio dejó de apostar y habló con su hermano. Entendió que el video vendía un curso. Ahora pone 200 al mes en su meta de la moto y aprende de inversión con fuentes oficiales.

> **Idea clave:** invertir es a largo plazo en algo que produce valor; especular y apostar pueden hacerte perder rápido. Las apuestas están prohibidas para menores y los «hazte rico rápido» ganan con tu dinero.



#### Comprueba lo que entendiste

1. ¿Cuál es la diferencia entre invertir y apostar?
*Respuesta:* Invertir es a largo plazo en algo que produce valor; apostar es azar.

2. ¿Qué es una pirámide?
*Respuesta:* Un esquema donde ganas por meter a otras personas.


#### Para recordar

- Invertir, especular y apostar son distintos.
- Cripto sube y baja muchísimo.
- Apuestas: prohibidas para menores.



### Profundiza (5 minutos más)

#### Señales de alerta

| Señal | Qué es |
|---|---|
| «Ganancias garantizadas» | Nadie puede garantizarlas |
| «Invita amigos y gana» | Pirámide |
| «Curso para vivir del trading» | Ganan con el curso |
| «Apuesta y recupera lo perdido» | Te hunde más |



#### Si apostar se sale de control

Si apuestas para recuperar lo perdido, mientes sobre cuánto apuestas o pides prestado para apostar, pide ayuda. En México las casas de apuestas no pueden aceptar a menores de edad. La Línea de la Vida (800 911 2000) y los Centros de Integración Juvenil atienden sin costo.



#### Casos


**Caso 1. El video de cripto**

Emilio vio un video de alguien que multiplicó su dinero en una semana.
- *¿Qué hace?* Desconfía: sabe que el precio también puede caer y que le venden algo.


**Caso 2. Las apuestas de Emilio**

Emilio perdió 1,800 apostando y quiere recuperarlo apostando más.
- *¿Qué hace?* Deja de apostar y busca ayuda.


**Caso 3. El grupo de Naomi**

A Naomi la invitan a un grupo donde «ganas por meter a tus amigas».
- *¿Qué hace?* No entra: es una pirámide.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer videos de ganancias fáciles | Pierdes | Te venden algo |
| Apostar para recuperar | Pierdes más | Detente |
| Confundir cripto con ahorro | Puede caer mucho | Entiende el riesgo |
| Entrar a pirámides | Pierdes y metes a otros | No entres |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál es apostar? a) Jugar en una casa de apuestas · b) Comprar bonos del gobierno en Cetesdirecto cada mes · c) Reinvertir en tu negocio
2. Te invitan a ganar por meter amigos. ¿Qué es? a) Un negocio normal · b) Una inversión segura · c) Una pirámide
3. ¿Pueden los menores apostar en casas de apuestas en México? a) Sí, con permiso · b) No · c) Solo en línea
**Respuestas:** 1-a: es azar. 2-c: ganas por meter gente. 3-b: está prohibido.



#### Ponlo en práctica

Apuestas 150 cada fin de semana durante 3 meses (12 fines de semana) y recuperas 400. ¿Cuánto perdiste?
**Respuesta:** 150 por 12: 1,800. Menos 400: perdiste 1,400.



#### A tu plan

Si alguien te ofrece una inversión, revisa la tabla de señales de alerta antes de decidir.



### Para saber más

- **Fraudes de inversión** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «criptoactivos» y «pirámides».
- **Criptoactivos** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «criptoactivos».
- **Ayuda por apuestas** (Centros de Integración Juvenil · español): https://www.gob.mx/salud/cij — **Qué buscar:** «juego patológico».

### Palabras clave

- *Criptomonedas:* monedas digitales sin respaldo de un gobierno cuyo precio sube y baja muchísimo.
- *Especular:* comprar algo esperando venderlo caro en poco tiempo.
- *Pirámide:* esquema en el que ganas por meter a otras personas; tarde o temprano se cae.

### Fuentes

Banco de México · CONDUSEF · Secretaría de Gobernación (juegos y sorteos) · Centros de Integración Juvenil, consultados el 30 de septiembre de 2026.

---


# Parte 6. Módulo 6. Crédito sin trampas

## M6 U01. Qué es el crédito y cuánto cuesta de verdad

**Lo que lograrás:** Explicar qué es un crédito, cómo funcionan los intereses y el CAT, y cuándo un crédito ayuda y cuándo hunde.

**Para empezar:** Santi quiere una laptop de 12,000 para aprender diseño. En la tienda le dicen: «Llévatela hoy, pagas 399 a la semana». No sabe si le conviene. En esta lección lo calcularás.

### Lo esencial (5 minutos)

#### Pedir prestado cuesta

Un crédito te permite tener algo hoy y pagarlo después. Por usar ese dinero pagas intereses y a veces comisiones. El total siempre es más que el precio.



#### La laptop de Santi

- Por semana: **399**
- Semanas: **52**
- Total a pagar: **20,748**
Pagaría 8,748 de más por una laptop de 12,000.


#### Crédito que ayuda y crédito que hunde

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Para algo que te hace ganar | Herramienta, estudio. | Si puedes pagarlo. |
| Con el total claro | Y el CAT. | Compara. |
| Para gustos del momento | Pagas meses por algo que ya no usas. | Evítalo. |
| Sin saber cuánto pagas | Sorpresas. | Nunca. |

#### El CAT

El CAT sirve para comparar créditos. Mientras más bajo, más barato. Todas las instituciones reguladas deben decírtelo.



#### Un caso en un minuto

Santi vio que pagaría casi 9,000 de más. Juntó 800 al mes con sus reparaciones y compró la laptop de contado en 15 meses. Mientras, practicó en la computadora de la biblioteca.

> **Idea clave:** un crédito siempre cuesta más que el precio. Compara el total y el CAT, y úsalo solo para algo que puedas pagar y que te ayude a crecer.



#### Comprueba lo que entendiste

1. ¿Qué son los intereses?
*Respuesta:* Lo que cuesta usar dinero prestado.

2. ¿Para qué sirve el CAT?
*Respuesta:* Para comparar el costo de distintos créditos.


#### Para recordar

- El crédito cuesta.
- Total y CAT.
- Para crecer, no para gustos.



### Profundiza (5 minutos más)

#### Contado contra crédito

| Opción | Pagas | Cuándo lo tienes |
|---|---|---|
| Contado ahorrando | 12,000 | En unos meses |
| Crédito a 52 semanas | 20,748 | Hoy |
| Diferencia | 8,748 | La paciencia vale dinero |



#### Cuándo sí puede servir

Un crédito puede ayudar en tres casos. Si lo que compras te hace ganar más de lo que cuesta. Si puedes pagar todas las cuotas sin problema. Y si comparaste el CAT. Aun así, siendo menor de edad no puedes firmarlo: se necesita a un adulto.



#### Casos


**Caso 1. La laptop de Santi**

Le ofrecen a Santi una laptop a 399 por semana durante un año.
- *¿Qué hace?* Calcula el total, lo compara con el contado y decide juntar.


**Caso 2. Los tenis a crédito de Naomi**

Naomi quiere unos tenis a meses en la tarjeta de su hermana.
- *¿Qué hace?* Sabe que es un gusto del momento y ahorra para comprarlos.


**Caso 3. La herramienta de Valeria**

Valeria podría duplicar su producción con una batidora de 2,500 a crédito.
- *¿Qué hace?* Compara el CAT y revisa si su ganancia extra paga las cuotas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo la cuota | Pagas de más | Total |
| No comparar el CAT | Eliges el caro | Compara |
| Crédito para gustos | Pagas por nada | Ahorra |
| Pedir prestado siendo menor sin un adulto | No es válido | Acompañamiento |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Naomi y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Pagas 250 por semana durante 40 semanas por algo de 7,000. ¿Cuánto pagas de más? a) 3,000 · b) 10,000 · c) 250
2. Entre dos créditos, ¿cuál es más barato? a) El de CAT más alto · b) El de CAT más bajo · c) El de cuota más chica
3. ¿Para qué conviene más un crédito? a) Para algo que te ayuda a ganar y puedes pagar · b) Para ropa de moda que viste en tus redes sociales esta semana · c) Para una fiesta
**Respuestas:** 1-a: 10,000 menos 7,000. 2-b: cuesta menos. 3-a: te ayuda a crecer.



#### Ponlo en práctica

Una bocina cuesta 1,500 de contado o 99 a la semana por 26 semanas. ¿Cuánto pagas de más a crédito?
**Respuesta:** 99 por 26: 2,574. Pagas 1,074 de más.



#### A tu plan

La próxima vez que veas «paga poquito a la semana», calcula el total.



### Para saber más

- **Simulador de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simuladores» y «CAT».

### Palabras clave

- *Crédito:* dinero que te prestan y que devuelves después, casi siempre con intereses.
- *Intereses:* lo que cuesta usar dinero prestado.
- *CAT:* Costo Anual Total: porcentaje que incluye intereses y comisiones de un crédito en un año.

### Fuentes

CONDUSEF · Banco de México, consultados el 30 de septiembre de 2026.

---

## M6 U02. Tarjeta de crédito, meses sin intereses y «compra ahora, paga después»

**Lo que lograrás:** Explicar cómo funciona una tarjeta de crédito (pago mínimo, pago para no generar intereses, fecha de corte), los meses sin intereses y las apps de «compra ahora, paga después».

**Para empezar:** La hermana de Naomi pagó solo el mínimo de su tarjeta durante un año y su deuda casi no bajó. Y Naomi compró un celular en una app de «compra ahora, paga después» en 4 pagos, se le pasó uno y le cobraron recargo. En esta lección verás cómo usar el crédito sin caer.

### Lo esencial (5 minutos)

#### Los números de tu tarjeta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Fecha de corte | Cuando se cierra el mes de compras. | Anótala. |
| Fecha límite de pago | Hasta cuándo pagas. | No te pases. |
| Pago para no generar intereses | Pagas todo lo del mes. | El mejor. |
| Pago mínimo | Lo más poco que puedes pagar. | La deuda casi no baja. |

#### La trampa del mínimo

Si solo pagas el mínimo, casi todo se va a intereses y la deuda dura años. Paga siempre el total del mes o, si no puedes, lo más que puedas.



#### Meses sin intereses y pagos en plazos

Los meses sin intereses no cobran intereses **si pagas cada mes a tiempo**; pero comprometen tu dinero de los próximos meses. Las apps de «compra ahora, paga después» dividen en pocos pagos; si te atrasas, cobran recargos y pueden reportarte.



#### Un caso en un minuto

La hermana de Naomi dejó de usar la tarjeta, pagó más del mínimo cada mes y en 10 meses terminó. Naomi puso en su calendario las fechas de los pagos de la app y ya no se le pasa ninguno.

> **Idea clave:** con tarjeta de crédito paga el total del mes; el pago mínimo alarga la deuda. Meses sin intereses y «paga después» comprometen tu dinero futuro y cobran si te atrasas.



#### Comprueba lo que entendiste

1. ¿Qué pasa si solo pagas el mínimo?
*Respuesta:* La deuda casi no baja porque se va en intereses.

2. ¿Cuándo los meses sin intereses no cobran intereses?
*Respuesta:* Si pagas cada mes a tiempo.


#### Para recordar

- Paga el total.
- El mínimo es una trampa.
- Plazos comprometen tu dinero futuro.



### Profundiza (5 minutos más)

#### Tus compromisos de pago

| Compra | Pago por mes | Meses que faltan |
|---|---|---|
| | | |
| | | |
| Total al mes | | |



#### Tarjeta adicional

Si alguien te da una tarjeta adicional de su cuenta, todo lo que gastes lo paga la persona titular. Úsala con reglas claras.



#### Casos


**Caso 1. El mínimo de la hermana de Naomi**

La hermana de Naomi paga solo el mínimo y su deuda no baja.
- *¿Qué hace?* Deja de usar la tarjeta y paga más del mínimo cada mes.


**Caso 2. Los 4 pagos de Naomi**

A Naomi se le pasó un pago de la app de «compra ahora, paga después».
- *¿Qué hace?* Paga cuanto antes y pone las fechas en su calendario.


**Caso 3. Los meses de Emilio**

Emilio quiere comprar tres cosas a meses sin intereses a la vez.
- *¿Qué hace?* Suma cuánto pagaría al mes y revisa si le alcanza.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar el mínimo | Deuda por años | Paga el total |
| Olvidar fechas | Recargos | Calendario |
| Muchos meses a la vez | No te alcanza | Suma el mes |
| Tarjeta adicional sin reglas | Deudas a otro | Acuerden |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pago de la tarjeta evita intereses? a) El mínimo que aparece en tu estado de cuenta · b) El total del mes · c) Ninguno
2. Compras tres cosas a 6 meses sin intereses: 1,200, 1,800 y 3,000. ¿Cuánto pagas al mes? a) 1,000 · b) 6,000 · c) 600
3. ¿Qué pasa si te atrasas en una app de «paga después»? a) Nada · b) Te regalan el pago · c) Te cobran recargo
**Respuestas:** 1-b: pagas todo lo del mes. 2-a: 6,000 entre 6. 3-c: y pueden reportarte.



#### Ponlo en práctica

Tu tarjeta tiene una deuda de 5,000. Si pagas 250 al mes y te cobran unos 150 de intereses cada mes, ¿cuánto baja la deuda al mes?
**Respuesta:** 250 menos 150: solo 100. Tardarías años.



#### A tu plan

Si usas una tarjeta o una app de pagos en plazos, anota sus fechas en tu calendario.



### Para saber más

- **Tarjetas de crédito** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «pago mínimo» y «meses sin intereses».

### Palabras clave

- *Fecha de corte:* día en que se cierra el periodo de compras de tu tarjeta.
- *Pago mínimo:* lo menos que puedes pagar sin atrasarte; la deuda casi no baja.
- *Pago para no generar intereses:* pagar todo lo que gastaste en el periodo.

### Fuentes

CONDUSEF · Banco de México, consultados el 30 de septiembre de 2026.

---

## M6 U03. Tu historial desde joven y lo que nunca firmas por otros

**Lo que lograrás:** Explicar qué es el historial de crédito, cómo se construye bien desde joven y la diferencia entre aval, obligado solidario y referencia personal.

**Para empezar:** Santi cumplió 18 y un amigo le pidió que fuera su aval para una moto. «Nada más firmas», le dijo. En esta lección verás qué implica.

### Lo esencial (5 minutos)

#### Tu historial

El historial de crédito guarda cómo pagas tus créditos. Un buen historial te abre puertas: créditos más baratos, rentar una casa, algunos trabajos. Se construye pagando a tiempo.



#### Cada firma, una responsabilidad

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aval | Si el otro no paga, te cobran todo a ti. | Afecta tu historial. |
| Obligado solidario | Respondes como si tú lo pidieras. | Te cobran directo. |
| Referencia personal | Solo das tus datos de contacto. | No te pueden cobrar. |
| Pagar a tiempo lo tuyo | Buen historial. | Desde el primer crédito. |

#### Referencia no es aval

Ser referencia personal no te obliga a pagar. Si no firmaste como aval u obligado solidario, esa deuda no es tuya y un despacho de cobranza no puede cobrártela.



#### Un caso en un minuto

Santi le dijo a su amigo: «No puedo firmar una deuda que no podría pagar». Le ayudó a comparar opciones y a juntar un enganche. Su historial sigue limpio.

> **Idea clave:** tu historial se construye pagando a tiempo; ser aval u obligado solidario es aceptar la deuda de otra persona. Ser referencia solo es dar tus datos.



#### Comprueba lo que entendiste

1. ¿Qué pasa si eres aval y la otra persona no paga?
*Respuesta:* Te cobran a ti y afecta tu historial.

2. ¿Te pueden cobrar si solo fuiste referencia?
*Respuesta:* No.


#### Para recordar

- Historial: pagar a tiempo.
- Aval: la deuda puede ser tuya.
- Referencia: solo datos.



### Profundiza (5 minutos más)

#### Construir historial desde joven

| Paso | Por qué |
|---|---|
| Una sola tarjeta o crédito pequeño | Fácil de controlar |
| Úsala poco | Menos de 30% del límite |
| Paga el total cada mes | Sin intereses y buen historial |
| Revisa tu reporte cada año | Sin costo en Buró y Círculo de Crédito |

> **Dato vigente:** las reglas de la CONDUSEF solo permiten a los despachos de cobranza cobrar al deudor, a sus avales y a sus obligados solidarios. No pueden cobrar a referencias personales. Consultado el 30 de septiembre de 2026 a través de la CONDUSEF.



#### Casos


**Caso 1. La moto del amigo de Santi**

Un amigo le pide a Santi que sea su aval.
- *¿Qué hace?* Dice que no puede firmar una deuda que no podría pagar y ofrece otra ayuda.


**Caso 2. La llamada a Valeria**

Un despacho le llama a Valeria para cobrarle la deuda de una vecina de la que solo es referencia.
- *¿Qué hace?* No paga y sabe que puede reportar al despacho en la CONDUSEF.


**Caso 3. La primera tarjeta de Santi**

Santi quiere empezar su historial.
- *¿Qué hace?* Usa una tarjeta poco y paga el total cada mes.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar «nada más» | La deuda puede ser tuya | Solo si podrías pagarla |
| Pagar como referencia | Pierdes dinero | No te pueden cobrar |
| Usar todo el límite | Riesgo | Menos de 30% |
| No revisar tu reporte | Errores | Cada año |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿A quién NO puede cobrar un despacho? a) Al aval · b) Al obligado solidario que firmó el contrato completo · c) A la referencia personal
2. ¿Cómo se construye un buen historial? a) Pagando a tiempo · b) Pidiendo muchos créditos · c) Usando todo tu límite
3. Tu límite es 4,000. ¿Cuánto es 30%? a) 400 · b) 1,200 · c) 3,000
**Respuestas:** 1-c: solo dio sus datos. 2-a: es lo más importante. 3-b: 30% de 4,000.



#### Ponlo en práctica

Fuiste aval de un préstamo de 15,000 y la persona dejó de pagar cuando faltaban 9,000. ¿Cuánto te pueden cobrar?
**Respuesta:** Los 9,000 que faltan, más los cargos que diga el contrato.



#### A tu plan

Escribe cómo dirías que no si alguien te pide ser su aval.



### Para saber más

- **Reporte de crédito** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** «reporte de crédito especial».
- **REDECO** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «REDECO» y despachos de cobranza.

### Palabras clave

- *Historial de crédito:* registro de tus créditos y de cómo los pagaste.
- *Aval:* persona que firma y paga si quien pidió el crédito no paga.
- *Referencia personal:* persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no firma ni se obliga a pagar.

### Fuentes

CONDUSEF · Buró de Crédito, consultados el 30 de septiembre de 2026.

---

## M6 U04. Pagar tus estudios o tu idea: antes que un préstamo

**Lo que lograrás:** Buscar primero becas, apoyos y concursos para estudiar o emprender, y si hace falta un crédito, comparar con cuidado.

**Para empezar:** Emilio quiere estudiar un técnico en diseño que cuesta 18,000 al año. Una app le ofrece prestárselo «en 5 minutos». Valeria quiere 5,000 para crecer su negocio. En esta lección verás qué buscar antes de pedir prestado.

### Lo esencial (5 minutos)

#### El orden para conseguir dinero

1. Becas y apoyos (no se pagan).
2. Concursos y programas para jóvenes emprendedores.
3. Ahorro y reinversión de tu propio negocio.
4. Apoyo de la familia, con acuerdo por escrito.
5. Si hace falta, un crédito regulado, comparando el CAT, con un adulto.



#### Opciones antes del préstamo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Becas | Benito Juárez en prepa; otras para universidad. | Revisa convocatorias. |
| Concursos | Emprendimiento juvenil. | Premios y asesoría. |
| Tu reinversión | Crece con lo que ganas. | Sin deuda. |
| Apps de préstamo rápido | Caras y a veces fraude. | Evítalas. |

#### Un caso en un minuto

Emilio encontró una escuela pública con un técnico parecido y una beca. Valeria entró a un concurso de emprendimiento juvenil de su estado: no ganó, pero le dieron asesoría y conoció a otros jóvenes que venden.

> **Idea clave:** antes de pedir prestado busca becas, concursos y apoyos; si necesitas un crédito, que sea regulado, comparado y con un adulto.



#### Comprueba lo que entendiste

1. ¿Qué buscas antes de un préstamo?
*Respuesta:* Becas, concursos y apoyos.

2. ¿Qué revisas si pides un crédito?
*Respuesta:* Que sea regulado y el CAT.


#### Para recordar

- Becas y concursos primero.
- Crece con lo que ganas.
- Crédito regulado y comparado.



### Profundiza (5 minutos más)

#### Dónde buscar

| Qué | Dónde |
|---|---|
| Becas de prepa | Programas para el Bienestar |
| Programas para jóvenes | Instituto Mexicano de la Juventud y el de tu estado |
| Capacitación y apoyo con IMSS a partir de 18 años sin estudio ni trabajo | Jóvenes Construyendo el Futuro |
| Concursos de emprendimiento | Tu escuela, tu estado y universidades |

> **Dato vigente:** en 2026, Jóvenes Construyendo el Futuro da un apoyo mensual de 9,582.47 pesos y seguro del IMSS por hasta 12 meses. Es para jóvenes de 18 a 29 años que no estudian ni trabajan, mientras se capacitan en un centro de trabajo. Consultado el 30 de septiembre de 2026 a través de la STPS.



#### Casos


**Caso 1. El técnico de Emilio**

Una app le ofrece a Emilio prestarle 18,000 en 5 minutos para su técnico.
- *¿Qué hace?* Busca primero escuelas públicas y becas.


**Caso 2. Los 5,000 de Valeria**

Valeria quiere 5,000 para crecer su negocio.
- *¿Qué hace?* Busca concursos para jóvenes y crece con su reinversión.


**Caso 3. El préstamo del tío**

El tío de Santi le ofrece prestarle para herramientas.
- *¿Qué hace?* Acepta con un acuerdo por escrito de cuánto y cuándo paga.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir prestado primero | Deuda que no necesitabas | Becas y concursos |
| Apps de préstamo rápido | Caras y riesgosas | Evítalas |
| Préstamos de familia sin acuerdo | Pleitos | Por escrito |
| No comparar | Pagas de más | CAT |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué buscas primero para pagar tus estudios? a) Un préstamo en app · b) Becas y apoyos · c) Una tarjeta de crédito
2. ¿Para quién es Jóvenes Construyendo el Futuro? a) De 18 a 29 años que no estudian ni trabajan · b) Menores de 15 · c) Solo universitarios con promedio de nueve o más en su carrera
3. Tu tío te presta 3,000. ¿Qué hacen? a) Todo de palabra · b) Nada, porque es familia y confían en ti · c) Un acuerdo por escrito
**Respuestas:** 1-b: no se pagan. 2-a: requisitos del programa. 3-c: evita pleitos.



#### Ponlo en práctica

Un técnico cuesta 18,000 al año. Una beca cubre 60%. ¿Cuánto te falta y cuánto es al mes?
**Respuesta:** Te faltan 7,200; al mes, 600.



#### A tu plan

Busca una beca o un concurso para jóvenes en tu estado y anota la fecha límite.



### Para saber más

- **Becas** (Programas para el Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «becas».
- **Jóvenes Construyendo el Futuro** (STPS · español): https://jovenesconstruyendoelfuturo.stps.gob.mx — **Qué buscar:** requisitos.
- **Instituto Mexicano de la Juventud** (Gobierno de México · español): https://www.gob.mx/imjuve — **Qué buscar:** convocatorias.

### Palabras clave

- *Beca:* apoyo para estudiar que no se paga.
- *Convocatoria:* anuncio con los requisitos y fechas de un programa o concurso.

### Fuentes

STPS · Programas para el Bienestar · Instituto Mexicano de la Juventud, consultados el 30 de septiembre de 2026.

---

## M6 U05. Adelantos de sueldo y préstamos de nómina en tu primer trabajo

**Lo que lograrás:** Identificar qué es un adelanto de sueldo, cuánto te pueden descontar por ley, por qué las apps de adelanto cuestan y qué preguntar antes de aceptar un préstamo de nómina.

**Para empezar:** Emilio quiere unos tenis de 1,800. En la taquería le ofrecen adelantarle la semana, y una app le promete «tu sueldo antes, sin intereses», con una comisión de 49 pesos. Él piensa: «Total, es mi dinero».

### Lo esencial (5 minutos)

#### Tu dinero antes… ¿a qué costo?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Adelanto del trabajo | Te dan antes lo que ya vas a ganar. | Por escrito. |
| App de adelanto | Comisión cada vez. | Suma el año. |
| Préstamo de nómina | Del banco donde cobras. | Te descuentan meses. |
| Tu apartado | Sin costo. | La primera opción. |

#### Tu sueldo tiene protección

Si trabajas con contrato, la ley limita lo que te pueden descontar por un adelanto. El tope es **30% de lo que ganas arriba del salario mínimo** por pago. Si eres menor de edad, tu jornada y tu pago también tienen reglas especiales (M9 U02).

> **Dato vigente:** el artículo 110 de la Ley Federal del Trabajo limita los descuentos por anticipos del patrón a 30% del excedente del salario mínimo. Consultado el 30 de septiembre de 2026 a través de la Ley Federal del Trabajo.



#### La cuenta de Emilio

Si usa la app cada semana: 49 × 52 = **2,548 pesos al año**. Con eso se compraba un par de tenis y le sobraba. Y la semana siguiente le llega menos dinero, así que es fácil volver a pedir.



#### Un caso en un minuto

Emilio no usó la app. Apartó 300 por fin de semana y en seis semanas compró los tenis sin deber nada. Si un día necesita un adelanto por una urgencia, lo pedirá en la taquería, por escrito.

> **Idea clave:** un adelanto no es dinero extra, es tu mismo sueldo antes; las apps cobran cada vez y suman mucho en un año.



#### Comprueba lo que entendiste

1. ¿Un adelanto es dinero extra?
*Respuesta:* No, es tu mismo sueldo antes.

2. ¿Cuánto pagas al año con 49 pesos cada semana?
*Respuesta:* 2,548 pesos.


#### Para recordar

- No es dinero extra.
- Las apps cobran cada vez.
- Primero, tu apartado.



### Profundiza (5 minutos más)

#### Si te ofrecen un préstamo de nómina

Cuando tengas tu primer empleo formal, el banco donde cobras te ofrecerá préstamos «preaprobados». Pregunta el CAT y el total a pagar, y cuántos meses te van a descontar. Si cambias de trabajo, la deuda sigue.



#### «Tu sueldo antes» para comprar algo que quieres

Pedir adelantos para gustos es la forma más fácil de vivir siempre una semana atrás. Déjalos solo para urgencias.



#### Casos


**Caso 1. Los tenis**

La app le cobra a Emilio 49 pesos por adelantarle cada semana.
- *¿Qué hace?* Aparta cada semana y compra los tenis sin deber.


**Caso 2. El préstamo preaprobado**

A Santi, en su primer trabajo, el banco le ofrece 15,000 de préstamo de nómina.
- *¿Qué hace?* Pregunta el total a pagar y cuántos meses le descontarán antes de decidir.


**Caso 3. El adelanto de palabra**

A Valeria le adelantaron dinero en la cafetería donde ayuda y no sabe cuánto le van a descontar.
- *¿Qué hace?* Pide por escrito cuánto le descuentan y cuántos pagos faltan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es dinero extra | Vives una semana atrás | Es tu mismo sueldo |
| Usar la app cada semana | Pagas miles al año | Suma el costo |
| Aceptar un preaprobado sin preguntar | Te descuentan meses | Pregunta el total |
| Adelantos de palabra | No sabes cuánto debes | Por escrito |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Santi y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es un adelanto de sueldo? a) Un regalo del trabajo · b) Tu mismo sueldo, antes · c) Un bono
2. 35 pesos de comisión cada semana. ¿Cuánto es al año? a) 1,820 · b) 420 · c) 35
3. ¿Qué preguntas antes de un préstamo de nómina? a) Si es rápido · b) Si te dan más · c) El total a pagar y cuántos meses te descuentan
**Respuestas:** 1-b: luego te lo descuentan. 2-a: 35 × 52. 3-c: así sabes cuánto cuesta.



#### Ponlo en práctica

Quieres algo de 1,500 y apartas 250 por semana. ¿En cuántas semanas lo compras sin deber?
**Respuesta:** 1,500 ÷ 250 = 6 semanas.



#### A tu plan

Elige algo que quieras comprar y calcula cuántas semanas necesitas apartando una cantidad fija, sin adelantos.



### Para saber más

- **Compara créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador de crédito de nómina».
- **Trabajo de adolescentes** (PROFEDET · español): 800 911 7877 | Asesoría laboral sin costo.

### Palabras clave

- *Adelanto de sueldo:* recibir antes parte de tu pago, que luego te descuentan.
- *Préstamo de nómina:* crédito del banco donde cobras que se paga con descuentos de tu sueldo.

### Fuentes

Ley Federal del Trabajo (artículo 110) · CONDUSEF · PROFEDET, consultados el 30 de septiembre de 2026.

---


# Parte 7. Módulo 7. Riesgos, protección y fraudes

## M7 U01. Identifica tus riesgos antes de que pasen

**Lo que lograrás:** Reconocer los riesgos que pueden afectar tu dinero y tu negocio (salud, robo, accidentes, pérdidas) y decidir cómo protegerte.

**Para empezar:** A Santi le robaron la mochila con sus herramientas y tres celulares de clientes. No tenía ahorro ni una forma de pagarles. En esta lección identificarás tus riesgos.

### Lo esencial (5 minutos)

#### Qué es un riesgo

Un riesgo es algo que puede pasar y costarte. No puedes evitarlo todo, pero sí prepararte: prevenir, guardar un fondo o asegurarte.



#### Cuatro formas de manejar un riesgo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Evitarlo | No hacer lo que es muy riesgoso. | Ej.: no cargar todo junto. |
| Reducirlo | Prevenir. | Candado, respaldo, cuidado. |
| Guardarte para él | Un fondo. | Para imprevistos. |
| Transferirlo | Un seguro. | Pagas poco para no perder mucho. |

#### Lo que perdió Santi

- Herramientas: **1,800**
- Pantallas de clientes: **4,500**
- Pérdida: **6,300**
Con un fondo y cuidado habría perdido mucho menos.


#### Un caso en un minuto

Ahora Santi no carga todo junto y anota los celulares que recibe. Tiene un fondo del negocio y guarda los equipos de clientes en un lugar seguro. Pagó a sus clientes poco a poco y recuperó su confianza.

> **Idea clave:** identifica qué puede salir mal y prepárate: evita, reduce, guarda un fondo o asegúrate.



#### Comprueba lo que entendiste

1. ¿Qué es un riesgo?
*Respuesta:* Algo que puede pasar y costarte dinero, salud o tiempo.

2. ¿Cuáles son las cuatro formas de manejarlo?
*Respuesta:* Evitar, reducir, guardar un fondo o asegurarte.


#### Para recordar

- Identifica tus riesgos.
- Evita, reduce, fondo o seguro.
- Prepárate antes.



### Profundiza (5 minutos más)

#### Tus riesgos

| Riesgo | Qué podría costar | Cómo me preparo |
|---|---|---|
| Robo del celular | | |
| Enfermedad | | |
| Accidente | | |
| Algo de mi negocio | | |



#### Respaldos

Respalda fotos, documentos y datos de tu negocio en la nube. Si pierdes el celular, no pierdes todo.



#### Casos


**Caso 1. La mochila de Santi**

Santi carga herramientas y celulares de clientes en la misma mochila.
- *¿Qué hace?* Los separa, los anota y los guarda en un lugar seguro.


**Caso 2. El celular de Naomi**

Naomi tiene todos sus dibujos solo en su celular.
- *¿Qué hace?* Los respalda en la nube.


**Caso 3. La cocina de Valeria**

Valeria cocina con prisa y ya se quemó una vez.
- *¿Qué hace?* Reduce el riesgo: más orden y cuidado, y un pequeño fondo por si algo pasa.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar que no te va a pasar | Sin preparación | Identifica |
| Cargar todo junto | Pierdes todo | Separa |
| Sin respaldo | Pierdes tu trabajo | Nube |
| Sin fondo | Deudas | Guarda |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Naomi y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es transferir un riesgo? a) Contratar un seguro · b) Olvidarte del riesgo · c) Pasárselo a un amigo
2. ¿Cómo reduces el riesgo de perder tus fotos? a) Con más fotos en el celular · b) Con un respaldo en la nube · c) Borrando todo
3. ¿Qué forma de manejar un riesgo es guardar dinero? a) Evitar · b) Transferirlo a una aseguradora · c) Tener un fondo
**Respuestas:** 1-a: pagas poco para no perder mucho. 2-b: si pierdes el celular, lo conservas. 3-c: para imprevistos.



#### Ponlo en práctica

Un respaldo en la nube cuesta 40 al mes. Perder tus diseños te costaría 3,000 en trabajo. ¿Cuánto pagarías en un año de respaldo y cuánto te podría ahorrar?
**Respuesta:** 480 al año contra una pérdida de 3,000.



#### A tu plan

Llena tu tabla de riesgos y elige uno que vas a prevenir esta semana.



### Para saber más

- **Seguros y riesgos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguros» y «jóvenes».

### Palabras clave

- *Riesgo:* algo que puede pasar y costarte dinero, salud o tiempo.
- *Respaldo:* copia de tus archivos en otro lugar.

### Fuentes

CONDUSEF, consultado el 30 de septiembre de 2026.

---

## M7 U02. Tu seguro de estudiante y otros seguros

**Lo que lograrás:** Activar el seguro de salud del IMSS para estudiantes de escuelas públicas, que no tiene costo, y entender para qué sirven otros seguros.

**Para empezar:** Emilio se lastimó el tobillo jugando futbol. Su familia pagó 2,800 en un consultorio privado. Nadie sabía que, por estudiar en una prepa pública, tenía seguro del IMSS sin costo. En esta lección lo activarás.

### Lo esencial (5 minutos)

#### Ya tienes un seguro

Si estudias en una preparatoria o universidad **pública**, tienes derecho al seguro de salud para estudiantes del IMSS mientras estudies. No tiene costo, pero tienes que activarlo.



#### Cómo activarlo

1. Consulta o tramita tu número de seguridad social (NSS) con tu CURP en la app IMSS Digital o en el sitio del IMSS.
2. Entrega tu NSS a tu escuela para que te dé de alta.
3. Revisa en 30 a 60 días que ya aparezcas vigente.
4. Regístrate en tu Unidad de Medicina Familiar.

> **Dato vigente:** el Seguro de Salud para Estudiantes del IMSS es para estudiantes de escuelas públicas de nivel medio superior, superior y posgrado. No tiene costo y está vigente mientras estudies. La escuela te da de alta con tu NSS. Consultado el 30 de septiembre de 2026 a través del IMSS.



#### Otros seguros

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguro del celular | Si tu celular es tu herramienta. | Compara el costo. |
| Accidentes | Si trabajas en la calle o haces deporte. | Pregunta en tu escuela. |
| Seguro de un negocio | Cuando tu negocio crece. | Más adelante. |
| Pagar lo que ya tienes | Revisa antes. | Tu seguro de estudiante. |

#### Un caso en un minuto

Emilio sacó su NSS en la app en 10 minutos y lo entregó en la dirección de su prepa. Dos meses después ya tenía su clínica. Su hermana también lo activó.

> **Idea clave:** si estudias en una escuela pública, tienes seguro de salud del IMSS sin costo. Saca tu NSS, entrégalo en tu escuela y regístrate en tu clínica.



#### Comprueba lo que entendiste

1. ¿Quién tiene el seguro de estudiantes del IMSS?
*Respuesta:* Quien estudia en una escuela pública de nivel medio superior o superior.

2. ¿Qué entregas a tu escuela?
*Respuesta:* Tu número de seguridad social (NSS).


#### Para recordar

- Escuela pública: seguro sin costo.
- NSS a tu escuela.
- Regístrate en tu clínica.



### Profundiza (5 minutos más)

#### Antes de contratar un seguro

| Pregunta | Por qué |
|---|---|
| ¿Ya tengo algo que me cubra? | Evitas pagar doble |
| ¿Cuánto cuesta al año? | Compara |
| ¿Qué no cubre? | Evitas sorpresas |
| ¿Está registrada la aseguradora? | En la CNSF |



#### Tu familia

Si en tu casa alguien no tiene seguridad social, cuéntales de dos opciones. Los centros de salud y el Seguro de Salud para la Familia del IMSS, que se paga por persona al año.



#### Casos


**Caso 1. El tobillo de Emilio**

Emilio se lastimó y su familia pagó un consultorio privado.
- *¿Qué hace para la próxima?* Activa su seguro de estudiante con su NSS en la escuela.


**Caso 2. El seguro del celular de Naomi**

En la tienda le ofrecen a Naomi un seguro para su celular.
- *¿Qué hace?* Compara el costo con lo que vale el celular y qué cubre.


**Caso 3. La prepa privada de Santi**

El primo de Santi estudia en una prepa privada.
- *¿Qué hace?* Revisa si su escuela o su familia le dan otra cobertura, porque el seguro de estudiante es para escuelas públicas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No activar tu seguro | Pagas de más | NSS a tu escuela |
| Pagar doble | Desperdicias | Revisa antes |
| No leer qué cubre | Sorpresas | Lee |
| Aseguradoras sin registro | Fraude | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Naomi y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuánto cuesta el seguro de salud del IMSS para estudiantes de escuelas públicas? a) Una cuota mensual · b) No tiene costo · c) Depende de tu promedio
2. ¿Qué necesitas para activarlo? a) Tu NSS entregado a tu escuela · b) Una tarjeta de crédito a tu nombre y la de tus papás · c) Un gestor
3. ¿Qué revisas antes de contratar un seguro? a) Solo el color de la póliza · b) Lo que te dice el vendedor de la tienda sobre el precio · c) Si ya tienes algo que te cubra
**Respuestas:** 1-b: es sin costo. 2-a: la escuela te da de alta. 3-c: evitas pagar doble.



#### Ponlo en práctica

Un seguro de celular cuesta 99 al mes y tu celular vale 3,500. ¿Cuánto pagas en un año y qué porcentaje del valor es?
**Respuesta:** 1,188 al año; unos 34% del valor del celular.



#### A tu plan

Consulta tu NSS con tu CURP y entrégalo en tu escuela esta semana.



### Para saber más

- **Seguro de Salud para Estudiantes** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «seguro para estudiantes» y «NSS».

### Palabras clave

- *Seguro de salud para estudiantes:* seguro del IMSS para estudiantes de escuelas públicas de nivel medio superior y superior; no tiene costo.
- *NSS:* número de seguridad social que te identifica en el IMSS.

### Fuentes

IMSS · CNSF, consultados el 30 de septiembre de 2026.

---

## M7 U03. Fraudes que buscan jóvenes: cuentas mula, falsos empleos y amenazas

**Lo que lograrás:** Reconocer los fraudes que buscan a jóvenes (prestar tu cuenta, empleos falsos, sorteos, amenazas en línea) y saber qué hacer.

**Para empezar:** A Emilio le escribieron por redes: «Gana 2,000 a la semana solo recibiendo depósitos en tu cuenta y pasándolos a otra». Parecía dinero fácil. En esta lección verás por qué es una trampa.

### Lo esencial (5 minutos)

#### Cuentas mula

Una cuenta mula es una cuenta que alguien presta para mover dinero de fraudes. Quien presta su cuenta puede quedar como responsable. **Nunca prestes tu cuenta ni tu tarjeta.**



#### Engaños frecuentes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Recibe y pasa depósitos» | Cuenta mula. | Delito. |
| Empleo que pide pago | Para «capacitación» o «uniforme». | Engaño. |
| «Ganaste un sorteo» | Te piden pagar para cobrar. | Engaño. |
| Amenazas en línea | Te piden dinero o fotos. | No pagues; pide ayuda. |

> **Dato vigente:** la CONDUSEF advierte que prestar tu cuenta para recibir y mover dinero de otros puede ser delito. Se llama operaciones con recursos de procedencia ilícita, con penas de 5 a 15 años de prisión. Reclutan jóvenes con ofertas de «trabajo desde casa». Consultado el 30 de septiembre de 2026 a través de la CONDUSEF.

#### Si alguien te amenaza en línea

Si alguien te pide dinero o fotos, o amenaza con publicar algo tuyo, no pagues ni mandes nada. Guarda capturas, bloquea y cuéntale a un adulto de confianza. Denuncia en el 088 o con la policía cibernética de tu estado. No es tu culpa y hay ayuda.



#### Un caso en un minuto

Emilio no contestó, bloqueó la cuenta y le avisó a su grupo del salón. Dos compañeros ya habían recibido el mismo mensaje.

> **Idea clave:** nunca prestes tu cuenta ni tu tarjeta; ningún trabajo real te pide pagar ni mover depósitos ajenos. Si te amenazan en línea, no pagues, guarda pruebas y pide ayuda.



#### Comprueba lo que entendiste

1. ¿Qué es una cuenta mula?
*Respuesta:* Una cuenta prestada para mover dinero de fraudes.

2. ¿Qué haces si te amenazan en línea?
*Respuesta:* No pagas, guardas capturas, bloqueas, avisas a un adulto y denuncias.


#### Para recordar

- Nunca prestes tu cuenta.
- Trabajo real no pide pagar.
- Amenazas: no pagues, pide ayuda.



### Profundiza (5 minutos más)

#### Señales de un empleo falso

| Señal | Por qué |
|---|---|
| Mucho dinero por poco trabajo | Demasiado bueno |
| Te piden pagar algo | Nadie serio cobra por contratarte |
| Solo por mensajes, sin empresa real | No hay a quién reclamar |
| Te piden tu cuenta o tarjeta | Cuenta mula |



#### Avisa a otros

Cuando reconozcas un fraude, avisa a tu grupo o a tu familia. Muchas veces el mismo mensaje llega a muchas personas.



#### Casos


**Caso 1. El «trabajo» de Emilio**

Le ofrecen a Emilio 2,000 a la semana por recibir y pasar depósitos.
- *¿Qué hace?* No acepta, bloquea y avisa: es una cuenta mula.


**Caso 2. El sorteo de Naomi**

A Naomi le avisan que ganó un celular y debe pagar 350 de envío.
- *¿Qué hace?* No paga: nadie cobra por darte un premio.


**Caso 3. La amenaza a Valeria**

Alguien amenaza a Valeria con publicar una foto si no le paga.
- *¿Qué hace?* No paga, guarda capturas, bloquea, avisa a un adulto y denuncia.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Prestar tu cuenta | Delito | Nunca |
| Pagar por un empleo | Engaño | Desconfía |
| Pagar por un premio | Pierdes | No existe |
| Callar una amenaza | Sigue | Pide ayuda |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Naomi y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te ofrecen pagar por recibir depósitos y pasarlos. ¿Qué es? a) Una cuenta mula · b) Un trabajo normal · c) Una inversión
2. ¿Qué haces si te amenazan con publicar algo tuyo? a) Pagas para que no lo publiquen · b) No pagas y pides ayuda · c) Mandas lo que pidan
3. Un empleo te pide 500 para «capacitación». ¿Qué es? a) Un trámite normal de cualquier empresa · b) Una oportunidad · c) Una señal de engaño
**Respuestas:** 1-a: mueve dinero de fraudes. 2-b: no es tu culpa. 3-c: nadie serio cobra por contratarte.



#### Ponlo en práctica

Un «empleo» te pide 450 de uniforme y 300 de capacitación. ¿Cuánto perderías y cuánto paga un empleo real por contratarte?
**Respuesta:** Perderías 750. Un empleo real no te cobra por contratarte.



#### A tu plan

Comparte en tu grupo de amigos qué es una cuenta mula.



### Para saber más

- **Cuentas mula** (CONDUSEF · español): https://www.gob.mx/condusef — **Qué buscar:** «cuentas mula».
- **Denuncia cibernética** (Guardia Nacional · español): 088 — **Qué buscar:** denuncia de fraudes y amenazas en línea.

### Palabras clave

- *Cuenta mula:* cuenta que alguien presta para recibir y mover dinero de fraudes; quien la presta puede ser acusado de un delito.
- *Extorsión:* cuando alguien te amenaza para que le des dinero o algo más.

### Fuentes

CONDUSEF · Guardia Nacional, consultados el 30 de septiembre de 2026.

---

## M7 U04. Tu identidad digital y tus contraseñas

**Lo que lograrás:** Proteger tus cuentas con contraseñas fuertes y verificación en dos pasos, cuidar tus datos y decidir qué pasa con tus cuentas digitales.

**Para empezar:** Naomi usa la misma contraseña para todo: su correo, su banco, sus juegos. Hackearon una página de juegos y días después alguien entró a su correo. En esta lección protegerás tu identidad digital.

### Lo esencial (5 minutos)

#### Candados digitales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Contraseñas distintas | Una por cuenta importante. | Largas. |
| Verificación en dos pasos | Un código extra. | En correo, banco y redes. |
| Gestor de contraseñas | Guarda tus contraseñas con seguridad. | Útil. |
| La misma contraseña para todo | Si cae una, caen todas. | Evítalo. |

#### Una contraseña fuerte

Una contraseña fuerte es larga: una frase de varias palabras que recuerdes, con números o signos. Tu fecha de nacimiento o «123456» se adivinan en segundos.



#### Un caso en un minuto

Naomi cambió la contraseña de su correo y de su banco por frases largas distintas. Activó la verificación en dos pasos y revisó qué apps tenían acceso a su cuenta.

> **Idea clave:** usa contraseñas largas y distintas en tus cuentas importantes y activa la verificación en dos pasos; nunca compartas códigos.



#### Comprueba lo que entendiste

1. ¿Por qué no usar la misma contraseña para todo?
*Respuesta:* Porque si cae una, caen todas.

2. ¿Qué es la verificación en dos pasos?
*Respuesta:* Un código extra además de tu contraseña.


#### Para recordar

- Contraseñas largas y distintas.
- Dos pasos.
- Nunca compartas códigos.



### Profundiza (5 minutos más)

#### Revisa tus cuentas

| Cuenta | Contraseña distinta | Dos pasos |
|---|---|---|
| Correo | | |
| Banco | | |
| Redes | | |
| Tienda en línea | | |



#### Tu legado digital

Tus cuentas, fotos y archivos también son parte de lo que dejas. Algunas plataformas permiten nombrar un contacto de legado. En tu familia, platiquen dónde están los papeles importantes: el testamento de tus papás, sus beneficiarios y cómo acceder a lo importante si algo pasa.



#### Casos


**Caso 1. La contraseña de Naomi**

Naomi usa la misma contraseña para todo.
- *¿Qué hace?* Pone contraseñas distintas y largas en sus cuentas importantes.


**Caso 2. El código de Emilio**

Alguien le pide a Emilio «el código que te llegó» para recuperar su cuenta.
- *¿Qué hace?* No lo da y activa la verificación en dos pasos.


**Caso 3. Los papeles de la familia de Valeria**

Los papás de Valeria no saben dónde están sus papeles importantes.
- *¿Qué hace?* Les propone hacer una carpeta y platicar dónde está todo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Una contraseña para todo | Caen todas | Distintas |
| Contraseñas cortas | Se adivinan | Frases largas |
| Dar códigos | Te roban la cuenta | Nunca |
| No hablar de papeles en familia | Problemas si algo pasa | Carpeta familiar |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Emilio y Valeria. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál contraseña es más fuerte? a) 123456 · b) Tu fecha de nacimiento con el nombre de tu mascota · c) Una frase larga con números
2. ¿Qué haces si alguien te pide el código que te llegó? a) No lo das · b) Lo das si es tu amigo · c) Lo publicas
3. ¿Qué protege tu cuenta aunque roben tu contraseña? a) Un fondo de pantalla · b) La verificación en dos pasos · c) Tener más seguidores y amigos en tus redes sociales
**Respuestas:** 1-c: es larga y difícil. 2-a: es la llave de tu cuenta. 3-b: pide un código extra.



#### Ponlo en práctica

Tienes 6 cuentas importantes y 2 tienen verificación en dos pasos. ¿Cuántas te faltan y qué porcentaje ya tiene?
**Respuesta:** Te faltan 4; ya tienes 33%.



#### A tu plan

Activa la verificación en dos pasos en tu correo y tu banco hoy.



### Para saber más

- **Seguridad digital** (Secretaría de Seguridad y Protección Ciudadana · español): https://www.gob.mx/sspc — **Qué buscar:** «contraseñas seguras».

### Palabras clave

- *Identidad digital:* tus cuentas, datos y lo que publicas en internet.
- *Verificación en dos pasos:* un código extra además de tu contraseña para entrar a tu cuenta.
- *Legado digital:* lo que pasa con tus cuentas y archivos si ya no puedes usarlos.

### Fuentes

SSPC · CONDUSEF, consultados el 30 de septiembre de 2026.

---


# Parte 8. Módulo 8. El sistema, la economía y tu familia

## M8 U01. Quién es quién en el sistema financiero y quién te protege

**Lo que lograrás:** Identificar las instituciones financieras (bancos y otras), las autoridades que las vigilan y tus derechos como usuario.

**Para empezar:** A Valeria su app le cobró una comisión que no reconoce. Llamó y nadie le resolvió. No sabe a quién más acudir. En esta lección conocerás quién te protege.

### Lo esencial (5 minutos)

#### Quién es quién

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bancos | Cuentas, tarjetas, créditos. | Depósitos protegidos por el IPAB. |
| Banco de México | Cuida el valor del peso y la inflación. | Autoridad. |
| CNBV | Vigila a bancos y otras instituciones. | Autoridad. |
| CONDUSEF | Te defiende como usuario. | Quejas y verificación. |
| PROFECO | Te defiende como consumidor. | Tiendas y servicios. |

#### Tus derechos como usuario

Tienes derecho a información clara (costos y CAT), a un contrato, a reclamar y a que te respondan. Primero reclama en la institución (su unidad de atención) y pide un folio. Si no te resuelven, acude a la CONDUSEF.



#### Verifica antes de confiar

Antes de abrir una cuenta o pedir un crédito, busca la institución en el SIPRES de la CONDUSEF. Te dice si existe, qué tipo de institución es y quién la vigila.



#### Un caso en un minuto

Valeria reclamó por escrito en su app y guardó el folio. Como no le respondieron en el plazo, presentó su queja en la CONDUSEF y le devolvieron la comisión.

> **Idea clave:** conoce quién es quién. Los bancos te dan servicios, las autoridades los vigilan y la CONDUSEF te defiende. Reclama primero con folio; si no te resuelven, acude a la CONDUSEF.



#### Comprueba lo que entendiste

1. ¿Quién te defiende como usuario de servicios financieros?
*Respuesta:* La CONDUSEF.

2. ¿Qué pides cuando reclamas?
*Respuesta:* Un número de folio.


#### Para recordar

- Bancos, autoridades y defensores.
- Reclama con folio.
- Verifica en el SIPRES.



### Profundiza (5 minutos más)

#### A quién acudir

| Problema | Dónde |
|---|---|
| Cobro que no reconoces en tu banco o app | Unidad de atención y luego CONDUSEF |
| Una tienda no respeta la garantía | PROFECO |
| Quieres saber si una financiera existe | SIPRES de la CONDUSEF |
| Fraude o amenaza | 088 |



#### Tus responsabilidades

También tienes obligaciones: leer lo que firmas, pagar a tiempo, cuidar tus claves y avisar rápido si pierdes tu tarjeta.



#### Casos


**Caso 1. La comisión de Valeria**

A Valeria le cobraron una comisión que no reconoce y no le resuelven.
- *¿Qué hace?* Reclama con folio y, si no le resuelven, acude a la CONDUSEF.


**Caso 2. La financiera nueva de Emilio**

Emilio vio una financiera nueva que presta a jóvenes.
- *¿Qué hace?* La busca en el SIPRES antes de dar sus datos.


**Caso 3. La garantía de Naomi**

Una tienda no quiere cambiarle a Naomi unos audífonos con garantía.
- *¿Qué hace?* Presenta su queja en la PROFECO.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No reclamar | Pierdes tu dinero | Reclama |
| Sin folio | No hay prueba | Pídelo |
| Confiar sin verificar | Fraude | SIPRES |
| No leer lo que firmas | Sorpresas | Tu responsabilidad |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién cuida el valor del peso y la inflación? a) La PROFECO · b) El Banco de México · c) Tu escuela y la dirección de la prepa
2. ¿Dónde verificas si una financiera existe? a) En el SIPRES de la CONDUSEF · b) En sus anuncios de redes · c) Preguntando a tus amigos del salón si la conocen
3. Una tienda no respeta tu garantía. ¿A dónde acudes? a) Al banco donde tienes tu cuenta · b) A la CNBV · c) A la PROFECO
**Respuestas:** 1-b: es su trabajo. 2-a: registro oficial. 3-c: defiende al consumidor.



#### Ponlo en práctica

Te cobraron 150 cada mes durante 5 meses una comisión que no reconoces. ¿Cuánto reclamas?
**Respuesta:** 150 por 5: 750.



#### A tu plan

Guarda en tu celular el número y el sitio de la CONDUSEF y de la PROFECO.



### Para saber más

- **CONDUSEF** (Gobierno de México · español): https://www.condusef.gob.mx — **Qué buscar:** «SIPRES» y «presenta tu queja».
- **Banco de México** (Gobierno de México · español): https://www.banxico.org.mx — **Qué buscar:** «qué hace el Banco de México».

### Palabras clave

- *CONDUSEF:* autoridad que defiende a las personas usuarias de servicios financieros.
- *CNBV:* autoridad que vigila a los bancos y otras instituciones financieras.
- *Folio:* número que te dan al reclamar y que sirve de prueba.

### Fuentes

CONDUSEF · Banco de México · CNBV · PROFECO, consultados el 30 de septiembre de 2026.

---

## M8 U02. Impuestos: de dónde salen tu escuela y tu beca

**Lo que lograrás:** Explicar qué son los impuestos, cuáles pagas aunque no te des cuenta (IVA) y para qué se usan (escuelas, hospitales, becas, calles).

**Para empezar:** Emilio dice: «Yo no pago impuestos, soy estudiante». Pero cada vez que compra un refresco o un celular paga IVA. Y su beca sale de los impuestos de todos. En esta lección verás cómo funciona.

### Lo esencial (5 minutos)

#### Para qué sirven

Los impuestos pagan escuelas, hospitales, becas, pensiones, calles, seguridad y más. Es lo que aportamos entre todas las personas para lo que usamos en común.



#### Impuestos que conoces

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IVA | 16% en el precio de muchas cosas. | Lo pagas al comprar. |
| ISR | Sobre lo que ganas. | Al trabajar o vender. |
| Predial | Por tener una casa. | Lo paga quien es dueño. |
| En qué se usan | Escuelas, becas, hospitales. | Lo que ves. |

#### El IVA de un celular

- Precio antes de IVA: **3,000**
- IVA: **16%**
- Impuesto: **480**
Pagas 3,480 en total.


#### Un caso en un minuto

Emilio revisó su ticket del súper: casi todo tenía IVA. Luego vio que su beca y su prepa se pagan con impuestos. Entendió por qué es importante que el dinero público se use bien y cómo preguntar en qué se gasta.

> **Idea clave:** todos pagamos impuestos, aunque sea en lo que compramos; con ellos se pagan escuelas, becas y hospitales. Pagarlos y vigilar cómo se usan es parte de ser ciudadano.



#### Comprueba lo que entendiste

1. ¿Qué impuesto pagas al comprar?
*Respuesta:* El IVA.

2. ¿Para qué se usan los impuestos?
*Respuesta:* Para escuelas, hospitales, becas, calles y otros servicios públicos.


#### Para recordar

- IVA en lo que compras.
- ISR sobre lo que ganas.
- Pagan servicios públicos.



### Profundiza (5 minutos más)

#### Tu recibo de nómina

| Concepto | Qué es |
|---|---|
| Sueldo | Lo que ganas |
| ISR retenido | Impuesto que se descuenta, si ganas más del mínimo |
| IMSS | Tu parte de seguridad social |
| Neto | Lo que te llega |



#### Transparencia

Puedes consultar en qué se gasta el dinero público en los portales de transparencia del gobierno. Preguntar y opinar también es una forma de participar.



#### Casos


**Caso 1. «Yo no pago impuestos»**

Emilio cree que como estudiante no paga impuestos.
- *¿Qué aprende?* Que paga IVA en lo que compra.


**Caso 2. El precio de Valeria**

Valeria vende a una tienda que le pide precio con IVA.
- *¿Qué hace?* Calcula el 16% y lo suma a su precio.


**Caso 3. La nómina de Santi**

En su primer recibo, Santi ve descuentos que no entiende.
- *¿Qué hace?* Revisa su recibo: ISR si gana más del mínimo, IMSS y su neto.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no pagas impuestos | Ignoras el IVA | Revisa tus tickets |
| No entender tu recibo | No sabes qué te descuentan | Revísalo |
| Olvidar el IVA en tu precio | Pierdes dinero | Súmalo si te lo piden |
| No preguntar cómo se gasta | Nadie vigila | Transparencia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Algo cuesta 500 antes de IVA. ¿Cuánto pagas con IVA de 16%? a) 516 · b) 580 · c) 800
2. ¿Qué pagas al comprar casi cualquier cosa? a) El predial · b) El IVA · c) El ISR
3. ¿Para qué sirven los impuestos? a) Para pagar servicios públicos · b) Para los bancos · c) Para las tiendas y las empresas que venden productos
**Respuestas:** 1-b: 500 más 80. 2-b: va en el precio. 3-a: escuelas, becas, hospitales.



#### Ponlo en práctica

Compras en el mes cosas por 2,320 con IVA incluido. ¿Cuánto es el IVA? (Pista: precio sin IVA = total entre 1.16)
**Respuesta:** 2,320 entre 1.16: 2,000. IVA: 320.



#### A tu plan

Revisa un ticket de compra y encuentra cuánto pagaste de IVA.



### Para saber más

- **Impuestos para jóvenes** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «cultura contributiva».
- **Transparencia presupuestaria** (Secretaría de Hacienda · español): https://www.transparenciapresupuestaria.gob.mx — **Qué buscar:** «en qué se gasta».

### Palabras clave

- *Impuestos:* dinero que pagamos al gobierno para cubrir servicios públicos.
- *IVA:* impuesto de 16% que va en el precio de muchas cosas.
- *ISR:* impuesto sobre lo que ganas.

### Fuentes

SAT · Secretaría de Hacienda, consultados el 30 de septiembre de 2026.

---

## M8 U03. Economía, noticias y rumores: lo que cambia tu dinero

**Lo que lograrás:** Explicar cómo la inflación, las tasas de interés y el tipo de cambio afectan tu dinero, y distinguir información confiable de rumores.

**Para empezar:** Naomi vio en redes: «¡El dólar va a llegar a 30 mañana, cambia todos tus pesos ya!». Emilio escuchó que «los precios subieron 50%». En esta lección verás qué es cierto y cómo verificarlo.

### Lo esencial (5 minutos)

#### Tres cosas que mueven tu dinero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Inflación | Suben los precios. | Tu dinero compra menos. |
| Tasa de interés | Cuánto pagan los ahorros y cobran los créditos. | La decide el mercado y Banxico influye. |
| Tipo de cambio | Pesos por dólar. | Afecta lo importado y las remesas. |

#### Información confiable

Las cifras de inflación las publica el INEGI; las del tipo de cambio, el Banco de México. Los rumores en redes buscan que actúes con miedo. Antes de decidir, revisa la fuente oficial y la fecha.



#### Ajusta tu plan sin pánico

Si suben los precios, revisa tu presupuesto y tus precios de venta. Si cambia el tipo de cambio, revisa tus compras en dólares. Cambios pequeños, no decisiones de pánico.



#### Un caso en un minuto

Naomi revisó el tipo de cambio en el Banco de México: no había nada parecido al rumor. Emilio vio en el INEGI que la inflación del año era mucho menor a 50%. Valeria subió sus precios un poco porque subió el azúcar.

> **Idea clave:** inflación, tasas y tipo de cambio afectan tu dinero; revisa las cifras en fuentes oficiales y ajusta tu plan sin pánico.



#### Comprueba lo que entendiste

1. ¿Quién publica la inflación en México?
*Respuesta:* El INEGI.

2. ¿Qué haces ante un rumor en redes?
*Respuesta:* Reviso la fuente oficial y la fecha antes de decidir.


#### Para recordar

- Inflación, tasas, tipo de cambio.
- Fuentes oficiales.
- Ajusta sin pánico.



### Profundiza (5 minutos más)

#### Si cambia la economía

| Si pasa | Qué revisas |
|---|---|
| Suben los precios | Tu presupuesto y tus precios de venta |
| Suben las tasas | Créditos más caros; ahorro paga más |
| Sube el dólar | Compras importadas más caras |
| Baja el dólar | Remesas rinden menos en pesos |



#### Cómo reconocer un rumor

Sin fuente, con mayúsculas y signos de alarma, pidiendo que actúes ya, o que viene de una cuenta que vende algo. Busca la misma noticia en medios serios o fuentes oficiales.



#### Casos


**Caso 1. El dólar a 30**

Naomi ve un mensaje: el dólar llegará a 30 mañana.
- *¿Qué hace?* Revisa el tipo de cambio en el Banco de México y no actúa con pánico.


**Caso 2. El azúcar de Valeria**

Subió el precio del azúcar y a Valeria le quedan menos ganancias.
- *¿Qué hace?* Recalcula su costo y ajusta un poco su precio.


**Caso 3. El 50% de Emilio**

Emilio escucha que los precios subieron 50%.
- *¿Qué hace?* Busca la inflación oficial del INEGI.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer rumores | Decisiones malas | Fuente oficial |
| Decidir con pánico | Pierdes | Ajusta con calma |
| No ajustar precios | Pierdes ganancia | Recalcula |
| Ignorar la economía | Sorpresas | Revisa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Valeria y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Quién publica el tipo de cambio oficial? a) Un influencer de finanzas · b) El Banco de México · c) Tu banco nada más
2. Suben los precios. ¿Qué pasa con tu dinero? a) Compra menos · b) Compra más · c) No cambia
3. ¿Qué señal tiene un rumor? a) Pide que actúes ya y no tiene fuente · b) Tiene fecha y fuente oficial · c) Está publicado en el sitio del INEGI con fecha y datos
**Respuestas:** 1-b: fuente oficial. 2-a: es la inflación. 3-a: prisa y sin fuente.



#### Ponlo en práctica

Tu postre cuesta 19 y los ingredientes suben 10%. Si quieres ganar lo mismo, ¿a cuánto sube tu costo?
**Respuesta:** 19 más 10%: unos 20.90.



#### A tu plan

Busca la inflación más reciente en el INEGI y compárala con lo que dicen en redes.



### Para saber más

- **Inflación** (INEGI · español): https://www.inegi.org.mx — **Qué buscar:** «INPC».
- **Tipo de cambio** (Banco de México · español): https://www.banxico.org.mx — **Qué buscar:** «tipo de cambio FIX».

### Palabras clave

- *Tasa de interés:* porcentaje que pagan los ahorros o cobran los créditos.
- *Rumor:* información sin fuente que circula sin verificar.

### Fuentes

INEGI · Banco de México, consultados el 30 de septiembre de 2026.

---

## M8 U04. Tu familia y el dinero: ayudar, sus papeles y lo que se hereda

**Lo que lograrás:** Apoyar en casa con reglas claras, ayudar a tu familia a ordenar sus papeles (beneficiarios, testamento) y saber lo básico de las herencias.

**Para empezar:** Los papás de Naomi trabajan en Estados Unidos y le mandan dinero a ella y a su abuela. Su abuela tiene una casa sin testamento y no sabe dónde están las escrituras. Naomi quiere ayudar pero no sabe cómo. En esta lección verás qué puedes hacer.

### Lo esencial (5 minutos)

#### Ayudar en casa con reglas

Si aportas dinero en tu casa, platícalo: cuánto das, para qué y cuánto guardas para ti y tu idea. Ayudar con números claros evita pleitos y te deja seguir creciendo.



#### Los papeles de la familia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Una carpeta | Actas, escrituras, pólizas, cuentas. | En un solo lugar. |
| Beneficiarios | En cuentas, Afore y seguros. | Sin juicio. |
| Testamento | Ante notario; en septiembre hay descuentos. | Evita pleitos. |
| Escrituras | ¿A nombre de quién está la casa? | Revisa. |

#### Lo básico de las herencias

Recibir una herencia **no paga ISR** en México, pero sí cuesta pasar una casa a tu nombre (impuesto estatal y notario). Las deudas de quien fallece se pagan con lo que deja; la familia no las paga con su dinero, salvo quien firmó como aval.



#### Un caso en un minuto

Naomi ayudó a su abuela a juntar sus papeles en una carpeta y encontró las escrituras. Su abuela nombró beneficiarios en su cuenta del banco y en septiembre hizo su testamento.

> **Idea clave:** ayuda en casa con números claros; propón una carpeta familiar, beneficiarios y testamento. Heredar no paga ISR, pero escriturar sí cuesta.



#### Comprueba lo que entendiste

1. ¿Qué es la carpeta familiar?
*Respuesta:* Un solo lugar con los papeles importantes de la familia.

2. ¿Se paga ISR por recibir una herencia en México?
*Respuesta:* No.


#### Para recordar

- Ayuda con números claros.
- Carpeta, beneficiarios y testamento.
- Heredar no paga ISR; escriturar sí cuesta.



### Profundiza (5 minutos más)

#### La carpeta familiar

| Papel | ¿Lo tenemos? | ¿Dónde está? |
|---|---|---|
| Actas de nacimiento y matrimonio | | |
| Escrituras de la casa | | |
| Testamento | | |
| Pólizas de seguros | | |
| Datos de cuentas y Afore | | |



#### Si tu familia está en dos países

Si tus papás viven en Estados Unidos y heredan una casa en México, también deben conocer las reglas de allá. Por ejemplo, deben avisar al IRS si una herencia del extranjero pasa de 100,000 dólares. Que lo pregunten a una persona experta.



#### Cuando los abuelos hablan de «pasar la casa»

A veces los abuelos pasan la casa a sus hijos o nietos en vida, pero conservan el derecho a vivir ahí hasta que fallecen. Se llama **usufructo**. Lo importante es que se haga por escrito ante notario, no de palabra.



#### Casos


**Caso 1. La abuela de Naomi**

La abuela de Naomi no tiene testamento ni sabe dónde están sus papeles.
- *¿Qué hace Naomi?* La ayuda a hacer su carpeta y le propone nombrar beneficiarios y hacer testamento.


**Caso 2. El aporte de Santi**

Santi da dinero en su casa pero nunca han hablado de cuánto.
- *¿Qué hace?* Platica en casa cuánto aporta y cuánto guarda para su idea.


**Caso 3. La deuda del tío de Emilio**

Falleció el tío de Emilio y un despacho dice que la familia debe pagar su deuda.
- *¿Qué hace?* Sabe que la deuda se paga con lo que dejó, salvo quien firmó como aval.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Papeles regados | Nadie encuentra nada | Carpeta familiar |
| Sin beneficiarios | Juicios | Nómbrenlos |
| Creer que heredar paga 30% | No escrituran | Pregunten en una notaría |
| Pagar deudas ajenas sin haber firmado | Pierden dinero | Revisen |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Naomi, Santi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué evita que el dinero de una cuenta quede atorado si alguien fallece? a) Nombrar beneficiarios · b) Cambiar la contraseña · c) Sacar todo el dinero
2. ¿Qué mes tiene descuentos para hacer testamento en México? a) Enero · b) Diciembre · c) Septiembre
3. Tu familia hereda una casa. ¿Qué sí cuesta? a) El ISR de la herencia, que es de 30% del valor · b) Pasarla a su nombre ante notario · c) Nada
**Respuestas:** 1-a: se entrega sin juicio. 2-c: Mes del Testamento. 3-b: impuesto estatal y notario.



#### Ponlo en práctica

Pasar una casa a tu nombre cuesta 2% de impuesto sobre 500,000 más 10,000 de notario. ¿Cuánto es en total?
**Respuesta:** 10,000 más 10,000: 20,000.



#### A tu plan

Propón en tu casa hacer la carpeta familiar y llenen juntos la tabla.



### Para saber más

- **Mes del Testamento** (Secretaría de Gobernación · español): https://www.gob.mx — **Qué buscar:** «Mes del Testamento».
- **Beneficiarios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «beneficiarios en cuentas».

### Palabras clave

- *Testamento:* documento ante notario que dice quién recibe los bienes de una persona.
- *Beneficiario:* persona que recibe el dinero de una cuenta, Afore o seguro si el titular fallece.
- *Herencia:* bienes que recibe una persona cuando otra fallece.

### Fuentes

Secretaría de Gobernación · CONDUSEF · SAT · IRS, consultados el 30 de septiembre de 2026.

---


# Parte 9. Módulo 9. Tu futuro y tu plan

## M9 U01. Estudiar, trabajar o emprender: decide con números

**Lo que lograrás:** Comparar caminos después de la prepa (estudiar, trabajar, emprender o combinarlos) pensando en costos, ingresos a futuro y lo que te gusta.

**Para empezar:** Santi termina la prepa este año. Su tío le dice: «Ponte a trabajar ya, estudiar no deja». Su maestra le dice que estudie programación. Él quiere seguir con su negocio de reparaciones. En esta lección decidirá con números.

### Lo esencial (5 minutos)

#### Estudiar también es invertir

Estudiar cuesta tiempo y dinero, pero suele aumentar lo que ganas durante muchos años. Es una inversión en ti. La pregunta es qué estudiar, dónde y cómo pagarlo.



#### Caminos que se pueden combinar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Estudiar | Universidad o técnico. | Becas y escuelas públicas. |
| Trabajar | Ingreso hoy y experiencia. | Puede pagar tus estudios. |
| Emprender | Tu idea como ingreso. | Puedes empezar mientras estudias. |
| Combinar | Estudiar y emprender, o trabajar y estudiar. | Lo más común. |

#### Los números de Santi

- Gana hoy al mes con reparaciones: **3,200**
- Podría ganar de más al mes con estudios de programación (estimado): **4,000**
- Al mes en unos años: **7,200**
Estudiar en una escuela pública con beca y seguir reparando le permite las dos cosas.


#### Un caso en un minuto

Santi eligió una carrera técnica en programación en una escuela pública, pidió una beca y sigue con sus reparaciones los sábados. Su meta: poner un servicio de reparación y desarrollo de apps.

> **Idea clave:** estudiar, trabajar y emprender se pueden combinar. Compara costos, becas e ingresos futuros, y elige algo que te guste y que la gente necesite.



#### Comprueba lo que entendiste

1. ¿Por qué estudiar es una inversión?
*Respuesta:* Porque cuesta hoy pero suele aumentar lo que ganas por años.

2. ¿Se pueden combinar los caminos?
*Respuesta:* Sí, estudiar y emprender o trabajar a la vez.


#### Para recordar

- Estudiar es invertir en ti.
- Busca becas y escuelas públicas.
- Combina caminos.



### Profundiza (5 minutos más)

#### Compara tus caminos

| Pregunta | Camino 1 | Camino 2 |
|---|---|---|
| ¿Cuánto cuesta? | | |
| ¿Hay beca? | | |
| ¿Cuánto podría ganar? | | |
| ¿Me gusta? | | |
| ¿Lo puedo combinar? | | |



#### Si ni estudias ni trabajas a los 18

Jóvenes Construyendo el Futuro te capacita en un centro de trabajo, de los 18 a los 29 años. Te da apoyo mensual y seguro del IMSS por hasta 12 meses.



#### Casos


**Caso 1. El dilema de Santi**

Santi no sabe si estudiar, trabajar o seguir con su negocio.
- *¿Qué hace?* Compara con números y combina estudio y negocio.


**Caso 2. La carrera de Naomi**

Naomi quiere estudiar artes pero le dicen que «no deja».
- *¿Qué hace?* Investiga en qué trabajan quienes estudian eso y cómo puede emprender con sus dibujos.


**Caso 3. La pausa de Emilio**

Emilio termina la prepa y no sabe qué hacer.
- *¿Qué hace?* Revisa opciones como Jóvenes Construyendo el Futuro mientras decide.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decidir sin números | Te arrepientes | Compara |
| Pensar que es uno u otro | Pierdes opciones | Combina |
| No buscar becas | Pagas de más | Busca |
| Elegir solo por dinero | Te aburres | También lo que te gusta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Santi, Naomi y Emilio. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Por qué estudiar se considera una inversión? a) Porque no cuesta nada de tiempo ni de dinero · b) Porque suele subir lo que ganas por años · c) Porque te dan dinero al inscribirte en cualquier escuela
2. ¿Se puede emprender mientras estudias? a) Sí, muchas personas lo combinan · b) No, está prohibido por la ley mientras estudias · c) Solo después de los 30
3. Un técnico te subiría 3,000 al mes y cuesta 20,000 en total. ¿En cuántos meses lo recuperas? a) 3 · b) Unos 7 · c) 20
**Respuestas:** 1-b: invertir en ti. 2-a: es lo más común. 3-b: 20,000 entre 3,000.



#### Ponlo en práctica

Estudiar te costaría 1,500 al mes durante 24 meses y después ganarías 3,500 más al mes. ¿Cuánto inviertes y en cuántos meses lo recuperas?
**Respuesta:** 1,500 por 24: 36,000. Entre 3,500: unos 10 meses.



#### A tu plan

Llena la tabla con dos caminos que te interesen.



### Para saber más

- **Oferta educativa y becas** (Secretaría de Educación Pública · español): https://www.gob.mx/sep — **Qué buscar:** «becas» y «educación superior».
- **Jóvenes Construyendo el Futuro** (STPS · español): https://jovenesconstruyendoelfuturo.stps.gob.mx — **Qué buscar:** requisitos.

### Palabras clave

- *Inversión en ti:* gastar tiempo o dinero en aprender algo que te hará ganar más en el futuro.

### Fuentes

SEP · STPS, consultados el 30 de septiembre de 2026.

---

## M9 U02. Tu primer trabajo formal: contrato, recibo, IMSS y Afore

**Lo que lograrás:** Identificar qué revisar en tu primer trabajo formal (contrato, salario, recibo, IMSS, Afore y derechos) y cómo empezar tu ahorro para el retiro desde joven.

**Para empezar:** Emilio cumplió 18 y le ofrecieron trabajo en una tienda. Le dijeron: «Te pagamos en efectivo y sin papeles, así ganas más». No sabe qué le conviene. En esta lección verás qué implica un trabajo formal.

### Lo esencial (5 minutos)

#### Lo que da un trabajo formal

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Contrato | Qué haces, horario y pago. | Por escrito. |
| IMSS | Médico, incapacidades y riesgos de trabajo. | Desde el primer día. |
| Afore | Ahorro para tu retiro. | El patrón aporta. |
| Prestaciones | Aguinaldo, vacaciones, prima. | Por ley. |

#### «Sin papeles ganas más»

Puede parecer que ganas más, pero pierdes seguro médico, incapacidades, semanas para tu pensión, ahorro de vivienda y prestaciones. Además, sin papeles es difícil reclamar si no te pagan.



#### Tu Afore desde joven

Cuando tengas trabajo formal, se abre tu Afore. Revisa cuál es, nombra beneficiarios y, si puedes, aporta un poco más. Por el interés compuesto, lo que pones a los 18 vale mucho más a los 60.

> **Dato vigente:** el salario mínimo general 2026 es de 315.04 pesos diarios; con el salario mínimo no se retiene ISR. Consultado el 30 de septiembre de 2026 a través de la CONASAMI y la Ley del ISR.



#### Un caso en un minuto

Emilio comparó: la tienda formal le daba IMSS, aguinaldo y Afore. Eligió el trabajo con contrato. En su primer recibo revisó su sueldo, sus descuentos y lo que le llega.

> **Idea clave:** un trabajo formal te da contrato, IMSS, Afore y prestaciones; «sin papeles» parece más, pero pierdes protección y ahorro para tu futuro.



#### Comprueba lo que entendiste

1. ¿Qué te da el IMSS en un trabajo formal?
*Respuesta:* Médico, incapacidades y protección por riesgos de trabajo.

2. ¿Por qué empezar tu Afore joven?
*Respuesta:* Por el interés compuesto, lo que pones joven crece más.


#### Para recordar

- Contrato por escrito.
- IMSS, Afore y prestaciones.
- Revisa tu recibo.



### Profundiza (5 minutos más)

#### Tu primer recibo

| Concepto | Qué revisar |
|---|---|
| Sueldo | Que sea lo acordado |
| Días trabajados | Que estén completos |
| ISR | Solo si ganas más del mínimo |
| IMSS | Tu parte de seguridad social |
| Neto | Lo que te llega |



#### Si algo no está bien

Si no te pagan, te despiden sin razón o te piden trabajar horas sin pago, pide orientación sin costo. Puedes ir a la PROFEDET o a la procuraduría del trabajo de tu estado.



#### Casos


**Caso 1. «Sin papeles ganas más»**

A Emilio le ofrecen trabajo en efectivo y sin papeles.
- *¿Qué hace?* Compara lo que pierde y prefiere un trabajo con contrato e IMSS.


**Caso 2. La Afore de Valeria**

Valeria empieza su primer trabajo formal y no sabe qué es su Afore.
- *¿Qué hace?* La busca con su CURP, nombra beneficiarios y aporta un poco más si puede.


**Caso 3. El recibo de Santi**

El recibo de Santi dice menos días de los que trabajó.
- *¿Qué hace?* Pregunta con su recibo en mano y, si no se corrige, pide orientación en la PROFEDET.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar sin papeles sin comparar | Pierdes protección | Compara |
| No revisar tu recibo | Errores | Revísalo |
| Olvidar tu Afore | Pierdes años de interés | Búscala |
| No pedir orientación | Pierdes lo tuyo | PROFEDET |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Emilio, Valeria y Santi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué pierdes en un trabajo «sin papeles»? a) Nada, porque te pagan más en efectivo cada semana · b) IMSS, Afore y prestaciones · c) Solo el uniforme
2. ¿Con qué buscas tu Afore? a) Con tu CURP · b) Con tu credencial de la escuela · c) Con tu número de celular
3. ¿Quién te orienta sin costo si no te pagan? a) La tienda de la esquina · b) Un gestor · c) La PROFEDET
**Respuestas:** 1-b: pierdes protección. 2-a: te identifica. 3-c: defensa del trabajo.



#### Ponlo en práctica

Ganas 9,600 al mes. Si aportas 2% extra a tu Afore, ¿cuánto pones al mes y al año?
**Respuesta:** 192 al mes; 2,304 al año.



#### A tu plan

Cuando empieces a trabajar formalmente, revisa tu primer recibo con la tabla.



### Para saber más

- **Tus derechos laborales** (PROFEDET · español): https://www.gob.mx/profedet — **Qué buscar:** «derechos de las personas trabajadoras».
- **Tu Afore** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «localiza tu Afore».

### Palabras clave

- *Trabajo formal:* trabajo con contrato, IMSS y prestaciones.
- *Prestaciones:* derechos además del sueldo, como aguinaldo y vacaciones.
- *Afore:* administradora que guarda tu ahorro para el retiro.

### Fuentes

CONASAMI · PROFEDET · CONSAR · IMSS, consultados el 30 de septiembre de 2026.

---

## M9 U03. Tu plan de una página y tu compromiso

**Lo que lograrás:** Reunir en una hoja tu presupuesto, tu idea, tus metas, tu protección y tu camino, con un compromiso con nombre, testigo y recordatorio.

**Para empezar:** Valeria tiene su presupuesto en una nota, su idea en otra, sus metas en su cabeza y su seguro de estudiante ni lo ha activado. Quiere verlo todo junto. En esta lección harás tu plan de una página.

### Lo esencial (5 minutos)

#### Las partes de tu plan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu dinero | Lo que entra y cómo lo repartes. | Módulo 1. |
| Tu idea | Qué vendes, precio y ganancia. | Módulos 3 y 4. |
| Tus metas | Ahorro e inversión. | Módulo 5. |
| Tu protección | Seguro de estudiante, candados, fraudes. | Módulo 7. |
| Tu camino | Estudiar, trabajar o emprender. | Módulo 9. |

#### Revísalo cada mes

Tu plan de una página se revisa en cinco minutos cada mes: ¿aparté para guardar y crear? ¿cómo va mi idea? ¿cuánto me falta para mi meta?



#### Tu compromiso de crecer

Escribe una meta con nombre («Horno para 60 postres por semana»), cuánto apartarás y cada cuándo. Díselo a alguien de confianza que te pregunte cómo vas y pon un recordatorio mensual en tu celular con el nombre de tu meta.



#### Un caso en un minuto

Valeria llenó su plan. Su compromiso: «Horno grande en 3 meses, 400 de cada mes de ganancia». Su hermano es su testigo. Activó su seguro de estudiante y puso candados a su celular.

> **Idea clave:** tu plan en una hoja te dice dónde estás y qué sigue; un compromiso con nombre, testigo y recordatorio te ayuda a crecer.



#### Comprueba lo que entendiste

1. ¿Cada cuándo revisas tu plan?
*Respuesta:* Cada mes.

2. ¿Qué tiene tu compromiso?
*Respuesta:* Meta con nombre, monto, fecha, testigo y recordatorio.


#### Para recordar

- Tu plan en una hoja.
- Revísalo cada mes.
- Meta con nombre, testigo y recordatorio.



### Profundiza (5 minutos más)

#### Tu plan

| Parte | Hoy | Siguiente paso |
|---|---|---|
| Lo que me entra al mes | | |
| Guardar y crear (%) | | |
| Mi idea: precio, costo y ganancia | | |
| Mi meta de ahorro o inversión | | |
| Seguro de estudiante y candados | | |
| Mi camino después de la prepa | | |
| Mi compromiso: meta, monto, fecha y testigo | | |



#### Por qué funciona

Estudios en varios países encontraron que ponerle nombre a una meta, comprometerse con alguien y recibir un recordatorio mensual ayuda a lograrla. Apartar el dinero antes de verlo también ayuda.



#### Casos


**Caso 1. Las notas de Valeria**

Valeria tiene todo en notas sueltas.
- *¿Qué hace?* Llena su plan de una página y lo guarda en su celular.


**Caso 2. El plan de Emilio**

Emilio hizo su plan pero nunca lo vuelve a ver.
- *¿Qué hace?* Pone un recordatorio mensual para revisarlo.


**Caso 3. La contraseña de Naomi**

Naomi quiere anotar sus contraseñas en su plan.
- *¿Qué hace?* No las anota: el plan no lleva datos sensibles.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Todo suelto | No ves el conjunto | Una hoja |
| No revisarlo | Se olvida | Cada mes |
| Datos sensibles | Riesgo | Sin contraseñas ni NIP |
| Meta sin nombre | No motiva | Ponle nombre |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Valeria, Emilio y Naomi. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué ayuda a cumplir una meta? a) Guardarla en secreto para que nadie opine de ella · b) Nombre, testigo y recordatorio · c) Esperar a tener suerte
2. ¿Qué no va en tu plan? a) Tu meta de ahorro · b) Tu idea de negocio · c) Tus contraseñas
3. Tu meta es 3,600 en 6 meses. ¿Cuánto apartas al mes? a) 600 · b) 360 · c) 6,000
**Respuestas:** 1-b: así lo logras. 2-c: son datos sensibles. 3-a: 3,600 entre 6.



#### Ponlo en práctica

Ganas 1,500 al mes con tu idea. Guardas 10%, reinviertes 30% y tu meta es 2,700. ¿En cuántos meses la logras con lo que guardas y reinviertes?
**Respuesta:** 40% de 1,500: 600 al mes. 2,700 entre 600: unos 5 meses (4.5).



#### A tu plan

Llena tu plan de una página, escribe tu compromiso de crecer y pon tu recordatorio mensual.



### Para saber más

- **Tu plan financiero** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «jóvenes» y «plan financiero».

### Palabras clave

- *Plan de una página:* resumen de tus decisiones de dinero en una sola hoja.
- *Testigo:* persona de confianza a quien le cuentas tu meta para que te pregunte cómo vas.

### Fuentes

CONDUSEF · Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera», consultados el 30 de septiembre de 2026.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Idea, Tu Dinero, Tu Futuro** es un programa de bienestar financiero para jóvenes de preparatoria en México, de 15 a 18 años.

Aquí aprenderás que el dinero no es solo para guardarlo: es para crear, probar ideas y hacerlas crecer con cabeza. Harás tu presupuesto, usarás el dinero digital con seguridad, probarás una idea de negocio con poco dinero, pondrás tu dinero a trabajar, entenderás el crédito, te protegerás de fraudes y armarás tu plan para después de la prepa.

Cada lección dura unos 5 minutos y está hecha para el celular.

Versión 1.0 · Septiembre de 2026.

### Cómo está hecho cada módulo

| Parte | Qué encuentras | Tiempo |
|---|---|---|
| **Libro de lecciones** | Cada lección empieza con una portada donde eliges tu ruta. | 5 o 10 minutos |
| **¿Qué harías?** | Tres situaciones para elegir la mejor decisión. | 3 minutos |
| **Autoevaluación del módulo** | Preguntas de todo el módulo. Apruebas con 70% y puedes intentarlo las veces que quieras. | 10 minutos |

### Los personajes

- **Valeria** (16): estudia en un CBTIS, hace postres muy buenos y quiere convertirlos en negocio.
- **Emilio** (17): trabaja los fines de semana en una taquería, quiere una moto y le atraen la cripto y las apuestas.
- **Naomi** (15): dibuja increíble, gasta en compras en línea y juegos; sus papás trabajan en Estados Unidos.
- **Santi** (18): repara celulares en su casa y termina la prepa este año.

### Tres reglas del programa

1. **Nunca te pediremos datos personales**, fotos, ubicación, redes, contraseñas ni códigos.
2. **No te vendemos nada**: ni préstamos, ni cripto, ni cursos para «hacerte rico».
3. **Cuando algo requiere mayoría de edad** (contratos, créditos, inversiones a tu nombre), te lo decimos y te pedimos que lo hagas con un adulto de confianza.

### Los datos cambian

Los datos del programa se consultaron el **30 de septiembre de 2026** y cada uno indica su fuente. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay ocho insignias. Al aprobar las nueve autoevaluaciones recibes la insignia **Plan completo · Tu Idea** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. El mes de Santi (Módulos 1 y 2)

**Datos.** A Santi le entran al mes 950 de beca, 3,200 de reparaciones y 400 de pasajes. Aparta 10% para guardar y 20% para crear. Un cliente le enseña una captura de «ya te transferí».

**Tareas.**

1. ¿Cuánto le entra al mes?
2. ¿Cuánto guarda y cuánto usa para crear?
3. ¿Qué hace con la captura?

**Clave.**

- 4,550.
- Guarda 455 y usa 910 para crear.
- Revisa en su app que el dinero llegó antes de entregar (M2 U02).

### E2. Los postres de Valeria (Módulo 3)

**Datos.** Cada postre le cuesta 19 (ingredientes 14, empaque 3, gas 2) y lo vende a 33. Compró un horno de 800.

**Tareas.**

1. ¿Cuánto gana por postre?
2. ¿Cuántos postres para recuperar el horno?
3. Si vende 60 al mes, ¿cuánto gana?

**Clave.**

- 14.
- 800 entre 14: 58 postres (57.1).
- 60 por 14: 840.

### E3. Los socios de Emilio (Módulo 4)

**Datos.** Emilio y Toño ganan 1,200 al mes. Toño puso 1,500 al inicio. Acuerdan regresarle primero su dinero con 50% de la ganancia y después repartir mitad y mitad.

**Tareas.**

1. ¿Cuánto recibe Toño cada mes hasta recuperar?
2. ¿En cuántos meses recupera?
3. ¿Qué debe decir su acuerdo?

**Clave.**

- 600.
- 1,500 entre 600: 3 meses (2.5).
- Quién pone qué, cómo se reparte, quién hace qué y qué pasa si alguien se sale.

### E4. Las decisiones de Emilio (Módulos 5 y 6)

**Datos.** Emilio quiere una moto de 28,000. Una tienda se la da en 104 semanas de 399. Un video le promete multiplicar su dinero en cripto. Gana 2,800 al mes.

**Tareas.**

1. ¿Cuánto pagaría a crédito y cuánto de más?
2. ¿Cuánto tendría que apartar al mes para juntarla en 20 meses?
3. ¿Qué hace con el video?

**Clave.**

- 41,496; 13,496 de más.
- 1,400 al mes; con 2,800 de ingreso es la mitad: puede ampliar el plazo o buscar una moto más barata.
- Desconfía: le venden algo y el precio también puede caer (M5 U04).

### E5. La familia de Naomi (Módulos 7 y 8)

**Datos.** Naomi estudia en una prepa pública y no ha activado su seguro. Le ofrecen 2,000 a la semana por recibir y pasar depósitos. Su abuela no tiene testamento.

**Tareas.**

1. ¿Cómo activa su seguro de estudiante?
2. ¿Qué es la oferta de los depósitos?
3. ¿Qué le propone a su abuela?

**Clave.**

- Con su NSS entregado a su escuela (M7 U02).
- Una cuenta mula: puede ser delito (M7 U03).
- Una carpeta familiar, beneficiarios y testamento en septiembre (M8 U04).


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U02 | Ganas 840 en 14 horas. ¿Cuánto vale tu hora? |
| P02 | M1 U03 | 89 en un juego 5 veces al mes. ¿Al año? |
| P03 | M1 U04 | Te entran 2,500 al mes; 10% guardar y 20% crear. ¿Cuánto a cada uno? |
| P04 | M2 U03 | 30 dólares a 18.40. ¿Cuánto en pesos? |
| P05 | M3 U03 | Costo 24, precio 40, vendes 50. ¿Ganancia? |
| P06 | M3 U05 | Inviertes 1,500 y ganas 25 por pieza. ¿Piezas para recuperar? |
| P07 | M4 U02 | Ganancia 1,000 repartida 70% y 30%. ¿Cuánto a cada socio? |
| P08 | M5 U02 | 1,000 al 8% anual con interés compuesto. ¿En 3 años? |
| P09 | M6 U01 | 149 por semana durante 52 semanas por algo de 5,000. ¿De más? |
| P10 | M6 U02 | 1,800, 2,400 y 1,200 a 6 meses sin intereses. ¿Pago al mes? |
| P11 | M8 U02 | Algo cuesta 1,250 antes de IVA. ¿Con IVA? |
| P12 | M9 U01 | Un curso de 12,000 te sube 2,000 al mes. ¿En cuántos meses lo recuperas? |

### Respuestas

- P01: 60.
- P02: 5,340.
- P03: 250 y 500.
- P04: 552.
- P05: 800.
- P06: 60.
- P07: 700 y 300.
- P08: unos 1,259.71.
- P09: 7,748 menos 5,000: 2,748.
- P10: 900.
- P11: 1,450.
- P12: 6 meses.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu mente y tu dinero

- **Ganancia:** lo que te queda después de restar lo que gastaste para vender.
- **Habilidad:** algo que sabes hacer bien y que otras personas pueden necesitar.
- **Ingreso:** dinero que recibes por trabajar, vender, invertir o por un apoyo.
- **Mesada:** dinero que te dan en tu casa cada semana o mes.
- **Presión de grupo:** cuando haces algo para encajar con tus amistades.
- **Presupuesto:** plan de cuánto dinero te entra y en qué lo vas a usar.
- **Publicidad:** mensaje pagado para que compres algo.
- **Reinvertir:** volver a usar la ganancia para que tu idea crezca.

### Tu cuenta y el dinero digital

- **CEP:** comprobante de Banco de México que confirma una transferencia.
- **CLABE:** número de 18 dígitos para recibir transferencias.
- **Comisión por conversión:** cargo que cobra tu banco por pagar en otra moneda.
- **Cotitular:** otra persona que comparte la cuenta contigo.
- **IPAB:** seguro que protege tus depósitos en bancos.
- **Suscripción:** servicio que se cobra cada mes o cada año hasta que lo cancelas.
- **Tarjeta de débito:** tarjeta para pagar con tu propio dinero.
- **Tipo de cambio:** cuántos pesos cuesta un dólar u otra moneda en un día.
- **Términos y condiciones:** reglas de un servicio que aceptas al usarlo.

### Crea: de la idea a tu primera venta

- **Anticipo:** parte del pago que da el cliente antes de que hagas el producto.
- **Cliente frecuente:** persona que te compra más de una vez.
- **Costo por pieza:** lo que te cuesta hacer cada producto.
- **Diferencia:** lo que hace que te elijan a ti y no a otra persona.
- **Fiar:** entregar ahora y cobrar después.
- **Idea de negocio:** forma de ganar dinero resolviendo un problema o un deseo.
- **Inventario:** productos que tienes guardados para vender.
- **Margen:** porcentaje de tu precio que es ganancia.
- **Prueba:** forma barata de saber si una idea funciona antes de invertir mucho.
- **Punto de equilibrio:** cantidad que necesitas vender para recuperar lo que invertiste; desde ahí empiezas a ganar.
- **Sueldo fijo:** cantidad que te pagas del negocio cada semana o mes.

### Haz crecer lo que empezaste

- **Aportación:** lo que cada socio pone: dinero, trabajo o herramientas.
- **Derechos de autor:** derechos de quien crea una obra sobre su uso.
- **Flujo:** cuánto dinero entra y sale de tu negocio cada semana.
- **Huella digital:** todo lo que queda de ti en internet: publicaciones, comentarios y fotos.
- **IVA:** impuesto que va incluido en el precio de muchas cosas.
- **Marca:** nombre, logo y estilo que identifican tu negocio.
- **Reserva:** dinero del negocio guardado para meses flojos.
- **RESICO:** régimen de impuestos con ISR bajo para personas con ingresos de hasta 3.5 millones al año.
- **RFC:** Registro Federal de Contribuyentes: tu clave para pagar impuestos y facturar.
- **Socio:** persona que comparte un negocio contigo.

### Pon tu dinero a trabajar

- **Criptomonedas:** monedas digitales sin respaldo de un gobierno cuyo precio sube y baja muchísimo.
- **Diversificar:** repartir tu dinero en varias inversiones para no perderlo todo si una sale mal.
- **Especular:** comprar algo esperando venderlo caro en poco tiempo.
- **Fondo para imprevistos:** dinero guardado para gastos que no esperabas.
- **Inflación:** aumento de los precios con el tiempo.
- **Interés compuesto:** cuando los rendimientos que gana tu dinero también empiezan a ganar rendimientos.
- **Invertir:** poner tu dinero en algo que puede crecer con el tiempo, aceptando algún riesgo.
- **Meta de ahorro:** lo que quieres juntar, cuánto y para cuándo.
- **Pirámide:** esquema en el que ganas por meter a otras personas; tarde o temprano se cae.
- **Rendimiento real:** lo que gana tu dinero después de restar la inflación.
- **Riesgo:** posibilidad de ganar menos o perder.

### Crédito sin trampas

- **Adelanto de sueldo:** recibir antes parte de tu pago, que luego te descuentan.
- **Aval:** persona que firma y paga si quien pidió el crédito no paga.
- **Beca:** apoyo para estudiar que no se paga.
- **CAT:** Costo Anual Total: porcentaje que incluye intereses y comisiones de un crédito en un año.
- **Convocatoria:** anuncio con los requisitos y fechas de un programa o concurso.
- **Crédito:** dinero que te prestan y que devuelves después, casi siempre con intereses.
- **Fecha de corte:** día en que se cierra el periodo de compras de tu tarjeta.
- **Historial de crédito:** registro de tus créditos y de cómo los pagaste.
- **Intereses:** lo que cuesta usar dinero prestado.
- **Pago mínimo:** lo menos que puedes pagar sin atrasarte; la deuda casi no baja.
- **Pago para no generar intereses:** pagar todo lo que gastaste en el periodo.
- **Préstamo de nómina:** crédito del banco donde cobras que se paga con descuentos de tu sueldo.
- **Referencia personal:** persona que solo da sus datos para confirmar que conoce a quien pide un crédito; no firma ni se obliga a pagar.

### Riesgos, protección y fraudes

- **Cuenta mula:** cuenta que alguien presta para recibir y mover dinero de fraudes; quien la presta puede ser acusado de un delito.
- **Extorsión:** cuando alguien te amenaza para que le des dinero o algo más.
- **Identidad digital:** tus cuentas, datos y lo que publicas en internet.
- **Legado digital:** lo que pasa con tus cuentas y archivos si ya no puedes usarlos.
- **NSS:** número de seguridad social que te identifica en el IMSS.
- **Respaldo:** copia de tus archivos en otro lugar.
- **Seguro de salud para estudiantes:** seguro del IMSS para estudiantes de escuelas públicas de nivel medio superior y superior; no tiene costo.
- **Verificación en dos pasos:** un código extra además de tu contraseña para entrar a tu cuenta.

### El sistema, la economía y tu familia

- **Beneficiario:** persona que recibe el dinero de una cuenta, Afore o seguro si el titular fallece.
- **CNBV:** autoridad que vigila a los bancos y otras instituciones financieras.
- **CONDUSEF:** autoridad que defiende a las personas usuarias de servicios financieros.
- **Folio:** número que te dan al reclamar y que sirve de prueba.
- **Herencia:** bienes que recibe una persona cuando otra fallece.
- **Impuestos:** dinero que pagamos al gobierno para cubrir servicios públicos.
- **ISR:** impuesto sobre lo que ganas.
- **Rumor:** información sin fuente que circula sin verificar.
- **Tasa de interés:** porcentaje que pagan los ahorros o cobran los créditos.
- **Testamento:** documento ante notario que dice quién recibe los bienes de una persona.

### Tu futuro y tu plan

- **Afore:** administradora que guarda tu ahorro para el retiro.
- **Inversión en ti:** gastar tiempo o dinero en aprender algo que te hará ganar más en el futuro.
- **Plan de una página:** resumen de tus decisiones de dinero en una sola hoja.
- **Prestaciones:** derechos además del sueldo, como aguinaldo y vacaciones.
- **Testigo:** persona de confianza a quien le cuentas tu meta para que te pregunte cómo vas.
- **Trabajo formal:** trabajo con contrato, IMSS y prestaciones.


## Dónde encontrar ayuda

Todas las opciones de esta tabla son oficiales y sin costo. Información consultada el 30 de septiembre de 2026; confírmala en el sitio oficial.

| Necesidad | Dónde | Qué verificar |
|---|---|---|
| Saber si una institución financiera existe | SIPRES de la CONDUSEF | Nombre exacto |
| Reclamar a un banco o una app | Unidad de atención y CONDUSEF: 55 5340 0999 u 800 999 8080 | Folio |
| Compras en línea y garantías | PROFECO | Contrato y ticket |
| Fraudes, cuentas mula y amenazas en línea | 088 y policía cibernética de tu estado | Capturas |
| Tu seguro de estudiante | IMSS (app IMSS Digital) y tu escuela | Tu NSS |
| Becas | Programas para el Bienestar | Registro sin costo |
| Programas para jóvenes | Instituto Mexicano de la Juventud y el de tu estado | Convocatorias |
| Capacitación con apoyo (18 a 29 años) | Jóvenes Construyendo el Futuro (STPS) | Requisitos |
| Tus derechos si trabajas | PROFEDET | Orientación sin costo |
| Tu RFC (a los 18) | SAT | Trámite sin costo |
| Invertir desde 100 pesos (mayores de edad) | Cetesdirecto | Sitio oficial |
| Apuestas que se salen de control | Línea de la Vida (800 911 2000) y Centros de Integración Juvenil | Atención sin costo |
| Apoyo emocional | Línea de la Vida: 800 911 2000 | 24 horas |
| Emergencias | 911 | Riesgo inmediato |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados.

**¿El curso me presta dinero o me recomienda inversiones?** No. Te enseña a comparar, a verificar y a crear con lo que tienes.

**¿Necesito tener un negocio para tomar el curso?** No. Puedes probar una idea chiquita o solo aprender a hacerlo.

**¿Mis papás o mi escuela ven mis respuestas?** Las autoevaluaciones se califican en la plataforma; las encuestas son anónimas. Nunca se piden datos personales ni financieros.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una acreditación oficial.


## Referencias

Fuentes que usamos en el curso, consultadas el 30 de septiembre de 2026.

### Instituciones

- **I01** CONDUSEF: cuentas, SIPRES, simuladores, cuentas mula, montadeudas y reclamaciones.
- **I02** Banco de México: inflación, tipo de cambio, CEP y criptoactivos.
- **I03** IPAB: seguro de depósitos.
- **I04** PROFECO: compras en línea, suscripciones y garantías.
- **I05** INEGI: inflación (INPC).
- **I06** SAT: RFC con CURP, RESICO, IVA y herencias.
- **I07** IMSS: Seguro de Salud para Estudiantes y NSS.
- **I08** STPS y PROFEDET: trabajo adolescente, derechos laborales y Jóvenes Construyendo el Futuro.
- **I09** Programas para el Bienestar: Beca Benito Juárez.
- **I10** Instituto Mexicano de la Juventud: emprendimiento y convocatorias.
- **I11** Cetesdirecto: inversión desde 100 pesos.
- **I12** Buró de Crédito y Círculo de Crédito: reportes sin costo.
- **I13** Secretaría de Gobernación: Mes del Testamento y juegos y sorteos.
- **I14** CONASAMA: Línea de la Vida. Centros de Integración Juvenil.

### Leyes

- **L01** Ley Federal del Trabajo: trabajo de personas de 15 a 17 años.
- **L02** Ley del Impuesto sobre la Renta: artículo 93 (herencias) y retenciones.
- **L03** Ley Federal de Protección al Consumidor.

### Marcos y estudios

- **E01** OCDE, marco de competencias financieras para jóvenes (2015).
- **E02** Innovations for Poverty Action y J-PAL, «Nudges para una óptima salud financiera».


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Mente que crea: el dinero no es solo para guardarlo

**Caso 1. La alcancía de Valeria.** Valeria tiene 1,500 guardados y quiere empezar a vender postres. **¿Qué hace?**

- ✔ Deja una base guardada y prueba con una parte.
- Usa los 1,500 completos para empezar en grande de una vez.
- Sigue guardando todo hasta tener muchísimo más dinero.

**Caso 2. El ahorro de Emilio.** Emilio guarda todo lo que gana en la taquería en su cajón desde hace un año. **¿Qué hace?**

- ✔ Piensa qué aprender o crear con una parte y guarda el resto en una cuenta.
- Lo sigue guardando en el cajón de su cuarto porque ahí nadie lo toca.
- Se lo gasta todo porque de todos modos pierde valor.

**Caso 3. El miedo de Naomi.** Naomi quiere vender dibujos, pero le da miedo perder su dinero. **¿Qué hace?**

- ✔ Empieza con poco para probar y aprende de lo que salga.
- No vende nada hasta estar segura de que no va a perder.
- Pide prestado para empezar con mucho material de golpe.

## M1 U02. ¿De dónde sale el dinero? Tus fuentes de ingreso

**Caso 1. La hora de Emilio.** Emilio gana 43 por hora en la taquería y quiere ganar más. **¿Qué hace?**

- ✔ Aprende una habilidad que otras personas necesiten.
- Pide más horas en la taquería aunque deje la escuela.
- Deja la taquería de golpe para buscar algo mejor sin plan.

**Caso 2. El horario de Naomi.** Le ofrecen a Naomi, de 15, trabajar de 7 de la noche a 2 de la mañana. **¿Qué hace?**

- ✔ No acepta: a su edad la ley prohíbe el trabajo nocturno.
- Acepta porque le pagan bien y nadie se va a enterar.
- Acepta solo los fines de semana para no faltar a la escuela.

**Caso 3. Los clientes de Santi.** Santi tiene más reparaciones de las que puede hacer. **¿Qué hace?**

- ✔ Sube un poco su precio y ordena sus horarios.
- Acepta todo y deja de dormir para terminar a tiempo.
- Deja de aceptar clientes nuevos sin decirles por qué.

## M1 U03. Influencers, antojos y presión: quién decide tus compras

**Caso 1. Los tenis de Naomi.** Naomi ve unos tenis con código de descuento «solo hoy». **¿Qué hace?**

- ✔ Los pone en su lista y espera 7 días.
- Los compra ya porque el código se acaba hoy en la noche.
- Pide dinero prestado a una amiga para no perder la oferta.

**Caso 2. Las skins de Emilio.** Emilio gasta en skins casi cada fin de semana. **¿Qué hace?**

- ✔ Suma lo que gasta al mes y se pone un límite.
- Sigue igual porque cada compra es de menos de 100 pesos.
- Usa la tarjeta de su mamá para no gastar su propio dinero.

**Caso 3. La salida de Valeria.** Sus amigas quieren ir a un lugar caro y Valeria está ahorrando para su negocio. **¿Qué hace?**

- ✔ Propone un plan más barato o va otro día.
- Va y paga con su ahorro del negocio para no quedar mal.
- Deja de salir con sus amigas para siempre para ahorrar.

## M1 U04. Tu presupuesto: mesada, beca y lo que ganas

**Caso 1. El fin de mes de Santi.** Santi no sabe cuánto tiene y a fin de mes le falta. **¿Qué hace?**

- ✔ Anota un mes lo que entra y sale, y reparte el día que cobra.
- Sigue igual y pide prestado cuando le falta a fin de mes.
- Deja de reparar celulares porque de todos modos no le alcanza.

**Caso 2. La beca de Valeria.** Valeria recibe su beca y se la gasta en la primera semana. **¿Qué hace?**

- ✔ Divide la beca entre los dos meses y aparta primero.
- Se la gasta rápido porque en dos meses llega otra.
- Le da toda la beca a una amiga para que se la guarde.

**Caso 3. El dinero de Naomi.** Los papás de Naomi le mandan dinero cada mes desde Estados Unidos. **¿Qué hace?**

- ✔ Lo incluye en su presupuesto y aparta para guardar y crear.
- Se lo gasta completo porque es un regalo de sus papás.
- Lo deja en la cuenta y no revisa nunca cuánto le queda al final de cada mes.

## M2 U01. Tu primera cuenta

**Caso 1. La caja de zapatos de Valeria.** Valeria guarda lo que vende en una caja y cree que no puede tener cuenta. **¿Qué hace?**

- ✔ Va al banco con su mamá y abre una cuenta sin comisiones.
- Sigue guardando en la caja porque cree que no puede tener cuenta.
- Le pide a una amiga mayor que guarde el dinero en su cuenta.

**Caso 2. La app de Emilio.** Una app le ofrece a Emilio «cuenta con rendimientos altísimos». **¿Qué hace?**

- ✔ Revisa en el SIPRES qué institución es y si tiene protección.
- Mete todo su ahorro de una vez porque los rendimientos que anuncian son muy altos.
- Mete poquito para probar sin revisar qué empresa es.

**Caso 3. La tarjeta de Santi.** Le ofrecen a Santi, que acaba de cumplir 18, una tarjeta de crédito al abrir su cuenta. **¿Qué hace?**

- ✔ Empieza con débito y aprende primero cómo funciona el crédito.
- Acepta la tarjeta de crédito y la usa para lo que quiera.
- Acepta la tarjeta de crédito y se la presta a su hermano para que también la use.

## M2 U02. Pagar y cobrar con el celular

**Caso 1. El «ya te transferí».** Un cliente le enseña a Santi una captura: «ya te transferí». **¿Qué hace?**

- ✔ Revisa en su app que el dinero llegó antes de entregar.
- Entrega el celular porque la captura se ve muy real.
- Entrega y le pide al cliente que le avise si hay problema.

**Caso 2. El error de Naomi.** Naomi mandó 300 a la cuenta equivocada. **¿Qué hace?**

- ✔ Avisa a su banco de inmediato y verifica el nombre la próxima vez.
- No dice nada porque cree que el dinero regresará solo.
- Busca a la persona en redes sociales y le escribe para pedirle que se lo regrese.

**Caso 3. El depósito de Emilio.** Alguien le depositó a Emilio 2,000 «por error» y le pide devolverlos a otra cuenta. **¿Qué hace?**

- ✔ No devuelve nada a otra cuenta y avisa a su banco.
- Devuelve el dinero rápido a la cuenta que le dieron.
- Se queda con el dinero porque se lo depositaron a él.

## M2 U03. Compras en línea y dinero de otro país

**Caso 1. La sudadera de Naomi.** Naomi ve una sudadera de 25 dólares en una tienda extranjera. **¿Qué hace?**

- ✔ Calcula el total en pesos con envío y comisión.
- La compra porque 25 dólares parece poco dinero.
- La compra sin revisar el envío porque ya la quiere.

**Caso 2. Los tenis baratísimos de Emilio.** Emilio ve unos tenis de marca a 300 pesos en una página que no conoce. **¿Qué hace?**

- ✔ Desconfía, revisa opiniones y no paga con depósito a una persona.
- Los compra rápido antes de que se acaben en la página.
- Deposita a la cuenta de la persona que vende para apartar sus tenis hoy mismo.

**Caso 3. El envío de los papás de Naomi.** A Naomi le llegan distintos pesos cada mes aunque le mandan los mismos dólares. **¿Qué hace?**

- ✔ Entiende el tipo de cambio y compara servicios de envío.
- Cree que sus papás le están mandando menos cada mes.
- Pide que le manden en efectivo por medio de un conocido.

## M2 U04. Las letras chiquitas: términos, suscripciones y contratos

**Caso 1. La prueba de Emilio.** Emilio aceptó una prueba sin costo y le cobran cada mes. **¿Qué hace?**

- ✔ La cancela y pone recordatorios antes de cada cobro.
- La sigue pagando cada mes porque cancelarla se ve muy complicado en la app.
- Cambia su tarjeta para que ya no le puedan cobrar.

**Caso 2. El préstamo para Valeria.** Una app le ofrece a Valeria, de 16, un préstamo para su negocio con solo aceptar términos. **¿Qué hace?**

- ✔ No acepta: siendo menor no debería firmar un préstamo.
- Acepta porque el dinero le ayudaría a crecer su negocio.
- Acepta con los datos de su mamá sin decirle nada a ella.

**Caso 3. Los datos de Naomi.** Una app de juegos pide acceso a los contactos y fotos de Naomi. **¿Qué hace?**

- ✔ Lee qué hace con sus datos y niega los permisos que no necesita.
- Acepta todos los permisos porque si no, no puede jugar con sus amigos en línea.
- Acepta y luego borra sus fotos del celular por si acaso.

## M3 U01. Encuentra un problema que valga la pena resolver

**Caso 1. El negocio de Santi.** Santi quiere poner un negocio pero no sabe de qué. **¿Qué hace?**

- ✔ Anota durante una semana problemas reales a su alrededor.
- Pone lo primero que se le ocurra para empezar ya mismo sin preguntar a nadie.
- Pide un préstamo para abrir un local y ver qué vende.

**Caso 2. La moda de Emilio.** Emilio quiere vender lo que está de moda porque «todos lo venden». **¿Qué hace?**

- ✔ Busca qué haría distinto o un problema que nadie resuelva.
- Vende exactamente lo mismo que todos, al mismo precio y en el mismo lugar.
- Vende lo mismo pero más barato aunque pierda dinero.

**Caso 3. Los dibujos de Naomi.** Naomi dibuja muy bien pero cree que eso no es negocio. **¿Qué hace?**

- ✔ Busca quién necesita dibujos: invitaciones, logos o regalos.
- Deja de dibujar porque cree que eso no deja dinero.
- Regala sus dibujos a quien se los pida para darse a conocer.

## M3 U02. Prueba tu idea con poco dinero

**Caso 1. La máquina de Emilio.** Emilio quiere comprar una máquina de 6,000 para empezar. **¿Qué hace?**

- ✔ Prueba primero con 10 piezas por pedido.
- Compra la máquina porque así ganará más desde el inicio.
- Pide prestado para comprar la máquina y 50 termos de una vez.

**Caso 2. Los postres de Valeria.** Valeria no sabe si sus postres se venderían a 35. **¿Qué hace?**

- ✔ Pregunta a 10 compañeros y prueba vender 20.
- Hace 200 postres de una vez para ver si se venden.
- Pone el precio que se le ocurre sin preguntar a nadie.

**Caso 3. La prueba que no salió.** Naomi vendió solo 2 de 10 separadores de libros. **¿Qué hace?**

- ✔ Pregunta qué mejorar y prueba otra vez con un cambio.
- Deja de vender porque cree que su idea no sirve para nada.
- Hace 50 separadores más para ver si ahora sí se venden.

## M3 U03. Costo, precio y ganancia

**Caso 1. El mes de Valeria.** Valeria vendió 1,800 y creyó que ganó 1,800. **¿Qué hace?**

- ✔ Resta todos sus costos para saber su ganancia real.
- Se gasta los 1,800 porque cree que todo es ganancia.
- Sube el precio al doble sin calcular nada primero.

**Caso 2. El precio de Santi.** Santi cobra 150 por cambiar una mica y no sabe si gana. **¿Qué hace?**

- ✔ Suma la mica, sus herramientas y su tiempo para calcular.
- Sigue cobrando igual porque sus clientes están contentos.
- Baja su precio a 100 para tener todavía más clientes.

**Caso 3. La competencia de Emilio.** Otro vendedor ofrece termos más baratos que Emilio. **¿Qué hace?**

- ✔ Revisa sus costos y destaca su diferencia antes de bajar precio.
- Baja su precio a la mitad aunque pierda dinero en cada termo que vende.
- Deja de vender termos porque el otro vende más barato.

## M3 U04. Tus primeras ventas: redes, cobro y clientes

**Caso 1. La dirección de Naomi.** Un cliente le pide a Naomi su dirección para pasar por el pedido. **¿Qué hace?**

- ✔ No la da; entrega en un lugar público con un adulto.
- Le da su dirección porque el cliente se ve amable.
- Le pide que pase a su escuela a la hora de la salida.

**Caso 2. El fiado de Valeria.** Un compañero le pide a Valeria que le fíe 5 postres hasta la próxima semana. **¿Qué hace?**

- ✔ Le pide pagar antes o al entregar.
- Le fía porque es su compañero y seguro le paga.
- Le fía y le cobra intereses si se tarda en pagarle.

**Caso 3. El cliente molesto de Santi.** Un cliente se queja porque la mica quedó con burbujas. **¿Qué hace?**

- ✔ Escucha, la cambia y agradece que se lo dijera.
- Le dice que así quedan todas las micas y no le cambia nada al cliente.
- Lo bloquea para que no deje malos comentarios.

## M3 U05. Punto de equilibrio y el dinero del negocio aparte

**Caso 1. Las herramientas de Santi.** Santi no sabe cuándo recuperará lo que invirtió. **¿Qué hace?**

- ✔ Divide la inversión entre la ganancia por reparación.
- Espera a ver si algún día recupera lo que invirtió, sin hacer ninguna cuenta.
- Compra más herramientas para recuperar más rápido.

**Caso 2. El dinero revuelto de Valeria.** Valeria usa el dinero de los postres para sus salidas y luego no tiene para ingredientes. **¿Qué hace?**

- ✔ Separa el dinero del negocio y se paga un sueldo fijo.
- Sigue usando el mismo dinero y pide prestado para ingredientes.
- Deja de salir con sus amigas para no gastar nada.

**Caso 3. La primera ganancia de Emilio.** Emilio ya recuperó lo que invirtió y quiere gastarse todo lo que sigue. **¿Qué hace?**

- ✔ Se paga su sueldo y reinvierte una parte para crecer.
- Se gasta todo porque ya recuperó lo que había puesto.
- Guarda todo en su cajón y ya no invierte en el negocio.

## M4 U01. Reinvertir: que tu ganancia trabaje

**Caso 1. Los tenis o el horno.** Valeria duda entre comprarse tenis o un horno más grande. **¿Qué hace?**

- ✔ Reparte su ganancia: su sueldo y una parte para el horno.
- Se compra los tenis con toda la ganancia del mes.
- Pide prestado para el horno y se compra los tenis también.

**Caso 2. El préstamo de Emilio.** Emilio quiere pedir prestado para crecer rápido. **¿Qué hace?**

- ✔ Crece primero con reinversión de su propia ganancia.
- Pide un préstamo en una app para crecer en un solo mes.
- Pide prestado a varios amigos sin decirles para qué es.

**Caso 3. El mes flojo de Santi.** En vacaciones Santi casi no tiene reparaciones y no puede comprar piezas. **¿Qué hace?**

- ✔ Usa su reserva y la vuelve a llenar cuando mejora.
- Pide prestado para comprar piezas aunque no tenga clientes.
- Cierra el negocio porque en vacaciones no hay trabajo.

## M4 U02. Socios y equipo: acuerdos claros entre amigos

**Caso 1. El pleito de Emilio y Toño.** Emilio y Toño discuten cómo repartir la ganancia. **¿Qué hacen?**

- ✔ Escriben un acuerdo con lo que puso cada uno y cómo se reparte.
- Se reparten lo que cada uno crea justo cada mes.
- Dejan de ser socios y hasta dejan de hablarse para ya no pelear por el dinero.

**Caso 2. El nuevo socio de Valeria.** Una amiga quiere entrar al negocio de postres de Valeria. **¿Qué hace?**

- ✔ Acuerdan por escrito qué pone cada una y cómo se reparte.
- La deja entrar de palabra porque son amigas desde niñas y confían una en la otra.
- La deja entrar y le da la mitad sin que ponga nada.

**Caso 3. El que se sale.** Un amigo de Santi quiere salirse del negocio y llevarse las herramientas. **¿Qué hace?**

- ✔ Revisan su acuerdo: se lleva su parte según lo escrito.
- Le deja llevarse todo para no perder la amistad.
- No le deja llevarse nada aunque haya puesto herramientas.

## M4 U03. Tu marca, tu reputación y tus datos en línea

**Caso 1. La cuenta de Naomi.** Naomi vende desde su cuenta personal con fotos de su casa. **¿Qué hace?**

- ✔ Abre una cuenta solo para el negocio, sin datos personales.
- Sigue vendiendo desde su cuenta porque tiene más seguidores.
- Pone su dirección para que los clientes pasen a recoger.

**Caso 2. El comentario grosero.** Un cliente deja un comentario grosero en la publicación de Valeria. **¿Qué hace?**

- ✔ Responde con respeto y ofrece una solución.
- Le contesta igual de grosero para que aprenda a respetar.
- Borra todos los comentarios negativos de su publicación.

**Caso 3. Los personajes de Emilio.** Emilio quiere vender termos con personajes de una caricatura famosa. **¿Qué hace?**

- ✔ Crea sus propios diseños para no usar marcas sin permiso.
- Usa los personajes porque todos los venden así.
- Usa los personajes famosos y solo les cambia un poco el color y el tamaño.

## M4 U04. Crecer en serio: RFC, permisos e impuestos cuando toque

**Caso 1. La factura de Santi.** Una tienda le pide factura a Santi, que ya tiene 18. **¿Qué hace?**

- ✔ Tramita su RFC sin costo y elige el RESICO.
- Rechaza el trabajo porque cree que le quitarán todo en impuestos.
- Le pide a un amigo que facture por él a cambio de una parte.

**Caso 2. El gestor de Emilio.** Un gestor le ofrece a Emilio sacarle el RFC por 800. **¿Qué hace?**

- ✔ No paga: el trámite en el SAT no tiene costo.
- Paga los 800 porque así no tiene que hacer nada.
- Le da su CURP y contraseña al gestor para que lo haga.

**Caso 3. Los postres en la escuela.** Valeria, de 16, quiere vender postres en su escuela. **¿Qué hace?**

- ✔ Pide permiso en la escuela y cuida la higiene.
- Vende a escondidas para que nadie le diga nada.
- Vende sin cuidar la higiene porque son solo postres.

## M5 U01. Ahorra con propósito

**Caso 1. El ahorro de Naomi.** Naomi se gasta su ahorro en lo primero que ve. **¿Qué hace?**

- ✔ Le pone nombre, monto y fecha a su meta y aparta primero.
- Sigue ahorrando lo que le sobra al final de cada semana.
- Deja de ahorrar porque de todos modos se lo acaba gastando.

**Caso 2. La moto de Emilio.** Emilio no sabe cuánto tardaría en juntar para la moto. **¿Qué hace?**

- ✔ Divide el precio entre los meses y aparta cada semana.
- Pide la moto a crédito para tenerla desde este mes.
- Espera a ver si algún día le alcanza para la moto, sin hacer ninguna cuenta.

**Caso 3. El celular roto de Santi.** A Santi se le rompió el celular y no tenía nada guardado. **¿Qué hace?**

- ✔ Junta primero un pequeño fondo para imprevistos.
- Pide prestado cada vez que algo se le descompone.
- Usa el dinero de su negocio para comprar otro celular.

## M5 U02. El interés compuesto y tu mejor aliado: el tiempo

**Caso 1. Santi y su primo.** Santi puede empezar a invertir 500 al mes a los 18. **¿Qué hace?**

- ✔ Empieza ya, aunque sea con poco, porque el tiempo multiplica.
- Espera a tener un buen trabajo en unos años para empezar con más dinero.
- Espera a los 30 como su primo porque es más seguro.

**Caso 2. El colchón de Emilio.** Emilio guarda sus ahorros en su casa por años. **¿Qué hace?**

- ✔ Busca una opción regulada que pague más que la inflación.
- Lo sigue guardando en su casa por años porque cree que ahí no se pierde nada.
- Lo mete a una app que promete duplicarlo en un mes.

**Caso 3. El rendimiento de Valeria.** Una inversión le paga 5% a Valeria y la inflación es 4%. **¿Qué hace?**

- ✔ Sabe que su rendimiento real es cerca de 1% y compara.
- Cree que gana 5% y no revisa nada más.
- Saca todo su dinero de la inversión porque cree que está perdiendo muchísimo.

## M5 U03. Invertir: riesgo, rendimiento y no poner todo junto

**Caso 1. El 20% al mes.** A Valeria le ofrecen ganar 20% al mes en una app. **¿Qué hace?**

- ✔ Desconfía: esas ganancias no existen y verifica la institución.
- Mete sus 3,000 completos para aprovechar la oferta antes de que se acabe.
- Mete poquito para probar y luego mete todo su ahorro.

**Caso 2. Todo en una sola cosa.** Emilio quiere poner todo su ahorro en una sola acción que vio en redes. **¿Qué hace?**

- ✔ Reparte su dinero y deja su fondo aparte.
- Pone todo en esa acción porque en redes dicen que va a subir.
- Pide prestado para comprar más acciones de esa empresa.

**Caso 3. La cuenta de Santi.** Santi ya cumplió 18 y quiere empezar a invertir poco. **¿Qué hace?**

- ✔ Abre su cuenta en una plataforma regulada desde 100 pesos.
- Espera a tener 50 mil pesos juntos para empezar a invertir cualquier cosa.
- Le da su dinero a un amigo que dice saber invertir.

## M5 U04. Cripto, trading, «hazte rico» y apuestas: invertir no es apostar

**Caso 1. El video de cripto.** Emilio vio un video de alguien que multiplicó su dinero en una semana. **¿Qué hace?**

- ✔ Desconfía: el precio también puede caer y le venden algo.
- Mete todos sus ahorros de la moto en cripto para multiplicarlos en una semana.
- Compra el curso del video para aprender a ganar igual.

**Caso 2. Las apuestas de Emilio.** Emilio perdió 1,800 apostando y quiere recuperarlo apostando más. **¿Qué hace?**

- ✔ Deja de apostar y busca ayuda.
- Apuesta más para recuperar lo que perdió este mes.
- Pide prestado a un amigo para seguir apostando.

**Caso 3. El grupo de Naomi.** A Naomi la invitan a un grupo donde «ganas por meter a tus amigas». **¿Qué hace?**

- ✔ No entra: es una pirámide.
- Entra y mete a sus amigas para ganar primero.
- Entra con poquito para ver si de verdad pagan.

## M6 U01. Qué es el crédito y cuánto cuesta de verdad

**Caso 1. La laptop de Santi.** Le ofrecen a Santi una laptop a 399 por semana durante un año. **¿Qué hace?**

- ✔ Calcula el total, lo compara con el contado y decide juntar.
- Se la lleva hoy porque 399 a la semana casi no se siente.
- Le pide a su mamá que firme el crédito para llevársela hoy sin revisar el total.

**Caso 2. Los tenis a crédito de Naomi.** Naomi quiere unos tenis a meses en la tarjeta de su hermana. **¿Qué hace?**

- ✔ Sabe que es un gusto del momento y ahorra para comprarlos.
- Los compra a meses con la tarjeta de su hermana sin decirle.
- Los compra a meses porque así casi no se nota el gasto.

**Caso 3. La herramienta de Valeria.** Valeria podría duplicar su producción con una batidora de 2,500 a crédito. **¿Qué hace?**

- ✔ Compara el CAT y revisa si su ganancia extra paga las cuotas.
- La compra a crédito sin revisar el CAT porque la necesita para su negocio.
- No la compra nunca porque cree que todo crédito es malo.

## M6 U02. Tarjeta de crédito, meses sin intereses y «compra ahora, paga después»

**Caso 1. El mínimo de la hermana de Naomi.** La hermana de Naomi paga solo el mínimo y su deuda no baja. **¿Qué hace?**

- ✔ Deja de usar la tarjeta y paga más del mínimo cada mes.
- Sigue pagando el mínimo porque así le alcanza para todo.
- Saca otra tarjeta para pagar la primera cada mes.

**Caso 2. Los 4 pagos de Naomi.** A Naomi se le pasó un pago de la app de «compra ahora, paga después». **¿Qué hace?**

- ✔ Paga cuanto antes y pone las fechas en su calendario.
- Espera al siguiente mes para pagar los dos pagos juntos cuando le llegue dinero.
- Deja de pagar porque ya le cobraron el recargo.

**Caso 3. Los meses de Emilio.** Emilio quiere comprar tres cosas a meses sin intereses a la vez. **¿Qué hace?**

- ✔ Suma cuánto pagaría al mes y revisa si le alcanza.
- Las compra todas porque no le cobran intereses.
- Las compra todas juntas y después ve cómo le hace para pagarlas cada mes.

## M6 U03. Tu historial desde joven y lo que nunca firmas por otros

**Caso 1. La moto del amigo de Santi.** Un amigo le pide a Santi que sea su aval. **¿Qué hace?**

- ✔ Dice que no puede firmar una deuda que no podría pagar.
- Firma porque es su amigo y seguro le va a pagar.
- Firma y le pide que le dé las cuotas a él para pagarlas.

**Caso 2. La llamada a Valeria.** Un despacho le llama a Valeria para cobrarle la deuda de una vecina de la que solo es referencia. **¿Qué hace?**

- ✔ No paga y sabe que puede reportar al despacho.
- Paga para que ya no le llamen a ella ni a su familia.
- Paga la mitad para que el despacho la deje en paz.

**Caso 3. La primera tarjeta de Santi.** Santi quiere empezar su historial. **¿Qué hace?**

- ✔ Usa una tarjeta poco y paga el total cada mes.
- Pide tres tarjetas para tener más historial rápido.
- Usa todo el límite para que vean que sí la usa.

## M6 U04. Pagar tus estudios o tu idea: antes que un préstamo

**Caso 1. El técnico de Emilio.** Una app le ofrece a Emilio prestarle 18,000 en 5 minutos para su técnico. **¿Qué hace?**

- ✔ Busca primero escuelas públicas y becas.
- Acepta el préstamo porque se lo dan en 5 minutos.
- Pide el préstamo con los datos de su mamá sin decirle.

**Caso 2. Los 5,000 de Valeria.** Valeria quiere 5,000 para crecer su negocio. **¿Qué hace?**

- ✔ Busca concursos para jóvenes y crece con su reinversión.
- Pide un préstamo en una app para crecer este mismo mes.
- Pide prestado a varios compañeros sin decirles para qué.

**Caso 3. El préstamo del tío.** El tío de Santi le ofrece prestarle para herramientas. **¿Qué hace?**

- ✔ Acepta con un acuerdo por escrito de cuánto y cuándo paga.
- Acepta de palabra porque es su tío, lo quiere mucho y no quiere ofenderlo.
- Acepta y le paga cuando le sobre algo de dinero.

## M6 U05. Adelantos de sueldo y préstamos de nómina en tu primer trabajo

**Caso 1. Los tenis.** La app le cobra a Emilio 49 pesos por adelantarle cada semana. **¿Qué hace?**

- ✔ Aparta cada semana y compra los tenis sin deber.
- Usa la app cada semana porque 49 pesos casi no se notan.
- Pide adelantos en la app y en la taquería para comprarlos ya.

**Caso 2. El préstamo preaprobado.** A Santi, en su primer trabajo, el banco le ofrece 15,000 de préstamo de nómina. **¿Qué hace?**

- ✔ Pregunta el total y cuántos meses le descontarán.
- Lo acepta porque ya está preaprobado y no pide papeles.
- Lo acepta completo para comprarse un celular nuevo.

**Caso 3. El adelanto de palabra.** A Valeria le adelantaron dinero en la cafetería donde ayuda y no sabe cuánto le van a descontar. **¿Qué hace?**

- ✔ Pide por escrito cuánto le descuentan y cuántos pagos faltan.
- Deja que le descuenten lo que quieran para no incomodar a nadie.
- Pide otro adelanto para no sentir el descuento.

## M7 U01. Identifica tus riesgos antes de que pasen

**Caso 1. La mochila de Santi.** Santi carga herramientas y celulares de clientes en la misma mochila. **¿Qué hace?**

- ✔ Los separa, los anota y los guarda en un lugar seguro.
- Sigue cargando todo junto porque así lo tiene a la mano.
- Deja de recibir celulares de clientes para no arriesgarse.

**Caso 2. El celular de Naomi.** Naomi tiene todos sus dibujos solo en su celular. **¿Qué hace?**

- ✔ Los respalda en la nube.
- Los deja solo en el celular porque nunca se le ha perdido.
- Toma capturas de pantalla de todos sus dibujos.

**Caso 3. La cocina de Valeria.** Valeria cocina con prisa y ya se quemó una vez. **¿Qué hace?**

- ✔ Ordena su cocina, cocina con cuidado y guarda un pequeño fondo.
- Sigue cocinando rápido para hacer más postres cada día.
- Deja de vender postres para siempre porque le da miedo volver a quemarse.

## M7 U02. Tu seguro de estudiante y otros seguros

**Caso 1. El tobillo de Emilio.** Emilio se lastimó y su familia pagó un consultorio privado. **¿Qué hace para la próxima?**

- ✔ Activa su seguro de estudiante con su NSS en la escuela.
- Contrata un seguro médico privado caro por si vuelve a pasar.
- Espera a lastimarse otra vez para ver qué hace.

**Caso 2. El seguro del celular de Naomi.** En la tienda le ofrecen a Naomi un seguro para su celular. **¿Qué hace?**

- ✔ Compara el costo con el valor del celular y lo que cubre.
- Lo contrata porque el vendedor dice que todos lo compran.
- Lo contrata sin leer porque solo son 99 al mes.

**Caso 3. La prepa privada de Santi.** El primo de Santi estudia en una prepa privada. **¿Qué hace?**

- ✔ Revisa si tiene otra cobertura, porque el seguro de estudiante es de escuela pública.
- Da por hecho que también tiene seguro de estudiante y no revisa nada más.
- Paga un gestor para que lo den de alta como estudiante.

## M7 U03. Fraudes que buscan jóvenes: cuentas mula, falsos empleos y amenazas

**Caso 1. El «trabajo» de Emilio.** Le ofrecen a Emilio 2,000 a la semana por recibir y pasar depósitos. **¿Qué hace?**

- ✔ No acepta, bloquea y avisa: es una cuenta mula.
- Acepta solo unas semanas para juntar para su moto.
- Acepta pero usa la cuenta de su hermano en lugar de la suya.

**Caso 2. El sorteo de Naomi.** A Naomi le avisan que ganó un celular y debe pagar 350 de envío. **¿Qué hace?**

- ✔ No paga: nadie cobra por darte un premio.
- Paga el envío porque el celular vale mucho más.
- Manda sus datos para ver si de verdad ganó algo.

**Caso 3. La amenaza a Valeria.** Alguien amenaza a Valeria con publicar una foto si no le paga. **¿Qué hace?**

- ✔ No paga, guarda capturas, bloquea, avisa a un adulto y denuncia.
- Paga lo que le piden para que no publiquen nada y no se entere nadie.
- Borra todo y no le cuenta a nadie por vergüenza.

## M7 U04. Tu identidad digital y tus contraseñas

**Caso 1. La contraseña de Naomi.** Naomi usa la misma contraseña para todo. **¿Qué hace?**

- ✔ Pone contraseñas distintas y largas en sus cuentas importantes.
- Sigue usando la misma contraseña en todo porque así no se le olvida nunca.
- Cambia la contraseña por su fecha de nacimiento.

**Caso 2. El código de Emilio.** Alguien le pide a Emilio «el código que te llegó» para recuperar su cuenta. **¿Qué hace?**

- ✔ No lo da y activa la verificación en dos pasos.
- Lo da porque se lo pide un contacto de su lista.
- Lo da y luego cambia su foto de perfil por si acaso.

**Caso 3. Los papeles de la familia de Valeria.** Los papás de Valeria no saben dónde están sus papeles importantes. **¿Qué hace?**

- ✔ Les propone hacer una carpeta y platicar dónde está todo.
- No dice nada porque le da miedo hablar de eso.
- Guarda ella sola los papeles en su cuarto sin decirle a nadie de la familia.

## M8 U01. Quién es quién en el sistema financiero y quién te protege

**Caso 1. La comisión de Valeria.** A Valeria le cobraron una comisión que no reconoce y no le resuelven. **¿Qué hace?**

- ✔ Reclama con folio y, si no le resuelven, acude a la CONDUSEF.
- Se resigna y no reclama porque cree que en ningún lado la van a escuchar.
- Deja de pagar su cuenta para que le hagan caso.

**Caso 2. La financiera nueva de Emilio.** Emilio vio una financiera nueva que presta a jóvenes. **¿Qué hace?**

- ✔ La busca en el SIPRES antes de dar sus datos.
- Manda sus datos porque la publicidad se ve muy profesional.
- Le pregunta a un amigo si ya le prestaron ahí.

**Caso 3. La garantía de Naomi.** Una tienda no quiere cambiarle a Naomi unos audífonos con garantía. **¿Qué hace?**

- ✔ Presenta su queja en la PROFECO.
- Deja un comentario enojado en redes y ya.
- Compra otros audífonos en otra tienda sin reclamar.

## M8 U02. Impuestos: de dónde salen tu escuela y tu beca

**Caso 1. «Yo no pago impuestos».** Emilio cree que como estudiante no paga impuestos. **¿Qué aprende?**

- ✔ Que paga IVA en lo que compra.
- Que de verdad no paga nada porque es estudiante.
- Que solo pagan impuestos las personas muy ricas.

**Caso 2. El precio de Valeria.** Valeria vende a una tienda que le pide precio con IVA. **¿Qué hace?**

- ✔ Calcula el 16% y lo suma a su precio.
- Pone el mismo precio y paga el IVA de su ganancia.
- Le dice a la tienda que ella no cobra impuestos.

**Caso 3. La nómina de Santi.** En su primer recibo, Santi ve descuentos que no entiende. **¿Qué hace?**

- ✔ Revisa su recibo: ISR si gana más del mínimo, IMSS y su neto.
- Cree que le robaron y renuncia al trabajo.
- No pregunta nada a nadie para no parecer que no sabe leer su recibo.

## M8 U03. Economía, noticias y rumores: lo que cambia tu dinero

**Caso 1. El dólar a 30.** Naomi ve un mensaje: el dólar llegará a 30 mañana. **¿Qué hace?**

- ✔ Revisa el tipo de cambio en el Banco de México sin pánico.
- Cambia todos sus pesos a dólares hoy mismo.
- Reenvía el mensaje a todos sus contactos y grupos para avisarles del dólar.

**Caso 2. El azúcar de Valeria.** Subió el precio del azúcar y a Valeria le quedan menos ganancias. **¿Qué hace?**

- ✔ Recalcula su costo y ajusta un poco su precio.
- Sigue igual aunque ahora gane menos por postre.
- Sube su precio al doble para no volver a perder.

**Caso 3. El 50% de Emilio.** Emilio escucha que los precios subieron 50%. **¿Qué hace?**

- ✔ Busca la inflación oficial del INEGI.
- Lo cree y deja de comprar cosas que necesita.
- Lo cree y compra todo lo que puede antes de que suba.

## M8 U04. Tu familia y el dinero: ayudar, sus papeles y lo que se hereda

**Caso 1. La abuela de Naomi.** La abuela de Naomi no tiene testamento ni sabe dónde están sus papeles. **¿Qué hace Naomi?**

- ✔ La ayuda a hacer su carpeta y le propone beneficiarios y testamento.
- No dice nada porque le da pena hablar de testamentos y papeles con su abuela.
- Guarda las escrituras en su cuarto sin decirle a nadie.

**Caso 2. El aporte de Santi.** Santi da dinero en su casa pero nunca han hablado de cuánto. **¿Qué hace?**

- ✔ Platica en casa cuánto aporta y cuánto guarda para su idea.
- Da todo lo que gana sin decir nada para no pelear.
- Deja de aportar en su casa porque necesita todo el dinero para su negocio.

**Caso 3. La deuda del tío de Emilio.** Falleció el tío de Emilio y un despacho dice que la familia debe pagar su deuda. **¿Qué hace?**

- ✔ Sabe que la deuda se paga con lo que dejó, salvo quien firmó como aval.
- Paga con su dinero la deuda del tío para que ya no molesten a su familia.
- Paga la mitad para que el despacho los deje en paz.

## M9 U01. Estudiar, trabajar o emprender: decide con números

**Caso 1. El dilema de Santi.** Santi no sabe si estudiar, trabajar o seguir con su negocio. **¿Qué hace?**

- ✔ Compara con números y combina estudio y negocio.
- Deja de estudiar porque su tío dice que estudiar no deja.
- Deja su negocio para estudiar y no hacer nada más.

**Caso 2. La carrera de Naomi.** Naomi quiere estudiar artes pero le dicen que «no deja». **¿Qué hace?**

- ✔ Investiga en qué trabajan y cómo emprender con sus dibujos.
- Estudia una carrera que no le gusta nada solo porque dicen que deja más dinero.
- Deja de dibujar porque todos dicen que no deja.

**Caso 3. La pausa de Emilio.** Emilio termina la prepa y no sabe qué hacer. **¿Qué hace?**

- ✔ Revisa opciones como Jóvenes Construyendo el Futuro mientras decide.
- Se queda en su casa un año sin buscar nada.
- Acepta el primer trabajo sin papeles ni contrato que le ofrezcan en su colonia.

## M9 U02. Tu primer trabajo formal: contrato, recibo, IMSS y Afore

**Caso 1. «Sin papeles ganas más».** A Emilio le ofrecen trabajo en efectivo y sin papeles. **¿Qué hace?**

- ✔ Compara lo que pierde y prefiere un trabajo con contrato e IMSS.
- Acepta que le paguen en efectivo y sin papeles porque así le queda más dinero hoy.
- Acepta sin papeles y piensa formalizarse algún día.

**Caso 2. La Afore de Valeria.** Valeria empieza su primer trabajo formal y no sabe qué es su Afore. **¿Qué hace?**

- ✔ La busca con su CURP, nombra beneficiarios y aporta si puede.
- No le hace caso porque el retiro está muy lejos.
- No le hace caso a su Afore y retira lo que pueda en cuanto le dejen para gastarlo.

**Caso 3. El recibo de Santi.** El recibo de Santi dice menos días de los que trabajó. **¿Qué hace?**

- ✔ Pregunta con su recibo y pide orientación si no se corrige.
- No dice nada para no tener problemas con su jefe.
- Deja de ir a trabajar sin avisarle a nadie para que así le paguen lo que falta.

## M9 U03. Tu plan de una página y tu compromiso

**Caso 1. Las notas de Valeria.** Valeria tiene todo en notas sueltas. **¿Qué hace?**

- ✔ Llena su plan de una página y lo guarda en su celular.
- Sigue con sus notas sueltas porque así ya se acostumbró.
- Hace un plan de 20 páginas que nunca termina.

**Caso 2. El plan de Emilio.** Emilio hizo su plan pero nunca lo vuelve a ver. **¿Qué hace?**

- ✔ Pone un recordatorio mensual para revisarlo.
- Lo guarda en un cajón porque ya lo hizo una vez.
- Lo rehace completo cada semana desde el principio.

**Caso 3. La contraseña de Naomi.** Naomi quiere anotar sus contraseñas en su plan. **¿Qué hace?**

- ✔ No las anota: el plan no lleva datos sensibles.
- Las anota al final para no olvidarlas nunca.
- Las anota al revés para que nadie las entienda.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Qué es poner el dinero a trabajar?

- Esconderlo en tu cuarto para no gastarlo
- Gastarlo en lo que se te antoje
- ✔ Usarlo para generar más

*¡Correcto! Es la idea de crecer.*

**M1 U01 P2.** Antes de probar una idea, ¿qué haces?

- Pides prestado para empezar en grande
- ✔ Apartas una base para imprevistos
- Usas todo lo que tienes

*¡Correcto! Crear con cabeza.*

**M1 U01 P3.** Inviertes 600 en material y vendes 1,500. ¿Cuánto ganas?

- 1,500
- 2,100
- ✔ 900

*¡Correcto! Ventas menos material.*

**M1 U02 P1.** Ganas 900 en 12 horas. ¿Cuánto vale tu hora?

- 108
- 900
- ✔ 75

*¡Correcto! 900 entre 12.*

**M1 U02 P2.** ¿Cuántas horas al día puede trabajar alguien de 16 años?

- Las que le pidan en el trabajo
- ✔ Máximo 6
- Máximo 10

*¡Correcto! La ley pone ese límite.*

**M1 U02 P3.** ¿Qué sube el valor de tu hora?

- Trabajar más horas sin descansar los fines de semana
- Cobrar menos que los demás
- ✔ Aprender una habilidad que se necesita

*¡Correcto! Te pagan más por saber.*

**M1 U03 P1.** Gastas 79 en un juego 6 veces al mes. ¿Cuánto al año?

- 474
- ✔ 5,688
- 948

*¡Correcto! 474 al mes por 12.*

**M1 U03 P2.** ¿Por qué un código de descuento de influencer no es opinión neutral?

- Porque es muy famoso y tiene millones de seguidores
- Porque siempre miente
- ✔ Porque le pagan si compras

*¡Correcto! Gana con tu compra.*

**M1 U03 P3.** ¿Qué haces con una oferta «solo hoy»?

- Compras antes de que se acabe
- Pides prestado
- ✔ Esperas y comparas

*¡Correcto! La prisa es el truco.*

**M1 U04 P1.** Recibes 1,900 de beca cada dos meses. ¿Cuánto es al mes?

- 1,900
- 3,800
- ✔ 950

*¡Correcto! 1,900 entre 2.*

**M1 U04 P2.** ¿Qué apartas primero cuando cobras?

- Lo de las salidas del fin de semana
- Lo de gustos y antojos
- ✔ Lo de guardar y crear

*¡Correcto! Primero tú y tu idea.*

**M1 U04 P3.** Te entran 3,000 al mes. ¿Cuánto es 20% para crear?

- ✔ 600
- 300
- 2,000

*¡Correcto! 20% de 3,000.*

## Módulo 2

**M2 U01 P1.** Tienes 16 años. ¿Cómo abres una cuenta?

- No puedes hasta los 21
- Solo por internet sin nadie
- ✔ Con tu mamá, papá o tutor

*¡Correcto! Te acompañan.*

**M2 U01 P2.** ¿Qué pasa si pagas con débito y no tienes saldo?

- Te prestan
- ✔ No pasa el pago
- Te cobran intereses

*¡Correcto! Usas tu dinero.*

**M2 U01 P3.** ¿Qué protege tus depósitos en un banco?

- La tienda donde compras
- Tu escuela
- ✔ El IPAB

*¡Correcto! Seguro de depósitos.*

**M2 U02 P1.** ¿Qué haces antes de entregar lo que vendiste?

- Aceptas la captura que te enseña el cliente en su celular
- ✔ Revisas en tu app que llegó el dinero
- Confías en su palabra

*¡Correcto! Una captura se falsifica.*

**M2 U02 P2.** ¿Qué dato NO das para cobrar?

- Tu CLABE
- Tu QR
- ✔ Tu NIP

*¡Correcto! Es secreto.*

**M2 U02 P3.** Te depositan «por error» y te piden devolver a otra cuenta. ¿Qué haces?

- Lo devuelves rápido
- Te lo quedas
- ✔ Avisas a tu banco

*¡Correcto! Puede ser fraude.*

**M2 U03 P1.** Algo cuesta 40 dólares y el dólar está a 18. ¿Cuánto es en pesos?

- ✔ 720
- 58
- 400

*¡Correcto! 40 por 18.*

**M2 U03 P2.** ¿Qué forma de pago es más riesgosa en línea?

- Tarjeta de débito o crédito
- ✔ Depósito a la cuenta de una persona
- Pago en una plataforma con protección

*¡Correcto! No puedes reclamar.*

**M2 U03 P3.** ¿Dónde te quejas si una tienda en México no cumple?

- En tu escuela
- En el banco
- ✔ En la PROFECO

*¡Correcto! Protege al consumidor.*

**M2 U04 P1.** ¿Qué significa dar clic en «Acepto»?

- Nada importante, es solo un trámite
- ✔ Aceptas un contrato
- Que ya pagaste

*¡Correcto! Es un contrato.*

**M2 U04 P2.** Pagas 99 al mes por una app que no usas. ¿Cuánto al año?

- 99
- 990
- ✔ 1,188

*¡Correcto! 99 por 12.*

**M2 U04 P3.** ¿Qué haces antes de que termine una prueba sin costo?

- ✔ Decides si la quieres y cancelas si no
- Esperas a que te cobren
- Das la tarjeta de otra persona para que le cobren a ella

*¡Correcto! Evitas cobros.*

## Módulo 3

**M3 U01 P1.** ¿Por dónde empieza una buena idea de negocio?

- Por lo que está de moda en redes
- ✔ Por un problema real
- Por un préstamo grande

*¡Correcto! Los negocios resuelven problemas.*

**M3 U01 P2.** ¿Qué une una buena idea?

- ✔ Lo que sabes y lo que alguien pagaría
- Lo que venden tus amigos del salón en el recreo
- Lo más caro que puedas vender

*¡Correcto! Tu ventaja y la necesidad.*

**M3 U01 P3.** Hay otra persona vendiendo lo mismo en tu escuela. ¿Qué haces?

- Te rindes y mejor no vendes nada
- Copias igual
- ✔ Buscas tu diferencia

*¡Correcto! Más rápido, cerca o personalizado.*

**M3 U02 P1.** ¿Cuál es la forma más barata de probar una idea?

- Comprar mucho inventario
- Rentar un local
- ✔ Preguntar a 10 personas

*¡Correcto! Cuesta cero.*

**M3 U02 P2.** Tu prueba vendió 2 de 10. ¿Qué haces?

- ✔ Cambias algo y pruebas otra vez
- Pides un préstamo para anunciarte
- Te rindes para siempre

*¡Correcto! El error enseña.*

**M3 U02 P3.** ¿Qué es un anticipo?

- Un regalo del cliente
- ✔ Una parte del pago antes de hacer el producto
- Una deuda con el banco que pagas cada mes con intereses

*¡Correcto! Te asegura el pedido.*

**M3 U03 P1.** Vendes 40 pulseras a 50 y cada una te cuesta 22. ¿Cuánto ganas?

- 2,000
- ✔ 1,120
- 880

*¡Correcto! 40 por 28.*

**M3 U03 P2.** ¿Qué es la ganancia?

- ✔ Lo que te queda después de costos
- Todo lo que cobraste en el mes por tus ventas
- Lo que te prestan para empezar

*¡Correcto! Ventas menos costos.*

**M3 U03 P3.** Tu costo es 20 y vendes a 32. ¿Cuánto ganas por pieza?

- 52
- ✔ 12
- 20

*¡Correcto! 32 menos 20.*

**M3 U04 P1.** Siendo menor, ¿dónde conviene entregar un pedido?

- En tu casa
- Donde diga el cliente
- ✔ En un lugar público con un adulto

*¡Correcto! Por tu seguridad.*

**M3 U04 P2.** ¿Qué pones en tu publicación?

- ✔ Foto, precio claro y cómo pedir
- Tu dirección y tus horarios para que te encuentren
- El nombre de tu escuela

*¡Correcto! Sin datos personales.*

**M3 U04 P3.** Un cliente se queja con razón. ¿Qué haces?

- Lo bloqueas de todas tus redes
- ✔ Escuchas y lo arreglas
- Lo ignoras

*¡Correcto! Así vuelve.*

**M3 U05 P1.** Inviertes 1,200 y ganas 40 por pieza. ¿Cuántas piezas para recuperar?

- 40
- ✔ 30
- 1,200

*¡Correcto! 1,200 entre 40.*

**M3 U05 P2.** ¿Qué haces con el dinero del negocio?

- Lo mezclas con el tuyo
- Lo gastas cada fin de semana con tus amigos del salón
- ✔ Lo separas y te pagas un sueldo fijo

*¡Correcto! Así sabes si ganas.*

**M3 U05 P3.** Ya recuperaste tu inversión. ¿Qué haces con la ganancia?

- ✔ Te pagas tu sueldo y reinviertes una parte
- Lo gastas todo
- Cierras el negocio porque ya ganaste lo que querías

*¡Correcto! Así crece.*

## Módulo 4

**M4 U01 P1.** Ganas 1,000; te pagas 400 y guardas 150 de reserva. ¿Cuánto reinviertes?

- ✔ 450
- 1,000
- 550

*¡Correcto! 1,000 menos 550.*

**M4 U01 P2.** ¿Qué hace crecer tu negocio sin deudas?

- Gastar la ganancia en ti
- ✔ Reinvertir una parte
- Pedir prestado

*¡Correcto! Tu ganancia trabaja.*

**M4 U01 P3.** ¿Para qué es la reserva del negocio?

- ✔ Para meses flojos
- Para salir con amigos
- Para prestar a clientes

*¡Correcto! Te protege.*

**M4 U02 P1.** ¿Cuándo conviene escribir el acuerdo con tu socio?

- Cuando haya problemas
- ✔ Antes de empezar
- Nunca, son amigos

*¡Correcto! Evita pleitos.*

**M4 U02 P2.** ¿Qué cuenta como aportación al negocio?

- Solo el dinero que cada quien puso al inicio
- Solo las horas de trabajo
- ✔ Dinero, trabajo y herramientas

*¡Correcto! Todo suma.*

**M4 U02 P3.** Ganan 900 y acordaron 60% y 40%. ¿Cuánto le toca a cada uno?

- ✔ 540 y 360
- 450 y 450
- 600 y 300

*¡Correcto! 60% de 900 y el resto.*

**M4 U03 P1.** ¿Qué publicas en la cuenta de tu negocio?

- ✔ Fotos de tus productos
- Tu dirección para que te encuentren fácil
- Fotos de tu escuela

*¡Correcto! Sin datos personales.*

**M4 U03 P2.** Te dejan una crítica. ¿Qué haces?

- Respondes enojado
- Bloqueas a todos los que opinen algo negativo
- ✔ Respondes con respeto y una solución

*¡Correcto! Da confianza.*

**M4 U03 P3.** ¿Puedes usar personajes de caricaturas famosas sin permiso?

- Sí, si los dibujas tú
- ✔ No, son de otra persona
- Sí, siempre que vendas poquito y no te vean

*¡Correcto! Tienen dueño.*

**M4 U04 P1.** ¿Qué es el RFC?

- ✔ Tu clave para pagar impuestos y facturar
- Una tarjeta del banco
- Un permiso de la escuela para vender en el recreo y en los eventos

*¡Correcto! Te identifica ante el SAT.*

**M4 U04 P2.** ¿Cuánto cuesta tramitar el RFC en el SAT?

- 800 con gestor
- Depende del estado
- ✔ No tiene costo

*¡Correcto! Lo haces tú.*

**M4 U04 P3.** ¿Qué impuesto va dentro del precio de muchas cosas que compras?

- El RESICO
- ✔ El IVA
- El RFC

*¡Correcto! Está en el precio.*

## Módulo 5

**M5 U01 P1.** Quieres 4,800 en 12 meses. ¿Cuánto apartas al mes?

- 480
- ✔ 400
- 1,200

*¡Correcto! 4,800 entre 12.*

**M5 U01 P2.** ¿Qué tiene una meta clara?

- Solo las ganas de lograrla
- Un número que suene bonito
- ✔ Qué, cuánto y cuándo

*¡Correcto! Así sabes qué hacer.*

**M5 U01 P3.** ¿Cuál ahorro conviene tener primero?

- ✔ Un fondo para imprevistos
- Para la fiesta de fin de año
- Ninguno

*¡Correcto! Te protege.*

**M5 U02 P1.** Tu dinero gana 9% y la inflación es 4%. ¿Rendimiento real aproximado?

- 13%
- ✔ 5%
- 9%

*¡Correcto! 9 menos 4.*

**M5 U02 P2.** ¿Qué es lo que más hace crecer el interés compuesto?

- ✔ El tiempo
- Revisar tu saldo diario
- Cambiar de banco cada mes

*¡Correcto! Mientras más tiempo, más crece.*

**M5 U02 P3.** 1,000 al 10% anual con interés compuesto. ¿Cuánto hay en 2 años?

- 1,200
- 1,100
- ✔ 1,210

*¡Correcto! 1,100 y luego 1,210.*

**M5 U03 P1.** ¿Qué inversión suele tener menos riesgo?

- Acciones de una empresa nueva
- ✔ Bonos del gobierno
- Una app que paga 20% al mes

*¡Correcto! Son del gobierno.*

**M5 U03 P2.** ¿Qué es diversificar?

- ✔ Repartir en varias inversiones
- Poner todo en la que más rendimiento promete
- Cambiar de banco cada año

*¡Correcto! Te protege.*

**M5 U03 P3.** Te prometen ganancias altísimas y seguras. ¿Qué es?

- Una gran oportunidad
- Una inversión normal
- ✔ Señal de fraude

*¡Correcto! No existen.*

**M5 U04 P1.** ¿Cuál es apostar?

- ✔ Jugar en una casa de apuestas
- Comprar bonos del gobierno en Cetesdirecto cada mes
- Reinvertir en tu negocio

*¡Correcto! Es azar.*

**M5 U04 P2.** Te invitan a ganar por meter amigos. ¿Qué es?

- Un negocio normal
- Una inversión segura
- ✔ Una pirámide

*¡Correcto! Ganas por meter gente.*

**M5 U04 P3.** ¿Pueden los menores apostar en casas de apuestas en México?

- Sí, con permiso
- ✔ No
- Solo en línea

*¡Correcto! Está prohibido.*

## Módulo 6

**M6 U01 P1.** Pagas 250 por semana durante 40 semanas por algo de 7,000. ¿Cuánto pagas de más?

- ✔ 3,000
- 10,000
- 250

*¡Correcto! 10,000 menos 7,000.*

**M6 U01 P2.** Entre dos créditos, ¿cuál es más barato?

- El de CAT más alto
- ✔ El de CAT más bajo
- El de cuota más chica

*¡Correcto! Cuesta menos.*

**M6 U01 P3.** ¿Para qué conviene más un crédito?

- ✔ Para algo que te ayuda a ganar y puedes pagar
- Para ropa de moda que viste en tus redes sociales esta semana
- Para una fiesta

*¡Correcto! Te ayuda a crecer.*

**M6 U02 P1.** ¿Qué pago de la tarjeta evita intereses?

- El mínimo que aparece en tu estado de cuenta
- ✔ El total del mes
- Ninguno

*¡Correcto! Pagas todo lo del mes.*

**M6 U02 P2.** Compras tres cosas a 6 meses sin intereses: 1,200, 1,800 y 3,000. ¿Cuánto pagas al mes?

- ✔ 1,000
- 6,000
- 600

*¡Correcto! 6,000 entre 6.*

**M6 U02 P3.** ¿Qué pasa si te atrasas en una app de «paga después»?

- Nada
- Te regalan el pago
- ✔ Te cobran recargo

*¡Correcto! Y pueden reportarte.*

**M6 U03 P1.** ¿A quién NO puede cobrar un despacho?

- Al aval
- Al obligado solidario que firmó el contrato completo
- ✔ A la referencia personal

*¡Correcto! Solo dio sus datos.*

**M6 U03 P2.** ¿Cómo se construye un buen historial?

- ✔ Pagando a tiempo
- Pidiendo muchos créditos
- Usando todo tu límite

*¡Correcto! Es lo más importante.*

**M6 U03 P3.** Tu límite es 4,000. ¿Cuánto es 30%?

- 400
- ✔ 1,200
- 3,000

*¡Correcto! 30% de 4,000.*

**M6 U04 P1.** ¿Qué buscas primero para pagar tus estudios?

- Un préstamo en app
- ✔ Becas y apoyos
- Una tarjeta de crédito

*¡Correcto! No se pagan.*

**M6 U04 P2.** ¿Para quién es Jóvenes Construyendo el Futuro?

- ✔ De 18 a 29 años que no estudian ni trabajan
- Menores de 15
- Solo universitarios con promedio de nueve o más en su carrera

*¡Correcto! Requisitos del programa.*

**M6 U04 P3.** Tu tío te presta 3,000. ¿Qué hacen?

- Todo de palabra
- Nada, porque es familia y confían en ti
- ✔ Un acuerdo por escrito

*¡Correcto! Evita pleitos.*

**M6 U05 P1.** ¿Qué es un adelanto de sueldo?

- Un regalo del trabajo
- ✔ Tu mismo sueldo, antes
- Un bono

*¡Correcto! Luego te lo descuentan.*

**M6 U05 P2.** 35 pesos de comisión cada semana. ¿Cuánto es al año?

- ✔ 1,820
- 420
- 35

*¡Correcto! 35 × 52.*

**M6 U05 P3.** ¿Qué preguntas antes de un préstamo de nómina?

- Si es rápido
- Si te dan más
- ✔ El total a pagar y cuántos meses te descuentan

*¡Correcto! Así sabes cuánto cuesta.*

## Módulo 7

**M7 U01 P1.** ¿Qué es transferir un riesgo?

- ✔ Contratar un seguro
- Olvidarte del riesgo
- Pasárselo a un amigo

*¡Correcto! Pagas poco para no perder mucho.*

**M7 U01 P2.** ¿Cómo reduces el riesgo de perder tus fotos?

- Con más fotos en el celular
- ✔ Con un respaldo en la nube
- Borrando todo

*¡Correcto! Si pierdes el celular, lo conservas.*

**M7 U01 P3.** ¿Qué forma de manejar un riesgo es guardar dinero?

- Evitar
- Transferirlo a una aseguradora
- ✔ Tener un fondo

*¡Correcto! Para imprevistos.*

**M7 U02 P1.** ¿Cuánto cuesta el seguro de salud del IMSS para estudiantes de escuelas públicas?

- Una cuota mensual
- ✔ No tiene costo
- Depende de tu promedio

*¡Correcto! Es sin costo.*

**M7 U02 P2.** ¿Qué necesitas para activarlo?

- ✔ Tu NSS entregado a tu escuela
- Una tarjeta de crédito a tu nombre y la de tus papás
- Un gestor

*¡Correcto! La escuela te da de alta.*

**M7 U02 P3.** ¿Qué revisas antes de contratar un seguro?

- Solo el color de la póliza
- Lo que te dice el vendedor de la tienda sobre el precio
- ✔ Si ya tienes algo que te cubra

*¡Correcto! Evitas pagar doble.*

**M7 U03 P1.** Te ofrecen pagar por recibir depósitos y pasarlos. ¿Qué es?

- ✔ Una cuenta mula
- Un trabajo normal
- Una inversión

*¡Correcto! Mueve dinero de fraudes.*

**M7 U03 P2.** ¿Qué haces si te amenazan con publicar algo tuyo?

- Pagas para que no lo publiquen
- ✔ No pagas y pides ayuda
- Mandas lo que pidan

*¡Correcto! No es tu culpa.*

**M7 U03 P3.** Un empleo te pide 500 para «capacitación». ¿Qué es?

- Un trámite normal de cualquier empresa
- Una oportunidad
- ✔ Una señal de engaño

*¡Correcto! Nadie serio cobra por contratarte.*

**M7 U04 P1.** ¿Cuál contraseña es más fuerte?

- 123456
- Tu fecha de nacimiento con el nombre de tu mascota
- ✔ Una frase larga con números

*¡Correcto! Es larga y difícil.*

**M7 U04 P2.** ¿Qué haces si alguien te pide el código que te llegó?

- ✔ No lo das
- Lo das si es tu amigo
- Lo publicas

*¡Correcto! Es la llave de tu cuenta.*

**M7 U04 P3.** ¿Qué protege tu cuenta aunque roben tu contraseña?

- Un fondo de pantalla
- ✔ La verificación en dos pasos
- Tener más seguidores y amigos en tus redes sociales

*¡Correcto! Pide un código extra.*

## Módulo 8

**M8 U01 P1.** ¿Quién cuida el valor del peso y la inflación?

- La PROFECO
- ✔ El Banco de México
- Tu escuela y la dirección de la prepa

*¡Correcto! Es su trabajo.*

**M8 U01 P2.** ¿Dónde verificas si una financiera existe?

- ✔ En el SIPRES de la CONDUSEF
- En sus anuncios de redes
- Preguntando a tus amigos del salón si la conocen

*¡Correcto! Registro oficial.*

**M8 U01 P3.** Una tienda no respeta tu garantía. ¿A dónde acudes?

- Al banco donde tienes tu cuenta
- A la CNBV
- ✔ A la PROFECO

*¡Correcto! Defiende al consumidor.*

**M8 U02 P1.** Algo cuesta 500 antes de IVA. ¿Cuánto pagas con IVA de 16%?

- 516
- ✔ 580
- 800

*¡Correcto! 500 más 80.*

**M8 U02 P2.** ¿Qué pagas al comprar casi cualquier cosa?

- El predial
- ✔ El IVA
- El ISR

*¡Correcto! Va en el precio.*

**M8 U02 P3.** ¿Para qué sirven los impuestos?

- ✔ Para pagar servicios públicos
- Para los bancos
- Para las tiendas y las empresas que venden productos

*¡Correcto! Escuelas, becas, hospitales.*

**M8 U03 P1.** ¿Quién publica el tipo de cambio oficial?

- Un influencer de finanzas
- ✔ El Banco de México
- Tu banco nada más

*¡Correcto! Fuente oficial.*

**M8 U03 P2.** Suben los precios. ¿Qué pasa con tu dinero?

- ✔ Compra menos
- Compra más
- No cambia

*¡Correcto! Es la inflación.*

**M8 U03 P3.** ¿Qué señal tiene un rumor?

- ✔ Pide que actúes ya y no tiene fuente
- Tiene fecha y fuente oficial
- Está publicado en el sitio del INEGI con fecha y datos

*¡Correcto! Prisa y sin fuente.*

**M8 U04 P1.** ¿Qué evita que el dinero de una cuenta quede atorado si alguien fallece?

- ✔ Nombrar beneficiarios
- Cambiar la contraseña
- Sacar todo el dinero

*¡Correcto! Se entrega sin juicio.*

**M8 U04 P2.** ¿Qué mes tiene descuentos para hacer testamento en México?

- Enero
- Diciembre
- ✔ Septiembre

*¡Correcto! Mes del Testamento.*

**M8 U04 P3.** Tu familia hereda una casa. ¿Qué sí cuesta?

- El ISR de la herencia, que es de 30% del valor
- ✔ Pasarla a su nombre ante notario
- Nada

*¡Correcto! Impuesto estatal y notario.*

## Módulo 9

**M9 U01 P1.** ¿Por qué estudiar se considera una inversión?

- Porque no cuesta nada de tiempo ni de dinero
- ✔ Porque suele subir lo que ganas por años
- Porque te dan dinero al inscribirte en cualquier escuela

*¡Correcto! Invertir en ti.*

**M9 U01 P2.** ¿Se puede emprender mientras estudias?

- ✔ Sí, muchas personas lo combinan
- No, está prohibido por la ley mientras estudias
- Solo después de los 30

*¡Correcto! Es lo más común.*

**M9 U01 P3.** Un técnico te subiría 3,000 al mes y cuesta 20,000 en total. ¿En cuántos meses lo recuperas?

- 3
- ✔ Unos 7
- 20

*¡Correcto! 20,000 entre 3,000.*

**M9 U02 P1.** ¿Qué pierdes en un trabajo «sin papeles»?

- Nada, porque te pagan más en efectivo cada semana
- ✔ IMSS, Afore y prestaciones
- Solo el uniforme

*¡Correcto! Pierdes protección.*

**M9 U02 P2.** ¿Con qué buscas tu Afore?

- ✔ Con tu CURP
- Con tu credencial de la escuela
- Con tu número de celular

*¡Correcto! Te identifica.*

**M9 U02 P3.** ¿Quién te orienta sin costo si no te pagan?

- La tienda de la esquina
- Un gestor
- ✔ La PROFEDET

*¡Correcto! Defensa del trabajo.*

**M9 U03 P1.** ¿Qué ayuda a cumplir una meta?

- Guardarla en secreto para que nadie opine de ella
- ✔ Nombre, testigo y recordatorio
- Esperar a tener suerte

*¡Correcto! Así lo logras.*

**M9 U03 P2.** ¿Qué no va en tu plan?

- Tu meta de ahorro
- Tu idea de negocio
- ✔ Tus contraseñas

*¡Correcto! Son datos sensibles.*

**M9 U03 P3.** Tu meta es 3,600 en 6 meses. ¿Cuánto apartas al mes?

- ✔ 600
- 360
- 6,000

*¡Correcto! 3,600 entre 6.*
