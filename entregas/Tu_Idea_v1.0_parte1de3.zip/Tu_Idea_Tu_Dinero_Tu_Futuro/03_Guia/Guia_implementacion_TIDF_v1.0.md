# Tu Idea, Tu Dinero, Tu Futuro: guía de implementación

Para el equipo que monta y opera el curso en Moodle 3.10.

# Parte 1. Instalación en Moodle, paso a paso

El mismo archivo está en `04_Moodle/README_INSTALAR_TU_IDEA_PARA_CLAUDE.md`.


Vas a crear el curso **Tu Idea, Tu Dinero, Tu Futuro** en academia.desarrollatalento.com. El sitio usa Moodle 3.10, el tema Boost, Level Up 3.15.2 y el complemento **Certificado personalizado** (mod_customcert).

Si en el sitio existen otros cursos, **no los toques.**

Trabaja con el navegador y con la sesión de administrador que la persona abrió.

Reglas:

- Usa solo la interfaz web.
- No uses SSH.
- No instales complementos.
- No cambies la configuración del sitio.
- No toques otros cursos.
- Si algo no coincide con estas instrucciones, detente y pregunta.

### 0. Antes de empezar

1. Confirma que no existe un curso con nombre corto `TIDF-MX`. Si existe, detente y pregunta.
2. Revisa en *Administración del sitio > Extensiones > Resumen de extensiones* si existen **Certificado personalizado** y **Level Up**. Anótalo para el reporte.
3. Si el sitio todavía no tiene actividades H5P, la primera que subas instala sus librerías: súbela con la cuenta de administración. Si aparece un error de librerías, detente y reporta el mensaje exacto.

### 1. Crear el curso

| Campo | Valor |
|---|---|
| Nombre | Tu Idea, Tu Dinero, Tu Futuro |
| Nombre corto | TIDF-MX |
| Visibilidad | **Mostrar** |
| Formato | **Mosaicos** (Tiles) si está instalado; si no, Temas. 11 secciones |
| Seguimiento de finalización | Sí |

**Formato Mosaicos (si existe):** en la configuración del curso, *Mostrar progreso en los mosaicos*: **como porcentaje**; un ícono por módulo acorde a su tema; la sección General arriba de los mosaicos. Si Mosaicos no existe, usa Temas con "Mostrar una sección por página".

**Inscripción:** *Métodos de inscripción* > activa **Autoinscripción** con la **clave de inscripción** que te dé la persona (si no la tienes, deja "[por definir]" y repórtalo). Desactiva el acceso de invitados.

### 2. Secciones

| Sección | Nombre | Descripción |
|---|---|---|
| General | Bienvenida | Enlace al capítulo 1 del libro de apoyo y foro "Dudas y comentarios" |
| 1 | Módulo 1. Tu mente y tu dinero | Contenido de `1_libros/M1_resumen.html` |
| 2 | Módulo 2. Tu cuenta y el dinero digital | `M2_resumen.html` |
| 3 | Módulo 3. Crea: de la idea a tu primera venta | `M3_resumen.html` |
| 4 | Módulo 4. Haz crecer lo que empezaste | `M4_resumen.html` |
| 5 | Módulo 5. Pon tu dinero a trabajar | `M5_resumen.html` |
| 6 | Módulo 6. Crédito sin trampas | `M6_resumen.html` |
| 7 | Módulo 7. Riesgos, protección y fraudes | `M7_resumen.html` |
| 8 | Módulo 8. El sistema, la economía y tu familia | `M8_resumen.html` |
| 9 | Módulo 9. Tu futuro y tu plan | `M9_resumen.html` |
| 10 | Materiales de apoyo | "Casos, prácticas, glosario y dónde pedir ayuda." |
| 11 | Evaluación y constancia | "Tu constancia de conclusión." |

Descripción del foro "Dudas y comentarios": "No compartas datos personales, fotos, ubicación, redes sociales, números de cuenta, contraseñas ni códigos."

### 3. Libros de lecciones

En cada sección de módulo:

1. Crea un libro: nombre `Lecciones del Módulo N`, formato de capítulo "Nada", finalización "Ver".
2. Menú del libro > **Importar capítulo** > `1_libros/MN_libro_Moodle.zip`, tipo "Cada archivo HTML representa un capítulo".
3. Comprueba que cada lección tenga su portada primero y 3 subcapítulos sangrados.

| Módulo | Capítulos | Páginas |
|---|---|---|
| M1 | 4 | 16 |
| M2 | 4 | 16 |
| M3 | 5 | 20 |
| M4 | 4 | 16 |
| M5 | 4 | 16 |
| M6 | 4 | 16 |
| M7 | 4 | 16 |
| M8 | 4 | 16 |
| M9 | 3 | 12 |

### 4. Libro de apoyo

En la sección 10, crea el libro `Materiales de apoyo` con la misma configuración e importa `1_libros/Apoyo_libro_Moodle.zip` (6 capítulos). En la sección General, agrega una **URL** o etiqueta al capítulo 1 ("Bienvenida").

En la misma sección 10, agrega un recurso **Archivo** llamado `Herramientas para tus cuentas (Excel)` con el archivo de `10_herramientas/`. Mostrar: "Forzar descarga". Descripción: "Presupuesto, lista de deudas, fondo de emergencia y meta con interés compuesto; y para tu negocio: costo y precio, punto de equilibrio y flujo de 8 semanas. Escribe solo en las celdas rosas; el archivo es tuyo y no se comparte." Finalización: "Ver".

### 5. Glosario

En la sección 10, crea el glosario `Palabras clave del curso` e importa `3_glosario/Glosario_curso_Moodle.xml`, destino "glosario actual".

### 6. Banco de preguntas y autoevaluaciones

1. *Banco de preguntas > Importar*: formato GIFT, `4_preguntas/banco_preguntas_tidf.gift.txt`. Se crean *Tu Idea v1.0/M1* a *M9*, con 108 preguntas.
2. En cada sección de módulo, crea el cuestionario `Autoevaluación del Módulo N`: aprobatoria 70, intentos ilimitados, calificación más alta, respuestas al azar, revisión con correcta y retroalimentación, finalización "Requiere calificación aprobatoria".
3. Agrega **todas** las preguntas de *Tu Idea v1.0/MN*, 10 por página:

| M1 | M2 | M3 | M4 | M5 | M6 | M7 | M8 | M9 |
|---|---|---|---|---|---|---|---|---|
| 12 | 12 | 15 | 12 | 12 | 12 | 12 | 12 | 9 |

### 7. Actividades H5P (36)

Archivos en `2_h5p/MN/`, en orden. En cada sección, **después del libro** y en orden de lección:

1. *Agregar actividad > Actividad H5P*.
2. Nombre: `MN UYY · ¿Qué harías?`.
3. Sube `MN_UYY_que_harias.h5p`.
4. Opciones: descarga no, incrustar no, derechos de autor sí.
5. Calificación: seguimiento sí, "calificación más alta". Finalización: "El estudiante debe recibir una calificación".

**Orden final de cada sección:** libro, H5P en orden, autoevaluación.

**Comprueba:** abre 3 actividades al azar con *Cambiar rol a > Estudiante*. Debes ver 3 casos, 3 opciones por caso y la calificación al terminar.

### 8. Encuestas del programa

En `8_encuestas/` están las encuestas y su documento `encuestas.md`. Usa el módulo **Retroalimentación** (Feedback), modo **anónimo**, y en cada una *Plantillas > Importar preguntas* con su XML (si la importación falla, créalas a mano con `encuestas.md`):

| Actividad | Sección | Archivo | Finalización |
|---|---|---|---|
| `Encuesta de inicio` | General | `encuesta_inicio.xml` | Enviar |
| `Encuesta final` | 11 | `encuesta_final.xml` | Enviar; es requisito de la constancia |
| `Seguimiento a 30 días` | 11 | `encuesta_seguimiento.xml` | Enviar |
| `Seguimiento a 90 días` | 11 | `encuesta_seguimiento.xml` | Enviar |

Restringe los seguimientos por fecha: 30 y 90 días después de la fecha de fin de la cohorte ("[por definir]"). La encuesta final es la evidencia de resultados del programa: no la omitas.

### 9. Level Up, insignias, finalización y constancia

Sigue `7_guias/guia_gamificacion.md`: secciones 2 (Level Up), 3 (8 insignias con `5_insignias/`; cada nombre lleva el curso para que sea único en la plataforma), 4 (finalización con las 9 autoevaluaciones) y 5 (constancia con la plantilla estándar y los datos de `6_constancia/constancia.md`). Si Level Up o Certificado personalizado no existen, no los instales: sáltate ese paso y repórtalo.

### 10. Revisión final (con rol de estudiante)

- M1 U01: portada primero, dos botones de ruta, términos en color con su significado y recuadros "Dato vigente" o "Antes de actuar, verifica".
- Una H5P por módulo abre, muestra 3 casos y registra calificación.
- Una autoevaluación muestra 3 opciones por pregunta.
- El libro de apoyo muestra "Ver la clave" en los casos integradores y las preguntas frecuentes desplegables.

### 11. Reporte para la persona

Enlace del curso; páginas por libro; H5P por módulo; preguntas por autoevaluación; encuestas creadas; insignias activas; configuración de Level Up; estado de la constancia; lo que no pudiste hacer y por qué; capturas de la portada en mosaicos, una H5P, una autoevaluación y la vista previa de la constancia.

El curso queda **visible**, con inscripción por clave. Para la ficha del catálogo usa `tarjeta_catalogo.md`.


# Parte 2. Actividades, puntos, insignias y constancia


Esta guía es para Moodle 3.10 con Level Up (block_xp) 3.15.2 y el complemento Certificado personalizado (mod_customcert).

El objetivo es motivar sin competir. Los puntos premian avanzar, no la calificación perfecta. Nunca se muestra el nombre de nadie en una tabla.

### 1. Qué hay en cada módulo

| Actividad | Cuántas | Finalización |
|---|---|---|
| Libro "Lecciones del Módulo N" | 1 por módulo (9) | Ver |
| Actividad H5P "MN UYY · ¿Qué harías?" | 1 por lección (36) | Recibir calificación |
| Cuestionario "Autoevaluación del Módulo N" | 1 por módulo (9) | Calificación aprobatoria de 70% |

**Configuración de cada actividad H5P:** sin botón de descarga, con botón de derechos de autor e incrustar desactivado; seguimiento de intentos con "Calificación más alta"; finalización "El estudiante debe recibir una calificación".

**Las autoevaluaciones:** usan el banco de 108 preguntas con tres opciones y retroalimentación, en las categorías *Tu Idea v1.0/M1* a *M9*. Calificación aprobatoria de 70%, intentos ilimitados, respuestas en orden aleatorio y revisión con respuesta correcta y retroalimentación al terminar.

### 2. Level Up: niveles y puntos

**Reglas** (*Level Up > Reglas*):

1. Quita o pon en 0 las reglas predeterminadas.
2. **Por completar cualquier actividad:** 25 puntos, con el evento "Se ha actualizado la finalización de un módulo del curso" (`\core\event\course_module_completion_updated`).
3. **Por participar en el foro:** 5 puntos, con el evento "Mensaje creado" (`\mod_forum\event\post_created`).
4. Deja activada la protección contra trampas.

Completar todo el curso da unos 1,350 puntos:

| Actividades | Cuántas | Puntos |
|---|---|---|
| Actividades H5P | 36 | 900 |
| Libros | 9 | 225 |
| Autoevaluaciones | 9 | 225 |
| **Total** | 54 | **1,350** |

**Niveles** (6 niveles, sin algoritmo automático):

| Nivel | Nombre | Puntos | Cuándo se alcanza, más o menos |
|---|---|---|---|
| 1 | Primer paso | 0 | Al entrar |
| 2 | Con idea | 150 | Durante el Módulo 2 |
| 3 | Primera venta | 350 | Durante el Módulo 4 |
| 4 | En crecimiento | 600 | Durante el Módulo 5 |
| 5 | Con cabeza | 800 | Durante el Módulo 7 |
| 6 | Con futuro | 1,000 | Durante el Módulo 9 |

**Clasificación:** anonimato activado; mostrar solo vecinos cercanos o desactivarla.

### 3. Insignias

*Administración del curso > Insignias > Agregar una nueva insignia*. Imágenes en `5_insignias/`. Emisor: Desarrolla Talento. Vencimiento: nunca. Los nombres llevan el curso para que no se repitan en la plataforma: úsalos tal cual.

| Imagen | Insignia | Criterio (finalización de actividad, con aprobación) | Descripción |
|---|---|---|---|
| 01_mente_que_crea.png | Mente que crea · Tu Idea | Autoevaluaciones de los Módulos 1 y 2 | Piensas en crear, tienes presupuesto y usas el dinero digital con seguridad. |
| 02_primera_venta.png | Primera venta · Tu Idea | Autoevaluación del Módulo 3 | Probaste una idea con costo, precio y ganancia. |
| 03_negocio_en_marcha.png | Negocio en marcha · Tu Idea | Autoevaluación del Módulo 4 | Sabes reinvertir, trabajar con socios y cuidar tu marca. |
| 04_dinero_que_trabaja.png | Dinero que trabaja · Tu Idea | Autoevaluación del Módulo 5 | Tu dinero trabaja y distingues invertir de apostar. |
| 05_credito_con_cabeza.png | Crédito con cabeza · Tu Idea | Autoevaluación del Módulo 6 | Sabes cuánto cuesta un crédito y cómo cuidar tu historial. |
| 06_nadie_me_engana.png | Nadie me engaña · Tu Idea | Autoevaluación del Módulo 7 | Tienes tu seguro de estudiante y reconoces fraudes y cuentas mula. |
| 07_entiendo_el_sistema.png | Entiendo el sistema · Tu Idea | Autoevaluación del Módulo 8 | Entiendes el sistema, los impuestos, la economía y los papeles de tu familia. |
| 08_plan_completo.png | Plan completo · Tu Idea | Finalización del curso | Concluiste los nueve módulos del programa. |

Al terminar, **activa** cada insignia.

### 4. Finalización del curso

*Administración del curso > Finalización del curso*: condición de finalización de actividades con **todas** las 9 autoevaluaciones. Opcional: los 9 libros.

### 5. Constancia de conclusión (Certificado personalizado)

1. En la sección "Evaluación y constancia", agrega **Certificado personalizado** con la **plantilla estándar de la plataforma** (sin imagen de fondo): nombre "Constancia de conclusión".
2. **Restringir acceso:** una condición de "Finalización de actividad" por cada una de las 9 autoevaluaciones, "debe estar completa con calificación aprobatoria", y la **Encuesta final** enviada.
3. En la plantilla cambia solo estos datos (también están en `6_constancia/constancia.md`):

   | Campo | Texto |
   |---|---|
   | Título del curso | Tu Idea, Tu Dinero, Tu Futuro |
   | Línea | por concluir el programa de bienestar financiero Tu Idea, Tu Dinero, Tu Futuro |
   | Tema 1 | Mente y dinero digital |
   | Tema 2 | Crear y crecer |
   | Tema 3 | Invertir y crédito |
   | Tema 4 | Riesgos y sistema |
   | Tema 5 | Futuro y plan |

4. Revisa la **Vista previa en PDF** y activa "Verificar certificado".

Si Certificado personalizado no está instalado, la insignia **Plan completo · Tu Idea** funciona como constancia digital.

### 6. Qué no hacer

- No dar puntos por ver páginas.
- No publicar nombres en rankings.
- No pedir datos reales para aprobar.
- No ligar insignias ni constancia a contratar servicios o productos.

