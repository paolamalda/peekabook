# Tu Talento, Tu Marca, Tu Futuro

Manual del programa · Versión 2 · Desarrolla Talento · 28 de septiembre de 2026

Finanzas, crédito, carrera, protección y futuro para personas que trabajan en el entretenimiento en México.

[[TOC]]

---

# 1. Datos generales

| Campo | Valor |
|---|---|
| Programa | Tu Talento, Tu Marca, Tu Futuro |
| Público | Personas residentes en México que trabajan en el entretenimiento: actuación (TV, teatro, cine, streaming), canto y música, modelaje, baile, creación de contenido, conducción, producción y técnica |
| Tono | Tuteo cálido, español de México, directo y sin culpas. Lectura accesible (secundaria o preparatoria) |
| Plataforma | Moodle 3.10 con Level Up, H5P "¿Qué harías?", autoevaluaciones y constancia (mismo diseño v3 que Tu Dinero, Tu Familia, Tu Futuro) |
| Duración | 11 módulos, 72 lecciones de 5 a 10 minutos |

## El problema que resuelve

Muchas personas del medio tienen varios créditos y no saben cómo llegaron ahí. En particular, muchas:

- tienen problemas en Buró o Círculo de Crédito y no saben cómo mejorarlos;
- no distinguen entre productos (tarjeta, crédito de tienda, préstamo personal, préstamo por app, meses sin intereses);
- no conocen el sistema ni diferencian entre instituciones;
- no comparan antes de contratar;
- ven el crédito como dinero extra, no como deuda.

Por eso el crédito es el eje del programa (módulos 4 a 8), sin recortar lo fiscal, los contratos y las regalías (módulos 2 y 3), con un módulo completo contra fraudes y robo de identidad (módulo 9) y más peso en protección y futuro (módulos 10 y 11).

## Reglas del programa

1. Nunca pedimos RFC, CURP, contraseñas, números de tarjeta ni montos reales. Se puede aprender con datos inventados.
2. No recomendamos instituciones, productos ni despachos. Enseñamos a verificar y comparar.
3. No damos asesoría fiscal ni legal personalizada: enseñamos a entender y a preparar preguntas para un contador o un abogado.
4. Para guardar dinero solo mencionamos opciones con respaldo del gobierno o de la protección del IPAB. No recomendamos SOFIPO, SOCAP ni SOFOM; se explican solo para que la persona sepa qué son.
5. Ningún servicio con fines comerciales aparece dentro de las lecciones (ver sección 5).
6. Las cifras que cambian (tasas, UMA, UDIS, límites) llevan fecha y se marcan [POR CONFIRMAR] hasta verificarlas con la fuente oficial.

## Personajes

| Personaje | Perfil | Reto principal |
|---|---|---|
| **Gael** (32) | Actor de TV, teatro y streaming. Cobra a veces por Asimilados y a veces factura. No sabe que esa combinación puede sacarlo de RESICO | Los meses sin llamados y no tener seguro médico |
| **Valeria** (28) | Cantante, modelo y creadora de contenido. Cobra eventos, campañas y publicidad; recibe regalías ocasionales | Mánager sin contrato claro, gastos de imagen y facturación |
| **Renata** (35) | Bailarina y coreógrafa. Tiene 6 tarjetas, un crédito de tienda departamental y un préstamo por app | Cree que su línea de crédito es parte de su ingreso |
| **Toño** (41) | Músico de sesión y técnico de audio. Tiene un atraso reportado en Buró y le llaman de cobranza | Quiere un crédito para su estudio y no sabe por qué se lo niegan |

---

# 2. Mapa de módulos

| Módulo | Nombre | Resultado |
|---|---|---|
| 1 | Tu dinero real: ingresos variables | Tu ganancia real por proyecto, tu sueldo fijo personal y tu fondo de sequía |
| 2 | Tu carrera como negocio: régimen fiscal e impuestos | Tu expediente fiscal y tu calendario de obligaciones |
| 3 | Contratos, representación y regalías | Tu lista de revisión de contratos y tu mapa de regalías |
| 4 | Conoce el sistema financiero mexicano | Tu mapa de instituciones y cómo verificarlas |
| 5 | Compara y elige: instituciones y productos | Tu comparativo de institución, cuenta, ahorro, seguro y crédito |
| 6 | El crédito es deuda | Tu inventario de deudas y tu límite de endeudamiento |
| 7 | Buró y Círculo de Crédito | Tu reporte revisado y tu plan para mejorarlo |
| 8 | Sal de deudas | Tu plan de pago con ingreso variable |
| 9 | No caigas: fraudes y robo de identidad | Tu protocolo de prevención y tu plan de respuesta si te pasa |
| 10 | Protección y prevención | Tu plan de salud, seguros, marca y documentos para tu familia |
| 11 | Tu futuro | Tu plan de retiro, tu reparto del "pago gordo" y tu plan de una página |

---

# 3. Lecciones

## Módulo 1. Tu dinero real: ingresos variables

**M1 U01 · ¿Todo lo que cobro por una producción es mi ganancia real?**
Objetivo: separar el monto del contrato de lo que realmente te queda después de comisión, impuestos y gastos del proyecto.
Gancho: Gael firma 100,000 por una miniserie y piensa cambiar de auto. Después de comisión, impuestos, vestuario y traslados, le quedan unos 63,750. (Lección de muestra completa en el archivo aparte.)

**M1 U02 · ¿Cómo me pago un sueldo si no tengo sueldo fijo?**
Objetivo: aplicar el método de cuenta concentradora y sueldo fijo personal.
Gancho: Valeria cobra 80,000 en un mes y nada en los dos siguientes. Gasta todo en el mes bueno y sufre en los vacíos.

**M1 U03 · ¿Cuánto necesito en mi fondo de sequía?**
Objetivo: calcular la reserva con tus gastos básicos y los meses promedio entre proyectos.
Fórmula: fondo de sequía = gastos básicos del mes × meses promedio entre proyectos (de 3 a 6).
Gancho: Gael gasta 18,000 al mes y suele pasar 4 meses entre producciones: su meta es 72,000.

**M1 U04 · ¿Dónde guardo mi fondo de sequía?**
Objetivo: elegir un lugar seguro, que no pierda contra la inflación y del que puedas sacar dinero rápido.
Opciones que enseñamos a comparar:
- **Cetes en Cetesdirecto:** valores del gobierno federal, desde 100 pesos, sin comisiones. BONDDIA permite retirar al día siguiente.
- **Inversión o cuenta a la vista en un banco**, incluidos bancos digitales. A septiembre de 2026:
  - **Revolut** recibió de la CNBV, con aprobación de Banxico, la autorización para operar como institución de banca múltiple; inició con una fase beta antes de su lanzamiento amplio.
  - **Nu México** era SOFIPO; recibió en abril de 2025 la autorización para constituirse como banco, y en julio de 2026 la CNBV le autorizó iniciar operaciones como banco. [POR CONFIRMAR en el padrón de la CNBV antes de publicar: que todos los productos de ahorro ya estén en el banco y no en la SOFIPO]
  - En cualquier banco, el IPAB protege los depósitos hasta 400,000 UDIS por persona y por banco (unos 3.4 millones de pesos).
  - Regla para la persona: antes de depositar, busca la entidad en el padrón de la CNBV y confirma que el nombre legal del contrato diga "Institución de Banca Múltiple".

Qué comparar: rendimiento anual (GAT nominal y real), si puedes retirar al día, comisiones y protección.
Se evita: invertir el fondo en acciones o en fondos que pueden bajar (por ejemplo, NAFTRAC); tampoco se recomiendan SOFIPO ni SOCAP.
Gancho: Valeria tiene 60,000 en su cuenta de nómina sin rendimiento. Una amiga le recomienda "invertirlo todo en la bolsa".

**M1 U05 · Vestuario, imagen y estilismo: ¿gasto necesario o fuga?**
Objetivo: separar el vestuario que pide una producción del mantenimiento de tu imagen, y presupuestar ambos.
Gancho: Valeria gasta 18,000 en ropa para una publicidad que le paga 30,000.

**M1 U06 · La productora paga a 60 o 90 días: ¿cómo organizo mi flujo?**
Objetivo: hacer un calendario de cobros y pagos con los tiempos reales de pago de las productoras, agencias y plataformas.
Gancho: Gael terminó de grabar en marzo y le pagan en junio; su tarjeta vence en abril.

## Módulo 2. Tu carrera como negocio: régimen fiscal e impuestos

**M2 U01 · ¿RESICO, Asimilados o Actividad Empresarial?**
Objetivo: conocer cómo funciona cada régimen para preparar la conversación con tu contador.

| Régimen | Cómo paga ISR | Deducciones | Lo que hay que saber |
|---|---|---|---|
| RESICO (personas físicas) | Tasa de 1% a 2.5% sobre lo que cobras (sin IVA), según tu ingreso del mes. Pagos mensuales definitivos. Si facturas a una empresa (persona moral), te retiene 1.25%, que acreditas en tu pago del mes | **No permite deducir gastos ni aplicar deducciones personales** | Límite de 3.5 millones al año. Cobras IVA en tus servicios. No pueden entrar, entre otros, socios o accionistas de empresas y quienes cobran honorarios asimilados a salarios |
| Asimilados a salarios | La empresa retiene ISR con la tarifa de sueldos, hasta 35% | No aplica deducciones del negocio | No es relación laboral: no hay IMSS, aguinaldo ni prestaciones |
| Actividad empresarial y profesional | Tarifa progresiva, hasta 35%, sobre ingresos menos gastos deducibles | **Sí permite deducir** gastos del negocio con factura (CFDI) | Pagos provisionales mensuales. Si facturas a una empresa, te retiene 10% de ISR y dos terceras partes del IVA |

Tabla mensual de RESICO (artículo 113-E de la LISR, sin cambios para 2026): hasta 25,000, 1%; hasta 50,000, 1.1%; hasta 83,333.33, 1.5%; hasta 208,333.33, 2%; hasta 3.5 millones al año, 2.5%.

Tres puntos que la lección aclara:
- **Asimilados y RESICO.** Si una productora te paga honorarios como asimilados a salarios (porque así lo pediste por escrito o porque le prestas servicios de forma preponderante), la ley te excluye de RESICO. Esa combinación, común en el medio, se revisa con el contador.
- **Sin deducciones.** RESICO no permite restar gastos del negocio ni deducciones personales (gastos médicos, colegiaturas, PPR).
- **Declaración anual.** La ley (artículo 113-G) la pide, pero la Resolución Miscelánea Fiscal ha liberado de presentarla en ciertos casos a partir del ejercicio 2024. [POR CONFIRMAR cada año con la RMF vigente]

Gancho: Gael no sabe si le conviene RESICO: gasta mucho en vestuario y cursos, que en RESICO no se deducen, y una productora le paga como asimilado.

**M2 U02 · El IVA: el dinero que cobras pero no es tuyo**
Objetivo: entender que el IVA que cobras en tus facturas se entera al SAT (menos el que te retengan y el IVA acreditable) y apartarlo de inmediato.
Gancho: Valeria facturó 50,000 más IVA y gastó los 58,000.

**M2 U03 · ¿Qué gastos de mi carrera sí puedo deducir, y en qué régimen?**
Objetivo: armar tu carpeta de comprobantes (CFDI) sabiendo que las deducciones del negocio aplican en Actividad Empresarial, no en RESICO.
Categorías: formación (actuación, canto, acento, baile), promoción (headshots, demo reel, sitio web, publicidad en redes), herramientas (instrumentos, equipo de audio o cómputo, vestuario de trabajo) y servicios (contador, abogado, representación).

**M2 U04 · Facturar, declarar y no atrasarte con el SAT**
Objetivo: conocer tu calendario: facturación CFDI 4.0, declaraciones mensuales, declaración anual y buzón tributario.
Gancho: Toño dejó de declarar dos años porque "casi no facturaba" y le llegó una carta invitación del SAT.

**M2 U05 · Deducciones personales y tu declaración anual**
Objetivo: conocer las deducciones personales (gastos médicos, colegiaturas, aportaciones a retiro, PPR) y saber que aplican en la declaración anual de sueldos, asimilados y actividad empresarial, pero no a los ingresos de RESICO.

## Módulo 3. Contratos, representación y regalías

**M3 U01 · Lo que revisas antes de firmar un llamado o una exclusividad**
Objetivo: identificar vigencia, territorio, medios, exclusividad, derechos de imagen, penalizaciones y fechas de pago.
Gancho: Valeria firmó una campaña "para redes" y su foto apareció en espectaculares durante tres años.

**M3 U02 · Derechos de imagen y voz: qué cedes y por cuánto tiempo**
Objetivo: distinguir entre ceder, licenciar y autorizar el uso de tu imagen y de tu voz, incluidos usos con inteligencia artificial y doblaje.

**M3 U03 · Mánagers y agencias: comisiones y cuentas claras**
Objetivo: pactar por escrito la comisión (normalmente entre 10% y 20%), sobre qué monto se cobra, qué gastos se descuentan y cómo te rinden cuentas.
Gancho: el mánager de Valeria cobra su comisión sobre el pago con IVA incluido y además descuenta "gastos de representación" sin comprobante.

**M3 U04 · ANDA, ANDI y las organizaciones del medio en México: ¿quién hace qué?**
Objetivo: saber a qué organización mexicana acudir según lo que necesitas:

| Organización | Qué es | Para qué te sirve |
|---|---|---|
| **ANDA** (Asociación Nacional de Actores) | Sindicato de actrices y actores de cine, teatro, radio, televisión, doblaje, stunts y centros nocturnos | Tu actividad laboral: agremiación, contratos, tabuladores, condiciones de trabajo y servicios para sus agremiados, incluidos servicios de salud [POR CONFIRMAR: servicios vigentes] |
| **ANDI** (Asociación Nacional de Intérpretes) | Sociedad de gestión colectiva autorizada por INDAUTOR | Cobra y reparte tus regalías como intérprete por retransmisiones de programas, telenovelas, películas y fonogramas, en México y el extranjero |
| **SACM** (Sociedad de Autores y Compositores de México) | Sociedad de gestión colectiva | Regalías de autores y compositores de música |
| **EJE** (Ejecutantes) | Sociedad de gestión colectiva | Regalías de músicos ejecutantes y cantantes de agrupaciones |
| **SOMEXFON** | Sociedad de gestión colectiva | Derechos de los productores de fonogramas (disqueras y quienes producen sus propias grabaciones) |

Idea clave: muchas personas creen que la ANDA cobra las regalías; la ANDA regula la actividad laboral y la ANDI administra las regalías. Puedes pertenecer a las dos.
Gancho: Gael es miembro de la ANDA y cree que ahí le llegan sus regalías de una telenovela que se retransmite en Sudamérica.

**M3 U05 · Cómo cobro mis regalías y reviso mis pagos**
Objetivo: afiliarte a la sociedad que te corresponde (ANDI, SACM, EJE o SOMEXFON), registrar tus obras o interpretaciones, revisar tus liquidaciones, desconfiar de gestores que cobran por "recuperar regalías" y saber que esos ingresos se declaran. [POR CONFIRMAR con contador: tratamiento de ISR e IVA de regalías por derechos de autor]

**M3 U06 · Cuando la productora no paga**
Objetivo: documentar, reclamar por escrito, conocer penalizaciones pactadas y cuándo acudir a un abogado o a PROFEDET (si hay relación laboral).

## Módulo 4. Conoce el sistema financiero mexicano

**M4 U01 · ¿Quién es quién en el sistema financiero?**
Objetivo: distinguir a las autoridades (Banxico, SHCP, CNBV, CONDUSEF, IPAB, CNSF) de las instituciones que te ofrecen productos.

**M4 U02 · Bancos, bancos digitales y otras entidades: ¿cuál es cuál?**
Objetivo: diferenciar un banco (con protección del IPAB) de otras entidades que también prestan o captan dinero: SOFOM, SOFIPO, SOCAP, instituciones de tecnología financiera, tiendas departamentales y casas de empeño. Se explican para que sepas qué contratas, sin recomendarlas.
Gancho: Renata tiene cinco "tarjetas de banco"; al revisar, solo dos son de bancos.

**M4 U03 · ¿Cómo verifico una institución antes de contratar?**
Objetivo: usar el SIPRES (registro de prestadores de servicios financieros), el Buró de Entidades Financieras de CONDUSEF y el padrón de entidades supervisadas de la CNBV.

**M4 U04 · Tus derechos como usuario**
Objetivo: conocer tus derechos (información clara, contrato registrado, cancelación, reclamación) y cómo reclamar: primero a la Unidad Especializada (UNE) de la institución, luego a CONDUSEF.

## Módulo 5. Compara y elige: instituciones y productos

**M5 U01 · Primero elige la institución**
Objetivo: comparar instituciones por supervisión, protección, calificación en el Buró de Entidades Financieras, reclamaciones, atención y canales.

**M5 U02 · Elige tu cuenta**
Objetivo: comparar cuentas por comisiones, saldo mínimo, retiros, transferencias y cobros en efectivo. Portabilidad de nómina si cobras por Asimilados.

**M5 U03 · Elige dónde ahorrar e invertir**
Objetivo: leer la GAT nominal y la GAT real, el plazo, la liquidez y la protección. Cetes, pagarés y cuentas a la vista de bancos.

**M5 U04 · Elige un seguro**
Objetivo: comparar suma asegurada, deducible, coaseguro, exclusiones y prima con los simuladores de CONDUSEF.

**M5 U05 · Elige un crédito: los números**
Objetivo: comparar por CAT, tasa, comisiones, pago total y plazo. Distinguir crédito revolvente (tarjeta) de crédito simple (pagos fijos).
Gancho: a Toño le ofrecen dos créditos para su estudio con el mismo pago mensual: uno cuesta 18,000 más que el otro.

**M5 U06 · Elige un crédito: el tipo correcto para cada uso**
Objetivo: relacionar el uso con el producto: equipo de trabajo, emergencia, auto, vivienda. Cuándo no conviene pedir crédito.

**M5 U07 · Lee el contrato antes de firmar**
Objetivo: revisar la carátula, el CAT, las comisiones, los seguros incluidos y el registro del contrato en el RECA de CONDUSEF.

## Módulo 6. El crédito es deuda

**M6 U01 · Tu línea de crédito no es tu ingreso**
Objetivo: entender que la línea es dinero prestado que se paga con tus ingresos futuros, y que un aumento de línea no es un aumento de sueldo.
Gancho: Renata dice "tengo 180,000 disponibles" al sumar las líneas de sus seis tarjetas.

**M6 U02 · Pago mínimo, pago para no generar intereses y fechas clave**
Objetivo: leer tu estado de cuenta: fecha de corte, fecha límite, pago mínimo y pago para no generar intereses. Cuánto tardas y cuánto pagas si solo cubres el mínimo.

**M6 U03 · Meses sin intereses: cuándo ayudan y cuándo te atrapan**
Objetivo: usar MSI solo en compras que planeabas (equipo de trabajo, por ejemplo) y sumar todas tus mensualidades antes de agregar otra.

**M6 U04 · Tu inventario de deudas**
Objetivo: listar cada deuda con institución, tipo, saldo, tasa o CAT, pago mínimo, fecha y si hay atraso.

**M6 U05 · ¿Cuánta deuda aguanta un ingreso variable?**
Objetivo: medir tus pagos de deuda contra tu mes bajo, no contra tu mejor mes, y fijar tu límite personal.

**M6 U06 · No uses la tarjeta para vivir la sequía**
Objetivo: diferenciar una emergencia de un faltante recurrente y usar primero el fondo de sequía.
Gancho: Gael pagó la renta de cuatro meses sin llamados con la tarjeta y ahora debe 60,000.

## Módulo 7. Buró y Círculo de Crédito

Marco: Ley para Regular las Sociedades de Información Crediticia (LRSIC) y reglas del Banco de México para esas sociedades (Circular 27/2008 y sus modificaciones). Orientación de CONDUSEF.

**M7 U01 · ¿Qué son el Buró y el Círculo de Crédito?**
Objetivo: entender que son sociedades de información crediticia: guardan tu historial y lo entregan a quien tú autorizas. No son una "lista negra", no prestan dinero y no deciden si te aprueban: decide la institución.

**M7 U02 · Buró y Círculo: ¿en qué se parecen y en qué no?**
Objetivo: saber que hay dos sociedades con la misma función, que cada institución reporta a una, a la otra o a ambas, y que por eso tu información puede ser distinta en cada una. Revisa las dos.
Gancho: Toño revisó su Buró y todo estaba bien, pero le negaron un crédito por un atraso que solo aparece en Círculo.

**M7 U03 · Pide tus reportes gratis: dos al año**
Objetivo: obtener tu Reporte de Crédito Especial gratis la primera vez y después una vez cada 12 meses en **cada** sociedad: uno en Buró y otro en Círculo. Se pide en sus sitios oficiales con tus datos y preguntas de seguridad; los reportes extra tienen costo (en Buró, unos 47 pesos por internet [POR CONFIRMAR]).
Regla: pídelo solo en los sitios oficiales. Nadie más "te consulta el Buró gratis" a cambio de tus datos.

**M7 U04 · Lee tu reporte**
Objetivo: identificar cuentas, otorgante, saldo, límite, forma de pago y atrasos, claves de observación (por ejemplo, cuenta liquidada con quita) y la lista de quién consultó tu historial en los últimos 24 meses.

**M7 U05 · Tu score: qué lo sube y qué lo baja**
Objetivo: saber que el score (como Mi Score de Buró) es un producto aparte y con costo, distinto del reporte gratuito, y conocer lo que lo mueve: pagos a tiempo, uso de tu línea, antigüedad, consultas y tipos de crédito.

**M7 U06 · ¿Cuánto tiempo se queda un atraso?**
Objetivo: conocer los plazos para que se elimine una deuda del historial, según su monto en UDIS:

| Monto de la deuda | Se elimina después de |
|---|---|
| Hasta 25 UDIS | 1 año |
| Más de 25 y hasta 500 UDIS | 2 años |
| Más de 500 y hasta 1,000 UDIS | 4 años |
| Más de 1,000 UDIS | 6 años |

No se eliminan por plazo las deudas mayores a 400,000 UDIS, las que están en juicio y las relacionadas con un fraude. Eliminar el registro no borra la deuda: el acreedor puede seguir cobrando. [POR CONFIRMAR con LRSIC y Circular 27/2008: desde qué fecha se cuenta el plazo]
Gancho: Toño cree que su atraso de hace siete años "lo tiene marcado de por vida".

**M7 U07 · Si hay un error: reclama paso a paso**
Objetivo: presentar una reclamación ante la unidad especializada del Buró o del Círculo, por escrito o en línea, con copia de tu reporte, los registros que impugnas y tus pruebas (por ejemplo, la carta de liquidación). La sociedad pide la información a la institución; si esta no la sustenta, el registro se corrige o se elimina. Hay reclamaciones gratuitas al año (en Círculo, dos gratis y las siguientes con costo) [POR CONFIRMAR: número de reclamaciones gratuitas y plazo de respuesta en LRSIC arts. 42 a 45]. Si no se resuelve, acude a CONDUSEF.

**M7 U08 · Protege tu historial: bloqueo y alertas**
Objetivo: conocer los servicios de protección:
- **Bloqueo de Buró:** mientras está activo, nadie puede consultar tu historial, así que nadie puede abrir un crédito a tu nombre. Lo desbloqueas cuando tú vas a pedir un crédito. [POR CONFIRMAR: condiciones y costo vigentes]
- **Alertas Buró:** te avisa cada vez que alguien consulta tu historial o se abre un crédito a tu nombre (con costo anual, unos 232 pesos [POR CONFIRMAR]).
- Servicios equivalentes de Círculo de Crédito. [POR CONFIRMAR]

**M7 U09 · Despachos que "limpian tu Buró": fraude**
Objetivo: reconocer que nadie puede borrar información correcta, que las reclamaciones las haces tú y son gratuitas, y que esos cobros son fraude.

**M7 U10 · Cómo mejorar tu historial paso a paso**
Objetivo: seguir un plan de 6 a 12 meses: pagar a tiempo, bajar el uso de tus tarjetas, no pedir créditos seguidos, regularizar los atrasos y revisar tus dos reportes cada año.

## Módulo 8. Sal de deudas

**M8 U01 · Elige tu método: avalancha o bola de nieve**
Objetivo: ordenar tus deudas por costo (avalancha) o por saldo (bola de nieve) y sostener el plan con tu mes bajo.

**M8 U02 · Negociar con el banco: reestructura, convenio o quita**
Objetivo: entender cada opción, qué pedir por escrito y cómo aparece en tu historial (una quita puede dejar una clave de observación).
Gancho: a Toño le ofrecen pagar 40% de su deuda "para liquidar"; no sabe qué pasará con su Buró.

**M8 U03 · ¿Consolidar deudas me conviene?**
Objetivo: comparar el costo total de consolidar contra seguir pagando, y evitar volver a usar las tarjetas liberadas.

**M8 U04 · Cobranza: tus derechos**
Objetivo: conocer lo que un despacho puede y no puede hacer, verificarlo en el REDECO de CONDUSEF y presentar una queja si hay abuso.

**M8 U05 · Tu plan de salida con ingreso variable**
Objetivo: definir un pago base con tu mes bajo, abonar extra en meses buenos y fijar fechas de revisión.

## Módulo 9. No caigas: fraudes y robo de identidad

**M9 U01 · Cómo piensa quien te quiere estafar**
Objetivo: reconocer los cuatro ganchos de casi todo fraude (urgencia, autoridad, premio y miedo) y la regla de oro: cuelga y verifica por tu cuenta.
Gancho: a Valeria le llama "el área de seguridad de su banco" y le pide un código "para cancelar un cargo".

**M9 U02 · Falsos castings, productoras y agencias que cobran**
Objetivo: reconocer convocatorias que cobran por audicionar, por "book" obligatorio o por inscripción, suplantan a productoras reales o piden datos de más. Verificar la empresa, el contacto y el lugar antes de ir o pagar.
Gancho: Gael recibe por Instagram un "casting para una serie de plataforma" que pide 3,500 para el material fotográfico.

**M9 U03 · Llamadas, mensajes y páginas falsas (phishing)**
Objetivo: identificar SMS, WhatsApp, correos y páginas que imitan a tu banco, al SAT, a paqueterías o a plataformas. Nunca compartir NIP, contraseñas, códigos de verificación ni el CVV.

**M9 U04 · Robo de identidad: cuando usan tu nombre**
Objetivo: reconocer las señales (créditos que no pediste, cobranza de deudas ajenas, consultas desconocidas en tu reporte), cuidar tu INE, CURP, RFC y firma, y saber qué hacer: activar el bloqueo de Buró y las alertas (M7 U08), reclamar a la institución y ante el Buró o el Círculo, acudir a CONDUSEF y presentar denuncia.
Gancho: a Toño le llega una cobranza por un préstamo que nunca pidió, abierto con una copia de su INE que dejó en un casting.

**M9 U05 · Tus redes y tu teléfono: robo de cuentas y cambio de SIM**
Objetivo: proteger tus cuentas de redes (tu vitrina de trabajo) con verificación en dos pasos, correo seguro y códigos de respaldo, y proteger tu línea con un NIP de portabilidad. Qué hacer si te roban la cuenta.
Gancho: a Valeria le roban su Instagram con 80,000 seguidores y piden "rescate" a sus contactos.

**M9 U06 · Apps de préstamo "montadeudas" y préstamos con depósito previo**
Objetivo: reconocer apps no registradas, que piden acceso a tus contactos o fotos, o que cobran antes de prestar. Qué hacer si ya caíste: no pagar extorsiones, guardar evidencia, reportar y denunciar.
Gancho: Renata pidió 3,000 en una app y ahora le exigen 7,000 y amenazan a sus contactos.

**M9 U07 · Inversiones milagro y "yo te manejo tu dinero"**
Objetivo: reconocer pirámides, esquemas de referidos, criptomonedas con rendimiento "garantizado", y a personas cercanas al medio que ofrecen manejar tu dinero sin estar autorizadas. Verificar en la CNBV antes de invertir.
Gancho: un productor conocido le ofrece a Gael 10% mensual por "invertir en su siguiente película".

**M9 U08 · Si ya te pasó: tu plan de respuesta**
Objetivo: seguir los pasos en orden: bloquear tarjetas y accesos, llamar a tu institución por el número oficial, reclamar por escrito, reportar a CONDUSEF, denunciar ante el Ministerio Público o la policía cibernética de tu estado, y avisar a tu comunidad sin exponer tus datos. Guardar evidencia.

## Módulo 10. Protección y prevención

**M10 U01 · Sin seguro de empresa: el Seguro de Gastos Médicos Mayores**
Objetivo: comparar suma asegurada, deducible, coaseguro, tabulador y exclusiones.

**M10 U02 · IMSS Modalidad 10: seguridad social para independientes**
Objetivo: conocer la Modalidad 10 (incorporación voluntaria al régimen obligatorio para personas trabajadoras independientes), que desde la reforma de diciembre de 2023 es un derecho permanente: atención médica, incapacidades, invalidez y vida, retiro en tu AFORE y aportaciones a Infonavit. La cuota depende del ingreso que registres; se calcula con la calculadora del IMSS. Conocer también los servicios de salud de ANDA para sus agremiados. [POR CONFIRMAR: cuotas 2026 y servicios de ANDA]
Gancho: Gael lleva seis años sin IMSS desde su último contrato de nómina.

**M10 U03 · Si no puedes trabajar: incapacidad, invalidez y accidentes**
Objetivo: proteger tu ingreso si una lesión o enfermedad te impide grabar, cantar o bailar. Qué cubren los seguros de accidentes e incapacidad y qué preguntar sobre coberturas especiales de voz o cuerpo.

**M10 U04 · Seguro de vida y beneficiarios**
Objetivo: decidir si lo necesitas, cuánto y a quién nombrar. Actualizar beneficiarios en tu cuenta, tu AFORE y tus seguros.

**M10 U05 · Protege tu nombre y tu marca**
Objetivo: tramitar la reserva de derechos al uso exclusivo de tu nombre artístico ante INDAUTOR y el registro de marca ante el IMPI (buscador MarcaNET).

**M10 U06 · Testamento y documentos para tu familia**
Objetivo: hacer tu testamento (en septiembre, el Mes del Testamento suele bajar costos), ordenar tus documentos y dejar instrucciones sobre tus regalías y derechos.

## Módulo 11. Tu futuro

**M11 U01 · Llegó un pago gordo: repártelo antes de gastarlo**
Objetivo: aplicar un reparto inmediato: primero impuestos (según tu régimen), luego deudas caras, fondo de sequía, retiro y una parte para disfrutar.
Gancho: Valeria cobra 400,000 por una campaña; hace un año gastó una cantidad parecida en tres meses.

**M11 U02 · Tu AFORE: encuéntrala y súmale**
Objetivo: localizar tu AFORE con tu CURP (e-SAR o AforeMóvil), actualizar beneficiarios y hacer aportaciones voluntarias.

**M11 U03 · Modalidad 40: si cotizaste antes de julio de 1997**
Objetivo: conocer la continuación voluntaria del IMSS (Modalidad 40) para personas de la Ley 73, que permite seguir sumando semanas y mejorar el salario con que se calcula la pensión.
Requisitos: haber cotizado al menos 52 semanas en los últimos cinco años antes de la baja, pedirla dentro de los cinco años siguientes a la baja y no estar dado de alta como trabajador en ese momento.
Costo 2026: 14.438% del salario que elijas, con tope de 25 UMA diarias. El IMSS endureció los controles en 2026. [POR CONFIRMAR: porcentaje y reglas vigentes]
Diferencia con la Modalidad 10: la 10 es para quien trabaja por su cuenta hoy y te da servicio médico; la 40 es para quien ya no cotiza y quiere mejorar su pensión, y no incluye servicio médico.
Gancho: Toño trabajó con nómina en una disquera de 1994 a 2021 y no sabe si le conviene la Modalidad 40 o la 10.

**M11 U04 · Plan Personal de Retiro (PPR) y aportaciones deducibles**
Objetivo: conocer el PPR y las aportaciones voluntarias deducibles (artículo 151 de la LISR, con límite). Saber que la deducción aplica a quien presenta declaración anual por sueldos, asimilados o actividad empresarial, no a los ingresos de RESICO. Comparar comisiones y rendimiento.

**M11 U05 · Invertir a largo plazo sin especular**
Objetivo: entender riesgo, plazo, diversificación y comisiones, y verificar que el intermediario esté autorizado. Qué es un fondo de inversión o un ETF y por qué no se usa para el fondo de sequía.

**M11 U06 · Vivienda: rentar, comprar o esperar**
Objetivo: comparar el costo total de comprar (enganche, gastos notariales, avalúo, seguros) contra rentar, y conocer las opciones de crédito para personas independientes. [POR CONFIRMAR: opciones de Infonavit para personas no asalariadas]

**M11 U07 · Ingresos fuera de cámara**
Objetivo: diversificar con clases, talleres, producción, marcas propias o consultoría, y calcular si un negocio paralelo realmente te deja ganancia.

**M11 U08 · Tu carrera larga**
Objetivo: planear las etapas de tu carrera (formación, crecimiento, madurez y transición) y lo que necesitas en cada una.

**M11 U09 · Tu plan de una página**
Objetivo: reunir tus números, deudas, reserva, protección, metas y tres acciones con fecha.

---

# 4. Qué cambió respecto a la versión 1

| Tema | Versión 1 | Versión 2 |
|---|---|---|
| Enfoque | Crédito en un módulo de 4 lecciones, como "herramienta en la sequía" | Crédito como eje: 5 módulos (sistema, comparar, deuda, Buró, salir de deudas) |
| RESICO | "Deducir" vestuario y gastos en RESICO | RESICO no permite deducir; las deducciones aplican en Actividad Empresarial |
| Tasa RESICO | 2.5% fija | De 1% a 2.5% según el ingreso del mes; retención de 1.25% al facturar a empresas |
| IVA | Casi no aparecía | Lección propia (M2 U02) |
| IMSS | Modalidad 10 sin detalle | Modalidad 10 en protección (M10 U02) y Modalidad 40 en futuro (M11 U03) |
| Regalías | AADI y "SOMEMEX" | Organizaciones mexicanas: ANDA (sindicato), ANDI, SACM, EJE y SOMEXFON |
| Buró | Una lección | Módulo de 10 lecciones: Buró vs. Círculo, reportes gratis, plazos, reclamaciones, bloqueo y alertas |
| RESICO | Sin exclusiones | Exclusión por asimilados, sin deducciones personales, declaración anual según RMF |
| Fuente F02 | Guía ANDI / SAG-AFTRA (no verificable) | Eliminada |
| Fondo de sequía | "CETES a la vista", NAFTRAC, SOFIPO | Cetes en Cetesdirecto (BONDDIA) y cuentas a la vista de bancos protegidos por el IPAB |
| e-SAR | esar.com.mx | e-sar.com.mx |
| Fórmula | Texto dañado | Corregida |
| Comparar | Solo tarjetas | Módulo completo: institución, cuenta, ahorro, seguro y crédito |
| Fraudes | Sin módulo | Módulo 9 completo: fraudes, falsos castings, phishing, robo de identidad, robo de cuentas, montadeudas, inversiones milagro y plan de respuesta |
| Futuro y prevención | 2 módulos cortos | Módulo 10 (6 lecciones) y Módulo 11 (8 lecciones) |
| Monetización | Puntos de venta dentro de las lecciones | Fuera de las lecciones; solo en canales, identificada como referencia |
| Quiz | Preguntas de memoria | Preguntas de decisión |

---

# 5. Comunidad, canales y referencias

## Espacio propio para este grupo

Sí es posible, sin que dependa de un curso:

| Opción | Para qué sirve | Ventajas | Cuidado |
|---|---|---|---|
| **Canal de WhatsApp** "Tu Talento" | Avisos, recordatorios, fechas del SAT, alertas de fraude y referencias | Casi todos lo usan; los seguidores no ven el número de los demás | Es de una sola vía: solo el equipo publica, los demás reaccionan |
| **Comunidad de WhatsApp** con un grupo de dudas | Conversación entre participantes | Conversación real | En el grupo de conversación los números son visibles para el grupo; necesita moderación y reglas |
| **Espacio "Comunidad Tu Talento" en Moodle** | Foro de dudas y avisos, separado del curso | Privado, moderado y ligado a tu plataforma | Hay que inscribir al grupo (con una cohorte) |

**Recomendación:** Canal de WhatsApp para avisos y referencias, más el foro de Moodle para dudas. Así las preguntas sobre deudas o el SAT no quedan expuestas con el número de teléfono de la persona.

**Reglas del espacio:**

- no compartir RFC, CURP, números de cuenta, montos reales ni capturas de estados de cuenta;
- no promover productos entre participantes;
- los casos personales se atienden por mensaje privado o se canalizan a un profesional.

## Referencias de servicios (fuera de las lecciones)

Los servicios con acuerdo comercial se ofrecen **solo en los canales**, nunca dentro de una lección, una autoevaluación ni la constancia:

- **Agencia de marca personal y redes (servicio propio).**
- **Despachos contables especializados en la industria creativa (referido).**
- **Agentes de seguros y planes de retiro (referido).**

Cada publicación dice "Referencia comercial: Desarrolla Talento puede recibir una comisión". Cada servicio sugiere comparar con al menos otra opción, y usarlo es voluntario: no afecta el acceso, los puntos ni la constancia.

---

# 6. Bibliografía y fuentes oficiales

## Libros

- Macías, Sofía. *Pequeño Cerdo Capitalista: Finanzas personales para todos.* Aguilar.
- Macías, Sofía. *Pequeño Cerdo Capitalista: Inversiones.* Aguilar.
- Horowitz, Sara. *The Freelancer's Bible.* Workman Publishing.

## Fuentes oficiales

| Institución | Sitio | Qué buscar |
|---|---|---|
| SAT | https://www.sat.gob.mx | RESICO, CFDI 4.0, declaraciones y buzón tributario |
| CONDUSEF | https://www.condusef.gob.mx | SIPRES, Buró de Entidades Financieras, RECA, REDECO, REUS, simuladores y comparadores |
| Banco de México | https://www.banxico.org.mx | Calculadora del CAT, comparativos de tarjetas |
| CNBV | https://www.gob.mx/cnbv | Padrón de entidades supervisadas |
| IPAB | https://www.gob.mx/ipab | Qué depósitos protege y hasta cuánto |
| Buró de Crédito | https://www.burodecredito.com.mx | Reporte de Crédito Especial, reclamaciones, Bloqueo y Alertas Buró |
| Policía cibernética | [POR CONFIRMAR: contacto de la policía cibernética de cada estado] | Reportar fraudes en línea y robo de cuentas |
| Círculo de Crédito | https://www.circulodecredito.com.mx | Reporte de crédito especial y reclamaciones |
| Cetesdirecto | https://www.cetesdirecto.com | Cuenta sin comisiones, BONDDIA y Cetes |
| CONSAR y e-SAR | https://www.e-sar.com.mx | Localiza tu AFORE con tu CURP |
| IMSS | https://www.imss.gob.mx/personas-trabajadoras-independientes | Modalidad 10 y su calculadora; trámite de Modalidad 40 (IMSS-02-007) |
| INDAUTOR | https://www.indautor.gob.mx | Reserva de derechos para nombre artístico |
| IMPI | https://www.gob.mx/impi | MarcaNET y registro de marca |
| ANDI | https://www.andi.org.mx | Afiliación y regalías de intérpretes |
| SACM | https://www.sacm.org.mx | Registro de obras musicales |
| EJE | https://www.ejecutantes.com | Regalías de músicos ejecutantes |
| SOMEXFON | https://www.somexfon.com | Derechos de productores de fonogramas |
| ANDA | https://laanda.org.mx | Agremiación y servicios para actrices y actores |
| INDAUTOR, sociedades de gestión colectiva | https://www.indautor.gob.mx/sociedades-de-gestion-colectiva.php | Lista de sociedades autorizadas |

## Leyes de referencia

- Ley del Impuesto sobre la Renta: artículos 113-E a 113-J (RESICO), 94 y 96 (sueldos y asimilados), 100 a 110 (actividad empresarial y profesional) y 151 (deducciones personales).
- Ley del Impuesto al Valor Agregado.
- Ley para Regular las Sociedades de Información Crediticia (artículos 23, 40 y 42 a 45).
- Banco de México, Circular 27/2008: reglas generales de las sociedades de información crediticia.
- Ley del Seguro Social: artículo 218 (continuación voluntaria, Modalidad 40) y reforma de diciembre de 2023 (personas trabajadoras independientes).
- Ley de Protección y Defensa al Usuario de Servicios Financieros.
- Ley Federal del Derecho de Autor.

---

# 7. Pendientes antes de escribir las lecciones

| Clave | Dato por confirmar |
|---|---|
| E01 | Declaración anual de RESICO: si la RMF del año libera de presentarla |
| E02 | Cuotas 2026 de la Modalidad 10 y reglas vigentes de la Modalidad 40 |
| E03 | Que los productos de ahorro de Nu ya estén en el banco (padrón de la CNBV) y la fecha de lanzamiento amplio de Revolut |
| E04 | Desde qué fecha se cuenta el plazo de eliminación en Buró y Círculo |
| E05 | Reclamaciones gratuitas al año y plazos de respuesta (LRSIC y Circular 27/2008) |
| E06 | Costo y condiciones de Bloqueo, Alertas Buró, reportes extra y servicios equivalentes de Círculo |
| E07 | Servicios de salud de ANDA para agremiados |
| E08 | Tratamiento de ISR e IVA de las regalías por derechos de autor |
| E09 | Opciones de crédito de vivienda para independientes y contactos de policía cibernética |
