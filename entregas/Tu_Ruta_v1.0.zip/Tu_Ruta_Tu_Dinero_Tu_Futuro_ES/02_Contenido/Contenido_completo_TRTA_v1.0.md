# Tu Ruta, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Beto | 28 años. Reparte en moto propia en Guadalajara con dos aplicaciones. |
| Mariana | 33 años. Conduce su auto en la Ciudad de México; es mamá de una niña. |
| Kevin | 21 años. Reparte en bici en Puebla mientras estudia. |
| Don Chava | 47 años. Conduce un auto que le renta un dueño por semana en Monterrey. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Tu ingreso real | Tu ganancia real por hora y un sueldo fijo para las semanas malas. | Ganancia real |
| Módulo 2. Tus derechos con la reforma | Tus derechos claros: quién es persona trabajadora de plataforma, prestaciones y cómo reclamar. | Conozco mis derechos |
| Módulo 3. Tu IMSS, tu Afore y tu Infonavit | Tu situación ante el IMSS revisada y tu Afore localizada. | Asegurado |
| Módulo 4. Tus impuestos | Tus retenciones entendidas y tu RFC en orden. | Cuentas claras con el SAT |
| Módulo 5. Tu vehículo | Tu apartado para el vehículo y tu decisión sobre seguro y compra. | Vehículo en orden |
| Módulo 6. Accidentes, salud y días sin trabajo | Tu plan ante un accidente y tu fondo para días sin trabajo. |  |
| Módulo 7. Préstamos y fraudes en la ruta | Tu regla contra préstamos caros y fraudes de cuentas. |  |
| Módulo 8. Tu futuro | Tu ahorro para el retiro y tu plan de una página. | Futuro en marcha |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Ingreso real, Derechos e IMSS, Impuestos, Vehículo y accidentes, Futuro.

## 3. Lecciones

# Parte 2. Módulo 1. Tu ingreso real

## M1 U01. Lo que entra no es lo que ganas

**Lo que lograrás:** Calcular tu ingreso real restando gasolina, mantenimiento y datos a lo que te paga la app.

**Para empezar:** Beto ve en la app que esta semana hizo 4,200 pesos y siente que le fue muy bien. El viernes no le alcanza para la renta. En esta lección verás dónde se quedó el dinero.

### Lo esencial (5 minutos)

#### La app muestra el bruto

Lo que ves en la app es lo que entra antes de tus gastos. Para saber lo que ganas de verdad, resta lo que te cuesta trabajar.



#### Lo que te cuesta trabajar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Gasolina o carga | Lo que más pesa. | Cada día. |
| Mantenimiento | Aceite, llantas, frenos. | Aparta cada semana. |
| Datos y celular | Plan, cargador, soporte. | Cada mes. |
| Renta del vehículo | Si no es tuyo. | Cada semana. |

#### La semana de Beto

- Entra en la app: **4,200**
- Gasolina: **900**
- Apartado para mantenimiento: **300**
- Datos: **100**
- Lo que de verdad gana: **2,900**


#### Un caso en un minuto

Beto anotó sus gastos una semana. Ahora sabe que gana 2,900, no 4,200, y hace su presupuesto con esa cifra.

> **Idea clave:** tu ingreso real es lo que entra menos lo que te cuesta trabajar; haz tus cuentas con esa cifra.



#### Comprueba lo que entendiste

1. ¿Qué muestra la app?
*Respuesta:* Lo que entra antes de mis gastos.

2. ¿Qué restas para saber tu ingreso real?
*Respuesta:* Gasolina, mantenimiento, datos y renta del vehículo si no es mío.


#### Para recordar

- La app muestra el bruto.
- Resta lo que te cuesta trabajar.
- Presupuesta con lo real.



### Profundiza (5 minutos más)

#### Mi semana

| Concepto | Monto |
|---|---|
| Entra en la app | |
| Gasolina o carga | |
| Mantenimiento | |
| Datos | |
| Renta del vehículo | |
| **Ingreso real** | |



#### En bici también hay gastos

Llantas, cámaras, frenos, comida extra y el celular. Son menos, pero cuentan.



#### Casos


**Caso 1. La semana de 4,200**

Beto cree que ganó 4,200.
- *¿Qué hace?* Resta sus gastos y hace su presupuesto con lo real.


**Caso 2. El auto rentado**

Don Chava paga 2,500 de renta por semana y no la cuenta.
- *¿Qué hace?* La resta de lo que entra en la app.


**Caso 3. La bici de Kevin**

Kevin cree que en bici no tiene gastos.
- *¿Qué hace?* Anota llantas, frenos y datos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Presupuestar con el bruto | No alcanza | Usa lo real |
| Olvidar el mantenimiento | Sorpresa grande | Aparta cada semana |
| No contar la renta | Crees que ganas más | Réstala |
| No anotar | No sabes | Una semana de prueba |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Don Chava y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es tu ingreso real? a) Lo que te dan de propina los clientes · b) Lo que muestra la app al final del día · c) Lo que entra menos lo que te cuesta trabajar
2. Entran 5,000 y gastas 1,600 en trabajar. ¿Cuánto ganas? a) 5,000 · b) 3,400 · c) 6,600
3. ¿Qué cuenta como gasto de trabajo? a) La renta de tu casa · b) La gasolina · c) Tus vacaciones
**Respuestas:** 1-c: el real. 2-b: 5,000 menos 1,600. 3-b: gasolina.



#### Ponlo en práctica

Entran 3,800, gasolina 700, mantenimiento 250 y datos 100. ¿Cuál es tu ingreso real?
**Respuesta:** 2,750 pesos.



#### A tu plan

Anota una semana completa lo que entra y lo que te cuesta trabajar.



### Para saber más

- **Presupuesto con ingreso variable** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «ingresos variables».

### Palabras clave

- *Ingreso bruto:* lo que entra antes de gastos.
- *Ingreso real:* lo que te queda después de gastos de trabajo.
- *Mantenimiento:* cuidados del vehículo para que no falle.

### Fuentes

CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.

---

## M1 U02. Cuánto ganas por hora

**Lo que lograrás:** Calcular tu ganancia por hora para decidir en qué horarios y zonas conviene trabajar.

**Para empezar:** Mariana trabaja 60 horas a la semana. Su amiga trabaja 40 y gana casi lo mismo. Mariana no entiende por qué. En esta lección calcularás tu ganancia por hora.

### Lo esencial (5 minutos)

#### Divide entre las horas

Toma tu ingreso real de la semana y divídelo entre las horas que estuviste conectada, incluyendo esperas. Esa es tu ganancia por hora.



#### Lo que cambia tu ganancia por hora

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Horario | Horas pico pagan mejor. | Comidas, noches, lluvia. |
| Zona | Viajes cortos o largos. | Regresos vacíos. |
| Esperas | Tiempo conectado sin pedidos. | También cuenta. |
| Gasolina por viaje | Viajes lejanos gastan más. | Réstala. |

#### Compara tus horarios

Anota una semana por bloques (mañana, comida, tarde, noche). Verás qué horas te dejan más y cuáles casi nada.



#### Un caso en un minuto

Mariana ganó 3,600 reales en 60 horas: 60 pesos por hora. En la comida y la noche gana 95; en la tarde, 30. Ahora descansa en la tarde y trabaja menos horas por casi lo mismo.

> **Idea clave:** divide tu ingreso real entre tus horas conectado; trabaja más en las horas que te dejan más.



#### Comprueba lo que entendiste

1. ¿Cómo calculas tu ganancia por hora?
*Respuesta:* Divido mi ingreso real entre las horas conectado, incluyendo esperas.

2. ¿Por qué comparar horarios?
*Respuesta:* Para trabajar más en las horas que me dejan más.


#### Para recordar

- Ingreso real entre horas.
- Las esperas cuentan.
- Compara horarios.



### Profundiza (5 minutos más)

#### La hora de Mariana

- Ingreso real de la semana: **3,600**
- Horas conectada: **60**
- Pesos por hora: **60**


#### El cansancio también cuesta

Más horas no siempre es más dinero. El cansancio aumenta el riesgo de accidentes (módulo 6).



#### Casos


**Caso 1. Sesenta horas**

Mariana trabaja muchas horas y gana poco por hora.
- *¿Qué hace?* Compara sus horarios y trabaja más en los que pagan mejor.


**Caso 2. Las esperas**

Beto no cuenta el tiempo que espera pedidos.
- *¿Qué hace?* Incluye las esperas en sus horas.


**Caso 3. Viajes largos**

Don Chava acepta viajes que lo dejan lejos y regresa vacío.
- *¿Qué hace?* Calcula si le conviene contando el regreso.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Contar solo horas con pedido | Ganancia inflada | Incluye esperas |
| No comparar horarios | Horas que no pagan | Anota por bloques |
| Más horas sin pensar | Cansancio | Mejor horario |
| Olvidar el regreso vacío | Pierdes | Cuéntalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Beto y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Ganas 2,400 reales en 40 horas. ¿Cuánto por hora? a) 2,400 · b) 40 · c) 60
2. ¿Las esperas sin pedido cuentan como horas? a) No · b) Sí · c) Solo si llueve
3. ¿Para qué sirve anotar por bloques de horario? a) Para nada · b) Para ver qué horas te dejan más · c) Para pagar menos impuestos al SAT
**Respuestas:** 1-c: 2,400 entre 40. 2-b: estás conectado. 3-b: comparar.



#### Ponlo en práctica

Ganas 1,200 reales en 15 horas de noche. ¿Cuánto por hora?
**Respuesta:** 80 pesos.



#### A tu plan

Anota una semana tus horas por bloques y calcula tu ganancia por hora en cada uno.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto».

### Palabras clave

- *Ganancia por hora:* lo que te queda por cada hora conectado.
- *Hora pico:* horas con más pedidos.
- *Regreso vacío:* viaje sin pago para volver.

### Fuentes

Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.

---

## M1 U03. Un sueldo fijo en un trabajo variable

**Lo que lograrás:** Darte un «sueldo» fijo semanal y guardar lo que sobra en semanas buenas para las malas.

**Para empezar:** Kevin tuvo una semana de 2,500 y otra de 900. En la buena gastó todo; en la mala pidió prestado. En esta lección verás cómo emparejar.

### Lo esencial (5 minutos)

#### Saca tu promedio

Suma tu ingreso real de las últimas cuatro semanas y divídelo entre cuatro. Ese es tu promedio.



#### Tu sistema de dos bolsas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Sueldo semanal | Un poco menos que tu promedio. | Para tus gastos. |
| Colchón | Lo que sobra en semanas buenas. | Para las malas. |

#### Cómo funciona

En una semana buena, te pagas tu sueldo y lo demás va al colchón. En una mala, completas tu sueldo con el colchón. Así tus gastos no dependen de la suerte de la semana.



#### Un caso en un minuto

Kevin promedió 1,600 por semana. Se paga 1,400. En la semana de 2,500 guardó 1,100; en la de 900 sacó 500 del colchón. Ya no pide prestado.

> **Idea clave:** págate un sueldo un poco menor a tu promedio; lo que sobra en semanas buenas cubre las malas.



#### Comprueba lo que entendiste

1. ¿Cómo sacas tu promedio?
*Respuesta:* Sumo el ingreso real de cuatro semanas y lo divido entre cuatro.

2. ¿Qué haces en una semana mala?
*Respuesta:* Completo mi sueldo con el colchón.


#### Para recordar

- Promedio de cuatro semanas.
- Sueldo un poco menor.
- Colchón para las malas.



### Profundiza (5 minutos más)

#### El promedio de Kevin

- Cuatro semanas: **6,400**
- Semanas: **4**
- Promedio semanal: **1,600**


#### Dónde guardar el colchón

En un apartado o cuenta distinta a la que usas diario. Si lo tienes junto, se gasta.



#### Casos


**Caso 1. La semana buena**

Kevin hizo 2,500.
- *¿Qué hace?* Se paga su sueldo y guarda el resto.


**Caso 2. La semana mala**

Beto hizo 1,800 y su sueldo es 2,600.
- *¿Qué hace?* Completa con su colchón.


**Caso 3. Todo junto**

Mariana guarda el colchón en la tarjeta de diario.
- *¿Qué hace?* Lo pasa a un apartado distinto.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Gastar todo en semanas buenas | Nada para las malas | Guarda el extra |
| Pedir prestado en semanas malas | Deudas | Usa el colchón |
| Sueldo igual al mejor semana | No alcanza | Menor al promedio |
| Colchón en la tarjeta diaria | Se gasta | Apártalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin, Beto y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Cuatro semanas suman 8,000. ¿Cuál es tu promedio? a) 4,000 · b) 8,000 · c) 2,000
2. ¿Cuánto conviene que sea tu sueldo semanal? a) Igual a tu mejor semana · b) Un poco menos que tu promedio · c) Lo que salga cada semana, sin fijarlo
3. Semana mala: ¿de dónde completas? a) De un préstamo · b) De tu colchón · c) De la app
**Respuestas:** 1-c: 8,000 entre 4. 2-b: menor al promedio. 3-b: el colchón.



#### Ponlo en práctica

Tu sueldo es 2,000 y esta semana hiciste 2,700. ¿Cuánto va al colchón?
**Respuesta:** 700 pesos.



#### A tu plan

Calcula tu promedio de cuatro semanas y decide tu sueldo semanal.



### Para saber más

- **Fondo de emergencia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Promedio:* lo que ganas en una semana normal.
- *Colchón:* dinero guardado para semanas malas.
- *Apartado:* espacio aparte en tu cuenta.

### Fuentes

CONDUSEF, ahorro con ingreso variable; consultado el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Tus derechos con la reforma

## M2 U01. ¿Eres persona trabajadora de plataforma?

**Lo que lograrás:** Comprobar si con la reforma te corresponde ser persona trabajadora de plataforma y cómo se calcula tu ingreso neto.

**Para empezar:** Don Chava escuchó que «ahora los de las apps tienen IMSS». Su compañero dice que solo los que trabajan muchas horas. Nadie sabe bien cómo se calcula. En esta lección lo verás.

### Lo esencial (5 minutos)

#### La reforma

Desde el 22 de junio de 2025, la Ley Federal del Trabajo reconoce el trabajo en plataformas digitales. Hay quien genera al menos un salario mínimo mensual de ingreso neto en una misma plataforma. Esa persona es **persona trabajadora de plataforma**, con derechos laborales y seguridad social.



#### Cómo se calcula tu ingreso neto

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En auto | Se descuenta 48% de lo que ganas. | Por costos del vehículo. |
| En moto | Se descuenta 32%. | Por costos. |
| En bici o a pie | Se descuenta 3%. | Por costos. |

#### El umbral de 2026

El salario mínimo mensual de 2026 es 9,582.47 pesos. Por eso necesitas, en bruto y en una misma plataforma: unos 18,428 en auto, 14,092 en moto o 9,879 en bici, al mes.



#### Un caso en un minuto

Don Chava hace unos 21,000 al mes en auto en una sola app. Menos 48%, su ingreso neto es 10,920: pasa el umbral. Le corresponde ser persona trabajadora de plataforma.

> **Idea clave:** si tu ingreso neto en una plataforma llega al salario mínimo mensual, eres persona trabajadora de plataforma con derechos y seguridad social.



#### Comprueba lo que entendiste

1. ¿Cuánto se descuenta en moto para calcular el neto?
*Respuesta:* 32%.

2. ¿Cuál es el salario mínimo mensual de 2026?
*Respuesta:* 9,582.47 pesos.


#### Para recordar

- Ingreso neto en una plataforma.
- Auto 48, moto 32, bici 3.
- Umbral: un salario mínimo.



### Profundiza (5 minutos más)

#### El neto de Don Chava

- Bruto al mes en auto: **21,000**
- 48% de descuento: **10,080**
- Ingreso neto: pasa el umbral: **10,920**


#### Si trabajas en dos apps

El umbral se cuenta por plataforma. Si repartes lo mismo entre dos apps, puede que en ninguna llegues. Es algo a considerar al decidir dónde trabajar más.



#### Casos


**Caso 1. ¿Me toca?**

Don Chava no sabe si le corresponde.
- *¿Qué hace?* Calcula su ingreso neto en la app donde más trabaja.


**Caso 2. Dos apps**

Beto reparte 8,000 en cada una de dos apps en moto.
- *¿Qué hace?* Revisa que en ninguna llega al umbral y decide si se concentra en una.


**Caso 3. En bici**

Kevin hace 10,500 al mes en bici en una app.
- *¿Qué hace?* Calcula: con 3% de descuento sí llega.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que es por horas | Calculas mal | Es por ingreso neto |
| Sumar dos apps | No aplica así | Por plataforma |
| Usar el porcentaje equivocado | Error | Según tu vehículo |
| No revisar | Pierdes derechos | Haz la cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chava, Beto y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Desde cuándo está vigente la reforma de plataformas? a) Desde el 22 de junio de 2025 · b) Desde 2010, con la primera app · c) Todavía no
2. ¿Cuánto se descuenta en auto para calcular el neto? a) 3% · b) 48% · c) 32%
3. ¿El umbral se cuenta sumando todas tus apps? a) Sí · b) Solo si son dos apps del mismo tipo · c) No, por plataforma
**Respuestas:** 1-a: junio de 2025. 2-b: 48%. 3-c: por plataforma.



#### Ponlo en práctica

Haces 16,000 al mes en moto en una app. ¿Cuál es tu ingreso neto y llegas al umbral?
**Respuesta:** 10,880 pesos (16,000 menos 32%); sí llegas.



#### A tu plan

Calcula tu ingreso neto del último mes en la app donde más trabajas.



### Para saber más

- **Preguntas frecuentes de la reforma** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** «trabajo en plataformas digitales».

### Palabras clave

- *Persona trabajadora de plataforma:* quien llega al umbral de ingreso neto en una app.
- *Ingreso neto:* lo que queda después del descuento según tu vehículo.
- *Umbral:* la cantidad mínima para entrar.

### Fuentes

Decreto de reforma a la Ley Federal del Trabajo en materia de plataformas digitales (DOF, 24 de diciembre de 2024); STPS, factores de exclusión 2026; consultados el 5 de octubre de 2026.

---

## M2 U02. Aguinaldo, vacaciones y reparto de utilidades

**Lo que lograrás:** Identificar las prestaciones proporcionales que te corresponden como persona trabajadora de plataforma.

**Para empezar:** En diciembre, Mariana vio un depósito extra en la app y pensó que era un error. Era la parte proporcional de su aguinaldo. En esta lección verás qué más te toca.

### Lo esencial (5 minutos)

#### Lo que te corresponde

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aguinaldo | Parte proporcional. | En diciembre. |
| Vacaciones y prima | Parte proporcional. | Según la ley. |
| Reparto de utilidades | Si trabajas más de 288 horas al año. | Cuando la empresa tiene utilidades. |
| IMSS e Infonavit | Seguridad social completa. | Módulo 3. |

#### Las 288 horas

Para el reparto de utilidades, además de ser persona trabajadora de plataforma, necesitas trabajar más de 288 horas efectivas al año en esa plataforma.



#### Revisa tus pagos

Las prestaciones proporcionales se pagan junto con lo que ganas. Revisa el detalle de tus pagos en la app y guarda capturas.



#### Un caso en un minuto

Mariana revisó su detalle: el depósito era su aguinaldo proporcional. Ahora guarda una captura cada mes para comprobar lo que le pagan.

> **Idea clave:** como persona trabajadora de plataforma tienes aguinaldo, vacaciones y prima proporcionales, y reparto de utilidades si pasas de 288 horas.



#### Comprueba lo que entendiste

1. ¿Cuántas horas al año necesitas para el reparto de utilidades?
*Respuesta:* Más de 288 horas efectivas.

2. ¿Cómo se pagan las prestaciones?
*Respuesta:* De forma proporcional, junto con lo que ganas.


#### Para recordar

- Aguinaldo proporcional.
- Vacaciones y prima.
- Utilidades: más de 288 horas.



### Profundiza (5 minutos más)

#### Mis prestaciones

| Prestación | ¿La veo en mis pagos? |
|---|---|
| Aguinaldo | |
| Vacaciones | |
| Prima vacacional | |
| Reparto de utilidades | |



#### Guarda capturas

Las apps cambian. Una captura mensual de tus pagos y su detalle es tu prueba si necesitas reclamar.



#### Casos


**Caso 1. El depósito extra**

Mariana cree que el aguinaldo es un error.
- *¿Qué hace?* Revisa el detalle y guarda captura.


**Caso 2. Pocas horas**

Kevin trabaja 200 horas al año en una app.
- *¿Le toca reparto de utilidades?* No, porque no pasa de 288 horas.


**Caso 3. No ve nada**

Don Chava pasa el umbral y no ve ninguna prestación.
- *¿Qué hace?* Junta capturas y pregunta en soporte; si no, reclama (U03).


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No revisar el detalle | No sabes qué te pagan | Revísalo |
| Sin capturas | No hay prueba | Una al mes |
| Creer que no te toca | No reclamas | Conoce tus derechos |
| Olvidar las 288 horas | Expectativa errónea | Revisa tus horas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Kevin y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué te corresponde como persona trabajadora de plataforma? a) Aguinaldo y vacaciones proporcionales · b) Nada · c) Solo las propinas de los clientes
2. ¿Cuántas horas al año para el reparto de utilidades? a) 100 · b) Más de 288 · c) 2,000
3. ¿Qué guardas cada mes? a) Nada · b) Los tickets de gasolina de otros · c) Capturas del detalle de pagos
**Respuestas:** 1-a: proporcionales. 2-b: 288. 3-c: capturas.



#### Ponlo en práctica

Trabajas 6 horas al día, 5 días a la semana, 10 semanas. ¿Pasas de 288 horas?
**Respuesta:** Sí: son 300 horas.



#### A tu plan

Revisa el detalle de tus pagos y guarda una captura este mes.



### Para saber más

- **Derechos en plataformas** (STPS · español): https://www.gob.mx/stps — **Qué buscar:** «plataformas digitales preguntas frecuentes».

### Palabras clave

- *Proporcional:* parte según lo que trabajaste.
- *Prima vacacional:* pago extra por vacaciones.
- *Reparto de utilidades:* parte de las ganancias de la empresa.

### Fuentes

Ley Federal del Trabajo, reforma en materia de plataformas digitales; STPS; consultados el 5 de octubre de 2026.

---

## M2 U03. Desactivaciones y cómo reclamar

**Lo que lograrás:** Decidir qué hacer si la app te desactiva o te paga mal, y a dónde acudir.

**Para empezar:** Una noche, la app desactivó a Beto «por mal comportamiento» sin decirle qué pasó. Se quedó sin ingreso de un día para otro. En esta lección verás qué derechos tienes.

### Lo esencial (5 minutos)

#### Transparencia

La reforma obliga a las plataformas a explicar cómo sus sistemas asignan pedidos, evalúan y desactivan. Tienes derecho a saber por qué te desactivaron y a pedir revisión.



#### Los pasos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Junta pruebas | Capturas de pagos, mensajes y calificaciones. | Con fechas. |
| Pide la revisión | Por el canal oficial de la app. | Por escrito. |
| Si no resuelven | Centro de Conciliación Laboral de tu estado. | Gratuito. |
| Orientación | PROFEDET, 800 911 7877. | Sin costo. |

#### Usa tu colchón

Mientras se resuelve, el colchón del módulo 1 te ayuda a no pedir prestado.



#### Un caso en un minuto

Beto pidió por escrito la razón de su desactivación y la revisión. No le respondieron en una semana. Fue a la PROFEDET, que lo orientó para ir al Centro de Conciliación. Lo reactivaron.

> **Idea clave:** si te desactivan, pide la razón y la revisión por escrito; si no resuelven, acude a la PROFEDET o al Centro de Conciliación.



#### Comprueba lo que entendiste

1. ¿Qué pides si te desactivan?
*Respuesta:* La razón y la revisión, por escrito.

2. ¿Quién te orienta sin costo?
*Respuesta:* La PROFEDET, 800 911 7877.


#### Para recordar

- Pide la razón.
- Por escrito.
- PROFEDET y Conciliación.



### Profundiza (5 minutos más)

#### Mi expediente

| Prueba | La tengo |
|---|---|
| Capturas de pagos | |
| Mensajes con soporte | |
| Mis calificaciones | |
| Fecha de la desactivación | |



#### No pagues por «reactivar»

Hay personas que cobran por «desbloquear» cuentas. No pagues ni des tu contraseña: es fraude (módulo 7).



#### Casos


**Caso 1. La desactivación**

Beto fue desactivado sin explicación.
- *¿Qué hace?* Pide por escrito la razón y la revisión.


**Caso 2. Sin respuesta**

Pasó una semana y nadie le contesta.
- *¿Qué hace?* Acude a la PROFEDET para orientarse.


**Caso 3. El que desbloquea**

Le ofrecen a Beto desbloquear su cuenta por 500 pesos.
- *¿Qué hace?* No paga ni da su contraseña.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Quedarte sin hacer nada | Pierdes ingreso | Pide revisión |
| Reclamar sin pruebas | Difícil | Junta capturas |
| Pagar por desbloquear | Fraude | Canal oficial |
| No conocer la PROFEDET | Sin orientación | 800 911 7877 |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te desactivan sin explicación. ¿Qué haces primero? a) Pides por escrito la razón y la revisión · b) Abres otra cuenta con el nombre de un familiar para seguir trabajando · c) Nada
2. ¿Quién te orienta sin costo? a) Un gestor · b) La PROFEDET · c) El que desbloquea cuentas
3. ¿Qué guardas como prueba? a) Solo tu memoria de lo que pasó · b) Nada · c) Capturas con fechas
**Respuestas:** 1-a: por escrito. 2-b: PROFEDET. 3-c: capturas.



#### Ponlo en práctica

Tu promedio semanal es 2,500 y te desactivan dos semanas. ¿Cuánto necesitas de tu colchón?
**Respuesta:** 5,000 pesos.



#### A tu plan

Guarda el teléfono de la PROFEDET y empieza tu carpeta de capturas.



### Para saber más

- **PROFEDET** (Gobierno de México · español): https://www.gob.mx/profedet — **Qué buscar:** cómo pedir asesoría laboral sin costo por teléfono o en línea; teléfono 800 911 7877.
- **Centros de Conciliación Laboral** de tu estado — **Qué buscar:** «centro de conciliación laboral» y tu estado.

### Palabras clave

- *Desactivación:* cuando la app te bloquea.
- *Transparencia algorítmica:* derecho a saber cómo decide el sistema.
- *Conciliación:* acuerdo con ayuda de una autoridad.

### Fuentes

Ley Federal del Trabajo, reforma en materia de plataformas digitales; PROFEDET; consultados el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Tu IMSS, tu Afore y tu Infonavit

## M3 U01. Lo que te da el IMSS completo

**Lo que lograrás:** Identificar qué te da el IMSS si eres persona trabajadora de plataforma y cómo comprobar que estás dado de alta.

**Para empezar:** Mariana pasa el umbral, pero nunca ha ido a una clínica del IMSS. No sabe si está dada de alta ni a qué clínica le toca. En esta lección lo revisarás.

### Lo esencial (5 minutos)

#### Lo que te da el IMSS completo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Médico y medicinas | Para ti y tu familia registrada. | Clínica asignada. |
| Riesgos de trabajo | Accidentes en la ruta. | Atención e incapacidad. |
| Guardería | Para tus hijos pequeños. | Según requisitos. |
| Afore e Infonavit | Ahorro para el retiro y vivienda. | Suma semanas. |

#### Comprueba tu alta

En la app o la página del IMSS puedes consultar tu vigencia de derechos y tu número de seguridad social con tu CURP. Si pasas el umbral y no apareces, pregunta en soporte de la plataforma.



#### Registra a tu familia

Para que tu familia tenga servicio médico, tienes que registrarla como beneficiaria en el IMSS.



#### Un caso en un minuto

Mariana consultó su vigencia: estaba dada de alta. Registró a su hija como beneficiaria y le asignaron clínica.

> **Idea clave:** si pasas el umbral, tienes IMSS completo; comprueba tu alta y registra a tu familia.



#### Comprueba lo que entendiste

1. ¿Qué incluye el IMSS completo?
*Respuesta:* Médico, riesgos de trabajo, guardería, Afore e Infonavit.

2. ¿Qué haces para que tu familia tenga servicio?
*Respuesta:* La registro como beneficiaria.


#### Para recordar

- Comprueba tu alta.
- Registra a tu familia.
- Suma semanas.



### Profundiza (5 minutos más)

#### Mi IMSS

| Dato | Lo tengo |
|---|---|
| Número de seguridad social | |
| Clínica asignada | |
| Beneficiarios registrados | |
| Vigencia comprobada | |



#### Puedes entrar y salir

Si un mes no llegas al umbral, ese mes no tienes la cobertura completa. Revisa tu vigencia cuando cambien tus ingresos.



#### Casos


**Caso 1. ¿Estoy dada de alta?**

Mariana no sabe si tiene IMSS.
- *¿Qué hace?* Consulta su vigencia con su CURP.


**Caso 2. La hija**

La hija de Mariana no tiene servicio médico.
- *¿Qué hace?* La registra como beneficiaria.


**Caso 3. No aparece**

Don Chava pasa el umbral y no aparece en el IMSS.
- *¿Qué hace?* Pregunta en soporte y guarda capturas de sus ingresos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No comprobar | No sabes si tienes | Consulta |
| No registrar a tu familia | Sin servicio | Regístrala |
| Creer que es para siempre | Cambia por mes | Revisa |
| No reclamar si no apareces | Pierdes derechos | Soporte y capturas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Con qué consultas tu vigencia en el IMSS? a) Con la placa · b) Con tu licencia · c) Con tu CURP
2. ¿Qué haces para que tu hija tenga IMSS? a) Nada · b) La registras como beneficiaria · c) Usas tu credencial cuando ella vaya
3. Un mes no llegas al umbral. ¿Qué pasa? a) Nada cambia · b) Ese mes no tienes cobertura completa · c) Pierdes para siempre todas las semanas que ya tenías
**Respuestas:** 1-c: CURP. 2-b: beneficiaria. 3-b: depende del mes.



#### Ponlo en práctica

Escribe los dos datos del IMSS que debes tener a la mano.
**Respuesta:** Mi número de seguridad social y mi clínica asignada.



#### A tu plan

Consulta tu vigencia en el IMSS y llena tu tabla.



### Para saber más

- **Vigencia de derechos** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «vigencia de derechos» y «plataformas digitales».

### Palabras clave

- *Vigencia:* que tu derecho está activo.
- *Beneficiario:* familiar con servicio médico por ti.
- *Número de seguridad social:* tu número en el IMSS.

### Fuentes

IMSS, incorporación de personas trabajadoras de plataformas digitales; consultado el 5 de octubre de 2026.

---

## M3 U02. Si no llegas al umbral

**Lo que lograrás:** Identificar qué protección tienes si no llegas al umbral y cómo completarla.

**Para empezar:** Kevin reparte en bici unas horas y gana 6,000 al mes. No llega al umbral. Cree que no tiene ninguna protección si se cae. En esta lección verás que sí tiene algo.

### Lo esencial (5 minutos)

#### Riesgos de trabajo

Aunque no llegues al umbral, mientras estás conectado tienes cobertura del IMSS por **riesgos de trabajo**: accidentes que te pasen trabajando.



#### Cómo completar tu protección

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IMSS voluntario | Afiliarte por tu cuenta. | Pagas una cuota. |
| IMSS-Bienestar | Si no tienes seguridad social. | Centro de salud. |
| Guardadito de salud | Para lo que no cubren. | Siempre ayuda. |

#### Si estudias

Las y los estudiantes de escuelas públicas pueden tener IMSS como estudiantes. Pregunta en tu escuela.



#### Un caso en un minuto

Kevin supo que su accidente en ruta está cubierto por riesgos de trabajo. Además se dio de alta en el IMSS como estudiante y empezó un guardadito de salud.

> **Idea clave:** aunque no llegues al umbral, tienes riesgos de trabajo mientras estás conectado; complétalo con IMSS voluntario, como estudiante o IMSS-Bienestar.



#### Comprueba lo que entendiste

1. ¿Qué cobertura tienes aunque no llegues al umbral?
*Respuesta:* Riesgos de trabajo mientras estoy conectado.

2. ¿Qué opción tienes si estudias en escuela pública?
*Respuesta:* IMSS como estudiante.


#### Para recordar

- Riesgos de trabajo siempre.
- Completa tu protección.
- Guardadito de salud.



### Profundiza (5 minutos más)

#### Conectado significa en la app

La cobertura por riesgos de trabajo aplica mientras estás conectado a la plataforma. Un accidente fuera de la app no entra ahí.



#### ¿Te conviene acercarte al umbral?

Si estás cerca, concentrarte en una sola app puede darte la cobertura completa (M2 U01).



#### Casos


**Caso 1. «No tengo nada»**

Kevin cree que no tiene protección.
- *¿Qué hace?* Sabe que tiene riesgos de trabajo y revisa cómo completarla.


**Caso 2. Estudiante**

Kevin estudia en una universidad pública.
- *¿Qué hace?* Pregunta por su alta como estudiante.


**Caso 3. Cerca del umbral**

Beto está a 1,500 pesos del umbral en una app.
- *¿Qué hace?* Evalúa concentrarse en esa app.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no tienes nada | No usas tu cobertura | Riesgos de trabajo |
| No completar | Sin médico | IMSS voluntario o Bienestar |
| Olvidar el IMSS estudiantil | Pierdes servicio | Pregunta |
| Repartir en muchas apps | No llegas a ninguna | Evalúa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. No llegas al umbral. ¿Qué cobertura tienes conectado? a) Todo el IMSS, igual que un empleado · b) Ninguna · c) Riesgos de trabajo
2. Estudias en escuela pública. ¿Qué puedes tener? a) IMSS como estudiante · b) Nada · c) Un préstamo para tus estudios
3. Te accidentas fuera de la app. ¿Cubre riesgos de trabajo? a) Sí, siempre · b) No, solo conectado · c) Solo de noche, cuando hay más riesgo
**Respuestas:** 1-c: riesgos. 2-a: estudiante. 3-b: conectado.



#### Ponlo en práctica

Ganas 13,000 al mes en moto en una app. ¿Llegas al umbral (neto de 9,582.47)?
**Respuesta:** No: tu neto es 8,840 (13,000 menos 32%).



#### A tu plan

Revisa qué cobertura tienes hoy y elige cómo completarla.



### Para saber más

- **IMSS para estudiantes** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «estudiantes».
- **IMSS-Bienestar** (Gobierno de México · español): https://www.gob.mx/imss-bienestar — **Qué buscar:** tu unidad médica más cercana y qué servicios dan sin costo.

### Palabras clave

- *Riesgo de trabajo:* accidente o enfermedad por trabajar.
- *Conectado:* activo en la app.
- *IMSS voluntario:* afiliarte por tu cuenta.

### Fuentes

IMSS, cobertura por riesgos de trabajo para personas trabajadoras independientes de plataformas; consultado el 5 de octubre de 2026.

---

## M3 U03. Tu Afore y tus semanas

**Lo que lograrás:** Localizar tu Afore y entender cómo las semanas cotizadas por la plataforma te acercan a una pensión.

**Para empezar:** Don Chava tiene 47 años y nunca pensó en su retiro: «los de las apps no tenemos eso». Ahora que tiene IMSS, cada mes suma semanas. En esta lección verás cuánto le faltan.

### Lo esencial (5 minutos)

#### Cada mes con IMSS suma

Los meses en que eres persona trabajadora de plataforma cotizas al IMSS: sumas semanas y la plataforma aporta a tu Afore.



#### Revisa tres cosas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu Afore | Con tu CURP en AforeMóvil. | Dónde está. |
| Tus semanas | Constancia del IMSS. | Cuántas tienes. |
| Las que faltan | Ley 97 en 2026: 875. | Suben 25 al año. |

#### Agrega tú

Puedes hacer aportaciones voluntarias desde 50 pesos en tiendas o en la app. En los meses que no llegas al umbral, tus aportaciones siguen sumando a tu ahorro.



#### Un caso en un minuto

Don Chava tenía 320 semanas de cuando trabajó en una fábrica. Con la plataforma suma 52 al año. Además aporta 200 al mes a su Afore.

> **Idea clave:** cada mes con IMSS suma semanas; localiza tu Afore y agrega aportaciones voluntarias.



#### Comprueba lo que entendiste

1. ¿Qué suma cada mes que eres persona trabajadora de plataforma?
*Respuesta:* Semanas cotizadas y aportaciones a mi Afore.

2. ¿Cuántas semanas pide la Ley 97 en 2026?
*Respuesta:* 875.


#### Para recordar

- Cada mes suma.
- Localiza tu Afore.
- Aporta tú también.



### Profundiza (5 minutos más)

#### Lo que le falta a Don Chava

- Requisito Ley 97 en 2026: **875**
- Semanas que tiene: **320**
- Semanas que le faltan: **555**


#### Unas 52 por año

Un año completo con IMSS suma unas 52 semanas. Para 555 hacen falta casi 11 años; por eso conviene no salir del umbral y empezar pronto.



#### Casos


**Caso 1. «Eso no es para nosotros»**

Don Chava cree que no tiene retiro.
- *¿Qué hace?* Localiza su Afore y consulta sus semanas.


**Caso 2. Meses abajo del umbral**

Beto no siempre llega al umbral.
- *¿Qué hace?* Hace aportaciones voluntarias esos meses.


**Caso 3. Afore desconocida**

Kevin no sabe si tiene Afore.
- *¿Qué hace?* La busca con su CURP en AforeMóvil.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no tienes retiro | No ahorras | Revisa |
| No consultar semanas | No sabes cuánto falta | Consulta |
| No aportar en meses bajos | Huecos | Aportación voluntaria |
| Esperar a los 60 | Ya no da tiempo | Empieza ya |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chava, Beto y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde localizas tu Afore? a) En el taller donde arreglas la moto · b) En la app de reparto, en tu perfil · c) En AforeMóvil con tu CURP
2. Tienes 500 semanas y eres Ley 97. ¿Cuántas te faltan en 2026? a) 375 · b) 500 · c) 75
3. ¿Desde cuánto puedes hacer una aportación voluntaria? a) 5,000 · b) 50 · c) No se puede
**Respuestas:** 1-c: AforeMóvil. 2-a: 875 menos 500. 3-b: desde 50.



#### Ponlo en práctica

Aportas 150 al mes durante 10 años. ¿Cuánto aportas, sin rendimientos?
**Respuesta:** 18,000 pesos.



#### A tu plan

Localiza tu Afore, consulta tus semanas y decide una aportación mensual.



### Para saber más

- **AforeMóvil** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «AforeMóvil».
- **Semanas cotizadas** (IMSS · español): https://serviciosdigitales.imss.gob.mx — **Qué buscar:** tu constancia de semanas cotizadas, que se descarga sin costo.

### Palabras clave

- *Semanas cotizadas:* semanas con IMSS.
- *Afore:* tu cuenta de ahorro para el retiro.
- *Aportación voluntaria:* lo que tú agregas.

### Fuentes

IMSS; CONSAR; consultados el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Tus impuestos

## M4 U01. Lo que la app retiene de impuestos

**Lo que lograrás:** Explicar las retenciones de ISR e IVA que hace la plataforma y por qué conviene tener RFC.

**Para empezar:** Beto vio en su resumen «retención ISR» e «IVA retenido» y pensó que la app le estaba robando. Su compañero, que no tiene RFC, le retienen mucho más. En esta lección verás por qué.

### Lo esencial (5 minutos)

#### Las plataformas retienen

Las plataformas de transporte y entrega retienen impuestos de lo que ganas y los pagan al SAT por ti. Con RFC: **2.1% de ISR y 8% de IVA**.



#### Con RFC y sin RFC

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Con RFC | ISR 2.1% e IVA 8%. | Lo normal. |
| Sin RFC | ISR 20% e IVA 16%. | Mucho más. |

#### La diferencia es grande

Sin RFC, de cada 1,000 pesos te retienen 200 de ISR en lugar de 21. Darte de alta en el RFC y registrarlo en la app te ahorra mucho.



#### Un caso en un minuto

El compañero de Beto sacó su RFC y lo registró en la app. Su retención de ISR bajó de 20% a 2.1%.

> **Idea clave:** con RFC te retienen 2.1% de ISR y 8% de IVA; sin RFC, 20% y 16%. Regístralo en la app.



#### Comprueba lo que entendiste

1. ¿Cuánto ISR te retienen con RFC?
*Respuesta:* 2.1%.

2. ¿Y sin RFC?
*Respuesta:* 20%.


#### Para recordar

- Con RFC: 2.1% y 8%.
- Sin RFC: 20% y 16%.
- Registra tu RFC.



### Profundiza (5 minutos más)

#### Con y sin RFC (por cada 10,000)

- ISR con RFC: **210**
- ISR sin RFC: **2,000**
- Diferencia: **1,790**


#### Tus constancias

La plataforma debe darte constancias de lo que te retuvo. Descárgalas y guárdalas: las necesitas para tus trámites con el SAT.



#### Casos


**Caso 1. «Me roban»**

Beto cree que la retención es un robo.
- *¿Qué hace?* Entiende que es el pago de sus impuestos al SAT.


**Caso 2. Sin RFC**

Al compañero de Beto le retienen 20%.
- *¿Qué hace?* Saca su RFC y lo registra en la app.


**Caso 3. Las constancias**

Mariana nunca ha descargado sus constancias.
- *¿Qué hace?* Las descarga y las guarda.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No tener RFC | Te retienen 20% | Sácalo |
| No registrarlo en la app | Te siguen reteniendo de más | Regístralo |
| No guardar constancias | Problemas con el SAT | Guárdalas |
| Creer que es un robo | No entiendes | Es tu impuesto |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, su compañero y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuánto IVA te retienen con RFC? a) 8% · b) 16% · c) Nada
2. Ganas 5,000. ¿Cuánto ISR te retienen con RFC? a) 1,000 · b) 105 · c) 500
3. ¿Qué haces con tus constancias de retención? a) Las tiras · b) Las vendes a un gestor · c) Las descargas y guardas
**Respuestas:** 1-a: 8%. 2-b: 2.1% de 5,000. 3-c: guárdalas.



#### Ponlo en práctica

Ganas 8,000 sin RFC. ¿Cuánto ISR te retienen? ¿Y con RFC?
**Respuesta:** Sin RFC 1,600; con RFC 168.



#### A tu plan

Revisa en la app si tienes tu RFC registrado y descarga tus constancias.



### Para saber más

- **Plataformas tecnológicas** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «plataformas tecnológicas».

### Palabras clave

- *Retención:* impuesto que te quitan y pagan por ti.
- *ISR:* impuesto sobre la renta.
- *IVA:* impuesto al valor agregado.

### Fuentes

SAT, régimen de plataformas tecnológicas y Ley de Ingresos 2026; consultados el 5 de octubre de 2026.

---

## M4 U02. Tu RFC y tu e.firma

**Lo que lograrás:** Darte de alta en el RFC en el régimen de plataformas tecnológicas y tener tus accesos en orden.

**Para empezar:** Kevin quiere sacar su RFC, pero en internet le cobran 600 pesos «por el trámite». En esta lección verás que lo puede hacer él.

### Lo esencial (5 minutos)

#### El trámite es sin costo

La inscripción al RFC es sin costo. Puedes hacerla en el portal del SAT con tu CURP o en una oficina del SAT con cita.



#### Lo que necesitas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| CURP | Para inscribirte. | Impresa o en el celular. |
| Correo | Tuyo, que uses. | Ahí llegan avisos. |
| Domicilio | Donde vives. | Para el registro. |
| Contraseña o e.firma | Tus accesos al SAT. | Solo tuyos. |

#### Elige el régimen correcto

Para el trabajo con apps, el régimen es el de **actividades empresariales con ingresos a través de plataformas tecnológicas**. Si tienes dudas, pregunta en el SAT.



#### Un caso en un minuto

Kevin se inscribió en el portal del SAT con su CURP, sacó su contraseña y registró su RFC en la app. No pagó nada.

> **Idea clave:** el RFC es sin costo; inscríbete en el régimen de plataformas y no compartas tus accesos.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta inscribirte al RFC?
*Respuesta:* Nada; es sin costo.

2. ¿Qué régimen eliges?
*Respuesta:* El de ingresos a través de plataformas tecnológicas.


#### Para recordar

- Sin costo.
- Régimen de plataformas.
- Accesos solo tuyos.



### Profundiza (5 minutos más)

#### No compartas tu contraseña ni tu e.firma

Con ellas alguien puede emitir facturas o hacer trámites a tu nombre. Guárdalas como guardas tu NIP.



#### Tu constancia de situación fiscal

Descárgala del portal del SAT. Te la pueden pedir la plataforma o un banco.



#### Casos


**Caso 1. Los 600 pesos**

Le cobran a Kevin por sacar su RFC.
- *¿Qué hace?* Lo saca él sin costo en el portal del SAT.


**Caso 2. El régimen**

Mariana no sabe qué régimen poner.
- *¿Qué hace?* Elige plataformas tecnológicas y, si duda, pregunta en el SAT.


**Caso 3. La e.firma prestada**

Un conocido le pide a Don Chava su e.firma para «facturar unas cosas».
- *¿Qué hace?* No la presta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por el RFC | Gasto inútil | Es sin costo |
| Régimen equivocado | Problemas | Plataformas |
| Prestar la e.firma | Facturas falsas a tu nombre | Nunca |
| Correo que no usas | No ves avisos | Uno tuyo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin, Mariana y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué necesitas para inscribirte al RFC en línea? a) Tu CURP · b) Una factura · c) Un aval
2. ¿Se presta la e.firma? a) A conocidos sí · b) Nunca · c) Solo a la familia
3. ¿Qué régimen es para las apps? a) Sueldos y salarios · b) Arrendamiento, por usar tu vehículo · c) Plataformas tecnológicas
**Respuestas:** 1-a: CURP. 2-b: nunca. 3-c: plataformas.



#### Ponlo en práctica

Escribe los cuatro datos que necesitas para tu RFC.
**Respuesta:** CURP, correo, domicilio y una contraseña o e.firma.



#### A tu plan

Si no tienes RFC, inscríbete esta semana y regístralo en tu app.



### Para saber más

- **Inscripción al RFC** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «inscripción al RFC con CURP».

### Palabras clave

- *RFC:* tu registro ante el SAT.
- *e.firma:* firma electrónica para trámites.
- *Régimen fiscal:* tipo de actividad que declaras.

### Fuentes

SAT, inscripción al RFC y régimen de plataformas tecnológicas; consultado el 5 de octubre de 2026.

---

## M4 U03. Al corriente con el SAT

**Lo que lograrás:** Identificar qué revisar cada año para estar al corriente con el SAT con tus ingresos de apps.

**Para empezar:** A Mariana le llegó un aviso del SAT a su correo y se asustó. No sabe si debe algo ni si tenía que presentar alguna declaración. En esta lección verás qué revisar.

### Lo esencial (5 minutos)

#### Revisa tu situación

En el portal del SAT puedes ver tu opinión de cumplimiento: si estás al corriente o te falta algo.



#### Lo que puede aplicarte

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Retención como pago | En algunos casos, lo que te retiene la app puede ser tu pago. | Revisa si te aplica. |
| Declaración anual | Si tienes otros ingresos o te corresponde. | En abril. |
| Buzón tributario | Avisos del SAT. | Revísalo. |

#### Si tienes dudas

El SAT da orientación sin costo por teléfono, chat y en oficinas. Pregunta con tus constancias a la mano antes de pagar a un gestor.



#### Un caso en un minuto

Mariana revisó su opinión de cumplimiento: estaba al corriente. El aviso era un recordatorio. Ahora revisa su buzón cada mes.

> **Idea clave:** revisa tu opinión de cumplimiento y tu buzón; si dudas, pregunta al SAT con tus constancias en la mano.



#### Comprueba lo que entendiste

1. ¿Dónde ves si estás al corriente?
*Respuesta:* En la opinión de cumplimiento del portal del SAT.

2. ¿Qué tienes a la mano al preguntar?
*Respuesta:* Mis constancias de retención.


#### Para recordar

- Opinión de cumplimiento.
- Buzón tributario.
- Pregunta al SAT.



### Profundiza (5 minutos más)

#### Abril

Las personas físicas presentan su declaración anual en abril. Revisa si te corresponde según tus ingresos.



#### Cuidado con mensajes falsos del SAT

Hay correos falsos que piden datos o pagos. El SAT no te pide contraseñas por correo; entra siempre tú al portal.



#### Casos


**Caso 1. El aviso**

Mariana recibe un aviso del SAT.
- *¿Qué hace?* Revisa su opinión de cumplimiento en el portal.


**Caso 2. El gestor**

Le ofrecen a Beto «arreglar su SAT» por 2,000.
- *¿Qué hace?* Primero pregunta en la orientación del SAT.


**Caso 3. El correo falso**

Le llega a Kevin un correo del «SAT» pidiendo su contraseña.
- *¿Qué hace?* No responde y entra él al portal.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ignorar avisos | Multas | Revisa |
| Pagar gestores sin preguntar | Gasto | Orientación del SAT |
| Responder correos falsos | Robo | Entra tú |
| Perder constancias | No puedes comprobar | Guárdalas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Beto y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde ves si estás al corriente con el SAT? a) En la opinión de cumplimiento · b) En la app de reparto, en tu perfil · c) En el banco donde cobras
2. Te piden tu contraseña por correo «del SAT». ¿Qué es? a) Normal · b) Una actualización · c) Fraude
3. ¿En qué mes se presenta la declaración anual de personas físicas? a) Julio · b) Diciembre · c) Abril
**Respuestas:** 1-a: opinión de cumplimiento. 2-c: el SAT no la pide. 3-c: abril.



#### Ponlo en práctica

Escribe dos cosas que revisas cada mes con el SAT.
**Respuesta:** Mi buzón tributario y mi opinión de cumplimiento.



#### A tu plan

Revisa tu opinión de cumplimiento y activa tu buzón tributario.



### Para saber más

- **Opinión de cumplimiento** (SAT · español): https://www.sat.gob.mx — **Qué buscar:** «opinión del cumplimiento».
- **Orientación** (SAT · español): MarcaSAT 55 627 22 728.

### Palabras clave

- *Opinión de cumplimiento:* constancia de si estás al corriente.
- *Buzón tributario:* canal de avisos del SAT.
- *Declaración anual:* reporte de tus ingresos del año.

### Fuentes

SAT, opinión de cumplimiento y buzón tributario; consultado el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Tu vehículo

## M5 U01. El apartado del vehículo

**Lo que lograrás:** Apartar cada semana para mantenimiento y reparaciones de tu vehículo.

**Para empezar:** A la moto de Beto se le rompió la cadena y le cambiaron llantas el mismo mes: 3,200 pesos. No tenía nada apartado y estuvo cuatro días sin trabajar. En esta lección harás tu apartado.

### Lo esencial (5 minutos)

#### Tu vehículo es tu herramienta

Si se descompone, no trabajas. El mantenimiento no es un gasto sorpresa: se sabe que va a llegar.



#### Lo que siempre llega

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Aceite | Cada cierto kilometraje. | Fijo. |
| Llantas | Se gastan con el uso. | Cada tantos meses. |
| Frenos y cadena | Desgaste normal. | Revisa. |
| Verificación y tenencia o refrendo | Cada año. | Según tu estado. |

#### Calcula tu apartado

Suma lo que gastaste en el año en mantenimiento y divídelo entre 52 semanas. Ese es tu apartado semanal.



#### Un caso en un minuto

Beto calculó que al año gasta unos 10,400 en su moto: 200 por semana. Ahora los aparta cada viernes. La siguiente reparación no lo detuvo.

> **Idea clave:** tu vehículo es tu herramienta; aparta cada semana lo que gastas al año en mantenimiento entre 52.



#### Comprueba lo que entendiste

1. ¿Cómo calculas tu apartado semanal?
*Respuesta:* Divido el gasto anual en mantenimiento entre 52.

2. ¿Por qué el mantenimiento no es sorpresa?
*Respuesta:* Porque se sabe que va a llegar.


#### Para recordar

- Tu vehículo es tu herramienta.
- Apartado semanal.
- Gasto anual entre 52.



### Profundiza (5 minutos más)

#### El apartado de Beto

- Mantenimiento al año: **10,400**
- Semanas: **52**
- Apartado por semana: **200**


#### Mi mantenimiento al año

| Concepto | Costo | Veces al año | Total |
|---|---|---|---|
| Aceite | | | |
| Llantas | | | |
| Frenos y cadena | | | |
| Trámites | | | |
| **Total** | | | |



#### Casos


**Caso 1. La cadena y las llantas**

A Beto le llegaron dos gastos el mismo mes.
- *¿Qué hace para la próxima?* Aparta cada semana para mantenimiento.


**Caso 2. Sin saber cuánto**

Mariana no sabe cuánto gasta al año en su auto.
- *¿Qué hace?* Llena su tabla con sus gastos del último año.


**Caso 3. La bici**

Kevin cree que no necesita apartado.
- *¿Qué hace?* Aparta poco para llantas, frenos y cámaras.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No apartar | Días sin trabajar | Apartado semanal |
| Usar el apartado para otra cosa | Sin dinero al fallar | Solo vehículo |
| Posponer el mantenimiento | Reparación más cara | A tiempo |
| No contar trámites | Multas | Inclúyelos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Mariana y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Gastas 7,800 al año en mantenimiento. ¿Cuánto apartas por semana? a) 78 · b) 780 · c) 150
2. ¿Para qué es el apartado del vehículo? a) Solo para el vehículo · b) Para fiestas · c) Para préstamos a tus compañeros
3. ¿Qué pasa si pospones el mantenimiento? a) Ahorras siempre, porque no gastas · b) La reparación puede salir más cara · c) Nada
**Respuestas:** 1-c: 7,800 entre 52. 2-a: solo vehículo. 3-b: más cara.



#### Ponlo en práctica

Llantas 2,400 dos veces al año y aceite 450 seis veces al año. ¿Cuánto al año?
**Respuesta:** 7,500 pesos.



#### A tu plan

Llena tu tabla de mantenimiento y decide tu apartado semanal.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto».

### Palabras clave

- *Mantenimiento:* cuidados para que el vehículo no falle.
- *Apartado:* dinero separado para algo.
- *Refrendo:* pago anual de placas, según el estado.

### Fuentes

Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.

---

## M5 U02. El seguro de tu vehículo

**Lo que lograrás:** Identificar qué cubre un seguro de auto o moto, qué cubre la plataforma y qué preguntar antes de contratar.

**Para empezar:** Mariana chocó a otro auto en una entrega. Pensó que el seguro de la app pagaría todo. Le dijeron que solo cubría ciertos casos y que su seguro no cubría uso comercial. En esta lección verás qué revisar.

### Lo esencial (5 minutos)

#### Lo que puede cubrir un seguro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Daños a terceros | Lo que le haces a otros. | Responsabilidad civil. |
| Daños a tu vehículo | Cobertura amplia o limitada. | Según la póliza. |
| Gastos médicos | Para ti y quien va contigo. | Revisa el monto. |
| Robo | Si te roban el vehículo. | Según la póliza. |

#### Pregunta por el uso con apps

Muchos seguros personales no cubren si estás trabajando con apps. Pregunta por escrito si tu póliza cubre «uso para plataformas» o «uso comercial».



#### Lo que da la plataforma

Algunas plataformas tienen seguros mientras estás en un viaje o entrega. Revisa en la app qué cubren, cuánto y en qué momento.



#### Un caso en un minuto

Mariana cambió a una póliza que cubre uso con apps. Pidió todo por escrito y verificó la aseguradora en el SIPRES.

> **Idea clave:** pregunta por escrito si tu seguro cubre trabajar con apps y revisa qué cubre la plataforma.



#### Comprueba lo que entendiste

1. ¿Qué es la responsabilidad civil?
*Respuesta:* La cobertura por los daños que le haces a otros.

2. ¿Qué preguntas sobre tu póliza?
*Respuesta:* Si cubre uso con apps o uso comercial.


#### Para recordar

- Daños a terceros.
- ¿Cubre uso con apps?
- Por escrito.



### Profundiza (5 minutos más)

#### El deducible

Es lo que pagas tú antes de que pague el seguro. Pregunta el monto: un deducible muy alto puede dejarte igual sin dinero para arreglar.



#### Verifica la aseguradora

Revisa que esté en el SIPRES de CONDUSEF. No te recomendamos ninguna: compara al menos dos.



#### Casos


**Caso 1. El choque**

Mariana pensó que el seguro de la app cubría todo.
- *¿Qué hace?* Revisa qué cubre la app y busca una póliza que cubra uso con apps.


**Caso 2. Seguro personal**

Beto tiene un seguro personal de su moto.
- *¿Qué hace?* Pregunta por escrito si cubre cuando trabaja.


**Caso 3. El deducible alto**

A Don Chava le ofrecen un seguro barato con deducible altísimo.
- *¿Qué hace?* Compara cuánto pagaría él en un choque.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que la app cubre todo | Pagas tú | Revisa |
| Seguro personal para trabajar | No cubre | Uso con apps |
| No ver el deducible | Sorpresa | Pregunta |
| No comparar | Pagas de más | Dos opciones |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Beto y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué cubre la responsabilidad civil? a) Tu gasolina · b) Tu celular si se te cae · c) Los daños que le haces a otros
2. ¿Qué preguntas a tu aseguradora? a) Si cubre uso con apps · b) El color de la póliza · c) Nada
3. El daño es de 20,000 y el deducible de 5,000. ¿Cuánto paga el seguro? a) 20,000 · b) 15,000 · c) 5,000
**Respuestas:** 1-c: terceros. 2-a: uso con apps. 3-b: 20,000 menos 5,000.



#### Ponlo en práctica

Escribe las preguntas que haces antes de contratar un seguro de tu vehículo.
**Respuesta:** ¿Cubre uso con apps?, ¿qué cubre?, ¿cuánto es el deducible?, ¿cuánto cuesta al año?



#### A tu plan

Revisa tu póliza actual y lo que cubre tu plataforma.



### Para saber más

- **Seguros de auto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de auto».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Responsabilidad civil:* daños a otras personas o sus cosas.
- *Deducible:* lo que pagas tú.
- *Uso comercial:* usar el vehículo para trabajar.

### Fuentes

CONDUSEF, seguros de automóvil; consultado el 5 de octubre de 2026.

---

## M5 U03. Comprar, financiar o rentar tu vehículo

**Lo que lograrás:** Comparar el costo total de comprar a crédito, rentar o rentar con opción a compra.

**Para empezar:** Don Chava paga 2,500 a la semana por un auto rentado. Le ofrecen uno «a pagos» de 2,900 a la semana por tres años, que al final será suyo. No sabe qué conviene. En esta lección lo calcularás.

### Lo esencial (5 minutos)

#### Tres caminos

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Rentar | Pagas por usar. | No es tuyo nunca. |
| Crédito | Pagas y es tuyo al final. | Con intereses. |
| Renta con opción a compra | Pagos y al final puede ser tuyo. | Revisa condiciones. |

#### Calcula el total

Multiplica el pago por todos los pagos. Compáralo con el precio de contado. Suma seguro y mantenimiento, que en algunos casos pagas tú.



#### Lee las condiciones

¿Qué pasa si te atrasas un pago? ¿Si chocas? ¿Si dejas de trabajar? En algunos contratos pierdes todo lo pagado. Pide todo por escrito.



#### Un caso en un minuto

Don Chava calculó: 2,900 por 156 semanas son 452,400 pesos por un auto de 280,000 de contado. Decidió ahorrar un enganche y buscar un crédito con mejor total.

> **Idea clave:** multiplica el pago por todos los pagos, compara con el contado y lee qué pasa si te atrasas.



#### Comprueba lo que entendiste

1. ¿Cómo calculas el costo total?
*Respuesta:* Multiplico el pago por el número de pagos.

2. ¿Qué preguntas sobre el contrato?
*Respuesta:* Qué pasa si me atraso, si choco o si dejo de trabajar.


#### Para recordar

- Total a pagar.
- Compara con contado.
- Lee las condiciones.



### Profundiza (5 minutos más)

#### El auto «a pagos» de Don Chava

- Pago semanal: **2,900**
- Semanas (3 años): **156**
- Total a pagar: **452,400**
- Precio de contado: **280,000**
- Lo que cuesta de más: **172,400**


#### Verifica a quien te financia

Busca la financiera en el SIPRES. Desconfía de contratos de palabra.



#### Casos


**Caso 1. A pagos**

A Don Chava le ofrecen un auto a 2,900 por semana durante tres años.
- *¿Qué hace?* Calcula el total y lo compara con el contado.


**Caso 2. Pierde lo pagado**

El contrato dice que si se atrasa, pierde todo.
- *¿Qué hace?* No firma sin entender y busca otra opción.


**Caso 3. La moto nueva**

Beto quiere una moto nueva a crédito.
- *¿Qué hace?* Compara el total y revisa que el pago quepa en su promedio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el pago semanal | Pagas mucho más | Total |
| Contratos de palabra | Sin protección | Por escrito |
| No leer qué pasa si te atrasas | Pierdes todo | Lee |
| Pago más alto que tu promedio | Te ahogas | Que quepa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chava y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Pagas 1,000 por semana durante 104 semanas. ¿Cuánto en total? a) 1,000 · b) 10,400, uno por cada semana · c) 104,000
2. ¿Qué revisas en el contrato? a) Qué pasa si te atrasas · b) El color y el modelo del auto · c) Nada
3. ¿Con qué comparas el total a pagar? a) Con la gasolina · b) Con el precio de contado · c) Con la renta de tu casa
**Respuestas:** 1-c: 1,000 por 104. 2-a: atrasos. 3-b: contado.



#### Ponlo en práctica

Una moto cuesta 32,000 de contado y a pagos son 52 semanas de 850. ¿Cuánto pagas de más?
**Respuesta:** 12,200 pesos (44,200 en total).



#### A tu plan

Si piensas cambiar de vehículo, compara dos opciones con el total y las condiciones por escrito.



### Para saber más

- **Créditos automotrices** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «crédito automotriz».

### Palabras clave

- *Contado:* pagar todo de una vez.
- *Enganche:* primer pago grande.
- *Opción a compra:* que al final puede ser tuyo.

### Fuentes

CONDUSEF, créditos automotrices; consultado el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Accidentes, salud y días sin trabajo

## M6 U01. Si tienes un accidente en la ruta

**Lo que lograrás:** Decidir qué hacer en las primeras horas después de un accidente trabajando y cómo usar la cobertura de riesgos de trabajo.

**Para empezar:** Kevin se cayó de la bici en una entrega y se lastimó la muñeca. No sabía si ir al IMSS, a un consultorio o aguantarse. En esta lección verás qué hacer.

### Lo esencial (5 minutos)

#### Primeras horas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| 1. Tu salud | Atención médica primero. | 911 si es grave. |
| 2. Pruebas | Fotos, hora, lugar, pedido activo. | Captura de la app. |
| 3. Avisa a la plataforma | Por el canal oficial. | Pide folio. |
| 4. IMSS | Riesgo de trabajo. | Con tus pruebas. |

#### Riesgo de trabajo

Si te accidentas conectado, el IMSS te cubre por riesgo de trabajo, aunque no llegues al umbral. Lleva tus pruebas de que estabas en un pedido o viaje.



#### Incapacidad

Si el médico te da incapacidad por riesgo de trabajo, el IMSS paga un subsidio mientras no puedes trabajar. Pregunta cómo tramitarlo.



#### Un caso en un minuto

Kevin tomó captura del pedido activo, avisó a la app y fue al IMSS. Lo atendieron como riesgo de trabajo y le dieron incapacidad por una semana.

> **Idea clave:** si te accidentas conectado, atiéndete, junta pruebas, avisa a la app y ve al IMSS por riesgo de trabajo.



#### Comprueba lo que entendiste

1. ¿Qué pruebas juntas?
*Respuesta:* Fotos, hora, lugar y captura del pedido o viaje activo.

2. ¿Qué te paga el IMSS si te dan incapacidad por riesgo de trabajo?
*Respuesta:* Un subsidio mientras no puedo trabajar.


#### Para recordar

- Salud primero.
- Captura del pedido.
- IMSS por riesgo de trabajo.



### Profundiza (5 minutos más)

#### Mi ficha de accidente

| Dato | Lo tengo |
|---|---|
| Número de seguridad social | |
| Teléfono de soporte de la app | |
| Teléfono de mi aseguradora | |
| Persona a quien avisar | |



#### Si chocas con alguien

Llama a tu aseguradora antes de llegar a acuerdos. No firmes nada sin entenderlo.



#### Casos


**Caso 1. La caída**

Kevin se cayó en una entrega.
- *¿Qué hace?* Toma captura del pedido, avisa a la app y va al IMSS.


**Caso 2. «Aguántate»**

A Beto le duele la rodilla tras un golpe y piensa seguir trabajando.
- *¿Qué hace?* Se atiende y deja registro del accidente.


**Caso 3. El choque**

Mariana choca con otro auto.
- *¿Qué hace?* Llama a su aseguradora antes de cualquier acuerdo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aguantarse | Lesión peor | Atiéndete |
| No tomar captura | No pruebas que trabajabas | Captura |
| No avisar a la app | Sin registro | Folio |
| Acuerdos sin aseguradora | Pagas de más | Llámala |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin, Beto y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te accidentas conectado. ¿Qué te cubre el IMSS? a) Riesgo de trabajo · b) Nada · c) Solo si tienes auto
2. ¿Qué captura tomas? a) Del pedido o viaje activo · b) De tus redes sociales del día · c) Ninguna
3. Chocas con otro auto. ¿Qué haces antes de un acuerdo? a) Te vas · b) Firmas lo que te den para terminar rápido · c) Llamas a tu aseguradora
**Respuestas:** 1-a: riesgo de trabajo. 2-a: pedido activo. 3-c: aseguradora.



#### Ponlo en práctica

Escribe los cuatro pasos de las primeras horas.
**Respuesta:** Salud, pruebas, avisar a la plataforma y acudir al IMSS.



#### A tu plan

Llena tu ficha de accidente y guárdala en tu celular.



### Para saber más

- **Riesgos de trabajo** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «riesgo de trabajo».

### Palabras clave

- *Riesgo de trabajo:* accidente o enfermedad por trabajar.
- *Incapacidad:* permiso médico para no trabajar.
- *Subsidio:* pago mientras estás incapacitado.

### Fuentes

IMSS, seguro de riesgos de trabajo; consultado el 5 de octubre de 2026.

---

## M6 U02. Un fondo para los días sin trabajo

**Lo que lograrás:** Juntar un fondo de emergencia para días sin trabajo por enfermedad, fallas o desactivación.

**Para empezar:** A Mariana se le enfermó la niña y no pudo trabajar una semana. Sin ingreso y sin ahorro, pidió prestado a una app. En esta lección empezarás tu fondo.

### Lo esencial (5 minutos)

#### Qué cubre

El fondo de emergencia es para cuando no puedes trabajar. Por ejemplo, si te enfermas tú o alguien de tu familia, si falla el vehículo, si te desactivan o si tienes una semana muy mala.



#### Metas por etapas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Primera meta | Una semana de gastos. | Lo más urgente. |
| Segunda meta | Un mes de gastos. | Más tranquilidad. |
| Meta grande | Tres meses. | Pocas personas lo tienen. |

#### Poco y seguido

Aparta una cantidad fija de cada día o cada semana. Aunque sea poco, la constancia hace el fondo.



#### Un caso en un minuto

Mariana aparta 100 pesos al día. En un mes tiene 3,000, casi una semana de sus gastos. La próxima vez no pedirá prestado.

> **Idea clave:** junta tu fondo por etapas: primero una semana de gastos, luego un mes.



#### Comprueba lo que entendiste

1. ¿Para qué es el fondo de emergencia?
*Respuesta:* Para cuando no puedo trabajar por enfermedad, fallas o desactivación.

2. ¿Cuál es la primera meta?
*Respuesta:* Una semana de gastos.


#### Para recordar

- Primero una semana.
- Luego un mes.
- Poco y seguido.



### Profundiza (5 minutos más)

#### El fondo de Mariana

- Al día: **100**
- Días: **30**
- En un mes: **3,000**


#### Dónde guardarlo

En un apartado o cuenta distinta, que puedas sacar rápido pero no uses a diario.



#### Casos


**Caso 1. La niña enferma**

Mariana no pudo trabajar y pidió prestado.
- *¿Qué hace ahora?* Aparta una cantidad fija cada día.


**Caso 2. «No me sobra»**

Beto dice que no le sobra nada.
- *¿Qué hace?* Empieza con 30 pesos al día.


**Caso 3. Lo usó**

Kevin usó su fondo por la caída.
- *¿Qué hace después?* Lo vuelve a llenar poco a poco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar a que sobre | Nunca empiezas | Monto fijo |
| Guardarlo con el dinero diario | Se gasta | Aparte |
| Usarlo para gustos | No está cuando lo necesitas | Solo emergencias |
| No reponerlo | Te quedas sin fondo | Llénalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Beto y Kevin. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es la primera meta del fondo? a) Una semana de gastos · b) Un año completo de gastos desde el inicio · c) Nada
2. Apartas 50 al día. ¿Cuánto en 30 días? a) 1,500 · b) 150 · c) 5,000
3. Usaste tu fondo. ¿Qué haces? a) Lo olvidas · b) Pides prestado para llenarlo de una vez · c) Lo vuelves a llenar
**Respuestas:** 1-a: una semana. 2-a: 50 por 30. 3-c: llénalo.



#### Ponlo en práctica

Tus gastos son 2,800 por semana. ¿Cuánto es tu meta de un mes (4 semanas)?
**Respuesta:** 11,200 pesos.



#### A tu plan

Decide cuánto apartarás al día y dónde guardarás tu fondo.



### Para saber más

- **Fondo de emergencia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fondo de emergencia».

### Palabras clave

- *Fondo de emergencia:* dinero para cuando no puedes trabajar.
- *Etapa:* paso de una meta.
- *Constancia:* hacerlo siempre.

### Fuentes

CONDUSEF, fondo de emergencia; consultado el 5 de octubre de 2026.

---

## M6 U03. Cansancio, estrés y tu dinero

**Lo que lograrás:** Reconocer cómo el cansancio y el estrés por dinero afectan tu seguridad en la ruta.

**Para empezar:** Beto trabaja hasta 14 horas para pagar sus deudas. Una noche se quedó dormido en un semáforo. Asustado, se dio cuenta de que el cansancio también le cuesta. En esta lección verás por qué.

### Lo esencial (5 minutos)

#### El cansancio es un riesgo

Manejar cansado aumenta el riesgo de accidentes, y un accidente cuesta más que las horas extra.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ojos pesados | Parpadeas mucho. | Para. |
| No recuerdas el camino | Kilómetros en blanco. | Para. |
| Irritación | Te enojas fácil. | Descansa. |
| Dolor de cabeza o estómago | Estrés. | Atiéndete. |

#### Trabaja mejor, no más

Con tu ganancia por hora (M1 U02), elige los horarios que pagan mejor y descansa en los que no. Ganas parecido con menos riesgo.



#### Un caso en un minuto

Beto dejó de trabajar de madrugada, que casi no le pagaba. Hizo un plan para sus deudas. Duerme siete horas y gana casi lo mismo.

> **Idea clave:** el cansancio es un riesgo para tu salud y tu dinero; trabaja en los horarios que pagan mejor y descansa.



#### Comprueba lo que entendiste

1. ¿Por qué el cansancio cuesta dinero?
*Respuesta:* Porque aumenta el riesgo de accidentes, que cuestan más que las horas extra.

2. ¿Qué haces si tienes los ojos pesados?
*Respuesta:* Me detengo a descansar.


#### Para recordar

- El cansancio es riesgo.
- Para si hay señales.
- Mejores horarios.



### Profundiza (5 minutos más)

#### El estrés por dinero

Uno de cada tres adultos en México reporta malestar físico por preocupaciones de dinero. Hacer un plan para tus deudas también baja el estrés.



#### Si te sientes muy mal

Si el estrés te quita las ganas de vivir, busca ayuda de inmediato: Línea de la Vida, 800 911 2000, las 24 horas.



#### Casos


**Caso 1. Catorce horas**

Beto trabaja 14 horas por sus deudas.
- *¿Qué hace?* Trabaja en los mejores horarios y hace un plan para sus deudas.


**Caso 2. Ojos pesados**

Mariana siente los ojos pesados de madrugada.
- *¿Qué hace?* Se detiene y descansa.


**Caso 3. Dolor de estómago**

Don Chava tiene gastritis desde que debe la renta del auto.
- *¿Qué hace?* Se atiende y revisa su presupuesto.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Manejar cansado | Accidente | Para |
| Más horas sin pensar | Riesgo | Mejores horarios |
| Ignorar el estrés | Te enfermas | Atiéndete |
| No hacer plan de deudas | Sigues igual | Haz tu plan |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Mariana y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Sientes los ojos pesados. ¿Qué haces? a) Te detienes a descansar · b) Subes el volumen y abres la ventana · c) Aceleras para llegar
2. ¿Qué te ayuda a trabajar menos horas? a) Elegir los horarios que pagan mejor · b) Trabajar de madrugada siempre, que hay menos tráfico · c) Nada
3. ¿A dónde llamas si el estrés te rebasa? a) A nadie · b) A la app, al soporte de viajes · c) A la Línea de la Vida
**Respuestas:** 1-a: descansa. 2-a: mejores horarios. 3-c: 800 911 2000.



#### Ponlo en práctica

De madrugada ganas 35 por hora y en la comida 90. ¿Cuántas horas de madrugada equivalen a 2 horas en la comida?
**Respuesta:** Unas 5 horas (180 entre 35).



#### A tu plan

Escribe tu horario ideal con tus mejores horas y tu tiempo de descanso.



### Para saber más

- **Línea de la Vida** (Gobierno de México · español): 800 911 2000.

### Palabras clave

- *Fatiga:* cansancio que afecta tu atención.
- *Estrés financiero:* preocupación por dinero.
- *Descanso:* tiempo para recuperarte.

### Fuentes

INEGI y CONDUSEF, ENSAFI 2023; consultado el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Préstamos y fraudes en la ruta

## M7 U01. Adelantos y préstamos dentro de la app

**Lo que lograrás:** Calcular cuánto cuesta un adelanto o préstamo que se descuenta de lo que ganas en la app.

**Para empezar:** A Don Chava la app le ofrece un «adelanto de ganancias» de 3,000 pesos que se descuenta de sus viajes. Parece cómodo. No sabe cuánto le cobran. En esta lección lo calcularás.

### Lo esencial (5 minutos)

#### Cómodo no es barato

Algunos adelantos y préstamos se descuentan solos de lo que ganas. Eso los hace fáciles de pedir, pero pueden tener comisiones o intereses.



#### Pregunta antes de aceptar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cuánto pago en total? | Préstamo más comisiones. | La cifra completa. |
| ¿Cuál es el CAT? | El costo anual. | Para comparar. |
| ¿Cuánto me descuentan al día? | Afecta tu sueldo. | Revisa tu promedio. |
| ¿Qué pasa si gano menos? | Una semana mala. | Por escrito. |

#### Primero tu colchón

Antes de un adelanto, revisa tu colchón y tu fondo (M1 U03 y M6 U02). Son tu dinero y no cuestan.



#### Un caso en un minuto

Don Chava preguntó: pagaría 3,450 por 3,000 en un mes. Prefirió usar 1,500 de su colchón y pedir solo lo que le faltaba.

> **Idea clave:** que un adelanto se descuente solo no lo hace barato; pregunta el total y el CAT, y usa primero tu colchón.



#### Comprueba lo que entendiste

1. ¿Qué preguntas antes de aceptar un adelanto?
*Respuesta:* Cuánto pago en total, el CAT, cuánto me descuentan al día y qué pasa si gano menos.

2. ¿Qué revisas antes de pedir?
*Respuesta:* Mi colchón y mi fondo de emergencia.


#### Para recordar

- Pregunta el total.
- Revisa el descuento diario.
- Colchón primero.



### Profundiza (5 minutos más)

#### El adelanto de Don Chava

- Lo que pagaría: **3,450**
- Lo que recibe: **3,000**
- Lo que cuesta en un mes: **450**


#### Quién te presta

Revisa quién da el préstamo: a veces es una financiera aliada de la app. Búscala en el SIPRES de CONDUSEF.



#### Casos


**Caso 1. El adelanto cómodo**

A Don Chava le ofrecen 3,000 que se descuentan solos.
- *¿Qué hace?* Pregunta el total y usa primero su colchón.


**Caso 2. Descuento diario**

A Beto le descontarían 250 al día por un préstamo.
- *¿Qué hace?* Revisa si con eso le alcanza su sueldo semanal.


**Caso 3. La financiera aliada**

Mariana no sabe quién le presta en la app.
- *¿Qué hace?* Busca el nombre de la financiera en el SIPRES.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Aceptar por cómodo | Pagas de más | Pregunta el total |
| Ignorar el descuento diario | Te quedas sin sueldo | Revísalo |
| No usar tu colchón | Préstamo innecesario | Colchón primero |
| No saber quién presta | Sin a quién reclamar | Verifica |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Chava, Beto y Mariana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te prestan 2,000 y pagas 2,300. ¿Cuánto cuesta? a) Nada · b) 2,300 · c) 300
2. ¿Qué usas antes de pedir un adelanto? a) Tu colchón · b) Otro préstamo · c) La tarjeta de un amigo
3. ¿Dónde verificas la financiera? a) En redes sociales · b) En el SIPRES de CONDUSEF · c) Con el soporte de otra app
**Respuestas:** 1-c: 2,300 menos 2,000. 2-a: colchón. 3-b: SIPRES.



#### Ponlo en práctica

Te descuentan 150 al día por 20 días. ¿Cuánto pagas? Si te prestaron 2,500, ¿cuánto cuesta?
**Respuesta:** Pagas 3,000; cuesta 500.



#### A tu plan

Si tienes un adelanto activo, escribe cuánto pagarás en total y cuánto te descuentan al día.



### Para saber más

- **Créditos** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «CAT».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Adelanto:* dinero que te dan antes y se descuenta después.
- *CAT:* costo anual total.
- *Financiera aliada:* empresa que presta a través de la app.

### Fuentes

CONDUSEF, CAT y créditos; consultado el 5 de octubre de 2026.

---

## M7 U02. Rentar o prestar tu cuenta

**Lo que lograrás:** Identificar los riesgos de rentar, prestar o usar cuentas de otras personas en las apps.

**Para empezar:** Un conocido le ofrece a Kevin 600 pesos a la semana por «prestarle» su cuenta de reparto mientras él estudia. Parece dinero fácil. En esta lección verás qué arriesga.

### Lo esencial (5 minutos)

#### La cuenta es tu identidad

Tu cuenta está ligada a tu nombre, tu INE, tu RFC y tu cuenta bancaria. Lo que haga otra persona con ella queda a tu nombre.



#### Lo que arriesgas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Desactivación | La app puede cerrar tu cuenta para siempre. | Pierdes tu trabajo. |
| Impuestos | Los ingresos se reportan a tu RFC. | Tú respondes al SAT. |
| Delitos o accidentes | Quedan a tu nombre. | Problemas legales. |
| Seguridad social | Tu IMSS y tus semanas se confunden. | Datos que no son tuyos. |

#### Usar una cuenta ajena tampoco

Si trabajas con la cuenta de otra persona, no tienes IMSS, ni derechos, ni seguro a tu nombre. Si te accidentas, no te cubren.



#### Un caso en un minuto

Kevin dijo que no. Su conocido prestó su cuenta a otra persona, que chocó. La cuenta fue desactivada y el reclamo le llegó a él.

> **Idea clave:** tu cuenta es tu identidad; no la rentes ni la prestes, y no trabajes con la de otra persona.



#### Comprueba lo que entendiste

1. ¿A nombre de quién queda lo que hace otra persona con tu cuenta?
*Respuesta:* A mi nombre.

2. ¿Qué pierdes si trabajas con una cuenta ajena?
*Respuesta:* El IMSS, mis derechos y el seguro a mi nombre.


#### Para recordar

- Tu cuenta es tu identidad.
- No la rentes.
- No uses cuentas ajenas.



### Profundiza (5 minutos más)

#### Los 600 pesos no alcanzan

Un solo problema con el SAT o una desactivación cuesta mucho más que lo que te pagan por la renta.



#### Cuida tus accesos

Activa la verificación en dos pasos y no compartas tu contraseña ni códigos.



#### Casos


**Caso 1. Prestar la cuenta**

Le ofrecen a Kevin 600 a la semana por su cuenta.
- *¿Qué hace?* No la presta.


**Caso 2. La cuenta del primo**

A Don Chava le ofrecen trabajar con la cuenta de un primo.
- *¿Qué hace?* Abre su propia cuenta para tener sus derechos.


**Caso 3. Contraseña compartida**

Beto le dio su contraseña a un amigo hace meses.
- *¿Qué hace?* La cambia y activa la verificación en dos pasos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Rentar tu cuenta | Problemas a tu nombre | No |
| Usar cuenta ajena | Sin derechos | La tuya |
| Compartir contraseñas | Robo de cuenta | Cámbiala |
| Creer que es dinero fácil | Cuesta más | Haz la cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin, Don Chava y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te ofrecen dinero por prestar tu cuenta. ¿Qué haces? a) La prestas a un familiar · b) La prestas solo los fines de semana · c) No la prestas
2. Trabajas con la cuenta de otra persona. ¿Tienes IMSS a tu nombre? a) Sí · b) No · c) Solo si te accidentas
3. ¿Qué haces si compartiste tu contraseña? a) Nada · b) La cambias y activas verificación en dos pasos · c) La publicas para que nadie la use
**Respuestas:** 1-c: no. 2-b: no. 3-b: cámbiala.



#### Ponlo en práctica

Te pagan 600 por semana por tu cuenta. ¿Cuánto en un año? ¿Vale el riesgo de perder tu trabajo?
**Respuesta:** 31,200 pesos; no, porque arriesgas tu cuenta, tu RFC y problemas legales.



#### A tu plan

Cambia tu contraseña y activa la verificación en dos pasos en tus apps.



### Para saber más

- **Robo de identidad** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «robo de identidad».

### Palabras clave

- *Identidad:* tus datos que te identifican.
- *Verificación en dos pasos:* un código extra al entrar.
- *Desactivación:* cierre de tu cuenta.

### Fuentes

CONDUSEF, robo de identidad; consultado el 5 de octubre de 2026.

---

## M7 U03. Soporte falso y robo de cuentas

**Lo que lograrás:** Reconocer mensajes y llamadas de soporte falso que buscan robar tu cuenta o tus ganancias.

**Para empezar:** Mariana recibió un mensaje: «Soporte. Tu cuenta será bloqueada. Envía el código que te llegó por SMS». Lo mandó. Una hora después le habían cambiado la cuenta bancaria de pagos. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Soporte nunca pide códigos

El soporte real de la plataforma no te pide por mensaje ni llamada tu contraseña ni el código que te llega por SMS.



#### Señales de soporte falso

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Urgencia | «Tu cuenta será bloqueada hoy». | Para que no pienses. |
| Piden códigos | El SMS que te llegó. | Con eso entran. |
| Ligas raras | Páginas parecidas. | No las abras. |
| Por WhatsApp | Números personales. | El soporte usa la app. |

#### Usa solo el canal oficial

Si dudas, abre tú la app y entra a ayuda o soporte desde ahí. Nunca desde una liga que te mandaron.



#### Un caso en un minuto

Mariana entró a soporte desde la app, reportó el robo y recuperó su cuenta. Ahora revisa cada semana que la cuenta de pagos sea la suya.

> **Idea clave:** el soporte real nunca te pide códigos; ante la duda, entra tú desde la app.



#### Comprueba lo que entendiste

1. ¿El soporte te pide el código que te llega por SMS?
*Respuesta:* No; si lo piden, es fraude.

2. ¿Por dónde contactas a soporte?
*Respuesta:* Desde la app, nunca desde una liga.


#### Para recordar

- Nunca des códigos.
- Soporte desde la app.
- Revisa tu cuenta de pagos.



### Profundiza (5 minutos más)

#### Revisión semanal

| Revisar | Bien |
|---|---|
| Mi cuenta de pagos es la mía | |
| Mi correo y teléfono son los míos | |
| No hay sesiones abiertas raras | |



#### Si ya pasó

Reporta desde la app, cambia tu contraseña, avisa a tu banco y guarda capturas.



#### Casos


**Caso 1. El código**

A Mariana le piden el código del SMS para «no bloquear» su cuenta.
- *¿Qué hace?* No lo manda y entra a soporte desde la app.


**Caso 2. La liga**

A Beto le llega una liga para «actualizar sus datos de pago».
- *¿Qué hace?* No la abre y revisa desde la app.


**Caso 3. Ya robaron**

A Don Chava le cambiaron la cuenta de pagos.
- *¿Qué hace?* Reporta desde la app y avisa a su banco.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar códigos | Te roban la cuenta | Nunca |
| Abrir ligas | Robo de datos | Desde la app |
| No revisar la cuenta de pagos | Te pagan a otro | Semanal |
| Tardar en reportar | Pierdes más | De inmediato |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Beto y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. «Soporte» te pide el código del SMS. ¿Qué haces? a) Das solo la mitad del código · b) Lo das para no perder tu cuenta · c) No lo das y entras a soporte desde la app
2. ¿Qué revisas cada semana? a) Que tu cuenta de pagos sea la tuya · b) Las calificaciones de otros repartidores · c) Nada
3. Te robaron la cuenta. ¿Qué haces? a) Esperas · b) Reportas desde la app y avisas a tu banco · c) Abres otra cuenta con otro nombre
**Respuestas:** 1-c: nunca des códigos. 2-a: cuenta de pagos. 3-b: reporta.



#### Ponlo en práctica

Escribe la frase que usarás si alguien te pide un código.
**Respuesta:** Ejemplo: «No doy códigos; entro yo a soporte desde la app».



#### A tu plan

Haz tu revisión semanal de cuenta este domingo.



### Para saber más

- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «phishing» y «robo de cuentas».

### Palabras clave

- *Soporte falso:* alguien que se hace pasar por la app.
- *Código SMS:* número que te llega para confirmar tu identidad.
- *Cuenta de pagos:* donde la app te deposita.

### Fuentes

CONDUSEF, alertas de fraude; consultado el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Tu futuro

## M8 U01. Tu retiro aunque trabajes con apps

**Lo que lograrás:** Hacer un plan de ahorro para el retiro con aportaciones voluntarias, aunque tu ingreso cambie.

**Para empezar:** Beto tiene 28 años y cree que el retiro «está muy lejos». Su papá, que fue taxista, no tiene pensión y depende de sus hijos. En esta lección verás qué puede hacer Beto desde ya.

### Lo esencial (5 minutos)

#### El tiempo hace el trabajo

Empezar a los 28 con poco vale más que empezar a los 50 con mucho, porque el ahorro tiene más años para crecer.



#### Tu plan de retiro

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Semanas | Mantente en el umbral cuando puedas. | Suman para pensión. |
| Aportación voluntaria | Monto fijo cada mes. | Desde 50 pesos. |
| Domiciliada | Automática. | Para no olvidar. |

#### En semanas malas, aunque sea poco

Si tu ingreso baja, baja el monto, pero no lo dejes en cero. La constancia cuenta.



#### Un caso en un minuto

Beto domicilió 250 al mes a su Afore. En semanas malas aporta 100 en la tienda. Ya no ve el retiro como algo lejano.

> **Idea clave:** suma semanas cuando llegues al umbral y aporta a tu Afore cada mes, aunque sea poco.



#### Comprueba lo que entendiste

1. ¿Por qué empezar joven?
*Respuesta:* Porque el ahorro tiene más años para crecer.

2. ¿Qué haces en semanas malas?
*Respuesta:* Bajo el monto, pero no lo dejo en cero.


#### Para recordar

- Empieza ya.
- Monto fijo cada mes.
- Nunca en cero.



### Profundiza (5 minutos más)

#### Lo que aporta Beto

- Al mes: **250**
- Meses: **12**
- Al año: **3,000**
- Años: **30**
- Aportado, sin contar lo que genere: **90,000**


#### No dependas solo de tus hijos

Tu ahorro te da independencia en la vejez y le quita una carga a tu familia.



#### Casos


**Caso 1. «Está muy lejos»**

Beto cree que el retiro no le importa todavía.
- *¿Qué hace?* Domicilia una aportación mensual.


**Caso 2. Semana mala**

A Mariana le fue mal este mes.
- *¿Qué hace?* Aporta menos, pero no deja de aportar.


**Caso 3. A los 47**

Don Chava cree que ya es tarde.
- *¿Qué hace?* Aporta y busca mantenerse en el umbral para sumar semanas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar que está lejos | Pierdes años | Empieza |
| Dejarlo en cero | Huecos | Aunque sea poco |
| Aportar cuando te acuerdas | Irregular | Domicilia |
| Creer que es tarde | No haces nada | Siempre suma |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Beto, Mariana y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuándo conviene empezar a ahorrar para el retiro? a) Lo antes posible · b) A los 60, cuando ya estés cerca · c) Nunca
2. Aportas 200 al mes durante 20 años. ¿Cuánto aportas? a) 48,000 · b) 4,800 · c) 200,000
3. Tuviste un mes malo. ¿Qué haces con tu aportación? a) Pides prestado para aportar · b) La cancelas para siempre y te olvidas · c) La bajas pero no la dejas en cero
**Respuestas:** 1-a: pronto. 2-a: 200 por 240 meses. 3-c: menos, no cero.



#### Ponlo en práctica

Aportas 300 al mes durante 15 años. ¿Cuánto aportas, sin rendimientos?
**Respuesta:** 54,000 pesos.



#### A tu plan

Decide tu aportación mensual y domicíliala.



### Para saber más

- **Ahorro voluntario** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «ahorro voluntario».

### Palabras clave

- *Retiro:* cuando dejas de trabajar por edad.
- *Domiciliar:* cargo automático.
- *Constancia:* hacerlo siempre.

### Fuentes

CONSAR, ahorro voluntario; consultado el 5 de octubre de 2026.

---

## M8 U02. La app como escalón

**Lo que lograrás:** Usar el trabajo en apps para juntar dinero hacia una meta: otro empleo, estudios o un negocio.

**Para empezar:** Kevin reparte para pagar la universidad. Mariana quiere poner un pequeño negocio de comida. Don Chava quiere su propio auto. Todos trabajan mucho, pero ninguno ha juntado nada para su meta. En esta lección pondrás tu meta en números.

### Lo esencial (5 minutos)

#### Tu meta en números

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Qué quieres | Una meta concreta. | Estudios, negocio, auto. |
| Cuánto cuesta | El monto. | Investiga. |
| Para cuándo | Una fecha. | Realista. |
| Cuánto apartar | Monto entre semanas. | Cada semana. |

#### Un apartado para la meta

Separa la meta del colchón y del fondo de emergencia. Cada uno tiene su lugar.



#### Lo que aprendes también cuenta

Manejar tiempos, clientes y dinero en la ruta es experiencia. Si tu meta es otro empleo, ponla en tu solicitud.



#### Un caso en un minuto

Mariana necesita 24,000 para su negocio en un año: 462 por semana. Los aparta cada viernes en un apartado. Lleva 9,000.

> **Idea clave:** pon tu meta en números (cuánto y para cuándo) y aparta cada semana en un lugar distinto.



#### Comprueba lo que entendiste

1. ¿Qué cuatro cosas defines de tu meta?
*Respuesta:* Qué quiero, cuánto cuesta, para cuándo y cuánto apartar por semana.

2. ¿Dónde guardas el dinero de la meta?
*Respuesta:* En un apartado distinto del colchón y del fondo.


#### Para recordar

- Meta concreta.
- Cuánto y para cuándo.
- Apartado propio.



### Profundiza (5 minutos más)

#### La meta de Mariana

- Meta: **24,000**
- Semanas: **52**
- Por semana: **462**


#### Si tu meta es un negocio

Prueba en pequeño antes de invertir todo (el programa Tu Negocio, Tu Dinero, Tu Futuro profundiza en eso).



#### Casos


**Caso 1. Sin meta clara**

Kevin dice que quiere «juntar para algo».
- *¿Qué hace?* Pone su meta en números: cuánto y para cuándo.


**Caso 2. Todo en un lugar**

Mariana guarda la meta junto con su fondo de emergencia.
- *¿Qué hace?* Los separa en apartados distintos.


**Caso 3. El auto propio**

Don Chava quiere su auto.
- *¿Qué hace?* Calcula el enganche y aparta cada semana.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Meta vaga | No avanzas | En números |
| Mezclar con el fondo | Lo gastas en emergencias | Separa |
| Fecha imposible | Te desanimas | Realista |
| No contar tu experiencia | Pierdes oportunidades | Inclúyela |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Kevin, Mariana y Don Chava. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Tu meta es 15,600 en 52 semanas. ¿Cuánto apartas por semana? a) 300 · b) 156 · c) 1,560
2. ¿Dónde guardas el dinero de la meta? a) En un apartado propio · b) Con el fondo de emergencia · c) En la cartera
3. ¿Qué hace una meta concreta? a) No sirve · b) Es solo un deseo que tienes en la cabeza · c) Dice qué, cuánto y para cuándo
**Respuestas:** 1-a: 15,600 entre 52. 2-a: propio. 3-c: qué, cuánto, cuándo.



#### Ponlo en práctica

Quieres 10,000 en 25 semanas. ¿Cuánto apartas por semana?
**Respuesta:** 400 pesos.



#### A tu plan

Escribe tu meta con los cuatro datos y abre un apartado para ella.



### Para saber más

- **Metas de ahorro** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «metas de ahorro».

### Palabras clave

- *Meta:* algo que quieres lograr.
- *Apartado:* espacio separado en tu cuenta.
- *Escalón:* paso hacia algo mejor.

### Fuentes

CONDUSEF, metas de ahorro; consultado el 5 de octubre de 2026.

---

## M8 U03. Tu plan de ruta en una página

**Lo que lograrás:** Reunir en una página tu ingreso, derechos, IMSS, impuestos, vehículo, protección y futuro.

**Para empezar:** Mariana tiene capturas, tablas y notas en el celular. Quiere verlo todo junto para saber qué sigue. En esta lección harás tu plan de ruta.

### Lo esencial (5 minutos)

#### Tu plan tiene seis partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ingreso | Real, por hora y sueldo fijo. | M1. |
| Derechos e IMSS | Umbral, prestaciones, alta. | M2 y M3. |
| SAT | RFC y retenciones. | M4. |
| Vehículo | Apartado y seguro. | M5. |
| Protección | Fondo, accidentes, fraudes. | M6 y M7. |
| Futuro | Retiro y meta. | M8. |

#### Una acción y una fecha

Para cada parte, escribe la siguiente acción y cuándo la harás.



#### Revísalo cada mes

Tus ingresos y las reglas cambian. Revisa tu plan cada mes, el mismo día.



#### Un caso en un minuto

Mariana escribió: registrar a su hija en el IMSS (el lunes), cambiar su seguro (este mes), apartar 462 para su negocio (cada viernes). Lo revisa el día 1.

> **Idea clave:** junta todo en una página con una acción y una fecha para cada parte, y revísalo cada mes.



#### Comprueba lo que entendiste

1. ¿Cuántas partes tiene tu plan?
*Respuesta:* Seis.

2. ¿Cada cuándo lo revisas?
*Respuesta:* Cada mes.


#### Para recordar

- Seis partes.
- Acción y fecha.
- Revisión mensual.



### Profundiza (5 minutos más)

#### Mi plan de ruta

| Parte | Siguiente acción | Fecha |
|---|---|---|
| Ingreso | | |
| Derechos e IMSS | | |
| SAT | | |
| Vehículo | | |
| Protección | | |
| Futuro | | |



#### Compártelo con alguien

Contarle tu plan a alguien de confianza te ayuda a cumplirlo.



#### Casos


**Caso 1. Notas regadas**

Mariana tiene todo disperso en el celular.
- *¿Qué hace?* Junta todo en su plan de una página.


**Caso 2. Todo hoy**

Kevin quiere resolver las seis partes hoy.
- *¿Qué hace?* Escribe una acción con fecha para cada parte.


**Caso 3. El plan olvidado**

Beto hizo su plan y no lo volvió a ver.
- *¿Qué hace?* Lo revisa cada mes el mismo día.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Notas regadas | No ves el avance | Una página |
| Todo hoy | Te abrumas | Una acción por parte |
| Sin fechas | No pasa | Fecha |
| No revisarlo | Se olvida | Cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Mariana, Kevin y Beto. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué lleva cada parte? a) La siguiente acción y una fecha · b) Solo lo que ya hiciste en el curso · c) Nada
2. ¿Cada cuándo revisas tu plan? a) Cada mes · b) Cada cinco años · c) Nunca
3. ¿Cuál es una parte del plan? a) El clima · b) Las calificaciones de otros repartidores · c) Vehículo
**Respuestas:** 1-a: acción y fecha. 2-a: cada mes. 3-c: vehículo.



#### Ponlo en práctica

Escribe la siguiente acción de la parte «SAT» con una fecha.
**Respuesta:** Ejemplo: «Registrar mi RFC en la app el sábado 10».



#### A tu plan

Llena tu plan de ruta y pon en tu calendario el día de revisión.



### Para saber más

- **Todo lo del curso** (Desarrolla Talento · español): repasa las tablas de los módulos 1 a 7.

### Palabras clave

- *Plan:* lista de lo que harás y cuándo.
- *Revisión:* volver a ver cómo vas.
- *Siguiente acción:* el próximo paso concreto.

### Fuentes

Elaboración propia con base en los módulos 1 a 8 del programa.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Ruta, Tu Dinero, Tu Futuro** — Programa de bienestar financiero para repartidores y conductores de aplicaciones en México: ingreso real, derechos de la reforma de plataformas, IMSS, impuestos, vehículo, accidentes, préstamos y futuro. 8 módulos y 24 lecciones cortas en línea, para tomar entre viajes.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Tu ingreso real:** Tu ganancia real por hora y un sueldo fijo para las semanas malas.
- **Tus derechos con la reforma:** Tus derechos claros: quién es persona trabajadora de plataforma, prestaciones y cómo reclamar.
- **Tu IMSS, tu Afore y tu Infonavit:** Tu situación ante el IMSS revisada y tu Afore localizada.
- **Tus impuestos:** Tus retenciones entendidas y tu RFC en orden.
- **Tu vehículo:** Tu apartado para el vehículo y tu decisión sobre seguro y compra.
- **Accidentes, salud y días sin trabajo:** Tu plan ante un accidente y tu fondo para días sin trabajo.
- **Préstamos y fraudes en la ruta:** Tu regla contra préstamos caros y fraudes de cuentas.
- **Tu futuro:** Tu ahorro para el retiro y tu plan de una página.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 24 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Beto:** 28 años. Reparte en moto propia en Guadalajara con dos aplicaciones.
- **Mariana:** 33 años. Conduce su auto en la Ciudad de México; es mamá de una niña.
- **Kevin:** 21 años. Reparte en bici en Puebla mientras estudia.
- **Don Chava:** 47 años. Conduce un auto que le renta un dueño por semana en Monterrey.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **No se recomiendan aplicaciones, aseguradoras ni financieras:** se enseña a comparar y verificar.
5. **Pensado para el celular y entre viajes:** cada lección se puede tomar en un descanso.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. La semana de Beto (Módulos 1 y 6)

**Datos.** Beto ve en sus dos apps 5,200 en la semana, más 400 de propinas. Gasta 1,100 en gasolina, aparta 300 para la moto, 120 de datos y 480 de comida en la calle. Estuvo conectado 50 horas. Sus gastos de la casa son 3,000 a la semana.

**Tareas.**

1. ¿Cuál es su ingreso real de la semana?
2. ¿Cuánto gana por hora?
3. ¿Qué sueldo semanal fijo le conviene pagarse si su promedio es parecido?
4. ¿Cuál es la primera meta de su fondo para días sin trabajo?

**Clave.**

- 5,600 menos 2,000: 3,600.
- 3,600 entre 50: 72 por hora.
- Uno un poco menor a su promedio, por ejemplo 3,300; lo que sobra en semanas buenas cubre las malas.
- Una semana de gastos: 3,000; luego un mes.

### E2. Los derechos de Mariana (Módulos 2 y 3)

**Datos.** Mariana conduce en una app. Su ingreso neto en esa plataforma llega al salario mínimo mensual. Una semana la desactivan sin explicarle. Tiene una hija y no sabe si está dada de alta en el IMSS.

**Tareas.**

1. ¿Es persona trabajadora de plataforma?
2. ¿Qué derechos tiene además del pago por viaje?
3. ¿Qué hace con la desactivación?
4. ¿Qué revisa en el IMSS?

**Clave.**

- Sí: su neto en la plataforma llega al salario mínimo mensual.
- Seguridad social, aguinaldo, vacaciones y prima proporcionales, y reparto de utilidades si pasa de 288 horas.
- Pide la razón y la revisión por escrito; si no resuelven, va a la PROFEDET o al Centro de Conciliación.
- Que esté dada de alta, su número de seguridad social y su clínica; y registra a su hija.

### E3. Impuestos y vehículo de Don Chava (Módulos 4 y 5)

**Datos.** Don Chava no ha registrado su RFC en la app. En un mes la app le pagó 10,000 antes de impuestos. Renta el auto por semana y le ofrecen comprar uno a 52 pagos semanales de 1,100; de contado cuesta 42,000. Al año gasta 7,800 en mantenimiento.

**Tareas.**

1. ¿Cuánto le retienen de ISR sin RFC (20%) y con RFC (2.1%)?
2. ¿Cuánto paga en total por el auto financiado y cuánto de más?
3. ¿Cuánto aparta cada semana para mantenimiento?
4. ¿Qué pregunta por escrito sobre el seguro?

**Clave.**

- Sin RFC: 2,000. Con RFC: 210. Registra su RFC en la app (el RFC es sin costo).
- 1,100 por 52: 57,200; paga 15,200 de más. Lee también qué pasa si se atrasa.
- 7,800 entre 52: 150 por semana.
- Si cubre trabajar con apps, qué cubre, el deducible y cuánto cuesta al año; y revisa qué cubre la plataforma.

### E4. Kevin y su futuro (Módulos 7 y 8)

**Datos.** Kevin reparte en bici mientras estudia. La app le ofrece un adelanto de 2,000 que le descuenta 2,300 en dos semanas. Un amigo le ofrece rentarle su cuenta por 600 a la semana. Kevin quiere juntar 12,000 para una laptop en 6 meses.

**Tareas.**

1. ¿Cuánto le cuesta el adelanto?
2. ¿Qué responde a lo de rentar su cuenta?
3. ¿Cuánto aparta por semana para su meta (unas 26 semanas)?
4. ¿Qué hace si alguien de «soporte» le pide un código por mensaje?

**Clave.**

- 300. Antes, pregunta el total y el CAT, y usa primero su colchón.
- No: su cuenta es su identidad; arriesga su cuenta, su RFC y problemas legales.
- 12,000 entre 26: unos 462 por semana, en un lugar distinto de su gasto.
- No da códigos: el soporte real nunca los pide; entra él a soporte desde la app.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Entran 3,800, gasolina 700, mantenimiento 250 y datos 100. ¿Cuál es tu ingreso real? |
| P02 | M1 U02 | Ganas 1,200 reales en 15 horas de noche. ¿Cuánto por hora? |
| P03 | M1 U03 | Tu sueldo es 2,000 y esta semana hiciste 2,700. ¿Cuánto va al colchón? |
| P04 | M2 U01 | Haces 16,000 al mes en moto en una app. ¿Cuál es tu ingreso neto y llegas al umbral? |
| P05 | M2 U02 | Trabajas 6 horas al día, 5 días a la semana, 10 semanas. ¿Pasas de 288 horas? |
| P06 | M2 U03 | Tu promedio semanal es 2,500 y te desactivan dos semanas. ¿Cuánto necesitas de tu colchón? |
| P07 | M3 U01 | Escribe los dos datos del IMSS que debes tener a la mano. |
| P08 | M3 U02 | Ganas 13,000 al mes en moto en una app. ¿Llegas al umbral (neto de 9,582.47)? |
| P09 | M3 U03 | Aportas 150 al mes durante 10 años. ¿Cuánto aportas, sin rendimientos? |
| P10 | M4 U01 | Ganas 8,000 sin RFC. ¿Cuánto ISR te retienen? ¿Y con RFC? |
| P11 | M4 U02 | Escribe los cuatro datos que necesitas para tu RFC. |
| P12 | M4 U03 | Escribe dos cosas que revisas cada mes con el SAT. |
| P13 | M5 U01 | Llantas 2,400 dos veces al año y aceite 450 seis veces al año. ¿Cuánto al año? |
| P14 | M5 U02 | Escribe las preguntas que haces antes de contratar un seguro de tu vehículo. |
| P15 | M5 U03 | Una moto cuesta 32,000 de contado y a pagos son 52 semanas de 850. ¿Cuánto pagas de más? |
| P16 | M6 U01 | Escribe los cuatro pasos de las primeras horas. |
| P17 | M6 U02 | Tus gastos son 2,800 por semana. ¿Cuánto es tu meta de un mes (4 semanas)? |
| P18 | M6 U03 | De madrugada ganas 35 por hora y en la comida 90. ¿Cuántas horas de madrugada equivalen a 2 horas en la comida? |
| P19 | M7 U01 | Te descuentan 150 al día por 20 días. ¿Cuánto pagas? Si te prestaron 2,500, ¿cuánto cuesta? |
| P20 | M7 U02 | Te pagan 600 por semana por tu cuenta. ¿Cuánto en un año? ¿Vale el riesgo de perder tu trabajo? |
| P21 | M7 U03 | Escribe la frase que usarás si alguien te pide un código. |
| P22 | M8 U01 | Aportas 300 al mes durante 15 años. ¿Cuánto aportas, sin rendimientos? |
| P23 | M8 U02 | Quieres 10,000 en 25 semanas. ¿Cuánto apartas por semana? |
| P24 | M8 U03 | Escribe la siguiente acción de la parte «SAT» con una fecha. |

### Respuestas

- **P01:** 2,750 pesos.
- **P02:** 80 pesos.
- **P03:** 700 pesos.
- **P04:** 10,880 pesos (16,000 menos 32%); sí llegas.
- **P05:** Sí: son 300 horas.
- **P06:** 5,000 pesos.
- **P07:** Mi número de seguridad social y mi clínica asignada.
- **P08:** No: tu neto es 8,840 (13,000 menos 32%).
- **P09:** 18,000 pesos.
- **P10:** Sin RFC 1,600; con RFC 168.
- **P11:** CURP, correo, domicilio y una contraseña o e.firma.
- **P12:** Mi buzón tributario y mi opinión de cumplimiento.
- **P13:** 7,500 pesos.
- **P14:** ¿Cubre uso con apps?, ¿qué cubre?, ¿cuánto es el deducible?, ¿cuánto cuesta al año?
- **P15:** 12,200 pesos (44,200 en total).
- **P16:** Salud, pruebas, avisar a la plataforma y acudir al IMSS.
- **P17:** 11,200 pesos.
- **P18:** Unas 5 horas (180 entre 35).
- **P19:** Pagas 3,000; cuesta 500.
- **P20:** 31,200 pesos; no, porque arriesgas tu cuenta, tu RFC y problemas legales.
- **P21:** Ejemplo: «No doy códigos; entro yo a soporte desde la app».
- **P22:** 54,000 pesos.
- **P23:** 400 pesos.
- **P24:** Ejemplo: «Registrar mi RFC en la app el sábado 10».


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu ingreso real

- **Apartado:** espacio aparte en tu cuenta.
- **Colchón:** dinero guardado para semanas malas.
- **Ganancia por hora:** lo que te queda por cada hora conectado.
- **Hora pico:** horas con más pedidos.
- **Ingreso bruto:** lo que entra antes de gastos.
- **Ingreso real:** lo que te queda después de gastos de trabajo.
- **Mantenimiento:** cuidados del vehículo para que no falle.
- **Promedio:** lo que ganas en una semana normal.
- **Regreso vacío:** viaje sin pago para volver.

### Tus derechos con la reforma

- **Conciliación:** acuerdo con ayuda de una autoridad.
- **Desactivación:** cuando la app te bloquea.
- **Ingreso neto:** lo que queda después del descuento según tu vehículo.
- **Persona trabajadora de plataforma:** quien llega al umbral de ingreso neto en una app.
- **Prima vacacional:** pago extra por vacaciones.
- **Proporcional:** parte según lo que trabajaste.
- **Reparto de utilidades:** parte de las ganancias de la empresa.
- **Transparencia algorítmica:** derecho a saber cómo decide el sistema.
- **Umbral:** la cantidad mínima para entrar.

### Tu IMSS, tu Afore y tu Infonavit

- **Afore:** tu cuenta de ahorro para el retiro.
- **Aportación voluntaria:** lo que tú agregas.
- **Beneficiario:** familiar con servicio médico por ti.
- **Conectado:** activo en la app.
- **IMSS voluntario:** afiliarte por tu cuenta.
- **Número de seguridad social:** tu número en el IMSS.
- **Riesgo de trabajo:** accidente o enfermedad por trabajar.
- **Semanas cotizadas:** semanas con IMSS.
- **Vigencia:** que tu derecho está activo.

### Tus impuestos

- **Buzón tributario:** canal de avisos del SAT.
- **Declaración anual:** reporte de tus ingresos del año.
- **e.firma:** firma electrónica para trámites.
- **ISR:** impuesto sobre la renta.
- **IVA:** impuesto al valor agregado.
- **Opinión de cumplimiento:** constancia de si estás al corriente.
- **Retención:** impuesto que te quitan y pagan por ti.
- **RFC:** tu registro ante el SAT.
- **Régimen fiscal:** tipo de actividad que declaras.

### Tu vehículo

- **Contado:** pagar todo de una vez.
- **Deducible:** lo que pagas tú.
- **Enganche:** primer pago grande.
- **Opción a compra:** que al final puede ser tuyo.
- **Refrendo:** pago anual de placas, según el estado.
- **Responsabilidad civil:** daños a otras personas o sus cosas.
- **Uso comercial:** usar el vehículo para trabajar.

### Accidentes, salud y días sin trabajo

- **Constancia:** hacerlo siempre.
- **Descanso:** tiempo para recuperarte.
- **Estrés financiero:** preocupación por dinero.
- **Etapa:** paso de una meta.
- **Fatiga:** cansancio que afecta tu atención.
- **Fondo de emergencia:** dinero para cuando no puedes trabajar.
- **Incapacidad:** permiso médico para no trabajar.
- **Subsidio:** pago mientras estás incapacitado.

### Préstamos y fraudes en la ruta

- **Adelanto:** dinero que te dan antes y se descuenta después.
- **CAT:** costo anual total.
- **Cuenta de pagos:** donde la app te deposita.
- **Código SMS:** número que te llega para confirmar tu identidad.
- **Financiera aliada:** empresa que presta a través de la app.
- **Identidad:** tus datos que te identifican.
- **Soporte falso:** alguien que se hace pasar por la app.
- **Verificación en dos pasos:** un código extra al entrar.

### Tu futuro

- **Domiciliar:** cargo automático.
- **Escalón:** paso hacia algo mejor.
- **Meta:** algo que quieres lograr.
- **Plan:** lista de lo que harás y cuándo.
- **Retiro:** cuando dejas de trabajar por edad.
- **Revisión:** volver a ver cómo vas.
- **Siguiente acción:** el próximo paso concreto.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Presupuesto con ingreso variable | CONDUSEF: https://www.condusef.gob.mx | «ingresos variables» | M1 U01 |
| Presupuesto | CONDUSEF: https://www.condusef.gob.mx | «presupuesto» | M1 U02, M5 U01 |
| Fondo de emergencia | CONDUSEF: https://www.condusef.gob.mx | «fondo de emergencia» | M1 U03, M6 U02 |
| Preguntas frecuentes de la reforma | STPS: https://www.gob.mx/stps | «trabajo en plataformas digitales» | M2 U01 |
| Derechos en plataformas | STPS: https://www.gob.mx/stps | «plataformas digitales preguntas frecuentes» | M2 U02 |
| PROFEDET | Gobierno de México: https://www.gob.mx/profedet | 800 911 7877 | — | M2 U03 |
| Vigencia de derechos | IMSS: https://www.imss.gob.mx | «vigencia de derechos» y «plataformas digitales» | M3 U01 |
| IMSS para estudiantes | IMSS: https://www.imss.gob.mx | «estudiantes» | M3 U02 |
| IMSS-Bienestar | Gobierno de México: https://www.gob.mx/imss-bienestar | — | M3 U02 |
| AforeMóvil | CONSAR: https://www.gob.mx/consar | «AforeMóvil» | M3 U03 |
| Semanas cotizadas | IMSS: https://serviciosdigitales.imss.gob.mx | — | M3 U03 |
| Plataformas tecnológicas | SAT: https://www.sat.gob.mx | «plataformas tecnológicas» | M4 U01 |
| Inscripción al RFC | SAT: https://www.sat.gob.mx | «inscripción al RFC con CURP» | M4 U02 |
| Opinión de cumplimiento | SAT: https://www.sat.gob.mx | «opinión del cumplimiento» | M4 U03 |
| Orientación | SAT: MarcaSAT 55 627 22 728 | — | M4 U03 |
| Seguros de auto | CONDUSEF: https://www.condusef.gob.mx | «seguro de auto» | M5 U02 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M5 U02, M7 U01 |
| Créditos automotrices | CONDUSEF: https://www.condusef.gob.mx | «crédito automotriz» | M5 U03 |
| Riesgos de trabajo | IMSS: https://www.imss.gob.mx | «riesgo de trabajo» | M6 U01 |
| Línea de la Vida | Gobierno de México: 800 911 2000 | — | M6 U03 |
| Créditos | CONDUSEF: https://www.condusef.gob.mx | «CAT» | M7 U01 |
| Robo de identidad | CONDUSEF: https://www.condusef.gob.mx | «robo de identidad» | M7 U02 |
| Fraudes | CONDUSEF: https://www.condusef.gob.mx | «phishing» y «robo de cuentas» | M7 U03 |
| Ahorro voluntario | CONSAR: https://www.gob.mx/consar | «ahorro voluntario» | M8 U01 |
| Metas de ahorro | CONDUSEF: https://www.condusef.gob.mx | «metas de ahorro» | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Tu ingreso real

- **M1 U01 · Lo que entra no es lo que ganas.** CONDUSEF, presupuesto con ingresos variables; consultado el 5 de octubre de 2026.
- **M1 U02 · Cuánto ganas por hora.** Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.
- **M1 U03 · Un sueldo fijo en un trabajo variable.** CONDUSEF, ahorro con ingreso variable; consultado el 5 de octubre de 2026.

### Tus derechos con la reforma

- **M2 U01 · ¿Eres persona trabajadora de plataforma?.** Decreto de reforma a la Ley Federal del Trabajo en materia de plataformas digitales (DOF, 24 de diciembre de 2024); STPS, factores de exclusión 2026; consultados el 5 de octubre de 2026.
- **M2 U02 · Aguinaldo, vacaciones y reparto de utilidades.** Ley Federal del Trabajo, reforma en materia de plataformas digitales; STPS; consultados el 5 de octubre de 2026.
- **M2 U03 · Desactivaciones y cómo reclamar.** Ley Federal del Trabajo, reforma en materia de plataformas digitales; PROFEDET; consultados el 5 de octubre de 2026.

### Tu IMSS, tu Afore y tu Infonavit

- **M3 U01 · Lo que te da el IMSS completo.** IMSS, incorporación de personas trabajadoras de plataformas digitales; consultado el 5 de octubre de 2026.
- **M3 U02 · Si no llegas al umbral.** IMSS, cobertura por riesgos de trabajo para personas trabajadoras independientes de plataformas; consultado el 5 de octubre de 2026.
- **M3 U03 · Tu Afore y tus semanas.** IMSS; CONSAR; consultados el 5 de octubre de 2026.

### Tus impuestos

- **M4 U01 · Lo que la app retiene de impuestos.** SAT, régimen de plataformas tecnológicas y Ley de Ingresos 2026; consultados el 5 de octubre de 2026.
- **M4 U02 · Tu RFC y tu e.firma.** SAT, inscripción al RFC y régimen de plataformas tecnológicas; consultado el 5 de octubre de 2026.
- **M4 U03 · Al corriente con el SAT.** SAT, opinión de cumplimiento y buzón tributario; consultado el 5 de octubre de 2026.

### Tu vehículo

- **M5 U01 · El apartado del vehículo.** Elaboración propia; CONDUSEF; consultado el 5 de octubre de 2026.
- **M5 U02 · El seguro de tu vehículo.** CONDUSEF, seguros de automóvil; consultado el 5 de octubre de 2026.
- **M5 U03 · Comprar, financiar o rentar tu vehículo.** CONDUSEF, créditos automotrices; consultado el 5 de octubre de 2026.

### Accidentes, salud y días sin trabajo

- **M6 U01 · Si tienes un accidente en la ruta.** IMSS, seguro de riesgos de trabajo; consultado el 5 de octubre de 2026.
- **M6 U02 · Un fondo para los días sin trabajo.** CONDUSEF, fondo de emergencia; consultado el 5 de octubre de 2026.
- **M6 U03 · Cansancio, estrés y tu dinero.** INEGI y CONDUSEF, ENSAFI 2023; consultado el 5 de octubre de 2026.

### Préstamos y fraudes en la ruta

- **M7 U01 · Adelantos y préstamos dentro de la app.** CONDUSEF, CAT y créditos; consultado el 5 de octubre de 2026.
- **M7 U02 · Rentar o prestar tu cuenta.** CONDUSEF, robo de identidad; consultado el 5 de octubre de 2026.
- **M7 U03 · Soporte falso y robo de cuentas.** CONDUSEF, alertas de fraude; consultado el 5 de octubre de 2026.

### Tu futuro

- **M8 U01 · Tu retiro aunque trabajes con apps.** CONSAR, ahorro voluntario; consultado el 5 de octubre de 2026.
- **M8 U02 · La app como escalón.** CONDUSEF, metas de ahorro; consultado el 5 de octubre de 2026.
- **M8 U03 · Tu plan de ruta en una página.** Elaboración propia con base en los módulos 1 a 8 del programa.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Lo que entra no es lo que ganas

**Caso 1. La semana de 4,200.** Beto cree que ganó 4,200. **¿Qué hace?**

- ✔ Resta sus gastos y presupuesta con lo real.
- Hace su presupuesto con los 4,200 que muestra la app.
- Trabaja más horas para que alcance.

**Caso 2. El auto rentado.** Don Chava paga 2,500 de renta por semana y no la cuenta. **¿Qué hace?**

- ✔ Resta la renta.
- No la cuenta, porque esa es la parte del dueño del auto y no suya.
- La paga con el dinero de la casa.

**Caso 3. La bici de Kevin.** Kevin cree que en bici no tiene gastos. **¿Qué hace?**

- ✔ Anota llantas, frenos y datos.
- No anota nada, porque en bici no gasta gasolina.
- Solo cuenta lo que gasta en comida.

## M1 U02. Cuánto ganas por hora

**Caso 1. Sesenta horas.** Mariana trabaja muchas horas y gana poco por hora. **¿Qué hace?**

- ✔ Compara sus horarios y trabaja en los que pagan mejor.
- Trabaja todavía más horas.
- Se conecta a todas horas por si acaso.

**Caso 2. Las esperas.** Beto no cuenta el tiempo que espera pedidos. **¿Qué hace?**

- ✔ Incluye las esperas.
- Cuenta solo el tiempo con pedido, porque esperar no es trabajar.
- No cuenta horas.

**Caso 3. Viajes largos.** Don Chava acepta viajes que lo dejan lejos y regresa vacío. **¿Qué hace?**

- ✔ Calcula contando el regreso vacío.
- Acepta todos los viajes largos porque pagan más.
- Rechaza todos los viajes largos.

## M1 U03. Un sueldo fijo en un trabajo variable

**Caso 1. La semana buena.** Kevin hizo 2,500. **¿Qué hace?**

- ✔ Se paga su sueldo y guarda el resto.
- Se gasta los 2,500 porque fue una semana buena.
- Presta el extra a un amigo.

**Caso 2. La semana mala.** Beto hizo 1,800 y su sueldo es 2,600. **¿Qué hace?**

- ✔ Completa con su colchón.
- Pide prestado en una app para completar los 800 pesos que le faltan.
- Deja de pagar la renta.

**Caso 3. Todo junto.** Mariana guarda el colchón en la tarjeta de diario. **¿Qué hace?**

- ✔ Lo pasa a un apartado distinto.
- Lo deja en la tarjeta de diario.
- Lo guarda en la cajuela.

## M2 U01. ¿Eres persona trabajadora de plataforma?

**Caso 1. ¿Me toca?.** Don Chava no sabe si le corresponde. **¿Qué hace?**

- ✔ Calcula su ingreso neto en su app principal.
- Pregunta en un grupo de chat y le cree al primero.
- Supone que no le toca.

**Caso 2. Dos apps.** Beto reparte 8,000 en cada una de dos apps en moto. **¿Qué hace?**

- ✔ Revisa que no llega en ninguna y decide.
- Suma las dos apps y cree que ya llega al umbral.
- Abre una tercera app.

**Caso 3. En bici.** Kevin hace 10,500 al mes en bici en una app. **¿Qué hace?**

- ✔ Calcula: con 3% sí llega.
- Supone que en bici nunca se llega.
- Le aplica el 32% de las motos.

## M2 U02. Aguinaldo, vacaciones y reparto de utilidades

**Caso 1. El depósito extra.** Mariana cree que el aguinaldo es un error. **¿Qué hace?**

- ✔ Revisa el detalle y guarda captura.
- Lo reporta como error para devolverlo, por si acaso.
- Lo gasta sin revisar.

**Caso 2. Pocas horas.** Kevin trabaja 200 horas al año en una app. **¿Le toca reparto de utilidades?**

- ✔ No, porque no pasa de 288 horas.
- Sí, porque trabaja en una app.
- Sí, porque es estudiante.

**Caso 3. No ve nada.** Don Chava pasa el umbral y no ve ninguna prestación. **¿Qué hace?**

- ✔ Junta capturas y pregunta en soporte.
- Se queda sin decir nada, porque cree que reclamar no sirve.
- Deja la app.

## M2 U03. Desactivaciones y cómo reclamar

**Caso 1. La desactivación.** Beto fue desactivado sin explicación. **¿Qué hace?**

- ✔ Pide por escrito la razón y la revisión.
- Abre una cuenta nueva con los datos de un familiar para seguir trabajando.
- Se queda esperando.

**Caso 2. Sin respuesta.** Pasó una semana y nadie le contesta. **¿Qué hace?**

- ✔ Acude a la PROFEDET.
- Espera otro mes sin hacer nada.
- Paga a alguien que desbloquea cuentas.

**Caso 3. El que desbloquea.** Le ofrecen a Beto desbloquear su cuenta por 500 pesos. **¿Qué hace?**

- ✔ No paga ni da su contraseña.
- Paga los 500 porque necesita trabajar ya.
- Le da su contraseña para ver si funciona.

## M3 U01. Lo que te da el IMSS completo

**Caso 1. ¿Estoy dada de alta?.** Mariana no sabe si tiene IMSS. **¿Qué hace?**

- ✔ Consulta su vigencia con su CURP.
- Espera a enfermarse para ver si la atienden.
- Pregunta en el taller.

**Caso 2. La hija.** La hija de Mariana no tiene servicio médico. **¿Qué hace?**

- ✔ La registra como beneficiaria.
- La lleva a consulta con la credencial de Mariana sin registrarla.
- Paga médico privado siempre.

**Caso 3. No aparece.** Don Chava pasa el umbral y no aparece en el IMSS. **¿Qué hace?**

- ✔ Pregunta en soporte y guarda capturas.
- Supone que no le toca.
- Deja de trabajar en esa app.

## M3 U02. Si no llegas al umbral

**Caso 1. «No tengo nada».** Kevin cree que no tiene protección. **¿Qué hace?**

- ✔ Sabe que tiene riesgos de trabajo y la completa.
- Cree que no tiene ninguna protección y no hace nada.
- Deja de repartir.

**Caso 2. Estudiante.** Kevin estudia en una universidad pública. **¿Qué hace?**

- ✔ Pregunta por su alta como estudiante.
- No pregunta.
- Usa la credencial de un compañero.

**Caso 3. Cerca del umbral.** Beto está a 1,500 pesos del umbral en una app. **¿Qué hace?**

- ✔ Evalúa concentrarse en esa app.
- Abre otra app para ganar más en total.
- No hace nada.

## M3 U03. Tu Afore y tus semanas

**Caso 1. «Eso no es para nosotros».** Don Chava cree que no tiene retiro. **¿Qué hace?**

- ✔ Localiza su Afore y consulta sus semanas.
- Supone que los de las apps no tienen retiro.
- Deja todo para los 60.

**Caso 2. Meses abajo del umbral.** Beto no siempre llega al umbral. **¿Qué hace?**

- ✔ Hace aportaciones voluntarias.
- No aporta esos meses, porque no llega al umbral y cree que no sirve.
- Pide prestado para aportar.

**Caso 3. Afore desconocida.** Kevin no sabe si tiene Afore. **¿Qué hace?**

- ✔ La busca con su CURP en AforeMóvil.
- Abre otra Afore sin buscar la suya.
- No la busca.

## M4 U01. Lo que la app retiene de impuestos

**Caso 1. «Me roban».** Beto cree que la retención es un robo. **¿Qué hace?**

- ✔ Entiende que es su pago de impuestos.
- Deja la app porque cree que le roban.
- Pide que no le retengan.

**Caso 2. Sin RFC.** Al compañero de Beto le retienen 20%. **¿Qué hace?**

- ✔ Saca su RFC y lo registra en la app.
- Sigue sin RFC, porque cree que así el SAT no lo encuentra.
- Usa el RFC de su hermano.

**Caso 3. Las constancias.** Mariana nunca ha descargado sus constancias. **¿Qué hace?**

- ✔ Las descarga y guarda.
- No las descarga.
- Las borra.

## M4 U02. Tu RFC y tu e.firma

**Caso 1. Los 600 pesos.** Le cobran a Kevin por sacar su RFC. **¿Qué hace?**

- ✔ Lo saca él, sin costo, en el portal.
- Paga los 600 pesos para que se lo hagan rápido.
- No saca RFC.

**Caso 2. El régimen.** Mariana no sabe qué régimen poner. **¿Qué hace?**

- ✔ Elige plataformas y, si duda, pregunta.
- Elige cualquiera de la lista.
- Pone sueldos y salarios.

**Caso 3. La e.firma prestada.** Un conocido le pide a Don Chava su e.firma para «facturar unas cosas». **¿Qué hace?**

- ✔ No la presta.
- La presta porque es un conocido de confianza que solo va a facturar unas cosas.
- La presta una vez.

## M4 U03. Al corriente con el SAT

**Caso 1. El aviso.** Mariana recibe un aviso del SAT. **¿Qué hace?**

- ✔ Revisa su opinión de cumplimiento.
- Lo ignora, porque seguro es otro correo de publicidad.
- Paga a un gestor sin revisar.

**Caso 2. El gestor.** Le ofrecen a Beto «arreglar su SAT» por 2,000. **¿Qué hace?**

- ✔ Pregunta primero al SAT.
- Paga los 2,000.
- Ignora el tema.

**Caso 3. El correo falso.** Le llega a Kevin un correo del «SAT» pidiendo su contraseña. **¿Qué hace?**

- ✔ No responde y entra él al portal.
- Responde con su contraseña.
- Le da clic a la liga.

## M5 U01. El apartado del vehículo

**Caso 1. La cadena y las llantas.** A Beto le llegaron dos gastos el mismo mes. **¿Qué hace para la próxima?**

- ✔ Aparta cada semana para mantenimiento.
- Espera a que se vuelva a romper y pide prestado.
- Deja de dar mantenimiento.

**Caso 2. Sin saber cuánto.** Mariana no sabe cuánto gasta al año en su auto. **¿Qué hace?**

- ✔ Llena su tabla con los gastos del año.
- Calcula a ojo.
- No calcula nada.

**Caso 3. La bici.** Kevin cree que no necesita apartado. **¿Qué hace?**

- ✔ Aparta poco para llantas, frenos y cámaras.
- No aparta nada, porque la bici no necesita casi nada.
- Compra una bici nueva cuando falle.

## M5 U02. El seguro de tu vehículo

**Caso 1. El choque.** Mariana pensó que el seguro de la app cubría todo. **¿Qué hace?**

- ✔ Busca una póliza que cubra uso con apps.
- Supone que el seguro de la app cubre todo, siempre.
- Deja de manejar.

**Caso 2. Seguro personal.** Beto tiene un seguro personal de su moto. **¿Qué hace?**

- ✔ Pregunta por escrito si cubre cuando trabaja.
- Supone que sí cubre.
- Cancela su seguro.

**Caso 3. El deducible alto.** A Don Chava le ofrecen un seguro barato con deducible altísimo. **¿Qué hace?**

- ✔ Compara cuánto pagaría él en un choque.
- Lo contrata porque es el más barato.
- Contrata el más caro.

## M5 U03. Comprar, financiar o rentar tu vehículo

**Caso 1. A pagos.** A Don Chava le ofrecen un auto a 2,900 por semana durante tres años. **¿Qué hace?**

- ✔ Calcula el total y compara.
- Acepta porque el pago semanal se parece a la renta que ya paga.
- Firma sin leer.

**Caso 2. Pierde lo pagado.** El contrato dice que si se atrasa, pierde todo. **¿Qué hace?**

- ✔ No firma sin entender.
- Firma y confía en no atrasarse nunca.
- Firma y luego pregunta.

**Caso 3. La moto nueva.** Beto quiere una moto nueva a crédito. **¿Qué hace?**

- ✔ Compara el total y revisa que el pago quepa.
- Elige la que tenga el pago más chico.
- Pide dos motos.

## M6 U01. Si tienes un accidente en la ruta

**Caso 1. La caída.** Kevin se cayó en una entrega. **¿Qué hace?**

- ✔ Toma captura, avisa a la app y va al IMSS.
- Se va a su casa a descansar sin avisar a nadie.
- Sigue repartiendo con dolor.

**Caso 2. «Aguántate».** A Beto le duele la rodilla tras un golpe y piensa seguir trabajando. **¿Qué hace?**

- ✔ Se atiende y deja registro.
- Sigue trabajando aunque le duela, porque no quiere perder el día.
- Se automedica.

**Caso 3. El choque.** Mariana choca con otro auto. **¿Qué hace?**

- ✔ Llama a su aseguradora antes de acordar.
- Arregla con el otro conductor ahí mismo, sin papeles.
- Se va del lugar.

## M6 U02. Un fondo para los días sin trabajo

**Caso 1. La niña enferma.** Mariana no pudo trabajar y pidió prestado. **¿Qué hace ahora?**

- ✔ Aparta una cantidad fija cada día.
- Espera a que algún día le sobre dinero para empezar a ahorrar.
- Pide prestado para tener un fondo.

**Caso 2. «No me sobra».** Beto dice que no le sobra nada. **¿Qué hace?**

- ✔ Empieza con 30 pesos al día.
- No ahorra.
- Ahorra solo en diciembre.

**Caso 3. Lo usó.** Kevin usó su fondo por la caída. **¿Qué hace después?**

- ✔ Lo vuelve a llenar poco a poco.
- Lo deja vacío.
- Pide prestado para llenarlo de golpe.

## M6 U03. Cansancio, estrés y tu dinero

**Caso 1. Catorce horas.** Beto trabaja 14 horas por sus deudas. **¿Qué hace?**

- ✔ Trabaja en mejores horarios y hace plan de deudas.
- Trabaja 16 horas para pagar más rápido, aunque duerma poco.
- Toma café y sigue.

**Caso 2. Ojos pesados.** Mariana siente los ojos pesados de madrugada. **¿Qué hace?**

- ✔ Se detiene y descansa.
- Sigue manejando.
- Sube la música.

**Caso 3. Dolor de estómago.** Don Chava tiene gastritis desde que debe la renta del auto. **¿Qué hace?**

- ✔ Se atiende y revisa su presupuesto.
- Ignora el dolor.
- Se toma algo y sigue.

## M7 U01. Adelantos y préstamos dentro de la app

**Caso 1. El adelanto cómodo.** A Don Chava le ofrecen 3,000 que se descuentan solos. **¿Qué hace?**

- ✔ Pregunta el total y usa primero su colchón.
- Lo acepta porque se descuenta solo y no tiene que hacer nada.
- Pide el doble.

**Caso 2. Descuento diario.** A Beto le descontarían 250 al día por un préstamo. **¿Qué hace?**

- ✔ Revisa si le alcanza su sueldo.
- Acepta sin calcular.
- Pide otro préstamo para el descuento.

**Caso 3. La financiera aliada.** Mariana no sabe quién le presta en la app. **¿Qué hace?**

- ✔ La busca en el SIPRES.
- Confía porque está en la app.
- No le importa.

## M7 U02. Rentar o prestar tu cuenta

**Caso 1. Prestar la cuenta.** Le ofrecen a Kevin 600 a la semana por su cuenta. **¿Qué hace?**

- ✔ No la presta.
- La presta, porque 600 pesos a la semana es dinero fácil mientras estudia.
- La presta solo a un amigo.

**Caso 2. La cuenta del primo.** A Don Chava le ofrecen trabajar con la cuenta de un primo. **¿Qué hace?**

- ✔ Abre su propia cuenta.
- Usa la del primo para empezar ya.
- Usa la del primo y paga una parte.

**Caso 3. Contraseña compartida.** Beto le dio su contraseña a un amigo hace meses. **¿Qué hace?**

- ✔ La cambia y activa verificación en dos pasos.
- Deja la misma, porque confía en su amigo.
- Comparte también su correo.

## M7 U03. Soporte falso y robo de cuentas

**Caso 1. El código.** A Mariana le piden el código del SMS para «no bloquear» su cuenta. **¿Qué hace?**

- ✔ No lo manda y entra a soporte desde la app.
- Lo manda rápido, porque no quiere perder su cuenta hoy.
- Manda la mitad del código.

**Caso 2. La liga.** A Beto le llega una liga para «actualizar sus datos de pago». **¿Qué hace?**

- ✔ No la abre y revisa desde la app.
- Abre la liga para ver qué es.
- Reenvía la liga a sus compañeros.

**Caso 3. Ya robaron.** A Don Chava le cambiaron la cuenta de pagos. **¿Qué hace?**

- ✔ Reporta desde la app y avisa a su banco.
- Espera a ver si regresa el dinero.
- Abre otra cuenta.

## M8 U01. Tu retiro aunque trabajes con apps

**Caso 1. «Está muy lejos».** Beto cree que el retiro no le importa todavía. **¿Qué hace?**

- ✔ Domicilia una aportación mensual.
- Lo deja para cuando tenga 40, porque ahora necesita el dinero.
- Ahorra en efectivo en su casa.

**Caso 2. Semana mala.** A Mariana le fue mal este mes. **¿Qué hace?**

- ✔ Aporta menos, pero no deja de aportar.
- Deja de aportar ese mes y los siguientes.
- Pide prestado para aportar.

**Caso 3. A los 47.** Don Chava cree que ya es tarde. **¿Qué hace?**

- ✔ Aporta y busca sumar semanas.
- Se rinde porque ya es tarde.
- Espera a que sus hijos lo mantengan.

## M8 U02. La app como escalón

**Caso 1. Sin meta clara.** Kevin dice que quiere «juntar para algo». **¿Qué hace?**

- ✔ Pone su meta en números.
- Sigue juntando «para algo», sin cantidad ni fecha.
- Gasta lo que junta.

**Caso 2. Todo en un lugar.** Mariana guarda la meta junto con su fondo de emergencia. **¿Qué hace?**

- ✔ Los separa en apartados distintos.
- Los deja juntos.
- Usa la meta para emergencias.

**Caso 3. El auto propio.** Don Chava quiere su auto. **¿Qué hace?**

- ✔ Calcula el enganche y aparta cada semana.
- Pide un crédito sin enganche hoy mismo.
- Espera a ganarse la lotería.

## M8 U03. Tu plan de ruta en una página

**Caso 1. Notas regadas.** Mariana tiene todo disperso en el celular. **¿Qué hace?**

- ✔ Junta todo en su plan de una página.
- Sigue con sus notas regadas, porque ahí está todo.
- Lo borra todo.

**Caso 2. Todo hoy.** Kevin quiere resolver las seis partes hoy. **¿Qué hace?**

- ✔ Escribe una acción con fecha para cada parte.
- Intenta resolver todo hoy.
- Lo deja para el próximo año.

**Caso 3. El plan olvidado.** Beto hizo su plan y no lo volvió a ver. **¿Qué hace?**

- ✔ Lo revisa cada mes.
- No lo vuelve a ver.
- Hace otro plan cada semana.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Qué es tu ingreso real?

- Lo que te dan de propina los clientes
- Lo que muestra la app al final del día
- ✔ Lo que entra menos lo que te cuesta trabajar

*¡Correcto! El real.*

**M1 U01 P2.** Entran 5,000 y gastas 1,600 en trabajar. ¿Cuánto ganas?

- 5,000
- ✔ 3,400
- 6,600

*¡Correcto! 5,000 menos 1,600.*

**M1 U01 P3.** ¿Qué cuenta como gasto de trabajo?

- La renta de tu casa
- ✔ La gasolina
- Tus vacaciones

*¡Correcto! Gasolina.*

**M1 U02 P1.** Ganas 2,400 reales en 40 horas. ¿Cuánto por hora?

- 2,400
- 40
- ✔ 60

*¡Correcto! 2,400 entre 40.*

**M1 U02 P2.** ¿Las esperas sin pedido cuentan como horas?

- No
- ✔ Sí
- Solo si llueve

*¡Correcto! Estás conectado.*

**M1 U02 P3.** ¿Para qué sirve anotar por bloques de horario?

- Para nada
- ✔ Para ver qué horas te dejan más
- Para pagar menos impuestos al SAT

*¡Correcto! Comparar.*

**M1 U03 P1.** Cuatro semanas suman 8,000. ¿Cuál es tu promedio?

- 4,000
- 8,000
- ✔ 2,000

*¡Correcto! 8,000 entre 4.*

**M1 U03 P2.** ¿Cuánto conviene que sea tu sueldo semanal?

- Igual a tu mejor semana
- ✔ Un poco menos que tu promedio
- Lo que salga cada semana, sin fijarlo

*¡Correcto! Menor al promedio.*

**M1 U03 P3.** Semana mala: ¿de dónde completas?

- De un préstamo
- ✔ De tu colchón
- De la app

*¡Correcto! El colchón.*

## Módulo 2

**M2 U01 P1.** ¿Desde cuándo está vigente la reforma de plataformas?

- ✔ Desde el 22 de junio de 2025
- Desde 2010, con la primera app
- Todavía no

*¡Correcto! Junio de 2025.*

**M2 U01 P2.** ¿Cuánto se descuenta en auto para calcular el neto?

- 3%
- ✔ 48%
- 32%

*¡Correcto! 48%.*

**M2 U01 P3.** ¿El umbral se cuenta sumando todas tus apps?

- Sí
- Solo si son dos apps del mismo tipo
- ✔ No, por plataforma

*¡Correcto! Por plataforma.*

**M2 U02 P1.** ¿Qué te corresponde como persona trabajadora de plataforma?

- ✔ Aguinaldo y vacaciones proporcionales
- Nada
- Solo las propinas de los clientes

*¡Correcto! Proporcionales.*

**M2 U02 P2.** ¿Cuántas horas al año para el reparto de utilidades?

- 100
- ✔ Más de 288
- 2,000

*¡Correcto! 288.*

**M2 U02 P3.** ¿Qué guardas cada mes?

- Nada
- Los tickets de gasolina de otros
- ✔ Capturas del detalle de pagos

*¡Correcto! Capturas.*

**M2 U03 P1.** Te desactivan sin explicación. ¿Qué haces primero?

- ✔ Pides por escrito la razón y la revisión
- Abres otra cuenta con el nombre de un familiar para seguir trabajando
- Nada

*¡Correcto! Por escrito.*

**M2 U03 P2.** ¿Quién te orienta sin costo?

- Un gestor
- ✔ La PROFEDET
- El que desbloquea cuentas

*¡Correcto! PROFEDET.*

**M2 U03 P3.** ¿Qué guardas como prueba?

- Solo tu memoria de lo que pasó
- Nada
- ✔ Capturas con fechas

*¡Correcto! Capturas.*

## Módulo 3

**M3 U01 P1.** ¿Con qué consultas tu vigencia en el IMSS?

- Con la placa
- Con tu licencia
- ✔ Con tu CURP

*¡Correcto! CURP.*

**M3 U01 P2.** ¿Qué haces para que tu hija tenga IMSS?

- Nada
- ✔ La registras como beneficiaria
- Usas tu credencial cuando ella vaya

*¡Correcto! Beneficiaria.*

**M3 U01 P3.** Un mes no llegas al umbral. ¿Qué pasa?

- Nada cambia
- ✔ Ese mes no tienes cobertura completa
- Pierdes para siempre todas las semanas que ya tenías

*¡Correcto! Depende del mes.*

**M3 U02 P1.** No llegas al umbral. ¿Qué cobertura tienes conectado?

- Todo el IMSS, igual que un empleado
- Ninguna
- ✔ Riesgos de trabajo

*¡Correcto! Riesgos.*

**M3 U02 P2.** Estudias en escuela pública. ¿Qué puedes tener?

- ✔ IMSS como estudiante
- Nada
- Un préstamo para tus estudios

*¡Correcto! Estudiante.*

**M3 U02 P3.** Te accidentas fuera de la app. ¿Cubre riesgos de trabajo?

- Sí, siempre
- ✔ No, solo conectado
- Solo de noche, cuando hay más riesgo

*¡Correcto! Conectado.*

**M3 U03 P1.** ¿Dónde localizas tu Afore?

- En el taller donde arreglas la moto
- En la app de reparto, en tu perfil
- ✔ En AforeMóvil con tu CURP

*¡Correcto! AforeMóvil.*

**M3 U03 P2.** Tienes 500 semanas y eres Ley 97. ¿Cuántas te faltan en 2026?

- ✔ 375
- 500
- 75

*¡Correcto! 875 menos 500.*

**M3 U03 P3.** ¿Desde cuánto puedes hacer una aportación voluntaria?

- 5,000
- ✔ 50
- No se puede

*¡Correcto! Desde 50.*

## Módulo 4

**M4 U01 P1.** ¿Cuánto IVA te retienen con RFC?

- ✔ 8%
- 16%
- Nada

*¡Correcto! 8%.*

**M4 U01 P2.** Ganas 5,000. ¿Cuánto ISR te retienen con RFC?

- 1,000
- ✔ 105
- 500

*¡Correcto! 2.1% de 5,000.*

**M4 U01 P3.** ¿Qué haces con tus constancias de retención?

- Las tiras
- Las vendes a un gestor
- ✔ Las descargas y guardas

*¡Correcto! Guárdalas.*

**M4 U02 P1.** ¿Qué necesitas para inscribirte al RFC en línea?

- ✔ Tu CURP
- Una factura
- Un aval

*¡Correcto! CURP.*

**M4 U02 P2.** ¿Se presta la e.firma?

- A conocidos sí
- ✔ Nunca
- Solo a la familia

*¡Correcto! Nunca.*

**M4 U02 P3.** ¿Qué régimen es para las apps?

- Sueldos y salarios
- Arrendamiento, por usar tu vehículo
- ✔ Plataformas tecnológicas

*¡Correcto! Plataformas.*

**M4 U03 P1.** ¿Dónde ves si estás al corriente con el SAT?

- ✔ En la opinión de cumplimiento
- En la app de reparto, en tu perfil
- En el banco donde cobras

*¡Correcto! Opinión de cumplimiento.*

**M4 U03 P2.** Te piden tu contraseña por correo «del SAT». ¿Qué es?

- Normal
- Una actualización
- ✔ Fraude

*¡Correcto! El SAT no la pide.*

**M4 U03 P3.** ¿En qué mes se presenta la declaración anual de personas físicas?

- Julio
- Diciembre
- ✔ Abril

*¡Correcto! Abril.*

## Módulo 5

**M5 U01 P1.** Gastas 7,800 al año en mantenimiento. ¿Cuánto apartas por semana?

- 78
- 780
- ✔ 150

*¡Correcto! 7,800 entre 52.*

**M5 U01 P2.** ¿Para qué es el apartado del vehículo?

- ✔ Solo para el vehículo
- Para fiestas
- Para préstamos a tus compañeros

*¡Correcto! Solo vehículo.*

**M5 U01 P3.** ¿Qué pasa si pospones el mantenimiento?

- Ahorras siempre, porque no gastas
- ✔ La reparación puede salir más cara
- Nada

*¡Correcto! Más cara.*

**M5 U02 P1.** ¿Qué cubre la responsabilidad civil?

- Tu gasolina
- Tu celular si se te cae
- ✔ Los daños que le haces a otros

*¡Correcto! Terceros.*

**M5 U02 P2.** ¿Qué preguntas a tu aseguradora?

- ✔ Si cubre uso con apps
- El color de la póliza
- Nada

*¡Correcto! Uso con apps.*

**M5 U02 P3.** El daño es de 20,000 y el deducible de 5,000. ¿Cuánto paga el seguro?

- 20,000
- ✔ 15,000
- 5,000

*¡Correcto! 20,000 menos 5,000.*

**M5 U03 P1.** Pagas 1,000 por semana durante 104 semanas. ¿Cuánto en total?

- 1,000
- 10,400, uno por cada semana
- ✔ 104,000

*¡Correcto! 1,000 por 104.*

**M5 U03 P2.** ¿Qué revisas en el contrato?

- ✔ Qué pasa si te atrasas
- El color y el modelo del auto
- Nada

*¡Correcto! Atrasos.*

**M5 U03 P3.** ¿Con qué comparas el total a pagar?

- Con la gasolina
- ✔ Con el precio de contado
- Con la renta de tu casa

*¡Correcto! Contado.*

## Módulo 6

**M6 U01 P1.** Te accidentas conectado. ¿Qué te cubre el IMSS?

- ✔ Riesgo de trabajo
- Nada
- Solo si tienes auto

*¡Correcto! Riesgo de trabajo.*

**M6 U01 P2.** ¿Qué captura tomas?

- ✔ Del pedido o viaje activo
- De tus redes sociales del día
- Ninguna

*¡Correcto! Pedido activo.*

**M6 U01 P3.** Chocas con otro auto. ¿Qué haces antes de un acuerdo?

- Te vas
- Firmas lo que te den para terminar rápido
- ✔ Llamas a tu aseguradora

*¡Correcto! Aseguradora.*

**M6 U02 P1.** ¿Cuál es la primera meta del fondo?

- ✔ Una semana de gastos
- Un año completo de gastos desde el inicio
- Nada

*¡Correcto! Una semana.*

**M6 U02 P2.** Apartas 50 al día. ¿Cuánto en 30 días?

- ✔ 1,500
- 150
- 5,000

*¡Correcto! 50 por 30.*

**M6 U02 P3.** Usaste tu fondo. ¿Qué haces?

- Lo olvidas
- Pides prestado para llenarlo de una vez
- ✔ Lo vuelves a llenar

*¡Correcto! Llénalo.*

**M6 U03 P1.** Sientes los ojos pesados. ¿Qué haces?

- ✔ Te detienes a descansar
- Subes el volumen y abres la ventana
- Aceleras para llegar

*¡Correcto! Descansa.*

**M6 U03 P2.** ¿Qué te ayuda a trabajar menos horas?

- ✔ Elegir los horarios que pagan mejor
- Trabajar de madrugada siempre, que hay menos tráfico
- Nada

*¡Correcto! Mejores horarios.*

**M6 U03 P3.** ¿A dónde llamas si el estrés te rebasa?

- A nadie
- A la app, al soporte de viajes
- ✔ A la Línea de la Vida

*¡Correcto! 800 911 2000.*

## Módulo 7

**M7 U01 P1.** Te prestan 2,000 y pagas 2,300. ¿Cuánto cuesta?

- Nada
- 2,300
- ✔ 300

*¡Correcto! 2,300 menos 2,000.*

**M7 U01 P2.** ¿Qué usas antes de pedir un adelanto?

- ✔ Tu colchón
- Otro préstamo
- La tarjeta de un amigo

*¡Correcto! Colchón.*

**M7 U01 P3.** ¿Dónde verificas la financiera?

- En redes sociales
- ✔ En el SIPRES de CONDUSEF
- Con el soporte de otra app

*¡Correcto! SIPRES.*

**M7 U02 P1.** Te ofrecen dinero por prestar tu cuenta. ¿Qué haces?

- La prestas a un familiar
- La prestas solo los fines de semana
- ✔ No la prestas

*¡Correcto! No.*

**M7 U02 P2.** Trabajas con la cuenta de otra persona. ¿Tienes IMSS a tu nombre?

- Sí
- ✔ No
- Solo si te accidentas

*¡Correcto! No.*

**M7 U02 P3.** ¿Qué haces si compartiste tu contraseña?

- Nada
- ✔ La cambias y activas verificación en dos pasos
- La publicas para que nadie la use

*¡Correcto! Cámbiala.*

**M7 U03 P1.** «Soporte» te pide el código del SMS. ¿Qué haces?

- Das solo la mitad del código
- Lo das para no perder tu cuenta
- ✔ No lo das y entras a soporte desde la app

*¡Correcto! Nunca des códigos.*

**M7 U03 P2.** ¿Qué revisas cada semana?

- ✔ Que tu cuenta de pagos sea la tuya
- Las calificaciones de otros repartidores
- Nada

*¡Correcto! Cuenta de pagos.*

**M7 U03 P3.** Te robaron la cuenta. ¿Qué haces?

- Esperas
- ✔ Reportas desde la app y avisas a tu banco
- Abres otra cuenta con otro nombre

*¡Correcto! Reporta.*

## Módulo 8

**M8 U01 P1.** ¿Cuándo conviene empezar a ahorrar para el retiro?

- ✔ Lo antes posible
- A los 60, cuando ya estés cerca
- Nunca

*¡Correcto! Pronto.*

**M8 U01 P2.** Aportas 200 al mes durante 20 años. ¿Cuánto aportas?

- ✔ 48,000
- 4,800
- 200,000

*¡Correcto! 200 por 240 meses.*

**M8 U01 P3.** Tuviste un mes malo. ¿Qué haces con tu aportación?

- Pides prestado para aportar
- La cancelas para siempre y te olvidas
- ✔ La bajas pero no la dejas en cero

*¡Correcto! Menos, no cero.*

**M8 U02 P1.** Tu meta es 15,600 en 52 semanas. ¿Cuánto apartas por semana?

- ✔ 300
- 156
- 1,560

*¡Correcto! 15,600 entre 52.*

**M8 U02 P2.** ¿Dónde guardas el dinero de la meta?

- ✔ En un apartado propio
- Con el fondo de emergencia
- En la cartera

*¡Correcto! Propio.*

**M8 U02 P3.** ¿Qué hace una meta concreta?

- No sirve
- Es solo un deseo que tienes en la cabeza
- ✔ Dice qué, cuánto y para cuándo

*¡Correcto! Qué, cuánto, cuándo.*

**M8 U03 P1.** ¿Qué lleva cada parte?

- ✔ La siguiente acción y una fecha
- Solo lo que ya hiciste en el curso
- Nada

*¡Correcto! Acción y fecha.*

**M8 U03 P2.** ¿Cada cuándo revisas tu plan?

- ✔ Cada mes
- Cada cinco años
- Nunca

*¡Correcto! Cada mes.*

**M8 U03 P3.** ¿Cuál es una parte del plan?

- El clima
- Las calificaciones de otros repartidores
- ✔ Vehículo

*¡Correcto! Vehículo.*
