# Your Money, Your Family, Your Future: full content

Version 4.0 · Desarrolla Talento. Everything participants see: lessons, support book, H5P activities and question bank.

# Part 1. Characters

#### Alex and Mar

A couple living in Los Angeles with their two children, ages 7 and 4. Alex's mother lives in Michoacán and they send her money every month. Alex is paid biweekly and sometimes does jobs with his truck; Mar is paid weekly, gets most of her tips in cash and sometimes sells food to order.

#### Rubén

He's 24 and came from Oaxaca two years ago. He shares an apartment in Los Angeles, works in a warehouse, is paid weekly and sends money to his mother. He has no credit history and pays almost everything with apps.

#### Daniela

She's 37 and from San Salvador. She lives in San Diego with her 10-year-old son, works by the hour and has a small custom-cake business she wants to formalize. She sends money to her sister.

#### Rosa

She's 61 and from Guadalajara, where she worked 15 years with IMSS coverage. She lives in Fresno with her daughter and grandchildren, cares for other children in her building and is paid in cash. She worries about her health and retirement.

#### Andrés

He's 44 and from León, Guanajuato. He lives in Sacramento with his wife, Carmen, and their 15-year-old daughter. He has a job with benefits and a retirement plan, wants to buy a home and supports his brother in Mexico.

These characters are fictional; any resemblance to real people is coincidental.

# Part 2. Module 1. Understand your money and organize your finances

## M1 U01. Is all the money I receive money I earned?

**What you will be able to do:** Tell apart the money you earn, the money you borrow, the money you only move and the money you get back.

**To start:** Alex checks the bank account on a Friday and sees more money than ever. It looks like a good week. But part of that money isn't really Alex's: it's an advance that will come out of the next paychecks. In this lesson you'll learn to recognize which money is truly yours before you spend it.

### The essentials (5 minutes)

#### Not everything that comes in is income

When you see a deposit in your account or get cash, it's easy to think you earned that money.

That's not always true. Sometimes someone lent it to you. Sometimes you only moved it from one place to another. And sometimes you got back something you had already paid.

Knowing where each deposit comes from helps you avoid spending money you'll have to give back later.



#### The four kinds of money coming in

| Type | Description | What it means for you |
|---|---|---|
| Earned income | Wages, tips or the profit from your sales. | It's yours to spend. |
| Loan | An advance from your boss, a loan from a friend or an advance from an app. | You'll have to pay it back. |
| Moving money between your accounts | Moving money from savings to checking, or taking cash out of an ATM. | It isn't new money: it only changed places. |
| Refund | Money back for a purchase, or a charge the bank corrected. | It only recovers money you already spent. |

#### What is really yours

Imagine you have 100 dollars and someone lends you 50. Now you can use 150, but you still owe 50.
- What you have: **150**
- What you owe: **50**
- What is yours: **100**
What you have minus what you owe is called your **net worth**.
> **Key idea:** a loan gives you money to use today, but it doesn't make you richer.


#### Why it matters

If you count a loan as if it were wages, you may commit to expenses your job doesn't cover.

The problem doesn't show up that day. It shows up weeks later, when the advance comes out of your paycheck or the loan is due.

> **Case in one minute:** Alex gets a 400-dollar advance on wages. If that money goes to a refrigerator, the next paychecks will be 400 smaller and rent will come up short. The advance wasn't new money: it was Alex's own future pay.



#### Signs that a deposit isn't income

Take a closer look at a deposit if:

- it comes from a payroll advance app, or from your boss "against" your wages;
- someone tells you they lent it to you or "deposited it by mistake";
- it's a transfer from another account of yours;
- your statement says *refund*, *reversal* or *credit adjustment*.

> **Before you act, check:** if you don't recognize a deposit, mark it "to be cleared up." Don't spend it until you know what it is.



#### Do it this week

1. Open your account activity for the last month.
2. Mark each deposit with a letter: **E** (earned income), **L** (loan), **M** (money moved between your accounts) or **R** (refund).
3. Add up only the deposits marked **E**. That's your real income for the month.
4. For each **L**, write down how much you owe and when you'll pay it.



#### Check your understanding

1. An app deposits a 200 advance. Is it earned income?
*Answer:* No. It's a loan: it will come out of your next paycheck.

2. You move 100 from savings to checking. Do you have more money?
*Answer:* No. It only changed places. The total is the same.


#### Remember

- Before you spend a large deposit, ask yourself where it came from.
- If it's a loan, write down when and how you'll pay it back.
- If you don't know what it is, don't spend it yet.



### Go deeper (5 more minutes)

#### What money is for

Money has three jobs:

1. **Exchange:** buying and selling without trading one thing for another.
2. **Pricing things:** knowing whether something is expensive or cheap.
3. **Storing buying power:** saving today to use later.



#### Money, income and wealth are not the same

**Money** is what you can use to pay: cash or an account balance.

**Income** is what you receive in exchange for your work or your sales.

**Wealth**, or net worth, is everything you have minus everything you owe.

A person can own a house and have almost no cash: they have wealth, but little money available. Another person can have a lot of cash because someone lent it to them: they have money, but no more wealth.



#### The forms money takes

A bill is **cash**.

A balance at the bank is a **deposit**: the bank owes you that money.

A **debit** card pays with your deposit. A **credit** card pays with a loan.

An app can show you several balances on the same screen. Before you use it, find out who holds your money. You can check whether a bank is insured on [FDIC BankFind](https://banks.data.fdic.gov/bankfind-suite/) and whether a credit union is insured on [NCUA](https://mapping.ncua.gov).

> **Good to know:** in the U.S., money at an FDIC-insured bank is protected up to 250,000 dollars. The limit is per person, per bank and per type of account. At insured credit unions, the NCUA gives the same protection.



#### Payroll advances

Some apps and some employers give you today part of the pay you've already worked for. It comes out of your next paycheck.

Even if they say "no interest," they can have costs: a fee to get the money instantly, or a "tip" the app suggests.

If you use advances often, each paycheck arrives a little shorter. Use them only for an emergency and write down the date they'll be taken out.



#### Step by step

Follow how your cash and your net worth change with each move.

| Step | What happens | Cash | Things you own | Debts | Net worth |
|---|---|---|---|---|---|
| 1 | You start with no debts | 500 | 0 | 0 | 500 |
| 2 | You get your 300 paycheck | 800 | 0 | 0 | 800 |
| 3 | You buy a 200 tool | 600 | 200 | 0 | 800 |
| 4 | You spend 50 on food | 550 | 200 | 0 | 750 |
| 5 | Someone lends you 100 | 650 | 200 | 100 | 750 |
| 6 | The tool is now worth 120 | 650 | 120 | 100 | 670 |

In step 5 you have more cash, but your net worth didn't change.

In step 6 your net worth went down 80, even though you didn't spend anything that day.



#### If you work for yourself

Not everything you charge is profit. Part of it pays you back for materials, merchandise or transportation.

> **Key idea:** profit = what you charge − what you spent to be able to sell.

If you don't do this subtraction, you may spend as profit the money you need to buy next week's merchandise.



#### Cases


**Case 1. The advance from the boss**

Alex gets a 400-dollar advance on wages. That week the account shows more money than ever. Mar wants to use it to buy a refrigerator.
- *What should they consider?* The advance will come out of the next paychecks. It isn't new income.
- *What happens if they spend it today?* In the next few weeks they'll have 400 less for rent and food.


**Case 2. Daniela's cakes**

Daniela sold 600 dollars' worth of cakes in a month. She spent 250 on ingredients and boxes.
- *How much did she earn?* 350 before taxes, not 600.
- *What happens if she spends the 600?* Next month she won't have money to buy ingredients.


**Case 3. The mystery deposit**

A 300 deposit shows up in Rubén's account. He doesn't know where it came from. A few days later, someone texts him: "I deposited it by mistake, send it back to me by Zelle."
- *What should Rubén do?* Not spend it and not send it back on his own. First he should call his bank at its official number.
- *Why?* It may be a scam. In many of these scams the original deposit is reversed later, and the money you "send back" comes out of your own balance. You can report it at [ReportFraud.ftc.gov](https://reportfraud.ftc.gov).


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Counting an advance or a loan as wages | You commit to expenses your job doesn't cover | Write down the loan and its due date |
| Counting everything you sell as profit | You run out of money to restock | Subtract your costs first |
| Thinking that moving money between accounts means having more | Your budget looks bigger than it is | Count the money in all your accounts only once |
| Spending a deposit you don't recognize | It may be a mistake or a scam, and they can take it back later | Mark it "to be cleared up" and call the bank |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Someone lends you 300 dollars. How does your net worth change? a) It goes up 300 · b) It doesn't change · c) It goes down 300
2. You move 100 dollars from your savings account to your checking account. Is it income? a) No · b) Yes · c) Yes, if it moves between two accounts at the same bank
3. You pay 20 in interest on your credit card. What happens to your net worth? a) It goes up · b) It doesn't change · c) It goes down
**Answers:** 1-b: you have 300 more, but you owe 300. 2-a: it only changed places. 3-c: you paid a cost and didn't reduce the debt.



#### Put it into practice

This month you received: 600 in wages, a 200 loan, a 100 transfer between your accounts and a 40 refund for a purchase. How much is new earned income?
**Answer:** 600. The loan has to be paid back, the transfer only moved your money and the refund reverses a purchase.



#### Your plan

Make a list with four columns: cash, deposits, things you own and debts. You don't need to share real amounts with the course.



### Learn more

- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** open the module on budgeting and managing money. Use it to practice separating income, expenses and debts.
- **Fake check scams** (FTC · English): https://consumer.ftc.gov/articles/fake-check-scams — **What to look for:** the signs of a deposit "by mistake" and what to do before you send any money back (Case 3).
- **Check that a bank is insured** (FDIC BankFind · English): https://banks.data.fdic.gov/bankfind-suite/ — **What to look for:** type the name of your bank, or your app's partner bank, and confirm it shows as insured.

### Key words

- *Asset:* something of value that you own.
- *Liability:* a debt or something you have to pay.
- *Net worth:* what you have minus what you owe.
- *Liquidity:* how quickly you can use something as money without losing value.

### Sources

[S06] Federal Reserve, money supply · FTC, fake check scams · FDIC, deposit insurance.

---

## M1 U02. Why doesn't the same money go as far anymore?

**What you will be able to do:** Calculate percentages, inflation, and simple and compound interest, and use them to understand your decisions.

**To start:** Mar buys the same groceries she bought a year ago and pays more. Her pay hasn't changed. She didn't overspend: money is worth less than before. In this lesson you'll learn to measure how much prices go up and how much borrowed money costs.

### The essentials (5 minutes)

#### When prices go up

Mar's groceries used to cost 100 dollars. Now they cost 105.
- Today's price: **105**
- Earlier price: **100**
- Up 5 out of every 100: 5%: **5**
When prices go up in general, it's called **inflation**.


#### Your buying power

If prices go up 5% and your income doesn't, you can buy less with the same money.

That's called losing **buying power**.

It isn't your fault. It's a reason to review your budget from time to time, not only when something goes wrong.

> **Key idea:** compare your own prices. The inflation in the news is an average; your rent or your food can go up more.



#### How to calculate a percentage

"Percent" means "out of every hundred."

To find 5% of 800, turn 5% into 0.05 and multiply: 800 × 0.05 = 40.

To find how much something changed: (new price − earlier price) ÷ earlier price. From 80 to 100 is (100 − 80) ÷ 80 = 25%.



#### Two kinds of interest

| Type | Description | What it means for you |
|---|---|---|
| Simple interest | 1,000 at 6% for 2 years: 60 each year, 120 in total. | It grows the same every year. |
| Compound interest | 1,000 at 6%: 1,060 the first year and 1,123.60 the second. | It grows faster and faster. |

#### Interest is the price of money

If someone lends you 100 and you pay back 110 in a year, you paid 10 in interest. The rate was 10% a year.

In savings, compound interest works for you. In a debt, it works against you: if you don't pay, the debt grows on top of itself.



#### Do it this week

1. Write down three prices you pay often: rent, food and transportation.
2. Find out what they cost a year ago and calculate how much they went up.
3. In any credit offer, look for whether the rate is yearly or monthly.



#### A case in one minute

Rubén earns the same as last year: 650 a week. His rent went up from 700 to 756 a month, and transportation from 120 to 132.

His rent went up 8% and transportation 10%. Even though his pay didn't go down, he has 68 dollars less each month.

Rubén isn't overspending. His prices went up and his income didn't. Knowing this helps him ask for a raise with numbers or look for where to adjust.

> **Before you act, check:** in any credit offer, look for whether the rate is yearly or monthly, simple or compound, and which fees it includes.



#### Check your understanding

1. What is 7% of 600?
*Answer:* 42, because 600 × 0.07 = 42.

2. Inflation went down from 6% to 4%. Did prices go down?
*Answer:* No. They're still going up, just more slowly.


#### Remember

- Inflation means prices go up; your buying power drops if your income doesn't go up as much.
- Compound interest helps savings and makes debt more expensive.
- Always check whether a rate is yearly or monthly.



### Go deeper (5 more minutes)

#### Percentages and percentage points

A rise and a drop of the same size don't give the same percentage, because the base changes.

- From 80 to 100: up 25%.
- From 100 to 80: down 20%.

If a rate goes from 3% to 5%, it went up **2 percentage points**. In relative terms it went up 66.7%, because 2 ÷ 3 = 0.667.



#### Simple and compound interest with numbers

**Simple:** interest = principal × rate × time. The principal is what you borrowed or saved at the start.

- 1,000 at 6% a year for 6 months: 1,000 × 0.06 × 0.5 = 30.
- 1,000 at 6% a year for 2 years: 120.

**Compound:** final balance = principal × (1 + rate per period) raised to the number of periods.

- Year 1: 1,000 × 1.06 = 1,060.
- Year 2: 1,060 × 1.06 = 1,123.60.

The difference from simple interest is 3.60 in two years. Over 20 or 30 years the difference is huge.



#### The rate and the period must match

12% a year is not 12% every month. If a rate is 12% a year calculated monthly, 1% is applied each month.

Over a year, the factor is 1.01 raised to 12 = 1.1268. That is, 12.68% a year.

On real products you'll see two abbreviations:

- **APR:** the yearly cost of credit. Check which fees it includes.
- **APY:** what savings earn in a year, with compound interest.

> **Good to know:** loans that charge "only 1% a week" look cheap. But 1% a week compounded for a year is almost 68%. Always ask for the yearly rate.



#### Inflation is measured with indexes

A price index sums up the price of a basket of products. If it goes from 200 to 210, inflation is (210 − 200) ÷ 200 = 5%.

Two months in a row of 1% add up to 2.01%, not 2%, because they build on each other: 1.01 × 1.01 − 1.

When inflation goes down, prices don't go down. They go up more slowly. When prices go down, that's called deflation.

In the U.S. the official index is published by the [Bureau of Labor Statistics (BLS)](https://www.bls.gov/cpi/).



#### Real return

If your savings grow 8% and inflation is 5%, your buying power grows 1.08 ÷ 1.05 − 1 = 2.86%.

If your savings grow 3% and inflation is 5%, you have more dollars but can buy less: 1.03 ÷ 1.05 − 1 = −1.9%.



#### Exchange rate

The exchange rate is the price of one currency in another.

Always say which way it goes: 17 pesos per dollar isn't the same as 0.059 dollars per peso.

Keep facts apart from forecasts. A news story about a possible crisis doesn't tell you when your hours will be cut. It's more useful to prepare a plan with less income (you'll see it in M1 U08).



#### How to use these numbers to ask for a raise

If your pay hasn't gone up and prices have, you have an argument with numbers.

Calculate how much inflation went up since your last raise and how much your main expenses went up. For example: "Since my last raise, two years ago, prices have gone up about 7%."

Ask for a conversation, bring your numbers and talk about your work. Mention how long you've been there, what new responsibilities you have and what results you deliver.

If there's no raise, ask about other options: more hours, a different schedule or training.



#### Cases


**Case 1. Alex and Mar's rent**

General inflation for the year was 3%, but their rent went up 8%.
- *Which inflation matters more to them?* The inflation of their own expenses. Rent weighs more than the national average.
- *What can they do?* Check how much of their income goes to rent and build their budget with the real increase.


**Case 2. The savings that "grew"**

Mar kept 1,000 dollars in an account that paid 3% in a year. The basket of things she buys went up 5%.
- *Did she gain or lose?* She has 1,030 dollars, but with them she can buy what used to cost 1,030 ÷ 1.05 = 980.95. Her buying power went down.


**Case 3. The "1% a week" loan**

Rubén is offered a "cheap" loan at 1% a week.
- *How much is that a year?* Almost 68%, because 1.01 raised to 52 is 1.678. It isn't cheap.
- *What should he ask?* The yearly rate (APR) and all the fees, in writing.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking that if inflation goes down, prices go down | You wait for relief that doesn't come | Compare your prices month to month |
| Comparing a monthly rate with a yearly one | You choose the more expensive loan | Turn everything into a yearly rate |
| Adding or subtracting percentages with different bases | You miscalculate the real change | Always use the earlier price as the base |
| Believing that more dollars means more wealth | Your savings lose to inflation | Calculate the real return |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is 7% of 600? a) 4.2 · b) 42 · c) 420
2. A rate goes up from 2% to 3%. How many percentage points did it go up? a) 1 · b) 50 · c) 3
3. Inflation went down from 6% to 4%. Did prices go down? a) Yes · b) Yes, they went down 2% from last year · c) No, they're going up more slowly
**Answers:** 1-b: 600 × 0.07. 2-a: the relative increase is 50%, but it's 1 percentage point. 3-c: they're going up more slowly.



#### Put it into practice

You save 1,000 and a year later you have 1,030. The prices of the things you buy went up 5%. Did your balance go up? Did your buying power go up?
**Answer:** Your balance went up 3%, but your buying power went down: 1,030 ÷ 1.05 = 980.95 in last year's dollars. The example doesn't include taxes or fees.



#### Your plan

Write down three prices that went up in your home this year and one action that is up to you.



### Learn more

- **Consumer Price Index** (BLS · English): https://www.bls.gov/cpi/ — **What to look for:** the latest yearly inflation number and the table by category (food, housing, transportation) to compare with your own expenses.
- **Compound interest calculator** (SEC Investor.gov · English): https://www.investor.gov/financial-tools-calculators/calculators/compound-interest-calculator — **What to look for:** enter a starting amount, a monthly deposit and a rate to see how it grows over time.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the module on borrowing, to practice reading a rate and the total cost.

### Key words

- *Inflation:* a general rise in prices.
- *Buying power:* what your money can buy.
- *Compound interest:* interest that is also calculated on earlier interest.
- *Percentage point:* the direct difference between two percentages.
- *Exchange rate:* the price of one currency in another.

### Sources

[R24] CFPB, compound interest · [R25] CFPB, how APY is calculated · [R26] BLS, Consumer Price Index.

---

## M1 U03. What do I need to take care of first?

**What you will be able to do:** Put your priorities in order based on your values and your situation, without blaming yourself.

**To start:** Rubén has 60 dollars left until his next paycheck. His mom needs medicine, his work shoes fell apart and a friend invited him to a concert. Everything seems important. In this lesson you'll learn a simple way to decide what comes first.

### The essentials (5 minutes)

#### Choosing is deciding what comes first

There's almost never enough for everything at once. That's why deciding with money means choosing what comes first and what can wait.

Choosing one thing doesn't mean the other doesn't matter. It means you'll do it later or in another way.



#### Everything you choose has a cost

When you use your money on something, you stop using it on something else. What you give up is called the **opportunity cost**.

One sentence makes it visible: "If I do this, then I put that off."

> **Key idea:** there are no "good" or "bad" expenses for everyone. There are decisions that protect what matters to you.



#### Three levels of priority

| Type | Description | What it means for you |
|---|---|---|
| Urgent | It's due soon and has a serious consequence if you don't do it: rent, medicine, getting to work. | It comes first. |
| Important | It gets you closer to a goal, but it can wait a few days: saving, helping family. | Plan it with a date. |
| Can wait | You like it or it's convenient, but nothing happens if you put it off: an outing, a new phone. | Decide it calmly. |

#### Four questions to start

1. **What do I need to protect?** Housing, food, health, work.
2. **What commitments do I already have?** Payments, debts, helping family.
3. **What do I want to achieve?** A specific goal.
4. **What worries me?** What keeps you up at night.



#### The pause rule

When something seems urgent, ask for three facts: the real due date, what happens if you wait and what other options there are.

Being tired or short on money makes it harder to compare. That's why it helps to set a rule before the offer arrives.

For example: "I wait 48 hours before any purchase over 100 dollars."



#### A case in one minute

Daniela gets a message: "Exclusive offer, a TV for 20 a week, today only." Her TV works, but the new one is bigger.

She applies her rule: she waits 48 hours and does the math. Twenty a week is 1,040 a year, and the cash price was 480.

After 48 hours, the offer is still there. Daniela decides not to buy it and to set aside 20 a week for her son's school uniform, due in two months.

> **Before you act, check:** if an offer says "today only," ask whether it will be there tomorrow. The answer is almost always yes.



#### Check your understanding

1. What is opportunity cost?
*Answer:* What you give up when you choose something else with your money.

2. An offer says "today only." What do you do?
*Answer:* I ask for the real date, ask what happens if I wait and compare other options before deciding.


#### Remember

- First, what protects your housing, food, health and work.
- "If I do this, I put that off" makes visible what you give up.
- A pause rule protects you from decisions made under pressure.



### Go deeper (5 more minutes)

#### Numbers and values

A money decision combines numbers and values.

Helping your mom, taking a break or calling your family can be important even if it doesn't make money.

The goal isn't to follow a universal list of correct expenses. It's to choose with information and know what you're giving up.



#### The three-option method

For an important decision, write down two real options and the option of waiting. For each one, note: cost in money, time, safety and effect on your family.

For example, doing a paperwork task in person costs 25 in transportation and 60 in lost pay: 85 in total. Doing it online costs 10, but you don't have a secure connection.

Before choosing, ask whether there are appointments at another time or a trusted place with internet, like a public library.



#### Pressures you can recognize

- **The clock:** "today only" creates urgency so you don't compare.
- **What you already spent:** it pushes you to stick with a bad purchase so you "don't lose" what you put in.
- **Comparison:** seeing what others buy changes what you consider normal.

The answer is a pause that matches the size of the commitment. A two-year contract deserves more review than a grocery purchase.



#### When the problem isn't the budget

If someone controls your documents or your income, or forces you into debt, a better budget won't solve the problem.

In that case your safety comes first. You'll see it in M4 U05.



#### Deciding as a family

When several people share expenses, each one may have different priorities. That's normal.

It helps to have a short talk at the start of each month: what payments are coming, what each person wants and what can wait.

Some rules that work in many homes:

- each adult has a small amount for personal use, without having to explain what it's for;
- big purchases are decided together;
- nobody signs debts in someone else's name without their permission.

If one person decides everything and the other can't give an opinion, see lesson M4 U05.



#### Cases


**Case 1. The two subscriptions**

Mar pays 15 a month for a music app she uses every day and 9 for a video app she forgot she had.
- *Should she cancel the more expensive one?* Not necessarily. What matters is the value she gets. She doesn't use the video app: that's the one worth canceling.


**Case 2. The birthday present**

Alex has 60 dollars left over. Alex can buy their son's birthday present or save the money.
- *What is the right answer?* It depends on Alex's priorities. A good decision keeps the bills covered, explains the choice and doesn't call the present "bad" or the savings "mandatory."


**Case 3. Rubén's 60 dollars**

Rubén has 60 dollars until his next paycheck. His mom needs a 40-dollar medicine, his work shoes are torn and he was invited to a concert.
- *What is urgent?* The medicine and the shoes, because they protect health and work.
- *What does he do about the concert?* He puts it off or looks for a no-cost option. He can set aside a little from each paycheck to go to the next one.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying first whatever pushes hardest | What protects your home or your job goes unpaid | Ask for the real date and the consequence of waiting |
| Calling every personal expense "bad" | Plans that are impossible to keep | Leave room for what gives you well-being |
| Sticking with a bad purchase because of what you already paid | You lose more money | Decide based on what's ahead, not on what you already spent |
| Deciding on a long contract the same day | You commit without comparing | Apply your pause rule |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is opportunity cost? a) The price of what you buy · b) What you give up when you choose · c) A bank fee
2. What should you do when everything seems urgent? a) Ask for the real date, the consequence of waiting and the alternatives · b) Pay whatever pushes hardest · c) Wait for everything to sort itself out
3. A long contract deserves: a) The same review as a daily purchase · b) Less review, because it's already written · c) More review
**Answers:** 1-b: it's what you give up. 2-a: with those facts you can compare. 3-c: it commits you for longer.



#### Put it into practice

You have 60 available for a goal or a present. Write two options and their consequence over the next month.
**Answer:** You can spend 60, save 60 or split it. A good answer explains your priority and keeps your obligations covered.



#### Your plan

Write your three priorities and a pause rule. You don't need to share personal experiences.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the goal-setting tool and the "spending priorities" tool; you can download and print them.
- **Financial well-being questionnaire** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/financial-well-being/ — **What to look for:** answer the 10 questions to see your starting point; take it again when you finish the course.

### Key words

- *Priorities:* needs or goals you take care of first.
- *Opportunity cost:* what you give up when you choose.
- *Budget:* a plan for assigning your money.

### Sources

[S04] CFPB, Your Money, Your Goals · CFPB, financial well-being scale.

---

## M1 U04. Is getting paid every week the same as getting paid every month?

**What you will be able to do:** Calculate your real income based on how often you get paid, how much it changes and how much it costs you to work.

**To start:** Alex gets paid every two weeks and Mar every week, plus cash tips. Some months more money comes in and some months less, even though they work the same. In this lesson you'll learn to calculate how much really comes in, and when.

### The essentials (5 minutes)

#### A month doesn't always bring the same

You get 100 dollars every Friday. Some months have four Fridays and others have five.
- Month with 4 Fridays: **400**
- One more Friday: **100**
- Month with 5 Fridays: **500**
That's why a monthly average is useful for planning the year, but **the real dates** are what pay the rent.


#### How often you get paid

| Type | Description | What it means for you |
|---|---|---|
| Every week | 52 paychecks a year. Some months bring five. | Multiply by 52 for the year. |
| Every two weeks | 26 paychecks a year. Two months of the year bring three. | Multiply by 26 for the year. |
| Twice a month | 24 paychecks a year, for example on the 15th and the 30th. | Multiply by 24 for the year. |
| Every month | 12 paychecks a year. | Multiply by 12 for the year. |

#### Watch out for "biweekly"

"Biweekly" usually means every two weeks, but some people use it for twice a month.

The difference is two paychecks a year. Ask which one applies to you so you don't miscalculate.



#### Income that changes

If your income changes every month, don't plan with your best month. Look at several months and build three scenarios: low, usual and high.

Fixed expenses, like rent, must fit in the low month.

> **Key idea:** don't take on a new fixed commitment just because you had a very good month.



#### Your cash log

If you get paid in cash or receive tips, don't wait until the end of the month to find out how much you earned.

At the end of each day, write down in a notebook or in your phone's notes how much you received. If you spent money on materials or transportation to work, write it down separately that same day.

What you received minus what you spent to work is your real profit.



#### Do it this week

1. Mark on a calendar each payday for the next 8 weeks.
2. Write how much you expect to receive on each date.
3. Mark as "uncertain" whatever isn't confirmed, like tips or extra jobs.



#### A case in one minute

Rubén gets paid every Friday. In July there were five Fridays and he received 3,250 instead of 2,600.

His roommate suggested renting a more expensive apartment, because "now you make more." Rubén checked his calendar: only four months of the year have five Fridays.

He decided to use the extra paycheck to build up his savings cushion and keep the rent he can pay with four paychecks.



#### Check your understanding

1. How many paychecks a year are there if you get paid every two weeks?
*Answer:* 26. That's why two months of the year bring three paychecks.

2. Your best month was 2,500. Do you plan a new fixed payment with that?
*Answer:* No. Fixed commitments must fit in your lowest month.


#### Remember

- The real dates pay the rent, not the average.
- Ask whether "biweekly" means every two weeks or twice a month.
- Write down cash and tips every day.



### Go deeper (5 more minutes)

#### From paycheck to year and month

Example: 1,200 every two weeks.

| Calculation | Result |
|---|---|
| 1,200 × 26 paychecks | 31,200 a year |
| 31,200 ÷ 12 months | 2,600 a month on average |
| Normal month (2 paychecks) | 2,400 |
| Month with 3 paychecks | 3,600 |

The 2,600 average almost never arrives. Most months you receive 2,400.



#### Paid by the day

If you're paid by the day, count only the days you actually worked.

100 a day for 20 days worked is 2,000, not 3,000. Rainy days, sick days or days without work don't pay.



#### Three scenarios for income that changes

In four months you received 1,800, 2,100, 1,600 and 2,500. The average is 2,000.

A fixed commitment of 2,000 would fail in the 1,600 month. Decide what you cover with the lowest month and what you set aside in the high months.

Sort each income:

- **Confirmed:** amount and date are known.
- **Likely:** depends on shifts, sales, tips or a client paying.
- **One-time:** it doesn't repeat, like a bonus or a big sale.



#### If you work for yourself

First subtract what it costs you to work: materials, gas, tools and app fees. Then set money aside for taxes (you'll see it in M1 U10).

What's left is what you can use for your home.

**Don't count twice:** if an app deposits money and then you move it to your bank, it's a single income.

**Cash:** keeping it outside the bank doesn't change what it is. Keep business, household and tax money separate.

> **Good to know:** keep the receipts for your work purchases and your daily log. They protect you when you file taxes: they're the proof of your income and your expenses.



#### Shared income at home

If several people in your home contribute, each one may get paid on different dates.

Make a shared calendar with everyone's paydays. That way you can see which week has more money and which one is tighter.

Agree on who pays what and when. For example: Alex's paycheck covers rent and Mar's covers food and utilities.



#### Cases


**Case 1. Alex and the three-paycheck months**

Alex gets 900 every two weeks. One month three paychecks arrive: 2,700.
- *What happens if Alex uses that month to sign a car loan?* In the two-paycheck months (1,800) it won't be enough.
- *What is the smart thing to do with the third paycheck?* Build up the savings cushion or pay ahead on a debt, not create a new fixed expense.


**Case 2. Mar's tips**

In December Mar received 2,400 between pay and tips. In January, only 1,500, because tips went down.
- *What does she need?* A plan for the low month before it arrives: set something aside in the high months.
- *How does she know how much she gets in tips?* With her daily cash log.


**Case 3. Daniela's orders**

Daniela charges 150 per cake order. One month she had 18 orders and spent 270 on ingredients and boxes.
- *How much is left before taxes?* 150 × 18 = 2,700; minus 270 = 2,430.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Planning with the monthly average | You come up short in two-paycheck months | Plan with the real dates |
| Signing a fixed payment based on your best month | It isn't enough in the low months | Use your lowest month as the reference |
| Counting the same money twice | Your income looks bigger | Count the app deposit and the transfer only once |
| Not writing down tips and cash | You don't know how much you earn and can't prove it | Keep a daily log |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. How many paychecks a year are there "every two weeks"? a) 24 · b) 26 · c) 52
2. You earn 100 a day and worked 18 days. How much did you receive? a) 1,800 · b) 3,000 · c) 2,400
3. Is it wise to take on a fixed commitment based on your best month? a) Yes · b) Yes, if it's a three-paycheck month · c) No
**Answers:** 1-b: 26 paychecks. 2-a: only the days worked count. 3-c: it must fit in your lowest month.



#### Put it into practice

You earn 150 a day, work 18 days and spend 270 on work costs. What's left before taxes and household expenses?
**Answer:** 150 × 18 = 2,700; minus 270 = 2,430. Taxes and household expenses still have to come out.



#### Your plan

Make an 8-week calendar with your paydays. Use one color for what's confirmed and another for what's estimated.



### Learn more

- **Gig Economy Tax Center** (IRS · English and Spanish): https://www.irs.gov/businesses/gig-economy-tax-center — **What to look for:** the recordkeeping section, to know what to keep if you get paid through apps, in cash or with tips.
- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "income tracker" tool to write down when and how much you get paid.

### Key words

- *Pay frequency:* how often you receive money.
- *Every two weeks:* 26 paychecks a year.
- *Twice a month:* 24 paychecks a year.
- *Scenarios:* possible versions of your future to test your plan.
- *Cash log:* a daily record of what you receive and spend in cash.

### Sources

IRS, gig economy · CFPB, Your Money, Your Goals.

---

## M1 U05. Why is my deposit smaller than what I earned?

**What you will be able to do:** Read your pay stub and know when and where to ask for a correction.

**To start:** Rubén worked all week and expected 700 dollars. He got 565. He doesn't know if it's a mistake or if that's how it should be. In this lesson you'll learn to read your pay stub line by line.

### The essentials (5 minutes)

#### Gross and net

Your pay stub says 500 dollars before deductions. 50 is taken out. 450 reaches your account.
- Gross income: **500**
- Deductions: **50**
- Net income: **450**
To know how much you can use, count the **net**. Don't add gross and net together.


#### How to read your pay stub from top to bottom

1. **Pay period** worked and pay date.
2. **Hours:** regular hours, overtime and hourly rate.
3. **Other pay:** bonuses, tips.
4. **Gross income:** the total before deductions.
5. **Deductions:** taxes, health insurance, retirement plan and others.
6. **Net income:** what is deposited.
7. **Year to date:** totals since January. It isn't this week's pay.



#### Not every deduction is a tax

Some deductions are tax withholding. Others are for your health insurance or your retirement plan.

If you see a deduction you don't understand, you have the right to ask what it is.

> **Key idea:** in California your employer must give you a pay stub with the details of your pay. Keep all of them.



#### Keep your own record of hours

Each day, write down what time you start, what time you leave and your breaks.

That way, when your pay stub arrives, you can compare. A difference isn't always a mistake, but your record helps you ask with facts.



#### If something doesn't add up

Prepare a specific question: the pay period, the hours you recorded, the amount you expected, the amount you received and what document you have.

Ask your employer or payroll first, preferably in writing.



#### A case in one minute

Mar gets her first pay stub at a new job. She sees one deduction that says "SDI" and another that says "FICA."

She asks a coworker and then checks the state's website. SDI is California's disability insurance: if she gets sick or has a baby, she can receive part of her pay. FICA is the contribution to Social Security and Medicare.

They aren't mistakes. They're contributions that protect her. Now Mar knows how to read her pay stub and keep it.



#### The most common deductions

| Type | Description | What it means for you |
|---|---|---|
| Federal and state tax | An advance on your income taxes. | It gets adjusted when you file. |
| FICA | Social Security and Medicare. | It counts toward your retirement in the U.S. |
| SDI | California disability insurance. | It pays you if you can't work because of illness or pregnancy. |

#### Three questions for every pay stub

Each time you get paid, ask yourself three questions:

1. Do the hours match my record?
2. Is the hourly rate the one we agreed on?
3. Is there a new deduction I don't understand?

If all three answers are fine, keep the pay stub. If something doesn't add up, ask that same week, while you still remember the details.



#### Check your understanding

1. Which money can you use: gross or net?
*Answer:* Net, because that's what's deposited.

2. Are all deductions taxes?
*Answer:* No. Some are for health insurance, retirement or other things.


#### Remember

- Plan with your net income.
- Keep your pay stubs and your record of hours.
- Ask in writing about any deduction you don't understand.



### Go deeper (5 more minutes)

#### Check your pay stub with numbers

| Item | Amount |
|---|---|
| 30 hours × 22 dollars | 660 |
| Bonus | 40 |
| **Gross** | **700** |
| Taxes | −90 |
| Health insurance | −25 |
| Retirement plan | −20 |
| **Expected net** | **565** |

If 550 was deposited, there are 15 to clear up. It isn't an accusation: it may be an adjustment or a mistake.



#### Benefits

Your employer's contribution to a retirement plan may show up on your pay stub without increasing your deposit. It's money for your future.

When you compare jobs, ask how much health insurance costs you, when it starts and what it covers.



#### Contractor or employee

An app or an employer calling you a "contractor" doesn't decide your job classification on its own.

California uses legal tests to decide whether you're an employee. If you have questions about overtime, breaks, minimum wage or classification, keep your pay stubs, schedules and messages.

You can contact the [California Labor Commissioner (DIR)](https://www.dir.ca.gov/dlse/). Basic labor rights, like minimum wage, apply no matter your immigration status.

> **Good to know:** your city's minimum wage may be higher than the state's. Check both every January.



#### Protect your data

Your pay stub has your name and your identification number. Don't share it in photos or in group chats.

Never write your full SSN or ITIN in a public question or on social media.



#### What SDI protects

SDI (State Disability Insurance) is state insurance that is taken out of your pay.

It can pay you part of your wages if you can't work because of an illness, an injury outside of work or a pregnancy. It also funds Paid Family Leave, to care for a sick family member or a newborn baby.

You apply through California's EDD. Ask the EDD what the requirements are for your case.

If you get hurt at work, what applies is workers' compensation insurance, which your employer pays for.



#### Overtime pay in California

In California, in general, you get time and a half for hours after 8 in a day or 40 in a week. In some cases you get double time.

There are exceptions depending on the type of job. If your overtime doesn't show up on your pay stub, ask and keep your record.



#### Your rights if you file a claim

In California, your employer can't fire you or punish you for asking about your pay or for filing a wage claim.

If you're owed money, you can file a claim with the Labor Commissioner. It's at no cost, there is service in Spanish and they don't ask about your immigration status.

Keep a copy of everything you turn in and write down who you spoke with and on what date.



#### Cases


**Case 1. The missing hours**

Alex worked 40 hours, but the pay stub says 36.
- *What should Alex check first?* The dates of the pay period. Maybe 4 hours carry over to the next pay stub.
- *And if that's not it?* Compare with the personal record and ask in writing, with dates and hours.


**Case 2. The unknown deduction**

Rubén sees a 12-dollar deduction called "uniform."
- *What does he do?* He asks in writing for an explanation of the charge and whether he has to pay it.


**Case 3. Rubén's 565**

Rubén expected 700 and received 565.
- *Is there a mistake?* Not necessarily. 700 was his gross pay. If deductions add up to 135, the correct net is 565.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Planning with gross pay | You come up short every paycheck | Always use net pay |
| Throwing away your pay stubs | You can't prove mistakes or income | Keep them in a folder |
| Complaining without facts | The correction gets stuck | Bring your record of hours and your pay stub |
| Accepting that "contractor" defines your rights | You can lose rights you do have | Contact the Labor Commissioner |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which money can you use? a) Gross · b) Net · c) The amount in your contract
2. Are all deductions taxes? a) No · b) Yes · c) Yes, except health insurance
3. If you're called a "contractor," does that decide your legal classification? a) Yes · b) Yes, if it's in writing · c) Not necessarily
**Answers:** 1-b: it's what's deposited. 2-a: there are also insurance, retirement and others. 3-c: the law uses its own tests.



#### Put it into practice

The pay stub shows 36 hours at 20 dollars and a net of 600. Your record says 40 hours. What do you ask first?
**Answer:** Confirm the dates of the pay period, compare the 4-hour difference with your record and ask for the breakdown of deductions. Without those facts you can't know what the correct net is.



#### Your plan

Create a folder for pay stubs and a record of hours. Write down one question about a benefit you don't understand.



### Learn more

- **California Labor Commissioner** (DIR · English and Spanish): https://www.dir.ca.gov/dlse/ — **What to look for:** the minimum wage section and the one on how to file a wage claim, with forms in several languages.
- **California minimum wage** (DIR · English): https://www.dir.ca.gov/dlse/faq_minimumwage.htm — **What to look for:** the current state minimum wage and the link to the list of cities with their own minimum wage.

### Key words

- *Gross income:* what you earn before deductions.
- *Net income:* what is deposited after deductions.
- *Withholding:* money taken out as an advance on taxes.
- *Employer contribution:* money your employer puts into your retirement plan.

### Sources

[S11] DIR, know your rights · California Labor Code, section 226 (pay stubs).

---

## M1 U06. Can a small purchase add up to a lot?

**What you will be able to do:** Measure the real weight of your big and small expenses, and choose adjustments you can actually keep up.

**To start:** Rubén checked his statement and found a 12.99 charge from an app he tried "at no cost" eight months ago. He never used it. In this lesson you'll learn to find the expenses that repeat and decide which ones are worth it.

### The essentials (5 minutes)

#### Small things that repeat

You buy something for 3 dollars ten times a month.
- Once: **3**
- Nine more times: **27**
- A month: 360 a year: **30**
A small expense that repeats is often called a **latte factor**. That doesn't make it bad: first ask yourself what it does for you.


#### Track before you judge

Before you decide to cut an expense, write down four things. How much it costs. How often it happens. What it does for you. And whether you can change it.

The size of an expense doesn't tell you whether it's necessary. A coffee with a friend may be your only break of the week.



#### Look at the big expenses first

Rent, transportation, child care and health usually make up most of the budget.

Giving up coffee won't make up for rent that goes up 200 dollars. That's why it's better to check the big expenses first.

> **Key idea:** adjust where the change is real and lasting, not where it makes you feel guilty.



#### Three kinds of expenses to review

| Type | Description | What it means for you |
|---|---|---|
| Subscriptions | Apps, streaming, gym. They charge you automatically every month. | Check them on your statement and in the app store. |
| Non-monthly expenses | Insurance every six months, car registration, school supplies. | Divide and set aside each month. |
| Small repeated purchases | Sodas, snacks, delivery orders. | Decide which ones are worth it. |

#### Canceling your card doesn't cancel the subscription

If you want to stop paying for a service, cancel it directly with the company and keep the confirmation.

Canceling your card doesn't always stop the charge, and it can leave you owing the company.



#### A case in one minute

Mar goes over her statement with a highlighter and finds three things. Two video apps. A 3.50 fee for using another bank's ATM, four times. And food delivery orders that add up to 140 a month.

She cancels one app, uses her own bank's ATMs and decides to order food only on Fridays. She frees up about 90 a month without giving up anything that matters to her.

> **Before you act, check:** before you cancel a service, check whether there's a penalty or a minimum term. Keep the confirmation number.



#### Three questions before you cut

Before you drop an expense, ask yourself:

1. Does it give me something I truly value, like rest, health or time with my family?
2. Is there a cheaper way to get the same thing?
3. Can I keep this change up for three months?

If the answer to the first is yes and to the other two is no, maybe that's not the expense to cut.



#### Check your understanding

1. A 4-dollar expense, 20 times a month: how much does it add up to in a year?
*Answer:* 960, because 4 × 20 = 80 a month and 80 × 12 = 960.

2. Insurance of 600 every six months: how much should you set aside each month?
*Answer:* 100, because 600 ÷ 6 = 100.


#### Remember

- Track an expense before you judge it.
- Check the big expenses first.
- Cancel subscriptions with the company and keep the confirmation.



### Go deeper (5 more minutes)

#### From money not spent to real savings

A 4-dollar purchase, 22 times a month.

| Step | Calculation | Result |
|---|---|---|
| Today | 4 × 22 | 88 a month |
| If you cut it to 10 times | 4 × 10 | 40 a month: you save 48 |
| If the other 12 times you buy something for 1.50 | 1.50 × 12 | 18 a month |
| Net savings | 48 − 18 | 30 a month |

That money only becomes savings if you decide where it goes. If not, it gets spent on something else.



#### Cost per unit

Divide the price by the amount you'll actually use.

A big package may be cheaper per piece, but a worse choice if it goes bad or leaves you without money for another need.



#### Promotions

Before you accept a promotion, ask yourself two things: would I buy it without the discount? Are there charges or automatic renewals afterward?

"No-cost trials" usually ask for your card and charge you automatically when they end. Write down the date so you can cancel before.

> **Good to know:** in California, companies that automatically renew subscriptions must let you cancel online if you signed up online. If they don't, you can file a complaint with the [California Attorney General](https://oag.ca.gov/consumers).



#### No guilt

Don't cut enough food, safe transportation or your only moment of rest to meet a goal that was poorly calculated.

A good adjustment is one you can keep up for months, not one you drop in a week.



#### Fees you can avoid

Some expenses that repeat aren't purchases but bank fees:

- another bank's ATMs, which can charge twice: your bank and the ATM owner;
- a monthly account fee if you don't keep a minimum balance;
- overdraft fees.

Ask your bank how to avoid them. Many accounts have no monthly fee if you get your pay by direct deposit. You'll see it in M2 U04.



#### Shop with a list

Going to the grocery store with a list and a full stomach helps you spend less on things you didn't plan to buy.

Compare unit prices on the shelf label: many stores show the price per ounce or per pound.

Store brands usually cost less and have the same quality for basic products, like rice, beans or oil.



#### Cases


**Case 1. Alex's sodas**

Alex buys a 2.50 soda every workday: 55 a month.
- *What does Alex decide?* To bring water three days a week and keep the soda on Fridays.
- *How much does that save?* About 30 a month, which goes to the savings cushion.


**Case 2. Rubén's forgotten subscription**

Rubén finds a 12.99 monthly charge from an app he tried "at no cost." He's been paying for eight months.
- *How much has he paid?* 12.99 × 8 = 103.92.
- *What does he do?* He cancels in the app or with the company, keeps the confirmation and checks his statement the next month.


**Case 3. Daniela's big package**

Daniela compares two packages of strawberries for her cakes. She'll only use half of the big one before they go bad.
- *Is the big one worth it?* No. What matters is the cost per piece she actually uses, not the price per piece she buys.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Cutting only small expenses | The savings are tiny and you get frustrated | Check rent, transportation and debts first |
| Canceling your card to stop paying for a service | The charge continues or you end up owing | Cancel with the company and keep the confirmation |
| Buying the big package because it's "cheap" | You waste food and come up short on something else | Calculate the cost based on what you actually use |
| Cutting every personal expense | The plan doesn't last | Leave room for what gives you well-being |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. A 4-dollar expense, 20 times a month: how much does it add up to in a year? a) 80 · b) 960 · c) 480
2. Does canceling your card automatically cancel a subscription? a) Not necessarily · b) Yes · c) Yes, if the card already expired
3. Insurance of 600 every 6 months: how much should you set aside each month? a) 50 · b) 600 · c) 100
**Answers:** 1-b: 80 a month for 12 months. 2-a: you have to cancel with the company. 3-c: 600 ÷ 6.



#### Put it into practice

Package A: 12 pieces for 9 dollars. Package B: 20 pieces for 14. You'll only use 10 before they expire. Which do you choose?
**Answer:** B is cheaper per piece bought (0.70 versus 0.75). But if you only use 10, the cost per piece used is 0.90 for A and 1.40 for B. A costs less money and wastes less.



#### Your plan

Choose one expense to reduce, one to cancel and one to keep, and write why.



### Learn more

- **Subscriptions and recurring charges** (FTC · English): https://consumer.ftc.gov — **What to look for:** type "cancel subscription" in the search box to see your rights and how to complain if they won't let you cancel.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the spending tracker worksheet in the budgeting module, to write down your expenses for a week.

### Key words

- *Latte factor:* a small expense that repeats.
- *Periodic expense:* a payment that repeats but isn't monthly.
- *Cost per unit:* price divided by the amount you actually use.
- *Automatic renewal:* when a service charges you again on its own.

### Sources

FDIC, Money Smart · FTC, recurring charges · California Automatic Renewal Law.

---

## M1 U07. Why am I short on money if I earn enough this month?

**What you will be able to do:** Spot shortfalls caused by dates, even when the monthly total seems to be enough.

**To start:** Alex and Mar earn enough to pay for the whole month. Even so, every 1st they're short on rent. They don't overspend: the problem is the dates. In this lesson you'll learn to make a money calendar.

### The essentials (5 minutes)

#### When money comes in and goes out

You have to pay 80 on Wednesday, but your 100 arrives on Friday. Today you have 50.
- What you have on Monday: **50**
- Wednesday's payment: **80**
- You're 30 short on Wednesday: **−30**
On Friday you'll have 70 left, but Wednesday comes up short. It's not only how much money comes in, but **when** it comes in and goes out: that's your **cash flow**.


#### Budget and calendar

A budget answers "how much." A money calendar answers "when."

You need both. A month can end positive and still have a negative week.



#### The calendar formula

Ending balance = starting balance + money in − money out.

One week's ending balance is the next week's starting balance.

> **Key idea:** write down each payment only once, on the date the money actually leaves.



#### What goes on your calendar

| Type | Description | What it means for you |
|---|---|---|
| Money in | Paychecks, tips, payments from clients. | With its real date. |
| Money out | Rent, utilities, debt payments, remittances, automatic charges. | With its charge date. |
| Moves between your accounts | Moving money from savings to checking. | Neither an expense nor income. |

#### If a week comes out negative

You have several options:

- set aside money from the previous paycheck;
- ask to change a payment date and confirm whether there are fees;
- agree on a partial payment;
- move an expense that can wait.

A change you asked for isn't approved until they confirm it, preferably in writing.



#### A case in one minute

Rubén gets 650 every Friday. His 750 rent is due on the 1st and his 60 phone bill on the 3rd.

If the 1st falls on a Tuesday, he only has what he got the Friday before. So he doesn't come up short, he sets aside 190 from each of the four paychecks before rent.

That way, when the 1st arrives, the money is already there. He doesn't earn more; he just arranges it in time.



#### Set alerts

Your bank's app can let you know when your balance drops below a certain amount or when a deposit comes in.

Turn on two alerts: one for a low balance, for example 100 dollars, and one two days before each automatic payment.

That way you find out in time, not after a fee has already been charged.



#### Check your understanding

1. If the month ends with a positive balance, can there be a negative week?
*Answer:* Yes. The problem can be the dates, not the total.

2. Is a transfer from your savings to your checking account an expense?
*Answer:* No. The money only changes places.


#### Remember

- Write down when each payment comes in and goes out.
- One week's ending balance is the next week's starting balance.
- Ask in writing for any date change.



### Go deeper (5 more minutes)

#### Positive month, negative week

| Day | What happens | Balance |
|---|---|---|
| Start | Starting balance | 100 |
| Day 1 | Rent −400 | −300 |
| Day 5 | Paycheck +600 | 300 |

The month ends with 300, but on day 1 you're 300 short. Having money at the end of the month doesn't solve day 1.



#### From your statement to your calendar

First check that your statement adds up: starting balance + deposits − withdrawals = ending balance.

Then separate:

- **transactions already posted;**
- **pending transactions**, which may already be subtracted from your available balance;
- **future commitments**, like next month's rent.



#### Automatic charges

Automatic payments are convenient, but they get charged even if you don't have the money.

If there's no money, the bank may reject the payment or cover it with an overdraft and charge you a fee.

Set an alert on your phone two days before each automatic charge.

> **Good to know:** many banks no longer charge overdraft fees or let you turn overdraft off. Ask whether your account has "overdraft protection" and how much it costs.



#### Fit the calendar to how you get paid

- **Paid daily:** close each day and add up each week.
- **Paid monthly:** from day one, set aside what's due later.
- **Shared household:** agree on what each person contributes and on what date.

An overdraft or a loan can cover a gap, but they cost money. Use them only after you've checked the other options.



#### Tools for your calendar

You don't need a special app. These work:

- a sheet of paper with 8 columns, one per week;
- your phone's calendar, with alerts on each payment date;
- the low-balance alerts in your bank's app.

What matters is writing down each paycheck and each payment on its real date and checking it once a week.

If you share expenses, a shared calendar on your phones helps everyone see the same thing.



#### Asking to change a payment date

Many utility companies, insurers and card companies let you choose your payment date.

Call or log in to your account and ask for a date that falls after your payday. Ask whether the change has any cost and ask for the confirmation in writing.

With rent it's harder, but you can propose paying in two parts if your lease and your landlord allow it. Always in writing.



#### Cases


**Case 1. Rent on the 1st**

Alex and Mar pay 1,800 in rent on the 1st. Alex gets paid every two weeks and Mar every week.
- *Why are they short on the 1st?* Because their paychecks arrive after the rent due date.
- *What do they do?* They set aside part of each paycheck from the two weeks before, to have the rent ready on time.


**Case 2. Daniela's automatic payment**

Daniela's car insurance is charged automatically on the 3rd. One month her account had 60 dollars and the 120 charge triggered a 35 overdraft fee.
- *What changed?* Now she has an alert two days before, and she asked her bank how to turn off overdraft.


**Case 3. Rubén's shared room**

Rubén and his roommates pay rent on the 1st, but each one gets paid on different dates.
- *What do they agree on?* Each one deposits their share into a shared account three days before, and they write it on a shared calendar.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Checking only the monthly total | You don't see the week when you're short | Make a calendar by week |
| Counting a payment twice | You think you're shorter than you really are | Write down each payment only once, on its date |
| Forgetting automatic charges | Overdrafts and fees | Set alerts before each charge |
| Assuming a date change went through | You get charged late fees | Wait for the confirmation in writing |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What is the formula for the ending balance? a) Money in − money out · b) Starting + money in − money out · c) Money in + money out − starting balance
2. If the month ends positive, can there be a negative week? a) Yes · b) No · c) Only if the month has five weeks
3. Is a date change you asked for already approved? a) Yes · b) Yes, if you asked by phone · c) No, not until they confirm it
**Answers:** 1-b: the previous week's balance counts. 2-a: the problem can be the dates. 3-c: wait for the confirmation.



#### Put it into practice

Week 1: starting balance 150, money in 500, money out 580. Week 2: money in 500, money out 620. Calculate the balances.
**Answer:** Week 1 ends at 70. Week 2 starts at 70 and ends at −50. You need to cover or move that shortfall before committing to another expense.



#### Your plan

Fill in 8 weeks with real dates. Mark each negative balance and the action you'll take.



### Learn more

- **Ways to pay your bills** (CFPB · English): https://files.consumerfinance.gov/f/documents/cfpb_ways-to-pay-your-bills_2022-08.pdf — **What to look for:** the comparison of automatic payment, online payment and in-person payment, with the pros and risks of each.
- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "bill calendar" tool to write down, week by week, when your money comes in and goes out.

### Key words

- *Cash flow:* money coming in and going out over time.
- *Available balance:* what the bank lets you use today.
- *Overdraft:* when you spend more than you have and the bank covers it for a fee.
- *Due date:* the last day to pay.

### Sources

CFPB, ways to pay your bills · CFPB, Your Money, Your Goals · CFPB, overdrafts.

---

## M1 U08. How do I decide what to use my money for?

**What you will be able to do:** Build a budget that works with your real resources and that you can adjust if your life changes.

**To start:** Alex and Mar made a budget that added up perfectly. A month later, Mar got fewer shifts and the plan fell apart. It wasn't a bad budget: it was missing a plan B. In this lesson you'll learn to make a budget that can handle a hard month.

### The essentials (5 minutes)

#### A budget is a plan

A **budget** is the plan for where your money will go before you spend it.

It doesn't require money to be left over. If you're short, a good budget shows it so you can look for a solution in time.



#### Add up where it goes

You have 100. You set aside 60 for food and transportation, 30 for a payment and 10 for another need.
- Food and transportation: **60**
- Payment and another need: **40**
- All your money has a job: **100**
If you need 120 in total, you're 20 short. Knowing it today gives you time to decide.


#### The order of priorities

1. **The basics:** housing, food, health, child care and transportation to work.
2. **Obligations:** debts and taxes, and what happens if you don't pay them.
3. **Family support** you've agreed on, like remittances.
4. **Savings and goals.**



#### Three ways to organize it

| Type | Description | What it means for you |
|---|---|---|
| By category | How much goes to each type of expense: rent, food, transportation. | The easiest way to start. |
| Zero-based | Every dollar has a job, including savings. | It doesn't mean spending it all. |
| Envelopes | You split your money into envelopes, in cash or in apps. | It helps you not go over in each category. |

#### Your plan B: the month with less income

Make two budgets: one with your usual income and one with 20% less.

For each adjustment, write what you'll do and for how long. For example: "I cut this category for one month" or "I ask to review this debt."

> **Key idea:** there is no percentage that works for every household. Use your real numbers.



#### A case in one minute

Rubén earns 2,600 a month. His rent is 750, food 400, transportation 130, phone 60, and he sends 300 to his mom. That adds up to 1,640 and leaves him 960.

It looks like a lot, but he hasn't counted work clothes or going out. Nor expenses that aren't monthly, like his roommate's car registration, which he helps pay.

With everything written down, he decides: 200 for savings, 150 for personal spending, 100 for non-monthly expenses and the rest for a study goal.



#### Do it this week

1. Write down your net income for the month.
2. Write down your basic expenses, your obligations and your family support.
3. Subtract: do you have money left or are you short?
4. Do the same math with 20% less income.



#### Check your understanding

1. Does a budget require money to be left over?
*Answer:* No. If you're short, it should show it so you can look for a solution.

2. A 240 payment is due in 6 months and you haven't set anything aside. How much do you set aside each month?
*Answer:* 40, because 240 ÷ 6 = 40.


#### Remember

- First the basics, then obligations, then family and goals.
- Have a budget for a month with 20% less income.
- A shortfall you've identified is already progress.



### Go deeper (5 more minutes)

#### Expenses that aren't monthly

If a 240 yearly payment is due in 6 months and you haven't set anything aside, you need 40 a month until that date.

Dividing by 12 (20 a month) would leave you short. After the payment, 20 a month is enough for the next year.

Car registration, school supplies or renewing a document aren't emergencies: you can see them coming.



#### If there's a deficit

A deficit is when what you need to pay is more than what you have. Order your actions like this:

1. Protect basic needs.
2. Check for support programs and your rights.
3. Negotiate obligations.
4. Cut expenses that can be replaced.
5. Look for realistic extra income, minus its costs.

Don't fill the budget with made-up income, and don't call it "saving" when you put what was missing on a credit card.



#### Alex and Mar's budget

| Item | Usual month | Month with 20% less |
|---|---|---|
| Income | 2,400 | 1,920 |
| Basic expenses | 1,800 | 1,800 |
| Debt | 200 | 200 |
| Remittance | 250 | 250 |
| Savings | 150 | 150 |
| **Result** | **0** | **−480** |

In a hard month they're 480 short of keeping everything the same.



#### Keep an emergency fund

An emergency fund is money for surprises, like an illness or losing work hours.

Start with a small goal, for example one week of basic expenses. Keep it apart from your day-to-day money.

> **Good to know:** according to Federal Reserve surveys, many families in the U.S. couldn't cover a surprise 400-dollar expense with cash. Starting small already puts you ahead.



#### What about the 50/30/20 rule?

You've probably heard of the 50/30/20 rule: 50% for needs, 30% for wants and 20% for savings.

It can be a starting point, but in cities with high rent almost nobody can follow it. If rent is already 45% of your income, you didn't fail: your city is expensive.

Use it as a reference, not as a test. What matters is that your plan is realistic and that you can keep it up.



#### Tools for your budget

You can make your budget in a notebook, in a spreadsheet on your phone or with your bank's app. The app often sorts your expenses on its own.

What matters isn't the tool, but reviewing it every month and adjusting it when your life changes.



#### Cases


**Case 1. Alex and Mar's hard month**

Their income drops from 2,400 to 1,920 and they're 480 short.
- *What adjustments can they make?* Pause savings (150), agree with the family on a smaller remittance for two months (100) and ask for a payment plan on the debt (100). That adds up to 350.
- *And the 130 still missing?* Look for support programs and review basic expenses. It's okay if a solution is still missing.


**Case 2. Is the subscription the problem?**

Canceling a 15 subscription leaves a 465 shortfall.
- *What does this show?* That the problem calls for reviewing big decisions and looking for support, not blaming the subscription.


**Case 3. Daniela's envelopes**

Daniela gets income from her hourly job and from her cake orders. She used to mix it all together, and at the end of the month she didn't know what had happened.
- *What changes?* She sets up three digital envelopes in her bank app: home, business and taxes. Each payment gets split up the same day.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Using an "ideal" percentage that isn't your reality | The plan fails from the first month | Start with your real numbers |
| Dividing a yearly payment by 12 when only a few months are left | You come up short when it's due | Divide by the months that are left |
| Calling it saving when you put what was missing on a card | The debt grows without you noticing | Record the shortfall as a deficit |
| Having no plan for a hard month | You decide in a hurry and it costs more | Build a budget with 20% less |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a budget require money to be left over? a) Yes · b) No · c) Yes, at least 10%
2. A 240 payment is due in 6 months and you haven't set anything aside. How much should you set aside each month? a) 40 · b) 20 · c) 240
3. Does a zero-based budget mean spending everything? a) Yes · b) It means not spending anything that isn't essential · c) No, it means giving every dollar a job
**Answers:** 1-b: it should show if you're short. 2-a: 240 ÷ 6. 3-c: every dollar has a job, including savings.



#### Put it into practice

Using Alex and Mar's numbers and the reduced income, write three adjustments and how much each one contributes. Are they enough?
**Answer:** For example: pausing savings (150), a smaller remittance for two months (100) and a payment plan on the debt (100) add up to 350. 130 is still missing: it's time to look for support programs and review basic expenses. A valid answer can show that a solution is still missing.



#### Your plan

Build your usual budget and one with 20% less income. Write down one immediate change, one conversation and one source of help.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "budget" tool and the "emergency fund" tool, ready to print.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the budgeting module and the monthly "spending plan" worksheet.

### Key words

- *Budget:* a plan for where your money will go.
- *Deficit:* when what you need is more than what you have.
- *Emergency fund:* money set aside for surprises.
- *Savings for planned expenses:* money set aside for a known payment.

### Sources

[S04] CFPB, Your Money, Your Goals · Federal Reserve, Economic Well-Being of U.S. Households report.

---

## M1 U09. Does filing taxes mean I'll get money back?

**What you will be able to do:** Tell apart filing, paying and getting a refund, and know what questions to ask.

**To start:** Mar expected a refund like last year. This time, when she did her tax return, it turned out she owed 400 dollars. She didn't do anything wrong: the way she gets paid changed. In this lesson you'll learn why sometimes you get money back and sometimes you pay.

### The essentials (5 minutes)

#### Filing is not the same as getting money back

**Filing your tax return** means reporting your information and calculating your tax for the year.

A **refund** only exists if you paid too much during the year. They're different things.



#### You paid too much or too little

The calculated tax is 100. During the year you already paid 120, because it was taken out of your wages.
- What you already paid: **120**
- What you owed: **100**
- Refund in your favor: **20**
If you had only paid 80, you would owe 20.


#### A deduction and a credit are not the same

| Type | Description | What it means for you |
|---|---|---|
| Deduction | It reduces the income your tax is calculated on. | It lowers part of your tax. |
| Tax credit | It reduces your tax directly. | It lowers your tax dollar for dollar. |

#### SSN and ITIN

The **SSN** is issued by Social Security. The **ITIN** is issued by the IRS to people who must file and can't get an SSN.

The ITIN **doesn't give you permission to work or change your immigration status**. Never use someone else's number or a made-up one.

> **Good to know:** if you don't use your ITIN on a federal return for three years in a row, the IRS deactivates it. Renewing it can take months and delay your refund and your state credits, like CalEITC and YCTC.



#### Filing and paying have dates

There's a date to file your return and another to pay what you owe. They usually both fall in mid-April.

An **extension to file** usually does **not** give you more time to pay.



#### A case in one minute

Daniela is paid by the hour at her job, with withholding, and she also sells cakes, without withholding.

She does her tax return and finds she owes nothing for her job, but she does owe taxes on the cakes.

For next year, she sets aside part of each order in a digital "taxes" envelope. That way, when April comes, the money will already be there.



#### Do I have to file?

It depends on how much you earned, your filing status and how you earned your money.

If you work for yourself, in many cases you must file even if you earned little. And even if you don't have to, filing can get you credits you're entitled to.

Ask at VITA or a preparer with credentials whether you have to file this year.



#### Do it this week

1. Put your W-2 and 1099 forms in a folder.
2. Check whether your ITIN or SSN and your family's are active.
3. Write down this year's deadline.



#### Check your understanding

1. Does filing your return guarantee a refund?
*Answer:* No. There's only a refund if you paid too much during the year.

2. Does the ITIN allow you to work?
*Answer:* No. It's only for meeting your tax obligations.


#### Remember

- Filing is reporting; a refund only exists if you paid too much.
- A credit lowers your tax more than a deduction of the same size.
- Use your ITIN every year so it doesn't get deactivated.



### Go deeper (5 more minutes)

#### Deduction versus credit with numbers

With a made-up rate of 10%:

- a 100 deduction lowers your tax by 10;
- a 100 credit lowers it by 100.

Some credits are **refundable**: they can give you money even if you owe no tax.



#### Marginal rate and effective rate

In a made-up scale, the first 1,000 pays 10% and the next 1,000 pays 20%.

With an income of 2,000, the tax is 100 + 200 = 300. The rate on the last bracket is 20%, but the effective rate is 300 ÷ 2,000 = 15%.

Moving into the next bracket does **not** make all your income pay the higher rate. Earning more always leaves you with more money.



#### Federal and state

There's a federal return, with the IRS, and in California a state return, with the Franchise Tax Board (FTB).

Your residency for tax purposes, your filing status and your dependents are decided by rules and facts, not by your nationality. Tax residency and immigration status are different things.



#### Withholding and estimated payments

What's taken out of your wages is an advance on your tax.

If you get paid through apps, in cash or on your own, nobody withholds anything. That's why you may owe at the end of the year. If that's your case, set money aside during the year (you'll see it in M1 U10).

> **Good to know:** the IRS usually contacts you first by mail. Be suspicious of calls, texts or emails demanding immediate payment.



#### What you need to file

- Your ID and your SSN or ITIN, and your dependents'.
- Your W-2 and 1099 forms.
- Your record of income and expenses if you work for yourself.
- Last year's return, if you have it.
- Your bank account information to receive the refund.

Bring everything to your appointment. If something is missing, ask whether you can turn it in later.



#### Watch out for tax scams

Some scams pretend to be the IRS: they call, text or email demanding immediate payment with gift cards or transfers.

The IRS doesn't ask you to pay with gift cards or threaten to arrest you over the phone. If you have doubts, go to IRS.gov yourself.



#### If you can't pay it all

If you find out you owe when you file and can't pay it all, file your return on time anyway. Not filing usually costs more than not paying.

The IRS and the FTB have installment payment plans. Request them on their official websites.



#### Cases


**Case 1. The expected refund**

Mar believes that "filing taxes is so they give you money back." This year she got part of her income through an app, with no withholding. When she does the math, she owes 400.
- *What happened?* Nobody withheld taxes from what she got through the app.
- *What can she do next year?* Set aside a little from each app payment or make payments during the year.


**Case 2. Dependents in Mexico**

Alex sends money to Alex's mother in Michoacán.
- *Can she be claimed as a dependent?* It isn't automatic. There are rules about relationship, residency and support that change. Alex should take the information to a preparer with credentials.


**Case 3. Rubén's ITIN**

Rubén got his ITIN four years ago, but he didn't file for the last three.
- *What can happen?* His ITIN may be deactivated. He should check it before filing so he can renew it in time.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking that filing always brings money | A debt catches you by surprise | Check whether taxes were withheld during the year |
| Believing that moving into a higher bracket takes money away | You turn down overtime or a raise | The higher rate only applies to what's above the bracket |
| Not using your ITIN | It gets deactivated and your credits are delayed | File every year |
| Paying someone who calls demanding an IRS payment | You lose money to a scam | Go to IRS.gov yourself to check |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does filing your return guarantee a refund? a) Yes · b) No · c) Yes, if you have children
2. Does the ITIN authorize you to work? a) No · b) Yes · c) Yes, if you renew it every year
3. Does an extension to file extend the deadline to pay? a) Usually yes · b) Yes, always for six months · c) Usually no
**Answers:** 1-b: only if you paid too much. 2-a: it's only for taxes. 3-c: payment is still due on the original date.



#### Put it into practice

Calculated tax 1,400; advance payments 1,100. What is the result? And if the advance payments were 1,600?
**Answer:** In the first case you owe 300. In the second, you get a 200 refund. This isn't a calculation with real tax tables.



#### Your plan

Write down the tax year, your documents, the dates you checked and your unanswered questions.



### Learn more

- **IRS: Filing** (IRS · English and Spanish): https://www.irs.gov/filing — **What to look for:** who has to file and this year's deadline.
- **How to apply for an ITIN** (IRS · English and Spanish): https://www.irs.gov/tin/itin/how-to-apply-for-an-itin — **What to look for:** the list of accepted documents and the section on when an ITIN expires and how to renew it.
- **No-cost tax help in California** (FTB · English): https://www.ftb.ca.gov/help/free-tax-help/index.html — **What to look for:** the no-cost filing options and the finder for nearby locations.

### Key words

- *Tax return:* a document that reports your information and calculates your tax.
- *Refund:* money back when you paid too much.
- *Withholding:* an advance on taxes taken out of your wages.
- *Deduction:* it lowers the amount the tax is calculated on.
- *Tax credit:* it lowers the tax.
- *ITIN:* the IRS tax number for people who can't get an SSN.

### Sources

[S12] IRS, ITIN · [R06] IRS, dates and extensions · IRS, ITIN expiration.

---

## M1 U10. Is everything I earn on my own for spending?

**What you will be able to do:** Organize your records based on your type of income: wages, self-employment or both.

**To start:** Daniela makes cakes to order on top of her hourly job. In April she realized she didn't know how much she had earned from the cakes or how much she had spent on ingredients. In this lesson you'll learn to keep your records so tax season isn't a headache.

### The essentials (5 minutes)

#### Getting paid is not the same as earning

You charge 100 for a job and spent 30 on materials.
- What you charged: **100**
- What you spent to do the work: **30**
- Your profit before taxes: **70**
Keep the receipt for the 30. It helps you prove your expense.


#### Three folders depending on your work

| Type | Description | What it means for you |
|---|---|---|
| Wages | Pay stubs, W-2 form and withholding. | Check that your information is correct. |
| Self-employment | Payments in cash, through apps and by transfer; expenses with receipts; tax payments you made. | Keep records all year, not only in April. |
| Both | Both folders and one sheet that brings them together. | Count each income only once. |

#### The daily log

If you get paid in cash, through apps or get tips, write down at the end of each day how much you received and how.

Separately, write down what you spent on materials, gas or tools, and take a photo of the receipt that same day.

At the end of the month, add it up: what you received minus what you spent to work is your real profit.



#### App income counts too

The IRS says that what you earn through apps may have to be reported even if you don't get any form.

The **1099 form** reports certain payments, but it doesn't calculate your profit or decide whether you're an employee.

> **Key idea:** if nobody withholds taxes for you, set money aside from each payment from day one.



#### Do it this week

1. Create two folders, on paper or on your phone: work income and work expenses.
2. Start your daily log of payments.
3. Take a photo of each receipt the same day.



#### A case in one minute

Alex does weekend jobs with a pickup truck. In one year Alex charged 6,000 and spent 1,500 on materials and 900 on gas.

Because each trip was written down, Alex can prove how many miles were used for work. The profit before taxes is 3,600, not 6,000.

Without those records, Alex could pay taxes on money that was actually spent on the work.



#### Set money aside for taxes from day one

If you work for yourself, nobody takes taxes out for you. That's why it helps to open a separate envelope or account just for taxes.

Each time you get paid, move part of it to that envelope. That way, when it's time to pay, you won't have to take the money from rent or food.



#### Check your understanding

1. You move 500 from your business account to your personal account. Is it new income?
*Answer:* No. It only changed places.

2. An app didn't send you a form. Do you report that income?
*Answer:* It may have to be reported. Record everything you receive.


#### Remember

- What you charge is not what you earn: subtract your costs.
- Write down your payments and expenses every day.
- Set money aside for taxes if nobody withholds them.



### Go deeper (5 more minutes)

#### Reconcile so you don't count twice

If a platform reports 1,000 and your bank received two deposits of 500 for those same payments, your income is 1,000, not 2,000.

Moving money from the business account to your personal account isn't new income or a business expense.

A family remittance isn't a business expense, even if it comes out of the business account.



#### Using your car and phone for both

If you use your car or phone for work and for personal use, you need records that show how you separate each use.

For the car, write down each work trip: date, destination, purpose and miles. An estimate without data doesn't work as proof.



#### Estimated payments

If you work for yourself and nobody withholds taxes, you may need to make estimated payments during the year.

There may be income tax and also self-employment tax, which covers your Social Security and Medicare.

Don't set aside "10%" just because someone else does. Calculate your case with professional guidance and update it when your income changes.

> **Good to know:** the IRS splits estimated payments into four dates a year. Paying late can bring penalties even if you pay it all in the end.



#### What each receipt should have

Date, seller, amount, what it was for and how you paid.

If one is missing, write down which one and how to get it back, for example by asking the seller for a copy. Never make up amounts or receipts.



#### If your business grows

If your business grows, you may need:

- a business license from your city;
- a seller's permit if you sell products, for example food;
- an employer identification number (EIN) if you hire someone.

You'll see it in detail in M5 U10. For now, keep good records: they're the basis for everything else.



#### Keep your accounts separate

Having an account just for your business makes everything easier. You see how much comes in, how much you spend and how much you earn. And you don't mix it with your personal life.

You don't need a business account with a fee. A second personal account with no fees can work at first.

Pay yourself a fixed amount, for example every week, by moving money from the business account to your personal account.



#### Cases


**Case 1. Mar's tips and app**

Mar gets her wages through payroll, tips in cash and some payments through an app. The app sends her a 1099 for 3,200. Her cash tips added up to 4,500 and don't show up on any form.
- *What must she report?* All of it: wages, the app payments and the tips.
- *How does she prove it?* With her daily tip log.


**Case 2. Alex's faded receipts**

Alex does weekend jobs and kept the receipts for materials in a box. By the end of the year many had faded.
- *What changes?* Now Alex takes a photo of each receipt the same day and saves it in a folder on the phone.


**Case 3. Daniela's cakes**

Daniela gets paid for her orders in cash and through Zelle. She buys ingredients at three different stores.
- *How does she get organized?* An order log with date, customer, amount and payment method, and a folder with photos of each ingredient receipt.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Counting the app deposit and the transfer to your account | You report too much | Reconcile and count each payment only once |
| Not writing down cash | You can't prove your income | Keep a daily log |
| Keeping receipts without checking them | They fade and become useless | Take a photo of them the same day |
| Setting aside a percentage you "heard about" | You're short or have too much when you file | Calculate your case with a professional |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can app income have to be reported even if you get no form? a) Never · b) It can · c) Only if it's over 600
2. Is moving 500 from the business account to your personal account new income? a) No · b) Yes · c) Yes, if it's more than 400
3. Should you set aside "10%" for taxes because a friend does? a) Yes · b) Yes, and 5% if you're paid in cash · c) No, you need to calculate your case
**Answers:** 1-b: the IRS says it can be. 2-a: it only changed places. 3-c: every case is different.



#### Put it into practice

Payments received 1,000; work costs 250; transfer to your personal account 500. What is the result before taxes?
**Answer:** 750. The 500 transfer isn't more income or another expense.



#### Your plan

Prepare folders for income, expenses, health, family and notices from the IRS or the FTB. If you have property or income in another country, write that question down for your preparer.



### Learn more

- **Gig Economy Tax Center** (IRS · English and Spanish): https://www.irs.gov/businesses/gig-economy-tax-center — **What to look for:** "What income do I report?" and the recordkeeping guide for people paid through apps.
- **Self-Employed Individuals Tax Center** (IRS · English): https://www.irs.gov/businesses/small-businesses-self-employed/self-employed-individuals-tax-center — **What to look for:** the section on estimated payments and self-employment tax.

### Key words

- *Business income:* what you receive before costs.
- *Business costs:* what you spend to work or sell.
- *Estimated payments:* tax payments made in advance during the year.
- *Form 1099:* reports certain payments you received.
- *W-2:* the yearly summary of your wages and withholding.

### Sources

[S13] IRS, gig economy · [R05] IRS, Publication 505 · [R27] IRS, self-employed individuals.

---

## M1 U11. What tax benefits are there if I file with an ITIN?

**What you will be able to do:** Learn how to get an ITIN, which credits may apply to your household and where to get no-cost help to file.

**To start:** Mar thought that, because she files with an ITIN, she wasn't entitled to any benefit. At a no-cost tax help site she found out her family could get state credits. In this lesson you'll learn what benefits exist if you file with an ITIN in California.

### The essentials (5 minutes)

#### Filing with an ITIN can put money in your pocket

Filing with an ITIN can give you access to state credits that put money in your pocket.

It also creates a record that you meet your tax obligations every year.



#### California credits that accept an ITIN

| Type | Description | What it means for you |
|---|---|---|
| CalEITC | State credit for work income for low-income households. | You can claim it with an ITIN. |
| Young Child Tax Credit (YCTC) | Extra credit if you qualify for CalEITC and have a child under 6. | You can claim it with an ITIN. |
| Federal credits (EITC and others) | Several federal credits require an SSN. | Check the requirements each year. |

#### Three steps

1. **Find out if you need an ITIN:** if you must file and can't get an SSN.
2. **Check which credits exist** for your situation this year.
3. **Look at no cost, certified help** to prepare your return.



#### No-cost help to file

**VITA** is an IRS program with certified volunteers. It helps people with incomes under a limit that is published every year, at no cost.

Many sites offer help in Spanish and help with the ITIN application.

> **Good to know:** if you don't use your ITIN on a federal return for three years in a row, it's deactivated. Filing every year keeps it active and avoids delays in your state credits.



#### A case in one minute

Rubén works and files with an ITIN. He has no children. He thought he didn't qualify for anything.

At VITA they explain that CalEITC can also apply to people without children, depending on income. His state return ends up with a small refund.

His return also leaves a record that he meets his tax obligations every year.



#### Do it this week

1. Find the nearest VITA site with the IRS locator.
2. Write down its hours, its languages and the documents it asks for.
3. Put your forms and your ID in a folder.



#### Children may need an ITIN too

If your children don't have an SSN and you want to include them on your return, they may also need an ITIN.

Ask at VITA which documents are needed for the children. Children born in the U.S. have an SSN and don't need an ITIN.



#### Check your understanding

1. Can you claim CalEITC with an ITIN?
*Answer:* Yes. It's a California state credit that accepts an ITIN.

2. Can you use an ITIN to work?
*Answer:* No. It's only for meeting your tax obligations.


#### Remember

- In California there are state credits that accept an ITIN.
- VITA helps at no cost and in Spanish.
- File every year to keep your ITIN active.



### Go deeper (5 more minutes)

#### How to get an ITIN

You apply with **Form W-7**, usually together with your tax return, plus documents that prove your identity and your country of origin. A valid passport works for both.

So you don't have to mail your original passport, you can go to a **Certifying Acceptance Agent** (CAA), who reviews and certifies your documents.

You can also make an appointment at some IRS offices that review documents in person.



#### Federal credits that require an SSN

The federal Earned Income Tax Credit (EITC) requires a valid SSN.

The federal Child Tax Credit has SSN requirements that changed recently. There's a smaller credit for "other dependents" with its own rules.

Always check the rules for the current year: they change often.



#### Other no-cost options

- **TCE:** an IRS program similar to VITA, focused on people 60 and older.
- **CalFile:** a no-cost FTB tool for simple state returns, if you qualify.



#### Why file even if it doesn't seem worth it this year

It may be required depending on your income. It creates a compliance record. It lets you get credits you're entitled to. And it keeps your ITIN active.

> **Before you act, check:** never pay someone who "sells" ITINs or promises credits without reviewing your documents.



#### Protect your ITIN

Your ITIN is as important as an SSN: tax returns can be filed in your name with it.

Don't share it on social media or with people who don't need it. Keep the IRS letter that assigned it to you.

If you get an IRS notice about a return you didn't file, it may be identity theft. Report it at IdentityTheft.gov (you'll see it in M4 U04).



#### When to apply or renew

The most common way is to apply for or renew the ITIN together with your return, starting in January.

If your ITIN is deactivated, renew it before you file. If you do it late, your refund and your credits can take several months.



#### What to bring to your VITA appointment

- Photo ID.
- The SSN card or ITIN letter for each person on the return.
- W-2 and 1099 forms.
- Your record of income and expenses if you work for yourself.
- Your bank account information for the refund.
- Last year's return, if you have it.



#### Cases


**Case 1. Mar and CalEITC**

Mar files with an ITIN. With her income and two young children, a VITA site checks whether she qualifies for CalEITC and YCTC.
- *What does she find out?* That instead of owing, she gets a state credit. Her 4-year-old also qualifies her for YCTC.


**Case 2. The passport in the mail**

A neighbor tells Rubén that for the ITIN he has to mail his original passport to the IRS.
- *Is there another option?* Yes. A Certifying Acceptance Agent can review his documents without him mailing them.


**Case 3. Daniela's expired ITIN**

Daniela didn't file for three years and her ITIN was deactivated.
- *What does she do?* She renews it with Form W-7 together with her next return, with time to spare, so her credits aren't delayed.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing there are no benefits with an ITIN | You leave money unclaimed | Check CalEITC and YCTC every year |
| Mailing your original passport when you don't have to | You're left without ID for months | Look for a Certifying Acceptance Agent |
| Paying someone who "sells" ITINs | You lose money and put your information at risk | Apply only through the IRS, VITA or an authorized agent |
| Not filing for three years | Your ITIN gets deactivated | File every year |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can you use an ITIN to work? a) Yes · b) No · c) Yes, in California
2. Can CalEITC be claimed with an ITIN? a) Yes · b) No · c) Only if you have an SSN
3. What happens if you don't use your ITIN on a federal return for three years in a row? a) Nothing · b) It turns into an SSN · c) It expires
**Answers:** 1-b: it's only for taxes. 2-a: it's a state credit that accepts an ITIN. 3-c: the IRS deactivates it.



#### Put it into practice

Write three questions to bring to your VITA appointment if you file with an ITIN and have children.
**Answer:** Do I qualify for CalEITC and YCTC this year? Are my ITIN and my children's active? What documents do I need to claim my dependents?



#### Your plan

Find the nearest VITA site and write down its hours, its languages and the documents it asks for.



### Learn more

- **CalEITC** (FTB · English and Spanish): https://www.ftb.ca.gov/file/personal/credits/california-earned-income-tax-credit.html — **What to look for:** this year's income limits table and the calculator to see if you qualify.
- **Young Child Tax Credit** (FTB · English): https://www.ftb.ca.gov/file/personal/credits/young-child-tax-credit.html — **What to look for:** the child's age requirements and how much the credit can be.
- **Acceptance Agent finder** (IRS · English): https://www.irs.gov/tin/itin/itin-acceptance-agents — **What to look for:** filter by California and your city to find a nearby agent.
- **No-cost tax return preparation (VITA)** (IRS · English and Spanish): https://www.irs.gov/individuals/free-tax-return-preparation-for-qualifying-taxpayers — **What to look for:** the site locator by ZIP code and what documents to bring.

### Key words

- *ITIN:* the IRS tax number for people who can't get an SSN.
- *CalEITC:* California's state credit for work income.
- *Refundable credit:* it can give you money even if you owe no tax.
- *VITA:* no-cost IRS tax help with certified volunteers.
- *Certifying Acceptance Agent:* a person authorized by the IRS to review ITIN documents.

### Sources

[S12] IRS, ITIN · [S14] FTB, ITIN · [S15] FTB, no-cost tax help · [R19] IRS, VITA · [R48] FTB, CalFile.

---

## M1 U12. How do I choose someone to help me with taxes?

**What you will be able to do:** Compare tax preparation services and recognize dangerous practices.

**To start:** Rubén saw an ad on social media: "3,000 refund guaranteed." They asked him to sign before they looked at his papers. Something didn't feel right. In this lesson you'll learn to choose who helps you with your taxes and spot the warning signs.

### The essentials (5 minutes)

#### Compare what's included, not only the price

One person advertises their service at 50 and another at 80. You still don't know which is cheaper: maybe the first charges extra for what you need.

Compare the **scope of service**: what's included, what isn't and what it all costs.



#### Three steps to choose

1. **Explain what you need:** federal and state, self-employment, ITIN, dependents.
2. **Ask what's included** and the total cost, in writing.
3. **Check who will do the work** and their credential.



#### Credentials in California

| Type | Description | What it means for you |
|---|---|---|
| PTIN | IRS number every paid preparer must have. | Required for everyone. |
| CTEC | State registry for preparers who aren't CPAs, EAs or attorneys. | Check it on their website. |
| CPA, EA or attorney | Licensed professionals who can represent you before the IRS. | Check them in the IRS directory. |

#### Warning signs

Walk away if the preparer:

- promises "the maximum refund guaranteed" before seeing your papers;
- asks you to sign blank pages;
- wants the refund sent to their account instead of yours;
- suggests making up expenses or dependents;
- doesn't sign the return as the preparer.

> **Key idea:** never sign something you haven't read. You are responsible for what your return says.



#### A case in one minute

Mar is looking for someone to do her tax return. An office in the neighborhood charges 60, but won't give her a copy. Another charges 150, signs as the preparer and is registered with CTEC.

Mar asks at a VITA site and finds out she qualifies for no-cost help. She brings her papers and gets a copy of everything.

She learned that the lowest price isn't always the best, and that the no-cost option is sometimes the safest.

> **Before you act, check:** always ask for the total price in writing and a complete copy of your return.



#### Do it this week

1. Ask two preparers what their price includes and the total cost.
2. Check their registration with CTEC or in the IRS directory.
3. Check whether you qualify for VITA, which costs nothing.



#### Check your understanding

1. What must every paid preparer have?
*Answer:* An IRS PTIN.

2. You're promised a guaranteed refund before they see your papers. What do you do?
*Answer:* You don't sign, and you look for an option you can verify, like VITA or a registered preparer.


#### Remember

- Compare what the price includes, not only the price.
- Check the PTIN and the CTEC registration.
- Never sign blank pages or let the refund go to another account.



### Go deeper (5 more minutes)

#### What to ask before hiring

- Does it include the federal and the state return?
- Does it include self-employment, ITIN, dependents, late returns or corrections?
- Will they help me if an IRS notice arrives later?
- Who signs the return and what credential do they have?



#### Compare the full bill

| | Advertised price | Self-employment | State | Total |
|---|---|---|---|---|
| Service A | 90 | 100 | 60 | 250 |
| Service B | 230 (all included) | included | included | 230 |

The comparison only works if both include the same tasks. In this case, the "expensive" one is cheaper.



#### Loans against your refund

Getting money early "against your refund" is a loan, with its own terms and costs.

The loan's speed isn't the IRS's speed. If the refund turns out smaller, you may end up owing.



#### Before and after you sign

**Before you sign,** check your information, income, expenses, dependents and the account where the refund will go.

**Afterward,** keep a complete copy and the filing confirmation.

**If a notice arrives,** write down the date and the deadline. Check that it's real by going to IRS.gov or FTB.ca.gov yourself; don't use the phone number in the message.

> **Good to know:** in California, preparers registered with CTEC must have a 5,000-dollar bond and take courses every year. You can check them at [ctec.org](https://www.ctec.org).



#### "Notario" scams and fake preparers

Some people advertise as a "notario" or "advisor" and offer to do taxes and immigration paperwork at the same time.

A notary public in the U.S. only certifies signatures. They can't prepare immigration paperwork or give legal advice. You'll see it in M4 U02.

If a preparer harms you, you can report them to the IRS with Form 14157 and, in California, to CTEC.



#### What they must give you

When it's done, ask for:

- a complete copy of your federal and state return;
- the e-file confirmation;
- the name and PTIN of the person who prepared it.

Keep it for at least three years. It will help if a notice arrives or if you need to prove your income.



#### When a professional is worth it

If your case is simple, VITA or a registered preparer can help you.

Sometimes it's worth going to an enrolled agent (EA), an accountant (CPA) or a tax attorney. For example, if you have a business with employees or property in another country. Also if you have several years of late returns or an IRS notice you don't understand.



#### Cases


**Case 1. The guaranteed refund**

An ad on social media promises Rubén a "3,000 refund guaranteed." They ask him to sign before reviewing anything.
- *What does he do?* He doesn't sign and looks for a VITA site.
- *Why is it a warning sign?* Nobody can promise a refund without reviewing your documents.


**Case 2. The two quotes**

Mar compares two preparers. The cheap one charges extra for the state return and for self-employment. The expensive one includes everything and gives her a copy.
- *Which one is better for her?* The second one, which turns out cheaper for her case.


**Case 3. The refund account**

Daniela's preparer asks her to have the refund sent to "the office account" to "save time."
- *What does she do?* She says no. The refund must go to her own account. She looks for another preparer.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Choosing by the advertised price | You pay more for what they charge extra | Ask for the total price in writing |
| Signing blank pages | They can put false information in your name | Sign only what you've reviewed |
| Letting the refund go to another account | You can lose your money | Use your own account |
| Calling the number in a "notice" message | It may be a scam | Go to IRS.gov or FTB.ca.gov yourself |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What must every paid preparer have? a) Nothing · b) A PTIN · c) A law license
2. In California, a paid preparer who isn't a CPA, EA or attorney must register with: a) CTEC · b) The DMV · c) The consulate
3. Is it safe to sign a blank tax return? a) Yes · b) Yes, if it's a preparer you know · c) No
**Answers:** 1-b: the PTIN is required. 2-a: CTEC is the state registry. 3-c: they can put false information on it.



#### Put it into practice

A preparer promises "the maximum refund guaranteed" before seeing your documents and asks you to sign empty pages. What do you do?
**Answer:** You don't sign, you protect your documents and you look for an option you can verify (VITA or a registered preparer). A refund can't be promised without reviewing your information.



#### Your plan

Compare two services and one no-cost option. Write down what you confirmed and what's still missing.



### Learn more

- **Verify a registered preparer** (CTEC · English): https://www.ctec.org — **What to look for:** "Verify a Preparer"; type the preparer's name to confirm their registration is current.
- **IRS directory of preparers** (IRS · English): https://irs.treasury.gov/rpo/rpo.jsf — **What to look for:** search by ZIP code to find CPAs and enrolled agents (EAs) with verified credentials.
- **No-cost tax return preparation (VITA)** (IRS · English and Spanish): https://www.irs.gov/individuals/free-tax-return-preparation-for-qualifying-taxpayers — **What to look for:** the site locator by ZIP code.

### Key words

- *Scope of service:* the tasks included in the price.
- *Credentials:* records that prove training or authorization.
- *PTIN:* the IRS preparer number.
- *CTEC:* California's registry of tax preparers.

### Sources

[S15] FTB, no-cost help · [S16] FTB, Publication 982 · [R36] CTEC, preparer verification.

---

## M1 U13. What should I know before I apply for public benefits?

**What you will be able to do:** Understand what "public charge" is, which benefits exist and where to confirm your case before you decide.

**To start:** Daniela needs help buying food for her son, but a neighbor told her that asking for any benefit could hurt her. She doesn't know if it's true. In this lesson you'll learn what the rule says and where to confirm your case without taking risks.

### The essentials (5 minutes)

#### Decide with information, not rumors

Many families don't apply for benefits they're entitled to, out of fear it will affect an immigration case. Others apply without knowing whether the rule applies to them.

Both problems have the same solution: reliable information about your case.



#### What public charge is

**Public charge** is a review done in some immigration cases, mainly certain applications for permanent residency.

It only applies to certain cases and only looks at certain benefits.



#### What the rule in effect since 2022 looks at

| Type | Description | What it means for you |
|---|---|---|
| It is considered | Cash assistance to maintain income (like SSI or CalWORKs cash aid) and long-term care paid by the government. | Get advice before applying. |
| It is not considered | CalFresh, Medi-Cal (except long-term care), WIC, school meals, housing, tax credits like CalEITC. | You can apply without it counting. |
| Your family's benefits | What other members receive, like citizen children, doesn't count as yours. | It isn't added to your case. |

#### Three steps before you decide

1. Identify what kind of help you need: food, health, housing or money.
2. Find out who in your household might qualify.
3. Confirm with a reliable source how the rule applies to your case.

> **Key idea:** rules can change. A proposal isn't a rule until it's published as final and takes effect.



#### A case in one minute

Rosa lives in Fresno with her daughter and grandchildren. She stopped taking her grandchildren to WIC out of fear it would affect her. Her daughter shares what she learned: WIC isn't considered under the current public charge rule, and the grandchildren's benefits don't count as Rosa's.

Rosa calls a community organization to confirm it. They tell her the same thing and recommend she check the rule every year in case it changes.

> **Before you act, check:** the current status of the rule and of each program with an attorney or an accredited representative.



#### Do it this week

1. Write down what help your household needs.
2. Look for a legal aid organization or an accredited representative near you.
3. Bring your questions in writing.



#### Check your understanding

1. Does public charge apply to all immigration cases?
*Answer:* No. Only to certain cases, mainly some residency applications.

2. Do benefits your citizen children receive count as yours?
*Answer:* No. Under the current rule, they don't count as yours.


#### Remember

- The rule only applies to certain cases and certain benefits.
- CalFresh, WIC and tax credits aren't considered under the current rule.
- Confirm your case with an attorney or an accredited representative.



### Go deeper (5 more minutes)

#### Who it doesn't apply to

The rule doesn't apply to many cases and categories. For example, it doesn't apply to permanent residents applying for citizenship, or to refugees or asylees.

That's why the right question isn't "will applying for help affect me?" but "does the rule apply to my case?"



#### Health care in California

In recent years Medi-Cal expanded coverage for people without regular immigration status. The 2025 state budget approved changes for adults, like pausing new enrollment starting in 2026, and other adjustments.

Confirm the current rules before you decide. Children have different rules.

> **Good to know:** even with changes to Medi-Cal, you have the right to receive medical care. Community health centers (called FQHCs) serve anyone regardless of immigration status and charge based on your income. You can find one at [findahealthcenter.hrsa.gov](https://findahealthcenter.hrsa.gov).



#### Where to confirm your case

- An immigration attorney or an accredited representative of the Department of Justice (DOJ).
- Organizations like *Protecting Immigrant Families*, with up-to-date materials.
- Your county's social services office, for each program's requirements.



#### Watch out for "paperwork helpers"

Nobody who isn't an attorney or an accredited representative can give you immigration advice. A notary public can't do it (you'll see it in M4 U02).

This course doesn't give immigration advice either: it helps you ask the right questions.



#### Common programs and how they're considered

| Program | Considered under the current rule? |
|---|---|
| CalFresh (food) | No |
| WIC | No |
| Medi-Cal | No, except long-term care |
| School meals | No |
| Tax credits (CalEITC, YCTC) | No |
| SSI or cash assistance | Yes |

This table sums up the rule in effect since 2022. Always check whether it has changed.



#### How to ask without exposing yourself

You can ask general questions without giving your name or your situation. For example: "Is this program considered for public charge?"

Legal aid organizations and accredited representatives keep what you tell them confidential.



#### Check the rule every year

The rules on public charge and on state programs can change.

Set a reminder on your phone to check every year, or before you start an immigration case, whether anything changed. Legal aid organizations post notices when something changes.



#### Cases


**Case 1. Food for Daniela's son**

Daniela's son was born in California. She was afraid to ask for help with food.
- *What does a community organization explain to her?* That her son's benefits don't count as hers and that CalFresh isn't considered under the current rule.
- *What does she do next?* She confirms her case with an accredited representative before she decides.


**Case 2. The neighbor's rumor**

A neighbor tells Alex that "any benefit takes away your green card."
- *What does Alex do?* Looks for a reliable source before deciding, like Protecting Immigrant Families or an accredited representative.


**Case 3. Mar's question**

Mar needs medical care and doesn't know whether she can enroll in Medi-Cal this year.
- *What options does she have while she confirms?* Go to a community health center that charges based on her income.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Deciding based on a rumor | You stop getting benefits you're entitled to | Confirm with a reliable source |
| Asking a notario or "helper" for advice | You get false information and pay too much | Look for an attorney or an accredited representative |
| Believing a proposal is already a rule | You decide with information that doesn't apply | Check whether the rule is final and in effect |
| Not getting care out of fear | Your health gets worse | Use a community health center |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does the public charge rule apply to all immigration cases? a) Yes · b) No · c) Only to citizenship
2. Under the current rule, is CalFresh considered for public charge? a) No · b) Yes · c) Yes, if the children use it
3. Who can give you immigration advice? a) A notario · b) An immigration consultant with an office and ads · c) An attorney or a DOJ-accredited representative
**Answers:** 1-b: only certain cases. 2-a: it isn't considered. 3-c: only they are authorized.



#### Put it into practice

Write three questions to bring to a legal aid organization before applying for a benefit for your family.
**Answer:** Does the public charge rule apply to my case? Is this benefit considered? Do my children's benefits affect my case?



#### Your plan

Write down what help your household needs, who might qualify and where you'll confirm your case.



### Learn more

- **Public charge: does it apply to me?** (Protecting Immigrant Families · English and Spanish): https://pifcoalition.org/resources/library/public-charge-does-this-apply-to-me/ — **What to look for:** the guide that explains which benefits count and who the rule applies to.
- **Medi-Cal** (California DHCS · English and Spanish): https://www.dhcs.ca.gov — **What to look for:** the eligibility section and the notices about changes for adults in 2026.
- **Find a health center** (HRSA · English and Spanish): https://findahealthcenter.hrsa.gov — **What to look for:** type your ZIP code to see nearby clinics that charge based on your income.

### Key words

- *Public charge:* a review in certain immigration cases of dependence on government benefits.
- *Accredited representative:* a person authorized by the DOJ to give immigration advice at a recognized organization.
- *CalFresh:* food assistance in California.
- *FQHC:* a community health center that serves people regardless of immigration status.

### Sources

[R33] USCIS, public charge · [R34] Protecting Immigrant Families · [R35] DHCS, Medi-Cal · HRSA, health centers.

---

## M1 U14. How do I turn what I learned into something I can actually do?

**What you will be able to do:** Build a 90-day plan with specific actions, dates and a backup if something changes.

**To start:** Rubén finished the module with lots of ideas: make a calendar, save, check his taxes. A week later he hadn't done anything. It wasn't lack of will: he hadn't turned them into steps. In this lesson you'll learn to make a plan you'll actually follow.

### The essentials (5 minutes)

#### A wish is not a plan

"I'm going to get organized" doesn't say how to start.

"On Saturday I'll write down my paychecks and payments for the next two weeks" does.

The difference is that the second sentence has an action, a date and something you can show.



#### A goal you can check

| Type | Description | What it means for you |
|---|---|---|
| Action | What exactly you're going to do. | "Write down my paychecks and payments." |
| Date | When you'll do it. | "On Saturday." |
| Evidence | What you can show when you're done. | "My two-week calendar." |

#### Three steps

1. **Choose one specific problem**, for example: "I'm short on money before rent."
2. **Write down one small action and a date.**
3. **Keep a sample** of what you did.



#### "I need to find out" counts too

Finding out is a valid action if it has a date.

For example: "On the 15th I'll call VITA to ask whether I qualify for CalEITC."



#### If something changes, adjust

If you lose work hours, the right action may be to ask for help or renegotiate a payment.

Don't keep an impossible savings amount just so the plan "looks good."

> **Key idea:** a plan that adjusts is a plan that works.



#### A case in one minute

Daniela wrote her 90-day plan with only three actions. Write down her payments every night. Set up envelopes for home, business and taxes. And make a VITA appointment in January.

After 30 days she checked her progress. She had done two actions, and the third wasn't due yet. Seeing her money in order gave her peace of mind. So she added a new action: set aside 10 dollars per order for her savings cushion.



#### Do it this week

1. Write three actions with dates for the next 90 days.
2. Set a reminder on your phone to review your plan in 30 days.
3. Tell someone you trust about your plan.



#### Share your plan

Telling a trusted person about your plan helps you follow it. It can be your partner, a friend or someone from the course.

Pick a date to review together how it's going. It isn't about someone watching you, but about having support.



#### Check your understanding

1. What does a goal you can check have?
*Answer:* Action, date and evidence.

2. Your income drops. Do you have to keep saving the same amount?
*Answer:* Not necessarily. Adjust the plan to your new reality.


#### Remember

- Every goal needs an action, a date and evidence.
- A few well-chosen priorities.
- Review and adjust your plan every 30 days.



### Go deeper (5 more minutes)

#### Put the module's pieces together

Your plan connects three tools:

- your money **calendar** (M1 U07);
- your **budget** with a plan B (M1 U08);
- your **tax folder** (M1 U10).

If the remittance is already on the calendar, don't add it again as an extra expense. If you set aside savings, say where you keep it and what it's for.



#### Your 90-day plan

| When | Action | Possible obstacle | Backup |
|---|---|---|---|
| This week | Write down paychecks and payments | I don't have time | 10 minutes every night |
| 30 days | Ask to change a payment date | They don't accept it | Set aside from each paycheck |
| 90 days | Review the whole plan | My income changed | Use the budget with 20% less |



#### Consistency check

Before you call your plan done, check:

- did you add gross and net pay from the same wages?
- did you count transfers between your accounts as income?
- do taxes and remittances have dates?
- did you assign the same savings to two things?
- does the plan depend on one-time income?



#### Measure your progress

When you started the course you took, or can take, the CFPB financial well-being questionnaire.

Take it again every 90 days. It isn't about having more money, but about feeling more in control and less stressed.

> **Good to know:** writing down a goal with a date and sharing it with someone you trust makes you more likely to reach it.



#### Celebrate your progress

Changing the way you handle money takes time. Every action you complete counts.

Write down in your plan what you've already done, even if it seems small: "I made my first calendar," "I canceled a subscription," "I went to VITA."

Seeing your progress encourages you to keep going. And if something didn't work, write that down too: it's information to adjust, not a failure.



#### If you need help

If your plan shows a shortfall you can't cover, don't try to solve it alone.

Look for county support programs, community organizations and no-cost financial counseling. The "Where to find help" chapter in the support materials has a list.



#### What's next

In Module 2 you'll learn to choose where to keep your money and to plan what you send to your family.

The calendar and budget from this module will help you decide how much you can send and when, without coming up short.



#### Cases


**Case 1. Alex and Mar's plan**

Their problem: they're short on money before rent.
- *What actions do they choose?* Week 1: write down dates and payments. Week 2: ask to change the car insurance date. Week 3: recalculate with the confirmed date or use another option.
- *What is their evidence?* The first calendar and the revised calendar.


**Case 2. "I want to save more"**

Daniela wants to save, but her household still has a deficit.
- *Where does she start?* She records the shortfall for 4 weeks, checks two support programs and takes care of one obligation. Her first goal is to stabilize.


**Case 3. Rubén's ideas**

Rubén has lots of ideas and no dates.
- *What does he do?* He chooses one: "on Sunday I'll make my 8-week calendar." He does it and then chooses the next one.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Writing goals without dates | They never start | Give each action a day |
| Choosing too many priorities | You get overwhelmed and give up | Start with three |
| Keeping an impossible savings amount | The plan breaks | Adjust to your real income |
| Not reviewing the plan | You follow a plan that no longer works | Review it every 30 days |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What does a goal you can check have? a) Only a wish · b) Action, date and evidence · c) A wish list for the year
2. Can "I need to find out" be an action? a) Yes, if it has a date · b) No · c) Only if someone else does it for you
3. If your income drops, do you have to keep saving the same amount? a) Yes · b) Yes, and stop paying other things · c) Not necessarily; adjust the plan
**Answers:** 1-b: that way you can check it. 2-a: finding out with a date is progress. 3-c: the plan adapts to your reality.



#### Put it into practice

Turn "I want to save more" into a doable action for a household that still has a deficit.
**Answer:** "For 4 weeks I'll record income and expenses, on the 15th I'll check two support programs and on the 30th I'll ask for a payment plan on one debt."



#### Your plan

Turn in your Module 1 file: your diagnosis, 8-week calendar, usual budget and budget with less income, tax checklist and three 90-day actions. What's evaluated is consistency and your ability to adjust, not how much money you have. Also solve integrated case E1 in the support materials.



### Learn more

- **Financial well-being questionnaire** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/financial-well-being/ — **What to look for:** answer the 10 questions and save your result to compare in 90 days.
- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "setting goals" tool, with space for action, date and steps.

### Key words

- *Goal you can check:* an action with a date and evidence.
- *Evidence:* a record that shows what you did.
- *Periodic expense:* a payment that repeats but isn't monthly.

### Sources

CFPB, Your Money, Your Goals · CFPB, financial well-being scale.

---


# Part 3. Module 2. Understand the financial system and plan your remittances

## M2 U01. Who takes care of my money and who provides the service?

**What you will be able to do:** Tell apart what each institution does (bank, credit union, insurer, money transmitter, app) and who is responsible if there's a problem.

**To start:** Rubén bought a prepaid card at a pharmacy, uses it with an app, and his money is held by a bank he has never seen. When a charge he didn't recognize showed up, he didn't know who to call. In this lesson you'll learn to identify who is responsible for each service you use.

### The essentials (5 minutes)

#### Behind one service there may be several companies

A store sells you a card, an app shows you the balance and a bank holds the money. They can be three different companies.

The logo you see isn't always the company that is responsible. The one that is responsible is called the **responsible company**, and its name appears in the contract or on the back of the card.



#### Who does what

| Type | Description | What it means for you |
|---|---|---|
| Bank | Holds deposits, processes payments and lends money. | Your balance is money the bank owes you. |
| Credit union | Like a bank, but owned by its members. | It asks you to become a member. |
| Money transmitter | Sends money to other people or countries. | It must be licensed in your state. |
| Fintech (app) | Provides services with technology; many use a partner bank. | Ask which bank holds your money. |
| Insurer | Covers risks defined in a policy. | Read what it covers and what it doesn't. |

#### Three steps to know who is responsible

1. **Identify what you need to do:** keep, pay, send, borrow or insure.
2. **Look for the legal name** of whoever is responsible for that service, in the contract or on the back of the card.
3. **Save their official contact**, taken from their website, not from an ad.



#### They all make money somehow

Institutions make money from fees, interest, a markup on the exchange rate, advertising or payments for recommending products.

A recommendation can be useful and have a business interest at the same time. Knowing that helps you compare calmly.

> **Key idea:** being registered with a regulator shows that a company exists and is authorized. It doesn't mean every offer it makes is good for you.



#### A case in one minute

Mar has a credit card from a department store. The logo is the store's, but the one lending her the money is a bank.

One month she was charged a late fee she didn't owe. At the store they told her they couldn't do anything.

Mar found the name of the card issuer on her statement, called the official number and asked for the correction in writing. It was fixed in a week.



#### Do it this week

1. Take out all your cards and open your money apps.
2. For each one, find the name of the responsible bank or company.
3. Save their official phone numbers on your phone.



#### Check your understanding

1. An unknown charge shows up on a card you bought at a pharmacy. Who do you call?
*Answer:* The issuing bank shown on the back of the card, at its official number.

2. Can you open an account at the Federal Reserve?
*Answer:* No. It's the central bank and doesn't serve individuals.


#### Remember

- The logo isn't always who is responsible: look for the legal name.
- Save the official contact for each service you use.
- Registration with a regulator is not a guarantee of a good offer.



### Go deeper (5 more minutes)

#### A map of the financial system

| Institution | What it does | Useful question |
|---|---|---|
| Central bank (Federal Reserve) | Public roles: stability and monetary policy. It doesn't open accounts for individuals. | It isn't where you dispute a charge. |
| Bank | Takes deposits, processes payments and lends. | Who owes me my balance? |
| Credit union | Like a bank, but owned by its members. | Can I become a member? |
| Insurer | Takes on risks defined in a policy. | What does it cover and what doesn't it? |
| Money transmitter | Sends money to other people or countries. | Who is responsible if it doesn't arrive? |
| Investment broker | Buys and sells investments for you. | Who holds what I bought? |
| Fintech | Uses technology to provide services, often with a partner bank. | Which bank holds my money? |



#### A card payment step by step

You authorize the payment. The store accepts it. A network, like Visa or Mastercard, processes it. A bank charges your account or lends you the money.

The network's logo on your card isn't who is responsible for your account. The issuing bank is.



#### Who supervises

Each institution is supervised according to what it does. In California, the **DFPI** supervises money transmitters, lenders and other financial companies. At the federal level, the **CFPB** protects consumers of financial products.

Always look for the exact legal name. A fake company can copy the name or logo of a real one.

> **Good to know:** you can file a no-cost complaint with the [CFPB](https://www.consumerfinance.gov/complaint/) against banks, money transmitters, payment apps and debt collectors. The company must answer, usually within 15 days.



#### How banks lend

When a bank lends, it creates a deposit in the account of the person receiving the loan.

Even so, it can't lend without limit: the capital it must hold, the risks and the rules restrict it. That's why they review you before lending.



#### Questions for any new service

Before you use a new financial service, ask:

1. Who is the responsible company and where is it registered?
2. How much does it cost in total, and how does the company make money?
3. What happens if something goes wrong, and where do I complain?
4. How do I cancel and get my money back?

If they can't answer clearly, it's a sign to look for another option.



#### Cases


**Case 1. The pharmacy card**

Rubén bought a prepaid card at a pharmacy. A charge he doesn't recognize shows up. At the pharmacy they tell him they can't help.
- *Who should he call?* The issuing bank shown on the back of the card, at the number printed there.
- *What should he keep?* The report number and the date of his call.


**Case 2. Alex's four needs**

Alex needs to keep the rent money, receive payments from clients, send money to Mexico and insure the pickup truck.
- *Does Alex need four institutions?* Not necessarily. For each need, write down the service, who is responsible, cost, access and how to complain.


**Case 3. Daniela's app**

Daniela receives payments for her cakes in an app. The app says it "works with banks."
- *What should she look for?* The name of the partner bank in the app's terms, and check it on FDIC BankFind.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Calling the store or app that isn't responsible | You lose time and the problem grows | Find the responsible company in the contract |
| Using the phone number from a message or ad | It may be a scam | Use the contact on the official website |
| Believing "registered" means "good for me" | You accept an expensive offer | Always compare with other options |
| Not keeping the report number | You can't prove you complained | Write down date, name and number |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can you open an account at the central bank? a) Yes · b) Yes, with an ITIN · c) No
2. Who should explain a policy's deductible? a) The central bank · b) The insurer · c) The money transmitter
3. A company is registered with a regulator. Does that guarantee its offer is good for you? a) No · b) Yes · c) Yes, if it has many customers
**Answers:** 1-c: it doesn't serve individuals. 2-b: the policy is theirs. 3-a: registration is not a guarantee.



#### Put it into practice

For each financial service you use, write: brand, responsible company, what it does and how you checked it.
**Answer:** For example: "Payment app X · partner bank Y · holds my money · I checked it on FDIC BankFind on September 28." A logo isn't enough.



#### Your plan

Build your map of services: what you use, who is responsible and their official contact.



### Learn more

- **Submit a complaint** (CFPB · English and Spanish): https://www.consumerfinance.gov/complaint/ — **What to look for:** the steps to complain about a bank, a payment app or a money transmitter, and what information to have ready.
- **Check that a bank is insured** (FDIC BankFind · English): https://banks.data.fdic.gov/bankfind-suite/ — **What to look for:** type the name of the bank on your card or app to confirm it exists and is insured.
- **California DFPI** (DFPI · English and Spanish): https://dfpi.ca.gov — **What to look for:** "Verify a license" to confirm whether a financial company is licensed in California.

### Key words

- *Responsible company:* the company responsible for the service according to the contract.
- *Central bank:* a public institution that doesn't handle personal accounts.
- *Fintech:* a company that uses technology to provide financial services.
- *Exchange rate markup:* the difference between a reference rate and the rate you're offered.

### Sources

[S06] Federal Reserve · CFPB, consumer complaints · DFPI, licenses.

---

## M2 U02. Is a money app always a bank?

**What you will be able to do:** Compare banks, credit unions and apps by who holds your money, what protection it has and how it fits your life.

**To start:** Daniela keeps her savings in an app that pays good interest. One day she read in the news that another app had shut down and its customers couldn't get their money out. She wondered if it could happen to her. In this lesson you'll learn to tell whether your money is protected.

### The essentials (5 minutes)

#### "Digital" doesn't mean "bank"

"Digital" describes how you use a service, not what license the company has.

A company can give you services through an app without being a bank. Another can be a credit union, owned by its members. And a traditional bank has an app too.



#### Deposit insurance

At a bank insured by the **FDIC**, your money is protected if the bank fails. The protection goes up to **250,000 dollars** per person, per bank and per type of account.

At credit unions, the equivalent protection comes from the **NCUA**.

That insurance does **not** protect you from scams or from the failure of an app that isn't a bank.



#### Is it insured?

| Type | Description | What it means for you |
|---|---|---|
| Deposits at an insured bank or credit union | Checking account, savings account, certificate of deposit. | Yes, up to the limit. |
| Investments | Stocks, funds, cryptocurrency, even if a bank sells them. | They aren't insured deposits. |
| Balance in an app | Depends on whether the app deposits your money at an insured bank in your name. | Ask and check. |

#### Three steps before you keep your money somewhere

1. **Look for the legal name** of the company and its partner bank.
2. **Check** that the bank is FDIC-insured or the credit union is NCUA-insured.
3. **Review how you deposit, withdraw and get help** if something goes wrong.



#### The lost phone test

Imagine you lost your phone and rent is due tomorrow. Can you get your money out?

If the app is your only way in, you need a plan B. It can be a physical card, a branch, a help line or a safe way to recover your account.

> **Key idea:** compare by how you use your money, not by the company's label.



#### A case in one minute

Rubén gets paid through payroll and pays for almost everything with his phone. He opened an account in an app because he didn't have to go to a branch.

He read the terms and found the name of the partner bank. He looked it up on BankFind: it was insured. He also asked for a physical card and wrote the help line down on paper.

Now he uses his app with peace of mind, knowing where his money is and what to do if he loses his phone.



#### Do it this week

1. Find the name of the bank that holds your money.
2. Check it on FDIC BankFind or NCUA.
3. Write down your bank's or app's help line on paper.



#### Check your understanding

1. You buy stocks in a bank's app. Are they FDIC-insured?
*Answer:* No. Investments aren't insured deposits, even if a bank sells them.

2. Does deposit insurance protect you if you're scammed?
*Answer:* No. It protects you if the insured bank fails.


#### Remember

- Check the bank that holds your money on FDIC BankFind or NCUA.
- Investments aren't insured like deposits.
- Have a plan B if you lose your phone.



### Go deeper (5 more minutes)

#### If you use an app

Ask three things:

1. Which bank is my money deposited in?
2. Who keeps the record of my balance?
3. Under what conditions does FDIC protection apply?

Look for the answers in the app's terms and check the bank on BankFind. If the app doesn't say which bank holds your money, that's a sign to be careful.

> **Good to know:** sometimes the company in the middle between the app and the bank fails. Then customers can take months to get their money back, even if the bank is insured. That's why it's wise not to keep all your money in one place.



#### Compare by what it does and how you access it

| Question | Why it matters |
|---|---|
| How do I get paid: cash, payroll, app? | It defines how you'll deposit. |
| Where do I deposit cash and what does it cost? | Many apps charge to deposit cash. |
| Do they offer help in Spanish? | Solving a problem in your language is part of the service. |
| What happens if I lose my phone? | A single way in can leave you without money. |
| Do they ask you to become a member? | At credit unions, the membership deposit can't always be spent. |



#### The "at no cost" account that turns out expensive

Account A charges 5 a month and includes cash deposits. Account B has no monthly fee, but each cash deposit costs 3 and you make 4 a month.
- Account B per year (12 × 3 × 4): **144**
- Account A per year (12 × 5): **60**
- The extra cost of the "no-fee" one: **84**
For someone who deposits cash often, the "at no cost" account is the most expensive.


#### The 250,000 limit

The limit is per person, per bank, per type of account. If you have two individual accounts at the same bank, they're added together.

Having accounts at different banks or with different ownership types can give you more protection. Almost nobody reaches that limit, but it's good to know.



#### What credit unions offer

Credit unions often have lower fees, loans with lower rates and more personal service.

Some in California specialize in immigrant communities and accept an ITIN, a passport or a consular ID. You'll find several in the program's comparison chart.

To become a member, you usually have to live, work or study in a certain area, or belong to a group. Ask about the requirements.



#### Cases


**Case 1. "We work with banks"**

An app tells Daniela that her money is protected because it "works with banks."
- *What does Daniela do?* She looks for the bank's name in the terms and checks it on BankFind.
- *What else does she ask?* Whether her money is held in her name at that bank and how she'd get it back if the app shuts down.


**Case 2. Rubén's phone**

Rubén lost his phone, and an app was his only way to reach his money.
- *What did he learn?* To ask for a physical card and to keep the app's help line written down on paper.


**Case 3. Mar's credit union**

A credit union asks Mar for 5 dollars to become a member.
- *Can she spend those 5?* Usually not: it's her membership share and it stays in the account while she's a member.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing every app is a bank | Your money may not be insured | Find and check the partner bank |
| Thinking investments are insured | You can lose money with no protection | Keep deposits and investments separate |
| Depending only on your phone | You're cut off from your money | Have a physical card and a help contact |
| Choosing the "at no cost" account without looking at your habits | You pay more in fees | Calculate the cost based on how you use your money |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does "digital" mean it's a bank? a) Yes · b) Yes, if it has a debit card · c) No
2. Is an investment bought at a bank FDIC-insured? a) Yes · b) No · c) Yes, up to 250,000
3. Does deposit insurance protect you from a scam? a) No · b) Yes · c) Yes, if you report it within 24 hours
**Answers:** 1-c: it describes access, not the license. 2-b: investments aren't deposits. 3-a: it only protects you if the bank fails.



#### Put it into practice

An app says "we work with banks." What four facts do you need to know whether your money is protected?
**Answer:** The name of the bank, that the bank is insured, how your account is recorded (in your name) and the terms of the agreement between the app and the bank.



#### Your plan

Check on BankFind or NCUA where your money is. Save the search and the date.



### Learn more

- **Check that a bank is insured** (FDIC BankFind · English): https://banks.data.fdic.gov/bankfind-suite/ — **What to look for:** type the bank's name and confirm it says "FDIC Insured."
- **Find an insured credit union** (NCUA · English): https://mapping.ncua.gov — **What to look for:** type the credit union's name or your ZIP code to see insured ones near you.
- **Deposit insurance and apps** (FDIC · English): https://www.fdic.gov/resources/deposit-insurance — **What to look for:** the section on apps and non-bank companies ("fintech") and what is and isn't insured.

### Key words

- *Deposit insurance:* protection for your money if the bank or credit union fails.
- *Credit union:* a financial institution owned by its members.
- *Neobank:* a brand name for digital services; check the bank behind it.
- *Partner bank:* the bank that holds the money of an app's customers.

### Sources

[S07] NCUA · [S08] FDIC, third-party apps · [S09] FDIC BankFind · [R02] FDIC, deposit insurance · [R03] NCUA, coverage.

---

## M2 U03. What ID works for financial paperwork?

**What you will be able to do:** Learn which documents banks, credit unions and money transmitters usually accept, and how to get the ones you're missing without risk.

**To start:** Rubén went to open an account with his passport and was told no. At another bank, with the same documents, they opened it in twenty minutes. It wasn't him: each institution accepts different documents. In this lesson you'll learn what to ask before you go.

### The essentials (5 minutes)

#### Why they ask for ID

Financial institutions are required by law to verify their customers' identity. It's to prevent fraud, not to judge you.

The law lets them accept, depending on their policy, a tax number (SSN or ITIN) or the number of a passport or another official ID.

That's why each bank asks for different things.



#### Common documents

| Type | Description | What it means for you |
|---|---|---|
| Passport | ID accepted almost everywhere. | Check that it's current. |
| Consular ID | ID from the Mexican consulate. Many institutions accept it. | Sometimes they ask for a second ID. |
| AB 60 license | California driver's license. | It doesn't work for federal purposes. |
| ITIN | Tax number. Some institutions accept it instead of an SSN. | It isn't a photo ID. |

#### Three steps before you go

1. **Make a list** of the documents you have and when they expire.
2. **Call and ask** which combination of documents that account accepts, at a branch or online.
3. **Write down the name** of the person who helped you, or ask for the answer in writing.



#### The exact question

"I want to open a checking account at a branch. I don't have an SSN; I have a passport and a consular ID. Which documents do you accept and how much do I need to open it?"

With this question you avoid extra trips and know what to expect.

> **Key idea:** if one bank says no, ask another. Credit unions and Bank On accounts often accept more combinations of documents.



#### A case in one minute

Daniela wanted to open an account with her Salvadoran passport and her AB 60 license. One bank told her she needed an SSN.

At a nearby credit union they explained they accepted her passport as her main ID and the license as a second ID. She opened her account with 25 dollars.

She learned that one bank's "no" isn't everyone's "no."



#### Do it this week

1. Make a list of your documents and their expiration dates.
2. Call one bank and one credit union with the exact question.
3. Write down what they told you and who you spoke with.



#### Check your understanding

1. Does the AB 60 license work as a REAL ID for federal purposes?
*Answer:* No. It works for driving and as ID in California, but not for federal purposes.

2. Where do you get a consular ID?
*Answer:* Only at the consulate, with an appointment through the official system.


#### Remember

- Each institution accepts different documents: ask first.
- Get documents only through official, no-cost channels.
- Don't send photos of your ID to strangers.



### Go deeper (5 more minutes)

#### Documents: what they're for and their limits

| Document | What it's for | Limits |
|---|---|---|
| Passport | ID accepted almost everywhere | Expiration date |
| Consular ID | ID from the Mexican consulate | Not everyone accepts it; sometimes they ask for another |
| AB 60 license | Driving and ID in California | It isn't a REAL ID |
| ITIN | Tax number in place of an SSN | Not a photo ID or a work permit |
| Proof of address | Utility bill or lease | It must be in your name or come with another document |



#### How to get documents without risk

- **Consular ID and Mexican passport:** only at the consulate, with an appointment through the official MiConsulado system.
- **AB 60 license:** at the California DMV, with an appointment on its official website.
- **ITIN:** with IRS Form W-7 (M1 U11).
- **Documents from El Salvador and other countries:** at your country's consulate, with an appointment on its official website.

Be wary of anyone who sells appointments or promises "faster" paperwork. Official appointments cost nothing.

> **Good to know:** the AB 60 license has a mark on the front that says "Federal Limits Apply." Even so, in California it works as ID for many things, and state law prohibits discriminating against people who use it.



#### If you're turned down

Ask for the reason.

It may be because of a report on your banking history, for example from **ChexSystems**. You have the right to know which company issued it and to ask for a copy at no cost. If there's a mistake, you can dispute it.



#### Protect your documents

Don't hand originals to anyone other than the official institution.

Don't send photos of your ID by message to strangers or post them on social media. With that information, accounts can be opened in your name.



#### Proof of address

Many institutions ask for proof of address. Electric, water or gas bills, a lease or a letter from your bank work.

If the utilities aren't in your name, ask what other options they accept. Sometimes a letter from the person you live with works, along with their bill. Official mail in your name may also work.



#### California law protects you

In California it's illegal for a business to discriminate against you because of your national origin or the language you speak.

If you feel you were denied a service for that reason, you can contact the California Civil Rights Department.



#### Cases


**Case 1. Rubén and the branch account**

Rubén has a passport and a consular ID, but no SSN or ITIN. He calls two banks and a credit union.
- *What does he find out?* One bank accepts his combination at a branch, the other requires an SSN, and the credit union accepts it if he becomes a member.


**Case 2. The appointment for sale**

Alex is offered a "fast" consulate appointment for 80 dollars.
- *What does Alex do?* Doesn't pay. Appointments cost nothing through the official system.


**Case 3. Daniela's ID**

Daniela's Salvadoran passport has expired.
- *What does she do before opening her account?* She makes an appointment at the Salvadoran consulate to renew it, and meanwhile asks which other combination of documents the bank accepts.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Going to the bank without asking first | You lose the day and get frustrated | Call first with the exact question |
| Paying for a consulate appointment | You lose money and sometimes your data | Get your appointment no-cost through the official system |
| Giving up after the first "no" | You're left without an account | Ask at another bank or credit union |
| Sending photos of your ID | Identity theft | Give it only to the official institution |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does the AB 60 license work as a REAL ID? a) Yes · b) Yes, for flying within the U.S. · c) No
2. Is the ITIN a photo ID? a) Yes · b) No · c) Yes, if you print it
3. Where do you get a consular ID? a) At the consulate, with an official appointment · b) At any store · c) Through a helper who sells appointments
**Answers:** 1-c: it doesn't work for federal purposes. 2-b: it's only a tax number. 3-a: only at the consulate.



#### Put it into practice

Write the exact question you'd ask a bank by phone before going to open an account without an SSN.
**Answer:** "I want to open a checking account at a branch. I don't have an SSN; I have a passport and a consular ID. Which documents do you accept and how much do I need to open it?"



#### Your plan

Put together your document kit: what you have, what's about to expire and what you still need to get.



### Learn more

- **AB 60 license** (California DMV · English and Spanish): https://www.dmv.ca.gov/portal/driver-licenses-identification-cards/assembly-bill-ab-60-driver-licenses/ — **What to look for:** the list of accepted documents to prove identity and residence, and how to make an appointment.
- **MiConsulado** (Mexico's Foreign Ministry · Spanish): https://citas.sre.gob.mx — **What to look for:** create your account and book a no-cost appointment for a consular ID or passport.
- **Checklist for opening a bank account** (CFPB · English): https://files.consumerfinance.gov/f/documents/cfpb_checklist_opening_bank_account_web.pdf — **What to look for:** the list of questions to ask the bank before you open the account.

### Key words

- *Consular ID:* an ID issued by the Mexican consulate (matrícula consular).
- *AB 60:* a California driver's license for people who can't prove legal presence.
- *REAL ID:* an ID valid for federal purposes.
- *ChexSystems:* a company that keeps records of bank account history.

### Sources

[R14] Financial institutions, ID requirements · [R42] California DMV, AB 60 · CFPB, checklist for opening an account.

---

## M2 U04. What do I need to open an account, and how much does it cost to keep it?

**What you will be able to do:** Compare accounts based on your needs, your documents and the way you use money.

**To start:** Alex opened an account that said "at no cost." A month later, a 12-dollar fee was charged. The account only cost nothing with direct deposit of wages, and Alex gets paid by check. In this lesson you'll learn to read the conditions before you open an account.

### The essentials (5 minutes)

#### Start with how you use your money

Before choosing an account, think about what you'll use it for: receiving your pay, depositing cash, paying bills, sending money or saving.

The best account for one person can be expensive for another.



#### Two amounts that get confused

| Type | Description | What it means for you |
|---|---|---|
| Opening deposit | The minimum to open the account, for example 25. | Only asked for once. |
| Balance to avoid the fee | What you must keep each month so they don't charge you, for example 500 every day. | It's a monthly condition. |

#### Alex's "at no cost" account

The account charges 12 a month, unless you get your pay by direct deposit. Alex gets paid by check.
- Fee per month: **12**
- The other 11 months: **132**
- What Alex pays per year for a "at no cost" account: **144**
**"Direct deposit"** usually means your payroll deposited electronically, not just any transfer.


#### Look for Bank On accounts

**Bank On** accounts are certified under a national standard: low cost, no overdraft fees and the basics to pay and receive money.

Ask your bank or credit union if they have a Bank On certified account.



#### Three questions when you open an account

1. **Which documents do you accept?**
2. **How much do I need to open it, and what does it cost each month?**
3. **What condition avoids the fee, and can I meet it with the way I get paid?**

> **Key idea:** the opening deposit and the monthly fee are different things. Meeting one doesn't remove the other.



#### A case in one minute

Rubén compares two accounts. The first has no monthly fee, but charges 3.50 for each cash deposit at stores. The second charges 5 a month, but cash deposits at its ATMs cost nothing.

Rubén deposits cash about 3 times a month. With the first he'd pay 10.50 a month; with the second, 5.

He chose the second, even though it "charges a fee," because for the way he uses money it's cheaper.



#### Do it this week

1. Write down how you get paid and how many times a month you deposit cash.
2. Find two accounts in the program's comparison chart.
3. Calculate how much each would cost you per year.



#### Check your understanding

1. An account costs nothing with direct deposit, but you get paid in cash. Is it no-cost for you?
*Answer:* Not necessarily. Ask which condition you can meet.

2. Are the opening deposit and the minimum balance the same thing?
*Answer:* No. One is to open; the other is a condition every month.


#### Remember

- Choose based on how you get paid and how you use your money.
- Ask what avoids the monthly fee and whether you can meet it.
- Look for Bank On certified accounts.



### Go deeper (5 more minutes)

#### Who owns the account

| Type | Who can use it | Keep in mind |
|---|---|---|
| Individual account | Only you | You decide everything |
| Joint account | Two or more owners | Any of them can withdraw everything |
| Authorized access | Someone uses it without being an owner | Ask what they can do |

Sharing your password isn't the same as giving formal authorization. Before adding someone, understand who can withdraw, close the account and receive notices.



#### If you deposit cash often

Besides the monthly fee, compare:

- where you can deposit cash and what it costs;
- which ATMs cost nothing;
- when the money you deposit becomes available;
- deposit limits.

Some apps charge 3 to 5 dollars for each cash deposit at stores. Some banks don't charge to deposit at the teller or at their ATMs.



#### An account for your business

A second account helps keep personal and business money apart, but it doesn't create a company or replace your records.

Using a personal account to receive business payments may be limited by the contract. Ask first.

> **Good to know:** according to the FDIC, a common reason people don't have a bank account is high or unpredictable fees. Bank On accounts were created to solve that.



#### Use the program's comparison chart

The program has a chart comparing more than 60 accounts, apps and services: monthly cost, accepted documents and cash deposits.

Each product shows the date it was checked. Always confirm the conditions on the official website before opening.



#### Accounts with no overdraft

Some accounts simply decline a payment if you don't have the balance, instead of covering it and charging an overdraft fee.

For many people that's better: they'd rather have a payment declined than pay a 35-dollar fee. Bank On accounts don't have overdraft.

Ask whether your account has overdraft and how to turn it off.



#### Cases


**Case 1. Alex's "at no cost" account**

Alex's account costs nothing with payroll direct deposit. Alex gets paid by check and deposits it at the teller.
- *How much does it cost?* 12 a month, 144 a year.
- *What can Alex do?* Ask the employer for direct deposit or switch to an account with no fee, like a Bank On certified one.


**Case 2. The joint account**

Mar's cousin asks her to add him to her account "to help him out."
- *What's the risk?* Her cousin could withdraw the whole balance.
- *What does Mar do?* She looks for another way to help without giving him access to her account.


**Case 3. Rubén's cash**

Rubén gets paid through payroll, but his roommates pay him their share of the rent in cash.
- *What does he compare?* Where he can deposit cash at no cost near his home and his work.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing "no fee" without reading the condition | You pay a fee every month | Ask what avoids the fee |
| Confusing the opening deposit with the minimum balance | You get charged even though you opened with what they asked | Ask about both amounts |
| Adding someone to your account to help them | They can take all your money | Help in another way |
| Not asking about cash deposits | You pay every time you deposit | Compare where it costs nothing |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Are the opening deposit and the minimum balance the same? a) Yes · b) Yes, both are paid every month · c) No
2. An account costs nothing with direct deposit and you get paid in cash. Can you assume it costs nothing? a) Yes · b) No · c) Yes, if you never overdraw
3. Does a joint account let the other person withdraw money? a) Yes · b) No · c) Only with your written permission each time
**Answers:** 1-c: one is to open and the other is monthly. 2-b: it depends on whether you meet the condition. 3-a: any owner can withdraw.



#### Put it into practice

You use cash every week. What should you compare besides the monthly fee?
**Answer:** Where and how much it costs to deposit cash, no-cost ATMs, when the money becomes available, distance, limits and help in your language.



#### Your plan

Fill in the comparison sheet for two accounts. You don't need to open one to pass.



### Learn more

- **Bank On certified accounts** (CFE Fund · English and Spanish): https://joinbankon.org — **What to look for:** "Find an account" and type your ZIP code to see certified accounts near you.
- **Checklist for opening a bank account** (CFPB · English): https://files.consumerfinance.gov/f/documents/cfpb_checklist_opening_bank_account_web.pdf — **What to look for:** the list of fees and conditions to ask about before you sign.
- **Newcomer's guides to managing money** (CFPB · English and Spanish): https://www.consumerfinance.gov/about-us/blog/the-newcomers-guides-to-managing-money/ — **What to look for:** the guide on choosing a bank account.

### Key words

- *Maintenance fee:* a monthly charge for having the account.
- *Checking account:* for frequent payments.
- *Savings account:* for keeping money.
- *Bank On:* a national standard for low-cost accounts.

### Sources

[R46] Bank On, national standards · FDIC, national survey of unbanked households · CFPB, newcomer's guides.

---

## M2 U05. Is all the balance I see available to spend?

**What you will be able to do:** Use your payment methods knowing when money is available and how to dispute a charge.

**To start:** Mar saw 100 dollars in her app and paid a 70 bill. The next day a payment she had scheduled went through and she ended up negative. The money was on the screen, but it already had a job. In this lesson you'll learn to read your balance for real.

### The essentials (5 minutes)

#### The money you see and the money that's available

Your screen shows 100, but you scheduled a 40 payment for tomorrow.
- What you see: **100**
- Scheduled payment: **40**
- What's actually available: **60**
The money you see and the money with no commitment can be different.


#### Three moments of a payment

A transaction can be **authorized** today, **posted** tomorrow, and the money **available** on another day.

A check you already see in your balance can be returned later. A scheduled transfer isn't done until it goes through.



#### Payment methods

| Type | Description | What it means for you |
|---|---|---|
| Debit card | Uses your money in the account. | If it's stolen, report it quickly. |
| Credit card | Uses a loan from the bank. | It creates debt and interest if you don't pay it all. |
| Person-to-person apps (Zelle, Venmo, Cash App) | Instant transfer. | Very hard to get back if you were tricked. |

#### Unauthorized and tricked are not the same

If someone uses your account or card **without your permission**, the law protects you if you report it quickly.

But if **you** send money by Zelle or an app to someone who tricked you, the rules are different. They don't require the bank to give it back.

> **Key idea:** treat instant payment apps as if they were cash. Only send to people you know and trust.



#### Do it this week

1. Check your available balance, not just the total.
2. Subtract scheduled payments that haven't been charged yet.
3. Turn on alerts for a low balance and for every transaction.



#### A case in one minute

Rubén saw a used phone at a good price on social media. The seller asked him to pay by Zelle before shipping it. Rubén paid 150 and the phone never arrived.

He called his bank. They told him that, because he had authorized the payment, they couldn't give the money back, although they would report it.

Since then, Rubén only uses Zelle with people he knows and pays strangers for purchases with a credit card, which does have protection.



#### Check your understanding

1. A check already shows in your balance. Is it guaranteed?
*Answer:* No. It can be returned days later.

2. You sent money by Zelle to someone who tricked you. Must the bank give it back?
*Answer:* Usually not, because you authorized the payment. That's why you check before sending.


#### Remember

- Subtract scheduled payments from what you see.
- Instant payment apps are like cash: check first.
- Report quickly any charge you didn't authorize.



### Go deeper (5 more minutes)

#### More payment methods

| Method | What it uses | Keep in mind |
|---|---|---|
| Prepaid card | Money you loaded | Check fees for reloading and withdrawing |
| ACH transfer | Network between banks | It can take one to three days |
| Wire transfer | Direct transfer | Fast and very hard to reverse |
| Check | Paper payment order | It can bounce days later |



#### What protects you if you didn't authorize a payment

With a debit card or bank account, reporting within 2 business days limits what you can lose to 50 dollars. If you take longer, you can lose more. With a credit card, the protection is usually greater.

If you get your statement and see unauthorized charges, report them within 60 days.

> **Good to know:** "tech support" or "your bank is calling" scams try to get you to authorize the payment yourself. Your bank will never ask you to send money by Zelle to "a safe account."



#### Reconciling your account

Reconciling means comparing your record with the bank's. Mark known, pending, duplicate and unknown charges.

If the account doesn't add up, look for the difference. It may be a fee, a duplicate charge or a payment you don't recognize.



#### The overpayment check scam

Someone deposits a check and asks you to send part of it back. The money shows as available, but days later the check bounces. You lose what you sent.

If someone asks you to return part of a deposit, call your bank at a number you look up yourself.



#### Switching accounts without problems

Make a list of your automatic deposits and payments. Move them to the new account. Wait for pending charges to go through. Then confirm the closing and the final balance in writing.



#### Protect your codes

Your bank will never ask you by phone or message for:

- your full password;
- the code you get by text;
- to move your money to "a safe account."

If someone asks for any of these, hang up and call the number on your card yourself.



#### Cases


**Case 1. The duplicate payment**

Alex doesn't see a payment show up and makes it again. The next day both appear.
- *What should Alex have done?* Check the payment's status and receipt before repeating it.
- *What now?* Call the company to ask for the duplicate payment back.


**Case 2. Mar's reconciliation**

Starting balance 100, deposit 500, payments of 320 and 60. She expected 220 and the statement shows 210.
- *What does she do?* She looks for the 10 difference: it's a fee for using another bank's ATM.


**Case 3. Rubén's "seller"**

Rubén paid 150 by Zelle for a used phone that never arrived.
- *Must the bank give him the money back?* Usually not, because he authorized the payment. He can report it to the bank and the FTC, but getting it back is hard.
- *What did he learn?* To pay strangers only with methods that have protection, like a credit card.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Spending what you see on the screen | A scheduled payment leaves you negative | Subtract what already has a job |
| Repeating a payment you don't see | You pay twice | Check the receipt first |
| Paying strangers by Zelle | You lose the money with no protection | Use a credit card for purchases |
| Taking too long to report an unauthorized charge | You lose more money | Report within 2 business days |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is a check you already see in your balance guaranteed? a) Yes · b) Yes, after 24 hours · c) No
2. Which is harder to get back? a) An unauthorized charge · b) A payment you authorized because you were tricked · c) Both are recovered the same if you report within 60 days
3. To cancel a subscription, is canceling the card enough? a) No · b) Yes · c) Yes, if you report it lost
**Answers:** 1-c: it can bounce. 2-b: you authorized it. 3-a: cancel with the company.



#### Put it into practice

Your record: start 300, deposit 500, purchases of 120 and 80, scheduled payment of 200. The bank shows 600. How much is available?
**Answer:** 400. The 200 scheduled payment already has a job, even if the bank hasn't taken it out yet.



#### Your plan

Set up useful alerts and a weekly check. Never share passwords or codes.



### Learn more

- **Ways to pay your bills** (CFPB · English): https://files.consumerfinance.gov/f/documents/cfpb_ways-to-pay-your-bills_2022-08.pdf — **What to look for:** the comparison of risks for each payment method, including apps.
- **Payment apps and scams** (FTC · English): https://consumer.ftc.gov — **What to look for:** type "payment apps" in the search box to see how to protect yourself when using Zelle, Venmo or Cash App.
- **Submit a complaint** (CFPB · English and Spanish): https://www.consumerfinance.gov/complaint/ — **What to look for:** how to complain if your bank doesn't resolve an unauthorized charge.

### Key words

- *Available balance:* what the bank lets you use today.
- *Reconcile:* compare your record with the bank's.
- *Dispute:* a request to review an incorrect charge.
- *ACH:* the network for electronic transfers between banks.

### Sources

CFPB, Regulation E (electronic transfers) · FTC, payment apps · CFPB, ways to pay your bills.

---

## M2 U06. How do I support my family without deciding at the last minute?

**What you will be able to do:** Identify the needs of the person receiving money and what you can keep up, so you can plan your remittances.

**To start:** Every month, Rubén's mom texts him asking for money, and every month Rubén decides at the last minute how much to send. Some months he sends too much and comes up short on rent. In this lesson you'll learn to plan what you send so the support can continue.

### The essentials (5 minutes)

#### Planning is caring

Sending money to your family in another country is sending a **remittance**.

Planning a remittance doesn't mean you love your family less. It means making sure the support can continue without you running out of the basics.



#### Two facts to plan

You need to know two things:

1. **What the person receiving needs:** how much, in what currency and by when.
2. **What you can keep up:** how much you have left after your bills, and on what date.



#### Four kinds of requests

| Type | Description | What it means for you |
|---|---|---|
| Regular | The month's food. | Fixed amount and date. |
| Foreseeable | The start of school, a celebration. | Set aside ahead of time. |
| Emergency | A hospital stay. | Verify and review options. |
| Project | Building a room. | A goal with a deadline (M2 U12). |

#### Think in the currency it's spent in

If the need is a 3,400-peso bill, the dollars you need change with the exchange rate and the fees.

Thinking in pesos, or the country's currency, helps you compare better and not come up short.



#### Three steps

1. **Ask** for the amount, the currency and the date of the need.
2. **Check** your upcoming payments on your calendar.
3. **Agree** on what you can confirm and what you can't yet.

> **Key idea:** separate what's regular from what's an emergency. Not everything urgent is an emergency.



#### A case in one minute

Every month, Rubén's mom texted him asking for a different amount. Rubén sent what he could at the moment, and sometimes he was short on rent.

They talked on a video call and agreed on 200 dollars on the 15th for food. His mom would let him know a month ahead if a school expense for his sister was coming.

Now Rubén has it on his calendar and his mom knows what she can count on each month.



#### Do it this week

1. Write down your family's requests from the last three months.
2. Sort them: regular, foreseeable, emergency or project.
3. Suggest an amount and a date for the regular one.



#### Check your understanding

1. Does planning a remittance mean loving your family less?
*Answer:* No. It's making sure the support can continue.

2. In what currency should you define a need that's paid in Mexico?
*Answer:* In pesos, because that's how it's spent.


#### Remember

- Ask for amount, currency and date.
- Sort: regular, foreseeable, emergency or project.
- Agree only to what you can keep up.



### Go deeper (5 more minutes)

#### Think about the person receiving

Think about how your family receives the money. What documents they have, and whether they have a bank account or a cell phone. How far the pickup point is, its hours and how safe the way there is.

An app you use easily can be hard for an older person.

> **Good to know:** in Mexico, many families can receive remittances directly in a bank account or in a Financiera para el Bienestar account. That way they don't have to carry cash on the street.



#### Ask without intruding

Ask how much actually arrives and what trouble they have picking it up.

Don't ask for passwords or full control of their money. Your family also has the right to decide.



#### Small sends or one big one

Sending 75 every week isn't the same as sending 300 once a month:

- you pay more fees with small sends;
- your family receives the money at different times;
- you may come up short between sends if you don't plan.

Compare the total monthly cost and what works for the person receiving.



#### Limits and independence

A lasting agreement accepts changes: your work can change, and there are emergencies on your side too.

If the conversation brings threats or pressure, put your safety first. You don't have to send what you don't have.



#### Prepare for foreseeable expenses

Foreseeable expenses, like the start of school, a celebration or a yearly payment, can be planned.

Ask your family what big expenses are coming this year and in what month. Divide the amount by the months left and set it aside little by little.

That way they don't turn into last-minute "emergencies."



#### When you can't help this month

Sometimes there isn't enough. Saying so early and with care is better than going silent.

For example: "This month my hours were cut. I can send 100 instead of 200. Next month I'll let you know how I'm doing."



#### If your family lives in a country other than Mexico

Rules and services change by country. In El Salvador, for example, the dollar is used and there's no exchange rate, but there are fees and charges to receive money.

Ask your family how they prefer to receive it and compare the services that reach their city. The World Bank comparison tool covers many countries.



#### Cases


**Case 1. Alex's mom**

She asks for 200 dollars every month for food, 120 at the start of her granddaughter's school year and, this month, 400 for a hospital stay.
- *How does Alex sort it?* Food: regular. School: foreseeable. Hospital: possible emergency.
- *What does Alex do before deciding?* Verify the hospital amount and the alternatives.


**Case 2. Rubén's messages**

Rubén's mom texts him every month with a different amount.
- *What changes?* They agree on a regular amount on the 15th and to give two weeks' notice if a foreseeable expense is coming.


**Case 3. Daniela's sister**

Daniela sends money to her sister in San Salvador for her niece's school.
- *In what currency does she plan?* In dollars, because El Salvador uses the dollar. Even so, she compares fees and how long it takes to arrive.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Deciding how much to send at the last minute | You come up short on your own bills | Agree on an amount and a date |
| Treating everything as an emergency | You send too much every month | Sort each request |
| Thinking about the need in dollars | You come up short because of the exchange rate | Ask for the amount in the local currency |
| Asking for your relative's password | You undermine their independence and security | Ask without intruding |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does planning a remittance mean loving your family less? a) Yes · b) Yes, if you send less than before · c) No
2. In what currency should you define a need that's paid in Mexico? a) Dollars · b) Pesos · c) The currency of the country where you live
3. Is it wise to ask for your relative's bank password to help them? a) No · b) Yes · c) Yes, if it's your mom
**Answers:** 1-c: it's making sure it continues. 2-b: it's the currency it's spent in. 3-a: it undermines their independence and security.



#### Put it into practice

Your family asks for 200 a month for food, 120 at the start of school and 400 for a hospital stay. Sort them and say what information is missing.
**Answer:** Food, regular; school, foreseeable; hospital, possible emergency. You still need to verify the amount, the urgency and the alternatives, and check your own capacity.



#### Your plan

Make a map of your sends: person, purpose, frequency and range. You can use made-up names.



### Learn more

- **Your rights when sending remittances** (CFPB · English and Spanish): https://www.consumerfinance.gov/ask-cfpb/what-is-a-remittance-transfer-and-what-are-my-rights-en-1161/ — **What to look for:** what information they must give you before you pay and on the receipt.
- **Remittances** (CONDUSEF · Spanish): https://www.condusef.gob.mx/?p=remesas — **What to look for:** the remittance comparison tool (Remesamex) and tips for people receiving money in Mexico.

### Key words

- *Remittance:* money sent to another person or country.
- *Exchange rate:* the price of one currency in another.
- *Priorities:* what you take care of first.

### Sources

CFPB, remittances · CONDUSEF, remittances · Financiera para el Bienestar.

---

## M2 U07. How much can I send, and when?

**What you will be able to do:** Calculate how much you can send by date, without neglecting your obligations.

**To start:** Mar wanted to send 200 dollars to her mother-in-law. After paying for the month, she only had 120 left. She sent the 200 and came up short on food. In this lesson you'll learn to calculate how much you can send without coming up short.

### The essentials (5 minutes)

#### Your sending capacity

You have 100. You need 60 for bills and food before your next paycheck. Sending costs 5.
- What you have today: **100**
- Commitments + sending cost: **65**
- What you can send today: **35**
Your **sending capacity** is what you can send without leaving your commitments uncovered, including the cost of sending.


#### Calculate by payday

Don't calculate with what's "left over" after shopping. Calculate with what you have today and what you need until your next paycheck.

When you get paid again, do the math again. Don't count today money that arrives later.



#### The formula

1. **Money available today.**
2. Minus what you need **until your next paycheck**: food, transportation.
3. Minus the **bills due** before payday.
4. Minus the **savings** you agreed to and a small cushion.
5. What's left is your sending capacity.



#### If it comes out negative

If the result is negative, don't turn it into zero: you have a shortfall.

You have several options. Send part now and part later, or change the date. Ask another relative to chip in. Pay a verifiable bill directly or look for local help.



#### If your income changes, agree on a range

If your income varies, agree on a **range**, for example between 150 and 180, instead of a fixed amount.

Let them know before the date if you can't that month. That way you avoid going into debt to keep your word.

> **Key idea:** speak up before, not after. "My usual support is between 150 and 180. If my hours are cut, I'll let you know before the date."



#### A case in one minute

Daniela gets paid every week, but her sister needs the money at the end of the month.

Instead of sending it all at once and coming up short, she sets aside 40 dollars from each weekly paycheck in a digital envelope. At the end of the month she has 160 ready to send, without affecting her rent or her son's food.



#### Do it this week

1. Write down today's balance and the date of your next paycheck.
2. Subtract what you need until that date.
3. Calculate your sending capacity with the formula.



#### Check your understanding

1. Is the cost of sending subtracted from your capacity?
*Answer:* Yes. It's also money coming out of your pocket.

2. Your capacity comes out negative. What do you do?
*Answer:* You recognize the shortfall and look for options: send less, change the date or ask another relative for help.


#### Remember

- Calculate by payday, not with what's left over.
- Also subtract the cost of sending.
- If your income varies, agree on a range.



### Go deeper (5 more minutes)

#### An example with two dates

| Step | Calculation | Result |
|---|---|---|
| Today you have | | 700 |
| Tomorrow you pay | − 450 | 250 |
| You need until your next paycheck | − 160 | 90 |
| Cost of sending | − 5 | 85 |
| Safety cushion | − 20 | 65 |
| **You can send today** | | **65** |

Promising 100 would take 35 more. When you get paid on Friday, calculate again.



#### Don't subtract twice

If you already set aside savings in another account, don't subtract it again from your balance.

If the remittance is already on your calendar for the month, don't count it again as an extra expense.



#### Income that changes

Don't make a permanent commitment based on a bonus or an unusual month.

Agree on what information will lead you to review the amount: for example, if your hours are cut or your rent changes.

> **Good to know:** if you're paid every two weeks, some months have three paychecks. They're good for sending ahead a foreseeable expense, like the start of school. Not for raising your regular amount.



#### If several siblings help

When several siblings send money to their parents, it helps to agree on how much each one puts in and on what date.

That way nobody carries it all alone and the parents know what they can count on each month.



#### An envelope for sending

If you send money every month, open a digital envelope or a separate account just for sending.

Move part of each paycheck into that envelope. When the sending date arrives, the money is already there and you don't have to decide in a hurry.

If there's some left one month, keep it for the next one or for a foreseeable family expense.



#### When the emergency is yours

Your own emergency counts too. If you lose work hours or have a medical expense, it's okay to send less that month.

Let them know in time and go back to the usual amount when you recover.



#### Your sending calendar

Add your sends to your Module 1 money calendar, with their date and amount.

That way you can see at a glance if rent and a transfer fall in the same week. You can move one of them before it becomes a problem.

Review the calendar each time your work hours or your family's needs change.



#### Cases


**Case 1. Rent and the send**

Alex gets paid three days after paying rent. The month ends positive, but if Alex sends money before rent, that day comes up short.
- *What does Alex decide?* To send after payday.


**Case 2. Mar's 120**

Mar has 900. She needs 650 until her next paycheck, 80 for her tax savings and 50 for the savings she agreed on.
- *How much can she send?* 120. If she sends 200, she creates an 80 shortfall.
- *What can she do?* Send 120 now and the rest when she gets paid again, letting her mother-in-law know.


**Case 3. Rubén's brothers**

Rubén and his brother, who lives in Texas, support their mom in Oaxaca.
- *What do they agree on?* Rubén sends on the 15th and his brother on the 30th. That way their mom receives money twice a month and neither of them is squeezed.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Sending what's "left over" without calculating | You come up short on your bills | Calculate by payday |
| Forgetting the cost of sending | You come up short | Subtract it from your capacity |
| Promising a fixed amount with changing income | You go into debt to keep your word | Agree on a range |
| Letting them know after you didn't send | Your family worries and trust suffers | Let them know before the date |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is the cost of sending subtracted from your capacity? a) No · b) Only if you pay by card · c) Yes
2. If your capacity comes out negative, what do you do? a) Write zero · b) Show the shortfall and look for options · c) Borrow to send the usual amount
3. Is it wise to promise a fixed amount if your income varies? a) Better a range · b) Yes · c) Yes, that way your family can plan better
**Answers:** 1-c: it also comes out of your pocket. 2-b: the shortfall is information. 3-a: a range protects you.



#### Put it into practice

If your next paycheck arrives three days after rent, is it enough for the month to end positive?
**Answer:** No. There has to be money on rent day. Set it aside earlier or review the dates.



#### Your plan

Write down your usual range, your sending dates and what will make you review the agreement.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the bill calendar tool; add your sends as one more line.
- **Your rights when sending remittances** (CFPB · English and Spanish): https://www.consumerfinance.gov/ask-cfpb/what-is-a-remittance-transfer-and-what-are-my-rights-en-1161/ — **What to look for:** what total cost they must show you before you pay.

### Key words

- *Sending capacity:* what you can send without neglecting your commitments.
- *Range:* the agreed minimum and maximum amount.
- *Cushion:* extra money you leave in case something changes.

### Sources

CFPB, remittances · CFPB, Your Money, Your Goals.

---

## M2 U08. Does "no fee" always mean more money arrives?

**What you will be able to do:** Compare transfers by what comes out of your pocket and what reaches your family.

**To start:** Rubén switched money transmitters because the new one said "no fee." A month later, his mom told him fewer pesos were arriving. They didn't charge him a fee, but they gave him a worse exchange rate. In this lesson you'll learn to really compare transfers.

### The essentials (5 minutes)

#### Two services, two results

Two services can turn the same dollars into different amounts of pesos.

A "no fee" service can deliver fewer pesos if its **exchange rate** is worse. The difference between the reference exchange rate and the one you're given is called the **exchange rate markup**.



#### Same budget, different result

You have 300 dollars in total.

| | Fee | Dollars converted | Exchange rate | Arrives |
|---|---|---|---|---|
| A | 5 | 295 | 17.00 | 5,015 pesos |
| B | 0 | 300 | 16.60 | 4,980 pesos |

A delivers 35 more pesos, even though it charges a fee.



#### Three steps to compare

1. **Use the same base:** the same total budget or the same amount to be received.
2. **Subtract** fees, payment method charges and taxes.
3. **Compare** how much arrives and how long it takes.



#### The 1% tax on cash remittances

Since January 2026 there has been a federal **1%** tax on certain remittances paid with **cash, a money order or a cashier's check**.

Paying from your bank account or with a debit card usually doesn't carry this tax. It doesn't depend on your nationality.

> **Key idea:** if you pay for your transfers in cash at a store, compare with paying from an account. You save the 1% and, often, fees.



#### A case in one minute

Mar compares three money transmitters on the same day to send 300 dollars to her mother-in-law.

The first charges 5 and gives 17.00 pesos per dollar. The second charges no fee and gives 16.60. The third charges 2 and gives 16.90.

She does the math and the first delivers the most pesos. Now she compares this way every month, in five minutes.



#### Do it this week

1. Ask for three quotes on the same day, for the same amount.
2. Write down how many pesos arrive with each one.
3. Check whether you pay in cash or from an account.



#### Check your understanding

1. Does "no fee" guarantee more money arrives?
*Answer:* No. The exchange rate may be worse and less may arrive.

2. You send 300 paying in cash. How much is the tax?
*Answer:* 3 dollars, 1% of 300.


#### Remember

- Compare how much arrives, not only the fee.
- Always use the same base to compare.
- Paying from an account avoids the 1% cash tax.



### Go deeper (5 more minutes)

#### What to write down for each quote

- Fee.
- Exchange rate.
- Payment method charges, for example paying with a credit card.
- Charges for receiving.
- Any tax that applies.
- Delivery time.
- Transportation cost for the person receiving.



#### If your family needs a fixed amount

Your family needs 4,000 pesos. A service with an exchange rate of 16.5 and a 10 fee.
- Dollars for 4,000 pesos (4,000 ÷ 16.5): **242.42**
- Fee: **10**
- What it costs you: **252.42**
With an exchange rate of 16 and a 6 fee it costs 256. If your family is charged 50 pesos to pick it up, calculate with 4,050.


#### The exchange rate markup with numbers

Compare the rate offered with a reference from the same moment, for example Google's or your bank's.

If the reference is 17 and you're offered 16.5, you lose 0.5 pesos per dollar. On 200 dollars that's 100 pesos.

The reference is for comparing. You'll almost never be able to exchange at exactly that rate.



#### Sending directly to an account in Mexico

Open a debit account with no fees here. From it, send directly to your family's bank account in Mexico or to their Financiera para el Bienestar account. That way:

- you avoid the 1% cash tax;
- you often pay a lower fee;
- your family receives the pesos in their account and doesn't have to carry cash on the street.

> **Good to know:** CONDUSEF publishes a weekly comparison of remittances from the U.S. to Mexico, with the cost and exchange rate of several companies.



#### Promotions

The price of the first transfer doesn't describe the usual cost. Compare with the price of the transfers that follow.



#### Speed versus cost

Transfers that arrive in minutes usually cost more than those that take one or two days.

If it's not an emergency, choosing the slower option can give you more pesos. If it is an emergency, pay for speed, but compare anyway.



#### Apps for sending and how to pay

Many money transmitters have an app. Paying in the app from your debit account is usually cheaper than paying cash at a store.

Paying with a credit card can count as a cash advance, with a fee and interest from day one. Ask first.

Save on your phone a screenshot of each quote and each receipt.



#### Cases


**Case 1. Rubén's promotion**

Rubén is offered "first transfer with no fee and a better exchange rate." The second month, the same app delivers fewer pesos than his previous option.
- *What does he do?* He compares three quotes from the same day with the same base.


**Case 2. Alex's cash**

Alex always pays for transfers in cash at the store.
- *How much does Alex save by paying from an account?* On 300 dollars, 3 in tax. And maybe also the fee for paying in cash.


**Case 3. Daniela's dollar**

Daniela sends money to El Salvador, which uses the dollar.
- *Is there an exchange rate?* No, but there are fees and charges to receive. She compares how much arrives and how long it takes.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Choosing by "no fee" | Less money arrives | Compare how much arrives |
| Comparing with different bases | You choose badly | Use the same budget or the same amount to be received |
| Always paying in cash | You pay the 1% tax | Pay from an account |
| Judging by the first-transfer promotion | You pay more later | Compare the usual price |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does "no fee" guarantee more money arrives? a) Yes · b) Yes, if it's also the first transfer · c) No
2. Does the 1% tax apply to all remittances? a) Yes · b) No, to certain remittances paid with cash or physical instruments · c) Only to remittances sent by app to another country
3. To compare, what has to be the same? a) The base: same budget or same amount to be received · b) Nothing · c) Only the fee; the exchange rate doesn't matter
**Answers:** 1-c: the exchange rate also counts. 2-b: only those paid in cash or similar. 3-a: otherwise they can't be compared.



#### Put it into practice

A transfer subject to the 1% tax is 300 dollars and the fee is 5, charged separately. How much comes out of your pocket?
**Answer:** 300 + 3 + 5 = 308. If your total budget were 300, you'd have to recalculate the amount to send.



#### Your plan

Compare three quotes from the same day with the same base and the same delivery time.



### Learn more

- **Remittances: compare transfers (Remesamex)** (CONDUSEF · Spanish): https://www.condusef.gob.mx/?p=remesas — **What to look for:** the weekly table of cost and exchange rate by company, from your city.
- **Remittance Prices Worldwide** (World Bank · English): https://remittanceprices.worldbank.org — **What to look for:** choose "United States" to "Mexico" or "El Salvador" to compare the total cost of sending 200 dollars.
- **Remittance tax** (IRS · English): https://www.irs.gov — **What to look for:** search for "remittance transfer excise tax" to read which transfers the 1% applies to.

### Key words

- *Exchange rate:* the pesos you get for each dollar.
- *Exchange rate markup:* the difference between the reference rate and the rate offered.
- *Quote:* the conditions offered for a given moment and amount.

### Sources

[R04] IRS, remittance tax · [R49] CONDUSEF, Remesamex · [R50] World Bank, remittance prices.

---

## M2 U09. What do I check before sending, and what do I do if something goes wrong?

**What you will be able to do:** Verify the money transmitter, know your rights and know what to do if there's a problem.

**To start:** Alex's receipt said the money would arrive on Monday. On Tuesday, Alex's mom was still waiting. Alex didn't know whether to send it again or wait. In this lesson you'll learn what to check before sending and how to complain if something goes wrong.

### The essentials (5 minutes)

#### Your receipt is your proof

The **remittance receipt** shows the transaction you made. It has the amount, date, company and a tracking number, often called the **confirmation number**.

Always keep it. Without a receipt it's much harder to complain.



#### Before you pay, check

1. **The recipient's exact name**, the same as on their ID.
2. **The amount they will receive** and in what currency.
3. **The delivery date** and where it's picked up.
4. **That the company is licensed** in California.



#### Your rights on international transfers

| Type | Description | What it means for you |
|---|---|---|
| Information before you pay | Total cost, exchange rate and amount that arrives. | They must show it to you in writing. |
| Cancel within 30 minutes | In general you can cancel at no cost if the money hasn't been picked up. | Act fast. |
| 180 days to report errors | From the promised delivery date. | Don't wait until the last day. |

#### Check the license

In California, companies that send money must be licensed by the **DFPI**.

You can look them up in the DFPI directory or on NMLS Consumer Access. A company without a license is a red flag, even if it offers a good exchange rate.

> **Key idea:** canceling, fixing an error and reporting fraud are different requests. Say clearly what you're asking for.



#### A case in one minute

Rubén sent money to his mom and, five minutes later, realized he had typed the wrong amount.

Since 30 minutes hadn't passed and his mom hadn't picked it up, he called the money transmitter and canceled the transfer at no cost. He sent it again with the right amount.

He kept both receipts in case of any question.



#### Do it this week

1. Look up the money transmitter you use in the DFPI directory.
2. Save a screenshot with the date.
3. Create a folder on your phone for your transfer receipts.



#### Check your understanding

1. In general, how much time do you have to cancel at no cost?
*Answer:* 30 minutes after paying, if the money hasn't been picked up.

2. You have 180 days to report an error. Is it wise to wait?
*Answer:* No. Act quickly; it's easier to solve that way.


#### Remember

- Check name, amount and date before you pay.
- Verify the money transmitter's license.
- Keep your receipt and complain quickly.



### Go deeper (5 more minutes)

#### What to confirm before you pay

Confirm the recipient's exact name, the country, the currency and the amount they'll receive. Also the total cost, the availability date and where and how it's picked up. Ask what ID the recipient needs and what happens if the name doesn't match.

A name with one different letter can keep your family from picking up the money.



#### Your record if something goes wrong

| Item | Example |
|---|---|
| Date and time of the transfer | March 12, 6:15 p.m. |
| Company | The company's legal name |
| Confirmation number | The receipt number |
| Amount sent and to be received | 300 dollars · 5,100 pesos |
| Promised date | March 13 |
| What happened | It isn't available to pick up |
| What you're asking for | Delivery or refund |
| Contact and answer | Who you spoke with and what they told you |



#### If they don't solve it

Contact the company through its official website or phone number and keep the answer.

If it isn't solved, file a complaint with the **CFPB** or the **DFPI**. Both cost nothing and you can do them in Spanish.

> **Good to know:** federal rules cover most international transfers that individuals make. There are exceptions, for example some scheduled transfers. If in doubt, ask the company or the CFPB.



#### Watch out for the second scam

If someone promises to "recover your transfer" in exchange for another urgent payment, it's very likely a scam.

Don't send a second remittance without understanding what happened to the first one.



#### What your receipt must say

By law, the receipt for an international transfer must show:

- the date the money will be available;
- the amount sent, the fees and the taxes;
- the exchange rate;
- the amount your family will receive;
- your rights to cancel and complain, and who to contact.

If something is missing, ask for it before you leave.



#### If the person receiving has trouble picking it up

Ask your family to let you know as soon as they try to pick it up.

If they're told the name doesn't match or some information is missing, don't send another transfer. Call the money transmitter with the confirmation number and ask them to correct it.

If your family picks up at a branch, they should bring a current official ID and the confirmation number.



#### Cases


**Case 1. The money that doesn't arrive**

Alex's receipt says the money would be available on Monday. On Tuesday it isn't there.
- *What does Alex do?* Checks the status with the confirmation number, confirms the recipient's information and calls the company.
- *What doesn't Alex do?* Send a second remittance without understanding what happened to the first one.


**Case 2. The money transmitter at the market**

A shop offers Rubén an excellent exchange rate. Rubén looks up the name in the DFPI directory and it isn't there.
- *What does he decide?* Not to use it. Without a license, he has nowhere to complain if something goes wrong.


**Case 3. The sister's name**

Daniela wrote her sister's last name with a different letter. Her sister couldn't pick up the money.
- *What does she do?* She calls the money transmitter with the confirmation number and asks them to correct the name. It's an error she has the right to report.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not checking the recipient's name | Your family can't pick it up | Copy it exactly as it appears on their ID |
| Using an unlicensed money transmitter | You have nowhere to complain | Check with the DFPI or NMLS |
| Throwing away the receipt | You can't prove your transfer | Keep it or take a photo of it |
| Paying someone who promises to "recover" your transfer | You lose more money | Complain only to the company and the CFPB |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Where do you check a money transmitter's license in California? a) In its ad · b) In social media reviews · c) DFPI or NMLS
2. In general, how much time do you have to cancel at no cost? a) 30 days · b) 30 minutes · c) 7 days
3. Does "you have 180 days" mean it's wise to wait? a) No · b) Yes · c) Yes, so the company notices on its own
**Answers:** 1-c: they're the official records. 2-b: if the money hasn't been picked up. 3-a: act quickly.



#### Put it into practice

Write your incident record for a transfer that didn't arrive on the promised date.
**Answer:** Date and time of the transfer, company, confirmation number, amount sent and to be received, promised date, what happened, what you're asking for (delivery or refund), who you contacted and what they answered.



#### Your plan

Create your remittance tracking sheet: company, license verified, confirmation number, date, problem, request and answer.



### Learn more

- **Directory of licensed money transmitters** (DFPI · English): https://dfpi.ca.gov/regulated-industries/money-transmitters/directory-of-money-transmitters/ — **What to look for:** the company's exact name in the list of authorized money transmitters.
- **NMLS Consumer Access** (NMLS · English): https://www.nmlsconsumeraccess.org — **What to look for:** type the company's name and check that it's licensed in California ("CA").
- **Your rights on remittances** (CFPB · English and Spanish): https://www.consumerfinance.gov/ask-cfpb/what-is-a-remittance-transfer-and-what-are-my-rights-en-1161/ — **What to look for:** the deadlines to cancel and to report errors.

### Key words

- *Remittance receipt:* proof with the details of the transfer.
- *Confirmation number:* the tracking number.
- *DFPI:* California's financial regulator.
- *NMLS:* the national registry of financial company licenses.

### Sources

[S17] CFPB, remittance rights · [R40] DFPI, license directory · [R41] NMLS Consumer Access.

---

## M2 U10. What happens when I borrow to send money?

**What you will be able to do:** Calculate the effect of going into debt to send money.

**To start:** Alex's mom had an emergency and Alex didn't have all the money. An app offered a quick loan "to help your family." It solved things that day, but two weeks later there wasn't enough to pay it back. In this lesson you'll learn to see the real cost of borrowing to send money.

### The essentials (5 minutes)

#### Today's help is tomorrow's payment

You borrow 100 to help your family and have to pay back 120.
- What you pay back: **120**
- What you received: **100**
- What the loan cost you: **20**
That cost is added to the cost of sending. Today's help turns into a future payment.


#### Before you accept, write down

1. The 100 as **borrowed money**, not earned money.
2. The **repayment** of 120 and its date.
3. **Where** those 120 will come from on your calendar.



#### The risk of "rolling over"

If you don't have it all on the due date, some companies offer to "roll over" the loan if you pay only the fee.

That way you still owe the same and you've already spent money on the fee. If you repeat it, you pay and pay without getting out of debt.



#### These are debt too

| Type | Description | What it means for you |
|---|---|---|
| Pay advance through an app | Even if they ask for a "voluntary tip." | It comes out of your next paycheck. |
| Credit card cash advance | Paying for a transfer with a credit card can count as a cash advance. | It charges interest from day one. |
| A loan from someone you know | Even if it has no interest. | It's a debt with a date. |

#### Alternatives before going into debt

- Send part now and the rest when you get paid.
- Ask your family to find out whether they can pay later.
- Ask another relative to chip in.
- Look for a local assistance program, there or here.

> **Key idea:** verify each alternative. None of them should be made up, but there's almost always an option before borrowing.



#### A case in one minute

Daniela's sister needed 400 dollars for medicine. Daniela only had 250 left over.

Instead of taking a quick loan, she sent 250 that day. She suggested her sister ask the pharmacy whether she could pay the rest the next week. The pharmacy agreed.

The next week, Daniela sent the 150 that was missing, without owing anyone anything.



#### Do it this week

1. Write three options for an emergency before borrowing.
2. Ask your bank whether your credit card transfers count as cash advances.
3. Check whether you use pay advances and how much they cost you each month.



#### Check your understanding

1. Is money someone lent you income?
*Answer:* No. It's money you have to pay back.

2. If you "roll over" by paying only the fee, does your debt go down?
*Answer:* No. You still owe the same and you've already paid a fee.


#### Remember

- Borrowing to send money turns today's help into a future payment.
- Check where the payment will come from before you accept.
- Look for alternatives before going into debt.



### Go deeper (5 more minutes)

#### Ask before you accept

Ask in writing for: the payment schedule, the upfront fees, how much you'll really receive and how much you'll pay back in total.

If you use a credit card, ask whether the transfer is treated as a purchase or as a cash advance. The advance usually costs more and charges interest from day one.



#### How debt grows when you roll over

You owe 240 plus a 30 fee in two weeks, but you'll only have 100 left over.

| When | You pay | You still owe | Fees paid so far |
|---|---|---|---|
| Week 2 | 30 (fee only) | 240 | 30 |
| Week 4 | 30 | 240 | 60 |
| Week 6 | 30 | 240 | 90 |

In six weeks you paid 90 and you still owe 240.



#### Pay advances through apps

Many apps advertise "no interest" advances, but they charge a fee for instant delivery or suggest a "tip."

A 5 tip to get 100 a week early works out to a very high yearly cost. Use them only for a real emergency.

> **Good to know:** in California, the DFPI supervises several earned wage access companies. If you have a problem with one, you can file a complaint on its website.



#### Talking with your family about your limits

Saying "I can't send it all today" isn't a lack of love. It's making sure you can keep helping.

Explain what you can do and when. Often your family would rather receive less on time than know you went into debt.



#### A fund for family emergencies

If your family's emergencies keep happening, it helps to have a small fund just for that.

Even at 10 dollars a week, in six months you'll have 260. With that you can cover an emergency without borrowing.



#### If you already have the debt

If you already borrowed and can't make the payment, don't wait for the due date. Talk to the lender beforehand and ask about a payment plan.

If the lender threatens you or collects in an abusive way, you can complain to the DFPI or the CFPB.



#### Cases


**Case 1. The emergency of Alex's mom**

Alex has 180 left over and needs to send 300. A loan would cover the missing 120, with an 18 fee, to be paid in 14 days: 138. On that date Alex will only have 100 left over.
- *What's the problem?* Alex will be 38 short to pay the loan.
- *What should Alex check before accepting?* A partial transfer, or whether a brother can chip in the difference.


**Case 2. Mar's advance**

Mar uses an app that advances her pay for a "voluntary tip" of 5 each time. She does it every week.
- *How much does it cost her?* 20 a month to get her own money early.


**Case 3. Rubén's card**

Rubén paid for a transfer with his credit card.
- *What should he check?* Whether the bank charged it as a cash advance, with a fee and interest from day one.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Counting the loan as income | You commit to expenses you can't cover | Write it down as a debt with a date |
| Rolling over by paying only the fee | The debt doesn't go down | Look for a plan to pay the total |
| Paying for transfers with a credit card without asking | It's charged as a cash advance | Ask first or use debit |
| Using app advances every week | Each paycheck arrives shorter | Use them only in emergencies |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is borrowed money earned income? a) Yes · b) Yes, if it's from a relative · c) No
2. If you "roll over" by paying only the fee, do you reduce what you owe? a) Yes · b) No · c) Yes, a little each time
3. Is a pay advance through an app a debt? a) Yes · b) No · c) No, because it's your own money
**Answers:** 1-c: you have to pay it back. 2-b: you still owe the same. 3-a: it comes out of your next paycheck.



#### Put it into practice

You borrow 300 and must pay back 345 in 30 days; you also pay 5 for the transfer. After your basic expenses you'll only have 250 on the due date. What problem shows up?
**Answer:** The loan costs 45 and the transfer 5. You're 95 short to pay the debt, even if you don't send anything else. Review the deal before accepting it, or look for help if you already have it.



#### Your plan

Write what you'd do in an emergency before borrowing: three options in order.



### Learn more

- **Payday loans and advances** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/payday-loans/ — **What to look for:** the costs of payday loans and the alternatives.
- **File a complaint with the DFPI** (DFPI · English and Spanish): https://dfpi.ca.gov — **What to look for:** "File a Complaint" if you have a problem with a lender or a pay advance app in California.

### Key words

- *Cash advance:* taking money out with a credit card, usually more expensive.
- *Roll over:* swapping a debt for another with new terms.
- *APR:* the yearly cost of credit.

### Sources

CFPB, payday loans · DFPI, earned wage access.

---

## M2 U11. How do I say how much I can help without promising too much?

**What you will be able to do:** Communicate what you can do with respect and agree on how to verify emergencies.

**To start:** Mar got a call: it was her nephew's voice, crying, asking for 500 dollars after an accident. She almost sent it. She called her sister and her nephew was fine. The voice was fake. In this lesson you'll learn to make agreements with your family and protect yourself from fake emergencies.

### The essentials (5 minutes)

#### Separate what's certain from what isn't

You can say: "I can send 50 on Friday. I can't confirm the other 30 yet."

That sentence says what you can do, what's missing and when you'll know more.



#### Three steps to talk about money

1. **Confirm** the amount and date you can commit to.
2. **Explain** what still needs to be confirmed.
3. **Agree** on when you'll talk again.



#### The family agreement

A **family agreement** is what you and your family understand and accept about the support. It covers how much, when, what for and what to do in an emergency.

It doesn't have to be a formal document. It can be a message you both keep.



#### Fake voices exist

Today scammers can **clone a relative's voice** with artificial intelligence, using a short video from social media.

That's why a voice that sounds just like your son or your mom doesn't prove it's real.



#### The family code word

1. **Agree today** on a secret word or phrase only you know. Don't post it on social media.
2. If you get an emergency call asking for urgent money, **stay calm and ask for the code word**.
3. If they don't know it or refuse, **hang up and call** your relative at the number you already had saved.

> **Key idea:** rushing and secrecy ("don't tell anyone") are signs of a scam.



#### Do it this week

1. Talk with your family and agree on a code word.
2. Save on your phone the number of a trusted contact to verify.
3. Check who can see your videos on social media.



#### Check your understanding

1. You get a call with your son's voice asking for money. How do you verify?
*Answer:* You ask for the code word and, if in doubt, hang up and call a number you already knew.

2. Does a voice that sounds just like your relative prove it's real?
*Answer:* No. Voices can be cloned today.


#### Remember

- Promise only what you can confirm.
- Agree on a family code word.
- Call a number you already knew, never the one in the message.



### Go deeper (5 more minutes)

#### A good agreement has six parts

| Part | Example |
|---|---|
| Purpose | Food for the month |
| Range | Between 150 and 180 dollars |
| Date | The 15th |
| Emergencies | A verified hospital stay or accident |
| Verification | Code word and a call to a known contact |
| Review | Every three months or if work hours change |



#### A script for the conversation

"I want to keep helping. This month I can send between 150 and 180 after rent. If something unusual happens, we first verify the amount and the date and look at options."

Listen to the expenses of the person receiving and explain your obligations. Don't promise uncertain money just to end an uncomfortable conversation.



#### More ways to verify

Besides the code word:

- have a **trusted contact** to confirm, like another relative;
- ask a **question only the family would know**, for example the name of a childhood pet;
- be suspicious of new numbers, requests for payment with gift cards or cryptocurrency, and anyone who asks you not to hang up.

> **Good to know:** the FTC receives thousands of reports a year of "family emergency" scams. If it happens to you, you can report it at ReportFraud.ftc.gov, even if you didn't lose money.



#### Protect your voice and your data

Check who can see your videos on social media. Avoid posting where your family is traveling or details that could be used to trick others.

If someone calls and asks you to say "yes," hang up. They can use your recorded voice.



#### Safety first

If there is control or violence in your family, an agreement shouldn't put you at risk. You don't have to confront anyone.



#### Signs of a fake emergency

- They call or text from a new number.
- They ask you not to hang up or tell anyone.
- There's a big rush: "right now."
- They ask for payment with gift cards, cryptocurrency or instant payment apps.
- The story changes when you ask questions.

If you see one or more of these signs, stop and verify.



#### When several relatives ask

If you get requests from several relatives, it helps to have a single family agreement. It says how much you give in total, to whom, what for and when.

That way nobody feels they get less than someone else, and you don't overcommit. Review it together once or twice a year.



#### Cases


**Case 1. The fake accident**

A message arrives from a new number: "It's your nephew, I had an accident, don't call anyone, send 500."
- *What does Mar do?* She calls her sister at the usual number. The nephew is fine. She reports the message.


**Case 2. Alex's agreement**

Alex and Alex's mom agree: food, between 150 and 180 dollars, on the 15th. Emergencies, verified by calling the aunt. Review every three months or if Alex's hours change.
- *What do they add after this lesson?* A family code word.


**Case 3. Rubén's code word**

Rubén gets a call with a voice just like his mom's, asking him for money for a doctor.
- *What does he do?* He asks for the code word. The voice hesitates and hangs up. Rubén calls his mom, who was at home with no problem at all.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Promising what isn't certain | You go into debt to keep your word | Separate what's certain from what isn't |
| Believing a familiar voice is proof | You fall for an AI scam | Ask for the code word |
| Calling the number in the message | You talk to the scammer | Call the number you already had |
| Posting your code word or travel details | You give information to scammers | Keep them private |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which number do you call to verify an emergency? a) The one in the message · b) The one the caller gives you · c) One you already knew
2. Does a voice that sounds just like your relative prove it's real? a) Yes · b) No · c) Yes, if it says your name
3. How many parts does a good family agreement have? a) 6 · b) 2 · c) 1: the amount
**Answers:** 1-c: the one in the message may belong to the scammer. 2-b: voices can be cloned today. 3-a: purpose, range, date, emergencies, verification and review.



#### Put it into practice

Write an agreement with purpose, range, date, emergency, verification and review.
**Answer:** Food; 150 to 180; the 15th; verified emergency; code word and a call to a known contact; review if hours change or every three months.



#### Your plan

Agree on a code word with your family today and keep your agreement private.



### Learn more

- **Family emergency scams** (FTC · English): https://consumer.ftc.gov — **What to look for:** search for "family emergency scam" to see the signs and how to protect yourself from cloned voices.
- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov — **What to look for:** the form to report a fake call or message.

### Key words

- *Family agreement:* what both sides understand and accept about the support.
- *Independent verification:* confirming through a channel you already knew.
- *Family code word:* a secret word to confirm that a call is real.
- *Voice cloning:* imitating a person's voice with artificial intelligence.

### Sources

FTC, family emergency scams and voice cloning · FTC, ReportFraud.

---

## M2 U12. How do I save for something that will be paid in pesos?

**What you will be able to do:** Plan goals in another country taking into account the exchange rate, ownership and documents.

**To start:** Alex wants to build a room for Alex's mom in Michoacán. The price given was 34,000 pesos. Alex saved 2,000 dollars, but when the money was sent the dollar had dropped and it wasn't enough. In this lesson you'll learn to save for goals that are paid in another country.

### The essentials (5 minutes)

#### Start with the currency it's paid in

If what you're going to pay costs pesos, your goal should be in pesos.

The dollars you need change with the exchange rate. That's why the same goal can cost you more or fewer dollars depending on the month.



#### The same goal at different exchange rates

A room that costs 34,000 pesos.

| Exchange rate | Dollars needed |
|---|---|
| 18 pesos per dollar | 1,888.89 |
| 17 pesos per dollar | 2,000.00 |
| 16 pesos per dollar | 2,125.00 |

Save with the least favorable scenario in mind.



#### Three steps

1. **Write down the price** and the currency it's paid in.
2. **Calculate the dollars** with today's exchange rate.
3. **Repeat** with a less favorable exchange rate and save with that number.



#### Sending money doesn't make you an owner

"Helping build a house" doesn't say who it will legally belong to.

If land is bought in someone else's name, your transfer receipt proves you sent money, not that you're an owner.

> **Key idea:** before a big commitment, check whose name it will be in and get a document that says so.



#### A case in one minute

Rubén wants to save 20,000 pesos in a year so his mom can fix the roof of her house in Oaxaca.

He does the math at 16.5 pesos per dollar: he needs 1,212.12 dollars, about 101 a month. If the dollar goes up, he finishes sooner; if it goes down, he already has a margin.

He also asks his mom to confirm the estimate with the builder, in writing.



#### Do it this week

1. Write your goal in the currency it will be paid in.
2. Calculate the dollars with three exchange rates.
3. Ask whose name what you build or buy will be in.



#### Check your understanding

1. In what currency do you set a goal that's paid in Mexico?
*Answer:* In pesos, because that's how it's paid.

2. Does your transfer receipt prove you own a piece of land?
*Answer:* No. It only proves you sent money.


#### Remember

- Set the goal in the currency it's paid in.
- Save with the least favorable exchange rate.
- Make sure whose name what you build will be in.



### Go deeper (5 more minutes)

#### A complete goal

A complete goal across two countries has: amount, date, currency, who owns it and who benefits.

If prices also go up 10%, a 30,000-peso goal becomes 33,000. Check the cost every few months.



#### Ownership and documents

Before sending large amounts for land or a house, check:

- the **deed** (escritura): whose name it's in;
- the **Public Property Registry** (Registro Público de la Propiedad): that it has no problems;
- whether you need a **contract** or a notarized document that recognizes your share.

A notario in Mexico is a lawyer with special powers, unlike a notary public in the U.S.

> **Good to know:** in Mexico you can give a power of attorney to a trusted relative so they can handle paperwork for you. You can do it at the Mexican consulate in the U.S.



#### Taxes in two countries

A gift, support, a loan or an investment can have different tax treatment in each country.

Describe the real purpose of the money and ask a professional. Don't use a label just because it seems to save taxes.



#### Keep track

Write down your contributions, the fees, the currency, the balance set aside and the updated cost of the goal.

The same contribution can't count toward the goal and toward your emergency fund at the same time.



#### Watch out for land scams

There are scams that sell land that doesn't exist, already has an owner or can't be built on.

Before paying, ask for the deed, check it at the Public Property Registry and don't pay large amounts upfront to strangers.



#### Where to keep the goal money

While you save for your goal in Mexico, keep the money separate from your day-to-day account, for example in an insured savings account.

Send it when it will be used, not before. That way the money isn't spent on something else there and isn't lost if the plan changes.

If you decide to send it little by little, ask that it be kept in an account in the right person's name. Ask them to share the progress of the work with you.



#### Cases


**Case 1. The room for Alex's mom**

The room costs 34,000 pesos: 2,000 dollars at 17, or 2,125 at 16.
- *What amount does Alex plan with?* 2,125, the least favorable scenario. If the dollar goes up, Alex finishes sooner.


**Case 2. The land in the brother's name**

Mar sent money for three years for land that's in her brother's name. Now she wants her share.
- *What problem does she have?* Without a document that recognizes her share, it's hard to prove.
- *What should she have done?* Agree in writing, before a notario, what her share was before sending.


**Case 3. Rubén's parents' house**

Rubén wants to help fix his parents' house in Oaxaca.
- *What does he ask first?* Whose name the house is in and whether his siblings will also chip in, to make it clear from the start.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Planning the goal in dollars | It isn't enough if the dollar drops | Plan in the currency it's paid in |
| Saving with today's exchange rate | You come up short | Use a less favorable scenario |
| Sending without knowing whose name it's in | You lose your share | Get a document first |
| Counting the same contribution for two goals | You think you have more | Assign each dollar to only one goal |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. In what currency do you set a goal that's paid in Mexico? a) Dollars · b) Whichever currency is cheaper that day · c) Pesos
2. Does your transfer receipt prove you own a piece of land? a) Yes · b) No · c) Yes, if you keep all the receipts
3. Can one contribution count for two goals at the same time? a) No · b) Yes · c) Yes, if they're for the same family
**Answers:** 1-c: that's how it's paid. 2-b: it only proves the transfer. 3-a: every dollar has one job.



#### Put it into practice

You send money for land in someone else's name. What still needs to be cleared up?
**Answer:** Who owns it, what rights you have, what agreement exists, what documents prove it, how the money is used and what the tax consequences are.



#### Your plan

Choose a goal across two countries and write down what's confirmed, what's pending and which professional you need.



### Learn more

- **Remittances and savings** (CONDUSEF · Spanish): https://www.condusef.gob.mx/?p=remesas — **What to look for:** tips for using remittances for savings and housing goals.
- **Newcomer's guides to managing money** (CFPB · English and Spanish): https://www.consumerfinance.gov/about-us/blog/the-newcomers-guides-to-managing-money/ — **What to look for:** the guide on savings goals and how to track them.
- **MiConsulado** (Mexico's Foreign Ministry · Spanish): https://citas.sre.gob.mx — **What to look for:** an appointment for notarial services, like a power of attorney, at your consulate.

### Key words

- *Scenarios:* possible versions of the future to test your plan.
- *Beneficiary:* the person who receives the benefit.
- *Ownership:* whose name something is in.
- *Deed:* a document that says who owns a property.

### Sources

CONDUSEF, remittances · Mexico's Foreign Ministry, notarial services at consulates.

---

## M2 U13. How do I bring my account and my remittances into one plan?

**What you will be able to do:** Bring your account, payments, remittances and family agreement together in a plan you can review.

**To start:** Alex got paid by check, cashed it at a store, paid bills in cash and sent money to Alex's mom from another store. At every step a little was lost. When Alex drew the whole path, the cost became clear. In this lesson you'll learn to see the full path of your money.

### The essentials (5 minutes)

#### Look at the full path

Choosing an account and choosing how to send money are connected decisions.

A cheap account with an expensive transfer, or a cheap transfer that forces you to pay in cash, can cost more overall.



#### Three steps to draw it

1. **Draw where the money comes from:** your paycheck.
2. **Write each step** until it reaches your family.
3. **Note the cost, the date and who is responsible** for each step.



#### Alex's path, before and after

| Step | Before | After |
|---|---|---|
| Getting paid | Check cashed at a store (fee) | Direct deposit to the account |
| Account | Account with a fee per deposit | No-fee account, Bank On certified |
| Paying rent | Money order bought with cash | Transfer from the account |
| Sending to Mexico | Cash at a store + 1% tax | From the account to Alex's mom's account |

With the new path, Alex saves fees and the 1% tax.



#### Check that it fits together

- An account that doesn't accept your documents isn't a ready option.
- A transfer that arrives late doesn't solve an urgent need.
- A promotion isn't the usual cost.
- Paying for a remittance in cash may trigger the 1% tax; from your account, usually not.

> **Key idea:** compare the full path of the money, not each piece separately.



#### A case in one minute

Daniela drew her path. She's paid by the hour into her account and gets cake orders paid by Zelle and in cash. She used to send money to her sister by paying with a credit card.

She found out her card charged each transfer as a cash advance. Now she sends from her debit account and deposits the cash from orders once a week.



#### Do it this week

1. Draw your path: paycheck, account, payments and transfer.
2. Mark in red each step where you pay a fee.
3. Choose one step to change this month.



#### Check your understanding

1. Does a promotion represent the usual cost?
*Answer:* No. Compare with the price of the transfers that follow.

2. Is sending less always better?
*Answer:* No. It may mean you have less capacity or that your family receives less than they need.


#### Remember

- Draw the path of your money from start to finish.
- Look for the steps where you lose money.
- Review your plan when fees or your needs change.



### Go deeper (5 more minutes)

#### Monthly record

Each month write down how much went out, how much arrived, on what date and what for.

Compare the plan with what really happened and explain the differences. Sending more can pay for an important goal or hide a debt; sending less can reflect less capacity.



#### Stress test

Ask yourself what happens if:

- your income drops 20% and an unusual request arrives;
- your account asks for a document you don't have;
- the exchange rate gets worse;
- the transfer takes two more days.

Mark which part of your plan depends on each condition and have an alternative.

> **Good to know:** according to the Bank of Mexico, most remittances that arrive in the country are received by electronic transfer, not in cash. Receiving into an account is more and more common, and safer.



#### The person receiving can save too

If your family receives money in a bank account or a Financiera para el Bienestar account, they can leave part of it saved there. That way they don't have to take it all out at once.

Ask together which account works best for them based on where they live and what documents they have.



#### Keeping the plan up to date

Keep the version of your sheet and the next review date.

Update it when fees, the way you get paid or your family's needs change.



#### What you achieved in this module

Now you know who holds your money, which account works for you and how much you can send. You know how to compare remittances, how to complain and how to protect yourself from fake emergencies.

In Module 3 you'll learn to build your credit and manage your debts.



#### Review your plan every three months

Set a reminder on your phone to review your path every three months.

Ask yourself: did my account's or my money transmitter's fees change? Did the way I get paid change? Does my family need something different?

If something changed, adjust that step. A plan that gets reviewed is a plan that keeps working.



#### Cases


**Case 1. Alex's path**

Payroll check, cashing at a store, paying for the remittance in cash.
- *What changes?* Alex asks for direct deposit, opens a no-fee account and sends from that account to the mom's account.
- *What does Alex save?* The check-cashing fee, the cash fees and the 1% tax.


**Case 2. The promotion that ended**

Rubén's provider was the best with the introductory promotion, but now delivers less than another one with the same budget.
- *What does he do?* He switches providers and double-checks his mom's information before the first transfer.


**Case 3. Daniela's plan**

Daniela is paid by the hour and by order. She sends money to her sister every month.
- *What does she discover when she draws her path?* That she paid for each transfer with a credit card and was charged as a cash advance. Now she pays from her debit account.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Comparing each piece separately | One cheap piece makes the total more expensive | Look at the full path |
| Not reviewing after a promotion | You pay more without noticing | Review every three months |
| Sending everything in cash | You pay the 1% and take risks | Use your account |
| Having no plan B | A change leaves you without options | Do a stress test |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What best shows that you compared? a) Downloading an app · b) Asking a friend which one they use · c) A sheet with two offers and a date
2. Is sending less always better? a) Yes · b) No · c) Yes, if the exchange rate goes up
3. Does a promotion represent the usual cost? a) No · b) Yes · c) Yes, if it lasts more than a month
**Answers:** 1-c: it's concrete evidence. 2-b: it depends on your capacity and the need. 3-a: compare the later price.



#### Put it into practice

Draw your current path: paycheck, account, payments and transfer. Mark where you pay fees.
**Answer:** For example: "check → cashed at a store (3) → cash → transfer at a store (5 + 1% tax)." Each step with a cost is a chance to save.



#### Your plan

Turn in your Module 2 file: map of institutions, account comparison, three transfer quotes, sending calendar, family agreement with a code word and an emergency protocol. Say which numbers are simulated and don't include the recipient's information. Also solve integrated case E2 in the support materials.



### Learn more

- **Newcomer's guides to managing money** (CFPB · English and Spanish): https://www.consumerfinance.gov/about-us/blog/the-newcomers-guides-to-managing-money/ — **What to look for:** the guide to sending money abroad and the guide to bank accounts.
- **Bank On certified accounts** (CFE Fund · English and Spanish): https://joinbankon.org — **What to look for:** no-fee accounts near you to receive your pay and send from there.
- **Your rights on remittances** (CFPB · English and Spanish): https://www.consumerfinance.gov/ask-cfpb/what-is-a-remittance-transfer-and-what-are-my-rights-en-1161/ — **What to look for:** what your receipt must say so you can complain.

### Key words

- *Money path:* all the steps from when you get paid until the money reaches your family.
- *Stress test:* reviewing your plan under worse conditions.
- *Evidence:* a record that shows what you did.

### Sources

CFPB, remittances · Bank On · Bank of Mexico, remittance statistics.

---


# Part 4. Module 3. Build your credit and manage your debts

## M3 U01. If they lend me money, does that mean I can pay it back?

**What you will be able to do:** Tell apart being approved for a loan from your real ability to pay.

**To start:** Andrés was approved for a loan on a new car in fifteen minutes. He left the dealership happy. In the first month he realized that, with insurance, the payment didn't fit in his budget. In this lesson you'll learn to know whether you can pay before you sign.

### The essentials (5 minutes)

#### Approved is not the same as affordable

Being approved by a lender means **the lender** believes you'll pay them back. It doesn't mean the payment is good for you or comfortable.

Lenders look at your income and your history, but they don't know all your expenses, your remittances or your plans.



#### Do the math yourself

You're offered a payment of 50 a month. After food, housing and commitments, you only have 30 left.
- What you have left over: **30**
- The payment offered: **50**
- You'd be short every month: **−20**
Your **ability to pay** means being able to cover the payment with your resources, even in a hard month.


#### Three different things

| Type | Description | What it means for you |
|---|---|---|
| Credit report | Information about your accounts and payments. | The lender reviews it. |
| Credit score | A number that sums up part of your report. | It helps you get approved. |
| Ability to pay | What's left after your expenses. | Only you really know it. |

#### Four questions before you ask for a loan

1. **Will they approve me?** It depends on the lender.
2. **Can I pay it?** It depends on your calendar and your budget.
3. **Is it good for me?** It depends on the purpose and the alternatives.
4. **What do I risk?** If there's collateral, you can lose the item.



#### A case in one minute

Mar was approved for a 1,000 loan and offered 500 more "just in case."

Mar did the math: the payment on 1,500 didn't fit in a month with fewer tips. She accepted only the 1,000 she needed.

Extra borrowed money is extra debt, even if it's easy to get.

> **Key idea:** a good score doesn't make the monthly payment for you.



#### Do it this week

1. Calculate how much you have left each month after your basic expenses, debts and remittances.
2. Subtract the payment you're offered, plus insurance and other costs.
3. Do the math again with 20% less income.



#### Check your understanding

1. You were approved for a loan. Does that mean you can pay it?
*Answer:* No. You have to check whether the payment fits your budget, even in a hard month.

2. Is an available credit limit your money?
*Answer:* No. It's money they would lend you and you'd have to pay back.


#### Remember

- Approved is not the same as affordable.
- Test the payment with a lower-income month.
- Ask only for what you need.



### Go deeper (5 more minutes)

#### Types of credit

| Type | Description | What it means for you |
|---|---|---|
| Revolving credit | Cards and lines of credit. You can use it again. | The balance can grow if you don't keep it in check. |
| Installment | Personal or car loan, with fixed payments. | You know when you'll finish. |
| Secured by collateral | An item backs the debt, like the car. | If you don't pay, you can lose the item. |

#### Debt-to-income ratio

The debt-to-income ratio compares your debt payments with your income.

Debt payments of 450 ÷ gross income of 3,000 = 15%. With a net income of 2,400, it's 18.75%. Always say which one you used.

This ratio doesn't include your basic expenses, like rent or food. That's why it doesn't replace your budget.



#### Stress test

If you have 200 left after your obligations and the new payment is 150, your margin is 50.

If your income drops by 100, you'll have a deficit of 50. Ask yourself whether you could keep up that payment in a month with fewer hours or fewer tips.



#### The costs you don't see

Financing a car also means insurance, gas, maintenance, registration and plates.

A furniture loan may include credit insurance you don't need. Ask what the monthly payment includes.

> **Good to know:** in California, car insurance has minimum required liability amounts. If you finance a car, the lender will also require full coverage, which costs more.



#### Credit as a tool

Credit lets you use resources today in exchange for a future obligation. It can help you reach a goal, like a car for work, and it can also take away flexibility.

Don't measure your progress by how many cards you have or by your available limit. A credit limit isn't your money.



#### Questions for the lender

Before you sign, ask in writing:

- What is the APR and the total cost of the loan?
- Is there a fee to open it or to pay it off early?
- What happens if I'm late on a payment?
- Does the payment include insurance or products I didn't ask for?

If they won't give you the answers in writing, don't sign yet.



#### Cases


**Case 1. Andrés's car**

Andrés earns 2,500 net a month. His expenses and commitments add up to 2,250: he has 250 left. The car payment would be 220, plus 90 for insurance.
- *Can he afford it?* No. He'd be 60 short every month, even though he was approved.
- *What options does he have?* A cheaper car, a bigger down payment or waiting to save more.


**Case 2. Mar's extra 500**

Mar is approved for 500 more than she asked for.
- *Should she take it to "make the most of it"?* No. It's extra debt with its own cost. She should ask only for what she needs.


**Case 3. Rubén's first card**

Rubén got a card offer with a 2,000 limit. He had never had so much "available money."
- *How should he see it?* As a loan he'd have to pay back, not as his money.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking that if you're approved you can pay | You fall behind from the first month | Do your own math |
| Accepting more than you need | You pay interest on money you don't use | Ask only for what you need |
| Forgetting the extra costs | The real payment is higher | Add insurance, gas and maintenance |
| Seeing your credit limit as your money | You spend and the debt piles up | Use it only with a payment plan |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a good score guarantee you can pay? a) No · b) Yes · c) Yes, if it's over 700
2. Is an available credit limit your money? a) Yes · b) Yes, if you don't use it · c) No
3. If you have a 200 margin and the payment is 150, what happens if your income drops by 100? a) You're still fine · b) A deficit of 50 · c) You have 50 left
**Answers:** 1-a: the score doesn't make the payment. 2-c: it's a loan available to you. 3-b: 200 − 100 − 150 = −50.



#### Put it into practice

The lender offers you 500 more than you asked for. Should you take it to "make the most of it"?
**Answer:** Not necessarily. Compare the need, the cost and the payment. Additional borrowed money is an additional obligation.



#### Your plan

Define the purpose, the amount you need, the payment you can cover and what you'd do if your income drops. If you have no margin, the first step may be to stabilize your finances.



### Learn more

- **Credit reports and scores** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** the difference between a report and a score, and what factors lenders use.
- **Auto loans** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/auto-loans/ — **What to look for:** the worksheet to calculate the total cost of the car with insurance and maintenance before you go to the dealership.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the "Borrowing Basics" module to practice evaluating a loan.

### Key words

- *Ability to pay:* being able to pay with your own resources.
- *Revolving credit:* credit you can use again.
- *Collateral:* an item that backs a debt.
- *Debt-to-income ratio:* debt payments divided by income.

### Sources

CFPB, credit reports and scores · CFPB, auto loans · California Department of Insurance, auto insurance.

---

## M3 U02. How do I know what information is used about my debts?

**What you will be able to do:** Read your credit report, spot errors and dispute them correctly.

**To start:** Andrés was turned down for a loan because of "information in his report." He didn't know he had a report or what it said. When he checked it, he found a card he never opened. In this lesson you'll learn to check your report and fix errors.

### The essentials (5 minutes)

#### What your credit report is

Your **credit report** brings together information about your accounts and how you pay. Three agencies make it: **Equifax, Experian and TransUnion**.

Your **score** is a number calculated with part of that information.

If you ever had a card, a loan or a phone paid in installments, you probably have a report.



#### How to get it at no cost

You can see your reports from all three agencies **no-cost every week** on the official site **AnnualCreditReport.com**.

Checking your own report does **not** lower your score.

If you file with an ITIN, some agencies let you request your report by mail or phone instead of online. Ask about the process.



#### What to check in your report

| Type | Description | What it means for you |
|---|---|---|
| Your information | Name, addresses, date of birth. | Is it yours? |
| Accounts | Creditor, balance, limit, status and payment history. | Do you recognize them? |
| Inquiries | Who asked to see your report. | Did you authorize it? |
| Collections | Debts that went to a collector. | Are they correct? |

#### Three steps

1. **Confirm** that the personal information is yours.
2. **Check** each account: balance, dates and payments.
3. **Mark** anything you don't recognize or that looks wrong.



#### An error is not the same as negative information

A late payment that really happened isn't an error, even if it lowers your score. You handle it by paying and getting organized.

Incorrect information is corrected with a well-documented **dispute**.

> **Key idea:** use only AnnualCreditReport.com. Other websites charge or ask for your card information.



#### A case in one minute

Andrés requested his three no-cost reports. One showed an address in another city where he never lived and a card he didn't open.

He took screenshots, disputed both items online with the agency and froze his credit at all three agencies. He wrote down the confirmation numbers and set an alert to check again in 30 days.



#### Do it this week

1. Go to AnnualCreditReport.com and request your three reports.
2. Check your personal information and each account.
3. Write down anything you don't recognize so you can look into it.



#### Check your understanding

1. Does checking your own report lower your score?
*Answer:* No. You can check it without affecting your score.

2. Your report shows a real late payment. Is it an error that can be erased?
*Answer:* No. Correct information isn't erased; you handle it by paying.


#### Remember

- Check your three reports no-cost at AnnualCreditReport.com.
- Separate errors from correct negative information.
- Dispute only errors, with proof.



### Go deeper (5 more minutes)

#### Unknown information can be three things

1. **An error** by the agency or the creditor.
2. **A different business name** for your creditor: the store gave you the card, but the bank shows up.
3. **Possible fraud:** someone opened an account in your name.

Figure out which one it is before you act.



#### How to dispute an error

| Step | What to do |
|---|---|
| 1 | Identify the exact item that's wrong |
| 2 | Explain why it's incorrect |
| 3 | Attach a copy of your proof, never the original |
| 4 | Send the dispute to the agency and, if you can, to the creditor |
| 5 | Keep a copy, the date and the confirmation number |

The agency usually has 30 days to investigate and answer you.



#### How long information stays

Much correct negative information can stay up to seven years. Certain bankruptcies, up to ten.

Don't treat these as a "clean slate" date: it depends on the type of record. Meanwhile, paying on time from now on does improve your history.

> **Good to know:** you can freeze your credit at no cost at all three agencies. That way nobody can open new accounts in your name. You'll see it in M4 U04.



#### Never lie in a dispute

Never claim identity theft to erase a real late payment. It's false and can have legal consequences.

Disputes are for correcting errors, not for erasing history.



#### How to write your dispute

A good dispute is short and specific:

"My name is [name]. My report shows the account ending in 1234 with a balance of 900. That account was closed at zero on March 10. I'm attaching a copy of the closing letter. I ask that you investigate and correct the balance."

Cover your sensitive information on the copies, like your full account number.



#### If you're denied credit

If you're denied a loan or a rental because of your report, they must tell you which agency issued it.

You have the right to request that report no-cost within the next 60 days and to dispute any errors.



#### Cases


**Case 1. Someone else's card**

Andrés's report shows a card he never opened and a real late payment on a phone.
- *What does he do about the card?* He disputes it as possible fraud and freezes his credit.
- *And about the real late payment?* He handles it by paying and asking for an agreement.


**Case 2. The balance that wasn't updated**

Mar paid off a card, but the report shows a balance of 900.
- *Is it an error?* She checks the report date: it was generated before the payment. She waits for the next update before disputing.


**Case 3. Rubén's first report**

Rubén requested his report by mail using his ITIN.
- *What did he find?* His phone installment plan, paid on time. He already had a history without knowing it.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Using websites that charge for your report | You pay for something no-cost or your data gets stolen | Use AnnualCreditReport.com |
| Disputing correct information | It isn't erased and you lose time | Dispute only errors |
| Sending original documents | You lose them | Send copies |
| Not keeping the dispute confirmation number | You can't follow up | Write down date, number and answer |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does checking your own report lower your score? a) No · b) Yes · c) Yes, 5 points each time
2. Is a real late payment an error that can be erased? a) Yes · b) Yes, if you pay a fee · c) No
3. What do you send as proof in a dispute? a) The original · b) A copy · c) Nothing; a phone call is enough
**Answers:** 1-a: checking your own doesn't affect it. 2-c: correct information isn't erased. 3-b: keep your originals.



#### Put it into practice

Your report shows a 900 balance on an account your closing letter shows at zero. Write the request.
**Answer:** Identify the account by its last digits, describe the difference, attach a copy of the letter with your sensitive information covered and ask them to investigate and correct it.



#### Your plan

Write down the date of your review, what you found, your proof and the next review date. Don't hand your full report to the course.



### Learn more

- **No-cost credit reports** (AnnualCreditReport.com · English and Spanish): https://www.annualcreditreport.com — **What to look for:** "Request your no-cost credit reports" to get all three; if you use an ITIN, the mail option.
- **How to dispute errors** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** the sample letters to dispute an error with the agency and with the creditor.

### Key words

- *Credit report:* a record of your accounts and payments.
- *Score:* a number calculated with a model.
- *Dispute:* a request to correct incorrect information.
- *Confirmation number:* a tracking number.

### Sources

[R07] CFPB, checking your report · [S19] CFPB, how long information stays · FTC, disputes.

---

## M3 U03. How do I start if I have no credit history?

**What you will be able to do:** Compare options for building a credit history without taking on too much debt.

**To start:** Rubén wants to rent his own apartment, but the landlord asks for a credit history. He has never had a card: he always pays in cash or with his app. He doesn't know where to start. In this lesson you'll learn the safest ways to build a history.

### The essentials (5 minutes)

#### Having no history isn't bad

Having no history doesn't mean you're irresponsible. Many people arrive in the U.S. with no history or prefer to use cash.

But without a history it's harder to rent, get a loan or get a good price on car insurance. That's why it's worth starting carefully.



#### Ways to start

| Type | Description | What it means for you |
|---|---|---|
| Secured card | You leave a deposit that backs your limit. You pay your purchases each month. | Ask if it reports to all three agencies. |
| Lending circle | A group lends with no interest and reports your payments. | Look for a recognized organization. |
| Rent reporting | Your on-time rent payments can be reported to the agencies. | Ask your landlord. |
| Credit-builder loan | You make payments and at the end you get the money. | Check the total cost. |

#### Be careful about locking up your money

If you have 500 in savings and a product asks you to lock up 400 as a deposit, you only have 100 left for emergencies.

No product is worth it if it locks up your only rent money.



#### You don't need to pay interest

To build a history with a card, **use a little and pay the full balance every month**. That way you pay no interest and your history grows anyway.

> **Key idea:** a product that doesn't report to the credit agencies doesn't build your history, even if you pay on time.



#### Do it this week

1. Ask your landlord whether they can report your rent to the agencies.
2. Ask at a credit union about secured cards or lending circles with an ITIN.
3. Write down how much money would be locked up with each option.



#### A case in one minute

Andrés came to the U.S. with a good credit history in Mexico, but here he had nothing. He asked a company that uses credit history from other countries, and a card accepted him with his Mexican history.

Rubén, with no history in any country, started with a 200 secured card and asked for his rent to be reported.



#### Check your understanding

1. Does a secured card's deposit pay for your purchases?
*Answer:* No. You pay your purchases each month; the deposit only backs the limit.

2. Do you need to pay interest to build a history?
*Answer:* No. If you pay the full balance every month, you pay no interest.


#### Remember

- Choose products that report to all three agencies.
- Don't lock up your emergency money.
- Pay the full balance every month.



### Go deeper (5 more minutes)

#### Compare the options

| Option | How it works | What to check |
|---|---|---|
| Secured card | A deposit backs the limit | Does it report? Annual fee? When do they return the deposit? |
| Credit-builder loan | You make payments and get the money at the end | Total cost, who it reports to |
| Savings-secured loan | Your savings back the loan | Money locked up, interest |
| Lending circle | A group lends with no interest and reports (M3 U09) | Who organizes it |
| Authorized user | Someone adds you to their card | How they manage it affects you too |
| Rent reporting | Your rent payments get reported | Whether the service charges a fee |



#### Your rent can build your credit

If you pay rent every month, you're already doing something that can count toward your history.

In California, since 2025, a law (AB 2747) requires many landlords to offer tenants an option. They can report their on-time rent payments to at least one credit agency.

It applies to buildings with more than 15 units and to some companies that own several properties. Only on-time payments are reported, if you ask. The landlord may charge you their cost, up to 10 dollars a month.

Ask your landlord whether they offer this service and whether it has a cost.

> **Good to know:** there are also companies that report your rent for a fee. Before paying, confirm they report to all three agencies and that you can cancel.



#### With an ITIN or with history from another country

Several credit unions and some banks offer cards and loans with an ITIN. Ask directly.

Some companies let you use your credit history from another country, like Mexico, for certain applications in the U.S. Check which countries and institutions take part.



#### Authorized user and cosigner are not the same

As an **authorized user** you use someone else's card, and their history can help you. In many cases you're not legally responsible for the debt.

As a **cosigner** you sign and you're responsible for the debt if the other person doesn't pay. You'll see it in M3 U08.



#### How long it takes to show up

Your first payments usually show up on your report one or two months after you open the account.

For a score to exist, many models need at least six months of history. Be patient: what matters is paying on time every month.



#### Cases


**Case 1. Rubén's secured card**

Rubén deposits 300 in a secured card and buys 40 in gas.
- *Does the deposit pay those 40?* No. Rubén has to pay the 40 according to his statement.
- *How does he build a history without paying interest?* By paying the full balance every month.


**Case 2. Two offers for Mar**

Offer A costs 36 a year and confirms in the contract that it reports to all three agencies. Offer B costs 120 and doesn't confirm that it reports.
- *Which is better?* A: it costs less and does build a history.


**Case 3. Daniela's rent**

Daniela pays 1,600 in rent every month, always on time, in a 40-unit building.
- *What can she ask?* Whether her landlord offers to report her rent payments to the credit agencies.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Choosing a product that doesn't report | You pay and don't build a history | Confirm it in the contract |
| Locking up your emergency savings | You're left without money for surprises | Use a smaller deposit or wait |
| Paying only the card's minimum | You pay interest you don't need to | Pay the full balance |
| Thinking you need many cards | More risk of debt | One, used well, is enough |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a secured card's deposit pay for your purchases? a) No · b) Yes · c) Yes, every month
2. Do you need to pay interest to build a history? a) Yes · b) Yes, at least a little each month · c) No
3. Does a product that doesn't report to the agencies build a history? a) Yes · b) No · c) Yes, if you pay on time
**Answers:** 1-a: you pay your purchases. 2-c: pay the full balance. 3-b: if it doesn't report, it doesn't count.



#### Put it into practice

You have 500 in savings. A product requires locking up 400. There's a possible 250 emergency. What do you do?
**Answer:** The emergency wouldn't be covered. Consider a product with a smaller deposit, waiting, or a path that doesn't lock up your savings, like rent reporting or a lending circle.



#### Your plan

Compare two products and the option of waiting to build up your savings. Write down which one reports and how much money it locks up.



### Learn more

- **Building or rebuilding your credit** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** the guide on how to build credit and the questions to ask about a secured card.
- **Lending circles** (Mission Asset Fund · English and Spanish): https://www.missionassetfund.org/lending-circles/ — **What to look for:** how to sign up, the requirements and whether they accept an ITIN.

### Key words

- *Credit history:* a record of your experience with credit.
- *Secured card:* a card backed by a deposit.
- *Authorized user:* someone who uses another person's card.
- *Cosigner:* someone who is responsible for another person's debt.

### Sources

[S18] CFPB, building or rebuilding credit · Mission Asset Fund · California AB 2747 (rent reporting, Civil Code 1954.07).

---

## M3 U04. Does improving my credit mean erasing everything?

**What you will be able to do:** Choose valid actions to rebuild your history and recognize false promises.

**To start:** Mar saw an ad: "We erase your debts from the credit bureau in 30 days, 499 dollars." She had some late payments and the offer sounded perfect. Before paying, she asked. In this lesson you'll learn what you can do and which promises are false.

### The essentials (5 minutes)

#### What really happened doesn't get erased

If something in your report is wrong, you can dispute it. If a late payment really happened, it doesn't get erased: the work is different.

Improving your credit means fixing errors and, above all, paying on time from now on.



#### Fixing and rebuilding are different

| Type | Description | What it means for you |
|---|---|---|
| Fix | Make sure your report is accurate, with disputes and proof. | Only for errors. |
| Rebuild | Pay on time, lower balances and don't open more debt than you need. | It takes months, but it works. |

#### Your card utilization

**Credit utilization** is how much of your limit you're using.

A 900 balance with a 1,500 limit = 60%. If you lower the balance to 450, it's 30%.

Using less of your limit helps your score. There's no magic percentage that guarantees a number.



#### False promises

Be wary of anyone who promises to:

- erase all negative information;
- raise your score by a guaranteed amount;
- create a "new credit identity";
- charge you before doing the work.

Anything a legitimate credit repair company does, you can do yourself at no cost.



#### Do it this week

1. Check your report and separate errors from correct information.
2. Dispute only errors, with proof.
3. Set alerts to pay everything on time.

> **Key idea:** nobody can guarantee you a number of points or erase correct information.



#### A case in one minute

Daniela had two late payments last year. Instead of paying to "repair" her credit, she set up automatic minimum payments on her two cards and lowered her balance little by little.

A year later, her late payments are still on the report, but she has twelve months in a row of on-time payments. She's already been approved for a loan at a better rate.



#### What weighs on your score

| Type | Description | What it means for you |
|---|---|---|
| On-time payments | What weighs the most. | Never fall behind. |
| Utilization | How much of your limit you use. | Use a little. |
| Length of history | How long you've had credit. | Think twice before closing your oldest card. |

#### Check your understanding

1. Can a real late payment be erased because it lowers your score?
*Answer:* No. Correct information stays; you improve by paying on time.

2. A company charges you before doing the "repair." Is that normal?
*Answer:* No. It's a red flag and the law prohibits it.


#### Remember

- Fix errors and rebuild by paying on time.
- Lower your card balances.
- Nobody can erase what really happened.



### Go deeper (5 more minutes)

#### Find the cause

First figure out why your history isn't good: an error, fraud, a late payment, high balances or recent changes.

Each cause has a different action. Fraud gets reported; an error gets disputed; a late payment is handled with a payment plan; a high balance is lowered little by little.



#### A routine that works

- Write down the due dates of all your debts.
- Make sure there's money before each automatic payment.
- If you see you're going to be late, contact the creditor before the due date.

One on-time payment doesn't change everything. Many on-time payments, one after another, do.



#### The clocks are different

Your payment, the update to your report, how long an item stays and the change in your score happen at different times.

That's why you can pay today and see the change in your report one or two months later.



#### The law protects you

Federal law prohibits credit repair companies from charging you before doing the work. They also must give you a written contract, and you have 3 days to cancel it.

> **Good to know:** in California, credit services companies must register with the state. If one isn't registered, it's a red flag.



#### Ideas that do help

- Set a reminder or an automatic minimum payment on each card.
- Pay more than once a month if you can: it lowers your utilization.
- Don't open several new accounts in a short time.
- If you have an old card with no annual fee, keep it open and use it now and then.



#### How to recognize a legitimate company

A legitimate credit counseling company doesn't promise you results, doesn't charge you upfront and gives you a written contract.

Many nonprofit agencies offer no-cost or low-cost counseling. Ask whether they're affiliated with a national credit counseling organization.



#### Cases


**Case 1. The 30-day offer**

Mar is offered to have her real late payments erased in 30 days for 499 dollars.
- *Does she sign up?* No. She checks her information, disputes only errors and organizes her payments.


**Case 2. Andrés's utilization**

Andrés has a 600 balance on a 1,000 limit: 60%. He pays 300 and drops to 30%.
- *How many points will he gain?* He doesn't know, but he does know he lowered his debt and his utilization.


**Case 3. Rubén's "new identity"**

Rubén is offered a "new number" to start a clean history.
- *What is it?* A scam and a crime. Using a number that isn't yours can bring serious legal problems.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying to "erase" real late payments | You lose money and the item stays | Organize your payments |
| Expecting a guaranteed number of points | You get frustrated | Measure actions: on-time payments, lower balance |
| Opening many new cards | More inquiries and more risk | Use the ones you have well |
| Accepting a "new number" | A crime and legal problems | Use only your own SSN or ITIN |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can a real late payment be erased because it lowers your score? a) No · b) Yes · c) Yes, if you pay a company
2. Balance 240 and limit 800. Utilization? a) 24% · b) 60% · c) 30%
3. Can a company charge you before doing the repair work? a) It's normal · b) It's a red flag · c) It's required by law
**Answers:** 1-a: correct information stays. 2-c: 240 ÷ 800 = 0.30. 3-b: the law prohibits it.



#### Put it into practice

A service guarantees it will erase your real late payments in 30 days. What do you do?
**Answer:** You don't sign up based on that promise. You check your information, dispute only errors and organize your payments.



#### Your plan

Choose three actions with dates: check your report, fix errors if any and organize your payments. Record results, without expecting a guaranteed date.



### Learn more

- **Credit repair scams** (FTC · English): https://consumer.ftc.gov — **What to look for:** search for "credit repair" to see the warning signs and how to do it yourself at no cost.
- **Credit reports and scores** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** "How to improve your credit score" and the explanation of utilization.

### Key words

- *Credit utilization:* balance divided by limit.
- *Delinquency or late payment:* not paying on time.
- *Collections:* efforts to collect a debt.

### Sources

[S20] FTC, credit repair · Credit Repair Organizations Act · California Civil Code, credit services.

---

## M3 U05. Why can a small payment end up costing more?

**What you will be able to do:** Compare loans and cards by their total cost, not by the monthly payment.

**To start:** Daniela was offered a professional oven for her business "for only 70 dollars a month." It seemed cheap. When she multiplied it out, the oven cost her almost double its price. In this lesson you'll learn to see the total cost before you sign.

### The essentials (5 minutes)

#### A low monthly payment can cost more

| Offer | Monthly payment | Months | Total |
|---|---|---|---|
| 1 | 10 | 10 | 100 |
| 2 | 8 | 15 | 120 |

Offer 2 has the lower payment, but it costs 20 more in total.



#### Add it all up

A small monthly payment can come from a longer term and a larger **total cost**.

Add up all the payments and fees. Compare that total with what you receive.



#### Three steps to compare

1. **Find out how much you really receive**, after fees.
2. **Add up all the payments and fees.**
3. **Check whether the payments fit** your paydays.



#### The card's minimum payment

The **minimum payment** keeps your card current, but it stretches the debt out a lot.

If you only pay the minimum, you can take years to finish and pay a lot in interest. Your statement shows how long it would take.



#### A case in one minute

Rubén bought a phone with "pay in 4" in an app, then some sneakers and then some headphones. Each plan was 35 dollars.

Separately they seemed small. Together they were 140 every two weeks, taken automatically from his debit card.

Now he writes down all his plans in one place before adding another.

> **Key idea:** compare by total cost, not by what you pay each month.



#### Three questions before you accept

1. How much do I really receive?
2. How much do I pay in total, adding everything up?
3. What happens if I fall behind?

If you can't answer all three, you don't have enough information to sign yet.



#### Check your understanding

1. Does paying your card's minimum avoid interest?
*Answer:* No. It only avoids falling behind; interest keeps being charged.

2. Payments of 70 for 24 months on a 1,000 loan. How much do you pay in total?
*Answer:* 1,680, because 70 × 24 = 1,680.


#### Remember

- Multiply the monthly payment by the number of payments.
- The minimum payment stretches the debt out.
- Add up all your "pay later" plans.



### Go deeper (5 more minutes)

#### APR

The **APR** is the yearly cost of credit calculated with official rules. It's used to compare loans with each other.

Check which fees it includes and which it doesn't. A loan with a lower APR usually costs less.



#### How a payment is split

A 1,000 loan at 1% a month with payments of 100.

| Month | Starting balance | Interest | Toward principal | Ending balance |
|---|---|---|---|---|
| 1 | 1,000.00 | 10.00 | 90.00 | 910.00 |
| 2 | 910.00 | 9.10 | 90.90 | 819.10 |
| 3 | 819.10 | 8.19 | 91.81 | 727.29 |

Interest is calculated on what's left to pay. That's why each month a little more goes to the principal.



#### Words on your card

| Type | Description | What it means for you |
|---|---|---|
| Statement closing date | The end of your statement period. | What you buy after goes on the next one. |
| Payment due date | The last day to pay without being late. | Pay before. |
| Grace period | If you pay the full balance on time, there's no interest on purchases. | It doesn't apply to cash advances. |
| Deferred interest | If you don't pay it off in time, you're charged all the accumulated interest. | It's not the same as 0%. |

#### Other products that commit your paychecks

"Buy now, pay later," rent-to-own and payday loans also commit your next paychecks.

Add up all your plans, not each one on its own.



#### Upfront fees

If you're lent 1,000 but 50 is kept as a fee, you receive 950. If you pay back 1,100, the cost is 150 on what you really received.

> **Good to know:** in California, rent-to-own has legal limits on the total price. Even so, it almost always costs much more than buying in cash or saving for a few months.



#### Buy now, pay later

"Pay in 4" apps usually don't charge interest if you pay on time, but they can charge late fees.

The risk is adding several plans at once and having them taken from your debit card when you don't have the balance.

Before using one, write down all the ones you already have and their dates.



#### Payday loans

Payday loans are small and are paid back on your next paycheck. They usually have a very high yearly cost.

In California they have limits on the amount and the fees, but they're still expensive. First ask your credit union about a small, low-cost loan.



#### Cases


**Case 1. Andrés's two loans**

A: he receives 1,000, pays 50 upfront and 12 payments of 95. B: he receives 1,000, no fee, 12 payments of 98.
- *How much does each one cost?* A: 50 + 1,140 = 1,190. B: 1,176.
- *Which is better?* B, which costs 14 less.


**Case 2. Daniela's oven**

The oven costs 900 in cash. The store offers payments of 70 a month for 24 months.
- *How much would she pay in total?* 1,680: 780 more than in cash.
- *What options does she have?* Save for a few months, look for a lower-cost loan from a credit union or buy a used one.


**Case 3. Rubén's plans**

Rubén has four "pay in 4" plans of 35 every two weeks.
- *How much does it add up to every two weeks?* 140, all together.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Comparing only the monthly payment | You pay much more in total | Add up all the payments |
| Paying only the minimum | The debt lasts years | Pay more than the minimum or the full balance |
| Believing deferred interest is 0% | You're charged all the interest at once | Pay it off before the date |
| Adding "pay later" plans without control | They eat up your paychecks | Write them all down in one place |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Loan A: 10 payments of 110 plus a 40 fee. B: 10 payments of 112. Which costs less? a) B (1,120) · b) A (1,140) · c) They cost the same
2. Does paying the minimum avoid interest? a) Yes · b) Yes, if you pay on time · c) No
3. Is deferred interest the same as 0%? a) Yes · b) No · c) Yes, if the store says so
**Answers:** 1-a: B costs 20 less. 2-c: it only avoids falling behind. 3-b: if you don't pay it off in time, they charge it all.



#### Put it into practice

Offer C has payments of 70 for 24 months, with no other fees, for the same 1,000. Is it cheaper?
**Answer:** No. 70 × 24 = 1,680. The payment is lower, but the total cost is much higher.



#### Your plan

Compare two offers for the same need: amount received, total, schedule, collateral and risks.



### Learn more

- **How credit card interest works** (CFPB · English and Spanish): https://www.consumerfinance.gov/ask-cfpb/ — **What to look for:** search for "grace period" and "deferred interest" to see examples with numbers.
- **Auto loans** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/auto-loans/ — **What to look for:** the tool to compare loan offers by total cost.

### Key words

- *APR:* the yearly cost of credit.
- *Amortization:* how the principal goes down with payments.
- *Minimum payment:* the least required each month.
- *Grace period:* time when you can avoid interest.

### Sources

[R28] CFPB, credit card interest · [R29] CFPB, grace period · California Karnette Rental-Purchase Act.

---

## M3 U06. Which debt do I start with?

**What you will be able to do:** Make a list of your debts and choose a strategy to pay them off.

**To start:** Mar has a credit card, a loan from a relative, a medical bill and a "pay later" plan. Each month she pays whatever pushes hardest and feels she never gets ahead. In this lesson you'll learn to see all your debts together and decide where to start.

### The essentials (5 minutes)

#### First, see them all together

When debts are spread out, it's easy to forget one or to pay first the one that calls the most.

A **debt list** is a list of all your debts. It helps you not forget payments and decide with information.



#### Three steps

1. **Write down every debt**, including medical, tax, family and remittance debts.
2. **Add up the minimum payments.**
3. **Compare** with what you can pay. Only if there's money left do you decide where to put extra.



#### Is there enough for the minimums?

You have 120 a month for debts. Your minimum payments add up to 80.
- What you can pay: **120**
- Minimum payments: **80**
- Extra money to pay down: **40**
If the result were negative, no extra-payment strategy would be enough: you need to negotiate or look for help (M3 U07).


#### Two strategies for the extra money

| Type | Description | What it means for you |
|---|---|---|
| Avalanche | The extra money goes to the debt with the **highest rate**. | It saves the most interest. |
| Snowball | The extra money goes to the debt with the **smallest balance**. | You close debts faster and it keeps you motivated. |

#### First, what puts the basics at risk

Sometimes the rate isn't what matters most. First take care of a debt that puts your housing, the car you use for work or a basic utility at risk. Also one that is already in court.

> **Key idea:** the best strategy is the one you can keep up. Both work if you pay all the minimums on time.



#### A case in one minute

Rubén owed 400 on his card at 28% and 150 to a friend, with no interest. He had 100 a month to pay.

He paid the 30 minimum on the card, 20 to his friend as agreed, and the extra 50 to the card. In seven months he paid off the card and kept going with his friend.



#### Do it this week

1. Make your list of debts with balance, rate and minimum payment.
2. Add up the minimums and compare them with what you can pay.
3. Choose avalanche or snowball for the extra money.



#### Check your understanding

1. Which strategy saves the most interest?
*Answer:* The avalanche, because it goes after the highest rate first.

2. Should you always pay the highest rate first?
*Answer:* No. First check the debts that put your housing, your job or your utilities at risk.


#### Remember

- Make a list of all your debts.
- Pay all the minimums on time.
- The extra money goes to one debt at a time.



### Go deeper (5 more minutes)

#### What to write down for each debt

| Item | Why it matters |
|---|---|
| Creditor | Who you pay |
| Type | Card, loan, medical, family |
| Balance | How much you owe |
| Rate | How much it costs you per year |
| Minimum payment and date | How much and when to pay |
| Past due | Whether you're already behind |
| Collateral | Whether you could lose an item |
| Verified contact | How to talk to the creditor |



#### Avalanche versus snowball with numbers

Three debts: card A of 2,500 at 27%, card B of 600 at 18% and a loan of 1,500 at 12%. Budget: 300 a month.

| Strategy | Order | Months | Total interest |
|---|---|---|---|
| Avalanche | A, B, loan | 18 | 715 |
| Snowball | B, loan, A | 19 | 912 |

The avalanche saves about 197. The snowball gives quick wins. Choose the one you can keep up.



#### Consolidate, refinance, settle

| Type | Description | What it means for you |
|---|---|---|
| Consolidate | Combine several debts into one. | Check the total cost. |
| Refinance | Change a debt's terms. | A lower payment doesn't always save money. |
| Settle for less | Pay less than you owe with an agreement. | It can affect your history and create taxes. |

#### Medical debts

Medical debts have special rules. Many small or paid medical bills no longer show up on credit reports.

Before paying a large medical bill, check whether you qualify for the hospital's financial assistance. You'll see it in M4 U08.

> **Good to know:** many nonprofit hospitals must offer discounts or forgive bills for people with low incomes. In California, ask about the hospital's fair pricing program.



#### Debts with family and friends

Debts with people close to you have no interest and no reporting, but they matter: they affect the relationship.

Include them in your list with the amount and the date you agreed on. If you can't pay on time, let them know beforehand and suggest a new date.



#### Cases


**Case 1. Mar's debts**

Debt A: 300 at 30%, minimum 30. Debt B: 1,000 at 15%, minimum 50. She has 120 for debts.
- *How much is left after the minimums?* 40, because 120 − 80 = 40.
- *Which one does she pay down?* A: it has the highest rate and the smallest balance. Both strategies agree.


**Case 2. Andrés's consolidation**

He's offered a lower payment, from 250 to 170, but from 12 to 24 payments.
- *How much does each option cost?* 250 × 12 = 3,000 versus 170 × 24 = 4,080.
- *Is it good for him?* It eases his monthly cash flow, but costs 1,080 more. Only if he really can't make the current payment.


**Case 3. Daniela's list**

Daniela made her list and found a 380 medical bill she had forgotten.
- *What does she do first?* She asks the hospital whether she qualifies for financial assistance before paying.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Paying first whatever pushes hardest | You forget important debts | Make your complete list |
| Skipping minimums to pay down one debt | Late payments and fees | Pay all the minimums first |
| Choosing a consolidation just for the payment | You pay more in total | Compare the total |
| Forgetting family and medical debts | Your plan isn't real | Include them in the list |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which strategy saves the most interest? a) Avalanche · b) Snowball · c) Paying only the minimums
2. Should you always pay the highest rate first? a) Yes · b) Yes, no exceptions, even if there are other consequences · c) No, check the consequences
3. Does a lower payment mean you pay less in total? a) Yes · b) Not necessarily · c) Yes, you always pay less
**Answers:** 1-a: it goes after the highest rate. 2-c: first what puts the basics at risk. 3-b: it can stretch out the term.



#### Put it into practice

A consolidation lowers your payment from 250 to 170, but stretches it from 12 to 24 payments. What do you compare?
**Answer:** The totals: 3,000 versus 4,080, plus fees. It eases your monthly cash flow, but costs 1,080 more.



#### Your plan

Make your debt list and write down two strategies and why you choose one. Don't plan new debt as a permanent solution.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "Debt log" tool to make your list.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the module on managing debt and the payment plan worksheet.

### Key words

- *Debt list:* a list of all your debts.
- *Consolidation:* combining debts into one.
- *Refinancing:* swapping one debt for another.

### Sources

CFPB, managing debt · CFPB, medical debt on credit reports.

---

## M3 U07. What do I do if I know I won't be able to pay?

**What you will be able to do:** Prepare a documented response when you can't pay, and know what to do about debt collection or a lawsuit.

**To start:** Andrés lost hours at work and knows his next card payment won't be covered. He's afraid to answer the bank's calls. In this lesson you'll learn to act before you fall behind and to defend yourself if you're being collected on.

### The essentials (5 minutes)

#### Don't wait until you're behind

Ignoring the due date doesn't make the problem go away. On the contrary: fees, interest and calls arrive.

If you know you won't be able to pay, talk to the creditor **before** the due date. Many companies have temporary plans, but they only offer them if you ask.



#### Three steps

1. **Calculate** what amount and what date are actually possible for you.
2. **Contact** the creditor through a verified channel and ask about your options.
3. **Keep in writing** what you agreed on.



#### Negotiating isn't begging

Asking for a change is **negotiating**. It's normal and it's your right to ask.

But an agreement you asked for isn't accepted until they confirm it, preferably in writing.



#### If a debt collector calls you

| Type | Description | What it means for you |
|---|---|---|
| Verify | Ask who they are, who they're collecting for and what debt it is. | Before giving information or paying. |
| Ask for validation | They must give you information about the debt in writing. | You usually have 30 days to dispute it. |
| They can't | Harass you, threaten you, lie to you or say they'll report you to immigration. | Report it to the CFPB. |

#### If you get court papers

A dispute with a credit agency does **not** stop a lawsuit.

If you get documents from a court, check the deadline to respond and get legal help right away. If you don't respond, a judgment can be entered against you and part of your wages can be taken.

> **Key idea:** court papers are never something to leave for later.



#### A case in one minute

Andrés called his bank a week before the due date. He explained his hours had been cut and asked whether there was any option.

They offered him a three-month temporary plan with a lower payment. He asked them to send it by mail before accepting.



#### Check your understanding

1. Does a dispute with a credit agency stop a lawsuit?
*Answer:* No. If you're sued, you have to respond to the court by its deadline.

2. A collector says they'll report you to immigration if you don't pay today. Is that legal?
*Answer:* No. It's a prohibited threat; you can report it to the CFPB.


#### Remember

- Talk to the creditor before you fall behind.
- Verify any collector before paying.
- If court papers arrive, get legal help now.



### Go deeper (5 more minutes)

#### Before you call, prepare

- Your current income.
- How much you can pay without giving up your needs, and for how long.
- Your documents: statements, letters, receipts.

Ask about the options, the fees, the effect on your report and how the agreement ends. Ask for the confirmation in writing.



#### The time limit to sue you

In California, the time a creditor has to sue you over a credit card debt or a written contract is usually **4 years**. It's called the statute of limitations.

If a collector contacts you about a very old debt, check the date first. In California, paying a debt that is already time-barred doesn't revive the right to sue you.

But **signing a new written promise to pay can**. The collector must tell you in writing if the debt is too old to sue over. Get guidance before you promise anything.

> **Good to know:** in California, debt collectors must be licensed by the DFPI, and there are special rules for debts sold to other companies. If a collector isn't licensed, report it.



#### Relief services

| Service | What it does | Keep in mind |
|---|---|---|
| Nonprofit credit counseling | Reviews your budget and options | Ask about costs and credentials |
| Debt management plan | The agency negotiates rates; you make one monthly payment | It may close your cards |
| Debt settlement | They negotiate paying less | Risk to your history and taxes; beware of upfront fees |
| Bankruptcy | A legal process | Requires an attorney |



#### Where to get legal help

The State Bar of California has a list of no-cost or low-cost legal aid services and certified lawyer referral services.

Many California courts have no-cost self-help centers that explain how to respond to a lawsuit.



#### What the written agreement should say

- The amount of each payment and the dates.
- How long it lasts.
- Whether interest or fees are charged during the plan.
- What happens at the end.
- How it will be reported to the credit agencies.

Keep a copy and write down each payment you make.



#### Your rights with debt collectors

Debt collectors can't call you before 8 in the morning or after 9 at night. They also can't call you at work if you tell them you can't take calls there.

You can ask them in writing to stop contacting you. That doesn't erase the debt, but it stops the calls.



#### Cases


**Case 1. Andrés's temporary agreement**

Andrés can pay 80 a month for three months, instead of 150.
- *What does he ask the bank?* "Is there a temporary option, how much will it cost, how will it affect my report and how will it be put in writing?"


**Case 2. The lawsuit**

Mar is disputing a debt with a credit agency and gets a court notice.
- *Does she wait for the dispute to finish?* No. She checks the court's deadline and gets legal help right away.


**Case 3. Rubén's old debt**

A collector calls Rubén about a phone debt from five years ago, from when he lived in another state.
- *What does he do?* He doesn't promise payments over the phone. He asks for the information in writing, checks the date and gets guidance before deciding.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not answering the creditor out of fear | The debt grows with fees | Call before the due date |
| Paying a collector without verifying | It may be a scam | Ask for validation in writing |
| Ignoring court papers | Judgment and wage garnishment | Respond by the deadline with legal help |
| Promising payments on a very old debt | You can make your situation more complicated | Check the date and get guidance |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a dispute with a credit agency stop a lawsuit? a) No · b) Yes · c) Yes, for 30 days
2. Can a collector threaten you? a) Yes · b) Yes, if the debt is old · c) No
3. Is an agreement you asked for already accepted? a) Yes · b) No, not until they confirm it · c) Yes, if you asked by phone
**Answers:** 1-a: the court has its own deadline. 2-c: it's prohibited. 3-b: you need the confirmation.



#### Put it into practice

You get a court notice while you're disputing information with a credit agency. Do you wait for the dispute to finish?
**Answer:** No. Check the court's deadline and get legal help right away.



#### Your plan

Create a file with facts, communications, options and dates. Find a legal aid service near you.



### Learn more

- **Debt collection: your rights** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/debt-collection/ — **What to look for:** the sample letters to ask for validation of a debt and to ask them to stop calling you.
- **Legal help in California** (State Bar of California · English and Spanish): https://www.calbar.ca.gov — **What to look for:** "Find Legal Help" at no cost or low-cost legal aid near you.
- **Court self-help centers** (California Courts · English and Spanish): https://selfhelp.courts.ca.gov — **What to look for:** "Debt lawsuits" to learn how to respond on time.

### Key words

- *Collections:* efforts to collect a debt.
- *Debt validation:* information the collector must give you.
- *Negotiate:* ask for a change in terms.
- *Statute of limitations:* the maximum time to sue you over a debt.

### Sources

[R08] CFPB, debt collectors · [R23] State Bar of California · California Code of Civil Procedure, time limits · California Code of Civil Procedure, section 360 · California Civil Code, section 1788.14 · DFPI, debt collectors.

---

## M3 U08. Can signing to help someone leave me with a debt?

**What you will be able to do:** Weigh the risks of signing, lending or taking on debt for your family, and help without putting your stability at risk.

**To start:** Mar's cousin asks her for a favor: "Just sign, I'll pay it." Mar loves him and trusts him. But that paper can turn her cousin's debt into her own. In this lesson you'll learn what to check before signing and other ways to help.

### The essentials (5 minutes)

#### Signing for someone else means committing to pay

When you sign as a **cosigner**, you promise to pay if the other person doesn't.

For the lender, that debt is yours too. They can collect from you, even if you don't use the car, the card or the money.

> **Key idea:** a family promise doesn't change the contract. If the contract says you're responsible, you're responsible.



#### Three ways of helping that can leave you with a debt

| Type | Description | What it means for you |
|---|---|---|
| Cosigning a loan | You sign together with the other person. | You pay it all if they don't, and late payments damage your credit report. |
| Lending your credit card | The other person buys with your card. | Everything they spend is in your name. |
| Sharing your password | The other person gets into your bank or app. | They can move your money, and the bank may not reimburse you. |

#### Do the math before you sign

You earn 2,400 a month. After your expenses you have 150 left over. Your cousin asks you to cosign a car with a 180 monthly payment.
- What you have left over: **150**
- The payment if your cousin stops paying: **180**
- What you'd be short each month: **−30**
And that's without counting late fees. In this case, signing puts your rent at risk.


#### Before you sign, follow three steps

1. **Read what responsibility you're taking on.** Ask for the contract and the cosigner notice.
2. **Calculate what would happen if the other person doesn't pay.** Could you pay the full payment each month, on top of your expenses?
3. **Decide with that information.** If you couldn't pay it, don't sign, even if someone you love asks you.



#### Five questions before you sign

1. What is the monthly payment and for how many months?
2. If the other person stops paying, can I pay it all myself?
3. Will they give me the cosigner notice and a copy of the contract?
4. How will I find out if there's a late payment?
5. Is there another way to help that doesn't leave me with a debt?



#### Another way to help

You can offer an amount you can give without needing it back.

You can also help with information: go with your relative to compare options or look for a credit union.

Saying "no" or offering another kind of help is also caring for your family.

> **Before you act, check:** if someone threatens you or forces you to sign, put your safety first. You'll see it in M4 U05.



#### Check your understanding

1. Your brother promises he'll pay the loan you cosign. Does that protect you?
*Answer:* No. If the contract says you're responsible, the lender can collect from you.

2. You have 150 left over a month and are asked to cosign a 180 payment. What does the math tell you?
*Answer:* That if the other person doesn't pay, you'd be 30 short each month. Signing puts your basic expenses at risk.


#### Remember

- Signing, lending your card and sharing your password can leave you with a debt.
- Do the math before you sign, not after.
- Helping with an amount you could give away is safer than signing.



### Go deeper (5 more minutes)

#### What being a cosigner means

The lender agrees to make the loan because you're responsible too. This means that:

- **They can collect from you** if the other person falls behind, sometimes without trying to collect from them first.
- **Late payments can show up on your credit report**, even if you don't use what was bought.
- **The debt counts as yours** when you apply for your own loan, and it can lower what you're lent.
- **Getting out of the contract isn't easy.** It usually ends only when the debt is paid off or refinanced without you.

Federal law requires many lenders to give you a cosigner notice before you sign. The FTC explains your risks in [Cosigning a Loan FAQs](https://consumer.ftc.gov/articles/cosigning-loan-faqs).

> **Good to know:** in California, the law requires the «Notice to Cosigner» to be given in English and in other languages, including Spanish. If you didn't get it, ask for it before you sign.



#### Ways to help: risks and alternatives

| Way to help | Who owes | Risk to you | Safer alternative |
|---|---|---|---|
| Cosigning a loan | You and the other person | Paying the whole balance and damage to your credit | Help with an amount you don't need back |
| Lending your credit card | You | Everything spent is in your name | Pay directly for one specific purchase yourself |
| Adding someone as an authorized user | You | Their spending adds to your debt | Set a spending limit or don't add them |
| Lending cash | The other person owes you | That they don't pay you back and you come up short on your expenses | Lend only what you could give away |
| Giving your details as a reference | The other person | None: a reference doesn't sign or promise to pay | Confirm they only want your details, not a signature |



#### A reference isn't a cosigner

When someone applies for a card, a loan or a rental, they're asked for references: names and phone numbers of people who know them. Being a reference doesn't obligate you to pay.

The federal Fair Debt Collection Practices Act (FDCPA) only lets a collector ask you how to locate that person. They can't tell you that person owes a debt, and they can't charge you. If they pressure you, write down the details and submit a complaint to the CFPB.



#### If you decide to lend money to a relative

Agree on these points in writing, even if it's just a message:

1. The exact **amount**.
2. **Schedule:** how much and when it's paid back.
3. **What happens if a payment is late:** is the date changed or paused?
4. **How each payment is recorded:** a shared note or receipts.

> **Key idea:** lend only what you could give away without falling behind on your rent, food and debts. That way, if you're not paid back, the relationship suffers, but not your stability.



#### A remittance you pay for later

Some services let you send today and pay later. If you send 200 today and have to pay 230 in a month, write two events on your calendar:

- today 200 goes out;
- in a month 230 goes out.

If your family promises to pay you back 100, don't count that money until there's a confirmed date and ability to pay.

Ask yourself: if I'm not paid back, which bill goes unpaid?



#### Passwords and access to your accounts

Never share your login information, not even with your family.

Anyone who logs in with your information can move your money, take out loans in your name and change your contact information.

Also, the bank may refuse to reimburse you because you "authorized" the access.

If someone needs to help you review a debt, look at it together on your screen.



#### Pressure and control

Asking for help is normal. There's pressure or control when someone:

- threatens you if you don't sign;
- takes your documents;
- controls your income;
- forces you to take on debt.

In those cases, put your safety first (M4 U05). Saying no or negotiating a different amount is part of planning, not a lack of love.



#### Never use your children's information

Sometimes, out of need, some families open electric, phone or credit accounts using their children's name or number.

That can damage the child's credit history before they turn 18, and will cause them problems when they want to rent or study.

If you find out someone opened accounts with a minor's information, you can **freeze their credit at no cost** at all three agencies. Report it at IdentityTheft.gov too.



#### Cases


**Case 1. Mar's cousin**

Mar cosigns a car loan of 180 a month because "my cousin will pay it." Four months later, he loses his job.
- *What happens now?* The lender collects from Mar, and the late payments show up on her credit report.
- *What should she have done beforehand?* Include those 180 in her budget as a risk scenario. If they didn't fit, the answer was not to sign.
- *What can she do today?* Talk to the lender before falling behind (M3 U07) and agree on a plan with her cousin in writing. If she has questions about her rights, she can check with the [CFPB](https://www.consumerfinance.gov).


**Case 2. The password**

A relative asks Alex for the bank password to "manage" a debt.
- *What does Alex suggest?* Reviewing the information together on Alex's own phone, without sharing the password.


**Case 3. The loan to her sister**

Daniela lends her sister 500. They agree by message that her sister will pay 100 a month for 5 months. In the third month, her sister can only pay 50.
- *Why doesn't Daniela fall behind on her rent?* Because she only lent what she could give away.
- *What do they do?* They adjust the schedule in writing: 50 this month and the rest the next month.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Signing because "it's just a formality" | You're obligated to pay the whole debt | Read the cosigner notice and calculate whether you could pay |
| Lending without dates or amounts | Misunderstandings and money that doesn't come back | Agree on everything in writing, even in a message |
| Counting on money you were promised back | You come up short on your own bills | Count it only when you receive it |
| Sharing passwords "out of trust" | You lose control of your account and the bank's protection | Review together, without sharing login information |
| Opening services or credit in your children's name or number | You damage their history before they turn 18 | Never use their information; if it already happened, freeze their credit |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can cosigning make you responsible for the whole debt? a) Yes · b) No · c) Only for half
2. Does a family promise change the contract with the bank? a) Yes · b) Yes, if it's in writing between you · c) No
3. Is it wise to share your password to help? a) Yes · b) No · c) Yes, if it's family
**Answers:** 1-a: the lender can collect all of it from you. 2-c: the contract is what counts. 3-b: you lose control and the bank's protection.



#### Put it into practice

You have 220 left over a month. Your aunt asks you to cosign a loan with a 160 monthly payment for 2 years. Could you cover it if she stops paying? What would you do?
**Answer:** You could cover it, but you'd have only 60 left over a month for 2 years, with no margin for emergencies. Before signing, ask for the cosigner notice, agree on how she'll let you know about a late payment and consider helping with an amount you can give away.



#### Your plan

Write what support you can give without putting your expenses at risk, what information you're missing to decide and what you'll do if your situation changes.



### Learn more

- **Cosigning a loan FAQs** (FTC · English): https://consumer.ftc.gov/articles/cosigning-loan-faqs — **What to look for:** what happens if the other person doesn't pay and the text of the cosigner notice they must give you before you sign.
- **Debt collection** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/debt-collection/ — **What to look for:** your rights if you're being collected on for a debt you signed.
- **Child identity theft** (FTC · English and Spanish): https://www.identitytheft.gov — **What to look for:** the section for children and how to freeze a minor's credit.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the module on loans and credit, to calculate whether a payment fits your budget.

### Key words

- *Cosigner:* a person who is responsible for someone else's debt.
- *Authorized user:* a person who can use your card; the debt is yours.
- *Login information:* your username and password; never shared.
- *Credit freeze:* a no-cost block on your report so nobody can open accounts in your name.

### Sources

FTC, Cosigning a Loan FAQs · CFPB, debt collection.

---

## M3 U09. Does a tanda help me build credit?

**What you will be able to do:** Compare the traditional tanda with lending circles that report to the credit agencies, and use both with less risk.

**To start:** Mar has been in tandas with her friends for years. She always keeps her word and has never missed a payment. When she applied for a card, she was told she had no credit history. All those years of on-time payments didn't show up anywhere. In this lesson you'll learn how to make your tanda count too.

### The essentials (5 minutes)

#### What a tanda is

In a **tanda**, each person puts in a fixed amount and, taking turns, each one receives the total.

It's a way of saving and lending among people who trust each other, very common in our communities.



#### How it works with numbers

10 people put in 100 every week. Each week one of them receives the total.
- What each person puts in: **100**
- What the other 9 put in: **900**
- What one person receives each week: **1,000**
Whoever receives first gets a loan with no interest. Whoever receives last is saving.


#### A traditional tanda doesn't build credit

Even if you pay on time for years, a traditional tanda **doesn't show up on your credit report**. Nobody reports your payments to the agencies.



#### A lending circle can

A **lending circle** works like a tanda, but it's organized by a nonprofit with a contract. Many **report your payments** to the credit agencies.

That way, what you already do in a tanda also helps you build a history, without paying interest.



#### Before joining a tanda

1. **Write down** how much you put in, how often and which turn you receive.
2. **Add up** how much you'll put in in total.
3. **Ask yourself** what happens if someone stops paying.

> **Key idea:** don't put money you need for the basics into a tanda.



#### A case in one minute

Rosa organizes a tanda with her neighbors in Fresno: eight people, 50 a week. To avoid problems, she writes everything down in a notebook, and each person signs when they pay in and when they receive.

The tanda also has a rule: whoever has been in the group the longest receives first.



#### Check your understanding

1. Does a traditional tanda build credit history?
*Answer:* No. Nobody reports your payments to the agencies.

2. What does whoever receives first in a tanda get?
*Answer:* A loan with no interest: they receive it all and pay later.


#### Remember

- A traditional tanda is saving and lending, but it doesn't build a history.
- An organized lending circle can report your payments.
- Write down turns and payments.



### Go deeper (5 more minutes)

#### Risks of a tanda

| Type | Description | What it means for you |
|---|---|---|
| Someone stops paying | Whoever already received may disappear. | The others lose. |
| The organizer disappears | They take the money. | There's nobody to complain to. |
| Your turn comes late | You need it earlier and can't move it up. | You have to wait. |
| No contract | Everything is by word of mouth. | No legal protection if something goes wrong. |

#### Tanda and lending circle

| | Traditional tanda | Organized lending circle |
|---|---|---|
| Interest | No | Usually no |
| Contract | Informal | Yes |
| Reports to the agencies | No | Yes, in many programs |
| If someone doesn't pay | The others lose | The organization has rules |
| With an ITIN | Yes | Many programs accept an ITIN |



#### To lower the risks of a tanda

- Take part with people you trust.
- Write down the names, turns, dates and payments, and share it with everyone.
- Ask for an early turn if you know you'll need the money.
- Keep a small separate cushion in case someone fails.

> **Good to know:** Mission Asset Fund, a California organization, runs no-interest lending circles that report to the credit agencies. Their on-time payments have helped thousands of people build credit.



#### Using both together

You don't have to leave your tanda. You can keep your trusted group and, at the same time, join a lending circle that reports.

That way you keep the tradition that already works and also build a history.



#### The tanda and saving

If you get the last turn, the tanda works as saving with no interest. If you get the first, as a loan with no interest.

If you only want to save, an insured savings account pays you some interest and doesn't depend on others paying.



#### Cases


**Case 1. Mar's tanda**

Mar is in a tanda of 10 people, 100 a week, and she has turn 8. In week 5 she needs money for an emergency.
- *Can she move up her turn?* No, unless someone agrees to swap.
- *What will she do next time?* Ask for an early turn or set aside a cushion.


**Case 2. Rubén's circle**

Rubén joins an organized lending circle, with his ITIN.
- *What happens a few months later?* His on-time payments show up on his credit report. He now has a history.


**Case 3. Daniela's tanda**

In Daniela's tanda, one member stopped paying after receiving.
- *What did they learn?* To write everything down, to give the first turns only to the most trusted people and to keep a small group cushion.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing the tanda builds credit | Years of payments that don't count | Look for a circle that reports |
| Joining without writing anything down | Conflicts and losses | Write down turns and payments |
| Putting in your rent money | You're left without the basics | Put in only what you can save |
| Trusting an organizer you don't know | They may disappear with the money | Take part with people you trust |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a traditional tanda build credit history? a) No · b) Yes · c) Yes, if it has more than 10 people
2. Whoever receives first in a tanda gets…? a) A profit · b) A penalty · c) A loan with no interest
3. Can an organized circle report to the agencies? a) No · b) Yes · c) Only if it's run by a bank
**Answers:** 1-a: nobody reports your payments. 2-c: they receive it all before paying. 3-b: many programs do.



#### Put it into practice

A tanda of 12 people, 50 a week. You have turn 3. How much do you receive and how much do you put in in total?
**Answer:** You receive 600 (12 × 50) and put in 600 in total (12 weeks × 50). Before receiving, you put in 150.



#### Your plan

If you're in a tanda, write down the members, turns and dates. Look into a lending circle that reports to the agencies.



### Learn more

- **Lending circles** (Mission Asset Fund · English and Spanish): https://www.missionassetfund.org/lending-circles/ — **What to look for:** how it works, how much is lent, whether they accept an ITIN and how to sign up.
- **Credit reports and scores** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** how to check later that your payments already show up on your report.

### Key words

- *Tanda:* rotating savings among people.
- *Lending circle:* an organized social loan that can report to the agencies.
- *Turn:* the moment when it's your turn to receive.

### Sources

[R43] Mission Asset Fund, lending circles.

---

## M3 U10. What's my next step with credit?

**What you will be able to do:** Choose your credit path and build a 30- to 90-day plan.

**To start:** Rubén has no history. Andrés has an error in his report. Mar has a card with a high balance. Daniela has an account in collections. All four want to "improve their credit," but each one needs something different. In this lesson you'll choose your own path.

### The essentials (5 minutes)

#### Each situation has its own path

Having no history, having an error and having late payments are different situations. Each one needs a different action.

Opening a card isn't the answer for everyone.



#### Choose your path

| Type | Description | What it means for you |
|---|---|---|
| No history | A product that reports to all three agencies, without locking up your savings. | M3 U03 and U09. |
| Error in your report | A specific dispute with proof. | M3 U02. |
| High balances | Lower your utilization and organize your payments. | M3 U04 and U06. |
| Late payment or collections | Verify the debt and negotiate or get counseling. | M3 U07. |
| Stable situation | Pay on time and check your report every year. | Keep the routine. |

#### Three steps

1. **Describe your situation** without judging yourself.
2. **Choose the action** that fits.
3. **Give it a date** and a way to prove you did it.



#### Measure actions, not points

"I'm going to raise my score 80 points" doesn't depend only on you. "I checked my report and filed a dispute with a confirmation number" does.

Checking your report is a completed action even if your score doesn't change right away.

> **Key idea:** asking for help in time is a skill, not a failure.



#### A case in one minute

Rubén has no history. In week 1 he asks two credit unions about secured cards with an ITIN. In week 3 he compares costs. On day 30 he chooses a card that reports to all three agencies and asks his landlord to report his rent.

At 90 days he checks his report: his first payments already show up.



#### Do it this week

1. Write your credit situation in one sentence.
2. Choose your path in the table.
3. Write down your first action with a date and how you'll prove it.



#### Check your understanding

1. Which improvement can you prove: "I'll raise my score 80 points" or "I checked my report and filed a dispute with a confirmation number"?
*Answer:* The second: it's your own action with evidence.

2. Is opening a card always the first step?
*Answer:* No. It depends on your situation.


#### Remember

- Identify your situation before acting.
- Measure your actions, not only your score.
- Review your plan at 30 and 90 days.



### Go deeper (5 more minutes)

#### Connect your statement with your plan

| Item | Amount |
|---|---|
| Starting balance | 1,000 |
| Interest | +20 |
| New purchases | +100 |
| Your payment | −150 |
| **Ending balance** | **970** |

You paid 150, but the debt only went down 30, because there was interest and new purchases. Always check all the items before judging your strategy.



#### Review at 30 and 90 days

At each review write down:

- the action you took;
- the answer you got;
- what it cost you;
- the obstacle you found;
- your next step.



#### Protect what you built

Once you have a history, take care of it:

- set up automatic minimum payments and pay the rest manually;
- check your no-cost reports every few months;
- freeze your credit if you don't plan to borrow soon (M4 U04).

> **Good to know:** negative information doesn't stay on your report forever. Meanwhile, every on-time payment works in your favor.



#### What's next

In Module 4 you'll learn to protect your money, your identity and your family: scams, identity theft, insurance and a plan for emergencies.



#### What you achieved in this module

Now you know how to tell approval from ability to pay, read your report and build a history without going into debt. You can recognize repair scams and compare loans by total cost. You can also organize your debts, negotiate, protect yourself from collectors, sign carefully and make your tanda count.



#### If you feel overwhelmed

If your debts keep you up at night, you're not alone. A nonprofit credit counseling agency can review your case at no cost or at low cost.

Asking for help in time avoids bigger problems.



#### Cases


**Case 1. Mar's balance**

Starting balance 1,000; interest 20; new purchases 100; payment 150.
- *What is the ending balance?* 970.
- *Why did it go down so little?* Because of the interest and the new purchases. If she stops using the card while she pays, the balance will go down faster.


**Case 2. Andrés's error**

Andrés disputes the card he didn't open and freezes his credit.
- *How does he know he made progress?* He has the dispute confirmation number and the freeze confirmation, even if the answer takes 30 days.


**Case 3. Daniela's collection account**

Daniela has a medical bill in collections.
- *What is her first step?* Ask for validation of the debt in writing and ask the hospital about financial assistance.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Using the same recipe for everyone | The action doesn't solve your case | Identify your path |
| Measuring progress only by your score | You get discouraged | Measure completed actions |
| Paying and still buying with the card | The debt barely goes down | Stop using it while you pay |
| Not reviewing the plan | You lose your way | Review at 30 and 90 days |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which improvement can be proven? a) "I checked my report and filed a dispute with a confirmation number" · b) "I'll raise my score 80 points" · c) "I'll have good credit before the end of this year"
2. Is opening a card always the first step? a) Yes · b) Yes, the more cards the better · c) No
3. Balance 800, interest 16, purchases 90, payment 120. Ending balance? a) 680 · b) 786 · c) 920
**Answers:** 1-a: it's an action with evidence. 2-c: it depends on your situation. 3-b: 800 + 16 + 90 − 120 = 786.



#### Put it into practice

Write your credit situation in one sentence and your first action with a date.
**Answer:** For example: "I have no history. On October 15 I'll ask two credit unions about secured cards with an ITIN that report to all three agencies."



#### Your plan

Turn in your Module 3 file: chosen path, a sample report with notes, a comparison of two financing options, debt list, two scenarios and a payment calendar. Also solve integrated case E3 in the support materials.



### Learn more

- **No-cost credit reports** (AnnualCreditReport.com · English and Spanish): https://www.annualcreditreport.com — **What to look for:** request your three reports and write down the date for your next review.
- **Credit reports and scores** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** the list of steps to build and protect your credit.

### Key words

- *Credit path:* the way forward based on your situation.
- *Scenarios:* possible versions to test your plan.

### Sources

CFPB, credit reports and scores · FTC, credit freezes.

---

## M3 U11. Is a paycheck advance money at no cost?

**What you will be able to do:** Compare your employer's advance, apps that advance your pay and payday loans, and calculate what they cost over a year.

**To start:** Rubén is 200 dollars short for rent and gets paid in four days. An app offers to advance it "with no interest," with a "suggested tip" of 8 dollars and 4 more to get it instantly. His friend recommends a payday loan.

### The essentials (5 minutes)

#### Three ways to get paid early

| Type | Description | What it means for you |
|---|---|---|
| Employer advance | Part of what you already worked, paid early. | Ask HR. |
| Advance app | "Tips," express fees or a membership. | Add it all up. |
| Payday loan | Very high fees and a two-week term. | Avoid it. |
| Your emergency fund | No cost. | The first option (M4 U06). |

#### What a "no-interest" advance costs

An 8-dollar tip plus a 4-dollar express fee is 12 dollars to advance 200 for four days. If you do it every two weeks, that's **312 dollars a year**. And your next check arrives 200 short, so it's easy to need another advance.



#### The payday trap

A payday loan charges fees that, over a year, often top 300%, and it's due in full on your next check. If you can't pay, you "roll it over" and pay fees again. Some states limit or ban them.



#### A case in one minute

Rubén asked at work: his employer advances up to half of what he's already earned, at no cost, once a month. He got the 200 there and started setting aside 20 dollars per check for his fund so he won't need it again.

> **Key idea:** an advance isn't extra money: it's your own pay, earlier. Add up a year of tips and fees, and ask your employer first.



#### Check your understanding

1. Is a "no-interest" advance app always at no cost?
*Answer:* Not always: tips, express fees and memberships cost money.

2. What happens to your next check after an advance?
*Answer:* It arrives with less money.


#### Remember

- Ask your employer first.
- Add up the yearly cost.
- Avoid payday loans.



### Go deeper (5 more minutes)

#### Add up a year

| Item | Per advance | Times a year | Total |
|---|---|---|---|
| Tip | 8 | 26 | 208 |
| Express fee | 4 | 26 | 104 |
| **Total** | 12 | 26 | **312** |



#### Be careful giving access to your account

These apps ask to connect to your bank account to collect automatically. If there's no balance, you may pay overdraft fees. Check the date they collect.



#### If you're already in the cycle

Lower the amount little by little: ask for 150 instead of 200, then 100, until you stop. Meanwhile, build your fund, even 10 dollars per check.



#### Cases


**Case 1. Rubén's app**

The app charges Rubén 12 dollars to advance 200 every two weeks.
- *How much does he pay a year?* 312 dollars.
- *What does he do?* He asks whether his employer advances pay at no cost and builds his fund.


**Case 2. Alex's payday loan**

Alex is offered a 400-dollar payday loan.
- *What does he do?* He looks for another option: payday loans roll over and fees add up.


**Case 3. Daniela's overdraft**

Daniela's app collected when she had no balance.
- *What does she do?* She changes the collection date and stops using it.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking it costs nothing | You pay hundreds a year | Add up tips and fees |
| Advancing every check | Your full pay never arrives | Lower the amount |
| Rolling over a payday loan | Fees pile up | Avoid it |
| Granting access without checking | Overdrafts | Check the collection date |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Alex and Daniela. Choose the best decision in each; if you miss, you can try again. Earns experience points.



#### Quiz

1. Where do you ask first for an advance? a) In an app · b) Your employer · c) A payday lender
2. 10 dollars per advance, 26 times a year. How much do you pay? a) 260 · b) 10 · c) 130
3. What happens to your next check after an advance? a) It arrives in full · b) It comes with a bonus · c) It arrives with less money
**Answers:** 1-b: many employers do it at no cost. 2-a: 10 × 26. 3-c: you already received that part.



#### Put it into practice

An app charges a 9.99 monthly membership plus 3 per express advance. You use 2 express advances a month. How much do you pay a year?
**Answer:** 9.99 + 6 = 15.99 a month; × 12 = 191.88 dollars.



#### Your plan

If you use an advance app, review last month's transactions and add up everything it charged you.



### Learn more

- **Payday loans and advances** (CFPB · English and Spanish): https://www.consumerfinance.gov — **What to look for:** "payday loans."
- **Nonprofit credit counseling** (NFCC · English and Spanish): https://www.nfcc.org — **What to look for:** "credit counseling."

### Key words

- *Paycheck advance:* getting part of what you already earned before payday.
- *Payday loan:* a small, very expensive loan due on your next paycheck.

### Sources

CFPB · NFCC, accessed September 30, 2026.

---

## M3 U12. Is pawning a good way out?

**What you will be able to do:** Understand how a U.S. pawn shop works, what it costs and what happens if you don't pay.

**To start:** Mar needs 300 dollars for a car repair. Her sister-in-law tells her to pawn her gold chain: "they give you the money in ten minutes and don't check your credit."

### The essentials (5 minutes)

#### How it works

1. You leave something valuable and get a **pawn ticket**.
2. They lend you only part of what it's worth.
3. You have a deadline to repay the loan plus fees and get it back.
4. Many shops let you **extend** by paying only the fees.
5. If you don't pay, the shop **keeps your item** and sells it.



#### Mar's chain

- Loan: **300**
- One month of fees: **75**
- To get it back: **375**
Fees vary by state; ask for them in writing before you sign.


#### The good and the bad

They don't check your credit and, if you don't pay, **they don't chase or report you**: you just lose the item. But it doesn't build your credit history either, and fees are usually high. Pawn shops need a state license.



#### A case in one minute

Mar compared: the shop would let her pay for the repair in two parts at no charge. So she didn't pawn her chain. She keeps pawning only for an emergency with no other option.

> **Key idea:** pawning doesn't affect your credit, but it's expensive and you can lose your item. Get the fees in writing, keep your ticket and note the deadline.



#### Check your understanding

1. What happens if you don't repay a pawn loan?
*Answer:* The shop keeps your item; it isn't reported to your credit.

2. Does pawning build your credit history?
*Answer:* No.


#### Remember

- Get the fees in writing.
- Keep your ticket.
- Note the deadline.



### Go deeper (5 more minutes)

#### Pawn versus other options

| Option | Upside | Risk |
|---|---|---|
| Pawn | Fast, no credit check | High fees, you lose the item |
| Payment plan with the shop or provider | Sometimes no charge | You have to ask |
| Credit union loan | Lower fees | Takes longer |
| Your emergency fund | No cost | You need to build it first |



#### What they ask for

They'll ask for ID. Check the ticket: shop name, description of your item, amount, fees and deadline.



#### Don't pawn what you use for work

If you pawn your tools or the phone your job calls you on, you can lose income as well as the item.



#### Cases


**Case 1. Mar's chain**

Mar needs 300 for the car.
- *What does she do first?* She asks the shop about a payment plan.


**Case 2. Andrés's tools**

Andrés wants to pawn the tools he uses for weekend jobs.
- *What does he do?* He doesn't pawn what he uses for work.


**Case 3. Rubén's ticket**

Rubén pawned his watch and lost the ticket.
- *What does he do?* He goes to the shop with his ID and asks for a copy.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Signing without asking the fees | You overpay | Get them in writing |
| Losing the ticket | Harder to get your item back | Take a photo |
| Forgetting the date | You lose your item | Write it down |
| Thinking it builds credit | You still have no history | Use another path (M3 U03) |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Mar, Andrés and Rubén. Choose the best decision in each; if you miss, you can try again. Earns experience points.



#### Quiz

1. If you don't repay a pawn loan, what happens to your credit? a) Nothing changes; you lose the item · b) It's reported as a debt in collections · c) Your bank account is frozen
2. Does pawning build your history? a) Yes · b) Only if you pay on time · c) No
3. What do you ask for before pawning? a) Nothing · b) The fees and the deadline in writing · c) An extra loan
**Answers:** 1-a: the shop keeps the item. 2-c: it isn't reported. 3-b: so you know what you'll pay.



#### Put it into practice

You're lent 250 with fees of 20% a month. How much do you pay to get it back in two months?
**Answer:** 20% of 250 = 50 a month; 100 in two months. You pay 350.



#### Your plan

Write three options in your plan for an emergency before pawning: your fund, a payment plan and a credit union.



### Learn more

- **Consumer protection** (CFPB · English and Spanish): https://www.consumerfinance.gov — **What to look for:** "small-dollar loans."
- **Your state's licenses** (your state's financial regulator · English) | What to search: "pawnbroker license" and your state's name.

### Key words

- *Pawn ticket:* the receipt for your pawn, with the amount, fees and deadline.
- *Extend:* pay only the fees to get more time.

### Sources

CFPB · state financial regulators, accessed September 30, 2026.

---


# Part 5. Module 4. Protect your money, your identity and your family

## M4 U01. Why is someone pushing me to act right now?

**What you will be able to do:** Recognize how scams work and verify on your own before you act.

**To start:** Rosa got a message: "Your account will be locked in 20 minutes. Confirm your code." Her heart started racing. She was about to answer when her granddaughter said: "Grandma, wait." In this lesson you'll learn to recognize rushing as the scammer's tool.

### The essentials (5 minutes)

#### Rushing is the trap

A scam wants you to act before you think. That's why it uses urgency, fear, love or a gain that sounds too good.

You don't need to prove that a message is fake to give yourself time to check it. If someone won't let you think, that's already a sign.



#### Phrases that deserve a pause

| Type | Description | What it means for you |
|---|---|---|
| "Today only" or "you have 20 minutes" | They create urgency so you don't compare. | Stop. |
| "Don't tell anyone" | They isolate you so nobody warns you. | Tell someone you trust. |
| "Give me the code you received" | With it they get into your account. | Never share it. |
| "Pay with gift cards or cryptocurrency" | These payments are almost impossible to get back. | No serious company charges that way. |

#### Four steps for any suspicious message

1. **Stop.** Don't pay, don't click and don't give information.
2. **Identify what they're asking for:** money, a code, your information or to install something.
3. **Verify on your own,** with a contact you already knew or by looking up the official website yourself.
4. **Decide with information.**



#### What "verify on your own" means

It means using a number or a website that **you** looked up, not the one in the message.

For example: if the message says it's from your bank, call the number on the back of your card.

> **Key idea:** knowing your name or part of your account number doesn't prove they're legitimate.



#### A case in one minute

Rosa hung up, waited and called the number on her card. The bank told her that her account was fine and that they never ask for codes by text.

Now she has a rule: "I never pay or give codes on the first call or message."



#### Do it this week

1. Write your pause rule and stick it next to your phone.
2. Write down on paper the official numbers of your bank and your phone company.
3. Tell your family which scams are going around.



#### Check your understanding

1. A message says it's from your bank and includes a number to call. Which one do you call?
*Answer:* The one you look up, for example the one on your card. Never the one in the message.

2. Will your bank ask you for the code you got by text?
*Answer:* No. That code is only for you.


#### Remember

- Rushing and secrecy are signs of a scam.
- Always verify through a channel you looked up.
- Never share codes or pay with gift cards.



### Go deeper (5 more minutes)

#### Things that prove nothing

- **The browser padlock** only says the connection is encrypted, not that the website is honest.
- **A nice-looking website**, a paid ad or testimonials don't prove anything either.
- **Knowing your name** or your last digits: that information leaks or is bought.



#### Common scams

| Scam | How it works |
|---|---|
| Fake job | They hire you fast and ask you to pay for training or forward money |
| Rental that doesn't exist | They ask for a deposit on an apartment that isn't theirs |
| Fake immigration help | They promise guaranteed papers (M4 U02) |
| Fake tax notice | They say they're the IRS and demand immediate payment |
| Online romance | After weeks of trust, they ask for money |
| "Guaranteed" investment | They promise high gains with no risk |
| Family emergency | A voice or message asks for urgent money (M2 U11) |



#### The overpayment check

They send you a check for more than agreed and ask you to return the difference.

The money shows as available in your account, but the check bounces days later. You lose what you sent, and the bank can charge you for the check too.



#### Buying on social media

Many scams happen on Marketplace, WhatsApp groups or ads.

If you buy from a stranger, prefer seeing the item in person, in a public place. Or pay with a credit card, which has more protection.

> **Good to know:** according to the FTC, people in the U.S. reported fraud losses of more than 10 billion dollars in a single year. Reporting, even if you didn't lose money, helps stop scammers.



#### Where to report

Report at **ReportFraud.ftc.gov**. If you lost money, also tell your bank right away and, if it happened online, the FBI's IC3.



#### Protect your family

Older people and young people who just arrived are often targets of scams.

Talk with your family about the most common scams and agree on a simple rule. Nobody pays or gives codes without first checking with another family member.



#### Cases


**Case 1. The job with a check**

An "employer" sends Alex a check to buy equipment and asks Alex to transfer part of it to a "supplier."
- *What does Alex do?* Verifies the company independently and checks with the bank before moving any money.
- *What does Alex find out?* The job didn't exist. It was the overpayment check scam.


**Case 2. The message from the bank**

Rosa gets: "Your account will be closed in 20 minutes, send the code."
- *What does she do?* She doesn't share the code and calls the number on her card.


**Case 3. Daniela's rental**

Daniela found a cheap apartment on social media. The "owner" asked her for the deposit by Zelle before she saw it, because he "was out of town."
- *What should she do?* Not pay without seeing the place and without verifying that the person is the owner or manager.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Acting in a hurry | You pay or give information to a scammer | Apply your pause rule |
| Calling the number in the message | You talk to the scammer | Look up the official number yourself |
| Believing the padlock proves it's real | You give information on a fake website | Check the website address |
| Not reporting out of embarrassment | The scam keeps going with others | Report at ReportFraud.ftc.gov |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Rosa and Alex. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which number do you call to verify? a) The one in the message · b) The one you look up yourself · c) The one in the email
2. Does the browser padlock prove a website is honest? a) No · b) Yes · c) Yes, if it's green
3. Will a bank ask you for the code you got by text? a) Yes · b) Yes, if they call from the bank's number · c) No
**Answers:** 1-b: the one in the message may be fake. 2-a: it only shows an encrypted connection. 3-c: the code is only for you.



#### Put it into practice

A message says your bank will close your account in 20 minutes if you don't give a code. What do you do?
**Answer:** You don't share the code or use the link. You call the bank at a number you know. If you already shared it, follow the steps in M4 U04 right away.



#### Your plan

Write your pause rule, for example "I never pay or give codes on the first call," and two contacts for verifying.



### Learn more

- **Consumer advice** (FTC · English): https://consumer.ftc.gov — **What to look for:** the "Scams" section with the most common types and their signs.
- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov — **What to look for:** the form to report a message, a call or a loss of money.
- **Scams against immigrants** (FTC · English and Spanish): https://consumer.ftc.gov/features/scams-against-immigrants — **What to look for:** the most common scams against immigrant communities and how to avoid them.

### Key words

- *Scam:* a trick to get money or information.
- *Phishing:* fake messages or websites that ask for information.
- *Independent verification:* confirming through a channel you looked up.

### Sources

[S22] FTC, IdentityTheft.gov · FTC, consumer fraud data · FBI, IC3.

---

## M4 U02. Who can really help me with an immigration case?

**What you will be able to do:** Recognize the frauds that hurt immigrants the most (notarios, fake lawyers, "express asylum" and government impostors) and know where to verify.

**To start:** Mar's neighbor was offered a "work permit in three months" at an office with a "Notaria – Inmigración" sign. They asked for 5,000 dollars upfront. In this lesson you'll learn who can really help you and how to verify it.

### The essentials (5 minutes)

#### Only two can give you immigration advice

In the U.S., only these can give you advice about your immigration case:

1. **Licensed attorneys**, and
2. **accredited representatives of the Department of Justice (DOJ)**, who work at recognized organizations.

Nobody else: not notarios, not "helpers," not social media "advisors."



#### A "notario" in the U.S. is not a lawyer

In much of Latin America, a notario is a kind of lawyer. In the U.S., a **notary public** only certifies signatures.

In California it's illegal to advertise as a "notario" to offer immigration services.



#### Who can do what

| Type | Description | What it means for you |
|---|---|---|
| Licensed attorney | Advises and represents you. | Check them with the State Bar. |
| Accredited representative (DOJ) | Advises and represents you from a recognized organization. | Check the DOJ list. |
| Immigration consultant | Only non-legal tasks: translating or filling out forms with your information. | Must be registered and give you a contract. |
| "Notario" or social media helper | No immigration advice at all. | A red flag. |

#### Watch out for "express asylum"

Watch out if someone promises you a fast work permit with an asylum request, even if you don't qualify.

A false request to USCIS is a serious crime. It can lead to a deportation case that can't be undone.

> **Key idea:** always confirm your case with a licensed attorney or a DOJ-accredited representative.



#### Three steps before hiring help

1. **Ask:** "Are you an attorney or a DOJ-accredited representative?"
2. **Verify** their license or accreditation at the official source.
3. **Ask for a written contract** with the total cost. Never pay for guaranteed "arrangements."



#### A case in one minute

Rosa wanted to help her granddaughter with some papers. On social media she found an "advisor" who charged 800 dollars.

Before paying, she looked up the name with the State Bar and on the DOJ list. It wasn't on either. She called a recognized organization in Fresno and got a no-cost appointment.



#### Do it this week

1. Find a recognized organization near you on the DOJ list.
2. Save its phone number and address.
3. Share this information with your family.



#### Check your understanding

1. Can a notary public give you immigration advice?
*Answer:* No. They only certify signatures.

2. Will ICE or USCIS ask you to pay by phone with gift cards?
*Answer:* No. No government agency charges that way.


#### Remember

- Only attorneys and accredited representatives can advise you.
- Always verify the license or accreditation.
- Nobody can guarantee the outcome of a case.



### Go deeper (5 more minutes)

#### How to verify

- **Attorney:** look up their name and license number with the State Bar of California, or of the state where they're licensed.
- **Accredited representative:** check the DOJ's (EOIR) official list of recognized organizations and accredited representatives.
- **Immigration consultant:** check their registration and bond with the California Secretary of State.



#### Government impostors

People who call, write or visit saying they're from ICE, USCIS, the IRS or the police:

- demand immediate payment to "avoid a deportation," "release a relative" or "cancel a fine";
- ask you to pay with gift cards, cryptocurrency, wire transfers or apps;
- threaten to arrest you if you hang up.

The government **doesn't** ask you to pay like that. Hang up and check the official website.



#### Red flags

| Sign | Why it's dangerous |
|---|---|
| They guarantee the outcome | Nobody can guarantee what the government decides |
| They charge for forms that cost nothing | USCIS forms can be downloaded at no cost |
| They ask you to sign blank forms or with false information | They can get you into a crime |
| They keep your originals | You lose important documents |
| They don't give you a contract or receipt | You have no way to complain |
| They sell "new programs" on social media | They're almost always fake |

> **Good to know:** USCIS forms cost nothing at uscis.gov. If someone charges you for the form, they're charging you for something that costs nothing.



#### Where to report

To the State Bar of California, the California Attorney General and the FTC (ReportFraud.ftc.gov).

Reporting helps other families and doesn't affect your situation. Many organizations will go with you to do it.



#### What an immigration services contract should have

- The name and license or accreditation number of the person helping you.
- Which services it includes and which it doesn't.
- The total cost and how it's paid.
- What happens if you cancel.

In California, immigration consultants must give you a written contract in your language and return your original documents.



#### Cases


**Case 1. Mar's neighbor**

A "Notaria – Inmigración" office promises Mar's neighbor "papers in 6 months" for 5,000 dollars.
- *What does Mar do?* She goes with her neighbor to an organization with accredited representatives, which reviews her case at no cost.


**Case 2. The call from "ICE"**

Alex gets a call: a cousin is detained and must pay 2,000 in gift cards to be released.
- *What does Alex do?* Hangs up and calls the cousin and the family. The cousin was at work.


**Case 3. The fast permit**

A social media "advisor" offers Daniela a work permit in three months "with an asylum application."
- *What's the risk?* If she doesn't qualify, filing a false application is a crime and can lead to deportation proceedings.
- *What does she do?* She checks with an accredited representative before doing any paperwork.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Trusting a "notario" or helper | You lose money and put your case at risk | Look for an attorney or accredited representative |
| Paying for a guaranteed outcome | It's a scam | Nobody can guarantee it |
| Signing applications with false information | A crime and deportation | Never sign something that isn't true |
| Paying someone who says they're ICE on the phone | You lose money | Hang up and verify |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can a notary public give you immigration advice? a) Yes · b) No · c) Yes, if they speak Spanish
2. Where do you check an attorney's license in California? a) State Bar · b) In their ad · c) With a notario
3. Will ICE ask you to pay with gift cards? a) Yes · b) Only if it's urgent · c) No
**Answers:** 1-b: they only certify signatures. 2-a: it's the official registry. 3-c: no agency charges that way.



#### Put it into practice

Write three questions to ask before hiring help for an immigration case.
**Answer:** Are you an attorney or a DOJ-accredited representative? What is your license number or recognized organization? Will you give me a written contract with the total cost and what it includes?



#### Your plan

Save the contact information of an organization with accredited representatives or a certified legal service near you. This course doesn't give immigration advice.



### Learn more

- **Official list of accredited representatives** (DOJ EOIR · English): https://www.justice.gov/eoir/recognized-organizations-and-accredited-representatives-roster-state-and-city — **What to look for:** the list for California and your city to find recognized organizations near you.
- **Attorney search** (State Bar of California · English and Spanish): https://www.calbar.ca.gov — **What to look for:** "Attorney Search" to confirm an attorney has an active license.
- **How to avoid immigration scams** (FTC · English and Spanish): https://consumer.ftc.gov/articles/how-avoid-immigration-scams-and-get-real-help — **What to look for:** the list of fraud signs and where to get real help.
- **Resources for immigrant communities** (California Attorney General · English and Spanish): https://oag.ca.gov/immigrant — **What to look for:** how to report a fraudulent notario or consultant in California.

### Key words

- *Notary public:* a person who certifies signatures; not a lawyer.
- *Accredited representative:* authorized by the DOJ to give immigration advice at a recognized organization.
- *Immigration consultant:* can do non-legal tasks if registered.

### Sources

[R23] State Bar of California · [R37] California Secretary of State, immigration consultants · [R38] DOJ EOIR · [R47] California Attorney General · USCIS, no-cost forms.

---

## M4 U03. What protects my accounts besides a password?

**What you will be able to do:** Protect your access, your devices and the way you recover your accounts.

**To start:** Alex used the same password for everything. An online store had a data breach. With that password, someone got into Alex's email and from there tried to get into the bank. In this lesson you'll learn to protect your accounts with simple steps.

### The essentials (5 minutes)

#### Your email and your phone are the master key

Your email and your phone number are used to recover almost all your other accounts: bank, social media, apps.

That's why they're the first things to protect.



#### Five basic protections

| Type | Description | What it means for you |
|---|---|---|
| Different passwords | One for your email and another for your bank. | A password manager helps. |
| Two-step verification | Besides the password, a code or an app. | Turn it on for email and bank. |
| Recovery information | Backup email and phone up to date. | Check them today. |
| Phone lock | A PIN or fingerprint, and updates installed. | It keeps others from using your phone. |
| Bank alerts | They let you know about every transaction. | You find out right away. |

#### Never share codes

The code you get by text is only for you. Nobody from your bank, your phone company or any other company will ask you for it.

If someone asks for it, it's a scam, even if they say they're from the bank.



#### Watch out for "tech support"

Don't install apps someone asks you to install during an unexpected call or pop-up. With them they can see and control your phone or computer.

> **Key idea:** protect your email and your phone number first.



#### Do it this week

1. Change your email password to one you don't use anywhere else.
2. Turn on two-step verification for your email and your bank.
3. Check that your recovery email and phone are up to date.



#### A case in one minute

Rubén turned on two-step verification for his email and his bank. A month later he got a message: "Someone tried to sign in to your account from another country."

Since they didn't have the second code, they couldn't get in. Rubén changed his password and carried on calmly.



#### Check your understanding

1. Which account do you protect first?
*Answer:* Your main email, because the others are recovered through it.

2. "The bank" calls and asks for the code you received. Do you share it?
*Answer:* No. You hang up and call the number on your card yourself.


#### Remember

- Your email and your phone are the key to everything.
- A different password for each important account.
- Never share codes or install apps a stranger asks for.



### Go deeper (5 more minutes)

#### Protect your phone number

There are scams where someone convinces your phone company to move your number to another SIM card. That way they get your codes.

Ask your phone company for a PIN or passcode for any change to your line. If your phone suddenly loses service for no reason, call your phone company.



#### App permissions

Before connecting an app, check what it can see, change and store, and how to remove its access.

A budgeting app doesn't need your contacts or your messages. Allowing it to read your transactions isn't allowing it to sell your information.



#### Shared devices

If you use a computer at a library or someone else's phone:

- sign out when you finish;
- don't save passwords;
- avoid banking on public Wi-Fi if you can.



#### If you lose your phone

1. Call your phone company to protect your line.
2. From another device, change your email password.
3. Tell your bank.
4. Use your paper contact list.

Always have a list of important contacts outside your phone.

> **Good to know:** turning on two-step verification blocks the vast majority of automated account takeover attempts, according to tech companies like Google and Microsoft.



#### If there's control at home

If someone at home controls your phone or your accounts, changing all your passwords at once can increase the risk. First look for a safe path (M4 U05).



#### How to create a strong password

A long phrase is stronger and easier to remember than a short word with symbols.

For example, four words that have nothing to do with each other. Don't use your name, your date of birth or your children's names.

A password manager stores all your passwords and you only have to remember one.



#### Cases


**Case 1. The same password**

Alex used the same password for email and bank. The one from an online store leaked and someone got into Alex's email.
- *Is changing the bank password enough?* No. The email was still compromised. Alex changed both and turned on two-step verification.


**Case 2. Tech support**

A pop-up on Mar's computer says "virus detected, call this number." They ask her to install an app.
- *What does she do?* She closes the browser and doesn't call.


**Case 3. Rosa's phone**

Rosa shares her phone with her grandchildren.
- *What changes?* She puts a PIN on her bank app and doesn't save the password on the phone.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Using the same password for everything | If one leaks, they get into everything | A different one for each important account |
| Sharing codes over the phone | They get into your account | Never share them |
| Installing "support" apps | They control your device | Close the window and hang up |
| Keeping everything only on your phone | If you lose it, you lose access | A paper contact list |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Which account do you protect first? a) Social media · b) Main email · c) Your music app
2. Do you share the code you received if "the bank" calls? a) No · b) Yes · c) Yes, if they know your name
3. Does a budgeting app need to read your messages? a) Yes · b) Yes, to sort your expenses · c) No
**Answers:** 1-b: the others are recovered through your email. 2-a: the code is only for you. 3-c: it doesn't need to.



#### Put it into practice

Write the three steps you'd take if you lost your phone today.
**Answer:** Call the phone company to protect the line, change the email password from another device and tell the bank.



#### Your plan

Complete your list of five protections and your plan if you lose your phone. The course reviews your plan, never your passwords.



### Learn more

- **Protect your accounts** (FTC · English): https://consumer.ftc.gov — **What to look for:** search for "multi-factor authentication" to see how to turn it on step by step.
- **Identity theft** (FTC · English and Spanish): https://www.identitytheft.gov — **What to look for:** what to do if someone got into your email or your bank.

### Key words

- *Two-step verification:* a second check besides the password.
- *Remote access:* controlling a device from a distance.
- *Login information:* username and password.

### Sources

FTC, account security · CISA, multi-factor authentication.

---

## M4 U04. What do I do if I already shared information or see something strange?

**What you will be able to do:** Respond quickly and in order to fraud or identity theft.

**To start:** Mar gave a code over the phone. Ten minutes later she realized what she had done. She panicked, but she knew what to do. In this lesson you'll learn the exact steps to respond to fraud.

### The essentials (5 minutes)

#### Act quickly

Reporting deadlines matter. The sooner you report, the easier it is to stop the damage and get your money back.

Don't blame yourself. These scams are designed to fool anyone. What matters is acting.



#### What happened and what you do first

| What happened | First action |
|---|---|
| You lost your card | Lock it from the app or by phone |
| Someone got into your account | Change passwords from a safe device and report it |
| You paid because you were tricked | Tell the bank or app right away |
| A new account in your name | Report it at IdentityTheft.gov and freeze your credit |
| A wrong charge | File a dispute with the card issuer |



#### General steps

1. **Stop talking** to the suspect.
2. **From a safe device,** contact the bank or company through its official channel.
3. **Describe** what happened: date, amount and what you did or didn't authorize.
4. **Ask** for protective measures and a confirmation number.
5. **Keep evidence:** messages, receipts and a timeline.



#### Freeze your credit

**Freezing your credit** costs nothing at all three agencies. It keeps new accounts from being opened in your name.

It doesn't protect your current accounts or erase debts, but it closes the door to new fraud. You can lift it when you need to apply for credit.

> **Key idea:** be wary of anyone who promises to "recover all your money" in exchange for an upfront payment. It's the second scam.



#### A case in one minute

Daniela saw two charges in her account from an online store she didn't know.

She locked her card from the app, called the bank, disputed the charges and asked for a new card. She wrote down the confirmation number on her incident sheet. A week later she got her money back.



#### Do it this week

1. Create your blank incident sheet, ready to use.
2. Write down on paper the phone numbers of your bank and the three credit agencies.
3. Consider freezing your credit if you don't plan to borrow soon.



#### Check your understanding

1. Does a credit freeze protect your existing accounts?
*Answer:* No. It prevents new accounts, but you have to keep watching the current ones.

2. Where do you create a recovery plan for identity theft?
*Answer:* At the FTC's IdentityTheft.gov.


#### Remember

- Act quickly and through official channels.
- Ask for and keep a confirmation number.
- Freeze your credit if there's a risk of identity theft.



### Go deeper (5 more minutes)

#### Identity theft

It's when someone uses your information to pretend to be you: opening accounts, taking out loans or even filing tax returns.

At **IdentityTheft.gov** you create a report and get a step-by-step recovery plan, with sample letters for banks and agencies.



#### Freeze and alert

- **Freeze:** nobody can open new credit in your name. You request it at each of the three agencies.
- **Fraud alert:** companies must verify your identity before opening something in your name. You request it at one agency and it notifies the other two.

Both cost nothing.



#### Your incident sheet

Write down on a sheet:

- what happened and when;
- who you called, who you spoke with and what they told you;
- the confirmation numbers;
- the letters you sent and received.

This sheet saves you from repeating everything each time you call.

> **Good to know:** if someone filed a tax return with your SSN or ITIN, the IRS has a special process. You'll find it at IdentityTheft.gov, in the taxes section.



#### If there's danger

If there's immediate physical danger, call 911. The course's questions aren't an emergency channel.



#### How to freeze and unfreeze

You request the freeze on each agency's website: Equifax, Experian and TransUnion. They give you a PIN or an account to manage it.

When you need to apply for credit or rent, you "thaw" it temporarily in minutes and then freeze it again. It costs nothing.



#### Your children's information

Children can also be victims of identity theft. You can freeze your minor children's credit at all three agencies, at no cost.

Don't share their Social Security numbers or photos of their documents.



#### Cases


**Case 1. The unknown account**

Alex's report shows a loan Alex never asked for.
- *What does Alex do?* Documents it, contacts the institution and the agency, follows the IdentityTheft.gov guide and freezes the credit.
- *What doesn't Alex do?* Pay the "cancellation fee" someone asks for over the phone.


**Case 2. The shared code**

Mar gave a code over the phone. Ten minutes later she realizes it.
- *What does she do?* She calls the bank, locks her account, changes her password and checks her transactions.


**Case 3. Rosa's lost card**

Rosa lost her wallet at the market.
- *What does she do first?* She locks her card from the app and calls the bank. Then she checks what other documents were in the wallet.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Waiting to see if something happens | The damage grows | Act as soon as you notice |
| Negotiating with the scammer | You lose more money | Stop talking to them |
| Paying someone who promises to recover your money | A second scam | Only with your bank and the authorities |
| Not keeping confirmation numbers or evidence | You can't prove what happened | Keep your incident sheet |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a credit freeze protect your existing accounts? a) Yes · b) No · c) Yes, credit cards too
2. Is negotiating with the scammer a necessary step? a) No · b) Yes · c) Yes, to get your money back
3. Where do you create a recovery plan for identity theft? a) Social media · b) On the website the scammer sent you · c) IdentityTheft.gov
**Answers:** 1-b: it only prevents new accounts. 2-a: stop talking to them. 3-c: it's the FTC's official site.



#### Put it into practice

You gave your bank password over the phone. Write your first four steps.
**Answer:** Change the password from a safe device, call the bank at the official number, check your transactions and turn on alerts. Ask for a confirmation number and write it down.



#### Your plan

Prepare an incident sheet and a list of official contacts, without full account numbers.



### Learn more

- **Identity theft** (FTC · English and Spanish): https://www.identitytheft.gov — **What to look for:** "Report identity theft" to create your report and your personal recovery plan.
- **Freeze your credit** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/ — **What to look for:** the links to Equifax, Experian and TransUnion to freeze at no cost.
- **Report fraud** (FTC · English and Spanish): https://reportfraud.ftc.gov — **What to look for:** the form to report the fraud even if you already told your bank.

### Key words

- *Identity theft:* using your information to pretend to be you.
- *Credit freeze:* prevents new accounts from being opened in your name.
- *Fraud alert:* a notice to verify your identity before giving you credit.
- *Confirmation number:* a tracking number.

### Sources

[S22] FTC, IdentityTheft.gov · [R09] CFPB, credit freezes · IRS, tax identity theft.

---

## M4 U05. Is talking about money the same as controlling someone?

**What you will be able to do:** Recognize financial abuse and know options for safe support.

**To start:** This lesson uses a made-up case. A woman hands her whole paycheck to her partner every week and has to ask permission to buy anything. He keeps her passport "so it doesn't get lost." In this lesson you'll learn to tell a healthy agreement apart from a pattern of control.

### The essentials (5 minutes)

#### Agreeing is not controlling

Agreeing on expenses as a couple or a family is healthy. Talking about money, making a budget together or asking for an opinion before a big purchase is too.

Taking someone's paycheck, keeping them from working or forcing them to sign a debt with threats is different.



#### Agreement or control

| Type | Description | What it means for you |
|---|---|---|
| Agreement | You decide together, everyone gives an opinion and has some money of their own. | It's healthy. |
| Control | One person decides everything, takes away money or documents, or threatens. | It may be financial abuse. |

#### Signs of control

- Taking away the paycheck or cards.
- Keeping someone from working or studying.
- Opening debts in another person's name.
- Keeping their ID documents.
- Threatening them for asking questions or spending.

Controlling another person's money, documents or decisions can be **financial abuse**.



#### Safety comes first

A visible change, like changing passwords, putting documents away or opening an account, can increase the risk in some relationships.

Look for confidential guidance from a safe device and at a safe time.

> **Key idea:** recognizing it doesn't mean you have to tell your private life. To pass this course you don't have to confront anyone or share your story.



#### Where to get support

The **National Domestic Violence Hotline** answers 24 hours a day, at no cost, confidential and in Spanish: **1-800-799-7233**.

If there's immediate danger, call **911**.



#### A case in one minute

Made-up case: a person tells a friend that their partner checks all their spending and gets angry if they buy something without permission.

The friend doesn't judge or tell them what to do. She shares the national hotline number and says: "I'm here whenever you need me."



#### Do it this week

1. Save the national hotline number in a safe place.
2. Think of a trusted person you could turn to.
3. Check whether you have some money and documents that are yours alone.



#### Check your understanding

1. Is a disagreement about spending always abuse?
*Answer:* No. What's worrying is a pattern of control, not a disagreement.

2. To pass, do you have to confront the other person?
*Answer:* No. You can work with made-up cases.


#### Remember

- Agreeing is healthy; controlling is not.
- Your safety comes before any change.
- There is confidential support in Spanish.



### Go deeper (5 more minutes)

#### Older people and financial abuse

Older people or people who depend on care can also suffer financial abuse. For example, relatives who use their money without permission, caregivers who ask to "borrow," or strangers who win their trust.

Helping manage someone's money requires their permission and limits. Having access doesn't give you the right to use it for yourself.

> **Good to know:** in California, each county's Adult Protective Services (APS) takes reports of financial abuse of older or dependent adults, 24 hours a day.



#### Safe steps if someone asks you for help

- Listen without judging and without pressuring.
- Don't tell them what to do; give them information.
- Share the national hotline number.
- Don't keep information where the other person can see it.



#### Documents and money of your own

Having a copy of your documents in a safe place, outside the home, and a little money of your own can give you options.

Do it only if it's safe for you and, preferably, with guidance from a specialized organization.



#### Your rights don't depend on your immigration status

Domestic violence laws protect everyone in the U.S. There are special protections for immigrant survivors.

An attorney or an accredited representative can explain your options confidentially.



#### Using your phone safely

If someone checks your phone, clear the history after looking for help or use a trusted person's phone.

Many support websites have a "quick exit" button that closes the page immediately.



#### Cases


**Case 1. The loan she can't read**

Made-up case: a person pressures their partner to sign a loan she can't read and asks for her passwords.
- *What signs are there?* Lack of information, pressure and the risk of a debt.
- *What response is safe?* Pause, look for independent support and not keep information where the other person can see it.


**Case 2. Alex and Mar's agreement**

Alex and Mar go over their budget together every Sunday. Each one has 50 dollars a week for whatever they want, with no explanations.
- *Is it control?* No. It's a healthy agreement: they decide together and each one has independence.


**Case 3. Rosa's pension**

Made-up case: an older person gives her card to a nephew so he can do her shopping. He starts using it for his own expenses.
- *What is it?* Financial abuse. Having access doesn't give the right to use the money.
- *What can she do?* Change her PIN, ask someone she trusts for help and report it to Adult Protective Services.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Confusing a disagreement with abuse | You misjudge a relationship | Look for a pattern of control |
| Making visible changes without a plan | The risk increases | Look for confidential guidance first |
| Pressuring someone to leave | They pull away from the person helping | Listen and share information |
| Using an older relative's money | It's financial abuse | Use their money only for them |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is a disagreement about spending always abuse? a) Yes · b) No · c) Yes, if there's yelling
2. To pass, do you have to confront the other person? a) No · b) Yes · c) Yes, in writing
3. Does having access to an older relative's money give you the right to use it? a) Yes · b) Yes, if you take care of them · c) No
**Answers:** 1-b: the pattern is what matters. 2-a: you can use made-up cases. 3-c: the money is theirs.



#### Put it into practice

In the made-up case of the couple and the loan, write a safe response.
**Answer:** Not signing at that moment, looking for confidential support from a safe place and keeping information only where the other person can't see it.



#### Your plan

You can complete this lesson with a made-up case. No personal story or evidence is asked for. Save the national hotline number in a safe place.



### Learn more

- **National Domestic Violence Hotline** (The Hotline · English and Spanish): https://www.thehotline.org — **What to look for:** the online chat and the "quick exit" button to use it safely.
- **Financial abuse** (CFPB · English and Spanish): https://www.consumerfinance.gov — **What to look for:** search for "elder financial abuse" and "economic abuse" to see guides for older adults and survivors.
- **Adult Protective Services** (California Department of Social Services · English): https://www.cdss.ca.gov/adult-protective-services — **What to look for:** your county's APS phone number to report abuse of an older person.

### Key words

- *Financial abuse:* control over another person's resources or financial decisions.
- *Independence:* being able to decide about your own money.
- *APS:* Adult Protective Services.

### Sources

The National Domestic Violence Hotline · CFPB, financial abuse · CDSS, Adult Protective Services.

---

## M4 U06. What is setting aside a little money for?

**What you will be able to do:** Build savings in stages according to their purpose.

**To start:** Daniela's refrigerator broke down two days before rent. She had nothing set aside and had to use her card. She paid interest for months. In this lesson you'll learn to build a cushion little by little, even if you start with very little.

### The essentials (5 minutes)

#### The unexpected doesn't wait

A repair, an illness or a week without work don't wait for your next paycheck.

An **emergency fund** is money you can use quickly for the unexpected. It isn't money that already has a job, like rent.



#### Three different kinds of savings

| Type | Description | What it means for you |
|---|---|---|
| Everyday cushion | For when a payment falls before your paycheck. | Small and used often. |
| Planned expenses | Car registration, school supplies, a yearly insurance payment. | Set aside each month. |
| Emergency | What can't be predicted: illness, losing your job. | Used only for that. |

#### How long does your savings cover you?

You have 600 set aside and your basic expenses are 1,500 a month, about 50 a day.

| Calculation | Result |
|---|---|
| 600 ÷ 1,500 | 0.4 months |
| 600 ÷ 50 a day | 12 days |

It isn't little: 12 days can be the difference between paying on time and going into debt.



#### Start in stages

1. **First goal:** a small surprise, for example 300.
2. **Second goal:** one week of basic expenses.
3. **Third goal:** one month of basic expenses.

If you have no margin today, the first step may be to stabilize your expenses and look for support.



#### A case in one minute

Rubén started setting aside 10 dollars every Friday in a separate account. He didn't feel it. In six months he had 260.

When his phone broke, he paid for it with his savings, with no card and no loan.

> **Key idea:** using your savings isn't failing. That's what it's for.



#### Is it an emergency or not?

Before using your savings, ask yourself:

1. Is it necessary?
2. Is it urgent?
3. Was it unexpected?

If all three answers are yes, it's an emergency. If not, it's probably a planned expense or a want that can wait.



#### Do it this week

1. Open a separate savings account or a digital envelope for your savings.
2. Set up an automatic transfer, even a small one.
3. Write down your first goal and the date you want to reach it.



#### Check your understanding

1. You have 600 in savings and spend 1,500 a month. How long does it cover you?
*Answer:* About 12 days, or 0.4 months.

2. Is your yearly car registration an emergency?
*Answer:* No. It's a planned expense: you set aside for it each month.


#### Remember

- Keep emergencies apart from planned expenses.
- Start with a small goal.
- If you use it, write down how you'll refill it.



### Go deeper (5 more minutes)

#### Where to keep it

Your savings should be **accessible, safe and not at risk of losing value**.

An insured savings account, separate from your everyday account, is a good option. An investment that can go down or a certificate with a penalty for early withdrawal isn't a good place for emergency money.



#### Don't count the same money twice

All three kinds of savings can be in the same account, but write down how much is for each one.

If you use the car registration money for an emergency, refill the registration money first.



#### If part of your income keeps coming in

If you lose hours but still get 900 of your 1,500 in expenses, your savings only needs to cover the difference: 600 a month.

That way, the same savings lasts longer.



#### How to refill it

After using it, write down how much you used and what for. Decide how much you'll set aside each week to refill it and how long it will take.

> **Good to know:** in California, CalSavers is a state retirement savings program. Some people also use it to save little by little, although its purpose is retirement. For emergencies, the best option is a savings account you can use with no penalty.



#### Ideas for setting money aside without feeling it

- An automatic transfer on payday.
- Saving your "change": rounding up each purchase and keeping the difference.
- Keeping part of your tax refund or the extra paycheck in three-paycheck months.



#### Savings or paying off debt

If you have high-interest debts, it may seem better to use everything to pay them off.

But without minimum savings, any surprise sends you back into debt. Many people start with small savings, for example 300 or 500, and then focus on the debts.



#### Cases


**Case 1. Alex and Mar's savings**

They have 900 and basic expenses of 1,800.
- *How long does it cover them?* Half a month.
- *And if their expenses go up to 2,000?* The same savings covers 0.45 months. It's worth reviewing when expenses go up.


**Case 2. The car registration**

Mar thought the car registration, 600 a year, was an emergency.
- *What was it?* A planned expense. With 50 a month for 12 months, she covers it.


**Case 3. Daniela's refrigerator**

Daniela paid for the refrigerator with her card and still owes 400.
- *What does she do now?* She pays down the card and, at the same time, sets aside 10 a week toward her first goal of 300.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Waiting to have a lot before starting | You never start | Start with 5 or 10 a week |
| Keeping your savings in your everyday account | It gets spent without you noticing | Use a separate account |
| Investing emergency money | It can drop when you need it | Keep it in insured savings |
| Feeling guilty for using it | You go into debt to avoid touching it | Use it and refill it with a plan |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Savings of 600 and expenses of 1,500. How many months does it cover? a) 2.5 · b) 0.4 · c) 1
2. Is a known yearly payment an emergency? a) No, it's a planned expense · b) Yes · c) Yes, if it's over 500
3. Is an investment that can go down a good place for your savings? a) Yes · b) Yes, if it goes up fast · c) No
**Answers:** 1-b: 600 ÷ 1,500 = 0.4. 2-a: it can be planned for. 3-c: savings shouldn't lose value.



#### Put it into practice

Your first goal is 300. You can set aside 15 a week. How long will it take?
**Answer:** 20 weeks, about 5 months, because 300 ÷ 15 = 20.



#### Your plan

Define your first stage, where you'll keep it, when you'll use it and how you'll refill it. No amount is required to pass.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "Saving for emergencies" tool with goals in stages.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the savings module and the worksheet to set your goal.

### Key words

- *Emergency fund:* money for surprises.
- *Savings for planned expenses:* money for known payments.
- *Liquidity:* how quickly you can use a resource.

### Sources

CFPB, emergency savings · FDIC, Money Smart · CalSavers.

---

## M4 U07. Does having insurance mean I won't pay anything?

**What you will be able to do:** Read a policy and compare insurance by what it really covers.

**To start:** Alex chose the cheapest car insurance. After a crash during a weekend delivery job, the insurer didn't pay: the policy didn't cover using the car for work. In this lesson you'll learn to read what your insurance covers before you need it.

### The essentials (5 minutes)

#### Four insurance words

| Type | Description | What it means for you |
|---|---|---|
| Premium | What you pay to have the insurance. | Monthly or yearly. |
| Deductible | What you pay before the insurance pays. | Lower = higher premium. |
| Coinsurance | The percentage you pay after the deductible. | For example, 20%. |
| Exclusion | What the policy doesn't cover. | Read it before you sign. |

#### Having insurance isn't the same as not paying

You pay a premium to have protection. When something happens, you first pay the deductible. There are also limits and things it doesn't cover.

That's why a cheaper premium doesn't mean it will cost you less when something happens.



#### Three steps before you choose

1. **Identify what you want to protect:** your health, your car, your things, your family.
2. **Read what the policy pays** and what you would pay.
3. **Compare policies with the same coverage.**



#### Car insurance in California

Since 2025, the minimum required liability amounts are **30,000** per injured person, **60,000** per accident and **15,000** for property damage.

That insurance pays for what you damage of other people's, it does **not** fix your own car. If you use your car for work, for example for app deliveries, tell your insurer: you may need other coverage.

> **Key idea:** compare the cost over a year with and without an incident, not just the premium.



#### A case in one minute

Andrés compared two car insurance policies with the same coverage. One cost 110 a month with a 500 deductible; the other, 85 a month with a 1,500 deductible.

Since he has 2,000 in savings, he chose the 85 one: he could pay the deductible if something happens, and he saves 300 a year.



#### Do it this week

1. Find your car, health or renters insurance policy.
2. Write down the premium, the deductible and what it doesn't cover.
3. Ask your insurer about one question you have.



#### Check your understanding

1. Does liability insurance fix your own car?
*Answer:* No. It pays for damage you cause to others.

2. Does the building owner's insurance cover your things?
*Answer:* No. That's what renters insurance is for.


#### Remember

- Read what your policy covers and what it excludes.
- Compare premium, deductible and coinsurance together.
- Tell your insurer if you use your car for work.



### Go deeper (5 more minutes)

#### Types of insurance

| Insurance | What it protects | Keep in mind |
|---|---|---|
| Car (liability) | Damage you cause to others | Required; it doesn't fix your car |
| Car (collision) | Your vehicle | Optional unless your loan requires it |
| Renters | Your things and some liability | The owner's insurance doesn't cover your things |
| Homeowners | The house | Earthquake and flood are usually separate |
| Health | Medical care | Check the network, copays and out-of-pocket maximum |
| Life | Your dependents if you die | Term or permanent |
| Disability | Part of your income if you can't work | Waiting periods |



#### Compare premiums and deductibles

| | Monthly premium | Deductible | Yearly premium |
|---|---|---|---|
| Policy A | 70 | 1,500 | 840 |
| Policy B | 100 | 500 | 1,200 |

B costs 360 more per year, but its deductible is 1,000 lower. The better one depends on whether you could pay the deductible when something happens.



#### A health event with numbers

A 2,000 service; 500 left on the deductible; 20% coinsurance on the rest.

You pay 500 + 20% of 1,500 = 500 + 300 = **800**.

Check the **out-of-pocket maximum**: it's the most you would pay in a year, not counting the premium.



#### Health care in California

California has a state mandate to have health coverage, with exemptions. Covered California offers plans with help paying the premium based on your income.

Check the network of doctors, the covered services, authorizations and copays before choosing.

> **Good to know:** renters insurance in California usually costs between 15 and 30 dollars a month and covers your things if there's a theft or fire. Many people don't have it because they think the owner covers them.



#### Verify the insurer and the agent

Look up the insurer and the agent with the **California Department of Insurance (CDI)**. If they aren't licensed, don't sign up.

The CDI also takes complaints if an insurer doesn't pay what it should.



#### Life insurance

Life insurance protects the people who depend on your income if you die.

**Term insurance** covers a number of years and is usually cheap. **Permanent** insurance costs more and combines insurance with savings. For many young families, term insurance is enough.

Be wary of anyone who pressures you to buy expensive life insurance as an "investment."



#### Cases


**Case 1. Alex's cheap policy**

A policy costs 20 less a month, but excludes using the car for work. Alex does jobs with the pickup truck on weekends.
- *Does it work for Alex?* No. If there's a crash while working, it won't pay.


**Case 2. The theft in the apartment**

Mar's TV is stolen.
- *Does the building's insurance cover it?* No. Now Mar is comparing renters insurance.


**Case 3. Rosa's health plan**

Rosa compares two plans: one with a low premium and a 3,000 deductible; another with a higher premium and a 500 deductible.
- *Which is better?* Since Rosa goes to the doctor often, the low-deductible plan may cost her less over the year.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Choosing by the premium only | You pay more when something happens | Add up premium, deductible and coinsurance |
| Believing the building's insurance covers your things | You lose your belongings | Get renters insurance |
| Not saying you use your car for work | Your accident isn't paid | Tell your insurer |
| Signing up with an unlicensed agent | A fake policy or one with no backing | Check with the CDI |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does liability insurance fix your car? a) Yes · b) No · c) Yes, if the crash was your fault
2. Does the building owner's insurance cover your belongings? a) No · b) Yes · c) Yes, if the theft was in the building
3. A 1,500 service, 300 deductible, 25% coinsurance. How much do you pay? a) 375 · b) 1,500 · c) 600
**Answers:** 1-b: it pays for damage to others. 2-a: you need renters insurance. 3-c: 300 + 25% of 1,200 = 600.



#### Put it into practice

Your plan has a 1,000 deductible and 20% coinsurance. You get care costing 3,000. How much do you pay?
**Answer:** 1,000 + 20% of 2,000 = 1,000 + 400 = 1,400, unless you reach your out-of-pocket maximum first.



#### Your plan

Write down your risks, what's already covered, what's missing and one question for a licensed agent.



### Learn more

- **California Department of Insurance** (CDI · English and Spanish): https://www.insurance.ca.gov — **What to look for:** "Check a License" for an agent or insurer, and the guides to car and renters insurance.
- **Covered California** (Covered California · English and Spanish): https://www.coveredca.com — **What to look for:** the "Shop and Compare" calculator to see plans and help paying based on your income.
- **Car insurance requirements** (California DMV · English and Spanish): https://www.dmv.ca.gov — **What to look for:** search for "insurance" to confirm the current minimum amounts.

### Key words

- *Premium:* what you pay for the insurance.
- *Deductible:* what you pay before the insurance pays.
- *Coinsurance:* the percentage you pay after the deductible.
- *Exclusion:* what it doesn't cover.

### Sources

[S21] CDI · [R10] DMV, insurance requirements · [R11] FTB, health mandate · Covered California.

---

## M4 U08. Is this medical document asking me to pay?

**What you will be able to do:** Review medical bills, ask for financial assistance and complain if something is wrong.

**To start:** Rosa went to the emergency room for a bad pain. Weeks later she got three different papers from the hospital and the insurance. She didn't know which one to pay or why the amounts were different. In this lesson you'll learn to read your medical documents and ask for help before paying.

### The essentials (5 minutes)

#### Never delay urgent care

First of all: **never delay urgent care out of fear of the cost**. Your health comes first. Payments get reviewed later, and there's help.



#### Three different documents

| Type | Description | What it means for you |
|---|---|---|
| Policy or plan information | What your insurance covers. | For reference. |
| Explanation of benefits (EOB) | How your insurance processed the care. | **It isn't a bill.** |
| Bill | What you're asked to pay. | Check it before you pay. |

#### Three steps before you pay

1. **Check** the name, date and service.
2. **Compare** the amounts and what the insurance already paid.
3. **Ask for an explanation** of any difference before you pay.



#### Protection against surprise bills

If you go to an emergency room, federal law (the **No Surprises Act**) protects you. It prohibits charging you excessive "out-of-network" rates for doctors you didn't choose.

And if you don't have insurance, you have the right to ask for a written **Good Faith Estimate**. It shows the total cost before scheduled care.



#### Ask for financial assistance before you pay

California hospitals must have a **financial assistance** policy and offer no-cost or discounted care to people with low and middle incomes who qualify.

Ask **before** you pay or put the bill on a credit card.

> **Key idea:** if two papers describe the same service, they aren't two debts.



#### Do it this week

1. Look up the financial assistance policy of your nearest hospital.
2. Keep your explanations of benefits together with your bills.
3. Write down your health plan's customer service phone number.



#### Check your understanding

1. Is the explanation of benefits (EOB) a bill?
*Answer:* No. It explains how your insurance paid; it doesn't ask you to pay.

2. You don't have insurance and a test is scheduled for you. What can you ask for?
*Answer:* A written Good Faith Estimate with the total cost.


#### Remember

- Your health first; payments get reviewed later.
- Compare the bill with the insurance's explanation.
- Ask about financial assistance before you pay.



### Go deeper (5 more minutes)

#### What to compare

Patient, date, service, amount charged, adjustments, what the plan paid and what you owe.

If there's a difference, ask for an **itemized bill** with each service and its code. Sometimes there are duplicate charges or services you didn't receive.



#### Emergencies and Medi-Cal

**Emergency Medi-Cal** can cover emergency care for people who qualify by income, regardless of immigration status.

Ask at the hospital whether they can help you apply.



#### Medical debts and your credit

In California, a law in effect since 2025 generally prohibits reporting medical debts to the credit agencies. Check whether there are exceptions or changes.

Even so, don't ignore a bill: ask for financial assistance or an no-interest payment plan.

> **Good to know:** if the Good Faith Estimate says 1,000 and you're charged 400 or more above it, you can start a federal dispute. You have 120 days from the bill.



#### Where to complain

The **DMHC** handles complaints about many health plans in California, including an independent medical review if you're denied treatment.

Other plans have a different regulator. Check your card or your policy to find out which one is yours.



#### Payment plans

If you owe a medical bill, ask for a payment plan. Many hospitals offer them with no interest.

Avoid putting a medical bill on a credit card: you lose the option of financial assistance and you pay interest.



#### What to say to the hospital

"I received this bill and I want to know whether I qualify for financial assistance. Can you send me the application? While you review it, can you put the billing on hold?"

Always ask for the name of the person who helped you and the date of the call.



#### Cases


**Case 1. The 300 bill**

Mar's explanation of benefits says she owes 150, but the bill asks for 300 for the same service.
- *What does she do?* She asks for an explanation before paying.


**Case 2. Alex's hospital stay**

Alex gets a 4,000 bill.
- *What does Alex do?* Asks about the hospital's financial assistance and turns in proof of income.
- *What happens?* The bill goes down to 400 with a payment plan.


**Case 3. Rosa's three papers**

Rosa received an EOB from the insurance, a bill from the hospital and another from the emergency room doctor.
- *What does she find out?* The EOB isn't a charge. The emergency doctor's bill had an "out-of-network" rate that, under the surprise billing law, she shouldn't be charged. She calls and disputes it.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Delaying urgent care out of fear of the cost | Your health gets worse | Get care first |
| Paying the EOB as if it were a bill | You pay too much | The EOB only informs |
| Paying without asking for financial assistance | You miss discounts you're entitled to | Ask before paying |
| Putting the bill on your card | You pay interest and lose assistance | Ask the hospital for a payment plan |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is the explanation of benefits a bill? a) Yes · b) No · c) Yes, it's due in 30 days
2. Must California hospitals have a financial assistance policy? a) Yes · b) No · c) Only public hospitals
3. Do you delay urgent care to finish the exercise? a) Yes · b) Yes, if there's little left · c) Never
**Answers:** 1-b: it only explains. 2-a: they must have one. 3-c: your health comes first.



#### Put it into practice

The EOB says you owe 150 and the hospital bill says 300. What do you do?
**Answer:** You don't pay yet. You call the hospital, explain the difference with the EOB, ask for an itemized bill and ask about financial assistance.



#### Your plan

Save the contacts of your plan, your doctors and the regulator. Ask for the financial assistance policy of your nearest hospital.



### Learn more

- **Hospital Fair Billing Program** (California HCAI · English): https://hcai.ca.gov/affordability/hospital-fair-billing-program/ — **What to look for:** who qualifies for discounts and how to ask for them.
- **File a complaint about your plan** (DMHC · English and Spanish): https://www.dmhc.ca.gov/FileaComplaint.aspx — **What to look for:** how to ask for an independent medical review if you're denied treatment.
- **Surprise medical bills** (CMS · English and Spanish): https://www.cms.gov/nosurprises — **What to look for:** your rights in the emergency room and how to ask for a Good Faith Estimate.

### Key words

- *Explanation of benefits:* a summary of how care was processed.
- *Financial assistance:* a discount or no-cost care based on income.
- *DMHC:* the regulator of many health plans in California.
- *Good Faith Estimate:* a written estimate if you don't have insurance.

### Sources

[R12] DMHC · [R52] HCAI, hospital fair pricing · CMS, No Surprises Act · California law on medical debt in credit reports (SB 1061).

---

## M4 U09. How do I pay for the essentials if I can't work for a few days?

**What you will be able to do:** Prepare your finances for a disaster, an accident or a temporary loss of income.

**To start:** A fire near Fresno forced Rosa to leave her house with her grandchildren in twenty minutes. She took the medicine, but left all her papers. In this lesson you'll learn to prepare your finances for an emergency before it arrives.

### The essentials (5 minutes)

#### An emergency takes away and adds at the same time

An accident, a disaster or an illness can take away income and, at the same time, add expenses: transportation, eating out, medicine.

A **contingency plan** prepares you without having to guess what will happen.



#### Three quick calculations

1. **Write down which income** could be missing.
2. **Write down the new expenses** and the ones that stay the same.
3. **Check the money available** and the help that's already confirmed.



#### What to prepare

| Type | Description | What it means for you |
|---|---|---|
| Contacts | A list on paper, outside your phone. | Keep it in your backpack. |
| Documents | Originals in a safe place and copies in another place. | Photos in the cloud too. |
| Inventory | Photos of your valuable things. | Useful for the insurance. |
| A way to pay | An extra card or some cash in small bills. | In case there's no power or internet. |

#### Safety first

In a fire, an evacuation or an accident, follow the emergency instructions. Then organize your resources.

> **Key idea:** don't count help that isn't confirmed. A payment from insurance or the government is only a resource once it's confirmed.



#### A case in one minute

After the fire, Rosa packed a backpack. She put copies of her documents in a sealed bag, a contact list on paper, medicine for three days and 100 dollars in small bills.

She keeps it by the door and told her daughter where it is.



#### Do it this week

1. Take photos of your documents and save them in the cloud or a secure email.
2. Write your contact list on paper.
3. Pack a backpack with the basics for three days.



#### Check your understanding

1. Does an insurance payment that isn't confirmed yet count as a resource?
*Answer:* No. It only counts when it's confirmed.

2. Do you keep the only copy of your documents at home?
*Answer:* No. Also keep a copy in another safe place.


#### Remember

- Prepare your backpack and your paper contact list.
- Keep copies of your documents in two places.
- Don't count help that isn't confirmed.



### Go deeper (5 more minutes)

#### Insurance and disasters

Check the deductibles and exclusions of your insurance **before** something happens.

Earthquake and flood usually require separate policies. In California there's the California Earthquake Authority (CEA) for earthquake insurance.



#### Scams after a disaster

After a disaster, fake donation campaigns appear, along with contractors who charge upfront and disappear.

Verify whoever asks for donations and whoever offers repairs. In California, contractors must be licensed by the CSLB.



#### Two weeks without working

| Item | Amount |
|---|---|
| Missing income | 900 |
| New expense (temporary move) | 200 |
| Savings (transportation to work) | −50 |
| **Total effect** | **1,050** |
| Savings available | 400 |
| **Shortfall** | **650** |

With the shortfall clear, you can decide which payments to move, who to call and what help to ask for.

> **Good to know:** if you get hurt at work, in California you have the right to workers' compensation, regardless of immigration status. If you can't work because of an illness outside of work, ask about State Disability Insurance (SDI).



#### Help after a disaster

When a disaster is declared, there may be help from the state, the county and community organizations. Some help doesn't depend on your immigration status.

Keep receipts for all your emergency expenses: they can help you claim assistance.



#### Emergency alerts

Turn on emergency alerts on your phone and sign up for your county's alert system.

In California, many alerts also come in Spanish. That way you find out about an evacuation in time.



#### Cases


**Case 1. Two weeks without working**

Alex gets hurt outside of work. Alex loses 900 in income; a temporary move costs 200, but saves 50 in transportation.
- *How much is Alex short?* With 400 in savings, 650 short.
- *What does Alex do?* Identifies which payments are due, asks about SDI and calls creditors before falling behind.


**Case 2. The phone lost in the evacuation**

All the family's information was on Mar's phone, which was lost in the evacuation.
- *What would have helped?* A secure copy of the documents and a paper contact list.


**Case 3. Rosa's contractor**

After the fire, a man offers to fix Rosa's roof if she pays everything upfront.
- *What does she do?* She checks his license with the CSLB and pays only as the work progresses, with a written contract.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Keeping everything only on your phone | You lose access to everything | A paper list and copies in another place |
| Counting help that isn't confirmed | You commit to payments you can't cover | Count only what's confirmed |
| Paying a contractor upfront | They disappear with your money | Check their license and pay as work progresses |
| Donating without verifying | Your help doesn't arrive | Donate to organizations you know |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rosa, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does an unconfirmed insurance payment count as a resource? a) Yes · b) No · c) Yes, if the lawyer says you'll win
2. Does homeowners insurance usually cover earthquakes? a) It's usually a separate policy · b) Yes · c) Yes, it's always included
3. Do you keep the only copy of your documents at home? a) Yes · b) Yes, in a locked drawer at home · c) No, also in another safe place
**Answers:** 1-b: only what's confirmed. 2-a: it's bought separately. 3-c: keep copies in two places.



#### Put it into practice

You lose 600 in income in a month and have 250 in savings. How much are you short and what do you do first?
**Answer:** You're 350 short. First you identify which payments are due, call those creditors beforehand and ask about available support.



#### Your plan

List six things in your continuity folder and who knows where it is.



### Learn more

- **Prepare for emergencies** (Ready.gov · English and Spanish): https://www.ready.gov — **What to look for:** "Build a Kit" and "Financial Preparedness," with lists to download.
- **Check a contractor** (California CSLB · English and Spanish): https://www.cslb.ca.gov — **What to look for:** "Check a License" to confirm a contractor's license.
- **Insurance guides** (CDI · English and Spanish): https://www.insurance.ca.gov — **What to look for:** guides to homeowners and renters insurance and what to do after a disaster.

### Key words

- *Contingency plan:* steps prepared to respond to a problem.
- *Inventory of belongings:* a list with photos of your things.
- *CSLB:* California's Contractors State License Board.

### Sources

Ready.gov · CSLB · CDI · DIR, workers' compensation.

---

## M4 U10. What happens to my family and my money if I can't be there?

**What you will be able to do:** Build a family preparedness plan: who takes care of your children, where your documents are and how bills get paid if you can't do it.

**To start:** Daniela is a single mom. One day she thought: "If something happens to me, who picks up my son at school? Who pays the rent?" She had no answer. In this lesson you'll build a plan so your family can keep going if you can't be there.

### The essentials (5 minutes)

#### Preparing isn't giving up

A detention, a hospital stay or an emergency trip can separate you from your family overnight.

A plan made calmly protects your family in a moment of crisis. Preparing isn't giving up: it's caring.



#### The five parts of the plan

| Type | Description | What it means for you |
|---|---|---|
| Care of the children | Who takes care of them and a backup person. | Talk with them today. |
| Documents | Birth certificates, passports, insurance, contracts. | In a place your family knows. |
| Money and accounts | How rent gets paid and who can access what. | With formal authorization. |
| Contacts | Family, school, doctor, attorney, consulate. | On paper. |
| Review | Every six months or if something changes. | Set a reminder. |

#### Three steps to start

1. **Decide who would take care of your children** and talk with that person.
2. **Gather your important documents** in a place your family knows.
3. **Leave instructions** for paying the rent and the bills.



#### The caregiver affidavit

California has the **Caregiver's Authorization Affidavit**.

It lets a trusted adult enroll your children in school and authorize some medical care. It does **not** change custody. It costs nothing and doesn't need a judge.



#### Sharing your password isn't enough

Sharing your bank password does **not** give your family legal permission to act if you're in the hospital or detained.

A **durable financial power of attorney** lets the person you choose pay the rent and manage your accounts legally while you're away.

> **Key idea:** this course doesn't give immigration or legal advice. For your options, go to an attorney or an accredited representative (M4 U02).



#### Do it this week

1. Talk with the person who would take care of your children.
2. Download the Caregiver's Authorization Affidavit.
3. Put birth certificates and passports together in a folder.



#### Check your understanding

1. Does the Caregiver's Authorization Affidavit change custody?
*Answer:* No. It only allows handling school matters and some medical ones.

2. Does sharing your password give legal authorization to manage your money?
*Answer:* No. That requires a power of attorney or another formal authorization.


#### Remember

- Choose a caregiver and a backup person, and talk with them.
- Gather your documents in a known place.
- Use formal authorizations, not passwords.



### Go deeper (5 more minutes)

#### 1. Care of the children

- Choose a trusted person and a backup.
- Update the school's emergency card with their names.
- Fill out the Caregiver's Authorization Affidavit and give a copy to the caregiver.
- For broader decisions, like guardianship, talk to a family law attorney.



#### 2. Documents

Gather originals and copies in a safe place:

- everyone's birth certificates and passports;
- if your children were born in the U.S., consider getting their U.S. passport and registering their dual nationality at the consulate;
- health insurance cards, prescriptions and health information;
- lease, vehicle titles, insurance policies;
- if you have an immigration case, the case number and the contact information of your attorney or accredited representative.



#### 3. Money and accounts

- A list of your accounts, automatic payments and dates, without passwords or full numbers.
- Who will be able to access your money and how. A joint account, an authorized user or a power of attorney give different powers (M5 U08).
- How the rent will be paid and who to notify.
- A small cushion the caregiver can use.

The durable financial power of attorney is prepared with an attorney or a certified legal service and signed before a notary. Ask at your legal aid organization.

> **Good to know:** California has a statutory form for a financial power of attorney. Even so, it's worth reviewing it with a legal service so it covers what you need.



#### 4. Contacts and 5. Review

Write down on paper: family, school, doctor, attorney or legal aid organization, consulate and employer.

Review the whole plan every six months or when something changes: a move, a new job, a new child.



#### If your children were born in the U.S.

Your children born in the U.S. are citizens and have the right to a U.S. passport. Having one can make travel and paperwork easier.

If you're Mexican, your children can also register their Mexican nationality at the consulate. Ask through MiConsulado which documents you need.



#### Cases


**Case 1. Alex and Mar's plan**

They choose Mar's sister as caregiver and a neighbor as backup.
- *What do they prepare?* The caregiver affidavit, a folder with documents and a sheet with the month's payments. The sister knows where everything is.


**Case 2. The password isn't enough**

A family thought sharing the bank password was enough. When the account holder was hospitalized, the bank didn't let anyone else handle anything.
- *What did they need?* A formal authorization, like a durable power of attorney.


**Case 3. Daniela's plan**

Daniela is a single mom and her family is in El Salvador.
- *Who does she choose?* A trusted friend in San Diego as caregiver and her cousin in Los Angeles as backup. She fills out the caregiver affidavit and makes an appointment with a legal service for her power of attorney.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking it won't happen to you | Your family is left without a plan | Prepare it calmly today |
| Choosing a caregiver without talking to them | They don't know what to do | Talk and give them a copy of the plan |
| Sharing passwords instead of authorizing | The bank won't let them act | Use a power of attorney |
| Keeping documents where nobody knows | They can't be found when needed | Tell your caregiver where they are |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does the Caregiver's Authorization Affidavit change custody? a) Yes · b) No · c) Yes, for one year
2. Does sharing your password give legal authorization? a) No · b) Yes · c) Yes, if it's written down
3. How often should you review the plan? a) Never · b) Every five years or when moving to another country · c) Every six months or if something changes
**Answers:** 1-b: it only authorizes school and some medical care. 2-a: a formal authorization is needed. 3-c: life changes.



#### Put it into practice

Write who would be your main caregiver, your backup and where you'll keep your documents.
**Answer:** For example: "My sister as caregiver, my neighbor as backup, and my documents in a folder in the closet with a copy at my sister's house."



#### Your plan

Complete the five sections of the plan. You can use made-up information for the course and keep the real documents only in your private folder.



### Learn more

- **Caregiver's Authorization Affidavit** (California Courts · English): https://courts.ca.gov/documents/caregiver.pdf — **What to look for:** download the form and read the instructions on the first page.
- **Court self-help centers** (California Courts · English and Spanish): https://selfhelp.courts.ca.gov — **What to look for:** "Guardianship" and "Power of attorney" to know when you need each one.
- **List of accredited representatives** (DOJ EOIR · English): https://www.justice.gov/eoir/recognized-organizations-and-accredited-representatives-roster-state-and-city — **What to look for:** organizations near you that help with family preparedness plans.

### Key words

- *Family preparedness plan:* instructions so your family can keep going if you can't be there.
- *Caregiver's Authorization Affidavit:* a California form for a minor's school matters and some medical matters.
- *Durable power of attorney:* authorizes another person to manage your money, even if you're incapacitated.

### Sources

[R39] California Courts, caregiver authorization · [R38] DOJ EOIR · California Probate Code, power of attorney.

---

## M4 U11. How do I know if my protection plan works?

**What you will be able to do:** Bring together prevention, protection and response, and test your plan with a drill.

**To start:** Rosa had her plan written on a sheet: contacts, documents, savings. One day she lost her phone and realized she didn't remember her email password. The sheet looked complete, but it didn't work. In this lesson you'll test your plan before you need it.

### The essentials (5 minutes)

#### A plan you can use

A plan works if you can use it, not if it looks complete on a sheet.

The best way to find out is to practice with a made-up situation: a **drill**.



#### A plan connects four things

| Type | Description | What it means for you |
|---|---|---|
| Risk | What can happen. | Losing your phone. |
| Impact | What it affects. | You can't get into your bank. |
| Protection | What you already have. | A recovery email and a paper list. |
| Action | What you do step by step. | Call, change passwords, notify. |

#### Your drill in three steps

1. **Choose a situation**, for example: you lose your phone and rent is due tomorrow.
2. **Explain each step** in order, without skipping any.
3. **Mark** what you still couldn't do and how to solve it.



#### A case in one minute

Rosa did her drill: she lost her phone. She found out she didn't know her email password and that her contact list was only on her phone.

She wrote her contacts on paper, asked her daughter to help her update her recovery email and kept the sheet in her backpack.

> **Key idea:** a plan that only works for one emergency needs adjustments.



#### Do it this week

1. Choose a situation and do your drill in 15 minutes.
2. Write down what was missing.
3. Fix one thing this same week.



#### Check your understanding

1. Does a protection plan require buying every insurance?
*Answer:* No. It's about identifying gaps and deciding how to cover them.

2. What is a drill for?
*Answer:* To discover what still doesn't work, before a real emergency.


#### Remember

- Test your plan with a made-up situation.
- Fix what didn't work.
- Review your plan when your life changes.



### Go deeper (5 more minutes)

#### Start with what affects you most

Prioritize the risks that can affect your housing, your income, your health or your safety.

Don't try to buy every insurance. Identify the gaps and decide what you can prevent and what you can cover with savings. Then decide what you can transfer to an insurance policy and what you need to handle with support.



#### For each risk, define

| Part | Example: losing your phone |
|---|---|
| Warning sign | You can't find your phone or it's stolen |
| Safe immediate action | Call the phone company from another phone |
| Verified channel | Your bank's number on your paper list |
| Follow-up | Check transactions and change passwords |



#### Three drills to practice

1. You lose your phone and rent is due tomorrow. How do you get access back? What information do you need and where is it?
2. An unexpected medical bill arrives. Which steps change?
3. A fake family emergency arrives when your income has dropped. Which parts of the plan do you use?

> **Good to know:** emergency plans that are practiced at least once a year work much better than ones that are only written. Many schools and workplaces hold drills for that reason.



#### When to review

Review your plan when your job, your home, your phone, your vehicle or your dependents change.

Set a reminder on your calendar to do a drill once a year.



#### What you achieved in this module

Now you know how to recognize scams, verify who can help you with immigration matters and protect your accounts. You can respond to fraud and recognize financial abuse. You can also build savings, understand your insurance and your medical bills, and prepare your family.



#### Do the drill as a family

Practicing as a family helps everyone know what to do. Ask each person: where's the backpack? Who do you call? Where do we meet if there's no signal?

Children can also learn a relative's phone number by heart.



#### What's next

In Module 5 you'll learn to build wealth and prepare your future: goals, investing, housing, retirement and your own business.



#### Cases


**Case 1. Alex's risk**

Risk: losing hours because of an accident. Protections: some coverage through work and 300 in savings. Gap: basic expenses are 1,800 a month.
- *What does Alex do?* Checks the coverage and support available, builds a scenario and slowly increases the savings. Alex doesn't assume 300 solves the risk.


**Case 2. Daniela's drill**

Daniela practices: "I'm in the hospital for a week."
- *What does she find out?* That her friend, the caregiver, didn't have a key to her house or know where the folder was. She fixes it that week.


**Case 3. Mar's fake emergency**

In her drill, Mar gets a fake call from a relative right when her hours were cut.
- *Which parts of the plan does she use?* The family code word, her calendar, her savings and her remittance agreement.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Writing the plan and not testing it | It fails when you need it | Do a drill |
| Trying to cover everything with insurance | You spend too much | Prioritize your main risks |
| Not updating the plan | It has old information | Review it when something changes |
| Keeping the plan where nobody can find it | It's useless in an emergency | Tell your family where it is |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Alex and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does a protection plan require buying every insurance? a) Yes · b) No · c) Yes, at least three
2. A fake emergency arrives when your income has dropped. Which parts do you use? a) Verification, calendar, savings and remittance agreement · b) Only the savings · c) Only the code word and the usual number
3. How often should you do a drill? a) Never · b) Only when something happens · c) At least once a year
**Answers:** 1-b: you prioritize the gaps. 2-a: the plan works as a whole. 3-c: practicing keeps the plan useful.



#### Put it into practice

Do the drill "I lose my phone and rent is due tomorrow." Write your steps and what was missing.
**Answer:** For example: I call the phone company from another phone, change my email password, tell the bank and pay the rent from another computer. My paper contact list was missing.



#### Your plan

Turn in your Module 4 file: five priority risks, a comparison of two coverages, an incident protocol, the index of your continuity folder and your family preparedness plan, with no sensitive information. Your reasoning is evaluated, not buying products. Also solve integrated case E4 in the support materials.



### Learn more

- **Prepare for emergencies** (Ready.gov · English and Spanish): https://www.ready.gov — **What to look for:** the guide to making a family plan and practicing it.
- **Identity theft** (FTC · English and Spanish): https://www.identitytheft.gov — **What to look for:** the list of steps to use in your identity theft drill.

### Key words

- *Gap:* the difference between your risk and your protection.
- *Drill:* practice of a made-up situation.

### Sources

Ready.gov · FTC, IdentityTheft.gov.

---

## M4 U12. How do I make sure child support reaches my kids?

**What you will be able to do:** Learn what child support is in the U.S., how to request it through your state agency, how to pay it with proof and what to do if the other parent lives in Mexico.

**To start:** Daniela is raising her son alone in San Diego. His father gives "when he can," in cash. Daniela is afraid to ask for more because she thinks her immigration status keeps her from going to a government office.

### The essentials (5 minutes)

#### The basics

| Type | Description | What it means for you |
|---|---|---|
| It's your children's right | Not the mother's or father's. | Set with a state formula. |
| Your state's child support agency | Helps establish, collect and record payments. | Low-cost services. |
| Payment with proof | Through the agency or wage withholding. | Never cash without a receipt. |
| If the other parent lives in Mexico | Ask your agency and your consulate. | There may be agreements. |

#### How to request it

Your state's child support agency can help establish paternity. It can also set an amount with the state formula and collect it, often with a deduction straight from the other parent's wages. In general they serve parents regardless of immigration status. Ask what documents they need.



#### If you're the one paying

Pay through the agency or wage withholding and keep proof. Cash or "side" payments may not count. If your income drops, request a modification; don't stop paying on your own.



#### A case in one minute

Daniela called her county's agency. They asked for her son's birth certificate and information about his father. Now the payment arrives through the agency every month and is recorded.

> **Key idea:** child support is your children's right. Your state agency helps request it and record payments. The paying parent must pay with proof.



#### Check your understanding

1. Who helps establish and collect child support?
*Answer:* Your state's child support agency.

2. What do you do if you pay and your income drops?
*Answer:* Request a modification; don't stop paying on your own.


#### Remember

- It's your children's right.
- Your state agency helps.
- Always pay with proof.



### Go deeper (5 more minutes)

#### Between the U.S. and Mexico

If the other parent lives in Mexico, tell your agency: some states have agreements with Mexico to collect child support. Your consulate can also guide you. If you live in the U.S. and your children live in Mexico, they can request child support (pensión alimenticia) before a judge there.



#### If it isn't paid

States can withhold wages, intercept tax refunds or suspend licenses of parents who don't pay. The debt doesn't disappear over time.



#### Manage what you receive

Record child support as your children's income and set aside the big yearly expenses (school, clothes, health).



#### Cases


**Case 1. "When I can"**

The father of Daniela's son pays only when he can, in cash.
- *What does Daniela do?* She calls her county's child support agency.


**Case 2. Andrés's payments**

Andrés pays child support for a daughter from a previous relationship, in cash and without a receipt.
- *What does he do?* He pays through the agency or with proof.


**Case 3. Rosa's grandson**

The father of Rosa's grandson lives in Mexico and doesn't pay.
- *What does Rosa's daughter do?* She asks her agency and her consulate about agreements with Mexico.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Thinking you can't request it | Your children lose their right | Ask your agency |
| Paying cash without a receipt | It may not count | Pay with proof |
| Stopping without a modification | The debt grows | Request a change |
| Mixing it with everything | It doesn't last | Track it separately |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Andrés and Rosa. Choose the best decision in each; if you miss, you can try again. Earns experience points.



#### Quiz

1. Whose right is child support? a) The children's · b) The receiving parent's · c) The state's
2. How do you pay so it counts? a) In cash, hand to hand · b) Through the agency or wage withholding · c) Whenever you can
3. Your income dropped and you pay child support. What do you do? a) Stop paying · b) Pay half · c) Request a modification
**Answers:** 1-a: it's for what they need. 2-b: it gets recorded. 3-c: the debt continues until it's changed.



#### Put it into practice

Child support is 450 dollars a month. How much is it a year, and how many receipts do you keep?
**Answer:** 450 × 12 = 5,400 dollars; 12 receipts.



#### Your plan

If you pay or receive child support, gather this year's receipts in a folder or in photos.



### Learn more

- **Child support** (Administration for Children and Families · English and Spanish): https://www.acf.hhs.gov/css — **What to look for:** "state child support agency."
- **Your consulate** (SRE · Spanish): https://consulmex.sre.gob.mx — **What to look for:** "protección" and "pensión alimenticia."

### Key words

- *Child support:* payments from the parent who doesn't live with the children to cover their needs.
- *Modification:* a change to the child support amount approved by the agency or the court.

### Sources

Office of Child Support Services (ACF) · SRE, accessed September 30, 2026.

---


# Part 6. Module 5. Build wealth and prepare your future

## M5 U01. How do I turn a wish into a goal?

**What you will be able to do:** Measure your net worth and set goals with an amount, a date and a priority, without counting the same money twice.

**To start:** Rubén wants to study English, help his mom fix her house and someday buy a car. He's eager, but every month the money goes and no goal moves forward. In this lesson you'll learn to turn wishes into goals you can actually reach.

### The essentials (5 minutes)

#### A wish is not a goal

"I want a house" is a wish. "I want to save 15,000 dollars for the down payment and buying costs in five years" is a goal.

The difference is that the goal has numbers and a date. That way you know how much to set aside each month.



#### A goal has four parts

| Type | Description | What it means for you |
|---|---|---|
| Amount | How much it costs. | 600 dollars. |
| Date | By when. | In 12 months. |
| Currency | What currency it's paid in. | Dollars or pesos. |
| Priority | What comes first if there isn't enough for everything. | 1, 2 or 3. |

#### How much to set aside each month

You want to pay for something that costs 120 in 6 months and you have nothing set aside.
- What it costs: **120**
- What you already have for that goal: **0**
- What's missing: 120 ÷ 6 = 20 a month: **120**
Check whether those 20 fit in your budget.


#### The same dollar doesn't pay for two goals

If you have 80 left over a month and your goals need 150, you can't assign the same 80 to each one.

You have to change amounts, deadlines or priorities. It's better to move forward on one goal than on none.



#### A case in one minute

Rubén has 150 left over a month. His goals: a 600 English course in 12 months (50 a month), his mom's 1,200 roof in 12 months (100 a month) and a 3,000 car in 24 months (125 a month). That adds up to 275.

He decides to start with the course and the roof (150) and leave the car for when he finishes the course.

> **Key idea:** a goal has an amount, a date, a currency and a priority.



#### How to order your goals

1. **First, your savings cushion:** a small emergency goal protects all the others. Without it, any surprise forces you to use another goal's money or go into debt.
2. **Next, what avoids costs:** paying off an expensive debt usually "earns" more than any savings.
3. **Then, what improves your life:** a course, a move, a car.
4. **Last, the wishes that aren't urgent:** you can move their date with no problem.

This order is a guide, not a rule. Your family decides what comes first.



#### Check your understanding

1. You want 600 in 12 months and already have 180 set aside. How much do you set aside each month?
*Answer:* 35, because 420 is missing and 420 ÷ 12 = 35.

2. Can you assign the same 80 to three goals?
*Answer:* No. Each dollar has only one job.


#### Remember

- Turn each wish into an amount, date, currency and priority.
- Calculate how much to set aside each month.
- If it isn't enough, change deadlines or priorities.



### Go deeper (5 more minutes)

#### Your net worth

Your **net worth** is what you have minus what you owe, on a given date.

| What you have | | What you owe | |
|---|---|---|---|
| Cash | 800 | Car loan | 5,500 |
| Savings | 1,200 | Credit card | 1,000 |
| Car (estimated value) | 7,000 | | |
| **Total** | **9,000** | **Total** | **6,500** |

Net worth: 2,500. But the money you could use tomorrow is only 2,000.



#### Liquidity

Not everything you own turns into cash quickly. A house, a car and a savings account have different **liquidity**.

That's why, besides your net worth, check how much money you could use in an emergency.



#### Your net worth is not your worth

Use realistic values and mark the estimates. Sentimental value isn't a sale price.

A negative net worth describes a situation, not a person's worth. Many people start with a negative net worth because of student or car debts, and improve it over time.



#### Short-term and long-term goals

- **Short term** (less than 2 years): the money should be safe and available, for example in a savings account.
- **Long term** (5 years or more): you can consider options that grow more, with more risk (M5 U02).

Separating your goals by time frame helps you decide where to keep the money for each one.

> **Good to know:** according to Federal Reserve research, people who write down their goals and set money aside automatically save more. Those who decide each month save less.



#### Goals in two currencies

If your goal is in Mexico, like your mom's roof, the exchange rate can change the amount you need in dollars.

If today 20,000 pesos equal about 1,100 dollars, in a year it could be more or less. Review your goal every three months and adjust what you set aside.

A simple way to protect yourself is to set aside a little more than you calculate, for example 10%. That covers changes in the exchange rate and in the cost of sending money (M2 U08).



#### Cases


**Case 1. Daniela's course**

Daniela wants a 600 baking course in 12 months, with no debt. She already has 180 set aside just for that.
- *How much does she set aside each month?* 420 is missing: 35 a month.


**Case 2. Andrés's net worth**

Andrés has a net worth of 2,500, but if a 2,300 bill arrives tomorrow, he can't use his car to pay it.
- *What does he still need to check?* His liquidity: how much money he can use right away.


**Case 3. Rubén's goals**

Rubén has three goals that add up to 275 a month and only 150 left over.
- *What does he do?* He prioritizes two and puts off the third. He doesn't assign the same money to all three.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Having wishes with no numbers | You never know if you're making progress | Give it an amount and a date |
| Assigning the same money to several goals | You think you have more | Every dollar, one job |
| Confusing net worth with available money | You can't pay for an emergency | Check your liquidity |
| Wanting every goal at the same time | None move forward | Prioritize |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Assets 12,000 and debts 8,500. Net worth? a) 20,500 · b) 8,500 · c) 3,500
2. Is net worth the same as available cash? a) Yes · b) No · c) Yes, if it includes the car
3. Can you assign the same 80 to three goals? a) No · b) Yes · c) Yes, if they're small goals
**Answers:** 1-c: 12,000 − 8,500. 2-b: it includes things that aren't cash. 3-a: every dollar has one job.



#### Put it into practice

Write three goals with an amount, date, currency and priority. Separate the one that needs money soon from the long-term one.
**Answer:** For example: 1) A 500 savings cushion in 5 months (dollars). 2) A 600 course in 12 months (dollars). 3) A 20,000-peso roof in 18 months (pesos). The first two are short term.



#### Your plan

Write down your three goals and how much you'll set aside for each one. Check whether they fit in your budget.



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "Setting SMART goals" tool and the "Net worth" tool.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the savings module and the worksheet to calculate your net worth.

### Key words

- *Net worth:* what you have minus what you owe.
- *Liquidity:* how quickly you can use a resource.
- *Contribution:* money you add to a goal.

### Sources

CFPB, Your Money, Your Goals · Federal Reserve, Survey of Consumer Finances.

---

## M5 U02. Does having more money mean my investment made money?

**What you will be able to do:** Choose between saving and investing based on time frame, risk and access, and calculate returns without fooling yourself.

**To start:** Andrés saw that his retirement account went from 2,000 to 2,300 in a year and thought he had earned 300. But he had put in 250 from his pay. In reality, the investment only earned 50. In this lesson you'll learn to measure what your money really earns.

### The essentials (5 minutes)

#### What you put in isn't a gain

You start with 100, add 20 from your own pocket and end with 125.
- What you have at the end: **125**
- What you put in (100 + 20): **120**
- What the investment earned: **5**
What you put in isn't a gain from the investment.


#### Saving and investing are not the same

| Type | Description | What it means for you |
|---|---|---|
| Saving | Keeping money in a safe, available place. | It grows a little, but doesn't go down. |
| Investing | Putting money in something that can go up or down. | It can grow more, but it can also lose. |

#### The time frame decides

If you'll need the money in less than one or two years, access and stability matter more than trying to earn a lot.

If you won't need it for many years, you can ride out ups and downs.



#### Ups and downs don't cancel out

If an investment goes up 20% one year and down 20% the next, you don't end up the same.

1,000 goes up to 1,200 and then down to 960. You lost 4%. To recover from a 20% drop, you need to go up 25%.



#### A case in one minute

Rosa needs 1,000 in three months for a trip to Guadalajara. Someone recommends an investment that "could go up 15%."

Rosa asks: "And if it goes down?" It could drop 20% and leave her with 800. Since she needs the money soon, she keeps it in a savings account.

> **Key idea:** having more dollars doesn't always mean being able to buy more. Check inflation.



#### Three questions before investing

| Type | Description | What it means for you |
|---|---|---|
| When do I need it? | If it's in less than two years, saving is better. | The time frame rules. |
| Do I have my savings cushion? | Without it, an emergency forces you to sell at a bad time. | Cushion first. |
| Do I have expensive debts? | Paying off a card at 25% "earns" more than almost any investment. | Pay the expensive debt first. |

If you answer all three well, you can start investing with a little, calmly.
> **Before you act, check:** who manages the investment, how much it charges in total and how you get your money out. Also check whether it's registered with the SEC or FINRA.

#### Check your understanding

1. Your account went from 2,000 to 2,300 and you put in 250. How much did the investment earn?
*Answer:* 50, because 2,300 − 2,000 − 250 = 50.

2. An investment goes up 10% and then down 10%. Starting from 1,000, how much is left?
*Answer:* 990, because 1,000 × 1.10 × 0.90 = 990.


#### Remember

- Separate what you put in from what the investment earned.
- If you need the money soon, don't invest it in something that can go down.
- Check fees and inflation.



### Go deeper (5 more minutes)

#### Where a gain comes from

You buy an investment for 1,000. In a year it pays you 40 and at the end it's worth 1,030.

| Item | Calculation | Result |
|---|---|---|
| Return from payments | 40 ÷ 1,000 | 4% |
| Change in price | 30 ÷ 1,000 | 3% |
| Total return | 70 ÷ 1,000 | 7% |
| With 15 in fees and 10 in taxes | 45 ÷ 1,000 | 4.5% net |



#### Real return

With a 4.5% net return and 3% inflation: 1.045 ÷ 1.03 − 1 = 1.46%. That's the real increase in your buying power.

Getting payments doesn't guarantee a gain. If the investment ends up worth 900 and paid 40, you lost 60.



#### Compare equal periods

2% in three months isn't 2% a year.

From 1,000 to 1,210 in two years is 21% in total, but 10% a year compounded.



#### Diversifying

**Diversifying** means spreading your money across different investments. It spreads the risk, but it doesn't eliminate losses.

Having many investments in the same sector isn't diversifying.

> **Good to know:** a 1% yearly fee seems small, but over 30 years it can eat up almost a quarter of what you would have built up. Always compare fees.



#### Riding out a drop

Being able to handle a drop emotionally isn't the same as being able to pay the rent if it happens.

Before investing, make sure you have your emergency fund and won't need that money soon.



#### Compound interest: time on your side

**Compound interest** makes what you earn start earning too.

1,000 at 5% for 10 years becomes about 1,629. For 30 years, about 4,322. Time matters more than the amount.

That's why starting early, even with a little, helps more than waiting to have a lot. Remember that 5% is an example: nobody can guarantee that return.



#### Cases


**Case 1. Rosa's trip**

Rosa needs 1,000 in three months.
- *Does she invest in something that can go up or down?* No. If it drops 20%, she wouldn't have enough for her trip. She uses a savings account.


**Case 2. Andrés's balance**

Andrés's retirement account went from 2,000 to 2,300, but he put in 250.
- *How much did the investment earn?* 50.


**Case 3. Rubén's "average"**

A friend tells Rubén that his investment "averaged 0%": it went up 20% and down 20%.
- *Did it stay the same?* No. From 1,000 it went to 960: it lost 4%.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Counting your contributions as gains | You think you earned more | Subtract what you put in |
| Investing money you need soon | You can lose it when you need it | Use savings for near-term goals |
| Ignoring fees | They eat your gains | Always compare them |
| Averaging ups and downs | You miscalculate | Multiply the changes |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Rosa and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. 1,000 at 4% for two years, with no contributions. Balance? a) 1,080 · b) 1,040 · c) 1,081.60
2. An investment goes up 10% and then down 10%. Starting from 1,000, how much is left? a) 1,000 · b) 990 · c) 1,010
3. Net return 5% and inflation 4%. Approximate real return? a) 0.96% · b) 9% · c) 1%
**Answers:** 1-c: compound interest. 2-b: 1,000 × 1.1 × 0.9. 3-a: 1.05 ÷ 1.04 − 1.



#### Put it into practice

For one goal, write down the time frame, how much you need available, how much you could lose without affecting your life and the costs.
**Answer:** For example: "Down payment in 5 years; I won't need it before then; I could handle a 10% drop one year; I'll look for fees under 0.5%."



#### Your plan

For each goal write down time frame, liquidity, loss you could handle and costs. Don't choose based only on past returns.



### Learn more

- **Investor.gov** (SEC · English and Spanish): https://www.investor.gov — **What to look for:** "Investing basics" and the explanation of risk and diversification.
- **Compound interest calculator** (SEC Investor.gov · English): https://www.investor.gov/financial-tools-calculators/calculators/compound-interest-calculator — **What to look for:** try a monthly contribution with different rates and time frames.

### Key words

- *Return:* the gain or loss of an investment.
- *Real return:* adjusted for inflation.
- *Diversification:* spreading the risk.
- *Volatility:* how much a value goes up and down.

### Sources

[S23] SEC Investor.gov · [R30] SEC, fees.

---

## M5 U03. Does opening an account mean I already invested?

**What you will be able to do:** Tell apart the account (the container) from the investment (what's inside) and verify who sells it to you.

**To start:** Andrés opened a retirement account a year ago and deposits money every month. When he checked, his money hadn't grown: it was sitting in cash, because he never chose what to invest in. In this lesson you'll learn the difference between opening an account and investing.

### The essentials (5 minutes)

#### The bag and what you keep inside

| Type | Description | What it means for you |
|---|---|---|
| The account (the container) | An investment or retirement account, like an IRA or a 401(k). | It has rules, but doesn't grow on its own. |
| What's inside | What you buy inside: cash, stocks, bonds or funds. | This is what goes up or down. |

#### Opening the account isn't investing

A retirement account is like a bag. If you put money in and don't choose what to buy, it stays in cash.

The name "retirement account" doesn't say what your money is invested in.



#### Three questions about your account

1. **Which account do I use?** IRA, 401(k), CalSavers, brokerage account.
2. **What product did I really buy?** Ask for the exact name.
3. **How does it gain or lose value, and how do I take my money out?**



#### Verify who sells to you

Before investing, look up the company and the person on FINRA's **BrokerCheck** or in the SEC's adviser database.

Ask whether your money goes to the institution or to the seller's personal account. If it goes to a personal account, it's a red flag.



#### A case in one minute

Daniela got a message from a social media "adviser" promising 20% a month in cryptocurrency.

She looked up his name on BrokerCheck and he wasn't there. She didn't invest. A month later, several people in the group reported they had lost their money.

> **Key idea:** nobody can guarantee you a high return with no risk.



#### Types of accounts

| Account | What it's for | What to check |
|---|---|---|
| Brokerage account | Buying and selling investments | Fees and custody |
| IRA | Saving for retirement with tax advantages | You need work income |
| 401(k) | Employer retirement plan | Employer contribution |
| CalSavers | State retirement plan | How much is deducted |

Inside each one, you choose what to buy. If you don't choose, the money may stay in cash.

> **Before you act, check:** the product's exact name, where your money is held and whether the person appears on BrokerCheck.



#### Check your understanding

1. Is an IRA the same as a stock?
*Answer:* No. The IRA is the account; a stock is something you can buy inside it.

2. Where do you check a broker?
*Answer:* On FINRA's BrokerCheck or in the SEC's database.


#### Remember

- The account is the container; the investment is what's inside.
- Check what your money is invested in.
- Verify who sells to you before investing.



### Go deeper (5 more minutes)

#### Basic products

| Product | What it is | Main risks |
|---|---|---|
| Certificate of deposit (CD) | Money at a bank for a set term | A penalty for withdrawing early |
| Bond | A loan to a company or government | That they don't pay; the price changes |
| Stock | A piece of a company | It can go up or down a lot |
| Fund | A managed set of investments | Fees; it can be concentrated |
| ETF | A fund bought and sold on the stock market | Like a fund |
| Crypto assets | Speculative digital assets | Big drops, fraud, custody |



#### Who holds your investments

**Custody** is who holds your investments and keeps the record that they're yours.

SIPC protection covers certain cases if the brokerage firm fails, but it does **not** protect against market drops.



#### Red flags

- "High guaranteed return."
- Gains people show off on social media.
- Pressure to decide quickly.
- Payments only in cryptocurrency or to personal accounts.
- "Invite your friends and earn more."

> **Good to know:** according to the FTC, cryptocurrency investment scams have cost people in the U.S. some of the most money in recent years.



#### Really diversifying

Having two "technology" funds with almost the same companies isn't diversifying: it doubles your risk.

A broad index fund, which holds hundreds of companies in different sectors, is usually a simple, low-cost way to diversify.



#### Target date funds

Many retirement plans offer **target date funds**, with a year in the name, like "2055."

They adjust their risk on their own: more stocks when there's a long way to go and more bonds as retirement gets closer. They're a simple option if you don't want to choose fund by fund.

Even so, check their yearly fee and that the fund's year is close to the year you plan to retire.



#### Cases


**Case 1. The IRA in cash**

Andrés opened an IRA a year ago and his money is still in cash because he never chose any investments.
- *What does he do?* He asks his plan administrator what options he has and chooses based on his time frame and risk.


**Case 2. Rubén's two funds**

Rubén bought two "technology" funds that hold almost the same companies.
- *Did he diversify?* No. He doubled his risk in the same sector.


**Case 3. The social media adviser**

Daniela gets an offer of 20% a month in cryptocurrency.
- *What does she do?* She looks up the adviser on BrokerCheck, he isn't there and she doesn't invest.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Opening the account and not choosing investments | The money doesn't grow | Check what it's invested in |
| Believing in guaranteed returns | A scam | Nobody guarantees without risk |
| Investing with someone without verifying | You lose your money | Look them up on BrokerCheck |
| Believing having many funds is diversifying | Concentrated risk | Check what's inside each one |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Is an IRA the same as a stock? a) Yes · b) Yes, if it's from a big company · c) No
2. Is having two similar funds diversifying? a) Yes · b) Not necessarily · c) Yes, as long as they're from different companies
3. Where do you check a broker? a) BrokerCheck · b) On their social media · c) With the adviser, by message
**Answers:** 1-c: one is the account and the other the product. 2-b: they may hold the same things. 3-a: it's the official registry.



#### Put it into practice

You're offered an investment with "15% guaranteed per year." What questions do you ask?
**Answer:** Who is the company and is it registered? Where is my money held? What happens if it goes down? What are all the fees? And I look it up on BrokerCheck before deciding.



#### Your plan

Fill in the investment sheet: account, product, goal, risk, cost, access and verified company. If you can't explain it, write down what you need to learn before signing up.



### Learn more

- **Check a broker or adviser** (FINRA BrokerCheck · English): https://brokercheck.finra.org — **What to look for:** type the person's or company's name and check their registration and complaints.
- **Investor.gov** (SEC · English and Spanish): https://www.investor.gov — **What to look for:** the guide to investment products and the one on fraud warning signs.

### Key words

- *Retirement account:* a structure with tax and withdrawal rules.
- *ETF:* a fund traded on the stock market.
- *Credit risk:* that the issuer doesn't pay.
- *Custody:* who holds your investments.

### Sources

[S24] SEC, investment products · [R31] SEC, diversification · [R32] SEC, bonds · FTC, cryptocurrency fraud.

---

## M5 U04. Rent or buy? What rights do I have as a tenant?

**What you will be able to do:** Know your basic rights as a tenant in California and the real costs of buying a home, even with an ITIN.

**To start:** Andrés dreams of buying a house in Sacramento. Carmen, his wife, would rather keep renting for a few years. While they decide, the landlord announces a 15% rent increase. In this lesson you'll learn your rights as a tenant and what buying really costs.

### The essentials (5 minutes)

#### Renting isn't "throwing money away"

Paying rent isn't throwing money away: you pay for a safe place to live and the flexibility to move.

Buying isn't always better either. It depends on how long you'll stay, your stability and all the costs.



#### Your rights as a tenant in California

| Type | Description | What it means for you |
|---|---|---|
| Limit on rent increases | Many homes have a yearly cap: 5% plus local inflation, with a maximum of 10%. | Some are exempt. |
| Just-cause eviction | In many homes, the landlord needs a valid reason to end the lease. | Ask for the reason in writing. |
| Your immigration status | The landlord can't ask about it or use it to rent to you or evict you. | It's the law in California. |
| A livable home | The landlord must make the necessary repairs. | Ask in writing. |

#### If you get eviction papers

If you get eviction papers from a court, the deadline to respond is **only a few days**.

Get legal help right away. Don't ignore the papers, even if you think they're wrong.



#### Buying costs more than the mortgage

A rent of 1,800 and a **mortgage** of 1,800 don't cost the same.

When you buy, you also pay property tax, homeowners insurance, maintenance and, sometimes, association fees.



#### A case in one minute

The landlord announces a 15% increase to Andrés. Andrés checks whether his building has a rent cap: it does.

He answers in writing that the increase allowed this year is lower, citing the law. The landlord adjusts the increase.

> **Key idea:** keep your lease, your receipts, photos of the home when you move in and all your messages with the landlord.



#### What to keep as a tenant

- Your signed lease and any change in writing.
- Rent receipts, especially if you pay in cash. Always ask for a receipt with the date and amount.
- Photos and videos of the home when you move in and when you move out.
- Messages and letters with the landlord about repairs or increases.

With these papers you can defend yourself if there's a disagreement about the rent, the deposit or an eviction.



#### Check your understanding

1. Can the landlord ask about your immigration status in California?
*Answer:* No. The law prohibits it.

2. Does an 1,800 mortgage cost the same as 1,800 in rent?
*Answer:* No. Buying has more costs: taxes, insurance, maintenance.


#### Remember

- Know the rent cap and your rights.
- Keep everything in writing.
- If court papers arrive, get legal help now.



### Go deeper (5 more minutes)

#### Security deposit

In California, since 2024, the security deposit generally can't be more than one month's rent. Some small landlords can ask for up to two.

When you move out, the landlord must return the deposit or explain in writing what was deducted, within 21 days.



#### Buying: the full costs

| Cost | What it is |
|---|---|
| Down payment | The part of the price you pay upfront |
| Closing costs | Paperwork, appraisal, insurance, fees |
| Mortgage | Principal and interest |
| Property tax | Yearly, based on the value |
| Homeowners insurance | Required with a mortgage |
| Maintenance | Worth setting aside for each month |
| Association fees (HOA) | In some developments |



#### Buying with an ITIN

Some lenders, like certain credit unions and community development financial institutions (CDFIs), offer mortgages with an ITIN. They usually require a bigger down payment and have higher rates.

Compare at least two options and check the total cost.



#### Homebuying assistance programs

In California there are programs that help first-time buyers with the down payment and closing costs. Some are state programs, like those of the California Housing Finance Agency (**CalHFA**), and some are local.

CalHFA programs require citizenship or an immigration status recognized by federal law. So, with only an ITIN, you can't use CalHFA today. Some local programs have different rules; ask each one directly.

> **Current fact:** CalHFA's Dream For All mortgage requires each borrower to be a citizen or a "qualified alien" under federal law. In 2024, AB 1840, a bill to open the program to people with an ITIN, was vetoed. Accessed October 6, 2026 through CalHFA and California news outlets.

A **HUD-certified housing counselor** can help you at no cost or at low cost. They review with you which programs apply and whether you qualify for a mortgage with an ITIN. They also help you see how much you need to save.

> **Good to know:** the counselor can also help if you already own a home and fall behind on the mortgage. That way you don't lose it.



#### Reporting rent to your credit history

Some landlords and services report your rent payments to the credit agencies. In California, owners of buildings with more than 15 units and some companies that own several properties must offer that option (AB 2747). They may charge you up to 10 dollars a month.

If you pay on time, this can help you build a credit history for a future mortgage (M3 U03).

Before accepting, ask whether it has a cost, whether they also report late payments and how to cancel the service.



#### Cases


**Case 1. Andrés's rent increase**

The landlord announces a 15% increase.
- *What does Andrés do?* He checks whether his building has a rent cap, confirms it and answers in writing with the allowed increase.


**Case 2. Andrés's dream**

Andrés wants to buy a house. A housing counselor helps him calculate the down payment, closing costs, taxes and insurance.
- *What does he find out?* That he needs 18 more months of saving and to check his credit. He also checks whether he qualifies for an assistance program.


**Case 3. Daniela's deposit**

Daniela moved out and the landlord didn't return her deposit.
- *What can she do?* Ask in writing for the refund or the list of deductions, with her photos of how she left the apartment. If there's no answer in 21 days, she can file in small claims court.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Accepting any increase without checking | You pay more than allowed | Check whether the cap applies |
| Ignoring eviction papers | You can be removed without defending yourself | Get legal help right away |
| Comparing only rent to mortgage | You underestimate the cost of buying | Add up all the costs |
| Not taking photos when you move in | You lose your deposit | Take dated photos |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Can the landlord ask about your immigration status in California? a) Yes · b) Only if it's a large building · c) No
2. Does an 1,800 mortgage cost the same as 1,800 in rent? a) Yes · b) No, there are more costs · c) Yes, if the rate is fixed
3. If you get court eviction papers, what do you do? a) Get legal help right away · b) Wait · c) Move out without notice to avoid court
**Answers:** 1-c: it's prohibited. 2-b: there are taxes, insurance and maintenance. 3-a: the deadline is very short.



#### Put it into practice

Your rent is 1,800 and you're told about a 12% increase. What do you check before accepting it?
**Answer:** Whether your home has a rent cap, what the maximum allowed increase is this year in your area, and I answer in writing if the increase is higher.



#### Your plan

Keep your lease and your receipts. If you want to buy, make an appointment with a certified housing counselor.



### Learn more

- **2026 Landlord-Tenant Guide** (California Department of Real Estate · English): https://www.dre.ca.gov/publications/ResourceGuidebook/2026_Landlord_Tenant_Guide.pdf — **What to look for:** the chapter on rent caps, deposits and evictions.
- **Find a housing counselor** (CFPB and HUD · English): https://www.consumerfinance.gov/find-a-housing-counselor/ — **What to look for:** type your ZIP code to see certified counselors near you and whether they offer help in Spanish.
- **Buying a house** (CFPB · English and Spanish): https://www.consumerfinance.gov/owning-a-home/ — **What to look for:** the step-by-step guide and the tool to compare mortgage rates.
- **CalHFA** (California Housing Finance Agency · English and Spanish): https://www.calhfa.ca.gov — **What to look for:** the first-time homebuyer programs and their requirements.

### Key words

- *Down payment:* the upfront payment when buying.
- *Closing costs:* the expenses of the purchase.
- *Mortgage:* a loan to buy a home.
- *Rent cap:* the maximum increase allowed.

### Sources

[R44] California, tenants' rights guide · [R22] CFPB, housing counselors · AB 12 (deposits, 2024) · AB 2747 (rent reporting) · CalHFA · AB 1840 (veto, 2024).

---

## M5 U05. Is the advertised price all it costs?

**What you will be able to do:** Compare a car or a course by its total cost and its flexibility.

**To start:** Rubén saw a car ad for "only 280 a month." It seemed perfect. When he added insurance, gas and maintenance, the car cost him 650 a month. In this lesson you'll learn to see everything something costs before you buy it.

### The essentials (5 minutes)

#### The advertised price isn't everything

A car may ask for a 200 monthly payment and also require insurance, gas and maintenance.

The **total cost of ownership** includes everything you pay to own and use something.



#### Rubén's two cars

| | Car A | Car B |
|---|---|---|
| Payment | 280 | 340 |
| Insurance | 160 | 120 |
| Gas | 140 | 80 |
| Maintenance | 70 | 60 |
| **Total per month** | **650** | **600** |

The car with the lower payment costs more each month.



#### Three steps to compare

1. **Write down the advertised payment.**
2. **Add the other costs:** insurance, gas, maintenance, registration.
3. **Compare** the options with the same list, including the option of waiting.



#### Education too

A course has tuition, but also materials, transportation, child care and the income you give up while you study.

Check that the provider is real and recognized. An ad promising a "guaranteed job" isn't guaranteed income.

> **Key idea:** always compare with the same list of costs.



#### A case in one minute

Daniela wants a baking course. Tuition is 1,200, materials 300, and she'd give up 500 in earnings because of class hours.

The total cost is 2,000, not 1,200. She decides to take it anyway, because she expects to raise her prices afterward. Now she knows how much she needs to save.



#### Questions before you sign

| Type | Description | What it means for you |
|---|---|---|
| What's the total price? | Not just the monthly payment. | Ask for it in writing. |
| What's the yearly rate (APR)? | Compare with your bank or credit union. | Bring an offer beforehand. |
| What extras are included? | Warranties, insurance and optional services. | You can say no. |

If you're pressured to sign today, that's a good reason to wait.

#### Waiting is also an option

Sometimes the best purchase is waiting a few months. With a bigger down payment, the loan is smaller and you pay less interest.

If your current car still works, calculate how much you'd save in six months and compare it with the cost of buying today.



#### Check your understanding

1. Car A: payment 250 and other costs 320. Car B: payment 310 and other costs 230. Which costs less each month?
*Answer:* B: 540 versus 570.

2. Is a longer loan always better because it lowers the payment?
*Answer:* No. You pay more interest and can owe more than the car is worth.


#### Remember

- Add up all the costs, not just the payment.
- Compare with the same list.
- Check that a course is real before paying.



### Go deeper (5 more minutes)

#### Car: total cost

Price, financing, insurance, gas or charging, maintenance, repairs, parking, registration and loss of value.

A longer loan lowers the payment, but it can leave you owing more than the car is worth. If you sell it or it's totaled, you still owe the difference.



#### Leasing

Leasing has mileage limits, return conditions and charges if you return the car damaged.

Don't compare only the monthly payment: at the end you don't own the car.



#### Depreciation

A new car loses a significant part of its value in the first years. A used car in good condition can be a better option for many families.

Have a trusted mechanic inspect a used car before you buy it.



#### Education: check before you pay

- Check that the school or program is recognized.
- Ask how many students finish and get jobs, with data.
- Ask about scholarships or no-cost programs from the state or community colleges.

California community colleges have low-cost programs and some student aid, including some that don't depend on immigration status.

> **Good to know:** in California, students who meet certain in-state schooling requirements can pay in-state tuition (AB 540) even without regular immigration status. Ask at the admissions office.



#### Test it with less income

If the payment depends on steady overtime, that's a weakness in the plan.

Ask yourself: could I pay it in a month with 20% less income?



#### Arrive with an approved loan

Before going to the dealership, ask your credit union or bank for a preapproval. Many credit unions lend with an ITIN.

That way you know how much you can pay and you compare the dealer's offer with a real rate. If the dealer offers you something better, great; if not, you already have an option.

Read the whole contract before signing. Some dealerships add optional products to the monthly payment without explaining them. Ask what each charge is and remove what you don't want.



#### Cases


**Case 1. Rubén's two cars**

Car A: total 650. Car B: total 600.
- *What does he still need to check?* Total price, term, down payment, the car's condition and loss of value. The payment alone is misleading.


**Case 2. Daniela's course**

Tuition 1,200, materials 300 and lost earnings 500.
- *How much does it cost?* 2,000.


**Case 3. Andrés's offer**

A dealership offers to lower Andrés's car payment by stretching the loan from 48 to 84 months.
- *Is it good for him?* Probably not: he'd pay much more interest and could owe more than the car is worth for years.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Choosing by the monthly payment | You pay more in total | Add up all the costs |
| Stretching the loan to lower the payment | More interest and a debt bigger than the car | Choose the shortest term you can afford |
| Paying for a course without checking it | You lose money | Check that it's recognized |
| Believing in a "guaranteed job" | You go into debt with no result | Ask for real data |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Car A: payment 250 and other costs 320. Car B: payment 310 and other costs 230. Which costs less each month? a) A (570) · b) They cost the same · c) B (540)
2. Is a longer loan always better because it lowers the payment? a) Yes · b) No · c) Yes, if the car is new
3. Is a "guaranteed job" in an ad secure income? a) No · b) Yes · c) Yes, if the school is large
**Answers:** 1-c: 540 is less. 2-b: you pay more interest. 3-a: nobody can guarantee it.



#### Put it into practice

Compare two transportation options and the option of waiting. Write down at least five costs for each one.
**Answer:** For example: a used car (payment, insurance, gas, maintenance, registration), public transportation (monthly pass, time, occasional rides) and waiting six months to make a bigger down payment.



#### Your plan

Compare two options and the option of waiting. Write down at least five costs and one contingency.



### Learn more

- **Auto loans** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/auto-loans/ — **What to look for:** the list of car costs and how to compare loans by total cost.
- **Federal student aid** (Department of Education · English and Spanish): https://studentaid.gov — **What to look for:** what types of aid exist and how to check a school.
- **State student aid** (California Student Aid Commission · English and Spanish): https://www.csac.ca.gov — **What to look for:** the California Dream Act application for students without regular immigration status.

### Key words

- *Total cost of ownership:* everything it costs to own and use something.
- *Depreciation:* loss of value over time.
- *Lease:* renting a car for a set time, without owning it.

### Sources

CFPB, auto loans · Department of Education · California Student Aid Commission, California Dream Act · AB 540.

---

## M5 U06. What will I live on when I work less or stop working?

**What you will be able to do:** Identify your possible sources of retirement income and the questions you should check.

**To start:** Rosa is 61. She worked 15 years in Guadalajara and has spent ten in California taking care of children. She wonders what she'll live on when she can't work anymore. In this lesson you'll learn your possible sources of retirement income and how to start, even with a little.

### The essentials (5 minutes)

#### Start with your needs

Planning for retirement doesn't start with choosing an investment. It starts with understanding what expenses you'll have, what income you could receive and how much time you have.

It's never too late to start, and every step counts.



#### Possible sources of retirement income

| Type | Description | What it means for you |
|---|---|---|
| U.S. Social Security | A benefit for years worked with a valid SSN. | Check your statement on my Social Security. |
| Employer plan (401(k)) | You contribute from your pay; sometimes your employer does too. | Don't leave money on the table. |
| CalSavers | California's program if your employer has no plan. | Ask if you can join. |
| Your own savings | Other accounts you manage. | Check their risk and access. |
| AFORE (Mexico) | Your retirement savings if you worked in Mexico with IMSS. | M5 U07. |

#### The employer contribution

If your employer puts in 50 cents for each dollar you contribute, up to a limit, contributing 100 gets you 50 more.

It's money you don't want to leave on the table. Ask about the limit and how long you have to work for that contribution to be yours.



#### Three steps

1. **Write down** the expenses you'll probably still have.
2. **Identify** your possible sources and which ones still need to be confirmed.
3. **Choose one action** you can start today.



#### A case in one minute

Andrés's employer puts in 50 cents for each dollar, up to 6% of his pay. Andrés was contributing only 2%.

He raised his contribution to 6%. Now his employer adds an extra 3% each month, without him spending more than he can already afford.

> **Key idea:** a small, steady contribution is different from a promised return. Nobody can guarantee how much it will grow.



#### It's never too late

If you start at 50, you have less time, but every year of contributions counts.

From age 50, some retirement plans and accounts allow extra contributions. Ask your plan how much you can put in.

You can also reduce expenses that will continue in retirement, like paying off debts before you stop working.



#### Check your understanding

1. Is a 20-year projection a promise?
*Answer:* No. It's a possible scenario, not a guarantee.

2. Should you cash out your 401(k) when you change jobs without looking at options?
*Answer:* No. It can cost taxes and penalties; first check whether you can transfer it.


#### Remember

- Know your possible sources of retirement income.
- Take advantage of your employer's contribution.
- Start with a little, but start.



### Go deeper (5 more minutes)

#### What to check for each source

| Source | What to check |
|---|---|
| Social Security | Your statement on my Social Security; contributions are only credited with a valid SSN |
| 401(k) or 403(b) | Employer contribution and when it becomes yours |
| CalSavers | Whether you can join, how much is deducted and how to withdraw |
| Traditional or Roth IRA | You need work income; there are yearly limits |
| AFORE | Your balance with your CURP (M5 U07) |



#### Traditional or Roth

The difference is when you pay taxes:

- **Traditional:** you don't pay taxes now, you do when you withdraw.
- **Roth:** you pay taxes now, not when you withdraw (if you follow the rules).

Neither is always better. It depends on your situation; ask a professional.



#### Scenarios, not forecasts

Contributing 100 a month:

| Scenario | 20 years | 30 years |
|---|---|---|
| No return | 24,000 | 36,000 |
| Hypothetical return of 5% a year | 41,103 | 83,226 |
| Same 5%, in today's dollars with 3% inflation | 22,757 | 34,288 |

The 5% is hypothetical. Inflation reduces what you'll be able to buy.



#### If you change jobs

Before taking money out of a plan when you change jobs, check the transfer options, the costs, the taxes and the penalties.

Cashing out before the allowed age can cost up to a third of the money in taxes and penalties.

> **Good to know:** CalSavers is required for many California employers that don't offer a retirement plan. If your employer enrolls you, you can choose how much to contribute or opt out.



#### Your housing and your retirement

Housing is one of the biggest expenses in retirement. Getting there without a mortgage, or with rent you can afford, changes a lot how much you need.

Some people plan to retire in Mexico, where the cost of living may be lower. If that's your case, check access to health care, the cost of sending money and how you'd receive your U.S. income.

Write down where you plan to live and what it would cost. That number makes your plan more real.



#### Cases


**Case 1. Andrés's job change**

Andrés leaves his job and is offered to cash out his 401(k).
- *What does he do first?* He asks about transferring it to an IRA or to his new employer's plan, and what taxes and penalties he'd face if he withdraws it.


**Case 2. Daniela's CalSavers**

Daniela's employer has no retirement plan and enrolls her in CalSavers.
- *What does she check?* How much is deducted, how to change it and how to opt out if she needs to.


**Case 3. Rosa's retirement**

Rosa worked in Mexico with IMSS and here she's paid in cash.
- *What sources does she need to check?* Her AFORE in Mexico (M5 U07), her own savings and whether she ever worked with an SSN in the U.S.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Waiting to have a lot before starting | You lose years of growth | Start with a little |
| Not taking the employer contribution | You leave matching money behind | Contribute at least what your employer matches |
| Cashing out your 401(k) when you change jobs | You pay taxes and penalties | Transfer it |
| Treating a projection as a promise | You plan with unrealistic numbers | Use several scenarios |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Rosa and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does an IRA require work income to contribute? a) No · b) Only if you have an SSN · c) Yes
2. Is a 20-year projection a promise? a) Yes · b) No · c) Yes, if the bank makes it
3. Should you cash out your 401(k) when you change jobs without checking options? a) No · b) Yes · c) Yes, if you need the money
**Answers:** 1-c: you need work income. 2-b: it's a scenario. 3-a: check the transfer first.



#### Put it into practice

Your employer puts in 50 cents for each dollar up to 4% of your pay. You earn 3,000 a month. How much must you contribute to get everything it offers, and how much do you get?
**Answer:** 4% of 3,000 = 120 a month. Your employer puts in half: 60 a month.



#### Your plan

Make your list of retirement income sources, your questions and a first step. Contributing isn't required to pass.



### Learn more

- **my Social Security** (SSA · English and Spanish): https://www.ssa.gov/myaccount/ — **What to look for:** create your account to see your earnings record and an estimate of your benefits (you need an SSN).
- **CalSavers** (State of California · English and Spanish): https://www.calsavers.com — **What to look for:** "For savers" to learn how it works, how much is deducted and how to change it.
- **Retirement calculators** (SEC Investor.gov · English): https://www.investor.gov — **What to look for:** "Retirement calculator" to try different scenarios.

### Key words

- *Employer contribution:* what your employer puts into your plan.
- *Vesting:* the conditions for that contribution to become yours.
- *IRA:* a personal retirement account.
- *CalSavers:* California's retirement program.

### Sources

[S27] CalSavers · [R53] SSA, my Social Security · IRS, retirement plans.

---

## M5 U07. What happens to what I saved in Mexico?

**What you will be able to do:** Check your AFORE from the U.S., know your options to keep contributing and verify before you decide.

**To start:** Rosa worked 15 years in Guadalajara with IMSS. She's spent ten in Fresno and never checked her AFORE. She doesn't know how much she has or whether she can keep contributing from here. In this lesson you'll learn to find those savings and take care of them.

### The essentials (5 minutes)

#### Your AFORE is still yours

If you worked in Mexico with IMSS or ISSSTE, you have an **AFORE** with your retirement savings. That money isn't lost because you live in another country.

To find it you need your **CURP**.



#### Three ways to check your AFORE

1. **AforeMóvil app:** download it, sign up with your CURP and your email, and verify your identity with a photo. There you see your balance, your AFORE and your transactions.
2. **e-SAR:** on the SAR website you can find which AFORE you're in with your CURP.
3. **SARTEL:** call the CONSAR phone line, which also takes calls from the U.S.



#### You can keep contributing

From AforeMóvil you can make **voluntary contributions**, even small amounts.

That money grows with your account and helps you reach your retirement in Mexico.



#### Don't confuse one thing with another

Contributing voluntarily to your AFORE isn't the same as continuing to add IMSS contribution weeks.

Contribution weeks are what count toward the right to a pension. There are other options for that (see Go deeper).



#### A case in one minute

Rosa downloaded AforeMóvil, signed up with her CURP and found her account: she had more than she imagined and 780 contribution weeks.

She updated her beneficiaries and set aside a small voluntary contribution every month.

> **Key idea:** update your beneficiaries in your AFORE. If you don't, your family may have to go through a long process to receive that money.



#### What you can do from AforeMóvil

| Type | Description | What it means for you |
|---|---|---|
| See your balance | How much you have and in which AFORE. | Check every year. |
| Update beneficiaries | Who receives your savings. | Do it today. |
| Contribute | Voluntary contributions by card or at stores. | Small amounts. |
| Switch AFORE | If another one suits you better. | Compare fees and returns. |

It all costs nothing. Nobody should charge you to use the app.
> **Before you act, check:** that you're using CONSAR's official app and not a copy. Never pay to sign up.

#### Check your understanding

1. What do you need to find your AFORE?
*Answer:* Your CURP.

2. Does a voluntary contribution add IMSS contribution weeks?
*Answer:* No. It increases your savings, but doesn't add weeks.


#### Remember

- Look up your AFORE with your CURP.
- Update your beneficiaries.
- You can contribute from the U.S. with the app.



### Go deeper (5 more minutes)

#### IMSS options for people living abroad

| Option | What it's for | What to check |
|---|---|---|
| Modalidad 40 (voluntary continuation) | Keep adding weeks toward the pension; it can be paid from abroad | At least 52 weeks contributed in the 5 years before you left formal work, and no more than 5 years since then; the cost with IMSS |
| Modalidad 33 (health insurance for the family) | IMSS medical care for your family in Mexico, and for you when you're there | Yearly fee based on each person's age |
| Voluntary contributions to the AFORE | Increase your savings | Doesn't add weeks |

These options have requirements and costs that change. Confirm them directly with IMSS before deciding.



#### U.S. and Mexican Social Security

The U.S. has social security agreements with several countries to add up periods worked in both. With Mexico, according to the SSA, **that agreement is not in effect**.

That's why your weeks in Mexico and your credits in the U.S. are reviewed separately.



#### Watch out for middlemen

Some people offer to "recover your AFORE" or "advance your pension" in exchange for a percentage or your personal information.

Procedures with your AFORE, CONSAR and IMSS cost nothing. Don't share your CURP, your NSS or your passwords with middlemen.



#### Unemployment withdrawals

Some accounts allow a partial withdrawal for unemployment. Doing it reduces your contribution weeks.

Before withdrawing, ask how many weeks you'd lose and whether it's worth it.

> **Good to know:** according to CONSAR, millions of AFORE accounts don't have updated information. If you don't know which one you're in, your account may be at the Banco de México as an "unassigned account." It can be recovered.



#### Compare your AFORE

AFOREs charge different fees and have different returns. CONSAR publishes a comparison every year.

If your AFORE has low returns, you can switch, generally once a year. Switching costs nothing and is done from AforeMóvil or at the new AFORE.

Don't switch because of a gift or an agent's promise. Compare with CONSAR's data.



#### Cases


**Case 1. Rosa finds her AFORE**

Rosa doesn't know which AFORE she's in.
- *What does she do?* She uses e-SAR or AforeMóvil with her CURP.


**Case 2. Rubén's middleman**

A middleman offers Rubén to "release his AFORE" for 30% of the balance.
- *What does Rubén do?* He doesn't accept. The procedures cost nothing and he does them himself with his AFORE or CONSAR.


**Case 3. Weeks or savings**

Rosa wants to increase her savings and also complete weeks for her pension.
- *Are voluntary contributions enough?* No. Contributions increase her savings; to add weeks she must ask IMSS about Modalidad 40.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Not checking your AFORE | You don't know what you have | Look it up with your CURP |
| Not updating beneficiaries | A long process for your family | Update them |
| Paying a middleman | You lose money or your data | Do it yourself, it costs nothing |
| Believing contributing adds weeks | You plan your pension wrong | Ask IMSS |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén and Rosa. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Do you lose your AFORE by living in the U.S.? a) Yes · b) Yes, after 5 years · c) No
2. What do you need to find it? a) Your ITIN · b) Your CURP · c) Your consular ID number
3. Is a middleman who charges to "release your AFORE" necessary? a) No · b) Yes · c) Only if you live abroad
**Answers:** 1-c: it's still yours. 2-b: the CURP. 3-a: the procedures cost nothing.



#### Put it into practice

Write down the three things you need to check your AFORE and who you'd name as your beneficiary.
**Answer:** For example: my CURP, an email address and my ID for the photo. Beneficiaries: my children, with percentages.



#### Your plan

Download AforeMóvil or use e-SAR, find your account and update your beneficiaries.



### Learn more

- **AforeMóvil** (CONSAR · Spanish): https://www.gob.mx/consar — **What to look for:** "AforeMóvil" to download the app and the steps to sign up from abroad.
- **e-SAR: find your AFORE** (SAR · Spanish): https://www.e-sar.com.mx — **What to look for:** "Localiza tu AFORE" and type your CURP.
- **Look up your CURP** (Government of Mexico · Spanish): https://www.gob.mx/curp/ — **What to look for:** download your CURP if you don't have it handy.
- **International agreements** (SSA · English): https://www.ssa.gov/international/agreements_overview.html — **What to look for:** the list of countries with an agreement; check whether Mexico appears.

### Key words

- *AFORE:* the company that manages your retirement savings in Mexico.
- *CURP:* your registration ID in Mexico.
- *Contribution weeks:* weeks with contributions to IMSS.
- *Voluntary contribution:* extra money you put in your AFORE.

### Sources

CONSAR, AforeMóvil · e-SAR · IMSS, Modalidades 40 and 33 · SSA, international agreements.

---

## M5 U08. What happens to my family if something happens to me?

**What you will be able to do:** Prepare the basics to protect your family: beneficiaries, documents and a plan for your children.

**To start:** Rubén has two children in Stockton. One night he wonders: if something happens to me, who takes care of them? Who knows where my money is? He has nothing in writing. In this lesson you'll prepare the basics, step by step, without fear.

### The essentials (5 minutes)

#### Planning isn't thinking the worst

Preparing documents is an act of care. It spares your family confusion, expenses and long procedures at a hard time.

You don't need a lot of money to do it.



#### The basics

| Type | Description | What it means for you |
|---|---|---|
| Beneficiaries | Who receives your account, your insurance or your AFORE. | Updated at each institution. |
| A plan for your children | Who takes care of them if you can't. | A caregiver form in California. |
| Power of attorney | Who you authorize to handle your affairs. | Only someone you fully trust. |
| Family folder | Where your documents and contacts are. | M1 U14. |

#### A plan for your children

In California, the **Caregiver's Authorization Affidavit** lets a trusted adult enroll your children in school and authorize medical care.

It doesn't take away your custody. You can cancel it whenever you want.



#### Beneficiaries on every account

Every bank account, life insurance policy, retirement plan and AFORE has its own beneficiary form.

Your will doesn't change what that form says. Check them all.



#### A case in one minute

Rubén talked with his sister, who agrees to take care of his children. He filled out the caregiver form and gave her a copy.

He updated the beneficiaries on his account and his insurance, and told his sister where his family folder is.

> **Key idea:** if you're worried about your immigration situation, an attorney or a DOJ-accredited representative can guide you on a family preparedness plan.



#### Talk with your family

Having documents isn't enough if nobody knows they exist. Sit down with the person who would take care of your children. Explain where your papers are, what accounts you have and who to call.

If your children are older, explain the plan in simple words. Knowing there's a plan gives them peace of mind.

Put the phone numbers of your consulate, your children's school and their doctor in your folder.

> **Before you act, check:** that the form is the official one from the California courts. Also confirm that the person who will care for your children agrees to do it.



#### Check your understanding

1. Does your will change the beneficiaries of your insurance?
*Answer:* No. They're updated on each institution's form.

2. Does the caregiver form take away your custody?
*Answer:* No. You can cancel it whenever you want.


#### Remember

- Update beneficiaries on every account.
- Make a plan for your children.
- Tell someone you trust where your documents are.



### Go deeper (5 more minutes)

#### Documents for your family's plan

| Document | What it's for |
|---|---|
| Caregiver's affidavit | Your children's school and medical care |
| Power of attorney for finances | So someone can handle your money if you can't |
| Advance health care directive | Your medical decisions and who makes them |
| Will | Who gets your property |
| List of accounts and contacts | So your family knows what exists |



#### The durable power of attorney

A **durable power of attorney** stays valid even if you can't make decisions, for example because of an illness.

It's a very powerful document: that person can use your money. Give it only to someone you fully trust and get legal guidance.



#### Your information in a safe place

Keep a list of your accounts, insurance, debts and important contacts. Don't write down full passwords.

Tell a trusted person where it is. You can use a sealed envelope or a folder at home.



#### If you have property in Mexico

A U.S. will may not be enough for property in Mexico. Ask a notario in Mexico.

In September, Mexico's "Mes del Testamento" (Will Month) offers discounts of up to 50% on notary fees. It applies in every state, and the price depends on the state.

> **Good to know:** the Mexican Consulate offers guidance and sometimes events with notarios for procedures like powers of attorney and wills. Ask at your consulate.



#### Low-cost legal help

You don't need to pay a lot to prepare basic documents. Look for:

- No-cost legal clinics from community organizations.
- California court self-help centers.
- Attorneys or DOJ-accredited representatives for immigration matters.

Be wary of "notarios" or "consultants" who offer immigration services. In the U.S., a notary public isn't a lawyer and can't give you legal advice.



#### Cases


**Case 1. Rubén's plan**

Rubén wants his sister to take care of his children if he can't.
- *What document does he use?* California's Caregiver's Authorization Affidavit.


**Case 2. Daniela's insurance**

Daniela made a will, but her life insurance still lists her ex-partner as beneficiary.
- *Who receives the insurance?* Probably the ex-partner. She must update the insurance form.


**Case 3. Andrés's power of attorney**

An acquaintance offers to "handle everything" for Andrés with a power of attorney.
- *What does he do?* He gives it only to someone he fully trusts, with legal guidance.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Having nothing in writing | Your family doesn't know what to do | Start with the basics |
| Not updating beneficiaries | The money goes to someone you don't want | Check every account |
| Giving a power of attorney to anyone | They can use your money | Only someone you fully trust |
| Keeping full passwords on paper | Risk of theft | Just say where to find the information |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does your will change the beneficiaries of your insurance? a) Yes · b) Yes, if it's more recent · c) No
2. Does the caregiver form take away your custody? a) Yes · b) No · c) Yes, for one year
3. Should just anyone have your power of attorney? a) No · b) Yes · c) Only a lawyer
**Answers:** 1-c: they're updated at each institution. 2-b: you can cancel it. 3-a: only someone you fully trust.



#### Put it into practice

Write the name of the person who would take care of your children, the accounts where you need to update beneficiaries and where you'll keep your folder.
**Answer:** For example: my sister; beneficiaries on my bank account, life insurance and AFORE; the folder in the closet drawer, and I tell my sister.



#### Your plan

Fill in your document list, update one beneficiary this week and talk with the person who would take care of your children.



### Learn more

- **Caregiver's Authorization Affidavit** (California Courts · English and Spanish): https://selfhelp.courts.ca.gov/guardianship/caregiver-affidavit — **What to look for:** the form and the instructions to fill it out.
- **Advance health care directive** (California Attorney General · English and Spanish): https://oag.ca.gov/consumers/general/adv_hc_dir — **What to look for:** the advance directive form.
- **Family preparedness plan** (Immigrant Legal Resource Center · English and Spanish): https://www.ilrc.org/family-preparedness-plan — **What to look for:** the guide to prepare documents and contacts.
- **Mexican consulates** (SRE · Spanish): https://directorio.sre.gob.mx — **What to look for:** your consulate and its notarial services.

### Key words

- *Beneficiary:* who receives an asset or insurance.
- *Durable power of attorney:* an authorization that stays valid if you can't decide.
- *Advance directive:* your medical instructions.
- *Will:* a document that says who gets your property.

### Sources

California Courts · California Attorney General · ILRC · SRE.

---

## M5 U09. How do I plan when my income changes every month?

**What you will be able to do:** Make a base budget and a plan for good and bad months when your income varies.

**To start:** Andrés works in construction. Some months have lots of work and rainy months have almost none. When there's money he overspends, and when there isn't he goes into debt. In this lesson you'll make a plan that works even when your income changes.

### The essentials (5 minutes)

#### Plan with your low month

If your income changes, don't build your plan on a good month. Build it on a realistic low month.

Look at your last six months and take one of the lowest, not counting an unusual month.



#### Your base budget

| Type | Description | What it means for you |
|---|---|---|
| Essential expenses | Rent, food, transportation, utilities. | They come first. |
| Minimum payments | Debts and commitments. | Avoid fees. |
| Reserve | A part for low months. | It gives you calm. |
| Everything else | Goals and treats. | When there's extra. |

#### What to do in a good month

Your base budget is 2,200 and this month you earned 3,000.
- What came in: **3,000**
- Your base budget: **2,200**
- The extra: don't spend it all: **800**
For example, 500 to your reserve and 300 to a goal.


#### Smooth out your income

Some people "pay themselves a salary." Everything that comes in goes to one account, and each week they move the same amount to their spending account.

That way the good months cover the bad ones.



#### A case in one minute

Andrés looked at six months: his low month was 2,100. He built his budget on that.

In June he earned 3,400 and set aside 1,000. In December, with the rains, he used that reserve instead of his card.

> **Key idea:** in the good months, prepare for the bad months.



#### Three accounts for variable income

| Type | Description | What it means for you |
|---|---|---|
| Income account | Everything you earn lands here. | You don't spend from here. |
| Spending account | Each week you move your fixed "salary." | You pay your bills from here. |
| Reserve account | The extra from good months. | For low months. |

If you don't want three accounts, start with two: one for spending and one for the reserve. What matters is separating.

#### Your plan in four steps

1. **Review** your income for the last six months.
2. **Choose** a realistic low month.
3. **Make** your base budget with that amount.
4. **Decide** what percentage of the extra you'll set aside, for example half.

Review your plan at the end of each season and adjust the percentage if your reserve is already full.



#### Check your understanding

1. What month do you build your plan on if your income changes?
*Answer:* A realistic low month.

2. What do you do with the extra from a good month?
*Answer:* Set part of it aside for low months.


#### Remember

- Plan with a realistic low month.
- Set aside the extra from good months.
- Pay yourself a fixed salary if you can.



### Go deeper (5 more minutes)

#### Andrés's six months

| Month | Income | Difference from his base (2,100) |
|---|---|---|
| January | 2,100 | 0 |
| February | 2,300 | +200 |
| March | 2,900 | +800 |
| April | 3,200 | +1,100 |
| May | 2,600 | +500 |
| June | 3,400 | +1,300 |

If he sets aside half of the extra, in six months he gathers 1,950 for the rainy months.



#### If you get cash or tips

Write down every day what you receive in cash and through apps. Without a record you can't know which is your low month.

Deposit your cash regularly. It helps you not spend it and gives you an income history (M1 U04).



#### Taxes if you work for yourself

If nobody withholds taxes for you, set aside part of what you earn to pay them. Many people set aside between 20% and 30%, depending on their situation.

Ask at a VITA center how much you should set aside and whether you should make estimated payments (M4 U04).



#### Warning signs

- You use your card for essential expenses several months in a row.
- You have no reserve when the low season starts.
- Your good month gets spent completely.

If you see these signs, lower your base budget or look for extra income in the low season.

> **Good to know:** according to the Federal Reserve, many people with variable income say the swings make it hard to pay their bills. A plan based on the low month reduces that stress.



#### Know your season

Many jobs have seasons: construction slows with the rains, farm work changes with the harvests and made-to-order food picks up in December.

Mark your good and bad months from the last year on a calendar. That way you know when to set money aside and how much you'll need.

Say your low season lasts three months and your essential expenses are 1,800. Your reserve goal for that season is 5,400, minus what you do earn in those months.



#### If a very bad month comes

If your reserve isn't enough, call before you fall behind: many utility companies, landlords and banks offer payment plans.

Prioritize housing, food, utilities and transportation to work. Avoid payday loans (M3 U09).



#### Cases


**Case 1. Andrés's rains**

Andrés earns little in December and January.
- *What does he do starting in June?* He sets aside part of the extra from each good month for those months.


**Case 2. Mar's tips**

Mar gets most of her tips in cash and doesn't know how much she earns a month.
- *What does she do first?* She writes down every day what she receives for one or two months.


**Case 3. Daniela's big order**

Daniela got a big cake order and earned 1,500 extra in one week.
- *Does she spend it all?* No. She sets money aside for taxes, her reserve and her next ingredient purchase.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Planning with the good month | You go into debt in the bad one | Use a realistic low month |
| Spending all the extra | You have no reserve | Set part of it aside |
| Not recording cash | You don't know your income | Write it down every day |
| Not setting aside for taxes | Debt with the IRS | Set aside a percentage |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Daniela, Andrés and Mar. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. What month do you plan with if your income changes? a) The best one · b) The year's average · c) A realistic low month
2. Your base is 2,000 and you earn 2,800. What do you do with the 800? a) Spend it · b) Set part of it aside · c) Prepay debts and spend the rest
3. Does recording your cash help you? a) Yes · b) No · c) Only if you pay taxes
**Answers:** 1-c: that way the plan holds up. 2-b: it prepares for bad months. 3-a: without a record you don't know your income.



#### Put it into practice

Write down your income for the last three or six months and choose your low month. What's your base budget?
**Answer:** For example: 2,300, 2,800, 2,100, 3,000. Low month: 2,100. My base budget is 2,100 and I set aside part of anything above that.



#### Your plan

Make your base budget with your low month and decide what percentage of the extra you'll set aside.



### Learn more

- **Budgeting with irregular income** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the "Irregular income" tool and the income and expense calendar.
- **Taxes for self-employed workers** (IRS · English and Spanish): https://www.irs.gov/businesses/small-businesses-self-employed/self-employed-individuals-tax-center — **What to look for:** estimated payments and how much to set aside.

### Key words

- *Base budget:* the minimum you need each month.
- *Variable income:* income that changes from month to month.
- *Estimated payments:* taxes you pay during the year.

### Sources

CFPB, Your Money, Your Goals · IRS, self-employed individuals · Federal Reserve, Economic Well-Being of U.S. Households.

---

## M5 U10. How do I formalize my business?

**What you will be able to do:** Separate business and personal money, know the first steps to formalize and compare a sole proprietorship with an LLC.

**To start:** Daniela sells custom cakes in San Diego. Business is good, but she mixes order money with household money and doesn't know if she's really making a profit. A customer asked her for an invoice and she didn't know what to do. In this lesson you'll take the first steps to formalize your business.

### The essentials (5 minutes)

#### Separate the business money

The first step is to separate business money from household money. If you mix them, you don't know if you're making money.

Open an account just for the business. Many banks and credit unions open one with an ITIN.



#### How much do you really make?

Daniela sold 1,200 in cakes in one month.
- Sales: **1,200**
- Ingredients and boxes: **450**
- Gas, fuel and other costs: **150**
- Real profit: **600**
If she charges without counting her costs, she thinks she makes twice as much.


#### First steps to formalize

| Type | Description | What it means for you |
|---|---|---|
| ITIN or SSN | To report your income. | M4 U03. |
| Local license | Your city or county may require a business license. | Ask your city. |
| Home food permit | If you sell food, a homemade food permit may apply. | Ask county health. |
| Record of sales and expenses | Keep receipts. | It helps with taxes. |

#### Sole proprietorship or LLC

Many people start as a **sole proprietorship**. It's the simplest and can be done with an ITIN. You only need your local license and, if you use another name, a business name registration.

An **LLC** protects your personal property from certain business debts. But in California it costs at least **800 dollars a year** in minimum tax, even if you don't make money.



#### A case in one minute

Daniela opened an account for her business, got her license and asked about the homemade food permit.

She started as a sole proprietorship. She'll move to an LLC when her profits comfortably cover the 800 a year.

> **Key idea:** start simple and grow when your business can pay for it.



#### Set prices with your numbers

Many people set prices "like everyone else" and without realizing it make very little.

Add up the costs of one order: ingredients, packaging, gas and your time. If a cake costs you 25 in materials and 3 hours, and you want to earn at least 15 an hour, your price should be 70 or more.

Review your prices every time your ingredients go up.



#### Check your understanding

1. You sell 900, your ingredients cost 350 and other expenses 100. How much do you make?
*Answer:* 450.

2. Does an LLC in California pay tax even if it doesn't make money?
*Answer:* Yes. There's a minimum tax of 800 a year.


#### Remember

- Separate the business money.
- Subtract your costs to know if you're making money.
- Start as a sole proprietorship if your business is small.



### Go deeper (5 more minutes)

#### Sole proprietorship or LLC

| | Sole proprietorship | LLC |
|---|---|---|
| What it is | You are the business | A company separate from you |
| With an ITIN | Yes | Yes, generally |
| Yearly cost in California | Local license and business name | At least 800 in tax to the FTB, plus paperwork |
| Protects your personal property | No | Yes, in certain cases |
| When it makes sense | A small or new business | When cash flow covers the cost and there's more risk |



#### The business name (DBA)

If your business uses a name different from yours, like "Pasteles Dany," register that **DBA** in your county.

Some banks require it to open the business account under that name.



#### Homemade food

In California there are permits to sell certain foods made at home, like cakes and cookies. Some counties allow small home kitchens with more types of food.

Ask your county health department which permit applies to what you sell.



#### Business taxes

If you earn 400 or more in the year working for yourself, you generally must file and pay self-employment tax.

Set aside part of each sale and ask for help at a VITA center or from a certified preparer (M4 U04).

> **Good to know:** Small Business Development Centers (SBDC) and many community organizations offer no-cost advice in Spanish to start a business.



#### Business loans

Some community institutions (CDFIs) and microloan programs lend to small businesses with an ITIN.

Compare the total cost and avoid cash advances that take a percentage of your daily sales without showing the yearly rate.



#### Getting paid with apps and cards

If you get paid through payment apps, use a business account. Payment apps send you and the IRS a Form 1099-K if you receive more than 20,000 dollars in a year. It must be in more than 200 payments for goods or services. Even if you don't get one, that income must be reported.

That doesn't mean you pay more taxes, but it does mean the IRS knows about that income. That's why you keep your record of sales and expenses.

Keep personal payments, like money from family, separate from customer payments.



#### Cases


**Case 1. Daniela's profits**

Daniela sold 1,200 and spent 600 in total.
- *How much did she make?* 600.


**Case 2. An LLC already?**

Rubén is starting to sell food to order some weekends and makes 150 a month.
- *Does an LLC make sense for him?* Probably not for now: the 800 yearly minimum would be more than he makes in five months. He starts as a sole proprietorship.


**Case 3. Andrés's loan**

Andrés is offered a business "advance" that's collected from his daily sales.
- *What does he check?* The total cost and the equivalent yearly rate, and he compares it with a CDFI.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Mixing business and household money | You don't know if you make money | A separate account |
| Not counting costs | You think you make more | Subtract ingredients and expenses |
| Opening an LLC too soon | You pay 800 even without profit | Start simple |
| Not setting aside for taxes | Debt with the IRS | Set aside from every sale |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You sell 900 and your costs are 450. Your profit? a) 900 · b) 1,350 · c) 450
2. Does an LLC in California pay tax even if it doesn't make money? a) No · b) Yes, at least 800 · c) Only if it has employees
3. What's the first step to organize your business? a) Separate the money · b) Open an LLC · c) Print business cards
**Answers:** 1-c: 900 − 450. 2-b: there's a yearly minimum tax. 3-a: without separating you don't know if you make money.



#### Put it into practice

Write down your business's sales and expenses for one month, or an imaginary one. How much did you make? What first step do you take to formalize?
**Answer:** For example: sales 1,000, ingredients 400, gas 100: profit 500. First step: open a separate account.



#### Your plan

Open an account for your business, record your sales and expenses for a month and ask your city what license you need.



### Learn more

- **Start a business in California** (CalGold · English): https://www.calgold.ca.gov — **What to look for:** type your city and business type to see the permits you need.
- **LLC franchise tax** (FTB · English): https://www.ftb.ca.gov/file/business/types/limited-liability-company/index.html — **What to look for:** the 800 minimum yearly tax and when it's due.
- **Small Business Development Centers** (SBA · English and Spanish): https://www.sba.gov/local-assistance — **What to look for:** type your ZIP code to find no-cost advice near you.
- **Cottage food operations** (California Department of Public Health · English): https://www.cdph.ca.gov/Programs/CEH/DFDCS/Pages/FDBPrograms/FoodSafetyProgram/CottageFoodOperations.aspx — **What to look for:** the list of allowed foods and how to register in your county.

### Key words

- *Sole proprietorship:* a business that is you.
- *LLC:* limited liability company.
- *DBA:* business name.
- *Profit:* sales minus costs.

### Sources

CalGold · FTB, LLC · SBA · CDPH, cottage food · IRS, self-employment.

---

## M5 U11. What's my financial plan?

**What you will be able to do:** Bring together what you learned in a one-page personal financial plan with actions and dates.

**To start:** You've reached the end of the program. Rubén, Daniela, Andrés and Rosa have something in common: they all started with doubts and now they have a plan. In this lesson you'll make yours, on a single page.

### The essentials (5 minutes)

#### A plan fits on one page

Your plan doesn't have to be perfect. It has to be clear and doable.

One page with your goals, your basic numbers and your next steps is enough to start.



#### The parts of your plan

| Type | Description | What it means for you |
|---|---|---|
| Your numbers | Low-month income, essential expenses and debts. | M1. |
| Your protection | Reserve, insurance and documents. | M3 and M5 U08. |
| Your goals | Amount, date, currency and priority. | M5 U01. |
| Your next steps | Three actions with dates. | Start with one. |

#### Three actions with dates

1. **This week:** something small, like opening an account or checking your AFORE.
2. **This month:** something that takes a bit more, like updating beneficiaries.
3. **This year:** a bigger goal, like building your reserve.



#### Review your plan

Review your plan every three or six months, or when something changes: a new job, a child, a move.

A plan you review is more useful than a perfect one you forget.



#### A case in one minute

Rosa wrote her plan: this week, sign up for AforeMóvil; this month, update her beneficiaries; this year, save a 1,000 reserve.

She stuck it on her fridge and reviews it every three months with her daughter.



#### Your commitment

Give a goal a name ("three-month family fund"), decide how much you set aside from each paycheck and tell someone you trust. Set up the automatic transfer on payday and a monthly reminder with your goal's name.

> **Key idea:** it's not about doing everything. It's about taking the next step, with a named goal, a witness and a reminder.



#### What you learned in the program

| Module | Key idea |
|---|---|
| M1 | Know your numbers and protect your information |
| M2 | Use safe services and avoid fraud |
| M3 | Build credit and manage your debts |
| M4 | Understand your taxes and protect your health |
| M5 | Set goals, plan your retirement and take care of your family |

Your plan brings all of this together on one page. From each module, choose only what matters to you today.



#### Your first step, today

Choose one action you can do today in less than 15 minutes. Check your balance, set aside 10 dollars or save the phone number of a VITA center.

Doing something small today helps you keep going tomorrow. The plan grows with every step.



#### Check your understanding

1. Does your plan have to be perfect to start?
*Answer:* No. It has to be clear and doable.

2. How often should you review it?
*Answer:* Every three or six months, or when something changes.


#### Remember

- Your plan fits on one page.
- Write three actions with dates.
- Review it when something changes.



### Go deeper (5 more minutes)

#### Your one-page plan

| Part | What you write |
|---|---|
| My numbers | Low-month income, essential expenses, debts |
| My reserve | How much I have and how much I want |
| My goals | Three goals with amount, date and priority |
| My protection | Insurance, beneficiaries, documents |
| My next steps | Three actions with dates |
| My help | Who I can ask at no cost guidance |



#### Your support network

Keep the contacts for no-cost help you learned about in the program: VITA centers, housing counselors, nonprofit credit counseling, your consulate, attorneys or accredited representatives.

You don't have to do it alone.



#### Protect your plan

- Don't share your passwords or your full numbers.
- Verify before investing or paying.
- If something sounds too good, ask first.

> **Good to know:** according to the FDIC, people who have an account and a savings plan are more likely to handle an emergency without debt.



#### Celebrate your progress

Every step counts: opening an account, paying off a debt, making your first contribution.

Write down your achievements in your plan. They remind you that you can do it.



#### Do it as a family

If you share expenses with your partner or your family, make the plan together. Talking about money without guilt or blame is part of the plan.

Agree on a fixed date, for example the first Sunday of each quarter, to check how you're doing.

You can use a simple rule: each person shares one achievement, one worry and one next step. That keeps the conversation short and useful.

If you have older children, include them in simple goals, like saving for something for the house. They learn by watching.



#### Why it works

Studies in several countries found that naming a goal, committing to someone and getting a monthly reminder with that goal helps people save more. Setting money aside automatically, before you see it, also helps.



#### When rules or the economy change

Immigration laws, remittance taxes, public programs, interest rates and prices change. Confirm each change with the official source, not social media: the IRS, USCIS, your county or the CFPB. Adjust one part of your plan at a time. If a change touches your immigration status, talk to an attorney or an accredited representative.



#### Keep learning

Your plan will change with your life. You can go back to any lesson in this program whenever you need it.

Something may change, like a new job, a child or a move. When it does, look for the lesson on that topic and update that part of your plan.



#### Cases


**Case 1. Rubén's plan**

Rubén has three goals but doesn't know where to start.
- *What does he do?* He chooses one small action for this week and writes it down with a date.


**Case 2. Andrés's change**

Andrés changed jobs.
- *What does he review in his plan?* His income, his base budget, his retirement plan and his beneficiaries.


**Case 3. Daniela's reserve**

Daniela had to use her reserve for an emergency.
- *Did her plan fail?* No. The plan worked: the reserve was for exactly that. Now she builds it back up little by little.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Waiting for the perfect plan | You never start | Start with one page |
| Writing goals without dates | They don't move forward | Put a date on each action |
| Not reviewing the plan | It becomes useless | Review it every three or six months |
| Feeling guilty if something fails | You abandon the plan | Adjust it and keep going |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Rubén, Daniela and Andrés. Choose the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. Does your plan have to be perfect to start? a) Yes · b) Yes, or it's useless · c) No
2. Is using your reserve in an emergency a failure? a) Yes · b) No, that's what it's for · c) Yes, you have to start over
3. When do you review your plan? a) Every three or six months, or when something changes · b) Never · c) Once, when you finish the course, and put it away
**Answers:** 1-c: clear and doable is enough. 2-b: the reserve did its job. 3-a: that keeps it useful.



#### Put it into practice

Write your one-page plan: your numbers, your reserve, three goals, your protection, three actions with dates and your support network.
**Answer:** For example: low month 2,100, essentials 1,700; reserve 300 of 1,000; goals: reserve, course, roof in Mexico; protection: beneficiaries pending; actions: AforeMóvil this week, beneficiaries this month, reserve this year; help: VITA and a housing counselor.



#### Your plan

Write your one-page plan and give it a review date. Congratulations on finishing the program!



### Learn more

- **Your Money, Your Goals** (CFPB · English and Spanish): https://www.consumerfinance.gov/consumer-tools/educator-tools/your-money-your-goals/ — **What to look for:** the goal, budget and action plan tools to print.
- **Money Smart for Adults** (FDIC · English and Spanish): https://www.fdic.gov/consumer-resource-center/money-smart-adults — **What to look for:** the modules you want to review.
- **Find a credit counselor** (NFCC · English and Spanish): https://www.nfcc.org — **What to look for:** no-cost or low-cost nonprofit counseling.

### Key words

- *Financial plan:* your goals and steps in writing.
- *Support network:* people and institutions that guide you at no cost.

### Sources

CFPB, Your Money, Your Goals · FDIC, Money Smart · NFCC.

---

## M5 U12. What happens if I inherit or leave something across two countries?

**What you will be able to do:** Know how to pass your accounts and home without court in the U.S., which taxes apply (and which don't) when inheriting here and in Mexico, and what to report to the IRS if you inherit something from Mexico.

**To start:** Alex's mom has a house in Michoacán and no will. Alex lives in Los Angeles, and a coworker told him that if he inherits it "the IRS charges 40%." Rosa has an account in Fresno and wants it to go to her grandchildren. In this lesson you'll see what's true and what to prepare.

### The essentials (5 minutes)

#### Two countries, two systems

What you own in the U.S. follows the rules here; what you own in Mexico follows the rules there. Preparing both keeps your family out of long procedures in two countries.



#### Passing things on without court in the U.S.

| Type | Description | What it means for you |
|---|---|---|
| Payable-on-death (POD) accounts | Bank and credit union. | They pass directly. |
| Investments and retirement with a beneficiary | TOD and IRA. | They pass directly. |
| Transfer on death deed | In California, for your home. | Avoids probate. |
| Small estate | Affidavit without probate. | The limit changes. |

#### Taxes on inheritances in the U.S.

Heirs **don't pay federal tax** for receiving an inheritance. The federal estate tax only applies to estates over 15 million dollars per person in 2026, and California has no inheritance tax.

If you inherit something from abroad worth more than 100,000 dollars, like a house in Mexico, you must report it to the IRS. You use **Form 3520**, even though you owe no tax. The penalty for not filing can reach 25% of the value.

> **Current fact:** the federal estate tax only applies to estates over 15 million dollars per person in 2026. Inheritances and gifts from foreign persons over 100,000 dollars are reported on Form 3520. Accessed September 30, 2026 through the IRS and specialized media.



#### What's in Mexico

In Mexico, receiving an inheritance **pays no income tax (ISR)**, but putting the house in your name does cost money: state tax, notary and registry. If there is ejido land, it passes through the ejido member's succession list. Mexican consulates offer notary services, such as wills and powers of attorney, so you can handle procedures without traveling.



#### A case in one minute

Alex talked with his mom: she'll make her will with a notary in Michoacán. Alex learned he won't pay 40%; if the house is worth more than 100,000 dollars, he'll just file Form 3520. Rosa named her grandchildren as POD beneficiaries on her account, with her daughter as guardian.

> **Key idea:** in the U.S., POD and TOD beneficiaries and a transfer on death deed avoid court. Inheriting pays no federal tax, except on huge estates. Foreign inheritances over 100,000 dollars are reported on Form 3520. In Mexico, inheriting pays no ISR, but transferring the title does cost money.



#### Check your understanding

1. Do you pay federal tax for inheriting your mom's house in Mexico?
*Answer:* No; if it's worth more than 100,000 dollars you just report it on Form 3520.

2. Where can you make a will for what you own in Mexico without traveling?
*Answer:* At a Mexican consulate.


#### Remember

- POD, TOD and transfer on death deed.
- Form 3520 if you inherit from abroad.
- In Mexico: no ISR, but the title transfer costs money.



### Go deeper (5 more minutes)

#### Your two-country map

| Asset | Where | How it passes |
|---|---|---|
| Bank account | U.S. | POD beneficiary |
| Retirement account | U.S. | Named beneficiary |
| House | U.S. | Transfer on death deed or trust |
| House or land | Mexico | Will with a notary or consulate |
| Ejido land | Mexico | Succession list at the RAN |
| AFORE | Mexico | Beneficiaries at the AFORE |



#### If you sell what you inherit

In the U.S., if you sell something you inherited, the gain is measured from its value when the person died. That usually lowers the tax. In Mexico, selling an inherited house may pay ISR on the gain; if you live there, the home exemption may apply.



#### Beware of "gestores"

Nobody needs to charge you thousands of dollars to "fix" an inheritance in Mexico from here. Ask your consulate and work with a registered notary.

> **Before you act, check:** the consulate's requirements for wills and powers of attorney, and the current small estate limit at the California courts.



#### Your home in Mexico: usufruct

Maybe you own a house or land in Mexico and want to pass it to your children while you're alive, but keep using it. Mexico has a gift with **reserved usufruct** (usufructo), done before a notary. In the U.S., a similar tool is a life estate. Ask your consulate before you sign.



#### Cases


**Case 1. Alex's 40%**

Alex is told the IRS will charge him 40% for inheriting his mom's house.
- *What does he learn?* That he pays no federal tax; he only reports it on Form 3520 if it's worth more than 100,000 dollars.


**Case 2. Rosa's account**

Rosa wants her Fresno account to go to her grandchildren without court.
- *What does she do?* She names them as POD beneficiaries and names her daughter as guardian.


**Case 3. Daniela's gestor**

A "gestor" offers to "fix" Daniela's aunt's inheritance in El Salvador for 3,000 dollars.
- *What does she do?* She asks her consulate and looks for a registered notary.


#### Common mistakes

| Mistake | What happens | What to do |
|---|---|---|
| Believing inheriting pays 40% | Needless fear | Only huge estates |
| Not reporting a foreign inheritance | Penalty up to 25% | Form 3520 |
| Leaving the house in Mexico without a will | Court there | Notary or consulate |
| Paying gestores | You lose money | Consulate and notary |

### Practice

#### Interactive activity

**What would you do? (H5P):** three situations from this lesson with Alex, Rosa and Daniela. Pick the best decision in each one; if you miss, you can try again. It earns experience points.



#### Quiz

1. You inherit a house in Mexico worth 130,000 dollars. What do you do with the IRS? a) File Form 3520 · b) Pay 40% · c) Nothing, because the house is in another country
2. What keeps your bank account out of court? a) Your will in Mexico · b) A POD beneficiary · c) Withdrawing everything in cash
3. How much ISR does an heir pay in Mexico? a) 30% · b) 16% · c) None
**Answers:** 1-a: it's an information report. 2-b: it passes directly. 3-c: it's exempt.



#### Put it into practice

You don't file Form 3520 for a 110,000-dollar inheritance. What would the maximum 25% penalty be?
**Answer:** 25% of 110,000: 27,500 dollars.



#### Your plan

Make your two-country map and check the beneficiaries on your accounts here.



### Learn more

- **Gifts and inheritances from abroad** (IRS · English): https://www.irs.gov — **What to look for:** "Form 3520".
- **Small estates and transfer on death deeds** (California Courts · English and Spanish): https://selfhelp.courts.ca.gov — **What to look for:** "small estate" and "transfer on death deed".
- **Consular notary services** (Mexican Ministry of Foreign Affairs · Spanish): https://www.gob.mx/sre — **What to look for:** "testamento" and "poder notarial en consulado".

### Key words

- *POD beneficiary:* person who directly receives a bank account when the owner dies.
- *Form 3520:* IRS report of foreign inheritances or gifts over 100,000 dollars.
- *Probate:* court process to distribute the property of someone who died.

### Sources

IRS · California Courts · Mexican Ministry of Foreign Affairs · SAT · Mexican Income Tax Law (article 93), accessed September 30, 2026.

---


# Part 7. Support materials

## Welcome

**Your Money, Your Family, Your Future** is a no-cost personal finance program for immigrants living in California. Here you'll learn to organize your money, send remittances for less, build your credit, protect yourself from fraud and prepare your future, here and in your home country.

You don't need to know about finance to start. Each lesson starts from an everyday situation, explains technical words when they come up and ends with an action you can take this week.

Version 3 · English edition · September 2026.

### How each module is built

| Part | What you'll find | Time |
|---|---|---|
| **Lessons book** | Each lesson starts with a cover page where you choose your path. | 5 or 10 minutes per lesson |
| **What would you do?** | One activity per lesson: three situations where you choose the best decision. | 3 minutes |
| **Module self-assessment** | Questions from all the lessons in the module. You pass with 70% and can try as many times as you want. | 15 to 20 minutes |

### Choose your path in each lesson

- **Quick path (5 min):** read *The essentials* and go to *Practice*. Ideal if you're short on time or already know the topic.
- **Full path (10 min):** add *Go deeper*, with cases, common mistakes and more facts.

**Colored words** show their meaning when you hover over them or tap them on your phone. Answers are hidden: try first, then tap to see them.

### Three program rules

1. **You can use made-up data.** We will never ask for your Social Security number (SSN), your ITIN, your immigration status, passwords or account numbers.
2. **You don't have to buy anything.** You don't need to open accounts, sign up for products or leave a review to learn or get your certificate.
3. **A good decision can be to wait.** Comparing and deciding not to sign up is also learning.

### Points, levels and badges

- You earn **experience points** by completing activities and self-assessments. Points move you up levels: Getting started, Getting organized, Using my account, Caring for my credit, Protecting my family and Building my future.
- When you pass each module's self-assessment you get its **badge**. There are special badges for people who spot scams and compare by total cost.
- Nobody sees your name on a leaderboard. Points reward moving forward, not competing.

### Certificate of completion

When you pass all five self-assessments you get the **Complete plan** badge and your **Certificate of Completion**, which you can download as a PDF. It has a code to verify it online.

It's an educational recognition from the program: it isn't a professional license or an official accreditation.

### Information changes

Fees, requirements and rules change. Before you act, confirm the current information with the institution. Examples with numbers are simulations for learning; they aren't offers or personal recommendations.

### When to ask for professional help

This program teaches you to understand, compare and prepare questions. For a tax, legal, immigration, insurance or investment case that needs a personal recommendation, look for a licensed professional. **Where to find help** has no-cost and low-cost options.

> **Important:** this program **never** gives immigration advice. Only an attorney or a representative accredited by the Department of Justice can give it.

### The five modules

| Module | What it covers | Lessons |
|---|---|---|
| 1. Understand your money and organize your finances | Income, expenses, cash flow, budget, taxes and benefits | 14 |
| 2. Understand the financial system and plan your remittances | Banks, credit unions, apps, accounts, payments, ID and remittances | 13 |
| 3. Build your credit and manage your debts | History, reports, loans, cards, debts, collections and tandas | 10 |
| 4. Protect your money, your identity and your family | Fraud, digital security, insurance, health, emergencies and family preparedness | 11 |
| 5. Build wealth and prepare your future | Goals, investing, housing, retirement, ties with Mexico and entrepreneurship | 11 |
### Meet the characters

Throughout the program you'll follow six people. Their decisions, mistakes and successes will help you practice. They're made-up characters: any resemblance to real people is a coincidence.

- **Alex and Mar** live in Los Angeles with their two children. Alex is paid through payroll every two weeks and does some freelance work on weekends. Mar is paid every week and gets most of her tips in cash. They send money to Alex's mother in Michoacán.
- **Rubén** is 24, came from Oaxaca two years ago and works in a warehouse. He sends money to his mother and is starting his credit history.
- **Daniela** is from San Salvador and lives in San Diego with her son. She works by the hour and has a custom cake business.
- **Rosa** is 61, worked in Guadalajara and lives in Fresno with her daughter and grandchildren. She thinks about her health and her retirement.
- **Andrés** is from León, Guanajuato, and lives in Sacramento with his wife and daughter. He wants to buy a house.


## Capstone cases

The capstone cases use made-up data so you can practice without sharing personal information. Amounts without a currency are in dollars. Solve each case before reading the key.

### E1. Alex and Mar's calendar (Module 1)

**Data.** Between Alex's and Mar's pay, the household receives 600 at the start of each week for eight weeks. Mar also receives 200 from food orders at the start of weeks 2, 4, 6 and 8. The household's starting balance is 200.

- Every week: 220 for food and transportation.
- Weeks 1 and 5: rent of 1,000.
- Weeks 2 and 6: utilities of 100.
- Weeks 3 and 7: card payment of 80.
- Weeks 4 and 8: insurance of 120 and a remittance of 150.

Income arrives before the payments of the same week. It's net income, with no taxes pending.

**Tasks.**

1. Calculate each week and explain the shortfall.
2. Design an alternative without making up income.
3. Suppose pay drops to 480 a week in weeks 5 to 8 and recalculate.
4. Classify the expenses as essential, predictable and family support.
5. Write three 90-day actions.

**Key.**

| Week | Starting balance | Income | Outflows | Ending balance |
|---|---|---|---|---|
| 1 | 200 | 600 | 1,220 | −420 |
| 2 | −420 | 800 | 320 | 60 |
| 3 | 60 | 600 | 300 | 360 |
| 4 | 360 | 800 | 490 | 670 |
| 5 | 670 | 600 | 1,220 | 50 |
| 6 | 50 | 800 | 320 | 530 |
| 7 | 530 | 600 | 300 | 830 |
| 8 | 830 | 800 | 490 | 1,140 |

Totals: income 5,600; outflows 4,660; net change 940; plus starting balance 200 = 1,140.

Week 1 shows 420 of rent without funds. The positive ending balance doesn't erase that problem.

**A possible alternative:** ask the landlord to split the first rent into 580 (week 1) and 420 (week 2) at no charge, and confirm the agreement in writing. Then the balances for weeks 1 and 2 would be 0 and 60, and the rest don't change. Not paying without an agreement isn't a solution.

**With less weekly income** (without the alternative), weeks 5 to 8 end at −70, 290, 470 and 660. A new shortfall appears in week 5.

**Additional tax practice.** A self-employed worker receives 2,000 through a platform and 300 in cash. Her costs for the year are 400. The platform deposits 2,000 in her bank and she moves 1,000 to another account of her own. Result before taxes: 2,300 − 400 = 1,900. The deposits and her own transfer aren't counted again.

### E2. Rubén: an emergency and three remittances (Module 2)

**Data.** Rubén's mother, in Oaxaca, asks for 5,000 pesos for an emergency. Rubén can use at most 310 dollars in total.

| Provider | Exchange rate | Fee | Delivery | Other costs |
|---|---|---|---|---|
| A | 17.00 | 5 | Next day | — |
| B | 16.70 | 0 | Same day | — |
| C | 17.10 | 8 | Same day | The recipient spends 80 pesos on transportation |

You pay from your debit account (no cash remittance tax). Made-up quotes from the same moment.

**Tasks.** Calculate how much you pay so that 5,000 net pesos arrive. Decide whether the date and access change your choice. Then verify a request that came from a new number and write a support agreement.

**Key.**

- A: 5,000 ÷ 17 + 5 = 299.12.
- B: 5,000 ÷ 16.70 = 299.40.
- C: (5,000 + 80) ÷ 17.10 + 8 = 305.08.

All fit within 310. A is the cheapest, but arrives the next day. If the need is same-day, B covers it at a lower cost than C. Before sending, verify the urgency and the provider.

**Debt variation.** You only have 180 left over. A loan would cover B's difference (119.40) with a fixed cost of 18, payable in 14 days: 137.40. If that day you'll only have 100 left over, 37.40 is missing. Don't accept automatically: look at a partial transfer or other real options.

**Cash variation.** If you paid for B in cash at a store and the transfer were subject to the 1% tax, you'd add about 3 dollars.

### E3. Andrés: report and debt plan (Module 3)

**Data.** Andrés's report shows:

- Account A: limit 1,000, balance 600, recognized.
- Account B: balance 900, not Andrés's.
- Account C: balance 250, even though there's proof of payoff.
- Account D: a real two-month delinquency.

**Key.** A's utilization: 60%. Investigate B as possible fraud and dispute C with the proof. Don't report D as identity theft: it's real. Write two requests (B and C) with the account partially identified, the facts, the proof and what you're asking for. For D, build a plan based on your ability to pay.

**Loan comparison.** X gives 1,000 with 12 payments of 100 plus 30 upfront: total 1,230. Y gives 1,000 with 18 payments of 75: total 1,350. Y lowers the payment, but costs 120 more. If your monthly margin is 85, X doesn't fit and Y leaves only 10. Looking for another alternative is also a valid conclusion.

### E4. Rosa: protection and response (Module 4)

**Data.** Rosa compares two policies. Policy A: 80 a month, 1,000 deductible and 20% coinsurance. Policy B: 110 a month, 500 deductible and 10% coinsurance. Allowed service: 3,000. Reserve: 400. A message asks for an access code "to process the payment," and the bill includes an unknown 200 service.

**Key.**

- Event with A: 1,000 + 20% of 2,000 = 1,400. With B: 500 + 10% of 2,500 = 750.
- Yearly premiums: A 960; B 1,320.
- Event plus premiums: A 2,360; B 2,070.
- With no event, B costs 360 more a year.
- The 400 reserve doesn't cover the event with either policy.
- Don't share the code. Verify the contact and ask for a breakdown of the unknown charge.
- B isn't better for everyone: it depends on risk and ability to pay.

**Additional task.** Build the table of contents of a family preparedness plan for Alex and Mar with what you learned in M4 U10 and M5 U08, using made-up data.

### E5. Daniela: future and consistency (Module 5)

**Data.** Daniela has liquid assets of 2,000; a car estimated at 6,000; a car loan of 4,000; a card balance of 500. Basic expenses 1,800 a month. Margin for goals: 120 a month, but she forgot a 40 insurance premium. Goals: reserve, a 600 course in 12 months and long-term retirement.

**Key.**

- Net worth: 8,000 − 4,500 = 3,500. Liquidity: 2,000.
- Coverage if all the liquidity were available: 2,000 ÷ 1,800 = 1.11 months.
- Corrected margin: 120 − 40 = 80.
- The course requires 50 a month; 30 is left for other goals.
- Don't count the same 2,000 for every goal.

**Adverse scenario.** Income drops 200 a month: the 80 margin becomes −120. The contributions are no longer sustainable. Review needs, support and dates, and document the gap.

**Final result.** Explain two decisions with: need, options, information, choice, risk and review date.

---

## Forms for your plan

Fill them in with data from the cases or your own data, on paper or on your computer. Don't upload them to the platform.

**F1 Calendar:** period; date; starting balance; confirmed income; estimated income; essential expense; debt; tax; remittance; reserve; ending balance; alert; action.

**F2 Compared decision:** need; option A; option B; amount; total cost; date; access; requirements; risk; source and date; what still needs confirming; decision; review.

**F3 Family agreement:** purpose; range; date; emergency; verification; review; who takes part; pending items.

**F4 Debts:** creditor; type; balance; rate; fees; minimum payment; due date; collateral; delinquency; consequence; contact; strategy; next review.

**F5 Protection:** risk; impact; coverage or control; exclusion; reserve; gap; action; person responsible; date; contact.

**F6 Goal:** purpose; amount or range; currency; time frame; resources; possible contribution; assumption; adverse scenario; document; consultation; review.

**F7 Professional consultation:** minimum facts; decision; available documents; specific question; deadline; specialty; confirmed cost; secure channel; answer; next step.

**F8 Family preparedness plan:** caregiver and backup; location of documents; accounts and payments (without full numbers); authorizations; contacts; review date.


## Calculation practice

Solve each exercise showing the procedure, the result, the period and the limits of the calculation. The answers are at the end.

| Code | Lesson | Exercise |
|---|---|---|
| P01 | M1 U02 | Calculate 7% of 600 and explain the conversion to a decimal. |
| P02 | M1 U02 | A rate goes from 2% to 3%. Tell apart percentage points and relative increase. |
| P03 | M1 U02 | Principal 1,500, 8% yearly simple interest, nine months, no fees. Calculate interest and balance. |
| P04 | M1 U02 | Principal 1,000 at 5% a year, compounded yearly, three years, no other activity. Calculate the balance. |
| P05 | M1 U02 | A 12% nominal yearly rate compounded monthly. Calculate the monthly rate and the effective yearly rate. |
| P06 | M1 U02 | A price index goes from 250 to 265. Calculate the inflation for the period. |
| P07 | M1 U02 | Inflation drops from 6% to 4%. Did prices go back to their previous level? |
| P08 | M1 U09 | A made-up scale: the first 1,000 at 10%, the next 500 at 20%. Tax and effective rate on 1,500. |
| P09 | M2 U08 | 3,600 pesos are needed. Exchange rate 18 and a fee of 5, no other charges. How much do you pay? |
| P10 | M3 U01 | Debt payments 600 and gross income 3,000 a month. Calculate the ratio and explain what it doesn't prove. |
| P11 | M3 U05 | Balance 800, 2% monthly interest, a 100 payment at the end of the month. Interest, principal paid and balance. |
| P12 | M4 U06 | Reserve 900 and basic expenses 1,800 a month. How much does it cover? |
| P13 | M5 U02 | Principal 1,000, final value 1,050 and a 30 cash payment not reinvested. Total gross return. |
| P14 | M5 U02 | Same case, with 20 in fees and 10 in tax for the year. Net return. |
| P15 | M5 U02 | Net return of 5% and inflation of 4%. Exact real return. |
| P16 | M5 U02 | An investment of 1,000 goes up 10% and then down 10%. Final value and an explanation of the average. |
| P17 | M5 U02 | Principal 1,000 ends at 900 and paid 50 in cash. Total gross return. |
| P18 | M5 U02 | The balance goes from 2,000 to 2,300 with a 250 contribution. Gain and the missing fact for the rate. |
| P19 | M5 U02 | 1,000 grows to 1,440 in two years with no activity. Cumulative rate and compound yearly rate. |
| P20 | M5 U06 | You contribute 40 a month for 10 years with no return. Total contributed; is it compound interest? |
| P21 | M3 U09 | A tanda of 10 people, 80 a week, turn 4. How much do you receive and how much did you contribute before receiving? |
| P22 | M5 U10 | You sell 900 a month, spend 380 on supplies and work 26 hours. Profit and profit per hour. |

### Answers

- **P01:** 42. 7% = 0.07; 600 × 0.07 = 42.
- **P02:** it went up 1 percentage point; the relative increase is 50%.
- **P03:** interest 90; balance 1,590 (1,500 × 0.08 × 9/12).
- **P04:** 1,157.63 (1,000 × 1.05³). With simple interest it would be 1,150.
- **P05:** 1% monthly; 12.68% effective yearly.
- **P06:** 6% ((265 − 250) ÷ 250).
- **P07:** no. Prices keep going up, just more slowly.
- **P08:** tax 200; effective rate 13.33%; marginal rate of the last bracket 20%.
- **P09:** 200 for the transfer plus a 5 fee = 205 dollars.
- **P10:** 20%. It doesn't prove you can pay after your basic expenses or that you'll be approved.
- **P11:** interest 16; principal paid 84; balance 716.
- **P12:** 0.5 months. Don't include money you can't access.
- **P13:** gain 80; return 8% (3% from the payment and 5% from the price change).
- **P14:** net gain 50; net return 5%.
- **P15:** 1.05 ÷ 1.04 − 1 = 0.96%.
- **P16:** 990; a 1% loss even though the average is zero.
- **P17:** −5%. Receiving cash didn't prevent the loss.
- **P18:** gain 50. You need to know when the contribution was made to calculate a comparable rate.
- **P19:** 44% cumulative and 20% compound yearly (1.2 × 1.2 = 1.44).
- **P20:** 4,800 contributed. There's no interest: contributions aren't a return.
- **P21:** you receive 800; before receiving you contributed 240 (3 weeks × 80), and in total you'll contribute 800.
- **P22:** profit 520; 20 an hour before taxes.


## Glossary

Definitions in plain language. A contract or a law may use the word with a more specific meaning. The Spanish term is in parentheses, in case you see it in materials in Spanish or talk about it with your family.

### Money and budgeting

- **Asset** (*activo*): something of value you own.
- **Liability** (*pasivo*): a debt or pending obligation.
- **Net worth** (*patrimonio neto*): assets minus liabilities. It isn't the same as available cash.
- **Gross income** (*ingreso bruto*): what you earn before deductions.
- **Net income** (*ingreso neto*): what you receive after deductions.
- **Cash flow** (*flujo de efectivo*): money coming in and going out over time.
- **Liquidity** (*liquidez*): how quickly you can use a resource without losing value.
- **Available balance** (*saldo disponible*): what the bank lets you use today; it may not include upcoming payments.
- **Budget** (*presupuesto*): a plan for where your money will go.
- **Small recurring expense** (*gasto hormiga*): a small expense that repeats and adds up; it isn't necessarily bad.
- **Periodic expense** (*gasto periódico*): a payment that repeats without being monthly.
- **Sinking fund** (*reserva para gastos previstos*): money set aside for a known payment.
- **Emergency fund** (*fondo de emergencia*): accessible money for the unexpected.
- **Opportunity cost** (*costo de oportunidad*): what you give up when you choose.
- **Priorities** (*prioridades*): what you decide to take care of first.
- **Biweekly** (*cada dos semanas*): every 14 days; 26 payments a year.
- **Semimonthly** (*dos veces al mes*): 24 payments a year.
- **Scenarios** (*escenarios*): possible versions of the future to test your plan.
- **Double counting** (*doble conteo*): using the same money for two things.

### Percentages, interest and inflation

- **Percentage** (*porcentaje*): a part of each hundred; 4% = 0.04.
- **Percentage point** (*punto porcentual*): the direct difference between percentages; from 4% to 6% is 2 points.
- **Principal** (*capital*): the base amount of a loan or investment.
- **Interest** (*interés*): the cost of using borrowed money, or the earnings on certain balances.
- **Simple interest** (*interés simple*): always calculated on the original principal.
- **Compound interest** (*interés compuesto*): also calculated on earlier interest.
- **Effective rate** (*tasa efectiva*): the real change over a period, taking compounding into account.
- **APR** (*tasa de porcentaje anual*): the yearly cost of credit according to official rules.
- **APY** (*rendimiento porcentual anual*): the yearly return on savings with compounding.
- **Fixed rate** (*tasa fija*): doesn't change during the agreed term.
- **Variable rate** (*tasa variable*): can change according to the contract.
- **Inflation** (*inflación*): a general rise in prices.
- **Disinflation** (*desinflación*): prices rise more slowly.
- **Deflation** (*deflación*): prices go down.
- **Purchasing power** (*poder de compra*): what your money can buy.
- **Exchange rate** (*tipo de cambio*): the price of one currency in another; always state the direction.

### Banks, payments and remittances

- **Central bank** (*banco central*): a public institution; it doesn't handle personal accounts.
- **Credit union** (*cooperativa de ahorro y crédito*): a financial institution owned by its members.
- **Fintech:** a company that uses technology for financial services; that doesn't prove it's a bank.
- **Neobank** (*neobanco*): a mainly digital service; check the bank behind it.
- **Responsible entity** (*entidad responsable*): the company that answers for the service.
- **Deposit insurance** (*seguro de depósitos*): protects eligible deposits if the institution fails (FDIC or NCUA).
- **Checking account** (*cuenta de cheques*): for frequent use.
- **Savings account** (*cuenta de ahorro*): for keeping money.
- **Fee** (*comisión*): a charge for a service.
- **Maintenance fee** (*comisión de mantenimiento*): a monthly charge for having the account.
- **Bank On:** a national standard for low-cost accounts.
- **Overdraft** (*sobregiro*): you spend more than you have and the bank covers it for a fee.
- **ACH:** the electronic transfer network between banks.
- **Dispute** (*disputa*): a request to review an incorrect charge or information.
- **Remittance** (*remesa*): money sent to another person or country.
- **Remittance receipt** (*recibo de remesa*): proof of the transfer.
- **Reference number** (*folio*): a tracking number.
- **Exchange-rate markup** (*margen cambiario*): the difference between the reference rate and the rate offered.
- **Quote** (*cotización*): the terms offered for a moment and an amount.
- **DFPI:** California's financial regulator; it licenses money transmitters.
- **NMLS:** the national licensing registry for financial companies.

### ID and taxes

- **SSN** (*número de Seguro Social*): Social Security number.
- **ITIN** (*número de identificación personal del contribuyente*): an IRS tax number for people who can't get an SSN; it doesn't authorize work.
- **Matrícula consular:** an ID issued by the Mexican consulate.
- **AB 60 license:** a California driver's license for people who can't prove legal presence; it isn't a REAL ID.
- **Tax return** (*declaración de impuestos*): reports your information and calculates your tax.
- **Tax refund** (*reembolso*): money returned if you paid too much.
- **Withholding** (*retención*): taxes paid in advance, taken out of your pay.
- **Tax deduction** (*deducción*): reduces the amount taxed.
- **Tax credit** (*crédito fiscal*): reduces the tax; some are refundable.
- **CalEITC:** California's state credit for work income; it can be claimed with an ITIN.
- **VITA:** no-cost IRS help to prepare taxes.
- **CTEC:** California's registry of tax preparers.
- **Estimated payments** (*pagos estimados*): tax payments made during the year.
- **Marginal rate** (*tasa marginal*): the rate on the last bracket of income.
- **Effective tax rate** (*tasa efectiva de impuesto*): tax divided by income.
- **Public charge** (*carga pública*): an assessment in certain immigration procedures about reliance on government benefits.

### Credit and debt

- **Credit history** (*historial crediticio*): the record of your experience with credit.
- **Credit report** (*reporte de crédito*): a document with your accounts and payments.
- **Credit score** (*puntaje de crédito*): a number calculated with a model.
- **Affordability** (*capacidad de pago*): being able to pay with your resources.
- **Credit utilization** (*utilización*): balance divided by limit.
- **Secured card** (*tarjeta garantizada*): backed by a deposit.
- **Credit builder loan** (*préstamo constructor de crédito*): you make payments and get the money at the end.
- **Tanda:** rotating savings among a group of people.
- **Lending circle** (*círculo de préstamo*): an organized social loan that can be reported to the credit bureaus.
- **Co-signer** (*cofirmante o aval*): someone who answers for another person's debt.
- **Authorized user** (*usuario autorizado*): someone who uses another person's card.
- **Minimum payment** (*pago mínimo*): the least required; it doesn't pay off the debt.
- **Grace period** (*periodo de gracia*): time to avoid interest if you pay in full.
- **Statement closing date** (*fecha de corte*): the end of the statement period.
- **Amortization** (*amortización*): how payments reduce the principal.
- **Delinquency** (*mora o atraso*): not paying on time.
- **Debt collection** (*cobranza*): actions to collect a debt.
- **Consolidation** (*consolidación*): combining debts into one.
- **Refinancing** (*refinanciamiento*): replacing a debt with another one with new terms.
- **Debt-to-income ratio** (*relación deuda-ingreso*): debt payments divided by income.

### Protection

- **Scam** (*estafa*): a trick to get money or information.
- **Phishing:** fake messages or pages that ask for your information.
- **Identity theft** (*robo de identidad*): using your information to impersonate you.
- **Credit freeze** (*congelamiento de crédito*): prevents new accounts from being opened in your name.
- **Multifactor authentication** (*autenticación de varios pasos*): a second check in addition to the password.
- **Notary public:** in the U.S. only certifies signatures; not a lawyer.
- **Accredited representative** (*representante acreditado*): authorized by the DOJ to give immigration advice at a recognized organization.
- **Economic abuse** (*abuso económico*): control over another person's resources or money decisions.
- **Premium** (*prima*): what you pay for insurance.
- **Deductible** (*deducible*): what you pay before the insurance pays.
- **Copayment** (*copago*): a fixed amount for a service.
- **Coinsurance** (*coaseguro*): the percentage you pay after the deductible.
- **Exclusion** (*exclusión*): what the insurance doesn't cover.
- **Explanation of benefits** (*explicación de beneficios*): a summary of how care was processed; it isn't a bill.
- **Contingency plan** (*plan de contingencia*): steps prepared to respond to a problem.
- **Family preparedness plan** (*plan de preparación familiar*): instructions so your family can carry on if you can't be there.
- **Caregiver's Authorization Affidavit** (*declaración jurada de autorización del cuidador*): a California document for a minor's school and certain medical matters; it doesn't change custody.

### Wealth, housing and the future

- **Contribution** (*aportación*): money you add to an account or goal; it isn't a gain.
- **Return** (*rendimiento*): the gain or loss of an investment.
- **Real return** (*rendimiento real*): adjusted for inflation.
- **Diversification** (*diversificación*): spreading the risk; it doesn't eliminate losses.
- **Volatility** (*volatilidad*): how much a value goes up and down.
- **ETF:** a fund bought and sold on the stock market.
- **Retirement account** (*cuenta de retiro*): a structure with tax and withdrawal rules.
- **Employer match** (*aportación patronal*): what your employer puts in.
- **Vesting** (*adquisición de derechos*): the conditions for your employer's contribution to become yours.
- **CalSavers:** California's retirement program.
- **AFORE:** the company that manages retirement savings in Mexico.
- **Down payment** (*enganche*): the upfront payment when buying.
- **Closing costs** (*costos de cierre*): the expenses of buying a home.
- **Rent cap** (*tope de renta*): the maximum increase allowed.
- **Beneficiary** (*beneficiario*): who receives a benefit.
- **Power of attorney** (*poder notarial*): authorizes someone to act for you.
- **EIN:** a business tax number.
- **Total cost of ownership** (*costo total de uso*): everything it costs to own and use something.


## Where to find help

Each option has a different role: a regulator doesn't replace a tax preparer or an attorney. Before sharing documents, confirm language, cost, scope and credentials. The information was verified as of September 27, 2026; confirm it's still current.

| Need | Where | Cost | What to check |
|---|---|---|---|
| Preparing taxes | IRS VITA and TCE | At no cost for those who qualify | Location, language, whether they help with ITINs |
| Tax help in California | FTB no-cost help and CalFile | At no cost depending on the program | Requirements for the year |
| Verifying a preparer | CTEC (California) and the IRS directory | No cost | Current registration |
| Immigration advice | Licensed attorneys and DOJ-accredited representatives | Varies; there are no-cost options | License with the State Bar or accreditation on the DOJ (EOIR) list |
| General legal help | State Bar of California certified lawyer referral services | The consultation may have a cost | Service certification and license |
| Reporting notario fraud | State Bar, California Attorney General, FTC | No cost | Keep contracts and receipts |
| Identity theft | FTC IdentityTheft.gov | No cost | Go directly to the site; avoid imitators |
| Financial complaints | CFPB and DFPI | No cost | Your complaint number |
| Money transmitter licenses | DFPI and NMLS Consumer Access | No cost | Exact legal name |
| Banks and credit unions | FDIC BankFind and the NCUA locator | No cost | Legal name and insurance |
| Building credit with tandas | Mission Asset Fund and other lending circles | No cost | Which bureaus they report to |
| Housing | HUD-certified housing counselors (CFPB locator) | No-cost or low cost | Agency and service area |
| Insurance | California Department of Insurance (CDI) | No cost | License of the insurer and the agent |
| Health plans | DMHC Help Center | No cost | Whether your plan is under its oversight |
| Wages and labor rights | Department of Industrial Relations (DIR) | No cost | Keep hours and pay stubs |
| Your own business | Small Business Development Centers (SBDC) | No-cost or low cost | Advice in Spanish |
| Retirement | CalSavers | No cost | Participation requirements |
| Consular financial guidance | Ventanillas de Asesoría Financiera at Mexican consulates | No cost | Hours and appointments |

**Private preparers.** You can compare them using the same approach. One example in San Diego is ATAX Chula Vista Downtown, which advertises tax services, including ITIN help; confirm the full fees, the credential of the person who helps you and the scope. Appearing on this list isn't a recommendation or a partnership.

### Script to ask for information

"I live in California and I need help with [topic]. Do you handle this kind of case in Spanish? What credential does the person who will help me have? What's the total cost and what doesn't it include? What documents do I need and how do I send them securely? Is there a no-cost or low-cost option?"

---

## Market observations

An educational sample of accounts, with public information as of September 27, 2026. It isn't a complete list or a ranking of the best. Published fees don't replace the contract or approval. We have no referral agreements with these institutions. You'll find the updated comparison matrix on the platform.

| Product | Type | Published cost | What to check |
|---|---|---|---|
| Wells Fargo Clear Access Banking | Bank | 5 a month or waived (account holder aged 13 to 24, or 250 in eligible electronic deposits) | Combination of documents and which deposit qualifies. It accepts the matrícula consular as primary ID, along with another ID. |
| Bank of America Advantage SafeBalance | Bank | 4.95 per cycle or waived (under 25, 500 minimum daily balance or a benefits program) | Documents, account opening and the full waiver conditions |
| Self-Help Checking | Credit union | 5 fee, no minimum opening deposit; waivers by age, direct deposit or balance | The entity on the contract, membership and conditions in California |
| Chime Checking | Digital service with partner banks | No monthly maintenance fee | It asks for a valid SSN, age 18 and citizenship or lawful residence: don't assume it accepts an ITIN. Check the issuing bank and other charges. |

**Exercise.** A 35-year-old person is paid in cash, has a matrícula consular and has no SSN or ITIN. Don't choose by "no fee": first identify which documents each option accepts, whether they can open at a branch and how much it costs to deposit cash. No option guarantees approval.

---

## Frequently asked questions

**Can I study without an SSN or ITIN?** Yes. We use a program ID and made-up cases. Whether you can use a financial product is a different question.

**Do I have to open an account to pass?** No. We assess how you compare and decide; waiting can be the right decision.

**What if I can't save?** Identify your gap, your priorities and the support available. We don't require an amount or blame everything on your habits.

**Should I stop sending remittances?** No. The goal is to fit together your family support, your ability to pay and your future.

**Does this course give me immigration advice?** No. Only an attorney or a DOJ-accredited representative can give it. We help you find reliable help.

**When will my score improve?** Nobody can promise a date or a number of points. We work with correct information, sustainable payments and follow-up.

**Can I use made-up information?** Yes. We assess your reasoning; you don't need to reveal your identity, your health or your finances.

**What do I do if a source changed?** Mark it, check the current version and don't use an expired fee as if it were current.

**Is the certificate officially accredited?** It's the program's own certificate, verifiable online. It isn't a license or an official accreditation.

**Do I have to leave a review?** No. Your feedback and follow-up are voluntary and don't affect your access or your certificate.

**Can I ask for a video call?** We offer question sessions according to the published availability. Cases that need a professional are referred.

**How do I send a question?** Include the module, the situation without sensitive information, what you tried and your specific question. If there's a fraud in progress or a medical emergency, first use the appropriate emergency channel.


## References

S references come from the program syllabus; R references were added to develop the lessons. Date accessed for this edition: September 27 and 28, 2026. Rules, fees and requirements change: check the current version before you act.

### Syllabus references

- **S01** OECD and European Union. Financial competence framework for adults.
- **S02** CFPB. Measuring financial skill.
- **S03** FDIC. Money Smart for Adults.
- **S04** CFPB. Your Money, Your Goals.
- **S05** CFPB. Financial Well-Being Scale.
- **S06** Federal Reserve. What is the money supply.
- **S07** NCUA. Differences between a credit union and a bank.
- **S08** FDIC. Banking with third-party apps.
- **S09** FDIC. BankFind Suite.
- **S10** CFPB. Spanish style guide and glossary.
- **S11** California DIR. Know Your Rights.
- **S12** IRS. Individual Taxpayer Identification Number (ITIN).
- **S13** IRS. Gig Economy Tax Center.
- **S14** California FTB. ITIN.
- **S15** California FTB. Get no-cost tax help.
- **S16** California FTB. Publication 982, choosing a tax preparer.
- **S17** CFPB. What is a remittance transfer and what are my rights?
- **S18** CFPB. Ways to start or rebuild a good credit history.
- **S19** CFPB. How long does information stay on my credit report?
- **S20** FTC. Only scammers say they'll remove all negative information from your credit report.
- **S21** California Department of Insurance. Consumer guides.
- **S22** FTC. IdentityTheft.gov.
- **S23** SEC Investor.gov. Introduction to investing.
- **S24** SEC Investor.gov. Investment products.
- **S25** SSA. U.S.–Mexico social security agreement (signed, not in effect).
- **S26** CFPB. Five principles for effective financial well-being programs (2017).
- **S27** CalSavers. Program details.

### Lesson references

- **R01** Bank of England. Money creation in the modern economy.
- **R02** FDIC. Understanding deposit insurance.
- **R03** NCUA. Share insurance coverage.
- **R04** IRS. News release IR-2026-48 on the remittance tax.
- **R05** IRS. Publication 505, Tax Withholding and Estimated Tax.
- **R06** IRS. Deadlines and extensions.
- **R07** CFPB. Does checking my credit report hurt my score?
- **R08** CFPB. What information does a debt collector have to give me?
- **R09** CFPB. What is a credit freeze?
- **R10** California DMV. Insurance requirements.
- **R11** California FTB. Health care mandate.
- **R12** California DMHC. File a complaint.
- **R13** Wells Fargo. Clear Access Banking.
- **R14** Wells Fargo. Questions about ID and account opening.
- **R15** Bank of America. SafeBalance.
- **R16** Self-Help. Checking.
- **R17** Chime. Checking account.
- **R18** Chime Help. How to open an account.
- **R19** IRS. No-cost tax preparation for qualifying taxpayers (VITA and TCE).
- **R20** ATAX Chula Vista Downtown. Advertised services.
- **R21** FTC. March 2022 action against a credit repair company.
- **R22** CFPB. Find a housing counselor.
- **R23** State Bar of California. Lawyer referral services.
- **R24** CFPB. How does compound interest work?
- **R25** CFPB. Regulation DD, APY calculation.
- **R26** Bureau of Labor Statistics. Consumer Price Index frequently asked questions.
- **R27** IRS. Self-Employed Individuals Tax Center.
- **R28** CFPB. How does my credit card calculate interest?
- **R29** CFPB. What is a credit card grace period?
- **R30** SEC Investor.gov. How fees affect your investments.
- **R31** SEC Investor.gov. Asset allocation and diversification.
- **R32** SEC Investor.gov. Bonds frequently asked questions.
- **R33** USCIS. Public charge.
- **R34** Protecting Immigrant Families. Public charge materials.
- **R35** California DHCS. Medi-Cal and eligibility changes.
- **R36** California Tax Education Council (CTEC). Registered preparer lookup.
- **R37** California Secretary of State. Immigration consultants.
- **R38** Department of Justice (EOIR). Recognized organizations and accredited representatives.
- **R39** California Courts. Caregiver's Authorization Affidavit.
- **R40** California DFPI. License search.
- **R41** NMLS Consumer Access.
- **R42** California DMV. AB 60 driver's license.
- **R43** Mission Asset Fund. Lending circles.
- **R44** State of California. Guide to tenants' rights and responsibilities.
- **R45** IRS. Apply for an Employer Identification Number (EIN).
- **R46** Cities for Financial Empowerment Fund. Bank On National Account Standards.
- **R47** California Attorney General. Immigration services fraud.
- **R48** California FTB. CalFile.
- **R49** CONDUSEF. Remesamex.
- **R50** World Bank. Remittance Prices Worldwide.
- **R51** FTC. ReportFraud.ftc.gov.
- **R52** California HCAI. Hospital fair pricing and financial assistance.
- **R53** Social Security Administration. my Social Security.
- **R54** CONSAR. Find your AFORE.
- **R55** California CDTFA. Seller's permit.
- **R56** SBA. Small Business Development Centers (SBDC).


# Part 8. H5P activities "What would you do?"

One per lesson. The option marked ✔ is correct; on the platform options appear in random order.

## M1 U01. Is all the money I receive money I earned?

**Case 1. The advance from the boss.** Alex gets a 400-dollar advance on wages. That week the account shows more money than ever. Mar wants to use it to buy a refrigerator. **What should they consider?**

- ✔ Consider that the advance will come out of the next paychecks.
- Buy the refrigerator now, because that week there's money left over.
- Spend it quickly, before the boss changes their mind.

**Case 2. Daniela's cakes.** Daniela sold 600 dollars' worth of cakes in a month. She spent 250 on ingredients and boxes. **How much did she earn?**

- ✔ 350 before taxes.
- 600, because that's what she charged.
- 850, adding sales and ingredients.

**Case 3. The mystery deposit.** A 300 deposit shows up in Rubén's account. He doesn't know where it came from. A few days later, someone texts him: "I deposited it by mistake, send it back to me by Zelle." **What should Rubén do?**

- ✔ Not touch it and first call his bank at the official number.
- Send it back by Zelle right away so he doesn't get in trouble.
- Spend it, because the mistake was the other person's, not his.

## M1 U02. Why doesn't the same money go as far anymore?

**Case 1. Alex and Mar's rent.** General inflation for the year was 3%, but their rent went up 8%. **Which inflation matters more to them?**

- ✔ Their own expenses, because rent weighs more.
- The national one, because it's the government's official number.
- Neither: inflation has nothing to do with rent.

**Case 2. The savings that "grew".** Mar kept 1,000 dollars in an account that paid 3% in a year. The basket of things she buys went up 5%. **Did she gain or lose?**

- ✔ She lost buying power even though she has more dollars.
- She gained 30 dollars, because her account grew.
- She stayed the same, because her money didn't drop a cent.

**Case 3. The "1% a week" loan.** Rubén is offered a "cheap" loan at 1% a week. **How much is that a year?**

- ✔ Almost 68% a year: it isn't cheap.
- 52% a year: 1% for each week.
- 12% a year, like a credit card.

## M1 U03. What do I need to take care of first?

**Case 1. The two subscriptions.** Mar pays 15 a month for a music app she uses every day and 9 for a video app she forgot she had. **Should she cancel the more expensive one?**

- ✔ Cancel the video app she doesn't use, even if it costs less.
- Cancel the music app, because it's the one that costs more each month.
- Cancel both, because neither one is a necessary expense.

**Case 2. The birthday present.** Alex has 60 dollars left over. Alex can buy their son's birthday present or save the money. **What is the right answer?**

- ✔ It depends on his priorities, if the bills are covered.
- Always save it, because a present is an unnecessary expense.
- Buy the present, because saving can always wait.

**Case 3. Rubén's 60 dollars.** Rubén has 60 dollars until his next paycheck. His mom needs a 40-dollar medicine, his work shoes are torn and he was invited to a concert. **What is urgent?**

- ✔ The medicine and the shoes: they protect his health and his job.
- The concert, because the invitation is only for that day.
- The shoes first; the medicine can wait until payday.

## M1 U04. Is getting paid every week the same as getting paid every month?

**Case 1. Alex and the three-paycheck months.** Alex gets 900 every two weeks. One month three paychecks arrive: 2,700. **What happens if Alex uses that month to sign a car loan?**

- ✔ In the two-paycheck months it won't be enough.
- Nothing: if that month is enough, every month is.
- There will be money left over because the pay comes more often.

**Case 2. Mar's tips.** In December Mar received 2,400 between pay and tips. In January, only 1,500, because tips went down. **What does she need?**

- ✔ A plan for the low month, setting aside in the high months.
- Take out a small loan every January to fill the gap.
- Spend the same as always and hope tips go up.

**Case 3. Daniela's orders.** Daniela charges 150 per cake order. One month she had 18 orders and spent 270 on ingredients and boxes. **How much is left before taxes?**

- ✔ 2,430.
- 2,700.
- 2,970.

## M1 U05. Why is my deposit smaller than what I earned?

**Case 1. The missing hours.** Alex worked 40 hours, but the pay stub says 36. **What should Alex check first?**

- ✔ The dates of the pay period.
- Whether to quit over the hours.
- Whether to complain in front of everyone.

**Case 2. The unknown deduction.** Rubén sees a 12-dollar deduction called "uniform." **What does he do?**

- ✔ Ask in writing what it is and whether he has to pay it.
- Accept it, because all deductions are legal.
- Stop going to work until they remove it.

**Case 3. Rubén's 565.** Rubén expected 700 and received 565. **Is there a mistake?**

- ✔ Not necessarily: 700 was his gross pay.
- Yes, the employer owes him 135 dollars.
- Yes, the bank made a mistake with the deposit that week.

## M1 U06. Can a small purchase add up to a lot?

**Case 1. Alex's sodas.** Alex buys a 2.50 soda every workday: 55 a month. **What does Alex decide?**

- ✔ Bring water three days and keep the soda on Fridays.
- Give up soda completely and never buy one again.
- Change nothing, because 2.50 a day makes no difference.

**Case 2. Rubén's forgotten subscription.** Rubén finds a 12.99 monthly charge from an app he tried "at no cost." He's been paying for eight months. **How much has he paid?**

- ✔ 103.92.
- 12.99.
- 155.88.

**Case 3. Daniela's big package.** Daniela compares two packages of strawberries for her cakes. She'll only use half of the big one before they go bad. **Is the big one worth it?**

- ✔ No: what counts is the cost of what she actually uses.
- Yes: the big package always comes out cheaper.
- Yes, because the price per piece is lower.

## M1 U07. Why am I short on money if I earn enough this month?

**Case 1. Rent on the 1st.** Alex and Mar pay 1,800 in rent on the 1st. Alex gets paid every two weeks and Mar every week. **Why are they short on the 1st?**

- ✔ Their paychecks arrive after the rent due date.
- They earn less than they need to live in their area.
- They spend too much on food during the first week.

**Case 2. Daniela's automatic payment.** Daniela's car insurance is charged automatically on the 3rd. One month her account had 60 dollars and the 120 charge triggered a 35 overdraft fee. **What changed?**

- ✔ She sets an alert and asks how to turn off overdraft.
- She cancels her car insurance to avoid more charges.
- She leaves the account empty so the charge doesn't go through.

**Case 3. Rubén's shared room.** Rubén and his roommates pay rent on the 1st, but each one gets paid on different dates. **What do they agree on?**

- ✔ Each one deposits their share three days before.
- Each one pays when they get paid, even if it's late.
- Rubén pays it all and then collects from the others.

## M1 U08. How do I decide what to use my money for?

**Case 1. Alex and Mar's hard month.** Their income drops from 2,400 to 1,920 and they're 480 short. **What adjustments can they make?**

- ✔ Pause savings, lower the remittance and ask for a payment plan.
- Cancel every subscription and hope it's enough.
- Take out a 480 loan and pay it back when things improve.

**Case 2. Is the subscription the problem?.** Canceling a 15 subscription leaves a 465 shortfall. **What does this show?**

- ✔ That big decisions need review and support is needed.
- That the subscription was the real problem of the month.
- That there's nothing to do and they can only wait for more work.

**Case 3. Daniela's envelopes.** Daniela gets income from her hourly job and from her cake orders. She used to mix it all together, and at the end of the month she didn't know what had happened. **What changes?**

- ✔ She sets up envelopes for home, business and taxes on payday.
- She keeps mixing it all and reviews it at the end of the year.
- She spends on the home first and at the end of the month sees what's left.

## M1 U09. Does filing taxes mean I'll get money back?

**Case 1. The expected refund.** Mar believes that "filing taxes is so they give you money back." This year she got part of her income through an app, with no withholding. When she does the math, she owes 400. **What happened?**

- ✔ Nobody withheld taxes from what she got through the app.
- The IRS made a mistake, because there's always a refund.
- She filed late last year and now she's being fined.

**Case 2. Dependents in Mexico.** Alex sends money to Alex's mother in Michoacán. **Can she be claimed as a dependent?**

- ✔ It isn't automatic: Alex should ask a tax preparer.
- Yes, as long as Alex sends money every month.
- No, nobody in another country can ever be a dependent.

**Case 3. Rubén's ITIN.** Rubén got his ITIN four years ago, but he didn't file for the last three. **What can happen?**

- ✔ His ITIN may be deactivated and need renewing.
- Nothing, because an ITIN never expires.
- He can never get another ITIN, even if he files again.

## M1 U10. Is everything I earn on my own for spending?

**Case 1. Mar's tips and app.** Mar gets her wages through payroll, tips in cash and some payments through an app. The app sends her a 1099 for 3,200. Her cash tips added up to 4,500 and don't show up on any form. **What must she report?**

- ✔ All of it: wages, app payments and tips.
- Only her wages and what the 1099 form says.
- Only what shows up on some official form.

**Case 2. Alex's faded receipts.** Alex does weekend jobs and kept the receipts for materials in a box. By the end of the year many had faded. **What changes?**

- ✔ Alex takes a photo of each receipt the same day.
- Alex throws out the faded receipts and doesn't count them.
- Alex guesses the expenses at the end of the year.

**Case 3. Daniela's cakes.** Daniela gets paid for her orders in cash and through Zelle. She buys ingredients at three different stores. **How does she get organized?**

- ✔ An order log and photos of each receipt.
- She writes down only Zelle payments, which are recorded anyway.
- She keeps the receipts in a box and looks at them in April.

## M1 U11. What tax benefits are there if I file with an ITIN?

**Case 1. Mar and CalEITC.** Mar files with an ITIN. With her income and two young children, a VITA site checks whether she qualifies for CalEITC and YCTC. **What does she find out?**

- ✔ That instead of owing, she gets a state credit.
- That with an ITIN she doesn't qualify for any credit.
- That she has to pay more taxes for having young children at home.

**Case 2. The passport in the mail.** A neighbor tells Rubén that for the ITIN he has to mail his original passport to the IRS. **Is there another option?**

- ✔ Yes: a Certifying Acceptance Agent can review his documents.
- No: you always have to mail the original passport.
- Yes: he can just mail a copy without certification.

**Case 3. Daniela's expired ITIN.** Daniela didn't file for three years and her ITIN was deactivated. **What does she do?**

- ✔ She renews it with the W-7 together with her tax return.
- She stops filing until the IRS comes looking for her.
- She asks for a new ITIN in another family member's name to file.

## M1 U12. How do I choose someone to help me with taxes?

**Case 1. The guaranteed refund.** An ad on social media promises Rubén a "3,000 refund guaranteed." They ask him to sign before reviewing anything. **What does he do?**

- ✔ He doesn't sign and looks for a VITA site.
- He signs quickly to lock in the refund.
- He pays a deposit to hold his spot.

**Case 2. The two quotes.** Mar compares two preparers. The cheap one charges extra for the state return and for self-employment. The expensive one includes everything and gives her a copy. **Which one is better for her?**

- ✔ The one that includes everything, because it's cheaper.
- The cheap one, because in the end they all charge the same.
- Neither: she does it herself even if she doesn't know the rules.

**Case 3. The refund account.** Daniela's preparer asks her to have the refund sent to "the office account" to "save time." **What does she do?**

- ✔ She says no: the refund must go to her own account.
- She agrees, because that way it's faster.
- She agrees, but asks the office for a receipt.

## M1 U13. What should I know before I apply for public benefits?

**Case 1. Food for Daniela's son.** Daniela's son was born in California. She was afraid to ask for help with food. **What does a community organization explain to her?**

- ✔ That her son's benefits don't count as hers.
- That asking for food always affects the whole family.
- That her son isn't entitled to any public benefit.

**Case 2. The neighbor's rumor.** A neighbor tells Alex that "any benefit takes away your green card." **What does Alex do?**

- ✔ Looks for a reliable source before deciding.
- Believes the neighbor and stops asking for any help.
- Asks in a social media group what other people did.

**Case 3. Mar's question.** Mar needs medical care and doesn't know whether she can enroll in Medi-Cal this year. **What options does she have while she confirms?**

- ✔ A community health center that charges based on income.
- Wait until it gets worse and go straight to the ER.
- Not get care until she has her own health insurance.

## M1 U14. How do I turn what I learned into something I can actually do?

**Case 1. Alex and Mar's plan.** Their problem: they're short on money before rent. **What actions do they choose?**

- ✔ Write down dates, ask to change a date and recalculate.
- Take out a loan every month to make rent.
- Wait to earn more before getting organized, because now it's impossible.

**Case 2. "I want to save more".** Daniela wants to save, but her household still has a deficit. **Where does she start?**

- ✔ Stabilize first: record the shortfall.
- Save 20% every month even if she's short.
- Forget about saving until she earns more.

**Case 3. Rubén's ideas.** Rubén has lots of ideas and no dates. **What does he do?**

- ✔ He picks one action with a date and does it.
- He does all his ideas in the same week.
- He waits until he has more spare time to start.

## M2 U01. Who takes care of my money and who provides the service?

**Case 1. The pharmacy card.** Rubén bought a prepaid card at a pharmacy. A charge he doesn't recognize shows up. At the pharmacy they tell him they can't help. **Who should he call?**

- ✔ The issuing bank, at the number on the back.
- The pharmacy, because that's where he bought it.
- The number someone sends him by text.

**Case 2. Alex's four needs.** Alex needs to keep the rent money, receive payments from clients, send money to Mexico and insure the pickup truck. **Does Alex need four institutions?**

- ✔ Not always: note the service, cost and how to complain.
- Yes, you always need one institution per need.
- No, one payment app is enough for everything.

**Case 3. Daniela's app.** Daniela receives payments for her cakes in an app. The app says it "works with banks." **What should she look for?**

- ✔ The partner bank's name, checked on BankFind.
- The app's reviews and how many people use it.
- Nothing: if it says it works with banks, it's protected.

## M2 U02. Is a money app always a bank?

**Case 1. "We work with banks".** An app tells Daniela that her money is protected because it "works with banks." **What does Daniela do?**

- ✔ She finds the bank in the terms and checks it on BankFind.
- She trusts it, because the app says so on its home page.
- She asks her friends whether it has gone well for them.

**Case 2. Rubén's phone.** Rubén lost his phone, and an app was his only way to reach his money. **What did he learn?**

- ✔ Ask for a physical card and write down the help line.
- Never use any app again to manage his money.
- Save his password in a text so he doesn't lose it.

**Case 3. Mar's credit union.** A credit union asks Mar for 5 dollars to become a member. **Can she spend those 5?**

- ✔ Usually not: it's her membership share.
- Yes, she can use it whenever she wants.
- No, it's charged to her as a fee.

## M2 U03. What ID works for financial paperwork?

**Case 1. Rubén and the branch account.** Rubén has a passport and a consular ID, but no SSN or ITIN. He calls two banks and a credit union. **What does he find out?**

- ✔ That each institution accepts different documents.
- That without an SSN no bank will open an account.
- That they all ask for exactly the same papers.

**Case 2. The appointment for sale.** Alex is offered a "fast" consulate appointment for 80 dollars. **What does Alex do?**

- ✔ Doesn't pay: appointments cost nothing in the official system.
- Pays, because that way Alex avoids months of waiting online.
- Pays half upfront and the rest at the appointment.

**Case 3. Daniela's ID.** Daniela's Salvadoran passport has expired. **What does she do before opening her account?**

- ✔ She renews her passport and asks which other papers they accept.
- She uses the expired passport and doesn't tell the bank.
- She asks a friend to open the account in the friend's name.

## M2 U04. What do I need to open an account, and how much does it cost to keep it?

**Case 1. Alex's "at no cost" account.** Alex's account costs nothing with payroll direct deposit. Alex gets paid by check and deposits it at the teller. **How much does it cost?**

- ✔ 12 a month: 144 a year.
- Nothing: the account costs nothing.
- 12 a year, only once.

**Case 2. The joint account.** Mar's cousin asks her to add him to her account "to help him out." **What's the risk?**

- ✔ Her cousin could withdraw the whole balance.
- None: the cousin can only see the balance.
- Only that the bank charges her more fees.

**Case 3. Rubén's cash.** Rubén gets paid through payroll, but his roommates pay him their share of the rent in cash. **What does he compare?**

- ✔ Where to deposit cash at no cost near home and work.
- Which app has the most downloads and best ratings.
- Which bank pays the highest interest rate this month.

## M2 U05. Is all the balance I see available to spend?

**Case 1. The duplicate payment.** Alex doesn't see a payment show up and makes it again. The next day both appear. **What should Alex have done?**

- ✔ Check the status and the receipt before repeating it.
- Repeat it, because if it goes through twice it's refunded.
- Close the account and open another one at another bank.

**Case 2. Mar's reconciliation.** Starting balance 100, deposit 500, payments of 320 and 60. She expected 220 and the statement shows 210. **What does she do?**

- ✔ She looks for the 10: a fee for using another ATM.
- She ignores it, because 10 dollars is very little.
- She closes the account because the bank stole from her.

**Case 3. Rubén's "seller".** Rubén paid 150 by Zelle for a used phone that never arrived. **Must the bank give him the money back?**

- ✔ Usually not, because he authorized the payment.
- Yes, the bank always refunds these payments.
- Yes, but only if he waits thirty days.

## M2 U06. How do I support my family without deciding at the last minute?

**Case 1. Alex's mom.** She asks for 200 dollars every month for food, 120 at the start of her granddaughter's school year and, this month, 400 for a hospital stay. **How does Alex sort it?**

- ✔ Food regular, school foreseeable, hospital an emergency.
- Everything is an emergency, because Alex's mom needs it.
- Everything is regular, because she asks every month.

**Case 2. Rubén's messages.** Rubén's mom texts him every month with a different amount. **What changes?**

- ✔ Agree on an amount and a date, and give notice early.
- Always send whatever his mom asks for, without questions.
- Stop answering until the amount she asks for goes down.

**Case 3. Daniela's sister.** Daniela sends money to her sister in San Salvador for her niece's school. **In what currency does she plan?**

- ✔ In dollars, comparing fees and delivery time.
- In pesos, because that's what's sent the most.
- In colones, El Salvador's former currency.

## M2 U07. How much can I send, and when?

**Case 1. Rent and the send.** Alex gets paid three days after paying rent. The month ends positive, but if Alex sends money before rent, that day comes up short. **What does Alex decide?**

- ✔ Send after payday.
- Send before rent.
- Borrow to send it.

**Case 2. Mar's 120.** Mar has 900. She needs 650 until her next paycheck, 80 for her tax savings and 50 for the savings she agreed on. **How much can she send?**

- ✔ 120.
- 200.
- 250.

**Case 3. Rubén's brothers.** Rubén and his brother, who lives in Texas, support their mom in Oaxaca. **What do they agree on?**

- ✔ Rubén sends on the 15th and his brother on the 30th.
- Both send on the same day so it's more money.
- Only whoever earned more that month sends money.

## M2 U08. Does "no fee" always mean more money arrives?

**Case 1. Rubén's promotion.** Rubén is offered "first transfer with no fee and a better exchange rate." The second month, the same app delivers fewer pesos than his previous option. **What does he do?**

- ✔ Compare three quotes from the same day and base.
- Stay with the app because it already had a promotion.
- Always choose the one that charges no fee.

**Case 2. Alex's cash.** Alex always pays for transfers in cash at the store. **How much does Alex save by paying from an account?**

- ✔ About 3 dollars in tax, and maybe the fee.
- Nothing: paying in cash or from an account costs the same.
- The whole transfer, because it costs nothing from an account.

**Case 3. Daniela's dollar.** Daniela sends money to El Salvador, which uses the dollar. **Is there an exchange rate?**

- ✔ No, but there are fees and charges to receive.
- Yes, the same as when sending to Mexico.
- No, and that's why sending costs nothing at all.

## M2 U09. What do I check before sending, and what do I do if something goes wrong?

**Case 1. The money that doesn't arrive.** Alex's receipt says the money would be available on Monday. On Tuesday it isn't there. **What does Alex do?**

- ✔ Check the status with the number and call the company.
- Wait three months for the money to show up on its own.
- Send the money again so the family can pick it up.

**Case 2. The money transmitter at the market.** A shop offers Rubén an excellent exchange rate. Rubén looks up the name in the DFPI directory and it isn't there. **What does he decide?**

- ✔ Not use it: without a license he'd have nowhere to complain.
- Use it, because its exchange rate is the best.
- Try it with a big transfer to see if it delivers.

**Case 3. The sister's name.** Daniela wrote her sister's last name with a different letter. Her sister couldn't pick up the money. **What does she do?**

- ✔ She calls with the number and asks to fix the name.
- She sends again and counts the first one as lost.
- She asks her sister to change her ID.

## M2 U10. What happens when I borrow to send money?

**Case 1. The emergency of Alex's mom.** Alex has 180 left over and needs to send 300. A loan would cover the missing 120, with an 18 fee, to be paid in 14 days: 138. On that date Alex will only have 100 left over. **What's the problem?**

- ✔ Alex will be 38 short to pay the loan.
- None: the loan solves the emergency.
- Alex will have 38 left after paying the loan.

**Case 2. Mar's advance.** Mar uses an app that advances her pay for a "voluntary tip" of 5 each time. She does it every week. **How much does it cost her?**

- ✔ 20 a month to get her own money early.
- Nothing, because the tip is voluntary.
- 5 dollars a year, only once.

**Case 3. Rubén's card.** Rubén paid for a transfer with his credit card. **What should he check?**

- ✔ Whether it was charged as a cash advance, with interest.
- Nothing: paying by credit card is the same as debit.
- Only whether he earned reward points for the payment.

## M2 U11. How do I say how much I can help without promising too much?

**Case 1. The fake accident.** A message arrives from a new number: "It's your nephew, I had an accident, don't call anyone, send 500." **What does Mar do?**

- ✔ She calls her sister at the usual number.
- She sends the money quickly in case it's true.
- She answers the message to ask for more details.

**Case 2. Alex's agreement.** Alex and Alex's mom agree: food, between 150 and 180 dollars, on the 15th. Emergencies, verified by calling the aunt. Review every three months or if Alex's hours change. **What do they add after this lesson?**

- ✔ A family code word.
- Alex's mom's account number.
- Nothing more: the agreement is complete.

**Case 3. Rubén's code word.** Rubén gets a call with a voice just like his mom's, asking him for money for a doctor. **What does he do?**

- ✔ He asks for the code word and calls his mom.
- He sends the money, because it's his mom's voice.
- He gives his card details to pay the doctor.

## M2 U12. How do I save for something that will be paid in pesos?

**Case 1. The room for Alex's mom.** The room costs 34,000 pesos: 2,000 dollars at 17, or 2,125 at 16. **What amount does Alex plan with?**

- ✔ With 2,125, the least favorable scenario.
- With 2,000, the most favorable scenario.
- With whatever is left each month, no fixed goal.

**Case 2. The land in the brother's name.** Mar sent money for three years for land that's in her brother's name. Now she wants her share. **What problem does she have?**

- ✔ Without a document recognizing her share, it's hard to prove.
- None: her transfer receipts prove she owns part of it.
- None: the land already belongs to both because they're family.

**Case 3. Rubén's parents' house.** Rubén wants to help fix his parents' house in Oaxaca. **What does he ask first?**

- ✔ Whose name the house is in and who else will chip in.
- How much cement and labor cost in Oaxaca right now.
- Nothing: since it's his parents' house, no need to ask.

## M2 U13. How do I bring my account and my remittances into one plan?

**Case 1. Alex's path.** Payroll check, cashing at a store, paying for the remittance in cash. **What changes?**

- ✔ Direct deposit, a no-fee account and sending from the account.
- Keep using checks and cash, because Alex knows the store.
- Switch stores to pay a lower fee for cashing the check.

**Case 2. The promotion that ended.** Rubén's provider was the best with the introductory promotion, but now delivers less than another one with the same budget. **What does he do?**

- ✔ He switches providers and checks his mom's information.
- He stays out of habit, because he knows the app.
- He stops sending until the promotion comes back.

**Case 3. Daniela's plan.** Daniela is paid by the hour and by order. She sends money to her sister every month. **What does she discover when she draws her path?**

- ✔ That she paid by credit card as a cash advance.
- That she was sending too much money every month.
- That her path couldn't be improved anymore.

## M3 U01. If they lend me money, does that mean I can pay it back?

**Case 1. Andrés's car.** Andrés earns 2,500 net a month. His expenses and commitments add up to 2,250: he has 250 left. The car payment would be 220, plus 90 for insurance. **Can he afford it?**

- ✔ No: he'd be 60 short every month.
- Yes, because the bank approved him.
- Yes, if he stops paying for insurance.

**Case 2. Mar's extra 500.** Mar is approved for 500 more than she asked for. **Should she take it to "make the most of it"?**

- ✔ No: she asks only for what she needs.
- Yes, in case an emergency comes up.
- Yes, and she keeps it as savings.

**Case 3. Rubén's first card.** Rubén got a card offer with a 2,000 limit. He had never had so much "available money." **How should he see it?**

- ✔ As a loan he'd have to pay back.
- As extra money he can spend.
- As a reward from the bank for being a customer.

## M3 U02. How do I know what information is used about my debts?

**Case 1. Someone else's card.** Andrés's report shows a card he never opened and a real late payment on a phone. **What does he do about the card?**

- ✔ He disputes it as fraud and freezes his credit.
- He pays it so it doesn't hurt his score.
- He ignores it, because he didn't open it.

**Case 2. The balance that wasn't updated.** Mar paid off a card, but the report shows a balance of 900. **Is it an error?**

- ✔ Not necessarily: the report is from before the payment.
- Yes, she has to dispute it today with the agency.
- Yes, the bank kept her card payment.

**Case 3. Rubén's first report.** Rubén requested his report by mail using his ITIN. **What did he find?**

- ✔ That he already had a history from his phone plan.
- That he had nothing, because he uses an ITIN.
- That his ITIN doesn't work for having credit.

## M3 U03. How do I start if I have no credit history?

**Case 1. Rubén's secured card.** Rubén deposits 300 in a secured card and buys 40 in gas. **Does the deposit pay those 40?**

- ✔ No: Rubén pays the 40 on his statement.
- Yes: the deposit pays his purchases up to 300.
- Yes, because that's what he deposited the 300 for.

**Case 2. Two offers for Mar.** Offer A costs 36 a year and confirms in the contract that it reports to all three agencies. Offer B costs 120 and doesn't confirm that it reports. **Which is better?**

- ✔ A: it costs less and does report.
- B, because the more expensive one is better.
- Neither: both charge too much.

**Case 3. Daniela's rent.** Daniela pays 1,600 in rent every month, always on time, in a 40-unit building. **What can she ask?**

- ✔ Whether her landlord can report her rent payments.
- Whether she can pay rent with her credit card.
- Whether the owner can lower her rent for paying on time.

## M3 U04. Does improving my credit mean erasing everything?

**Case 1. The 30-day offer.** Mar is offered to have her real late payments erased in 30 days for 499 dollars. **Does she sign up?**

- ✔ No: she disputes only errors and organizes her payments.
- Yes, because 499 is little for clean credit.
- Yes, but she pays only half upfront.

**Case 2. Andrés's utilization.** Andrés has a 600 balance on a 1,000 limit: 60%. He pays 300 and drops to 30%. **How many points will he gain?**

- ✔ He doesn't know, but his debt went down.
- Exactly 100 points this month.
- None, because he still owes money.

**Case 3. Rubén's "new identity".** Rubén is offered a "new number" to start a clean history. **What is it?**

- ✔ A scam and a crime.
- A legal and safe option.
- A government program.

## M3 U05. Why can a small payment end up costing more?

**Case 1. Andrés's two loans.** A: he receives 1,000, pays 50 upfront and 12 payments of 95. B: he receives 1,000, no fee, 12 payments of 98. **How much does each one cost?**

- ✔ A: 1,190. B: 1,176.
- A: 1,140. B: 1,176.
- They cost the same: 1,176.

**Case 2. Daniela's oven.** The oven costs 900 in cash. The store offers payments of 70 a month for 24 months. **How much would she pay in total?**

- ✔ 1,680: 780 more than in cash.
- 900: the same as in cash.
- 1,200: only 300 more than in cash.

**Case 3. Rubén's plans.** Rubén has four "pay in 4" plans of 35 every two weeks. **How much does it add up to every two weeks?**

- ✔ 140, all together.
- 35, one at a time.
- 70, two plans.

## M3 U06. Which debt do I start with?

**Case 1. Mar's debts.** Debt A: 300 at 30%, minimum 30. Debt B: 1,000 at 15%, minimum 50. She has 120 for debts. **How much is left after the minimums?**

- ✔ 40.
- 120.
- 80.

**Case 2. Andrés's consolidation.** He's offered a lower payment, from 250 to 170, but from 12 to 24 payments. **How much does each option cost?**

- ✔ 3,000 versus 4,080.
- They cost the same.
- The 170 one costs less.

**Case 3. Daniela's list.** Daniela made her list and found a 380 medical bill she had forgotten. **What does she do first?**

- ✔ Ask whether she qualifies for financial assistance.
- Pay it today with her credit card.
- Ignore it, because she had forgotten it.

## M3 U07. What do I do if I know I won't be able to pay?

**Case 1. Andrés's temporary agreement.** Andrés can pay 80 a month for three months, instead of 150. **What does he ask the bank?**

- ✔ If there's a temporary option, its cost and how it's put in writing.
- Nothing: he stops paying and waits for the bank to call.
- Whether they'll lend him more money to pay what he owes.

**Case 2. The lawsuit.** Mar is disputing a debt with a credit agency and gets a court notice. **Does she wait for the dispute to finish?**

- ✔ No: she checks the court deadline and gets help.
- Yes, the dispute stops any lawsuit.
- She ignores it, because the debt is in dispute.

**Case 3. Rubén's old debt.** A collector calls Rubén about a phone debt from five years ago, from when he lived in another state. **What does he do?**

- ✔ He asks for the information in writing and verifies it.
- He promises to pay by phone so they stop calling.
- He gives his account number to settle it quickly.

## M3 U08. Can signing to help someone leave me with a debt?

**Case 1. Mar's cousin.** Mar cosigns a car loan of 180 a month because "my cousin will pay it." Four months later, he loses his job. **What happens now?**

- ✔ The lender collects from Mar and it hurts her report.
- Nothing, because the loan is her cousin's, not hers.
- The bank forgives the debt because he lost his job.

**Case 2. The password.** A relative asks Alex for the bank password to "manage" a debt. **What does Alex suggest?**

- ✔ Review it together on Alex's phone, without the password.
- Give the password, because it's family.
- Refuse to help and never talk about it again.

**Case 3. The loan to her sister.** Daniela lends her sister 500. They agree by message that her sister will pay 100 a month for 5 months. In the third month, her sister can only pay 50. **Why doesn't Daniela fall behind on her rent?**

- ✔ Because she only lent what she could give away.
- Because her sister paid it all back.
- Because she took out a loan to cover herself.

## M3 U09. Does a tanda help me build credit?

**Case 1. Mar's tanda.** Mar is in a tanda of 10 people, 100 a week, and she has turn 8. In week 5 she needs money for an emergency. **Can she move up her turn?**

- ✔ No, unless someone agrees to swap.
- Yes, as long as she gives a week's notice.
- Yes, if she pays a penalty to the organizer.

**Case 2. Rubén's circle.** Rubén joins an organized lending circle, with his ITIN. **What happens a few months later?**

- ✔ His payments show up on his credit report.
- Nothing, because circles never report.
- He's charged high interest for being new.

**Case 3. Daniela's tanda.** In Daniela's tanda, one member stopped paying after receiving. **What did they learn?**

- ✔ To write everything down and give first turns carefully.
- To never join a tanda again.
- To charge interest to whoever receives first.

## M3 U10. What's my next step with credit?

**Case 1. Mar's balance.** Starting balance 1,000; interest 20; new purchases 100; payment 150. **What is the ending balance?**

- ✔ 970.
- 1,000.
- 1,270.

**Case 2. Andrés's error.** Andrés disputes the card he didn't open and freezes his credit. **How does he know he made progress?**

- ✔ He has the confirmation number and the freeze confirmation.
- His score went up 100 points in a week.
- He can't know until two years have passed.

**Case 3. Daniela's collection account.** Daniela has a medical bill in collections. **What is her first step?**

- ✔ Ask for validation in writing and for financial assistance.
- Pay it all today, even if she doesn't know whether it's hers.
- Change her number so they stop calling her.

## M3 U11. Is a paycheck advance money at no cost?

**Case 1. Rubén's app.** The app charges Rubén 12 dollars to advance 200 every two weeks. **How much does he pay a year?**

- ✔ He asks if his employer advances pay at no cost and builds his fund.
- He keeps using the app because 12 dollars seems like very little money.
- He asks for the biggest advance the app will allow.

**Case 2. Alex's payday loan.** Alex is offered a 400-dollar payday loan. **What does he do?**

- ✔ He looks elsewhere: payday loans roll over and fees grow.
- He takes it because he'll repay it all on his next check.
- He takes it and gets another one later to pay the first.

**Case 3. Daniela's overdraft.** Daniela's app collected when she had no balance. **What does she do?**

- ✔ She changes the collection date and stops using it.
- She keeps it as is and pays the overdraft each time.
- She opens another account just so the app collects there.

## M3 U12. Is pawning a good way out?

**Case 1. Mar's chain.** Mar needs 300 for the car. **What does she do first?**

- ✔ She asks the shop about a payment plan.
- She pawns the chain right away because it's faster than asking.
- She takes a payday loan so she doesn't touch her chain.

**Case 2. Andrés's tools.** Andrés wants to pawn the tools he uses for weekend jobs. **What does he do?**

- ✔ He doesn't pawn what he uses for work.
- He pawns them and borrows other tools for the weekend.
- He pawns them because he'll surely get them back in two weeks.

**Case 3. Rubén's ticket.** Rubén pawned his watch and lost the ticket. **What does he do?**

- ✔ He goes to the shop with his ID and asks for a copy.
- He gives the watch up for lost and does nothing else.
- He buys another watch so he doesn't have to deal with it.

## M4 U01. Why is someone pushing me to act right now?

**Case 1. The job with a check.** An "employer" sends Alex a check to buy equipment and asks Alex to transfer part of it to a "supplier." **What does Alex do?**

- ✔ Verify the company and check with the bank first.
- Transfer quickly so the job isn't lost.
- Deposit the check and keep a share.

**Case 2. The message from the bank.** Rosa gets: "Your account will be closed in 20 minutes, send the code." **What does she do?**

- ✔ She doesn't give the code and calls the number on her card.
- She sends the code so she doesn't lose her account.
- She answers the message to ask for more time.

**Case 3. Daniela's rental.** Daniela found a cheap apartment on social media. The "owner" asked her for the deposit by Zelle before she saw it, because he "was out of town." **What should she do?**

- ✔ Not pay without seeing the place or verifying the owner.
- Pay quickly to hold the apartment.
- Pay only half and the rest on arrival.

## M4 U02. Who can really help me with an immigration case?

**Case 1. Mar's neighbor.** A "Notaria – Inmigración" office promises Mar's neighbor "papers in 6 months" for 5,000 dollars. **What does Mar do?**

- ✔ She takes her to accredited representatives, who advise at no cost.
- She advises paying quickly to secure a spot in line.
- She lends money so it can be paid to the office in installments.

**Case 2. The call from "ICE".** Alex gets a call: a cousin is detained and must pay 2,000 in gift cards to be released. **What does Alex do?**

- ✔ Hangs up and calls the cousin and the family.
- Buys the gift cards to help.
- Gives personal information so they can verify.

**Case 3. The fast permit.** A social media "advisor" offers Daniela a work permit in three months "with an asylum application." **What's the risk?**

- ✔ A false application is a crime and can lead to deportation.
- None: it's a quick process lots of people use.
- Only losing the fee if the permit isn't approved.

## M4 U03. What protects my accounts besides a password?

**Case 1. The same password.** Alex used the same password for email and bank. The one from an online store leaked and someone got into Alex's email. **Is changing the bank password enough?**

- ✔ No: change both and turn on two-step.
- Yes: changing the bank one is enough.
- Only change the online store one.

**Case 2. Tech support.** A pop-up on Mar's computer says "virus detected, call this number." They ask her to install an app. **What does she do?**

- ✔ She closes the browser and doesn't call.
- She calls and installs the app they ask for.
- She pays for support to remove the virus.

**Case 3. Rosa's phone.** Rosa shares her phone with her grandchildren. **What changes?**

- ✔ She puts a PIN on her bank app.
- She gives the password to her grandchildren.
- She stops using her phone.

## M4 U04. What do I do if I already shared information or see something strange?

**Case 1. The unknown account.** Alex's report shows a loan Alex never asked for. **What does Alex do?**

- ✔ Document it and follow the IdentityTheft.gov guide.
- Pay the loan so it doesn't hurt the credit.
- Wait to see if it disappears from the report.

**Case 2. The shared code.** Mar gave a code over the phone. Ten minutes later she realizes it. **What does she do?**

- ✔ She calls the bank, locks it and changes her password.
- She waits until tomorrow to see if anything odd happens.
- She calls the number that asked for the code.

**Case 3. Rosa's lost card.** Rosa lost her wallet at the market. **What does she do first?**

- ✔ She locks her card and calls the bank.
- She waits to see if someone turns it in.
- She asks for a new card next month.

## M4 U05. Is talking about money the same as controlling someone?

**Case 1. The loan she can't read.** Made-up case: a person pressures their partner to sign a loan she can't read and asks for her passwords. **What signs are there?**

- ✔ Lack of information, pressure and risk of debt.
- None: it's normal for a partner to decide that.
- Just a normal disagreement about spending.

**Case 2. Alex and Mar's agreement.** Alex and Mar go over their budget together every Sunday. Each one has 50 dollars a week for whatever they want, with no explanations. **Is it control?**

- ✔ No: it's a healthy agreement with independence for both.
- Yes, because they review every household expense together.
- Yes, because each one has a weekly limit.

**Case 3. Rosa's pension.** Made-up case: an older person gives her card to a nephew so he can do her shopping. He starts using it for his own expenses. **What is it?**

- ✔ Financial abuse.
- Family help.
- A loan.

## M4 U06. What is setting aside a little money for?

**Case 1. Alex and Mar's savings.** They have 900 and basic expenses of 1,800. **How long does it cover them?**

- ✔ Half a month.
- Two months.
- One month.

**Case 2. The car registration.** Mar thought the car registration, 600 a year, was an emergency. **What was it?**

- ✔ A planned expense: 50 a month covers it.
- An emergency nobody could predict.
- An expense worth avoiding by paying late.

**Case 3. Daniela's refrigerator.** Daniela paid for the refrigerator with her card and still owes 400. **What does she do now?**

- ✔ She pays the card and sets aside 10 a week.
- She doesn't save until the card is paid off.
- She gets another card to have more room.

## M4 U07. Does having insurance mean I won't pay anything?

**Case 1. Alex's cheap policy.** A policy costs 20 less a month, but excludes using the car for work. Alex does jobs with the pickup truck on weekends. **Does it work for Alex?**

- ✔ No: if there's a crash while working, it won't pay.
- Yes, because it costs less each month.
- Yes, if Alex always drives carefully.

**Case 2. The theft in the apartment.** Mar's TV is stolen. **Does the building's insurance cover it?**

- ✔ No: the building's insurance doesn't cover her things.
- Yes: the owner's insurance covers the whole building.
- Yes, if the theft happened at night or on a weekend.

**Case 3. Rosa's health plan.** Rosa compares two plans: one with a low premium and a 3,000 deductible; another with a higher premium and a 500 deductible. **Which is better?**

- ✔ The low deductible, because she goes to the doctor often.
- The low premium, because it always comes out cheaper.
- Either one, because in the end they cost the same.

## M4 U08. Is this medical document asking me to pay?

**Case 1. The 300 bill.** Mar's explanation of benefits says she owes 150, but the bill asks for 300 for the same service. **What does she do?**

- ✔ She asks for an explanation before paying.
- She pays the 300 the bill says.
- She pays 150 and doesn't tell anyone.

**Case 2. Alex's hospital stay.** Alex gets a 4,000 bill. **What does Alex do?**

- ✔ Ask about the hospital's financial assistance.
- Pay by credit card so as not to owe the hospital.
- Ignore the bill until it goes to collections.

**Case 3. Rosa's three papers.** Rosa received an EOB from the insurance, a bill from the hospital and another from the emergency room doctor. **What does she find out?**

- ✔ The out-of-network rate shouldn't be charged to her.
- She has to pay all three bills in full.
- She pays only the hospital's and throws out the rest.

## M4 U09. How do I pay for the essentials if I can't work for a few days?

**Case 1. Two weeks without working.** Alex gets hurt outside of work. Alex loses 900 in income; a temporary move costs 200, but saves 50 in transportation. **How much is Alex short?**

- ✔ 650.
- 900.
- 400.

**Case 2. The phone lost in the evacuation.** All the family's information was on Mar's phone, which was lost in the evacuation. **What would have helped?**

- ✔ A secure copy of documents and contacts on paper.
- A more expensive, tougher phone for next time.
- Nothing: you can't prepare anything for an evacuation.

**Case 3. Rosa's contractor.** After the fire, a man offers to fix Rosa's roof if she pays everything upfront. **What does she do?**

- ✔ She checks his license and pays as work progresses, with a contract.
- She pays everything upfront so he starts right away.
- She pays him in cash with no receipt to save money.

## M4 U10. What happens to my family and my money if I can't be there?

**Case 1. Alex and Mar's plan.** They choose Mar's sister as caregiver and a neighbor as backup. **What do they prepare?**

- ✔ The caregiver affidavit, a folder and the month's payments.
- Nothing in writing: Mar's sister already knows what to do.
- Only a will, because that covers everything else.

**Case 2. The password isn't enough.** A family thought sharing the bank password was enough. When the account holder was hospitalized, the bank didn't let anyone else handle anything. **What did they need?**

- ✔ A formal authorization, like a power of attorney.
- Also sharing the email password.
- A handwritten letter, even if it isn't signed.

**Case 3. Daniela's plan.** Daniela is a single mom and her family is in El Salvador. **Who does she choose?**

- ✔ A friend as caregiver and her cousin as backup.
- Nobody, because her family is in El Salvador.
- A neighbor she barely knows, because he lives closer.

## M4 U11. How do I know if my protection plan works?

**Case 1. Alex's risk.** Risk: losing hours because of an accident. Protections: some coverage through work and 300 in savings. Gap: basic expenses are 1,800 a month. **What does Alex do?**

- ✔ Check the coverage and slowly increase the savings.
- Assume the 300 in savings solves the risk.
- Buy every insurance offered that month.

**Case 2. Daniela's drill.** Daniela practices: "I'm in the hospital for a week." **What does she find out?**

- ✔ That her friend had no key and didn't know about the folder.
- That everything was perfect and nothing needed to change.
- That practicing is useless if nothing really happens.

**Case 3. Mar's fake emergency.** In her drill, Mar gets a fake call from a relative right when her hours were cut. **Which parts of the plan does she use?**

- ✔ Code word, calendar, savings and remittance agreement.
- Only her savings, because it's a money emergency.
- Nothing: she sends the money because it's a relative.

## M4 U12. How do I make sure child support reaches my kids?

**Case 1. "When I can".** The father of Daniela's son pays only when he can, in cash. **What does Daniela do?**

- ✔ She calls her county's child support agency.
- She keeps waiting because she thinks her status keeps her from asking.
- She borrows money from a friend every month instead.

**Case 2. Andrés's payments.** Andrés pays child support for a daughter from a previous relationship, in cash and without a receipt. **What does he do?**

- ✔ He pays through the agency or with proof.
- He keeps paying cash because that's what they agreed years ago.
- He pays cash, but every three months to pay more at once.

**Case 3. Rosa's grandson.** The father of Rosa's grandson lives in Mexico and doesn't pay. **What does Rosa's daughter do?**

- ✔ She asks her agency and consulate about agreements with Mexico.
- She gives up on it because he lives in another country.
- She asks a gestor to collect on his own in Mexico.

## M5 U01. How do I turn a wish into a goal?

**Case 1. Daniela's course.** Daniela wants a 600 baking course in 12 months, with no debt. She already has 180 set aside just for that. **How much does she set aside each month?**

- ✔ 35 a month.
- 50 a month.
- 15 a month.

**Case 2. Andrés's net worth.** Andrés has a net worth of 2,500, but if a 2,300 bill arrives tomorrow, he can't use his car to pay it. **What does he still need to check?**

- ✔ His liquidity: what he can use right away.
- Nothing: his 2,500 net worth is enough.
- Sell his car today to have cash just in case.

**Case 3. Rubén's goals.** Rubén has three goals that add up to 275 a month and only 150 left over. **What does he do?**

- ✔ He prioritizes two goals and puts off the third.
- He assigns the same 150 to all three goals.
- He takes a personal loan to cover all three at once.

## M5 U02. Does having more money mean my investment made money?

**Case 1. Rosa's trip.** Rosa needs 1,000 in three months. **Does she invest in something that can go up or down?**

- ✔ No: if it drops, she won't have enough for the trip.
- Yes, because it could go up 15% in three months.
- Yes, but she invests only half of the money.

**Case 2. Andrés's balance.** Andrés's retirement account went from 2,000 to 2,300, but he put in 250. **How much did the investment earn?**

- ✔ 50.
- 300.
- 250.

**Case 3. Rubén's "average".** A friend tells Rubén that his investment "averaged 0%": it went up 20% and down 20%. **Did it stay the same?**

- ✔ No: it went from 1,000 to 960.
- Yes: it ended at exactly 1,000.
- No: it gained 4% over the two years.

## M5 U03. Does opening an account mean I already invested?

**Case 1. The IRA in cash.** Andrés opened an IRA a year ago and his money is still in cash because he never chose any investments. **What does he do?**

- ✔ He asks about his options and chooses by time frame and risk.
- Nothing: the IRA invests itself in the best option.
- He closes the account because it didn't earn anything.

**Case 2. Rubén's two funds.** Rubén bought two "technology" funds that hold almost the same companies. **Did he diversify?**

- ✔ No: he doubled his risk in the same sector.
- Yes: having two funds is already diversifying.
- Yes, because technology companies always go up in price.

**Case 3. The social media adviser.** Daniela gets an offer of 20% a month in cryptocurrency. **What does she do?**

- ✔ She looks up the adviser on BrokerCheck and doesn't invest.
- She invests a little to test whether it's true.
- She invites her friends to earn a commission per person.

## M5 U04. Rent or buy? What rights do I have as a tenant?

**Case 1. Andrés's rent increase.** The landlord announces a 15% increase. **What does Andrés do?**

- ✔ He checks whether the cap applies and answers in writing.
- He pays the 15% because the landlord can charge anything.
- He stops paying rent until the landlord backs down.

**Case 2. Andrés's dream.** Andrés wants to buy a house. A housing counselor helps him calculate the down payment, closing costs, taxes and insurance. **What does he find out?**

- ✔ That he needs more savings and to check his credit.
- That he can buy tomorrow with what he already has.
- That he can never buy a house because he files with an ITIN.

**Case 3. Daniela's deposit.** Daniela moved out and the landlord didn't return her deposit. **What can she do?**

- ✔ Ask in writing for the deposit or the list of deductions.
- Forget the deposit, because the landlord always wins.
- Stop paying her new rent to make up for it.

## M5 U05. Is the advertised price all it costs?

**Case 1. Rubén's two cars.** Car A: total 650. Car B: total 600. **What does he still need to check?**

- ✔ Total price, term, down payment, condition and value.
- Nothing else: B is cheaper and he already decided.
- Only the color, the model and the accessories he likes most.

**Case 2. Daniela's course.** Tuition 1,200, materials 300 and lost earnings 500. **How much does it cost?**

- ✔ 2,000.
- 1,200.
- 1,500.

**Case 3. Andrés's offer.** A dealership offers to lower Andrés's car payment by stretching the loan from 48 to 84 months. **Is it good for him?**

- ✔ Probably not: he'd pay more interest.
- Yes: paying less each month is always better.
- Yes, especially if the car is new and has a long warranty.

## M5 U06. What will I live on when I work less or stop working?

**Case 1. Andrés's job change.** Andrés leaves his job and is offered to cash out his 401(k). **What does he do first?**

- ✔ He asks about transferring it and about taxes and penalties.
- He cashes it out to use on whatever he needs.
- He leaves it where it is without checking what happens to it.

**Case 2. Daniela's CalSavers.** Daniela's employer has no retirement plan and enrolls her in CalSavers. **What does she check?**

- ✔ How much is deducted and how to change it.
- Nothing, because it's mandatory and can't change.
- She opts out right away without reading anything.

**Case 3. Rosa's retirement.** Rosa worked in Mexico with IMSS and here she's paid in cash. **What sources does she need to check?**

- ✔ Her AFORE, her savings and whether she worked with an SSN.
- Only U.S. Social Security.
- Nothing, because without an SSN no kind of retirement exists.

## M5 U07. What happens to what I saved in Mexico?

**Case 1. Rosa finds her AFORE.** Rosa doesn't know which AFORE she's in. **What does she do?**

- ✔ She uses e-SAR or AforeMóvil with her CURP.
- She pays a middleman to look for it.
- She travels to Mexico to ask in person.

**Case 2. Rubén's middleman.** A middleman offers Rubén to "release his AFORE" for 30% of the balance. **What does Rubén do?**

- ✔ He doesn't accept: the procedures cost nothing.
- He accepts, because it's faster and easier.
- He negotiates the fee down to 15% of the balance.

**Case 3. Weeks or savings.** Rosa wants to increase her savings and also complete weeks for her pension. **Are voluntary contributions enough?**

- ✔ No: to add weeks she must ask IMSS.
- Yes: every contribution adds contribution weeks.
- No, and she can't do anything from the U.S.

## M5 U08. What happens to my family if something happens to me?

**Case 1. Rubén's plan.** Rubén wants his sister to take care of his children if he can't. **What document does he use?**

- ✔ California's Caregiver's Authorization Affidavit.
- A will made before a notary public.
- A handwritten letter, even if it isn't signed.

**Case 2. Daniela's insurance.** Daniela made a will, but her life insurance still lists her ex-partner as beneficiary. **Who receives the insurance?**

- ✔ Probably the ex-partner: she must update it.
- Her children, because her will says so.
- The state, because two documents say different things.

**Case 3. Andrés's power of attorney.** An acquaintance offers to "handle everything" for Andrés with a power of attorney. **What does he do?**

- ✔ He gives it only to someone he fully trusts.
- He signs it so he doesn't have to worry about anything.
- He signs it if the acquaintance charges little for the favor.

## M5 U09. How do I plan when my income changes every month?

**Case 1. Andrés's rains.** Andrés earns little in December and January. **What does he do starting in June?**

- ✔ He sets aside part of the extra from each good month.
- He spends the extra and borrows in December.
- He looks for another job just for the rainy months.

**Case 2. Mar's tips.** Mar gets most of her tips in cash and doesn't know how much she earns a month. **What does she do first?**

- ✔ She writes down every day what she receives.
- She guesses how much she earns.
- She asks her coworkers how much they earn a month.

**Case 3. Daniela's big order.** Daniela got a big cake order and earned 1,500 extra in one week. **Does she spend it all?**

- ✔ No: she sets aside for taxes, reserve and ingredients.
- Yes, because she earned it with her work that week.
- She lends it to a friend so it earns more.

## M5 U10. How do I formalize my business?

**Case 1. Daniela's profits.** Daniela sold 1,200 and spent 600 in total. **How much did she make?**

- ✔ 600.
- 1,200.
- 1,800.

**Case 2. An LLC already?.** Rubén is starting to sell food to order some weekends and makes 150 a month. **Does an LLC make sense for him?**

- ✔ Probably not: he starts as a sole proprietorship.
- Yes: every business should be an LLC from day one.
- Yes, because an LLC pays no tax while it's small.

**Case 3. Andrés's loan.** Andrés is offered a business "advance" that's collected from his daily sales. **What does he check?**

- ✔ The total cost and yearly rate, and he compares with a CDFI.
- Nothing: if the money arrives fast, it's worth accepting.
- Only the amount they lend him, not what they charge.

## M5 U11. What's my financial plan?

**Case 1. Rubén's plan.** Rubén has three goals but doesn't know where to start. **What does he do?**

- ✔ He chooses one small action with a date.
- He waits until everything is clear first.
- He works on all three goals at the same time.

**Case 2. Andrés's change.** Andrés changed jobs. **What does he review in his plan?**

- ✔ Income, base budget, retirement and beneficiaries.
- Nothing: his plan stays the same even if he changes jobs.
- Only his new address and phone number.

**Case 3. Daniela's reserve.** Daniela had to use her reserve for an emergency. **Did her plan fail?**

- ✔ No: the reserve did its job; now she rebuilds it.
- Yes: she must start a new plan from scratch.
- Yes: if she had to use it, saving no longer makes sense.

## M5 U12. What happens if I inherit or leave something across two countries?

**Case 1. Alex's 40%.** Alex is told the IRS will charge him 40% for inheriting his mom's house. **What does he learn?**

- ✔ That he pays no federal tax; he only reports it on Form 3520.
- That it's better not to tell the IRS anything since the house is in Mexico.
- That it's better to sell the house quickly before he inherits it.

**Case 2. Rosa's account.** Rosa wants her Fresno account to go to her grandchildren without court. **What does she do?**

- ✔ She names them as POD beneficiaries and her daughter as guardian.
- She leaves the account as is because her grandchildren will get it anyway.
- She withdraws everything in cash and keeps it at home for them.

**Case 3. Daniela's gestor.** A "gestor" offers to "fix" Daniela's aunt's inheritance in El Salvador for 3,000 dollars. **What does she do?**

- ✔ She asks her consulate and looks for a registered notary.
- She pays the gestor so she doesn't have to travel or do anything.
- She sends the gestor her documents over WhatsApp to get started.

# Part 9. Question bank

The option marked ✔ is correct; the feedback is below it.

## Module 1

**M1 U01 P1.** Someone lends you 300 dollars. How does your net worth change?

- It goes up 300
- ✔ It doesn't change
- It goes down 300

*Correct! You have 300 more, but you owe 300.*

**M1 U01 P2.** You move 100 dollars from your savings account to your checking account. Is it income?

- ✔ No
- Yes
- Yes, if it moves between two accounts at the same bank

*Correct! It only changed places.*

**M1 U01 P3.** You pay 20 in interest on your credit card. What happens to your net worth?

- It goes up
- It doesn't change
- ✔ It goes down

*Correct! You paid a cost and didn't reduce the debt.*

**M1 U02 P1.** What is 7% of 600?

- 4.2
- ✔ 42
- 420

*Correct! 600 × 0.07.*

**M1 U02 P2.** A rate goes up from 2% to 3%. How many percentage points did it go up?

- ✔ 1
- 50
- 3

*Correct! The relative increase is 50%, but it's 1 percentage point.*

**M1 U02 P3.** Inflation went down from 6% to 4%. Did prices go down?

- Yes
- Yes, they went down 2% from last year
- ✔ No, they're going up more slowly

*Correct! They're going up more slowly.*

**M1 U03 P1.** What is opportunity cost?

- The price of what you buy
- ✔ What you give up when you choose
- A bank fee

*Correct! It's what you give up.*

**M1 U03 P2.** What should you do when everything seems urgent?

- ✔ Ask for the real date, the consequence of waiting and the alternatives
- Pay whatever pushes hardest
- Wait for everything to sort itself out

*Correct! With those facts you can compare.*

**M1 U03 P3.** A long contract deserves:

- The same review as a daily purchase
- Less review, because it's already written
- ✔ More review

*Correct! It commits you for longer.*

**M1 U04 P1.** How many paychecks a year are there "every two weeks"?

- 24
- ✔ 26
- 52

*Correct! 26 paychecks.*

**M1 U04 P2.** You earn 100 a day and worked 18 days. How much did you receive?

- ✔ 1,800
- 3,000
- 2,400

*Correct! Only the days worked count.*

**M1 U04 P3.** Is it wise to take on a fixed commitment based on your best month?

- Yes
- Yes, if it's a three-paycheck month
- ✔ No

*Correct! It must fit in your lowest month.*

**M1 U05 P1.** Which money can you use?

- Gross
- ✔ Net
- The amount in your contract

*Correct! It's what's deposited.*

**M1 U05 P2.** Are all deductions taxes?

- ✔ No
- Yes
- Yes, except health insurance

*Correct! There are also insurance, retirement and others.*

**M1 U05 P3.** If you're called a "contractor," does that decide your legal classification?

- Yes
- Yes, if it's in writing
- ✔ Not necessarily

*Correct! The law uses its own tests.*

**M1 U06 P1.** A 4-dollar expense, 20 times a month: how much does it add up to in a year?

- 80
- ✔ 960
- 480

*Correct! 80 a month for 12 months.*

**M1 U06 P2.** Does canceling your card automatically cancel a subscription?

- ✔ Not necessarily
- Yes
- Yes, if the card already expired

*Correct! You have to cancel with the company.*

**M1 U06 P3.** Insurance of 600 every 6 months: how much should you set aside each month?

- 50
- 600
- ✔ 100

*Correct! 600 ÷ 6.*

**M1 U07 P1.** What is the formula for the ending balance?

- Money in − money out
- ✔ Starting + money in − money out
- Money in + money out − starting balance

*Correct! The previous week's balance counts.*

**M1 U07 P2.** If the month ends positive, can there be a negative week?

- ✔ Yes
- No
- Only if the month has five weeks

*Correct! The problem can be the dates.*

**M1 U07 P3.** Is a date change you asked for already approved?

- Yes
- Yes, if you asked by phone
- ✔ No, not until they confirm it

*Correct! Wait for the confirmation.*

**M1 U08 P1.** Does a budget require money to be left over?

- Yes
- ✔ No
- Yes, at least 10%

*Correct! It should show if you're short.*

**M1 U08 P2.** A 240 payment is due in 6 months and you haven't set anything aside. How much should you set aside each month?

- ✔ 40
- 20
- 240

*Correct! 240 ÷ 6.*

**M1 U08 P3.** Does a zero-based budget mean spending everything?

- Yes
- It means not spending anything that isn't essential
- ✔ No, it means giving every dollar a job

*Correct! Every dollar has a job, including savings.*

**M1 U09 P1.** Does filing your return guarantee a refund?

- Yes
- ✔ No
- Yes, if you have children

*Correct! Only if you paid too much.*

**M1 U09 P2.** Does the ITIN authorize you to work?

- ✔ No
- Yes
- Yes, if you renew it every year

*Correct! It's only for taxes.*

**M1 U09 P3.** Does an extension to file extend the deadline to pay?

- Usually yes
- Yes, always for six months
- ✔ Usually no

*Correct! Payment is still due on the original date.*

**M1 U10 P1.** Can app income have to be reported even if you get no form?

- Never
- ✔ It can
- Only if it's over 600

*Correct! The IRS says it can be.*

**M1 U10 P2.** Is moving 500 from the business account to your personal account new income?

- ✔ No
- Yes
- Yes, if it's more than 400

*Correct! It only changed places.*

**M1 U10 P3.** Should you set aside "10%" for taxes because a friend does?

- Yes
- Yes, and 5% if you're paid in cash
- ✔ No, you need to calculate your case

*Correct! Every case is different.*

**M1 U11 P1.** Can you use an ITIN to work?

- Yes
- ✔ No
- Yes, in California

*Correct! It's only for taxes.*

**M1 U11 P2.** Can CalEITC be claimed with an ITIN?

- ✔ Yes
- No
- Only if you have an SSN

*Correct! It's a state credit that accepts an ITIN.*

**M1 U11 P3.** What happens if you don't use your ITIN on a federal return for three years in a row?

- Nothing
- It turns into an SSN
- ✔ It expires

*Correct! The IRS deactivates it.*

**M1 U12 P1.** What must every paid preparer have?

- Nothing
- ✔ A PTIN
- A law license

*Correct! The PTIN is required.*

**M1 U12 P2.** In California, a paid preparer who isn't a CPA, EA or attorney must register with:

- ✔ CTEC
- The DMV
- The consulate

*Correct! CTEC is the state registry.*

**M1 U12 P3.** Is it safe to sign a blank tax return?

- Yes
- Yes, if it's a preparer you know
- ✔ No

*Correct! They can put false information on it.*

**M1 U13 P1.** Does the public charge rule apply to all immigration cases?

- Yes
- ✔ No
- Only to citizenship

*Correct! Only certain cases.*

**M1 U13 P2.** Under the current rule, is CalFresh considered for public charge?

- ✔ No
- Yes
- Yes, if the children use it

*Correct! It isn't considered.*

**M1 U13 P3.** Who can give you immigration advice?

- A notario
- An immigration consultant with an office and ads
- ✔ An attorney or a DOJ-accredited representative

*Correct! Only they are authorized.*

**M1 U14 P1.** What does a goal you can check have?

- Only a wish
- ✔ Action, date and evidence
- A wish list for the year

*Correct! That way you can check it.*

**M1 U14 P2.** Can "I need to find out" be an action?

- ✔ Yes, if it has a date
- No
- Only if someone else does it for you

*Correct! Finding out with a date is progress.*

**M1 U14 P3.** If your income drops, do you have to keep saving the same amount?

- Yes
- Yes, and stop paying other things
- ✔ Not necessarily; adjust the plan

*Correct! The plan adapts to your reality.*

## Module 2

**M2 U01 P1.** Can you open an account at the central bank?

- Yes
- Yes, with an ITIN
- ✔ No

*Correct! It doesn't serve individuals.*

**M2 U01 P2.** Who should explain a policy's deductible?

- The central bank
- ✔ The insurer
- The money transmitter

*Correct! The policy is theirs.*

**M2 U01 P3.** A company is registered with a regulator. Does that guarantee its offer is good for you?

- ✔ No
- Yes
- Yes, if it has many customers

*Correct! Registration is not a guarantee.*

**M2 U02 P1.** Does "digital" mean it's a bank?

- Yes
- Yes, if it has a debit card
- ✔ No

*Correct! It describes access, not the license.*

**M2 U02 P2.** Is an investment bought at a bank FDIC-insured?

- Yes
- ✔ No
- Yes, up to 250,000

*Correct! Investments aren't deposits.*

**M2 U02 P3.** Does deposit insurance protect you from a scam?

- ✔ No
- Yes
- Yes, if you report it within 24 hours

*Correct! It only protects you if the bank fails.*

**M2 U03 P1.** Does the AB 60 license work as a REAL ID?

- Yes
- Yes, for flying within the U.S.
- ✔ No

*Correct! It doesn't work for federal purposes.*

**M2 U03 P2.** Is the ITIN a photo ID?

- Yes
- ✔ No
- Yes, if you print it

*Correct! It's only a tax number.*

**M2 U03 P3.** Where do you get a consular ID?

- ✔ At the consulate, with an official appointment
- At any store
- Through a helper who sells appointments

*Correct! Only at the consulate.*

**M2 U04 P1.** Are the opening deposit and the minimum balance the same?

- Yes
- Yes, both are paid every month
- ✔ No

*Correct! One is to open and the other is monthly.*

**M2 U04 P2.** An account costs nothing with direct deposit and you get paid in cash. Can you assume it costs nothing?

- Yes
- ✔ No
- Yes, if you never overdraw

*Correct! It depends on whether you meet the condition.*

**M2 U04 P3.** Does a joint account let the other person withdraw money?

- ✔ Yes
- No
- Only with your written permission each time

*Correct! Any owner can withdraw.*

**M2 U05 P1.** Is a check you already see in your balance guaranteed?

- Yes
- Yes, after 24 hours
- ✔ No

*Correct! It can bounce.*

**M2 U05 P2.** Which is harder to get back?

- An unauthorized charge
- ✔ A payment you authorized because you were tricked
- Both are recovered the same if you report within 60 days

*Correct! You authorized it.*

**M2 U05 P3.** To cancel a subscription, is canceling the card enough?

- ✔ No
- Yes
- Yes, if you report it lost

*Correct! Cancel with the company.*

**M2 U06 P1.** Does planning a remittance mean loving your family less?

- Yes
- Yes, if you send less than before
- ✔ No

*Correct! It's making sure it continues.*

**M2 U06 P2.** In what currency should you define a need that's paid in Mexico?

- Dollars
- ✔ Pesos
- The currency of the country where you live

*Correct! It's the currency it's spent in.*

**M2 U06 P3.** Is it wise to ask for your relative's bank password to help them?

- ✔ No
- Yes
- Yes, if it's your mom

*Correct! It undermines their independence and security.*

**M2 U07 P1.** Is the cost of sending subtracted from your capacity?

- No
- Only if you pay by card
- ✔ Yes

*Correct! It also comes out of your pocket.*

**M2 U07 P2.** If your capacity comes out negative, what do you do?

- Write zero
- ✔ Show the shortfall and look for options
- Borrow to send the usual amount

*Correct! The shortfall is information.*

**M2 U07 P3.** Is it wise to promise a fixed amount if your income varies?

- ✔ Better a range
- Yes
- Yes, that way your family can plan better

*Correct! A range protects you.*

**M2 U08 P1.** Does "no fee" guarantee more money arrives?

- Yes
- Yes, if it's also the first transfer
- ✔ No

*Correct! The exchange rate also counts.*

**M2 U08 P2.** Does the 1% tax apply to all remittances?

- Yes
- ✔ No, to certain remittances paid with cash or physical instruments
- Only to remittances sent by app to another country

*Correct! Only those paid in cash or similar.*

**M2 U08 P3.** To compare, what has to be the same?

- ✔ The base: same budget or same amount to be received
- Nothing
- Only the fee; the exchange rate doesn't matter

*Correct! Otherwise they can't be compared.*

**M2 U09 P1.** Where do you check a money transmitter's license in California?

- In its ad
- In social media reviews
- ✔ DFPI or NMLS

*Correct! They're the official records.*

**M2 U09 P2.** In general, how much time do you have to cancel at no cost?

- 30 days
- ✔ 30 minutes
- 7 days

*Correct! If the money hasn't been picked up.*

**M2 U09 P3.** Does "you have 180 days" mean it's wise to wait?

- ✔ No
- Yes
- Yes, so the company notices on its own

*Correct! Act quickly.*

**M2 U10 P1.** Is borrowed money earned income?

- Yes
- Yes, if it's from a relative
- ✔ No

*Correct! You have to pay it back.*

**M2 U10 P2.** If you "roll over" by paying only the fee, do you reduce what you owe?

- Yes
- ✔ No
- Yes, a little each time

*Correct! You still owe the same.*

**M2 U10 P3.** Is a pay advance through an app a debt?

- ✔ Yes
- No
- No, because it's your own money

*Correct! It comes out of your next paycheck.*

**M2 U11 P1.** Which number do you call to verify an emergency?

- The one in the message
- The one the caller gives you
- ✔ One you already knew

*Correct! The one in the message may belong to the scammer.*

**M2 U11 P2.** Does a voice that sounds just like your relative prove it's real?

- Yes
- ✔ No
- Yes, if it says your name

*Correct! Voices can be cloned today.*

**M2 U11 P3.** How many parts does a good family agreement have?

- ✔ 6
- 2
- 1: the amount

*Correct! Purpose, range, date, emergencies, verification and review.*

**M2 U12 P1.** In what currency do you set a goal that's paid in Mexico?

- Dollars
- Whichever currency is cheaper that day
- ✔ Pesos

*Correct! That's how it's paid.*

**M2 U12 P2.** Does your transfer receipt prove you own a piece of land?

- Yes
- ✔ No
- Yes, if you keep all the receipts

*Correct! It only proves the transfer.*

**M2 U12 P3.** Can one contribution count for two goals at the same time?

- ✔ No
- Yes
- Yes, if they're for the same family

*Correct! Every dollar has one job.*

**M2 U13 P1.** What best shows that you compared?

- Downloading an app
- Asking a friend which one they use
- ✔ A sheet with two offers and a date

*Correct! It's concrete evidence.*

**M2 U13 P2.** Is sending less always better?

- Yes
- ✔ No
- Yes, if the exchange rate goes up

*Correct! It depends on your capacity and the need.*

**M2 U13 P3.** Does a promotion represent the usual cost?

- ✔ No
- Yes
- Yes, if it lasts more than a month

*Correct! Compare the later price.*

## Module 3

**M3 U01 P1.** Does a good score guarantee you can pay?

- ✔ No
- Yes
- Yes, if it's over 700

*Correct! The score doesn't make the payment.*

**M3 U01 P2.** Is an available credit limit your money?

- Yes
- Yes, if you don't use it
- ✔ No

*Correct! It's a loan available to you.*

**M3 U01 P3.** If you have a 200 margin and the payment is 150, what happens if your income drops by 100?

- You're still fine
- ✔ A deficit of 50
- You have 50 left

*Correct! 200 − 100 − 150 = −50.*

**M3 U02 P1.** Does checking your own report lower your score?

- ✔ No
- Yes
- Yes, 5 points each time

*Correct! Checking your own doesn't affect it.*

**M3 U02 P2.** Is a real late payment an error that can be erased?

- Yes
- Yes, if you pay a fee
- ✔ No

*Correct! Correct information isn't erased.*

**M3 U02 P3.** What do you send as proof in a dispute?

- The original
- ✔ A copy
- Nothing; a phone call is enough

*Correct! Keep your originals.*

**M3 U03 P1.** Does a secured card's deposit pay for your purchases?

- ✔ No
- Yes
- Yes, every month

*Correct! You pay your purchases.*

**M3 U03 P2.** Do you need to pay interest to build a history?

- Yes
- Yes, at least a little each month
- ✔ No

*Correct! Pay the full balance.*

**M3 U03 P3.** Does a product that doesn't report to the agencies build a history?

- Yes
- ✔ No
- Yes, if you pay on time

*Correct! If it doesn't report, it doesn't count.*

**M3 U04 P1.** Can a real late payment be erased because it lowers your score?

- ✔ No
- Yes
- Yes, if you pay a company

*Correct! Correct information stays.*

**M3 U04 P2.** Balance 240 and limit 800. Utilization?

- 24%
- 60%
- ✔ 30%

*Correct! 240 ÷ 800 = 0.30.*

**M3 U04 P3.** Can a company charge you before doing the repair work?

- It's normal
- ✔ It's a red flag
- It's required by law

*Correct! The law prohibits it.*

**M3 U05 P1.** Loan A: 10 payments of 110 plus a 40 fee. B: 10 payments of 112. Which costs less?

- ✔ B (1,120)
- A (1,140)
- They cost the same

*Correct! B costs 20 less.*

**M3 U05 P2.** Does paying the minimum avoid interest?

- Yes
- Yes, if you pay on time
- ✔ No

*Correct! It only avoids falling behind.*

**M3 U05 P3.** Is deferred interest the same as 0%?

- Yes
- ✔ No
- Yes, if the store says so

*Correct! If you don't pay it off in time, they charge it all.*

**M3 U06 P1.** Which strategy saves the most interest?

- ✔ Avalanche
- Snowball
- Paying only the minimums

*Correct! It goes after the highest rate.*

**M3 U06 P2.** Should you always pay the highest rate first?

- Yes
- Yes, no exceptions, even if there are other consequences
- ✔ No, check the consequences

*Correct! First what puts the basics at risk.*

**M3 U06 P3.** Does a lower payment mean you pay less in total?

- Yes
- ✔ Not necessarily
- Yes, you always pay less

*Correct! It can stretch out the term.*

**M3 U07 P1.** Does a dispute with a credit agency stop a lawsuit?

- ✔ No
- Yes
- Yes, for 30 days

*Correct! The court has its own deadline.*

**M3 U07 P2.** Can a collector threaten you?

- Yes
- Yes, if the debt is old
- ✔ No

*Correct! It's prohibited.*

**M3 U07 P3.** Is an agreement you asked for already accepted?

- Yes
- ✔ No, not until they confirm it
- Yes, if you asked by phone

*Correct! You need the confirmation.*

**M3 U08 P1.** Can cosigning make you responsible for the whole debt?

- ✔ Yes
- No
- Only for half

*Correct! The lender can collect all of it from you.*

**M3 U08 P2.** Does a family promise change the contract with the bank?

- Yes
- Yes, if it's in writing between you
- ✔ No

*Correct! The contract is what counts.*

**M3 U08 P3.** Is it wise to share your password to help?

- Yes
- ✔ No
- Yes, if it's family

*Correct! You lose control and the bank's protection.*

**M3 U09 P1.** Does a traditional tanda build credit history?

- ✔ No
- Yes
- Yes, if it has more than 10 people

*Correct! Nobody reports your payments.*

**M3 U09 P2.** Whoever receives first in a tanda gets…?

- A profit
- A penalty
- ✔ A loan with no interest

*Correct! They receive it all before paying.*

**M3 U09 P3.** Can an organized circle report to the agencies?

- No
- ✔ Yes
- Only if it's run by a bank

*Correct! Many programs do.*

**M3 U10 P1.** Which improvement can be proven?

- ✔ "I checked my report and filed a dispute with a confirmation number"
- "I'll raise my score 80 points"
- "I'll have good credit before the end of this year"

*Correct! It's an action with evidence.*

**M3 U10 P2.** Is opening a card always the first step?

- Yes
- Yes, the more cards the better
- ✔ No

*Correct! It depends on your situation.*

**M3 U10 P3.** Balance 800, interest 16, purchases 90, payment 120. Ending balance?

- 680
- ✔ 786
- 920

*Correct! 800 + 16 + 90 − 120 = 786.*

**M3 U11 P1.** Where do you ask first for an advance?

- In an app
- ✔ Your employer
- A payday lender

*Correct! Many employers do it at no cost.*

**M3 U11 P2.** 10 dollars per advance, 26 times a year. How much do you pay?

- ✔ 260
- 10
- 130

*Correct! 10 × 26.*

**M3 U11 P3.** What happens to your next check after an advance?

- It arrives in full
- It comes with a bonus
- ✔ It arrives with less money

*Correct! You already received that part.*

**M3 U12 P1.** If you don't repay a pawn loan, what happens to your credit?

- ✔ Nothing changes; you lose the item
- It's reported as a debt in collections
- Your bank account is frozen

*Correct! The shop keeps the item.*

**M3 U12 P2.** Does pawning build your history?

- Yes
- Only if you pay on time
- ✔ No

*Correct! It isn't reported.*

**M3 U12 P3.** What do you ask for before pawning?

- Nothing
- ✔ The fees and the deadline in writing
- An extra loan

*Correct! So you know what you'll pay.*

## Module 4

**M4 U01 P1.** Which number do you call to verify?

- The one in the message
- ✔ The one you look up yourself
- The one in the email

*Correct! The one in the message may be fake.*

**M4 U01 P2.** Does the browser padlock prove a website is honest?

- ✔ No
- Yes
- Yes, if it's green

*Correct! It only shows an encrypted connection.*

**M4 U01 P3.** Will a bank ask you for the code you got by text?

- Yes
- Yes, if they call from the bank's number
- ✔ No

*Correct! The code is only for you.*

**M4 U02 P1.** Can a notary public give you immigration advice?

- Yes
- ✔ No
- Yes, if they speak Spanish

*Correct! They only certify signatures.*

**M4 U02 P2.** Where do you check an attorney's license in California?

- ✔ State Bar
- In their ad
- With a notario

*Correct! It's the official registry.*

**M4 U02 P3.** Will ICE ask you to pay with gift cards?

- Yes
- Only if it's urgent
- ✔ No

*Correct! No agency charges that way.*

**M4 U03 P1.** Which account do you protect first?

- Social media
- ✔ Main email
- Your music app

*Correct! The others are recovered through your email.*

**M4 U03 P2.** Do you share the code you received if "the bank" calls?

- ✔ No
- Yes
- Yes, if they know your name

*Correct! The code is only for you.*

**M4 U03 P3.** Does a budgeting app need to read your messages?

- Yes
- Yes, to sort your expenses
- ✔ No

*Correct! It doesn't need to.*

**M4 U04 P1.** Does a credit freeze protect your existing accounts?

- Yes
- ✔ No
- Yes, credit cards too

*Correct! It only prevents new accounts.*

**M4 U04 P2.** Is negotiating with the scammer a necessary step?

- ✔ No
- Yes
- Yes, to get your money back

*Correct! Stop talking to them.*

**M4 U04 P3.** Where do you create a recovery plan for identity theft?

- Social media
- On the website the scammer sent you
- ✔ IdentityTheft.gov

*Correct! It's the FTC's official site.*

**M4 U05 P1.** Is a disagreement about spending always abuse?

- Yes
- ✔ No
- Yes, if there's yelling

*Correct! The pattern is what matters.*

**M4 U05 P2.** To pass, do you have to confront the other person?

- ✔ No
- Yes
- Yes, in writing

*Correct! You can use made-up cases.*

**M4 U05 P3.** Does having access to an older relative's money give you the right to use it?

- Yes
- Yes, if you take care of them
- ✔ No

*Correct! The money is theirs.*

**M4 U06 P1.** Savings of 600 and expenses of 1,500. How many months does it cover?

- 2.5
- ✔ 0.4
- 1

*Correct! 600 ÷ 1,500 = 0.4.*

**M4 U06 P2.** Is a known yearly payment an emergency?

- ✔ No, it's a planned expense
- Yes
- Yes, if it's over 500

*Correct! It can be planned for.*

**M4 U06 P3.** Is an investment that can go down a good place for your savings?

- Yes
- Yes, if it goes up fast
- ✔ No

*Correct! Savings shouldn't lose value.*

**M4 U07 P1.** Does liability insurance fix your car?

- Yes
- ✔ No
- Yes, if the crash was your fault

*Correct! It pays for damage to others.*

**M4 U07 P2.** Does the building owner's insurance cover your belongings?

- ✔ No
- Yes
- Yes, if the theft was in the building

*Correct! You need renters insurance.*

**M4 U07 P3.** A 1,500 service, 300 deductible, 25% coinsurance. How much do you pay?

- 375
- 1,500
- ✔ 600

*Correct! 300 + 25% of 1,200 = 600.*

**M4 U08 P1.** Is the explanation of benefits a bill?

- Yes
- ✔ No
- Yes, it's due in 30 days

*Correct! It only explains.*

**M4 U08 P2.** Must California hospitals have a financial assistance policy?

- ✔ Yes
- No
- Only public hospitals

*Correct! They must have one.*

**M4 U08 P3.** Do you delay urgent care to finish the exercise?

- Yes
- Yes, if there's little left
- ✔ Never

*Correct! Your health comes first.*

**M4 U09 P1.** Does an unconfirmed insurance payment count as a resource?

- Yes
- ✔ No
- Yes, if the lawyer says you'll win

*Correct! Only what's confirmed.*

**M4 U09 P2.** Does homeowners insurance usually cover earthquakes?

- ✔ It's usually a separate policy
- Yes
- Yes, it's always included

*Correct! It's bought separately.*

**M4 U09 P3.** Do you keep the only copy of your documents at home?

- Yes
- Yes, in a locked drawer at home
- ✔ No, also in another safe place

*Correct! Keep copies in two places.*

**M4 U10 P1.** Does the Caregiver's Authorization Affidavit change custody?

- Yes
- ✔ No
- Yes, for one year

*Correct! It only authorizes school and some medical care.*

**M4 U10 P2.** Does sharing your password give legal authorization?

- ✔ No
- Yes
- Yes, if it's written down

*Correct! A formal authorization is needed.*

**M4 U10 P3.** How often should you review the plan?

- Never
- Every five years or when moving to another country
- ✔ Every six months or if something changes

*Correct! Life changes.*

**M4 U11 P1.** Does a protection plan require buying every insurance?

- Yes
- ✔ No
- Yes, at least three

*Correct! You prioritize the gaps.*

**M4 U11 P2.** A fake emergency arrives when your income has dropped. Which parts do you use?

- ✔ Verification, calendar, savings and remittance agreement
- Only the savings
- Only the code word and the usual number

*Correct! The plan works as a whole.*

**M4 U11 P3.** How often should you do a drill?

- Never
- Only when something happens
- ✔ At least once a year

*Correct! Practicing keeps the plan useful.*

**M4 U12 P1.** Whose right is child support?

- ✔ The children's
- The receiving parent's
- The state's

*Correct! It's for what they need.*

**M4 U12 P2.** How do you pay so it counts?

- In cash, hand to hand
- ✔ Through the agency or wage withholding
- Whenever you can

*Correct! It gets recorded.*

**M4 U12 P3.** Your income dropped and you pay child support. What do you do?

- Stop paying
- Pay half
- ✔ Request a modification

*Correct! The debt continues until it's changed.*

## Module 5

**M5 U01 P1.** Assets 12,000 and debts 8,500. Net worth?

- 20,500
- 8,500
- ✔ 3,500

*Correct! 12,000 − 8,500.*

**M5 U01 P2.** Is net worth the same as available cash?

- Yes
- ✔ No
- Yes, if it includes the car

*Correct! It includes things that aren't cash.*

**M5 U01 P3.** Can you assign the same 80 to three goals?

- ✔ No
- Yes
- Yes, if they're small goals

*Correct! Every dollar has one job.*

**M5 U02 P1.** 1,000 at 4% for two years, with no contributions. Balance?

- 1,080
- 1,040
- ✔ 1,081.60

*Correct! Compound interest.*

**M5 U02 P2.** An investment goes up 10% and then down 10%. Starting from 1,000, how much is left?

- 1,000
- ✔ 990
- 1,010

*Correct! 1,000 × 1.1 × 0.9.*

**M5 U02 P3.** Net return 5% and inflation 4%. Approximate real return?

- ✔ 0.96%
- 9%
- 1%

*Correct! 1.05 ÷ 1.04 − 1.*

**M5 U03 P1.** Is an IRA the same as a stock?

- Yes
- Yes, if it's from a big company
- ✔ No

*Correct! One is the account and the other the product.*

**M5 U03 P2.** Is having two similar funds diversifying?

- Yes
- ✔ Not necessarily
- Yes, as long as they're from different companies

*Correct! They may hold the same things.*

**M5 U03 P3.** Where do you check a broker?

- ✔ BrokerCheck
- On their social media
- With the adviser, by message

*Correct! It's the official registry.*

**M5 U04 P1.** Can the landlord ask about your immigration status in California?

- Yes
- Only if it's a large building
- ✔ No

*Correct! It's prohibited.*

**M5 U04 P2.** Does an 1,800 mortgage cost the same as 1,800 in rent?

- Yes
- ✔ No, there are more costs
- Yes, if the rate is fixed

*Correct! There are taxes, insurance and maintenance.*

**M5 U04 P3.** If you get court eviction papers, what do you do?

- ✔ Get legal help right away
- Wait
- Move out without notice to avoid court

*Correct! The deadline is very short.*

**M5 U05 P1.** Car A: payment 250 and other costs 320. Car B: payment 310 and other costs 230. Which costs less each month?

- A (570)
- They cost the same
- ✔ B (540)

*Correct! 540 is less.*

**M5 U05 P2.** Is a longer loan always better because it lowers the payment?

- Yes
- ✔ No
- Yes, if the car is new

*Correct! You pay more interest.*

**M5 U05 P3.** Is a "guaranteed job" in an ad secure income?

- ✔ No
- Yes
- Yes, if the school is large

*Correct! Nobody can guarantee it.*

**M5 U06 P1.** Does an IRA require work income to contribute?

- No
- Only if you have an SSN
- ✔ Yes

*Correct! You need work income.*

**M5 U06 P2.** Is a 20-year projection a promise?

- Yes
- ✔ No
- Yes, if the bank makes it

*Correct! It's a scenario.*

**M5 U06 P3.** Should you cash out your 401(k) when you change jobs without checking options?

- ✔ No
- Yes
- Yes, if you need the money

*Correct! Check the transfer first.*

**M5 U07 P1.** Do you lose your AFORE by living in the U.S.?

- Yes
- Yes, after 5 years
- ✔ No

*Correct! It's still yours.*

**M5 U07 P2.** What do you need to find it?

- Your ITIN
- ✔ Your CURP
- Your consular ID number

*Correct! The CURP.*

**M5 U07 P3.** Is a middleman who charges to "release your AFORE" necessary?

- ✔ No
- Yes
- Only if you live abroad

*Correct! The procedures cost nothing.*

**M5 U08 P1.** Does your will change the beneficiaries of your insurance?

- Yes
- Yes, if it's more recent
- ✔ No

*Correct! They're updated at each institution.*

**M5 U08 P2.** Does the caregiver form take away your custody?

- Yes
- ✔ No
- Yes, for one year

*Correct! You can cancel it.*

**M5 U08 P3.** Should just anyone have your power of attorney?

- ✔ No
- Yes
- Only a lawyer

*Correct! Only someone you fully trust.*

**M5 U09 P1.** What month do you plan with if your income changes?

- The best one
- The year's average
- ✔ A realistic low month

*Correct! That way the plan holds up.*

**M5 U09 P2.** Your base is 2,000 and you earn 2,800. What do you do with the 800?

- Spend it
- ✔ Set part of it aside
- Prepay debts and spend the rest

*Correct! It prepares for bad months.*

**M5 U09 P3.** Does recording your cash help you?

- ✔ Yes
- No
- Only if you pay taxes

*Correct! Without a record you don't know your income.*

**M5 U10 P1.** You sell 900 and your costs are 450. Your profit?

- 900
- 1,350
- ✔ 450

*Correct! 900 − 450.*

**M5 U10 P2.** Does an LLC in California pay tax even if it doesn't make money?

- No
- ✔ Yes, at least 800
- Only if it has employees

*Correct! There's a yearly minimum tax.*

**M5 U10 P3.** What's the first step to organize your business?

- ✔ Separate the money
- Open an LLC
- Print business cards

*Correct! Without separating you don't know if you make money.*

**M5 U11 P1.** Does your plan have to be perfect to start?

- Yes
- Yes, or it's useless
- ✔ No

*Correct! Clear and doable is enough.*

**M5 U11 P2.** Is using your reserve in an emergency a failure?

- Yes
- ✔ No, that's what it's for
- Yes, you have to start over

*Correct! The reserve did its job.*

**M5 U11 P3.** When do you review your plan?

- ✔ Every three or six months, or when something changes
- Never
- Once, when you finish the course, and put it away

*Correct! That keeps it useful.*

**M5 U12 P1.** You inherit a house in Mexico worth 130,000 dollars. What do you do with the IRS?

- ✔ File Form 3520
- Pay 40%
- Nothing, because the house is in another country

*Correct! It's an information report.*

**M5 U12 P2.** What keeps your bank account out of court?

- Your will in Mexico
- ✔ A POD beneficiary
- Withdrawing everything in cash

*Correct! It passes directly.*

**M5 U12 P3.** How much ISR does an heir pay in Mexico?

- 30%
- 16%
- ✔ None

*Correct! It's exempt.*
