# Tu Regreso, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Don Rafa | 52 años. Trabajó 18 años en construcción en Texas. Lo deportaron en marzo; volvió a Michoacán. |
| Lupita | 38 años. Regresó por decisión propia a Guanajuato con dos hijos nacidos en EE. UU. |
| Memo | 24 años. Llegó a EE. UU. a los 6 años; regresó a Puebla y casi no conoce México. |
| Chayo | 45 años. Vive en Oaxaca; recibía remesas de su esposo, que acaba de regresar. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Tus papeles | Tu lista de papeles en orden: constancia, CURP, acta, INE y los de tus hijos. | Papeles en orden |
| Módulo 2. Tu cuenta en México | Una cuenta a tu nombre para recibir apoyos y dinero, y tus tarjetas de regreso bien usadas. | Cuenta a mi nombre |
| Módulo 3. Crédito desde cero | Tu primer historial de crédito en México, empezando chico y sin trampas. | Historial desde cero |
| Módulo 4. Lo que dejaste en Estados Unidos | Tu lista de lo que quedó allá: último pago, cuentas, impuestos y retiro. | Nada se queda allá |
| Módulo 5. Tu Afore, tu IMSS y tus semanas | Tus semanas cotizadas revisadas y tu Afore localizada. | Semanas contadas |
| Módulo 6. Tus primeros 90 días | Tu presupuesto de regreso para los primeros tres meses. | Noventa días |
| Módulo 7. Trabajo o negocio con lo que sabes hacer | Tu plan para usar lo que sabes hacer: empleo, oficio o negocio pequeño. | Lo que sé hacer |
| Módulo 8. Que no te engañen al regresar | Tu protocolo contra gestores falsos, fraudes y extorsión al que regresa. |  |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Papeles y cuenta, Crédito desde cero, Lo que quedó allá, Afore y semanas, Plan de regreso.

## 3. Lecciones

# Parte 2. Módulo 1. Tus papeles

## M1 U01. Tu constancia y tu CURP: los dos primeros papeles

**Lo que lograrás:** Explicar para qué sirve la constancia de repatriación y cómo sacar tu CURP para empezar cualquier trámite.

**Para empezar:** Don Rafa llegó a Michoacán con una hoja del Instituto Nacional de Migración doblada en la cartera. Su hermano le dijo que la tirara, que «ya estaba en México». En esta lección verás por qué esa hoja vale oro.

### Lo esencial (5 minutos)

#### La constancia de repatriación

Si te regresaron de Estados Unidos, el Instituto Nacional de Migración (INM) te entregó una **Constancia de Recepción de Mexicanos Repatriados**. Sirve como identificación temporal para tus primeros trámites: CURP, acta, servicios de salud, empleo y apoyos de México te Abraza.



#### Para qué te sirve

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| CURP | Para sacar o recuperar tu CURP. | Primer paso. |
| Salud | Atención médica básica y continuar tratamientos. | IMSS e instituciones de salud. |
| Empleo | Inscribirte al Servicio Nacional de Empleo. | Bolsa de trabajo. |
| Apoyos | Tarjeta Bienestar Paisano y Tarjeta FINABIEN Paisano. | Módulo 2. |

#### La CURP es la llave

Casi todo en México pide tu CURP: cuenta de banco, IMSS, Afore, escuela de tus hijos, empleo. Si ya tenías CURP, la puedes consultar e imprimir en gob.mx/curp sin costo. Si no tenías, se tramita en el Registro Civil o en módulos de atención a repatriados.



#### Un caso en un minuto

Don Rafa guardó su constancia, consultó su CURP en un cibercafé y la imprimió. Con las dos hojas pudo pedir su acta de nacimiento y registrarse para el apoyo.

> **Idea clave:** guarda tu constancia y saca tu CURP primero; con ellas abres las demás puertas.



#### Comprueba lo que entendiste

1. ¿Para qué sirve la constancia de repatriación?
*Respuesta:* Como identificación temporal para tus primeros trámites en México.

2. ¿Cuánto cuesta consultar tu CURP en gob.mx?
*Respuesta:* Nada: la consulta y la impresión no tienen costo.


#### Para recordar

- Guarda la constancia.
- Saca tu CURP primero.
- Ningún trámite de CURP cuesta.



### Profundiza (5 minutos más)

#### Tu lista de papeles

| Papel | Lo tengo | Dónde se saca |
|---|---|---|
| Constancia de repatriación | | INM, al llegar |
| CURP | | gob.mx/curp o Registro Civil |
| Acta de nacimiento | | gob.mx/actas o Registro Civil |
| INE | | Módulo del INE |



#### Si perdiste la constancia

Pide una copia en la oficina del INM o en el módulo de atención a repatriados de tu estado. Mientras tanto, cualquier otro papel que tengas (acta, matrícula consular, pasaporte aunque esté vencido) ayuda a demostrar quién eres.



#### Casos


**Caso 1. La hoja de Don Rafa**

Su hermano le dice que tire la constancia porque «ya está en México».
- *¿Qué hace?* La guarda junto con sus demás papeles.


**Caso 2. La CURP de Memo**

Memo no sabe si tiene CURP; se fue a EE. UU. a los 6 años.
- *¿Qué hace?* La busca en gob.mx/curp con su nombre y fecha de nacimiento.


**Caso 3. El «gestor» de la plaza**

Un señor le ofrece a Lupita sacarle la CURP por 500 pesos.
- *¿Qué hace?* No paga: la consulta en gob.mx es sin costo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Tirar la constancia | Te quedas sin identificación | Guárdala |
| Pagar por la CURP | Pierdes dinero | Es sin costo |
| Dejar la CURP para después | Se atoran los demás trámites | Primero la CURP |
| Dar tus papeles a un desconocido | Robo de identidad | Hazlo tú |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Memo y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué papel te da el INM al regresarte? a) La Constancia de Recepción de Mexicanos Repatriados · b) Tu credencial del INE nueva, lista para votar · c) Tu acta de nacimiento
2. ¿Cuál es la llave de casi todos los trámites? a) La credencial del trabajo de EE. UU. · b) La CURP · c) El recibo de luz
3. ¿Cuánto cuesta imprimir tu CURP en gob.mx? a) 500 pesos · b) 150 pesos · c) Nada
**Respuestas:** 1-a: es tu identificación temporal. 2-b: casi todo la pide. 3-c: es sin costo.



#### Ponlo en práctica

Tienes constancia y CURP, pero no acta ni INE. ¿Qué dos papeles te faltan de la lista básica?
**Respuesta:** El acta de nacimiento y la INE.



#### A tu plan

Llena tu lista de papeles: marca lo que tienes y anota dónde sacarás lo que falta.



### Para saber más

- **Consulta tu CURP** (Gobierno de México · español): https://www.gob.mx/curp — **Qué buscar:** «consulta e impresión».
- **México te Abraza** (SEGOB · español): https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza — **Qué buscar:** «servicios».

### Palabras clave

- *Repatriación:* regreso de una persona a su país.
- *Constancia:* papel oficial que comprueba algo.
- *CURP:* Clave Única de Registro de Población.

### Fuentes

SEGOB, México te Abraza; INM, Constancia de Recepción de Mexicanos Repatriados; consultados el 5 de octubre de 2026.

---

## M1 U02. Tu acta y tu INE

**Lo que lograrás:** Sacar tu acta de nacimiento y tramitar tu credencial del INE, que te pedirán en el banco y en el trabajo.

**Para empezar:** Chayo acompañó a su esposo al banco para abrir una cuenta. Le pidieron INE. Él solo traía su licencia de Texas. Volvieron a casa sin cuenta. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### El acta de nacimiento

Puedes sacar una copia certificada de tu acta en gob.mx/actas con tu CURP, pagar en línea o en banco, e imprimirla. Vale lo mismo que la del Registro Civil. El costo depende del estado.



#### La INE

La credencial del INE es la identificación que más piden. El trámite es gratuito. Lleva al módulo: acta de nacimiento, una identificación con foto (la constancia de repatriación o un documento con foto) y un comprobante de domicilio.



#### Si no tienes comprobante de domicilio

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Recibo de familiar | Luz, agua o predial a nombre de quien te recibe. | Pregunta en el módulo qué aceptan. |
| Testigos | Algunos módulos aceptan dos testigos. | Pregunta antes de ir. |
| Constancia de residencia | La da el municipio o la autoridad local. | Útil en comunidades. |

#### Un caso en un minuto

El esposo de Chayo sacó su acta en línea, pidió una constancia de residencia en el municipio y fue al módulo del INE. En dos semanas tenía su credencial y abrió su cuenta.

> **Idea clave:** con acta y comprobante de domicilio sacas tu INE sin costo; es la identificación que abre el banco.



#### Comprueba lo que entendiste

1. ¿Dónde puedes sacar tu acta sin ir al Registro Civil?
*Respuesta:* En gob.mx/actas, con tu CURP.

2. ¿Cuánto cuesta la INE?
*Respuesta:* Nada: el trámite es gratuito.


#### Para recordar

- Acta en gob.mx/actas.
- INE sin costo.
- Comprobante de domicilio: pregunta opciones.



### Profundiza (5 minutos más)

#### Qué llevar al módulo del INE

| Requisito | Qué puedes llevar |
|---|---|
| Nacionalidad | Acta de nacimiento |
| Identidad con foto | Constancia de repatriación, pasaporte o matrícula |
| Domicilio | Recibo de servicio o constancia de residencia |



#### Mientras llega tu INE

Pide en el módulo tu comprobante de trámite y guárdalo. Si necesitas cobrar un apoyo antes, pregunta en la oficina del programa qué identificación aceptan.



#### Casos


**Caso 1. La licencia de Texas**

El esposo de Chayo quiere abrir una cuenta con su licencia de Texas.
- *¿Qué hace?* Tramita su INE con su acta y un comprobante de domicilio.


**Caso 2. Sin recibos a su nombre**

Memo vive con su tía y ningún recibo está a su nombre.
- *¿Qué hace?* Pregunta en el módulo si aceptan el recibo de su tía o testigos.


**Caso 3. La cita pagada**

Una página pide 300 pesos por «apartar cita» en el INE.
- *¿Qué hace?* No paga: la cita y la credencial son gratuitas.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Llegar sin acta | Te regresan | Llévala impresa |
| Pagar por la cita del INE | Fraude | Es sin costo |
| No preguntar por el domicilio | Pierdes la vuelta | Pregunta antes |
| Tirar el comprobante de trámite | No puedes recoger la credencial | Guárdalo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con el esposo de Chayo y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué te piden para la INE? a) Pasaporte vigente de EE. UU. · b) Acta, identificación con foto y comprobante de domicilio · c) Un aval con casa propia y su comprobante de domicilio
2. ¿Cuánto cuesta sacar la credencial del INE? a) Nada · b) 300 pesos · c) Depende del estado
3. No tienes recibos a tu nombre. ¿Qué haces? a) Esperas a tener casa propia · b) Usas cualquier recibo de luz que encuentres en la calle, aunque no sea de tu casa · c) Preguntas si aceptan el de tu familiar, testigos o constancia de residencia
**Respuestas:** 1-b: son los tres requisitos. 2-a: es sin costo. 3-c: hay opciones.



#### Ponlo en práctica

Ya tienes acta y constancia de repatriación. Vives con tu mamá y el recibo de luz está a su nombre. ¿Qué te falta confirmar antes de ir al módulo?
**Respuesta:** Si aceptan el recibo de tu mamá como comprobante de domicilio.



#### A tu plan

Saca tu acta en línea y llama o pregunta en el módulo del INE más cercano qué comprobante de domicilio aceptan.



### Para saber más

- **Acta de nacimiento en línea** (Gobierno de México · español): https://www.gob.mx/actas — **Qué buscar:** «copia certificada».
- **Requisitos de la credencial** (INE · español): https://www.ine.mx — **Qué buscar:** «requisitos credencial para votar».

### Palabras clave

- *Copia certificada:* copia oficial que vale como el original.
- *Comprobante de domicilio:* papel que muestra dónde vives.
- *Módulo:* oficina donde se tramita la INE.

### Fuentes

INE, requisitos para tramitar la credencial; Gobierno de México, actas en línea; consultados el 5 de octubre de 2026.

---

## M1 U03. Los papeles de tus hijos nacidos en Estados Unidos

**Lo que lograrás:** Registrar en México a tus hijos nacidos en EE. UU. para que tengan CURP, escuela y servicios.

**Para empezar:** Los hijos de Lupita nacieron en Houston. En la escuela de Guanajuato le dijeron que sin CURP no podían inscribirlos. En esta lección verás cómo se hace la doble nacionalidad.

### Lo esencial (5 minutos)

#### Son mexicanos también

Si tu hijo nació en EE. UU. y tú eres mexicana o mexicano, tu hijo también es mexicano por nacimiento. Para que México lo reconozca, se **inscribe su nacimiento** en el Registro Civil o en un consulado. Así obtiene acta mexicana y CURP.



#### Lo que normalmente piden

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Acta de EE. UU. | El birth certificate original. | Algunos estados piden apostilla. |
| Traducción | Al español, si la piden. | Pregunta antes. |
| Tus papeles | Tu acta mexicana e identificación. | De mamá o papá. |
| Tu hijo | Debe estar presente o según indique la oficina. | Pregunta. |

#### La escuela no debe esperar

La SEP indica que las niñas y niños pueden inscribirse aunque les falten papeles, mientras se regularizan. Pide en la escuela la inscripción y avisa que el trámite está en curso.



#### Un caso en un minuto

Lupita llevó las actas de sus hijos al Registro Civil. Le dijeron qué necesitaba en su estado. Mientras tanto, sus hijos entraron a la escuela con inscripción provisional.

> **Idea clave:** registra a tus hijos en México para que tengan acta y CURP; la escuela no debe esperar a tenerlas.



#### Comprueba lo que entendiste

1. ¿Tu hijo nacido en EE. UU. puede ser mexicano?
*Respuesta:* Sí, si su mamá o su papá es mexicano; se inscribe su nacimiento.

2. ¿Qué haces si la escuela pide CURP y aún no la tienes?
*Respuesta:* Pides inscripción mientras se regulariza el trámite.


#### Para recordar

- Inscribe su nacimiento.
- Pregunta requisitos en tu estado.
- La escuela no espera.



### Profundiza (5 minutos más)

#### Lista para tus hijos

| Papel | Hijo 1 | Hijo 2 |
|---|---|---|
| Birth certificate | | |
| Apostilla (si la piden) | | |
| Acta mexicana | | |
| CURP | | |



#### Apostilla

Es un sello que reconoce un documento de otro país. Para un acta de EE. UU. se pide en el estado donde nació el niño. Algunos registros civiles ya no la piden: pregunta antes de pagar.



#### Casos


**Caso 1. La escuela de Lupita**

Le dicen que sin CURP no hay lugar para sus hijos.
- *¿Qué hace?* Pide inscripción mientras termina el registro de nacimiento.


**Caso 2. El acta original**

Lupita tiene solo una copia simple del birth certificate.
- *¿Qué hace?* Pregunta en el Registro Civil si la aceptan o cómo pedir una certificada.


**Caso 3. La traducción cara**

Le ofrecen traducir las actas por 2,000 pesos cada una.
- *¿Qué hace?* Primero pregunta si su estado pide traducción y quién puede hacerla.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar que no son mexicanos | No los registras | Sí lo son |
| Pagar apostilla sin preguntar | Gasto de más | Pregunta antes |
| Dejar a los niños sin escuela | Pierden el año | Inscripción provisional |
| Perder el birth certificate | Cuesta reponerlo desde México | Guarda el original |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita y sus hijos. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu hijo nació en EE. UU. y tú eres mexicana. ¿Qué es tu hijo? a) Solo estadounidense · b) También mexicano, si inscribes su nacimiento · c) Extranjero hasta que cumpla 18 años y decida
2. ¿Qué haces antes de pagar apostilla o traducción? a) Preguntas si tu estado la pide · b) Pagas la apostilla y la traducción más caras para ir seguro · c) Nada, no hace falta registrar
3. La escuela pide CURP y está en trámite. ¿Qué haces? a) Esperas al próximo ciclo · b) Lo inscribes el próximo año, cuando ya tenga su CURP · c) Pides inscripción mientras se regulariza
**Respuestas:** 1-b: se inscribe su nacimiento. 2-a: no todos la piden. 3-c: la escuela no debe esperar.



#### Ponlo en práctica

Tienes dos hijos nacidos en EE. UU. con birth certificate. ¿Qué dos papeles mexicanos tendrán al terminar el trámite?
**Respuesta:** Acta de nacimiento mexicana y CURP.



#### A tu plan

Pregunta en el Registro Civil de tu municipio qué piden para inscribir el nacimiento de tus hijos y llena la lista.



### Para saber más

- **Doble nacionalidad** (SRE · español): https://www.gob.mx/sre — **Qué buscar:** «inscripción de nacimiento doble nacionalidad».
- **Inscripción a la escuela** (SEP · español): https://www.gob.mx/sep — **Qué buscar:** «inscripción niñas y niños migrantes».

### Palabras clave

- *Doble nacionalidad:* ser de dos países a la vez.
- *Apostilla:* sello que reconoce un documento extranjero.
- *Inscripción de nacimiento:* registro en México de un nacimiento ocurrido fuera.

### Fuentes

SRE, doble nacionalidad; SEP, normas de inscripción para población migrante; consultados el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Tu cuenta en México

## M2 U01. Tus tarjetas de regreso

**Lo que lograrás:** Distinguir la Tarjeta Bienestar Paisano de la Tarjeta FINABIEN Paisano y usar bien los 2,000 pesos.

**Para empezar:** A Don Rafa le dieron una tarjeta con 2,000 pesos en el centro de atención. Un compañero del camión le dijo que «cada mes le iban a caer más». En esta lección verás qué es cada tarjeta y qué no es.

### Lo esencial (5 minutos)

#### Dos tarjetas distintas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Bienestar Paisano | Un apoyo único de 2,000 pesos. | Para el traslado y los primeros gastos. |
| FINABIEN Paisano | Una cuenta para recibir y enviar dinero. | Remesas y pagos. |

#### El apoyo es una sola vez

Los 2,000 pesos de la Tarjeta Bienestar Paisano se entregan una vez y no se repiten cada mes. Úsalos para llegar a tu comunidad y para lo más urgente: comida, transporte, papeles.



#### La FINABIEN sí es para quedarte

La Tarjeta FINABIEN Paisano es una cuenta: puedes recibir dinero desde EE. UU., guardar y pagar. Se pide en las sucursales de FINABIEN. Úsala mientras abres otra cuenta o como tu cuenta principal.



#### Un caso en un minuto

Don Rafa usó 900 pesos del apoyo en el camión a su pueblo y guardó el resto para su acta y sus primeros días. Después sacó su FINABIEN para que su hijo le mande dinero desde Dallas.

> **Idea clave:** el apoyo de 2,000 pesos es una sola vez; la FINABIEN es una cuenta para seguir recibiendo dinero.



#### Comprueba lo que entendiste

1. ¿Cada cuándo llega el apoyo de la Tarjeta Bienestar Paisano?
*Respuesta:* Una sola vez.

2. ¿Para qué sirve la Tarjeta FINABIEN Paisano?
*Respuesta:* Para recibir, guardar y enviar dinero, como una cuenta.


#### Para recordar

- 2,000 pesos una vez.
- FINABIEN es cuenta.
- Lo urgente primero.



### Profundiza (5 minutos más)

#### Los 2,000 pesos de Don Rafa

- Apoyo: **2,000**
- Camión a su pueblo: **900**
- Acta y copias: **250**
- Comida de la primera semana: **600**
- Para imprevistos: **250**


#### Tu NIP es solo tuyo

Nadie del programa te pide el NIP ni la clave por teléfono. Si alguien lo pide, es fraude (módulo 8).



#### Casos


**Caso 1. «Cada mes te caen más»**

A Don Rafa le dicen que el apoyo se repite cada mes.
- *¿Qué hace?* Planea con 2,000 pesos de una sola vez.


**Caso 2. El hijo en Dallas**

El hijo de Don Rafa quiere mandarle dinero cada quincena.
- *¿Qué hace?* Usa su FINABIEN para recibirlo.


**Caso 3. La llamada del programa**

Le llaman «del programa» para «activar» la tarjeta con su NIP.
- *¿Qué hace?* Cuelga: nadie del programa pide el NIP.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Esperar más depósitos | Te quedas sin dinero | Es una sola vez |
| Confundir las tarjetas | No recibes remesas | FINABIEN es cuenta |
| Dar el NIP | Te vacían la tarjeta | Nunca lo des |
| Gastar todo el primer día | Sin dinero para papeles | Lo urgente primero |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa y su hijo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué es la Tarjeta Bienestar Paisano? a) Un apoyo único de 2,000 pesos · b) Una pensión que llega cada mes a tu cuenta · c) Un crédito
2. ¿Qué tarjeta te sirve para recibir dinero de EE. UU.? a) Ninguna · b) La FINABIEN Paisano · c) La tarjeta de una tienda departamental
3. Te piden el NIP «para activar». ¿Qué es? a) Un trámite normal · b) Un requisito del banco · c) Un fraude
**Respuestas:** 1-a: es una sola vez. 2-b: es una cuenta. 3-c: nadie pide el NIP.



#### Ponlo en práctica

Recibiste 2,000 pesos. El camión cuesta 650 y tus papeles 300. ¿Cuánto te queda?
**Respuesta:** 1,050 pesos.



#### A tu plan

Haz tu lista de cómo usarás los 2,000 pesos: traslado, papeles, comida y un guardadito.



### Para saber más

- **México te Abraza** (SEGOB · español): https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza — **Qué buscar:** «Bienestar Paisano».
- **FINABIEN** (Gobierno de México · español): https://www.gob.mx/finabien — **Qué buscar:** «Tarjeta FINABIEN Paisano».

### Palabras clave

- *Apoyo único:* dinero que se da una sola vez.
- *Remesa:* dinero que manda un familiar desde otro país.
- *NIP:* número secreto de tu tarjeta.

### Fuentes

SEGOB, México te Abraza; Secretaría de Bienestar, Tarjeta Bienestar Paisano; FINABIEN, Tarjeta FINABIEN Paisano; consultados el 5 de octubre de 2026.

---

## M2 U02. Elige una cuenta sin comisiones

**Lo que lograrás:** Comparar cuentas básicas y elegir una a tu nombre que no te cobre por tener tu dinero.

**Para empezar:** Lupita abrió una cuenta en la primera sucursal que encontró. A los tres meses vio que le cobraban 120 pesos al mes por «saldo mínimo». En esta lección verás qué revisar antes de firmar.

### Lo esencial (5 minutos)

#### Las cuentas básicas

Los bancos deben ofrecer una **cuenta básica**: sin comisión por apertura, sin saldo mínimo y sin cobro mensual por manejo. Pide esa cuenta por su nombre.



#### Antes de firmar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cobra por manejo? | Cobro mensual por tener la cuenta. | Busca cero. |
| ¿Pide saldo mínimo? | Si bajas de cierta cantidad, te cobran. | Busca que no. |
| ¿Retiros sin costo? | En qué cajeros no cobran. | Pregunta cuáles. |
| ¿Está protegida? | Que la institución esté autorizada. | Revisa en CONDUSEF. |

#### Verifica la institución

No te recomendamos un banco: te enseñamos a revisarlo. Busca la institución en el SIPRES de CONDUSEF. Si no aparece, no deposites ahí.



#### Un caso en un minuto

Lupita fue a otra sucursal y pidió la cuenta básica. No le cobran nada al mes. Cerró la anterior y dejó de perder 120 pesos.

> **Idea clave:** pide la cuenta básica y pregunta por comisiones antes de firmar.



#### Comprueba lo que entendiste

1. ¿Qué no debe cobrarte una cuenta básica?
*Respuesta:* Apertura, saldo mínimo ni manejo mensual.

2. ¿Dónde revisas que una institución está autorizada?
*Respuesta:* En el SIPRES de CONDUSEF.


#### Para recordar

- Pide la cuenta básica.
- Pregunta comisiones.
- Verifica en CONDUSEF.



### Profundiza (5 minutos más)

#### Lo que perdía Lupita

- Comisión al mes: **120**
- Meses: **12**
- Al año, por nada: **1,440**


#### Lee el contrato y la carátula

La carátula es la hoja de resumen del contrato. Ahí vienen las comisiones. Pide una copia y guárdala.



#### Casos


**Caso 1. El saldo mínimo**

A Lupita le ofrecen una cuenta con tarjeta dorada y saldo mínimo de 3,000.
- *¿Qué hace?* Pide la cuenta básica sin saldo mínimo.


**Caso 2. La caja del pueblo**

A Chayo le ofrecen guardar su dinero en una caja que da 4% al mes.
- *¿Qué hace?* La busca en el SIPRES de CONDUSEF antes de depositar.


**Caso 3. Sin contrato**

Memo firmó y no le dieron copia.
- *¿Qué hace?* Pide su contrato y la carátula con las comisiones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Firmar sin preguntar | Comisiones escondidas | Pregunta antes |
| Aceptar saldo mínimo | Te cobran si bajas | Cuenta básica |
| Depositar en lugares no autorizados | Puedes perderlo | Verifica |
| No guardar el contrato | No puedes reclamar | Pide copia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Chayo y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cuál cuenta pides para no pagar comisiones? a) La tarjeta dorada · b) La cuenta básica · c) La de inversión
2. Te ofrecen 4% al mes. ¿Qué haces primero? a) Revisas la institución en CONDUSEF · b) Depositas todo, porque 4% al mes es buen rendimiento · c) Invitas a tu familia
3. ¿Dónde vienen las comisiones? a) En el anuncio · b) En lo que te dice en voz el ejecutivo de la ventanilla · c) En la carátula del contrato
**Respuestas:** 1-b: sin comisiones. 2-a: verifica primero. 3-c: la carátula las resume.



#### Ponlo en práctica

Una cuenta cobra 85 pesos al mes. ¿Cuánto pagas en un año?
**Respuesta:** 1,020 pesos.



#### A tu plan

Anota las cuatro preguntas y hazlas antes de abrir tu cuenta. Guarda la carátula.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** el nombre de la institución.
- **Cuentas básicas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica».

### Palabras clave

- *Cuenta básica:* cuenta sin comisiones de apertura ni manejo.
- *Comisión:* cobro por un servicio.
- *Carátula:* resumen del contrato.

### Fuentes

CONDUSEF, cuentas básicas y SIPRES; consultados el 5 de octubre de 2026.

---

## M2 U03. Cobrar, pagar y reclamar

**Lo que lograrás:** Usar tu cuenta para cobrar y pagar sin riesgos, y saber cómo reclamar un cargo que no hiciste.

**Para empezar:** Memo recibió su primer pago por transferencia y vio un cargo de 1,800 pesos que no reconoce. No sabe si es error, fraude o «así es México». En esta lección verás qué hacer en las primeras horas.

### Lo esencial (5 minutos)

#### Formas de mover tu dinero

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transferencia (SPEI) | Con la CLABE de 18 dígitos. | Llega en minutos. |
| Tarjeta de débito | Pagas con tu propio dinero. | No es crédito. |
| App del banco | Consultas y transfieres. | Solo la oficial. |
| Retiro en cajero | Prefiere los sin costo. | Revisa tu entorno. |

#### Activa las alertas

Pide que te avisen por mensaje de cada movimiento. Así ves un cargo raro el mismo día.



#### Si ves un cargo que no hiciste

1. Llama al banco al número de atrás de tu tarjeta y bloquéala.
2. Pide un folio de tu reclamación.
3. Si no te resuelven, acude a CONDUSEF: 55 5340 0999.



#### Un caso en un minuto

Memo llamó al banco, bloqueó la tarjeta y anotó su folio. El banco revisó y le devolvió los 1,800 pesos.

> **Idea clave:** activa alertas; si ves un cargo raro, bloquea, pide folio y reclama.



#### Comprueba lo que entendiste

1. ¿Qué necesitas para recibir una transferencia?
*Respuesta:* Tu CLABE de 18 dígitos.

2. ¿Qué haces primero ante un cargo que no hiciste?
*Respuesta:* Llamas al banco, bloqueas la tarjeta y pides folio.


#### Para recordar

- Alertas activadas.
- Bloquea y pide folio.
- CONDUSEF si no resuelven.



### Profundiza (5 minutos más)

#### Tu ficha de cuenta

| Dato | Lo tengo |
|---|---|
| CLABE (18 dígitos) | |
| Teléfono del banco | |
| Alertas activadas | |
| Folio de reclamación (si hubo) | |



#### El tiempo cuenta

Reclama en cuanto veas el cargo. Mientras más tardas, más difícil es probar que no fuiste tú.



#### Casos


**Caso 1. El cargo de Memo**

Ve 1,800 pesos que no gastó.
- *¿Qué hace?* Bloquea la tarjeta, pide folio y reclama.


**Caso 2. La CLABE para el patrón**

El patrón de Don Rafa le pide sus datos para pagarle.
- *¿Qué hace?* Le da su CLABE, nunca su NIP ni contraseña.


**Caso 3. «Así es México»**

Un amigo le dice a Memo que no reclame porque «nunca devuelven».
- *¿Qué hace?* Reclama y, si no le resuelven, va a CONDUSEF.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No reclamar | Pierdes el dinero | Reclama pronto |
| Dar el NIP para recibir pagos | Fraude | Solo la CLABE |
| No pedir folio | No hay prueba | Siempre folio |
| Apps no oficiales | Robo de datos | Solo la del banco |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Memo y Don Rafa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué das para que te paguen? a) Tu NIP · b) Tu CLABE · c) Tu contraseña de la app
2. ¿Qué pides al reclamar en el banco? a) Un folio · b) Un descuento · c) Nada
3. El banco no te resuelve. ¿A dónde vas? a) A la policía de tránsito · b) A otro banco · c) A CONDUSEF
**Respuestas:** 1-b: solo la CLABE. 2-a: es tu prueba. 3-c: defiende a usuarios.



#### Ponlo en práctica

¿Cuántos dígitos tiene una CLABE?
**Respuesta:** 18.



#### A tu plan

Llena tu ficha de cuenta y activa las alertas por mensaje.



### Para saber más

- **Reclamaciones** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presentar una reclamación». Teléfono 55 5340 0999.

### Palabras clave

- *CLABE:* número de 18 dígitos para transferencias.
- *SPEI:* sistema de transferencias entre bancos.
- *Folio:* número que comprueba tu reclamación.

### Fuentes

CONDUSEF, reclamaciones; Banco de México, SPEI; consultados el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Crédito desde cero

## M3 U01. Tu historial de allá no cuenta aquí

**Lo que lograrás:** Explicar que en México empiezas sin historial de crédito y revisar tu reporte sin costo.

**Para empezar:** Don Rafa tenía buen crédito en Texas: pagó su troca a tiempo durante años. En México fue a pedir un préstamo y le dijeron que «no aparece en ningún lado». En esta lección verás por qué y qué hacer.

### Lo esencial (5 minutos)

#### Dos países, dos historiales

Tu historial de crédito de EE. UU. no pasa a México. Aquí lo llevan las sociedades de información crediticia, como **Buró de Crédito** y **Círculo de Crédito**. Si nunca tuviste crédito en México, apareces sin historial. No es malo: es empezar de cero.



#### Qué dice tu reporte

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tus créditos | Quién te prestó y cuánto. | Bancos, tiendas, apps. |
| Cómo pagaste | Si a tiempo o con atraso. | Lo que más pesa. |
| Quién te consultó | Quién revisó tu reporte. | Cuidado con muchas consultas. |

#### Revísalo sin costo

Puedes pedir tu reporte especial sin costo una vez cada 12 meses en cada sociedad. Hazlo para confirmar que nadie abrió créditos a tu nombre mientras no estabas.



#### Un caso en un minuto

Don Rafa pidió su reporte: no tenía créditos. Pero el de su primo mostró un préstamo de una app que nunca pidió. Lo reclamó a tiempo.

> **Idea clave:** en México empiezas sin historial; revisa tu reporte sin costo para ver que nadie usó tu nombre.



#### Comprueba lo que entendiste

1. ¿Tu historial de EE. UU. cuenta en México?
*Respuesta:* No: aquí empiezas de cero.

2. ¿Cada cuándo puedes pedir tu reporte sin costo?
*Respuesta:* Una vez cada 12 meses en cada sociedad.


#### Para recordar

- Empiezas de cero.
- Reporte sin costo cada 12 meses.
- Revisa que nadie usó tu nombre.



### Profundiza (5 minutos más)

#### Tu revisión

| Sociedad | Lo pedí | Fecha | ¿Todo bien? |
|---|---|---|---|
| Buró de Crédito | | | |
| Círculo de Crédito | | | |



#### Si aparece algo que no es tuyo

Presenta una reclamación ante la sociedad (en su página) y avisa a la institución que dio el crédito. Si no te resuelven, acude a CONDUSEF.



#### Casos


**Caso 1. «No apareces»**

A Don Rafa le dicen que no tiene historial.
- *¿Qué hace?* Entiende que empieza de cero y pide su reporte para revisar.


**Caso 2. El préstamo ajeno**

El reporte del primo muestra una app que no usó.
- *¿Qué hace?* Presenta una reclamación ante la sociedad.


**Caso 3. El reporte con costo**

Una página le cobra a Memo 400 pesos por su reporte.
- *¿Qué hace?* Lo pide en la página oficial, sin costo una vez al año.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que tu crédito de EE. UU. sirve aquí | Te frustras | Empieza de cero |
| No revisar tu reporte | No ves fraudes | Pídelo |
| Pagar por el reporte anual | Pierdes dinero | Es sin costo una vez al año |
| Ignorar un crédito ajeno | Lo pagas tú | Reclama |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, su primo y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tenías buen crédito en Texas. ¿Cómo apareces en México? a) Sin historial · b) Con el mismo puntaje · c) Con mal crédito
2. ¿Cuántas veces al año es sin costo tu reporte especial? a) Ninguna · b) Una · c) Cada mes
3. Aparece un crédito que no pediste. ¿Qué haces? a) Lo pagas para no tener problemas · b) Presentas una reclamación · c) Nada
**Respuestas:** 1-a: empiezas de cero. 2-b: una vez cada 12 meses. 3-b: reclamas.



#### Ponlo en práctica

Pediste tu reporte en Buró en enero. ¿Desde qué mes lo puedes volver a pedir sin costo?
**Respuesta:** Desde enero del año siguiente.



#### A tu plan

Pide tu reporte especial en Buró de Crédito y en Círculo de Crédito y anota la fecha.



### Para saber más

- **Reporte de Crédito Especial** (Buró de Crédito · español): https://www.burodecredito.com.mx — **Qué buscar:** «reporte de crédito especial».
- **Reporte gratuito** (Círculo de Crédito · español): https://www.circulodecredito.com.mx — **Qué buscar:** «reporte de crédito».

### Palabras clave

- *Historial de crédito:* registro de cómo has pagado lo que te prestan.
- *Sociedad de información crediticia:* empresa autorizada que guarda ese registro.
- *Reporte especial:* tu historial completo, sin costo una vez al año.

### Fuentes

Buró de Crédito y Círculo de Crédito, reporte especial; CONDUSEF; consultados el 5 de octubre de 2026.

---

## M3 U02. Empieza chico y paga a tiempo

**Lo que lograrás:** Construir historial en México con un crédito pequeño que puedas pagar completo y a tiempo.

**Para empezar:** Memo quiere una tarjeta de crédito para «tener historial» y le ofrecen una con límite de 20,000 pesos. Gana 9,000 al mes. En esta lección verás cómo empezar sin hundirte.

### Lo esencial (5 minutos)

#### Empezar chico

Para crear historial no necesitas mucho crédito. Necesitas **un** crédito pequeño y pagarlo a tiempo varios meses. Puede ser una tarjeta con límite bajo o una compra pequeña a plazos que ya ibas a hacer.



#### Las tres reglas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| A tiempo | Paga antes de la fecha límite. | Lo que más cuenta. |
| Usa poco | No uses más de un tercio del límite. | Ejemplo: de 3,000, usa hasta 1,000. |
| Paga todo | Paga el total, no el mínimo. | Así no pagas intereses. |

#### El pago mínimo es una trampa

Si pagas solo el mínimo, la deuda dura años y pagas mucho más en intereses. Usa la tarjeta solo para lo que ya tienes en la cuenta para pagar.



#### Un caso en un minuto

Memo pidió una tarjeta con límite de 3,000. La usa para su recarga y el gas, y la paga completa cada mes. En un año ya tiene historial.

> **Idea clave:** un crédito chico, poco uso y pago total a tiempo construyen tu historial.



#### Comprueba lo que entendiste

1. ¿Cuánto del límite conviene usar?
*Respuesta:* No más de un tercio.

2. ¿Por qué no pagar solo el mínimo?
*Respuesta:* Porque la deuda dura años y pagas mucho en intereses.


#### Para recordar

- Un crédito chico.
- Usa poco.
- Paga todo y a tiempo.



### Profundiza (5 minutos más)

#### El límite de Memo

- Límite: **3,000**
- Un tercio: **3**
- Lo máximo que conviene usar: **1,000**


#### Compara con el CAT

El Costo Anual Total (CAT) junta intereses y comisiones. Entre dos créditos parecidos, el de CAT más bajo es más barato. Lo ves en la carátula y en los simuladores de CONDUSEF.



#### Casos


**Caso 1. El límite de 20,000**

A Memo le ofrecen 20,000 de límite; gana 9,000.
- *¿Qué hace?* Pide un límite bajo que pueda pagar completo.


**Caso 2. El pago mínimo**

El estado de cuenta de Lupita dice «pago mínimo 250».
- *¿Qué hace?* Paga el total para no generar intereses.


**Caso 3. Tres tarjetas a la vez**

A Don Rafa le ofrecen tres tarjetas en una semana.
- *¿Qué hace?* Empieza con una sola y la paga a tiempo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pedir mucho límite | Te endeudas | Empieza chico |
| Pagar el mínimo | Intereses por años | Paga todo |
| Usar todo el límite | Afecta tu historial | Un tercio |
| Muchas tarjetas al inicio | Difícil de controlar | Una |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Memo, Lupita y Don Rafa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué construye mejor tu historial? a) Muchas tarjetas abiertas al mismo tiempo · b) Un crédito chico pagado a tiempo · c) Pagar el mínimo
2. Tu límite es 6,000. ¿Cuánto conviene usar como máximo? a) 2,000 · b) 6,000 · c) 4,500
3. ¿Qué indicador compara el costo de dos créditos? a) El color de la tarjeta · b) El pago mínimo · c) El CAT
**Respuestas:** 1-b: chico y a tiempo. 2-a: un tercio. 3-c: junta intereses y comisiones.



#### Ponlo en práctica

Tu límite es 4,500. ¿Cuánto es un tercio?
**Respuesta:** 1,500 pesos.



#### A tu plan

Si decides pedir un crédito, escribe tu límite máximo, para qué lo usarás y cómo lo pagarás completo cada mes.



### Para saber más

- **Simuladores y comparadores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «simulador tarjeta de crédito».

### Palabras clave

- *Límite de crédito:* lo máximo que te prestan.
- *Pago mínimo:* lo menos que puedes pagar sin atraso; genera intereses.
- *CAT:* Costo Anual Total del crédito.

### Fuentes

CONDUSEF, tarjetas de crédito y CAT; Banco de México; consultados el 5 de octubre de 2026.

---

## M3 U03. Préstamos «sin buró» y apps que cobran de más

**Lo que lograrás:** Reconocer los préstamos caros que buscan a quien no tiene historial y compararlos antes de firmar.

**Para empezar:** Lupita necesita 5,000 pesos para el uniforme de sus hijos. Una app le promete el dinero en 10 minutos, «sin buró y sin papeles». En una semana debe 7,800. En esta lección verás cómo pasa.

### Lo esencial (5 minutos)

#### «Sin buró» no es sin costo

Quien no tiene historial es blanco de préstamos rápidos con intereses muy altos y plazos de una o dos semanas. Algunas apps además piden acceso a tus contactos para presionarte.



#### Señales de alerta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Plazo muy corto | 7 a 15 días. | Difícil de pagar. |
| Piden tus contactos | Acceso a tu agenda y fotos. | Para presionarte. |
| No dicen el CAT | No te muestran el costo total. | Mala señal. |
| No está registrada | No aparece en CONDUSEF. | No la uses. |

#### Haz la cuenta antes

Pregunta cuánto pagarás **en total** y en cuánto tiempo. Si pides 5,000 y pagas 7,800 en una semana, el préstamo te cuesta 2,800: más de la mitad.



#### Un caso en un minuto

Lupita borró la app antes de aceptar. Pidió a su comadre esperar dos semanas y usó parte de su tanda. Si llega a necesitar crédito, comparará el costo total.

> **Idea clave:** antes de pedir prestado, pregunta cuánto pagarás en total; si no te lo dicen o piden tus contactos, no firmes.



#### Comprueba lo que entendiste

1. ¿Qué pregunta haces antes de cualquier préstamo?
*Respuesta:* Cuánto pagaré en total y en cuánto tiempo.

2. ¿Por qué una app pide tus contactos?
*Respuesta:* Para presionarte con tu familia si te atrasas.


#### Para recordar

- Pregunta el total.
- No des tus contactos.
- Verifica en CONDUSEF.



### Profundiza (5 minutos más)

#### El préstamo de la app

- Lo que pagarías: **7,800**
- Lo que te prestan: **5,000**
- Lo que cuesta, en una semana: **2,800**


#### Si ya te están acosando

Guarda capturas, no pagues a cuentas personales y presenta tu queja ante CONDUSEF. Si te amenazan, denuncia ante la Fiscalía. El módulo 8 lo ve a fondo.



#### Casos


**Caso 1. Los 10 minutos**

Una app le promete a Lupita 5,000 en 10 minutos sin papeles.
- *¿Qué hace?* Pregunta el total; como no se lo dicen, no la usa.


**Caso 2. Los contactos**

La app pide acceso a la agenda de Memo.
- *¿Qué hace?* Niega el permiso y la desinstala.


**Caso 3. El préstamo en la tienda**

La tienda de muebles ofrece a Chayo pagos «chiquitos».
- *¿Qué hace?* Suma todos los pagos y compara con el precio de contado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No preguntar el total | Pagas el doble | Pregunta siempre |
| Dar acceso a contactos | Acoso a tu familia | Niégalo |
| Usar apps no registradas | Sin a quién reclamar | Verifica |
| Ver solo el pago chiquito | Costo escondido | Suma todo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Memo y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te prestan 3,000 y pagas 4,500 en dos semanas. ¿Cuánto te cuesta? a) 4,500 · b) 1,500 · c) Nada
2. Una app pide tus contactos. ¿Qué haces? a) Lo niegas y no la usas · b) Lo aceptas · c) Le das los de tu familia
3. ¿Qué debe decirte cualquier préstamo antes de firmar? a) Solo el pago semanal · b) El nombre y el teléfono del cobrador · c) Cuánto pagarás en total
**Respuestas:** 1-b: 4,500 menos 3,000. 2-a: es para presionarte. 3-c: el total.



#### Ponlo en práctica

Te ofrecen 12 pagos semanales de 450 por un celular de 3,900 de contado. ¿Cuánto pagas de más?
**Respuesta:** 1,500 pesos (12 por 450 son 5,400).



#### A tu plan

Escribe tres formas de conseguir dinero urgente sin préstamos caros: ahorro, venta, apoyo, plazo con quien le debes.



### Para saber más

- **Apps de préstamo** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «apps de préstamos» y «SIPRES».

### Palabras clave

- *Plazo:* tiempo para pagar.
- *Costo total:* todo lo que pagas, menos lo que te prestaron.
- *Acoso de cobranza:* presión ilegal para que pagues.

### Fuentes

CONDUSEF, alertas sobre apps de préstamos y gestión de cobranza; consultados el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Lo que dejaste en Estados Unidos

## M4 U01. Tu último pago y tu cuenta de allá

**Lo que lograrás:** Recuperar el sueldo que te deben y decidir qué hacer con tu cuenta de banco en EE. UU.

**Para empezar:** A Don Rafa lo detuvieron un jueves; el viernes era día de pago. Su patrón le debe una semana y en su cuenta de Texas quedaron 1,400 dólares. Cree que ya los perdió. En esta lección verás que no necesariamente.

### Lo esencial (5 minutos)

#### Tu sueldo es tuyo

Lo que trabajaste se te debe pagar, aunque ya no estés en EE. UU. Puedes pedir al patrón que lo deposite en tu cuenta de allá o que mande un cheque a alguien de confianza. El consulado de México puede orientarte si el patrón no paga.



#### Tu cuenta de EE. UU.: opciones

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguir usándola | Con la app o la página del banco. | Revisa si cobra por inactividad. |
| Mandar el dinero a México | Transferencia o envío a tu cuenta de aquí. | Compara el costo. |
| Cerrarla | Pide el saldo por transferencia o cheque. | Hazlo por escrito. |

#### No la dejes olvidada

Una cuenta sin movimientos puede cobrar comisiones y, después de unos años, el dinero pasa al estado como «propiedad no reclamada». Se puede recuperar, pero es más trámite.



#### Un caso en un minuto

Don Rafa entró a la app de su banco desde México y transfirió 1,350 dólares a su FINABIEN. Su sobrino en Houston recogió el cheque de su última semana y se lo depositó.

> **Idea clave:** tu último sueldo y tu cuenta de allá siguen siendo tuyos; decide qué hacer con ellos pronto.



#### Comprueba lo que entendiste

1. ¿Pierdes tu último sueldo si te regresaron?
*Respuesta:* No: se te debe pagar; puedes pedirlo a tu patrón.

2. ¿Qué pasa con una cuenta olvidada por años?
*Respuesta:* Cobra comisiones y el dinero pasa al estado como propiedad no reclamada.


#### Para recordar

- Tu sueldo se te debe.
- Decide sobre tu cuenta.
- El consulado orienta.



### Profundiza (5 minutos más)

#### Lo que quedó allá: dinero

| Concepto | Monto | Quién me ayuda | Hecho |
|---|---|---|---|
| Último sueldo | | | |
| Saldo en cuenta | | | |
| Depósito de renta | | | |
| Dinero prestado a alguien | | | |



#### Propiedad no reclamada

Cada estado de EE. UU. tiene una página para buscar dinero no reclamado a tu nombre (cuentas, cheques, depósitos). Se busca sin costo; desconfía de quien cobra por buscar.



#### Casos


**Caso 1. El día de pago**

El patrón de Don Rafa le debe una semana.
- *¿Qué hace?* Le pide el pago por depósito o cheque a alguien de confianza.


**Caso 2. La cuenta olvidada**

Lupita dejó 300 dólares en una cuenta hace un año.
- *¿Qué hace?* Revisa si le cobran y decide si la usa o la cierra.


**Caso 3. «Te consigo tu dinero»**

Alguien ofrece a Memo recuperar su dinero si le da su contraseña del banco.
- *¿Qué hace?* No da su contraseña; lo hace él o con el consulado.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar por perdido el sueldo | Pierdes lo trabajado | Pídelo |
| Olvidar la cuenta | Comisiones | Decide pronto |
| Dar contraseñas | Te vacían la cuenta | Nunca |
| Pagar por buscar dinero no reclamado | Gasto innecesario | Es sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Lupita y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te deben una semana de sueldo en EE. UU. ¿Qué haces? a) Lo pides por depósito o cheque · b) Lo das por perdido · c) Le das tu contraseña a un gestor
2. ¿Qué puede pasar con una cuenta olvidada? a) Nada, nunca cambia · b) Cobra comisiones y pasa al estado · c) Te la cierran y te mandan el doble
3. ¿Quién puede orientarte si el patrón no paga? a) Un gestor de la plaza que conoce a los patrones · b) El consulado de México · c) Nadie
**Respuestas:** 1-a: es tuyo. 2-b: propiedad no reclamada. 3-b: el consulado orienta.



#### Ponlo en práctica

Tu cuenta de allá cobra 12 dólares al mes y tiene 150. ¿En cuántos meses queda vacía?
**Respuesta:** En 13 meses (12.5 redondeado hacia arriba).



#### A tu plan

Llena la tabla de lo que quedó allá y marca a quién le pedirás ayuda para cada cosa.



### Para saber más

- **Protección consular** (SRE · español): https://consulmex.sre.gob.mx — **Qué buscar:** «protección» y el consulado de la ciudad donde trabajaste.
- **Propiedad no reclamada** (NAUPA · inglés): https://unclaimed.org — **Qué buscar:** el estado donde viviste.

### Palabras clave

- *Último pago:* sueldo pendiente al terminar un trabajo.
- *Propiedad no reclamada:* dinero olvidado que guarda el estado.
- *Consulado:* oficina de México en otro país.

### Fuentes

SRE, protección consular; NAUPA, propiedad no reclamada; consultados el 5 de octubre de 2026.

---

## M4 U02. Tus impuestos de allá

**Lo que lograrás:** Comprobar si te conviene presentar tu declaración en EE. UU. para recuperar impuestos retenidos.

**Para empezar:** A Lupita le retenían impuestos en cada cheque del restaurante en Houston. Nunca hizo su declaración porque «para qué». En esta lección verás que puede haber dinero esperándote.

### Lo esencial (5 minutos)

#### La retención

Si trabajaste con nómina en EE. UU., te quitaron impuestos de cada pago. Al presentar tu declaración anual (taxes), a veces te regresan una parte: es tu **reembolso**.



#### Qué necesitas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Tu número | SSN o ITIN. | Con el que trabajaste. |
| Formas W-2 | Las que te dio el patrón. | Una por patrón. |
| El año | Cada declaración es por año. | Puedes presentar años pasados. |
| Tu dirección | Para que te llegue el cheque. | Puede ser en México. |

#### El reembolso puede llegar a México

El IRS no deposita en cuentas de México. Pero puede mandar un cheque por correo a tu dirección o a la de alguien de confianza en EE. UU. Generalmente tienes hasta tres años para reclamar un reembolso.



#### Un caso en un minuto

Lupita pidió a su antiguo patrón sus formas W-2. Con ayuda de una organización del consulado presentó dos años. Le llegó un cheque a casa de su hermana en Houston.

> **Idea clave:** si te retuvieron impuestos, presenta tu declaración; puede haber un reembolso para ti.



#### Comprueba lo que entendiste

1. ¿Qué es el reembolso?
*Respuesta:* Parte de los impuestos retenidos que te regresan al declarar.

2. ¿Hasta cuándo puedes reclamarlo?
*Respuesta:* Generalmente hasta tres años.


#### Para recordar

- Te retuvieron impuestos.
- Pide tus W-2.
- Tienes unos tres años.



### Profundiza (5 minutos más)

#### Tus años de trabajo

| Año | Patrón | W-2 | ¿Declaré? |
|---|---|---|---|
| | | | |
| | | | |



#### Cuidado con quien «te saca más»

Hay preparadores que prometen reembolsos enormes y cobran un porcentaje. Si inventan datos, el problema es tuyo. Busca ayuda en programas gratuitos o a través del consulado.



#### Casos


**Caso 1. «Para qué»**

Lupita nunca declaró.
- *¿Qué hace?* Pide sus W-2 y revisa si tiene reembolso.


**Caso 2. Sin W-2**

Don Rafa no tiene sus formas.
- *¿Qué hace?* Se las pide al patrón o al IRS con su número.


**Caso 3. El preparador milagroso**

Le ofrecen a Memo «el doble de reembolso» por 30%.
- *¿Qué hace?* Busca ayuda gratuita y no inventa datos.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No declarar | Pierdes tu reembolso | Revisa |
| Esperar muchos años | Se vence | Unos tres años |
| Inventar datos | Multas | Solo datos reales |
| Pagar porcentajes altos | Pierdes tu dinero | Ayuda gratuita |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Don Rafa y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué forma te da el patrón con lo que ganaste y te retuvieron? a) La W-2 · b) La CURP · c) El recibo de renta
2. ¿El IRS deposita en una cuenta de México? a) Sí, siempre · b) Solo en una cuenta FINABIEN Paisano · c) No; manda un cheque por correo
3. ¿Generalmente cuánto tiempo tienes para reclamar un reembolso? a) Un mes · b) Unos tres años · c) Para siempre, no hay fecha límite
**Respuestas:** 1-a: la W-2. 2-c: cheque por correo. 3-b: unos tres años.



#### Ponlo en práctica

Te retuvieron 2,400 dólares y lo que debías de impuestos era 1,700. ¿Cuánto sería tu reembolso?
**Respuesta:** 700 dólares.



#### A tu plan

Anota los años que trabajaste con nómina y a qué patrón le pedirás cada W-2.



### Para saber más

- **Reembolsos** (IRS · español): https://www.irs.gov/es — **Qué buscar:** «reembolso» y «contribuyentes en el extranjero».
- **Protección consular** (SRE · español): https://consulmex.sre.gob.mx — **Qué buscar:** «ventanillas de asesoría financiera».

### Palabras clave

- *Retención:* impuesto que te quitan de cada pago.
- *Reembolso:* lo que te regresan si pagaste de más.
- *W-2:* forma con tu sueldo y retenciones del año.

### Fuentes

IRS, reembolsos y plazo para reclamarlos; consultado el 5 de octubre de 2026.

---

## M4 U03. Tu retiro de allá: 401(k) y Seguro Social

**Lo que lograrás:** Comprobar si dejaste dinero de retiro en EE. UU. y a quién preguntar para no perderlo.

**Para empezar:** Memo trabajó cinco años en una bodega con 401(k). Un amigo le dijo que, si sacaba todo ya, «se lo quedaba el gobierno». En esta lección verás qué preguntar antes de decidir.

### Lo esencial (5 minutos)

#### El 401(k) es tuyo

Si tu patrón tenía plan 401(k) y tú aportabas, ese dinero es tuyo. Puedes dejarlo, moverlo o retirarlo. Si lo retiras antes de los 59 años y medio, normalmente hay una penalización y te retienen impuestos.



#### Antes de retirar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Cuánto tengo? | Saldo del plan. | Al administrador. |
| ¿Cuánto me retienen? | Impuestos y penalización. | Por escrito. |
| ¿Puedo dejarlo? | Seguir con el dinero invertido. | Y retirarlo después. |
| ¿Cómo me pagan? | Transferencia o cheque. | A tu nombre. |

#### El Seguro Social de EE. UU.

Si trabajaste con un número de Seguro Social válido, tus aportaciones quedaron registradas. Con 40 créditos (unos 10 años) podrías tener derecho a una pensión al llegar a la edad. Las reglas para cobrarla viviendo en México dependen de tu caso: pregunta en la Unidad de Beneficios Federales de la Embajada de EE. UU.



#### Un caso en un minuto

Memo llamó al administrador del plan. Le explicaron cuánto le retendrían. Decidió dejar el dinero invertido y no tocarlo hasta tener empleo estable.

> **Idea clave:** tu retiro de allá sigue siendo tuyo; pregunta cuánto te retienen antes de sacarlo.



#### Comprueba lo que entendiste

1. ¿Qué pasa si retiras tu 401(k) antes de los 59 años y medio?
*Respuesta:* Normalmente hay penalización y retención de impuestos.

2. ¿Dónde preguntas por tu Seguro Social de EE. UU.?
*Respuesta:* En la Unidad de Beneficios Federales de la Embajada.


#### Para recordar

- Tu 401(k) es tuyo.
- Pregunta retenciones.
- Seguro Social: pregunta tu caso.



### Profundiza (5 minutos más)

#### Tu retiro de allá

| Plan | Administrador | Saldo | Decisión |
|---|---|---|---|
| 401(k) | | | |
| Seguro Social | | Créditos: | |



#### No lo saques por miedo

Sacar todo de golpe por miedo a perderlo puede costarte una buena parte en penalización e impuestos. Infórmate primero; el dinero no desaparece por vivir en México.



#### Casos


**Caso 1. «Se lo queda el gobierno»**

A Memo le dicen que saque todo ya.
- *¿Qué hace?* Pregunta al administrador cuánto le retendrían antes de decidir.


**Caso 2. Diez años en la construcción**

Don Rafa trabajó 10 años con número de Seguro Social.
- *¿Qué hace?* Pregunta en la Embajada si tiene derecho y cómo cobrarlo.


**Caso 3. El asesor por WhatsApp**

Le escriben a Lupita para «mover su retiro» si da sus datos.
- *¿Qué hace?* No da datos; habla directo con el administrador del plan.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sacar todo por miedo | Penalización | Pregunta antes |
| Olvidar el plan | Dinero perdido | Anota el administrador |
| Dar datos por WhatsApp | Robo | Solo con el plan |
| Creer que no tienes derecho | No preguntas | Pregunta tu caso |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Memo, Don Rafa y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Tu 401(k) es de… a) Tu patrón · b) Ti · c) El gobierno de EE. UU.
2. Retiras tu 401(k) a los 35 años. ¿Qué pasa normalmente? a) Te dan un bono por sacarlo antes de tiempo · b) Nada · c) Pagas penalización y retención
3. ¿Cuántos créditos suelen pedirse para una pensión del Seguro Social de EE. UU.? a) 40 · b) 4 · c) 400
**Respuestas:** 1-b: es tuyo. 2-c: antes de 59 y medio. 3-a: unos 10 años.



#### Ponlo en práctica

Tienes 8,000 dólares en tu 401(k). Si te retienen y penalizan 30% en total, ¿cuánto recibirías?
**Respuesta:** 5,600 dólares.



#### A tu plan

Anota el nombre del administrador de tu plan y llama para preguntar las cuatro cosas antes de decidir.



### Para saber más

- **Unidad de Beneficios Federales** (Embajada de EE. UU. en México · español): https://mx.usembassy.gov/es — **Qué buscar:** «Federal Benefits Unit» o «beneficios federales».
- **Seguro Social** (SSA · español): https://www.ssa.gov/espanol — **Qué buscar:** «pagos fuera de EE. UU.».

### Palabras clave

- *401(k):* plan de retiro de un empleo en EE. UU.
- *Penalización:* cobro extra por retirar antes de tiempo.
- *Crédito del Seguro Social:* unidad que cuenta tu trabajo cotizado.

### Fuentes

IRS, retiros anticipados de planes de retiro; SSA, pagos fuera de EE. UU.; consultados el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Tu Afore, tu IMSS y tus semanas

## M5 U01. ¿Tienes Afore? Encuéntrala

**Lo que lograrás:** Comprobar si tienes una cuenta de Afore de cuando trabajaste en México y localizarla.

**Para empezar:** Antes de irse, Don Rafa trabajó seis años en una fábrica en Morelia con IMSS. No sabe si ese dinero «se perdió». En esta lección verás cómo encontrarlo.

### Lo esencial (5 minutos)

#### Tu Afore te espera

Si trabajaste en México con IMSS después de 1997, tienes una cuenta de Afore con tu nombre. El dinero no se pierde por irte: sigue ahí y genera rendimientos.



#### Cómo localizarla

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| App AforeMóvil | Con tu CURP. | Te dice en qué Afore estás. |
| e-SAR | Página de la CONSAR. | Localiza tu Afore. |
| SARTEL | 55 1328 5000. | Sin costo. |

#### Si nunca trabajaste formal

Si no tienes Afore, puedes abrir una con tu CURP en la app AforeMóvil, incluso si trabajas por tu cuenta. Así empiezas a ahorrar para tu retiro (U03).



#### Un caso en un minuto

Don Rafa descargó AforeMóvil, puso su CURP y apareció su cuenta con el ahorro de sus seis años en la fábrica. Actualizó su teléfono y su domicilio.

> **Idea clave:** si trabajaste formal en México, tu Afore sigue ahí; localízala con tu CURP.



#### Comprueba lo que entendiste

1. ¿Se pierde tu Afore si te fuiste a EE. UU.?
*Respuesta:* No: sigue ahí a tu nombre.

2. ¿Qué necesitas para localizarla?
*Respuesta:* Tu CURP.


#### Para recordar

- Tu Afore no se pierde.
- Localízala con tu CURP.
- Actualiza tus datos.



### Profundiza (5 minutos más)

#### Tu Afore

| Dato | Lo tengo |
|---|---|
| Afore donde estoy | |
| Saldo aproximado | |
| Beneficiarios registrados | |
| Datos de contacto al día | |



#### Registra a tus beneficiarios

Son las personas que recibirían tu ahorro si faltas. Revísalos en tu Afore; si los pusiste hace años, quizá ya no son los que quieres.



#### Casos


**Caso 1. «Se perdió»**

Don Rafa cree que perdió su ahorro de la fábrica.
- *¿Qué hace?* Lo busca con su CURP en AforeMóvil.


**Caso 2. Nunca formal**

Memo nunca trabajó formal en México.
- *¿Qué hace?* Abre su Afore con su CURP para empezar a ahorrar.


**Caso 3. El gestor de Afores**

Le ofrecen a Chayo «sacar» la Afore de su esposo por una comisión.
- *¿Qué hace?* No paga: la consulta es gratuita y él la hace con su CURP.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar por perdida la Afore | Dinero olvidado | Búscala |
| No actualizar datos | No te localizan | Actualiza |
| Beneficiarios viejos | El dinero va a quien no quieres | Revísalos |
| Pagar a gestores | Fraude | Es sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Memo y Chayo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Trabajaste en México con IMSS en 2005. ¿Tienes Afore? a) Probablemente sí · b) No, se borró · c) Solo si vives en México desde entonces
2. ¿Con qué localizas tu Afore? a) Con tu licencia de EE. UU. · b) Con tu CURP · c) Con tu recibo de luz
3. ¿Qué son los beneficiarios? a) Los que recibirían tu ahorro si faltas · b) Los dueños y directivos de la Afore · c) Tus jefes
**Respuestas:** 1-a: si cotizaste, la tienes. 2-b: con la CURP. 3-a: quienes la reciben.



#### Ponlo en práctica

¿Qué dos cosas revisas al encontrar tu Afore, además del saldo?
**Respuesta:** Tus datos de contacto y tus beneficiarios.



#### A tu plan

Localiza tu Afore con tu CURP y llena la tabla.



### Para saber más

- **Localiza tu Afore** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «localiza tu Afore» y «AforeMóvil». SARTEL 55 1328 5000.

### Palabras clave

- *Afore:* administradora de tu ahorro para el retiro.
- *Rendimiento:* lo que gana tu ahorro con el tiempo.
- *Beneficiario:* persona que recibe tu ahorro si faltas.

### Fuentes

CONSAR, localización de cuentas y AforeMóvil; consultados el 5 de octubre de 2026.

---

## M5 U02. Tus semanas cotizadas

**Lo que lograrás:** Consultar tus semanas cotizadas en el IMSS y saber cuántas te faltan para una pensión.

**Para empezar:** Chayo escuchó que su esposo «ya no alcanza pensión porque se fue muchos años». Nadie ha revisado cuántas semanas tiene. En esta lección verás cómo hacerlo.

### Lo esencial (5 minutos)

#### Las semanas no se borran

Cada semana que trabajaste con IMSS en México se queda registrada. Al irte se detuvo el conteo, pero no se perdió. Puedes consultarlo sin costo en la página del IMSS con tu CURP y tu número de seguridad social.



#### ¿Qué ley te toca?

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ley 73 | Empezaste a cotizar antes del 1 de julio de 1997. | Pide 500 semanas. |
| Ley 97 | Empezaste después. | En 2026 pide 875 semanas. |

#### La Ley 97 sube cada año

Para la Ley 97, el requisito sube 25 semanas cada año hasta llegar a 1,000 en 2031. Si te faltan semanas, puedes volver a cotizar con un empleo formal o por tu cuenta (U03).



#### Un caso en un minuto

El esposo de Chayo consultó: tiene 610 semanas y empezó en 1993, así que es Ley 73. Ya rebasa las 500. Al cumplir la edad podrá revisar su pensión.

> **Idea clave:** tus semanas no se borran; consúltalas y averigua qué ley te toca.



#### Comprueba lo que entendiste

1. ¿Qué pasa con tus semanas al irte a EE. UU.?
*Respuesta:* Se quedan registradas; el conteo se detiene, pero no se borran.

2. ¿Cuántas semanas pide la Ley 97 en 2026?
*Respuesta:* 875.


#### Para recordar

- Las semanas no se borran.
- Ley 73: 500.
- Ley 97: 875 en 2026.



### Profundiza (5 minutos más)

#### Cuántas le faltan a Don Rafa (Ley 97)

- Requisito en 2026: **875**
- Semanas que tiene: **312**
- Semanas que le faltan: **563**


#### Unas 52 semanas por año

Un año completo de trabajo formal suma unas 52 semanas. Para 563 semanas se necesitan casi 11 años; por eso conviene empezar pronto.



#### Casos


**Caso 1. «Ya no alcanza»**

A Chayo le dicen que su esposo perdió todo.
- *¿Qué hace?* Consultan sus semanas en el IMSS con su CURP.


**Caso 2. ¿Qué ley?**

Don Rafa empezó a trabajar formal en 2001.
- *¿Qué hace?* Sabe que le toca Ley 97 y calcula cuántas le faltan.


**Caso 3. Le faltan semanas**

A Don Rafa le faltan más de 500 semanas.
- *¿Qué hace?* Busca un empleo formal o cotizar por su cuenta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que se borraron | No las cobras | Consulta |
| Confundir la ley | Cuentas mal | Revisa la fecha de inicio |
| Esperar a los 60 | Ya no da tiempo | Empieza pronto |
| Pagar por la consulta | Fraude | Es sin costo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo y Don Rafa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Empezaste a cotizar en 1990. ¿Qué ley te toca? a) Ley 97 · b) Ley 73 · c) Ninguna
2. ¿Cuántas semanas pide la Ley 97 en 2026? a) 500 · b) 1,250 · c) 875
3. ¿Cuántas semanas suma un año completo de trabajo formal? a) Unas 52 · b) 12 · c) 365, una por cada día del año
**Respuestas:** 1-b: antes de julio de 1997. 2-c: 875. 3-a: unas 52.



#### Ponlo en práctica

Tienes 700 semanas y eres Ley 97. ¿Cuántas te faltan en 2026?
**Respuesta:** 175.



#### A tu plan

Consulta tus semanas en la página del IMSS y escribe cuántas tienes y qué ley te toca.



### Para saber más

- **Constancia de semanas cotizadas** (IMSS · español): https://serviciosdigitales.imss.gob.mx — **Qué buscar:** «semanas cotizadas».

### Palabras clave

- *Semanas cotizadas:* semanas trabajadas con IMSS.
- *Ley 73 y Ley 97:* reglas de pensión según cuándo empezaste a cotizar.
- *NSS:* número de seguridad social.

### Fuentes

IMSS, constancia de semanas cotizadas y requisitos de pensión Ley 73 y Ley 97; consultados el 5 de octubre de 2026.

---

## M5 U03. Ahorra para tu retiro aunque trabajes por tu cuenta

**Lo que lograrás:** Hacer aportaciones voluntarias a tu Afore y conocer cómo afiliarte al IMSS si trabajas por tu cuenta.

**Para empezar:** Don Rafa ahora hace trabajos de albañilería por su cuenta. No tiene patrón ni IMSS. Cree que el retiro «ya no es para él». En esta lección verás que sí puede hacer algo.

### Lo esencial (5 minutos)

#### Aportaciones voluntarias

Puedes depositar a tu Afore desde 50 pesos en tiendas de conveniencia, en la app AforeMóvil o por domiciliación. Ese dinero es tuyo y suma a tu retiro.



#### Formas de ahorrar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En la tienda | Desde 50 pesos. | Con tu CURP. |
| En la app | AforeMóvil. | Cuando quieras. |
| Domiciliado | Un monto fijo de tu cuenta. | Automático. |

#### IMSS si trabajas por tu cuenta

Las personas trabajadoras independientes pueden afiliarse al IMSS de forma voluntaria y pagar su cuota. Les da servicio médico y les cuenta semanas. Revisa los requisitos y el costo en la página del IMSS.



#### Un caso en un minuto

Don Rafa decidió apartar 200 pesos cada quincena para su Afore en la tienda. En un año habrá ahorrado 4,800 pesos más rendimientos.

> **Idea clave:** aunque trabajes por tu cuenta, puedes ahorrar en tu Afore desde 50 pesos.



#### Comprueba lo que entendiste

1. ¿Desde cuánto puedes hacer una aportación voluntaria en tienda?
*Respuesta:* Desde 50 pesos.

2. ¿Qué te da afiliarte al IMSS como independiente?
*Respuesta:* Servicio médico y semanas cotizadas.


#### Para recordar

- Desde 50 pesos.
- Tienda, app o domiciliado.
- IMSS voluntario existe.



### Profundiza (5 minutos más)

#### El ahorro de Don Rafa

- Por quincena: **200**
- Quincenas al año: **24**
- En un año, más rendimientos: **4,800**


#### Aportaciones de largo plazo

Las aportaciones voluntarias pueden tener beneficios fiscales si las dejas hasta el retiro. Pregunta a tu Afore qué tipo de aportación te conviene.



#### Casos


**Caso 1. «No es para mí»**

Don Rafa cree que sin patrón no puede ahorrar para el retiro.
- *¿Qué hace?* Aporta a su Afore cada quincena en la tienda.


**Caso 2. Sin servicio médico**

Lupita trabaja vendiendo comida y no tiene IMSS.
- *¿Qué hace?* Revisa los requisitos para afiliarse como independiente.


**Caso 3. Ahorro con un conocido**

Un conocido ofrece a Memo guardar su ahorro de retiro «con buen interés».
- *¿Qué hace?* Ahorra en su Afore, que está a su nombre.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Creer que no puedes | No ahorras | Desde 50 pesos |
| Esperar a tener patrón | Pierdes años | Empieza ya |
| Ahorro con conocidos | Riesgo de perderlo | En tu Afore |
| No revisar el IMSS voluntario | Sin servicio médico | Infórmate |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Lupita y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Dónde puedes aportar a tu Afore? a) Solo en el banco donde te depositaba el patrón · b) En tienda, app o domiciliado · c) Solo al jubilarte
2. Ahorras 100 pesos por semana en tu Afore. ¿Cuánto en un año? a) 1,200 · b) 5,200 · c) 520
3. ¿Qué te da afiliarte al IMSS como independiente? a) Un préstamo · b) Una tarjeta de crédito con límite según tu cuota · c) Servicio médico y semanas
**Respuestas:** 1-b: tienes tres formas. 2-b: 52 semanas por 100. 3-c: servicio médico y semanas.



#### Ponlo en práctica

Aportas 300 pesos al mes. ¿Cuánto en dos años, sin contar rendimientos?
**Respuesta:** 7,200 pesos.



#### A tu plan

Decide cuánto aportarás a tu Afore y cada cuándo. Escríbelo y haz la primera aportación.



### Para saber más

- **Ahorro voluntario** (CONSAR · español): https://www.gob.mx/consar — **Qué buscar:** «ahorro voluntario».
- **Personas trabajadoras independientes** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «personas trabajadoras independientes».

### Palabras clave

- *Aportación voluntaria:* dinero que tú agregas a tu Afore.
- *Domiciliación:* cargo automático a tu cuenta.
- *Trabajador independiente:* quien trabaja sin patrón.

### Fuentes

CONSAR, ahorro voluntario; IMSS, incorporación de personas trabajadoras independientes; consultados el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Tus primeros 90 días

## M6 U01. Piensa en pesos: tu presupuesto de regreso

**Lo que lograrás:** Hacer un presupuesto en pesos para tus primeros 90 días, con lo que de verdad entra y sale.

**Para empezar:** Memo ganaba 18 dólares la hora en EE. UU. En Puebla le ofrecen 2,400 pesos a la semana. Hace cuentas en dólares y siente que «no le alcanza para nada». En esta lección verás cómo hacer cuentas que sí sirven.

### Lo esencial (5 minutos)

#### Cambia el chip

Comparar tu sueldo de allá con el de aquí solo te desanima: los precios también son distintos. Haz tus cuentas en pesos, con los precios de tu comunidad.



#### Tu presupuesto de 90 días

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo que entra | Sueldo, trabajos, apoyos, ahorro que traes. | Solo lo seguro. |
| Lo básico | Comida, techo, transporte, salud. | Primero. |
| Papeles | Actas, copias, traslados. | Gasto de una vez. |
| Un guardadito | Para imprevistos. | Aunque sea poco. |

#### Tres meses, no uno

Los primeros meses casi siempre entra menos de lo que esperas. Planea para 90 días y cuenta solo el dinero que es seguro, no el que «a lo mejor» llega.



#### Un caso en un minuto

Memo anotó lo que gasta en Puebla: renta compartida, comida y camión suman 7,600 al mes. Con 2,400 a la semana le entran unos 10,400. Le quedan 2,800 para papeles y su guardadito.

> **Idea clave:** haz tus cuentas en pesos y para 90 días, con lo que es seguro.



#### Comprueba lo que entendiste

1. ¿Por qué no comparar tu sueldo en dólares con el de aquí?
*Respuesta:* Porque los precios también son distintos; sirve hacer las cuentas en pesos.

2. ¿Qué dinero cuentas en tu presupuesto?
*Respuesta:* Solo el que es seguro.


#### Para recordar

- Cuentas en pesos.
- Planea 90 días.
- Solo lo seguro.



### Profundiza (5 minutos más)

#### El mes de Memo

- Le entra (2,400 por semana, unas 4.3 semanas): **10,400**
- Renta compartida: **2,500**
- Comida: **3,600**
- Transporte: **1,500**
- Para papeles y guardadito: **2,800**


#### Tus 90 días

| Concepto | Mes 1 | Mes 2 | Mes 3 |
|---|---|---|---|
| Entra | | | |
| Comida | | | |
| Techo | | | |
| Transporte | | | |
| Papeles | | | |
| Guardadito | | | |



#### Casos


**Caso 1. Los 18 dólares**

Memo compara su sueldo de allá con el de aquí.
- *¿Qué hace?* Hace su presupuesto en pesos con los precios de Puebla.


**Caso 2. El trabajo prometido**

A Don Rafa le prometen trabajo «en un mes».
- *¿Qué hace?* No lo cuenta hasta que sea seguro.


**Caso 3. Todo en el primer mes**

Lupita quiere gastar todo su ahorro en amueblar la casa.
- *¿Qué hace?* Reparte su ahorro para los tres meses.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pensar en dólares | Te desanimas | Cuentas en pesos |
| Contar dinero no seguro | Te quedas corto | Solo lo seguro |
| Planear un mes | Se acaba el ahorro | 90 días |
| Olvidar los papeles | Gastos sorpresa | Inclúyelos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Memo, Don Rafa y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Para cuánto tiempo planeas al regresar? a) Una semana · b) 90 días · c) Un día
2. Te prometen trabajo «en un mes». ¿Lo cuentas? a) Sí, todo · b) La mitad, por si acaso sí te contratan · c) No, hasta que sea seguro
3. ¿Cómo haces tus cuentas? a) En pesos con precios de aquí · b) En dólares · c) Con los precios de allá, para comparar mejor
**Respuestas:** 1-b: los primeros meses. 2-c: solo lo seguro. 3-a: en pesos.



#### Ponlo en práctica

Te entran 9,000 al mes y gastas 7,200 en lo básico. ¿Cuánto te queda?
**Respuesta:** 1,800 pesos.



#### A tu plan

Llena tu tabla de 90 días con lo que entra seguro y lo básico.



### Para saber más

- **Presupuesto** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «presupuesto personal».

### Palabras clave

- *Presupuesto:* plan de lo que entra y sale.
- *Ingreso seguro:* dinero que sabes que llega.
- *Guardadito:* ahorro pequeño para imprevistos.

### Fuentes

CONDUSEF, herramientas de presupuesto; consultado el 5 de octubre de 2026.

---

## M6 U02. Los compromisos de bienvenida

**Lo que lograrás:** Poner límites amables a los gastos y préstamos que te piden al regresar.

**Para empezar:** Al llegar, a Don Rafa le organizaron una fiesta de bienvenida que él pagó. Luego su compadre le pidió prestado «porque viene de allá». En dos semanas se le fue la mitad de su ahorro. En esta lección verás cómo decir que no sin pelear.

### Lo esencial (5 minutos)

#### «Vienes con dólares»

Mucha gente cree que quien regresa trae dinero. A veces es cierto; muchas veces no. Tu ahorro tiene que durar hasta que tengas ingreso.



#### Tres respuestas que ayudan

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| «Ahorita no puedo» | Sin explicar de más. | Corto y amable. |
| «Cuando tenga trabajo» | Cambia el cuándo. | Sin prometer monto. |
| «Te ayudo con otra cosa» | Tiempo, contactos, oficio. | No solo dinero. |

#### Decide un monto antes

Si quieres ayudar, decide antes cuánto puedes dar sin poner en riesgo tus 90 días. Dalo como regalo, no como préstamo que te va a doler cobrar.



#### Un caso en un minuto

Don Rafa decidió que podía dar 500 pesos al mes a su mamá y nada más. A su compadre le dijo: «Ahorita no, cuando tenga trabajo vemos». Su ahorro le alcanzó tres meses.

> **Idea clave:** tu ahorro de regreso tiene que durar; decide antes cuánto puedes ayudar y di que no con amabilidad.



#### Comprueba lo que entendiste

1. ¿Por qué cuidar tu ahorro al regresar?
*Respuesta:* Porque tiene que durar hasta que tengas ingreso.

2. ¿Cómo ayudar sin desbalancearte?
*Respuesta:* Decides antes un monto y lo das como regalo.


#### Para recordar

- Tu ahorro tiene que durar.
- Decide un monto.
- Di que no con amabilidad.



### Profundiza (5 minutos más)

#### Lo que se fue en dos semanas

- Ahorro de Don Rafa: **8,000**
- Fiesta de bienvenida: **2,500**
- Préstamo al compadre: **1,500**
- Le quedaba la mitad: **4,000**


#### No es egoísmo

Cuidar tu ahorro también cuida a tu familia: si te quedas sin nada, después alguien tendrá que ayudarte a ti.



#### Casos


**Caso 1. La fiesta**

La familia de Don Rafa quiere una fiesta que pagaría él.
- *¿Qué hace?* Propone algo sencillo y pone un tope.


**Caso 2. El compadre**

El compadre le pide 1,500 «porque viene de allá».
- *¿Qué hace?* Le dice «ahorita no, cuando tenga trabajo vemos».


**Caso 3. La mamá de Lupita**

Lupita quiere ayudar a su mamá cada mes.
- *¿Qué hace?* Decide un monto fijo que no ponga en riesgo sus 90 días.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar todo por compromiso | Ahorro que se va | Pon un tope |
| Prestar sin pensar | Difícil de cobrar | Regalo o nada |
| Explicar de más | Te convencen | Respuesta corta |
| Sentir culpa | Cedes | Cuidar tu ahorro cuida a todos |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, su compadre y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te piden prestado al llegar. ¿Qué te ayuda? a) Prestar todo · b) Una respuesta corta y amable · c) Pedir prestado para poder prestar a tu familia
2. ¿Cuándo decides cuánto ayudar? a) Antes, según tus 90 días · b) Cuando te lo pidan, según lo que necesite cada quien · c) Nunca
3. Si ayudas con dinero, conviene darlo como… a) Préstamo con intereses · b) Adelanto · c) Regalo que puedes dar
**Respuestas:** 1-b: corta y amable. 2-a: antes. 3-c: sin esperar cobrarlo.



#### Ponlo en práctica

Tienes 9,000 de ahorro y necesitas 2,500 al mes para completar tus gastos. ¿Cuánto puedes regalar en tres meses sin quedarte corto?
**Respuesta:** 1,500 pesos.



#### A tu plan

Escribe cuánto puedes dar al mes y tu frase para decir que no.



### Para saber más

- **Finanzas en familia** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «prestar dinero a familiares».

### Palabras clave

- *Tope:* lo máximo que vas a gastar.
- *Compromiso:* gasto que sientes que te toca hacer.
- *Límite:* hasta dónde puedes llegar sin dañarte.

### Fuentes

CONDUSEF, recomendaciones sobre préstamos entre familiares; consultado el 5 de octubre de 2026.

---

## M6 U03. Cuando dejan de llegar las remesas

**Lo que lograrás:** Reorganizar el gasto de la casa cuando el familiar que mandaba dinero regresa o deja de enviar.

**Para empezar:** Chayo recibía 300 dólares al mes de su esposo. Ahora él regresó y no hay remesa. Los recibos y la escuela siguen llegando. En esta lección verás cómo ajustar la casa entre los dos.

### Lo esencial (5 minutos)

#### La casa cambia de números

Si la casa dependía de la remesa, hay que hacer un presupuesto nuevo con lo que entra ahora. En 2025 las remesas a México bajaron 4.6%: muchas familias están en la misma situación.



#### Cuatro pasos en familia

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Lo que entra hoy | Sueldos, apoyos, ventas. | De todos. |
| Qué se recorta | Lo que no es básico. | Juntos. |
| Qué no se toca | Comida, escuela, salud. | Prioridad. |
| Revisión mensual | Cómo vamos. | En familia. |

#### Revisa los apoyos

Algunas familias tienen derecho a becas o programas que no han pedido. Revisa en tu municipio y en los programas del Bienestar.



#### Un caso en un minuto

Chayo y su esposo sumaron lo que entra: ventas de ella y trabajos de él. Recortaron el cable y el celular caro. Inscribieron a su hija a la beca de secundaria. Les alcanza, justo.

> **Idea clave:** si la remesa se acaba, hagan un presupuesto nuevo en familia y protejan lo básico.



#### Comprueba lo que entendiste

1. ¿Qué gastos no se tocan?
*Respuesta:* Comida, escuela y salud.

2. ¿Qué pueden revisar además de recortar?
*Respuesta:* Apoyos o becas a los que tengan derecho.


#### Para recordar

- Presupuesto nuevo.
- Lo básico primero.
- Revisa apoyos.



### Profundiza (5 minutos más)

#### La casa de Chayo

- Ventas de Chayo: **6,000**
- Trabajos de él: **4,500**
- Lo que entra hoy: **10,500**


#### Hablar sin culpas

La remesa no se acabó por culpa de nadie. Hablar con números ayuda a decidir juntos en vez de pelear.



#### Casos


**Caso 1. Sin remesa**

Chayo ya no recibe los 300 dólares.
- *¿Qué hace?* Hace con su esposo un presupuesto nuevo.


**Caso 2. El cable y la escuela**

No alcanza para todo.
- *¿Qué hace?* Recortan lo que no es básico y cuidan la escuela.


**Caso 3. La beca**

Su hija podría tener beca y no la han pedido.
- *¿Qué hace?* Revisa los requisitos y la solicita.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Seguir gastando igual | Deudas | Presupuesto nuevo |
| Recortar escuela o salud | Daño mayor | Protégelas |
| Culparse | Peleas | Hablen con números |
| No revisar apoyos | Dinero que no llega | Infórmate |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Chayo y su familia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Se acabó la remesa. ¿Qué hacen primero? a) Un presupuesto nuevo con lo que entra hoy · b) Piden un préstamo para seguir gastando como antes · c) Siguen igual
2. ¿Qué gasto se protege? a) El cable · b) La escuela · c) El celular caro
3. ¿Qué más pueden revisar? a) Nada · b) Las apuestas en línea para recuperar lo de la remesa · c) Apoyos o becas a los que tengan derecho
**Respuestas:** 1-a: con números reales. 2-b: es básico. 3-c: puede haber apoyos.



#### Ponlo en práctica

Entran 10,500 y lo básico cuesta 9,200. ¿Cuánto queda para lo demás?
**Respuesta:** 1,300 pesos.



#### A tu plan

Siéntense en familia y llenen juntos lo que entra hoy y lo básico. Fijen una fecha para revisar cada mes.



### Para saber más

- **Programas para el Bienestar** (Gobierno de México · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «becas» y «requisitos».

### Palabras clave

- *Remesa:* dinero que manda un familiar desde otro país.
- *Recorte:* gasto que se quita o se baja.
- *Beca:* apoyo para estudiar.

### Fuentes

Banco de México, ingresos por remesas 2025; Secretaría de Bienestar; consultados el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Trabajo o negocio con lo que sabes hacer

## M7 U01. Lo que sabes hacer vale

**Lo que lograrás:** Hacer la lista de tus habilidades y saber cómo demostrarlas para conseguir trabajo.

**Para empezar:** Don Rafa sabe instalar tablaroca, leer planos en inglés y manejar una cuadrilla. En la entrevista solo dijo «le hago a todo». No lo llamaron. En esta lección verás cómo contar lo que sabes.

### Lo esencial (5 minutos)

#### Tu experiencia es tu capital

Los años en EE. UU. te dejaron oficios, inglés, disciplina y trato con clientes. Eso vale aquí, pero tienes que decirlo con claridad y, si se puede, demostrarlo.



#### Tu lista de lo que sabes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Oficio | Construcción, cocina, limpieza, mecánica. | Con años. |
| Idioma | Inglés hablado o escrito. | Muy buscado. |
| Mando | Coordinar personas. | Supervisión. |
| Pruebas | Fotos, cartas, certificados. | Lo que demuestra. |

#### Dónde buscar

El Servicio Nacional de Empleo tiene bolsa de trabajo y atiende a personas repatriadas. Además, el CONOCER puede certificar lo que ya sabes hacer, aunque no tengas título.



#### Un caso en un minuto

Don Rafa escribió: «12 años en tablaroca, leo planos, coordiné cuadrillas de 8, hablo inglés». Llevó fotos de sus obras. En la siguiente entrevista lo contrataron como encargado.

> **Idea clave:** haz la lista de lo que sabes hacer y llévala con pruebas.



#### Comprueba lo que entendiste

1. ¿Qué te dejaron los años en EE. UU.?
*Respuesta:* Oficios, idioma, disciplina y trato con clientes.

2. ¿Quién puede certificar lo que sabes sin título?
*Respuesta:* El CONOCER.


#### Para recordar

- Haz tu lista.
- Lleva pruebas.
- SNE y CONOCER.



### Profundiza (5 minutos más)

#### Tu lista

| Lo que sé hacer | Años | Prueba |
|---|---|---|
| | | |
| | | |
| | | |



#### El inglés abre puertas

Centros de atención telefónica, turismo y empresas que exportan buscan personas que hablen inglés. Si lo hablas, ponlo primero.



#### Casos


**Caso 1. «Le hago a todo»**

Don Rafa no dice qué sabe hacer.
- *¿Qué hace?* Escribe su lista con oficio, años y pruebas.


**Caso 2. El inglés de Memo**

Memo habla inglés como nativo, pero no lo pone en su solicitud.
- *¿Qué hace?* Lo pone primero y busca trabajos que lo pidan.


**Caso 3. Sin título**

Lupita cocinó 10 años en un restaurante, pero no tiene papel que lo diga.
- *¿Qué hace?* Busca certificar su experiencia con el CONOCER.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Decir «de todo» | No te recuerdan | Sé concreto |
| Esconder el inglés | Pierdes oportunidades | Ponlo primero |
| Creer que sin título no vale | No te certificas | CONOCER |
| Ir sin pruebas | No te creen | Fotos y cartas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Memo y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Cómo presentas tu experiencia? a) «Le hago a todo» · b) Oficio, años y pruebas · c) Solo tu nombre y el país donde trabajaste
2. ¿Quién tiene bolsa de trabajo para repatriados? a) El Servicio Nacional de Empleo · b) Un gestor · c) Nadie
3. Hablas inglés. ¿Qué haces? a) Lo escondes · b) Lo dices solo si preguntan · c) Lo pones primero
**Respuestas:** 1-b: concreto. 2-a: SNE. 3-c: es muy buscado.



#### Ponlo en práctica

Escribe una frase de tu experiencia con oficio, años y lo que coordinabas.
**Respuesta:** Ejemplo: «8 años en cocina de restaurante, preparaba 200 platillos por turno y entrenaba a dos ayudantes».



#### A tu plan

Llena tu lista con tres cosas que sabes hacer y junta una prueba de cada una.



### Para saber más

- **Servicio Nacional de Empleo** (STPS · español): https://www.empleo.gob.mx — **Qué buscar:** «repatriados».
- **Certificación de competencias** (CONOCER · español): https://conocer.gob.mx — **Qué buscar:** «certifícate».

### Palabras clave

- *Habilidad:* algo que sabes hacer bien.
- *Certificación:* papel oficial que reconoce lo que sabes.
- *Bolsa de trabajo:* lista de empleos disponibles.

### Fuentes

STPS, Servicio Nacional de Empleo; CONOCER; consultados el 5 de octubre de 2026.

---

## M7 U02. Compara ofertas: sueldo y prestaciones

**Lo que lograrás:** Comparar un empleo formal y uno informal sumando lo que no se ve en el sueldo.

**Para empezar:** A Memo le ofrecen dos trabajos: uno de 2,400 a la semana con IMSS y otro de 2,700 «en efectivo, sin papeles». Le parece obvio cuál tomar. En esta lección verás qué más cuenta.

### Lo esencial (5 minutos)

#### El sueldo no es todo

Un empleo formal incluye prestaciones: IMSS (salud), Afore, aguinaldo, vacaciones pagadas y crédito Infonavit. Un empleo informal paga solo el sueldo.



#### Lo que suma un empleo formal

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| IMSS | Médico, incapacidades. | Para ti y tu familia. |
| Afore | Ahorro para tu retiro. | Suma semanas. |
| Aguinaldo | Al menos 15 días de sueldo. | Cada diciembre. |
| Vacaciones | Días pagados. | Por ley. |

#### Haz la cuenta completa

Una consulta y medicinas sin IMSS pueden costar más que la diferencia de sueldo. Y cada semana formal te acerca a una pensión (módulo 5).



#### Un caso en un minuto

Memo sumó el aguinaldo y lo que gastaría en médico. El trabajo formal le convenía. Además, empezó a sumar semanas.

> **Idea clave:** compara el sueldo más las prestaciones, no solo lo que te pagan a la semana.



#### Comprueba lo que entendiste

1. ¿Qué incluye un empleo formal además del sueldo?
*Respuesta:* IMSS, Afore, aguinaldo, vacaciones e Infonavit.

2. ¿Cuánto es el aguinaldo mínimo?
*Respuesta:* 15 días de sueldo.


#### Para recordar

- Sueldo más prestaciones.
- Aguinaldo: 15 días.
- Semanas para tu pensión.



### Profundiza (5 minutos más)

#### El aguinaldo de Memo

- Sueldo diario (2,400 entre 7): **343**
- Días: **15**
- Aguinaldo mínimo: **5,145**


#### Pide tu alta en el IMSS

Si el trabajo es formal, el patrón debe darte de alta desde el primer día. Puedes revisar tu alta en la página del IMSS con tu CURP.



#### Casos


**Caso 1. Los 300 pesos de diferencia**

Memo compara 2,400 con IMSS contra 2,700 sin papeles.
- *¿Qué hace?* Suma prestaciones y gastos de salud antes de decidir.


**Caso 2. «Te doy de alta luego»**

El patrón de Don Rafa le dice que lo dará de alta en tres meses.
- *¿Qué hace?* Pide su alta desde el primer día y la revisa.


**Caso 3. Sin aguinaldo**

A Lupita le dicen que en su trabajo «no se usa» el aguinaldo.
- *¿Qué hace?* Sabe que es un derecho y pregunta en la PROFEDET.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Ver solo el sueldo | Comparas mal | Suma prestaciones |
| Aceptar alta después | Sin IMSS ni semanas | Desde el día uno |
| No revisar tu alta | No sabes si cotizas | Revísala |
| Renunciar a derechos | Pierdes dinero | Pregunta a la PROFEDET |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Memo, Don Rafa y Lupita. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué NO te da un empleo informal? a) Sueldo · b) IMSS y Afore · c) Un pago por las horas que trabajas
2. Ganas 300 pesos diarios. ¿Cuál es tu aguinaldo mínimo? a) 4,500 · b) 300 · c) 9,000
3. ¿Desde cuándo deben darte de alta en el IMSS? a) Desde el primer día · b) A los tres meses, cuando pases el periodo de prueba · c) Al año
**Respuestas:** 1-b: no hay prestaciones. 2-a: 15 días. 3-a: desde el inicio.



#### Ponlo en práctica

Ganas 2,100 a la semana. ¿Cuánto es tu sueldo diario?
**Respuesta:** 300 pesos.



#### A tu plan

Si tienes dos ofertas, escribe para cada una: sueldo, IMSS, aguinaldo y vacaciones.



### Para saber más

- **Derechos laborales** (PROFEDET · español): https://www.gob.mx/profedet — **Qué buscar:** «aguinaldo». Teléfono 800 911 7877.
- **Consulta tu alta** (IMSS · español): https://www.imss.gob.mx — **Qué buscar:** «semanas cotizadas».

### Palabras clave

- *Prestaciones:* lo que recibes además del sueldo.
- *Aguinaldo:* pago anual de al menos 15 días.
- *Alta en el IMSS:* registro de tu empleo para la seguridad social.

### Fuentes

Ley Federal del Trabajo, aguinaldo y vacaciones; PROFEDET; IMSS; consultados el 5 de octubre de 2026.

---

## M7 U03. Un negocio chico sin arriesgar tu ahorro

**Lo que lograrás:** Probar una idea de negocio en pequeño antes de meter todo tu dinero.

**Para empezar:** Lupita quiere poner una taquería «como las de Houston». Le cotizaron local, plancha y mesas: 85,000 pesos, todo su ahorro. En esta lección verás cómo probar antes de apostar todo.

### Lo esencial (5 minutos)

#### Prueba primero

Antes de rentar un local, vende en pequeño: pedidos a vecinos, un puesto los fines de semana, por encargo. Así ves si la gente compra y a qué precio.



#### Tres números que necesitas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Costo | Lo que te cuesta hacer cada producto. | Ingredientes, gas, empaque. |
| Precio | Lo que cobras. | Mayor que el costo. |
| Ventas | Cuántos vendes. | Por semana. |

#### Separa el dinero del negocio

Usa una cuenta o un sobre solo para el negocio. Si mezclas el dinero de la casa con el del negocio, no sabes si ganas o pierdes.



#### Un caso en un minuto

Lupita vendió tacos por encargo seis fines de semana. Cada taco le cuesta 9 pesos y lo vende en 18. Vende unos 300 por fin de semana. Ahora sabe que su idea funciona y cuánto puede invertir.

> **Idea clave:** prueba en pequeño, conoce tu costo y tu precio, y separa el dinero del negocio.



#### Comprueba lo que entendiste

1. ¿Qué haces antes de rentar un local?
*Respuesta:* Pruebas en pequeño si la gente compra y a qué precio.

2. ¿Por qué separar el dinero del negocio?
*Respuesta:* Para saber si ganas o pierdes.


#### Para recordar

- Prueba en pequeño.
- Costo, precio, ventas.
- Separa el dinero.



### Profundiza (5 minutos más)

#### Los tacos de Lupita

- Precio: **18**
- Costo: **9**
- Le queda por taco: **9**
- Tacos por fin de semana: **300**
- Le queda por fin de semana: **2,700**


#### Para seguir aprendiendo

Si tu idea funciona, el programa Tu Negocio, Tu Dinero, Tu Futuro profundiza en precios, flujo de dinero, SAT y crédito para crecer.



#### Casos


**Caso 1. La taquería completa**

Lupita quiere invertir todo su ahorro de una vez.
- *¿Qué hace?* Vende primero por encargo para probar.


**Caso 2. El precio**

Lupita no sabe cuánto le cuesta cada taco.
- *¿Qué hace?* Suma ingredientes, gas y empaque por taco.


**Caso 3. Todo en la misma bolsa**

Don Rafa usa el dinero de sus trabajos para la casa sin anotar.
- *¿Qué hace?* Separa en una cuenta o sobre el dinero del negocio.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Invertir todo de golpe | Puedes perder tu ahorro | Prueba en pequeño |
| No saber tu costo | Pierdes sin darte cuenta | Calcúlalo |
| Mezclar dinero | No sabes si ganas | Sepáralo |
| Copiar precios de allá | No se vende | Precio de aquí |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita y Don Rafa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué haces antes de invertir tu ahorro en un negocio? a) Lo pruebas en pequeño · b) Pides un préstamo · c) Rentas el local más grande
2. Un producto te cuesta 25 y lo vendes en 40. ¿Cuánto te queda por pieza? a) 65 · b) 15 · c) 40
3. ¿Por qué separar el dinero del negocio? a) Por gusto · b) Porque la ley lo pide a todo negocio, aunque sea chico · c) Para saber si ganas o pierdes
**Respuestas:** 1-a: prueba primero. 2-b: 40 menos 25. 3-c: para ver si ganas.



#### Ponlo en práctica

Vendes 120 piezas a la semana y te quedan 12 pesos por pieza. ¿Cuánto te queda a la semana?
**Respuesta:** 1,440 pesos.



#### A tu plan

Si tienes una idea, escribe cómo la probarás en pequeño, su costo, su precio y dónde guardarás el dinero del negocio.



### Para saber más

- **Emprender** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «emprendedores».

### Palabras clave

- *Costo:* lo que te cuesta hacer o comprar lo que vendes.
- *Precio:* lo que cobras.
- *Ganancia:* lo que te queda después del costo.

### Fuentes

CONDUSEF, guías para emprendedores; consultado el 5 de octubre de 2026.

---


# Parte 9. Módulo 8. Que no te engañen al regresar

## M8 U01. Gestores falsos

**Lo que lograrás:** Reconocer a quien cobra por trámites gratuitos o se queda con tus papeles.

**Para empezar:** Afuera del centro de atención, un señor con chaleco ofrecía a Don Rafa «agilizar» su CURP, su acta y su apoyo por 1,500 pesos. Solo tenía que dejarle sus papeles originales. En esta lección verás por qué no.

### Lo esencial (5 minutos)

#### Quién es un gestor falso

Es alguien que te cobra por algo que es sin costo o que tú puedes hacer solo. A veces se queda con tus papeles o tus datos. Se para afuera de oficinas y centros de atención, o te busca por redes.



#### Señales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cobra por lo sin costo | CURP, INE, apoyos, consulta de semanas. | Todo eso es sin costo. |
| Pide originales | Para «llevarlos él». | Nunca los sueltes. |
| Promete rapidez | «Yo tengo un conocido». | No existe atajo. |
| Chaleco o gafete | Parece oficial. | No basta para creerle. |

#### Qué hacer

Entra a la oficina y pregunta en ventanilla. Si alguien dice ser de gobierno, pide su nombre y verifícalo dentro. Los trámites de este curso los puedes hacer tú.



#### Un caso en un minuto

Don Rafa no le dio sus papeles. Entró, preguntó en ventanilla y le dijeron que todo era sin costo. Hizo su trámite ese mismo día.

> **Idea clave:** si te cobran por un trámite gratuito o piden tus originales, no es ayuda: es un gestor falso.



#### Comprueba lo que entendiste

1. ¿Cuánto cuesta tramitar tu CURP o tu INE?
*Respuesta:* Nada; si te cobran, desconfía.

2. ¿Qué haces si alguien con chaleco ofrece ayuda afuera?
*Respuesta:* Entras y preguntas en ventanilla.


#### Para recordar

- Lo sin costo no se paga.
- Tus originales contigo.
- Pregunta en ventanilla.



### Profundiza (5 minutos más)

#### Trámites sin costo de este curso

| Trámite | ¿Tiene costo? |
|---|---|
| Consulta e impresión de CURP | No |
| Credencial del INE | No |
| Localizar tu Afore | No |
| Consultar semanas en el IMSS | No |
| Reporte de crédito especial (1 al año) | No |



#### Copias, no originales

Para la mayoría de los trámites te piden ver el original y te quedas con él; ellos sacan copia. No dejes tus originales a nadie fuera de la ventanilla.



#### Casos


**Caso 1. El chaleco**

Un señor con chaleco ofrece agilizar todo por 1,500.
- *¿Qué hace?* Entra y pregunta en ventanilla.


**Caso 2. El grupo de Facebook**

En un grupo de repatriados ofrecen «sacar tu apoyo» con tus datos.
- *¿Qué hace?* No da datos; tramita en la oficina del programa.


**Caso 3. Los originales**

Le piden a Memo dejar su acta original «para el trámite».
- *¿Qué hace?* Entrega copia y conserva su original.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por lo sin costo | Pierdes dinero | Pregunta en ventanilla |
| Dejar originales | Robo de identidad | Copias |
| Creer en el chaleco | Engaño | Verifica dentro |
| Dar datos por redes | Fraude | Solo en oficinas |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te cobran por tramitar tu INE. ¿Qué es? a) Un gestor falso · b) Lo normal · c) Un trámite exprés legal
2. ¿Dónde verificas si alguien es de gobierno? a) En su chaleco · b) Dentro de la oficina · c) En su tarjeta de presentación
3. ¿Qué dejas para un trámite? a) Tus originales · b) Tu NIP · c) Copias, y muestras el original
**Respuestas:** 1-a: es sin costo. 2-b: pregunta dentro. 3-c: copias.



#### Ponlo en práctica

Un gestor cobra 1,500 por tres trámites gratuitos. ¿Cuánto te ahorras si los haces tú?
**Respuesta:** 1,500 pesos.



#### A tu plan

Repasa la tabla de trámites sin costo y guárdala en tu celular.



### Para saber más

- **Fraudes y gestores** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «gestores» y «fraudes».

### Palabras clave

- *Gestor:* persona que hace trámites por otros.
- *Original:* el documento verdadero, no la copia.
- *Ventanilla:* lugar oficial de atención.

### Fuentes

CONDUSEF, alertas sobre gestores y fraudes; SEGOB, México te Abraza; consultados el 5 de octubre de 2026.

---

## M8 U02. Fraudes y extorsión al que regresa

**Lo que lograrás:** Reconocer los fraudes y las extorsiones más comunes contra quien regresa y saber qué hacer.

**Para empezar:** A Lupita le llamaron diciendo que tenían a su hermano «detenido en la frontera» y que necesitaba depositar 8,000 pesos ya. Sonaba alguien llorando. En esta lección verás cómo actuar.

### Lo esencial (5 minutos)

#### Los más comunes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Familiar «detenido» | Piden depósito urgente. | Extorsión. |
| Trabajo con pago adelantado | «Paga el curso o el uniforme». | Fraude. |
| Inversión milagro | «Duplica tus dólares». | Fraude. |
| «Te tramito tu retiro de allá» | Piden tus datos y un pago. | Fraude. |

#### La regla de oro

Ante una llamada urgente: **cuelga, respira y llama tú** al familiar o a la institución con un número que ya tengas. Los delincuentes usan la prisa para que no pienses.



#### Si ya pagaste o te amenazan

Guarda los números y las capturas. Denuncia al 089 (anónimo) o en la Fiscalía. Si fue por banco, avisa al banco de inmediato.



#### Un caso en un minuto

Lupita colgó y llamó a su hermano. Estaba en su trabajo en Dallas. Bloqueó el número y lo reportó al 089.

> **Idea clave:** ante la prisa, cuelga y llama tú; nadie serio te pide depósitos urgentes por teléfono.



#### Comprueba lo que entendiste

1. ¿Qué haces ante una llamada urgente pidiendo dinero?
*Respuesta:* Cuelgo y llamo yo al familiar con un número que ya tengo.

2. ¿A qué número denuncias una extorsión?
*Respuesta:* Al 089, de forma anónima.


#### Para recordar

- Cuelga y llama tú.
- Nada de depósitos urgentes.
- 089 para denunciar.



### Profundiza (5 minutos más)

#### Cuida lo que publicas

Publicar que acabas de regresar, con quién vives o dónde trabajas da información a los extorsionadores. Revisa quién ve tus redes.



#### Ofertas de trabajo reales

Un empleo real no te cobra por contratarte. Si te piden pago por curso, uniforme o examen antes de empezar, desconfía.



#### Casos


**Caso 1. El hermano detenido**

Le piden a Lupita 8,000 pesos para liberar a su hermano.
- *¿Qué hace?* Cuelga y llama ella a su hermano.


**Caso 2. El trabajo con cuota**

A Don Rafa le ofrecen trabajo si paga 1,200 por el uniforme.
- *¿Qué hace?* No paga: un empleo real no cobra por contratar.


**Caso 3. Duplica tus dólares**

A Memo le ofrecen duplicar sus ahorros en tres meses.
- *¿Qué hace?* No invierte: nadie duplica dinero sin riesgo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Depositar por miedo | Pierdes dinero | Cuelga y llama tú |
| Pagar por un empleo | Fraude | No pagues |
| Creer en ganancias rápidas | Pierdes tu ahorro | Desconfía |
| Publicar de más | Te ubican | Cuida tus redes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Lupita, Don Rafa y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. Te llaman: tu familiar está detenido y piden dinero ya. ¿Qué haces? a) Cuelgas y llamas tú a tu familiar · b) Depositas · c) Das tus datos
2. Un empleo te pide pagar el uniforme antes de empezar. ¿Qué es? a) Normal · b) Una prestación que da el patrón para empezar · c) Una señal de fraude
3. ¿A qué número denuncias de forma anónima? a) 911 solo · b) 089 · c) Al número que te llamó
**Respuestas:** 1-a: verifica tú. 2-c: no se paga por trabajar. 3-b: 089.



#### Ponlo en práctica

Te ofrecen convertir 10,000 en 20,000 en tres meses. ¿Qué haces?
**Respuesta:** No invierto; es una señal de fraude.



#### A tu plan

Acuerda con tu familia una palabra clave para emergencias y guarda el 089 en tu celular.



### Para saber más

- **Denuncia anónima** (Gobierno de México · español): 089.
- **Fraudes financieros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraudes».

### Palabras clave

- *Extorsión:* amenaza para que entregues dinero.
- *Denuncia anónima:* reporte sin dar tu nombre.
- *Palabra clave:* contraseña familiar para confirmar emergencias.

### Fuentes

CONDUSEF, alertas de fraude; Secretariado Ejecutivo del SNSP, línea 089; consultados el 5 de octubre de 2026.

---

## M8 U03. Tu plan de regreso en una página

**Lo que lograrás:** Reunir en una sola hoja tus papeles, tu cuenta, tu historial, lo que quedó allá, tu retiro y tu presupuesto.

**Para empezar:** Don Rafa tiene notas en tres cuadernos y fotos en el celular. Cuando le preguntan «¿cómo vas?», no sabe por dónde empezar. En esta lección juntarás todo en una página.

### Lo esencial (5 minutos)

#### Tu página tiene seis partes

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Papeles | Lo que tienes y lo que falta. | M1. |
| Cuenta | Tu CLABE y alertas. | M2. |
| Crédito | Tu reporte revisado. | M3. |
| Lo de allá | Sueldo, cuenta, impuestos, retiro. | M4. |
| Retiro | Afore y semanas. | M5. |
| 90 días | Presupuesto y trabajo. | M6 y M7. |

#### Una acción por parte

Para cada parte escribe la siguiente acción y una fecha. No hace falta resolver todo hoy; hace falta saber qué sigue.



#### Un caso en un minuto

Don Rafa hizo su página. Le falta la INE (cita el lunes), pedir sus W-2 (esta semana) y localizar su Afore (ya lo hizo). Ahora sabe por dónde seguir.

> **Idea clave:** junta todo en una página con la siguiente acción y una fecha para cada parte.



#### Comprueba lo que entendiste

1. ¿Cuántas partes tiene tu plan?
*Respuesta:* Seis: papeles, cuenta, crédito, lo de allá, retiro y 90 días.

2. ¿Qué escribes en cada parte?
*Respuesta:* La siguiente acción y una fecha.


#### Para recordar

- Seis partes.
- Una acción por parte.
- Con fecha.



### Profundiza (5 minutos más)

#### Tu plan de regreso

| Parte | Cómo voy | Siguiente acción | Fecha |
|---|---|---|---|
| Papeles | | | |
| Cuenta | | | |
| Crédito | | | |
| Lo de allá | | | |
| Retiro | | | |
| 90 días | | | |



#### Revísalo cada mes

Tu situación cambia rápido los primeros meses. Revisa tu página cada mes y tacha lo que ya hiciste.



#### Casos


**Caso 1. Tres cuadernos**

Don Rafa tiene notas regadas.
- *¿Qué hace?* Junta todo en su plan de una página.


**Caso 2. Todo hoy**

Lupita quiere resolver las seis partes en un día.
- *¿Qué hace?* Escribe la siguiente acción de cada parte con una fecha.


**Caso 3. El plan guardado**

Memo hizo su plan y lo olvidó en un cajón.
- *¿Qué hace?* Lo revisa cada mes y tacha lo que avanzó.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Notas regadas | No ves el avance | Una página |
| Querer todo hoy | Te abrumas | Una acción por parte |
| Sin fechas | Se queda en idea | Pon fecha |
| No revisarlo | Se olvida | Cada mes |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Rafa, Lupita y Memo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo. Suma puntos de experiencia.



#### Quiz

1. ¿Qué lleva cada parte de tu plan? a) Solo lo que ya hiciste · b) La siguiente acción y una fecha · c) Un dibujo de cómo te ves en un año
2. ¿Cada cuándo revisas tu plan? a) Cada mes · b) Cada cinco años · c) Nunca
3. ¿Cuál de estas es una parte del plan? a) Tus redes sociales · b) Tus papeles · c) Tus vacaciones
**Respuestas:** 1-b: acción y fecha. 2-a: cada mes. 3-b: papeles.



#### Ponlo en práctica

Te falta la INE, tus W-2 y tu reporte de crédito. Escribe la siguiente acción de una de ellas con fecha.
**Respuesta:** Ejemplo: «Ir al módulo del INE el lunes 12 con acta y comprobante».



#### A tu plan

Llena tu plan de regreso en una página y ponle fecha a cada siguiente acción.



### Para saber más

- **Todo lo del curso** (Desarrolla Talento · español): repasa las listas de los módulos 1 a 7.

### Palabras clave

- *Plan:* lista de lo que harás y cuándo.
- *Siguiente acción:* el próximo paso concreto.
- *Revisión:* volver a ver cómo vas.

### Fuentes

Elaboración propia con base en los módulos 1 a 7 del programa.

---


# Parte 10. Materiales de apoyo

## Bienvenida

**Tu Regreso, Tu Dinero, Tu Futuro** — Programa de bienestar financiero para personas que regresan de Estados Unidos a México, por deportación o por decisión propia: 8 módulos y 24 lecciones cortas. Formato híbrido: una sesión presencial de arranque y el resto en línea.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Tus papeles:** Tu lista de papeles en orden: constancia, CURP, acta, INE y los de tus hijos.
- **Tu cuenta en México:** Una cuenta a tu nombre para recibir apoyos y dinero, y tus tarjetas de regreso bien usadas.
- **Crédito desde cero:** Tu primer historial de crédito en México, empezando chico y sin trampas.
- **Lo que dejaste en Estados Unidos:** Tu lista de lo que quedó allá: último pago, cuentas, impuestos y retiro.
- **Tu Afore, tu IMSS y tus semanas:** Tus semanas cotizadas revisadas y tu Afore localizada.
- **Tus primeros 90 días:** Tu presupuesto de regreso para los primeros tres meses.
- **Trabajo o negocio con lo que sabes hacer:** Tu plan para usar lo que sabes hacer: empleo, oficio o negocio pequeño.
- **Que no te engañen al regresar:** Tu protocolo contra gestores falsos, fraudes y extorsión al que regresa.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **8 y 8 minutos** con la práctica. Son 24 lecciones en 8 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Don Rafa:** 52 años. Trabajó 18 años en construcción en Texas. Lo deportaron en marzo; volvió a Michoacán.
- **Lupita:** 38 años. Regresó por decisión propia a Guanajuato con dos hijos nacidos en EE. UU.
- **Memo:** 24 años. Llegó a EE. UU. a los 6 años; regresó a Puebla y casi no conoce México.
- **Chayo:** 45 años. Vive en Oaxaca; recibía remesas de su esposo, que acaba de regresar.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **No se da asesoría migratoria ni legal:** se orienta a consulados, a la Embajada y a oficinas públicas.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. La primera semana de Don Rafa (Módulos 1 y 2)

**Datos.** Don Rafa llegó con su constancia de recepción y la Tarjeta Bienestar Paisano con 2,000 pesos. El camión a su pueblo cuesta 650, su acta y copias 250, y la comida de la semana 600. Afuera del centro, un señor le cobra 500 por «sacarle la CURP».

**Tareas.**

1. ¿Cuánto le queda de los 2,000?
2. ¿Le paga al señor por la CURP?
3. ¿Qué tarjeta usa su hijo para mandarle dinero desde Dallas?
4. ¿Qué cuenta pide en el banco y qué revisa antes?

**Clave.**

- 2,000 menos 1,500: 500. El apoyo es una sola vez.
- No: la consulta e impresión de la CURP en gob.mx son sin costo.
- La Tarjeta FINABIEN Paisano, que funciona como cuenta.
- La cuenta básica; revisa la institución en el SIPRES de la CONDUSEF y pide la carátula.

### E2. Lo que quedó en Texas (Módulos 3 y 4)

**Datos.** El patrón le debe a Don Rafa una semana: 900 dólares. En su cuenta de allá hay 1,400 dólares y cobra 12 al mes. Le retuvieron 2,400 dólares de impuestos el último año y debía 1,700. Un «asesor» le ofrece «buen crédito en México» si le paga 400 pesos por su reporte.

**Tareas.**

1. ¿Qué hace con la semana que le deben?
2. ¿Cuánto pierde en un año si deja la cuenta olvidada?
3. ¿De cuánto sería su reembolso?
4. ¿Qué hace con el reporte de crédito?

**Clave.**

- La pide por depósito o con cheque a alguien de confianza; el consulado lo orienta si no le pagan.
- 12 por 12: 144 dólares.
- 2,400 menos 1,700: 700 dólares.
- Lo pide sin costo en la página oficial, una vez al año en cada sociedad; en México empieza de cero.

### E3. Las semanas de Lupita (Módulos 5 y 6)

**Datos.** Lupita trabajó en México de 2003 a 2007 con IMSS (unas 210 semanas). Ahora le entran 9,000 al mes y sus básicos son 7,600. Su familia le pide 1,500 para una fiesta de bienvenida.

**Tareas.**

1. ¿Qué ley le toca y cuántas semanas pide en 2026?
2. ¿Cuántas le faltan?
3. ¿Cuánto le queda al mes después de los básicos?
4. ¿Qué responde a lo de la fiesta?

**Clave.**

- Ley 97, porque empezó después de julio de 1997: 875 semanas en 2026.
- 875 menos 210: 665.
- 9,000 menos 7,600: 1,400.
- Propone algo sencillo con un tope que no ponga en riesgo sus 90 días.

### E4. El trabajo de Memo (Módulos 7 y 8)

**Datos.** A Memo le ofrecen 2,400 a la semana con IMSS o 2,700 en efectivo sin papeles. Otro «trabajo» le pide 1,200 por el uniforme antes de empezar. Le llaman: «Tenemos a tu primo en la frontera, deposita 8,000».

**Tareas.**

1. ¿Cuánto es su aguinaldo mínimo en el trabajo formal?
2. ¿Qué más suma el trabajo formal?
3. ¿Qué hace con el trabajo que cobra el uniforme?
4. ¿Qué hace con la llamada?

**Clave.**

- 2,400 entre 7 son unos 343 por día; por 15 días: unos 5,145.
- IMSS, Afore, vacaciones e Infonavit; y semanas para su pensión.
- No paga: un empleo real no cobra por contratar.
- Cuelga y llama él a su primo con un número que ya tiene; denuncia al 089.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Tienes constancia y CURP, pero no acta ni INE. ¿Qué dos papeles te faltan de la lista básica? |
| P02 | M1 U02 | Ya tienes acta y constancia de repatriación. Vives con tu mamá y el recibo de luz está a su nombre. ¿Qué te falta confirmar antes de ir al módulo? |
| P03 | M1 U03 | Tienes dos hijos nacidos en EE. UU. con birth certificate. ¿Qué dos papeles mexicanos tendrán al terminar el trámite? |
| P04 | M2 U01 | Recibiste 2,000 pesos. El camión cuesta 650 y tus papeles 300. ¿Cuánto te queda? |
| P05 | M2 U02 | Una cuenta cobra 85 pesos al mes. ¿Cuánto pagas en un año? |
| P06 | M2 U03 | ¿Cuántos dígitos tiene una CLABE? |
| P07 | M3 U01 | Pediste tu reporte en Buró en enero. ¿Desde qué mes lo puedes volver a pedir sin costo? |
| P08 | M3 U02 | Tu límite es 4,500. ¿Cuánto es un tercio? |
| P09 | M3 U03 | Te ofrecen 12 pagos semanales de 450 por un celular de 3,900 de contado. ¿Cuánto pagas de más? |
| P10 | M4 U01 | Tu cuenta de allá cobra 12 dólares al mes y tiene 150. ¿En cuántos meses queda vacía? |
| P11 | M4 U02 | Te retuvieron 2,400 dólares y lo que debías de impuestos era 1,700. ¿Cuánto sería tu reembolso? |
| P12 | M4 U03 | Tienes 8,000 dólares en tu 401(k). Si te retienen y penalizan 30% en total, ¿cuánto recibirías? |
| P13 | M5 U01 | ¿Qué dos cosas revisas al encontrar tu Afore, además del saldo? |
| P14 | M5 U02 | Tienes 700 semanas y eres Ley 97. ¿Cuántas te faltan en 2026? |
| P15 | M5 U03 | Aportas 300 pesos al mes. ¿Cuánto en dos años, sin contar rendimientos? |
| P16 | M6 U01 | Te entran 9,000 al mes y gastas 7,200 en lo básico. ¿Cuánto te queda? |
| P17 | M6 U02 | Tienes 9,000 de ahorro y necesitas 2,500 al mes para completar tus gastos. ¿Cuánto puedes regalar en tres meses sin quedarte corto? |
| P18 | M6 U03 | Entran 10,500 y lo básico cuesta 9,200. ¿Cuánto queda para lo demás? |
| P19 | M7 U01 | Escribe una frase de tu experiencia con oficio, años y lo que coordinabas. |
| P20 | M7 U02 | Ganas 2,100 a la semana. ¿Cuánto es tu sueldo diario? |
| P21 | M7 U03 | Vendes 120 piezas a la semana y te quedan 12 pesos por pieza. ¿Cuánto te queda a la semana? |
| P22 | M8 U01 | Un gestor cobra 1,500 por tres trámites gratuitos. ¿Cuánto te ahorras si los haces tú? |
| P23 | M8 U02 | Te ofrecen convertir 10,000 en 20,000 en tres meses. ¿Qué haces? |
| P24 | M8 U03 | Te falta la INE, tus W-2 y tu reporte de crédito. Escribe la siguiente acción de una de ellas con fecha. |

### Respuestas

- **P01:** El acta de nacimiento y la INE.
- **P02:** Si aceptan el recibo de tu mamá como comprobante de domicilio.
- **P03:** Acta de nacimiento mexicana y CURP.
- **P04:** 1,050 pesos.
- **P05:** 1,020 pesos.
- **P06:** 18.
- **P07:** Desde enero del año siguiente.
- **P08:** 1,500 pesos.
- **P09:** 1,500 pesos (12 por 450 son 5,400).
- **P10:** En 13 meses (12.5 redondeado hacia arriba).
- **P11:** 700 dólares.
- **P12:** 5,600 dólares.
- **P13:** Tus datos de contacto y tus beneficiarios.
- **P14:** 175.
- **P15:** 7,200 pesos.
- **P16:** 1,800 pesos.
- **P17:** 1,500 pesos.
- **P18:** 1,300 pesos.
- **P19:** Ejemplo: «8 años en cocina de restaurante, preparaba 200 platillos por turno y entrenaba a dos ayudantes».
- **P20:** 300 pesos.
- **P21:** 1,440 pesos.
- **P22:** 1,500 pesos.
- **P23:** No invierto; es una señal de fraude.
- **P24:** Ejemplo: «Ir al módulo del INE el lunes 12 con acta y comprobante».


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tus papeles

- **Apostilla:** sello que reconoce un documento extranjero.
- **Comprobante de domicilio:** papel que muestra dónde vives.
- **Constancia:** papel oficial que comprueba algo.
- **Copia certificada:** copia oficial que vale como el original.
- **CURP:** Clave Única de Registro de Población.
- **Doble nacionalidad:** ser de dos países a la vez.
- **Inscripción de nacimiento:** registro en México de un nacimiento ocurrido fuera.
- **Módulo:** oficina donde se tramita la INE.
- **Repatriación:** regreso de una persona a su país.

### Tu cuenta en México

- **Apoyo único:** dinero que se da una sola vez.
- **Carátula:** resumen del contrato.
- **CLABE:** número de 18 dígitos para transferencias.
- **Comisión:** cobro por un servicio.
- **Cuenta básica:** cuenta sin comisiones de apertura ni manejo.
- **Folio:** número que comprueba tu reclamación.
- **NIP:** número secreto de tu tarjeta.
- **Remesa:** dinero que manda un familiar desde otro país.
- **SPEI:** sistema de transferencias entre bancos.

### Crédito desde cero

- **Acoso de cobranza:** presión ilegal para que pagues.
- **CAT:** Costo Anual Total del crédito.
- **Costo total:** todo lo que pagas, menos lo que te prestaron.
- **Historial de crédito:** registro de cómo has pagado lo que te prestan.
- **Límite de crédito:** lo máximo que te prestan.
- **Pago mínimo:** lo menos que puedes pagar sin atraso; genera intereses.
- **Plazo:** tiempo para pagar.
- **Reporte especial:** tu historial completo, sin costo una vez al año.
- **Sociedad de información crediticia:** empresa autorizada que guarda ese registro.

### Lo que dejaste en Estados Unidos

- **401(k):** plan de retiro de un empleo en EE. UU.
- **Consulado:** oficina de México en otro país.
- **Crédito del Seguro Social:** unidad que cuenta tu trabajo cotizado.
- **Penalización:** cobro extra por retirar antes de tiempo.
- **Propiedad no reclamada:** dinero olvidado que guarda el estado.
- **Reembolso:** lo que te regresan si pagaste de más.
- **Retención:** impuesto que te quitan de cada pago.
- **W-2:** forma con tu sueldo y retenciones del año.
- **Último pago:** sueldo pendiente al terminar un trabajo.

### Tu Afore, tu IMSS y tus semanas

- **Afore:** administradora de tu ahorro para el retiro.
- **Aportación voluntaria:** dinero que tú agregas a tu Afore.
- **Beneficiario:** persona que recibe tu ahorro si faltas.
- **Domiciliación:** cargo automático a tu cuenta.
- **Ley 73 y Ley 97:** reglas de pensión según cuándo empezaste a cotizar.
- **NSS:** número de seguridad social.
- **Rendimiento:** lo que gana tu ahorro con el tiempo.
- **Semanas cotizadas:** semanas trabajadas con IMSS.
- **Trabajador independiente:** quien trabaja sin patrón.

### Tus primeros 90 días

- **Beca:** apoyo para estudiar.
- **Compromiso:** gasto que sientes que te toca hacer.
- **Guardadito:** ahorro pequeño para imprevistos.
- **Ingreso seguro:** dinero que sabes que llega.
- **Límite:** hasta dónde puedes llegar sin dañarte.
- **Presupuesto:** plan de lo que entra y sale.
- **Recorte:** gasto que se quita o se baja.
- **Tope:** lo máximo que vas a gastar.

### Trabajo o negocio con lo que sabes hacer

- **Aguinaldo:** pago anual de al menos 15 días.
- **Alta en el IMSS:** registro de tu empleo para la seguridad social.
- **Bolsa de trabajo:** lista de empleos disponibles.
- **Certificación:** papel oficial que reconoce lo que sabes.
- **Costo:** lo que te cuesta hacer o comprar lo que vendes.
- **Ganancia:** lo que te queda después del costo.
- **Habilidad:** algo que sabes hacer bien.
- **Precio:** lo que cobras.
- **Prestaciones:** lo que recibes además del sueldo.

### Que no te engañen al regresar

- **Denuncia anónima:** reporte sin dar tu nombre.
- **Extorsión:** amenaza para que entregues dinero.
- **Gestor:** persona que hace trámites por otros.
- **Original:** el documento verdadero, no la copia.
- **Palabra clave:** contraseña familiar para confirmar emergencias.
- **Plan:** lista de lo que harás y cuándo.
- **Revisión:** volver a ver cómo vas.
- **Siguiente acción:** el próximo paso concreto.
- **Ventanilla:** lugar oficial de atención.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Consulta tu CURP | Gobierno de México: https://www.gob.mx/curp | «consulta e impresión» | M1 U01 |
| México te Abraza | SEGOB: https://portales.segob.gob.mx/es/PoliticaMigratoria/Mexico-te-abraza | «servicios» | M1 U01, M2 U01 |
| Acta de nacimiento en línea | Gobierno de México: https://www.gob.mx/actas | «copia certificada» | M1 U02 |
| Requisitos de la credencial | INE: https://www.ine.mx | «requisitos credencial para votar» | M1 U02 |
| Doble nacionalidad | SRE: https://www.gob.mx/sre | «inscripción de nacimiento doble nacionalidad» | M1 U03 |
| Inscripción a la escuela | SEP: https://www.gob.mx/sep | «inscripción niñas y niños migrantes» | M1 U03 |
| FINABIEN | Gobierno de México: https://www.gob.mx/finabien | «Tarjeta FINABIEN Paisano» | M2 U01 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | el nombre de la institución | M2 U02 |
| Cuentas básicas | CONDUSEF: https://www.condusef.gob.mx | «cuenta básica» | M2 U02 |
| Reclamaciones | CONDUSEF: https://www.condusef.gob.mx | «presentar una reclamación». Teléfono 55 5340 0999 | M2 U03 |
| Reporte de Crédito Especial | Buró de Crédito: https://www.burodecredito.com.mx | «reporte de crédito especial» | M3 U01 |
| Reporte gratuito | Círculo de Crédito: https://www.circulodecredito.com.mx | «reporte de crédito» | M3 U01 |
| Simuladores y comparadores | CONDUSEF: https://www.condusef.gob.mx | «simulador tarjeta de crédito» | M3 U02 |
| Apps de préstamo | CONDUSEF: https://www.condusef.gob.mx | «apps de préstamos» y «SIPRES» | M3 U03 |
| Protección consular | SRE: https://consulmex.sre.gob.mx | «protección» y el consulado de la ciudad donde trabajaste | M4 U01, M4 U02 |
| Propiedad no reclamada | NAUPA: https://unclaimed.org | el estado donde viviste | M4 U01 |
| Reembolsos | IRS: https://www.irs.gov/es | «reembolso» y «contribuyentes en el extranjero» | M4 U02 |
| Unidad de Beneficios Federales | Embajada de EE. UU. en México: https://mx.usembassy.gov/es | «Federal Benefits Unit» o «beneficios federales» | M4 U03 |
| Seguro Social | SSA: https://www.ssa.gov/espanol | «pagos fuera de EE. UU.» | M4 U03 |
| Localiza tu Afore | CONSAR: https://www.gob.mx/consar | «localiza tu Afore» y «AforeMóvil». SARTEL 55 1328 5000 | M5 U01 |
| Constancia de semanas cotizadas | IMSS: https://serviciosdigitales.imss.gob.mx | «semanas cotizadas» | M5 U02 |
| Ahorro voluntario | CONSAR: https://www.gob.mx/consar | «ahorro voluntario» | M5 U03 |
| Personas trabajadoras independientes | IMSS: https://www.imss.gob.mx | «personas trabajadoras independientes» | M5 U03 |
| Presupuesto | CONDUSEF: https://www.condusef.gob.mx | «presupuesto personal» | M6 U01 |
| Finanzas en familia | CONDUSEF: https://www.condusef.gob.mx | «prestar dinero a familiares» | M6 U02 |
| Programas para el Bienestar | Gobierno de México: https://programasparaelbienestar.gob.mx | «becas» y «requisitos» | M6 U03 |
| Servicio Nacional de Empleo | STPS: https://www.empleo.gob.mx | «repatriados» | M7 U01 |
| Certificación de competencias | CONOCER: https://conocer.gob.mx | «certifícate» | M7 U01 |
| Derechos laborales | PROFEDET: https://www.gob.mx/profedet | «aguinaldo». Teléfono 800 911 7877 | M7 U02 |
| Consulta tu alta | IMSS: https://www.imss.gob.mx | «semanas cotizadas» | M7 U02 |
| Emprender | CONDUSEF: https://www.condusef.gob.mx | «emprendedores» | M7 U03 |
| Fraudes y gestores | CONDUSEF: https://www.condusef.gob.mx | «gestores» y «fraudes» | M8 U01 |
| Denuncia anónima | Gobierno de México: 089 | — | M8 U02 |
| Fraudes financieros | CONDUSEF: https://www.condusef.gob.mx | «fraudes» | M8 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Tus papeles

- **M1 U01 · Tu constancia y tu CURP: los dos primeros papeles.** SEGOB, México te Abraza; INM, Constancia de Recepción de Mexicanos Repatriados; consultados el 5 de octubre de 2026.
- **M1 U02 · Tu acta y tu INE.** INE, requisitos para tramitar la credencial; Gobierno de México, actas en línea; consultados el 5 de octubre de 2026.
- **M1 U03 · Los papeles de tus hijos nacidos en Estados Unidos.** SRE, doble nacionalidad; SEP, normas de inscripción para población migrante; consultados el 5 de octubre de 2026.

### Tu cuenta en México

- **M2 U01 · Tus tarjetas de regreso.** SEGOB, México te Abraza; Secretaría de Bienestar, Tarjeta Bienestar Paisano; FINABIEN, Tarjeta FINABIEN Paisano; consultados el 5 de octubre de 2026.
- **M2 U02 · Elige una cuenta sin comisiones.** CONDUSEF, cuentas básicas y SIPRES; consultados el 5 de octubre de 2026.
- **M2 U03 · Cobrar, pagar y reclamar.** CONDUSEF, reclamaciones; Banco de México, SPEI; consultados el 5 de octubre de 2026.

### Crédito desde cero

- **M3 U01 · Tu historial de allá no cuenta aquí.** Buró de Crédito y Círculo de Crédito, reporte especial; CONDUSEF; consultados el 5 de octubre de 2026.
- **M3 U02 · Empieza chico y paga a tiempo.** CONDUSEF, tarjetas de crédito y CAT; Banco de México; consultados el 5 de octubre de 2026.
- **M3 U03 · Préstamos «sin buró» y apps que cobran de más.** CONDUSEF, alertas sobre apps de préstamos y gestión de cobranza; consultados el 5 de octubre de 2026.

### Lo que dejaste en Estados Unidos

- **M4 U01 · Tu último pago y tu cuenta de allá.** SRE, protección consular; NAUPA, propiedad no reclamada; consultados el 5 de octubre de 2026.
- **M4 U02 · Tus impuestos de allá.** IRS, reembolsos y plazo para reclamarlos; consultado el 5 de octubre de 2026.
- **M4 U03 · Tu retiro de allá: 401(k) y Seguro Social.** IRS, retiros anticipados de planes de retiro; SSA, pagos fuera de EE. UU.; consultados el 5 de octubre de 2026.

### Tu Afore, tu IMSS y tus semanas

- **M5 U01 · ¿Tienes Afore? Encuéntrala.** CONSAR, localización de cuentas y AforeMóvil; consultados el 5 de octubre de 2026.
- **M5 U02 · Tus semanas cotizadas.** IMSS, constancia de semanas cotizadas y requisitos de pensión Ley 73 y Ley 97; consultados el 5 de octubre de 2026.
- **M5 U03 · Ahorra para tu retiro aunque trabajes por tu cuenta.** CONSAR, ahorro voluntario; IMSS, incorporación de personas trabajadoras independientes; consultados el 5 de octubre de 2026.

### Tus primeros 90 días

- **M6 U01 · Piensa en pesos: tu presupuesto de regreso.** CONDUSEF, herramientas de presupuesto; consultado el 5 de octubre de 2026.
- **M6 U02 · Los compromisos de bienvenida.** CONDUSEF, recomendaciones sobre préstamos entre familiares; consultado el 5 de octubre de 2026.
- **M6 U03 · Cuando dejan de llegar las remesas.** Banco de México, ingresos por remesas 2025; Secretaría de Bienestar; consultados el 5 de octubre de 2026.

### Trabajo o negocio con lo que sabes hacer

- **M7 U01 · Lo que sabes hacer vale.** STPS, Servicio Nacional de Empleo; CONOCER; consultados el 5 de octubre de 2026.
- **M7 U02 · Compara ofertas: sueldo y prestaciones.** Ley Federal del Trabajo, aguinaldo y vacaciones; PROFEDET; IMSS; consultados el 5 de octubre de 2026.
- **M7 U03 · Un negocio chico sin arriesgar tu ahorro.** CONDUSEF, guías para emprendedores; consultado el 5 de octubre de 2026.

### Que no te engañen al regresar

- **M8 U01 · Gestores falsos.** CONDUSEF, alertas sobre gestores y fraudes; SEGOB, México te Abraza; consultados el 5 de octubre de 2026.
- **M8 U02 · Fraudes y extorsión al que regresa.** CONDUSEF, alertas de fraude; Secretariado Ejecutivo del SNSP, línea 089; consultados el 5 de octubre de 2026.
- **M8 U03 · Tu plan de regreso en una página.** Elaboración propia con base en los módulos 1 a 7 del programa.


# Parte 11. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Tu constancia y tu CURP: los dos primeros papeles

**Caso 1. La hoja de Don Rafa.** Su hermano le dice que tire la constancia porque «ya está en México». **¿Qué hace?**

- ✔ La guarda con sus demás papeles, porque es su identificación temporal.
- La tira, porque en México ya no la va a necesitar.
- Se la da a su hermano para que la guarde en su casa.

**Caso 2. La CURP de Memo.** Memo no sabe si tiene CURP; se fue a EE. UU. a los 6 años. **¿Qué hace?**

- ✔ La busca en gob.mx con su nombre y fecha de nacimiento.
- Paga a un conocido para que le saque una CURP nueva.
- Espera a que le llegue por correo a casa de su tía.

**Caso 3. El «gestor» de la plaza.** Un señor le ofrece a Lupita sacarle la CURP por 500 pesos. **¿Qué hace?**

- ✔ No paga, porque en gob.mx la consulta y la impresión son sin costo.
- Paga los 500 pesos para que su CURP salga más rápido.
- Le da sus datos y le paga la mitad por adelantado.

## M1 U02. Tu acta y tu INE

**Caso 1. La licencia de Texas.** El esposo de Chayo quiere abrir una cuenta con su licencia de Texas. **¿Qué hace?**

- ✔ Tramita su INE con acta y comprobante.
- Insiste con la licencia de Texas, porque también tiene foto.
- Pide a Chayo que abra la cuenta a nombre de ella.

**Caso 2. Sin recibos a su nombre.** Memo vive con su tía y ningún recibo está a su nombre. **¿Qué hace?**

- ✔ Pregunta en el módulo si aceptan el recibo de su tía o testigos.
- Espera a rentar una casa propia para tener recibos.
- Usa un recibo de luz que encontró en la calle.

**Caso 3. La cita pagada.** Una página pide 300 pesos por «apartar cita» en el INE. **¿Qué hace?**

- ✔ No paga: la cita y la credencial son sin costo.
- Paga los 300 pesos para asegurar la cita esta semana.
- Da sus datos en la página y paga después.

## M1 U03. Los papeles de tus hijos nacidos en Estados Unidos

**Caso 1. La escuela de Lupita.** Le dicen que sin CURP no hay lugar para sus hijos. **¿Qué hace?**

- ✔ Pide inscripción mientras se registra a sus hijos.
- Deja a sus hijos en casa hasta que tengan su CURP.
- Los inscribe con la CURP de un sobrino mientras tanto.

**Caso 2. El acta original.** Lupita tiene solo una copia simple del birth certificate. **¿Qué hace?**

- ✔ Pregunta en el Registro Civil si aceptan esa copia o cómo pedir una certificada.
- Saca varias fotocopias de la copia simple y las lleva.
- Desiste del trámite porque no tiene el original.

**Caso 3. La traducción cara.** Le ofrecen traducir las actas por 2,000 pesos cada una. **¿Qué hace?**

- ✔ Pregunta primero si su estado pide traducción.
- Paga los 2,000 por cada acta para no perder tiempo.
- Traduce las actas con una app del celular y las firma.

## M2 U01. Tus tarjetas de regreso

**Caso 1. «Cada mes te caen más».** A Don Rafa le dicen que el apoyo se repite cada mes. **¿Qué hace?**

- ✔ Planea con 2,000 pesos de una sola vez.
- Gasta todo esperando que el próximo mes le depositen otra vez.
- Pide prestado contando con el depósito del próximo mes.

**Caso 2. El hijo en Dallas.** El hijo de Don Rafa quiere mandarle dinero cada quincena. **¿Qué hace?**

- ✔ Usa su Tarjeta FINABIEN Paisano, que funciona como cuenta, para recibirlo.
- Le pide que se lo mande en efectivo con un conocido que viaja.
- Le pide que lo deposite en la Tarjeta Bienestar Paisano.

**Caso 3. La llamada del programa.** Le llaman «del programa» para «activar» la tarjeta con su NIP. **¿Qué hace?**

- ✔ Cuelga: nadie del programa pide el NIP.
- Da el NIP porque, si no, le pueden quitar el apoyo.
- Da solo los primeros dos números del NIP.

## M2 U02. Elige una cuenta sin comisiones

**Caso 1. El saldo mínimo.** A Lupita le ofrecen una cuenta con tarjeta dorada y saldo mínimo de 3,000. **¿Qué hace?**

- ✔ Pide la cuenta básica, sin saldo mínimo.
- Acepta la tarjeta dorada porque se ve más seria en el banco.
- Abre las dos cuentas para tener opciones.

**Caso 2. La caja del pueblo.** A Chayo le ofrecen guardar su dinero en una caja que da 4% al mes. **¿Qué hace?**

- ✔ Busca la caja en el SIPRES de CONDUSEF antes de depositar un peso.
- Deposita todo su ahorro porque le pagan 4% cada mes.
- Deposita la mitad para probar si es confiable.

**Caso 3. Sin contrato.** Memo firmó y no le dieron copia. **¿Qué hace?**

- ✔ Pide su contrato y la carátula.
- Confía en lo que le dijeron en voz en la sucursal.
- Le toma foto al anuncio de la sucursal por si acaso.

## M2 U03. Cobrar, pagar y reclamar

**Caso 1. El cargo de Memo.** Ve 1,800 pesos que no gastó. **¿Qué hace?**

- ✔ Bloquea la tarjeta, pide folio y reclama.
- Espera al próximo estado de cuenta para ver si se corrige solo.
- Lo deja así porque reclamar tarda mucho.

**Caso 2. La CLABE para el patrón.** El patrón de Don Rafa le pide sus datos para pagarle. **¿Qué hace?**

- ✔ Le da su CLABE de 18 dígitos y nada más.
- Le da su NIP para que pueda depositarle sin errores.
- Le presta su tarjeta para que la registre en la nómina.

**Caso 3. «Así es México».** Un amigo le dice a Memo que no reclame porque «nunca devuelven». **¿Qué hace?**

- ✔ Reclama y, si no resuelven, va a CONDUSEF.
- No reclama, porque su amigo dice que nunca devuelven nada.
- Publica su queja en redes sociales y espera.

## M3 U01. Tu historial de allá no cuenta aquí

**Caso 1. «No apareces».** A Don Rafa le dicen que no tiene historial. **¿Qué hace?**

- ✔ Pide su reporte y entiende que empieza de cero.
- Insiste en que su buen crédito de Texas tiene que contar aquí.
- Pide un préstamo en una app para aparecer rápido.

**Caso 2. El préstamo ajeno.** El reporte del primo muestra una app que no usó. **¿Qué hace?**

- ✔ Presenta una reclamación ante la sociedad de información crediticia.
- Paga el préstamo de la app para no meterse en problemas.
- Lo ignora porque él no lo pidió.

**Caso 3. El reporte con costo.** Una página le cobra a Memo 400 pesos por su reporte. **¿Qué hace?**

- ✔ Lo pide sin costo en la página oficial.
- Paga los 400 pesos en esa página porque es más rápido.
- Le pide a un amigo su usuario para ver el reporte.

## M3 U02. Empieza chico y paga a tiempo

**Caso 1. El límite de 20,000.** A Memo le ofrecen 20,000 de límite; gana 9,000. **¿Qué hace?**

- ✔ Pide un límite bajo que pueda pagar.
- Acepta los 20,000 de límite por si un día los necesita.
- Acepta y usa todo el límite para crear historial rápido.

**Caso 2. El pago mínimo.** El estado de cuenta de Lupita dice «pago mínimo 250». **¿Qué hace?**

- ✔ Paga el total del mes para no generar intereses.
- Paga el mínimo cada mes, porque así no tiene atrasos.
- Paga cuando se acuerde, aunque sea tarde.

**Caso 3. Tres tarjetas a la vez.** A Don Rafa le ofrecen tres tarjetas en una semana. **¿Qué hace?**

- ✔ Empieza con una sola y la paga a tiempo.
- Acepta las tres tarjetas para tener más historial más rápido.
- Acepta dos y cancela la tercera después.

## M3 U03. Préstamos «sin buró» y apps que cobran de más

**Caso 1. Los 10 minutos.** Una app le promete a Lupita 5,000 en 10 minutos sin papeles. **¿Qué hace?**

- ✔ No la usa: no le dicen el total.
- Acepta porque el dinero llega en 10 minutos y es urgente.
- Acepta y paga solo lo que pueda cada semana.

**Caso 2. Los contactos.** La app pide acceso a la agenda de Memo. **¿Qué hace?**

- ✔ Niega el permiso a sus contactos y borra la app.
- Da el permiso porque la app no funciona sin él.
- Da el permiso, pero antes borra algunos contactos.

**Caso 3. El préstamo en la tienda.** La tienda de muebles ofrece a Chayo pagos «chiquitos». **¿Qué hace?**

- ✔ Suma todos los pagos y compara.
- Firma porque los pagos semanales son chiquitos.
- Firma ahora y luego pregunta cuánto paga en total.

## M4 U01. Tu último pago y tu cuenta de allá

**Caso 1. El día de pago.** El patrón de Don Rafa le debe una semana. **¿Qué hace?**

- ✔ Pide su pago por depósito o con cheque a alguien de confianza.
- Lo da por perdido, porque ya no está en Estados Unidos.
- Le da su contraseña del banco a un compañero para que cobre.

**Caso 2. La cuenta olvidada.** Lupita dejó 300 dólares en una cuenta hace un año. **¿Qué hace?**

- ✔ Revisa si le cobran y decide qué hacer.
- La deja olvidada, porque son pocos dólares.
- Le comparte su contraseña a su prima para que la cierre.

**Caso 3. «Te consigo tu dinero».** Alguien ofrece a Memo recuperar su dinero si le da su contraseña del banco. **¿Qué hace?**

- ✔ No da su contraseña y lo hace él.
- Le da su contraseña para que recupere el dinero más rápido.
- Le paga por adelantado para que empiece el trámite.

## M4 U02. Tus impuestos de allá

**Caso 1. «Para qué».** Lupita nunca declaró. **¿Qué hace?**

- ✔ Pide sus W-2 y revisa si hay reembolso.
- Lo deja, porque desde México ya no puede declarar.
- Espera a que el IRS la busque para pagarle.

**Caso 2. Sin W-2.** Don Rafa no tiene sus formas. **¿Qué hace?**

- ✔ Se las pide al patrón o al IRS con su número de trabajo.
- Inventa los montos de memoria para no perder tiempo.
- Desiste de declarar porque no tiene las formas.

**Caso 3. El preparador milagroso.** Le ofrecen a Memo «el doble de reembolso» por 30%. **¿Qué hace?**

- ✔ Busca ayuda gratuita y no inventa datos.
- Acepta pagar el 30% a cambio del doble de reembolso.
- Acepta si le prometen que nadie va a revisar.

## M4 U03. Tu retiro de allá: 401(k) y Seguro Social

**Caso 1. «Se lo queda el gobierno».** A Memo le dicen que saque todo ya. **¿Qué hace?**

- ✔ Pregunta al administrador cuánto le retendrían antes de decidir.
- Saca todo esta semana por miedo a que se lo quiten.
- Lo olvida, porque ya no vive en Estados Unidos.

**Caso 2. Diez años en la construcción.** Don Rafa trabajó 10 años con número de Seguro Social. **¿Qué hace?**

- ✔ Pregunta en la Embajada por su caso.
- Supone que lo perdió todo al regresar a México.
- Le paga a un gestor para que se lo tramite.

**Caso 3. El asesor por WhatsApp.** Le escriben a Lupita para «mover su retiro» si da sus datos. **¿Qué hace?**

- ✔ Habla directo con el administrador.
- Le da sus datos al asesor de WhatsApp para que lo mueva.
- Le manda una foto de su estado de cuenta al asesor.

## M5 U01. ¿Tienes Afore? Encuéntrala

**Caso 1. «Se perdió».** Don Rafa cree que perdió su ahorro de la fábrica. **¿Qué hace?**

- ✔ Lo busca con su CURP en AforeMóvil.
- Lo da por perdido, porque se fue muchos años.
- Le paga a un gestor para que lo busque.

**Caso 2. Nunca formal.** Memo nunca trabajó formal en México. **¿Qué hace?**

- ✔ Abre su Afore con su CURP en la app, aunque trabaje por su cuenta.
- Espera a tener patrón para pensar en su retiro.
- Ahorra para el retiro en una lata en su casa.

**Caso 3. El gestor de Afores.** Le ofrecen a Chayo «sacar» la Afore de su esposo por una comisión. **¿Qué hace?**

- ✔ No paga: la consulta es sin costo.
- Le paga la comisión al gestor para no batallar.
- Le da al gestor la CURP de su esposo para que avance.

## M5 U02. Tus semanas cotizadas

**Caso 1. «Ya no alcanza».** A Chayo le dicen que su esposo perdió todo. **¿Qué hace?**

- ✔ Consultan sus semanas en la página del IMSS con su CURP.
- Dan por perdidas las semanas, porque se fue muchos años.
- Le pagan a un gestor para recuperarlas.

**Caso 2. ¿Qué ley?.** Don Rafa empezó a trabajar formal en 2001. **¿Qué hace?**

- ✔ Calcula cuánto le falta con la Ley 97.
- Supone que es Ley 73, porque así le piden menos semanas.
- No revisa nada, porque todavía le falta mucho.

**Caso 3. Le faltan semanas.** A Don Rafa le faltan más de 500 semanas. **¿Qué hace?**

- ✔ Busca cotizar con empleo formal o por su cuenta.
- Se rinde, porque le faltan más de 500 semanas.
- Espera a cumplir 60 años para ver qué pasa.

## M5 U03. Ahorra para tu retiro aunque trabajes por tu cuenta

**Caso 1. «No es para mí».** Don Rafa cree que sin patrón no puede ahorrar para el retiro. **¿Qué hace?**

- ✔ Aporta a su Afore cada quincena en la tienda, desde 50 pesos.
- Decide que el retiro ya no es para él, porque no tiene patrón.
- Espera a tener patrón para empezar a ahorrar.

**Caso 2. Sin servicio médico.** Lupita trabaja vendiendo comida y no tiene IMSS. **¿Qué hace?**

- ✔ Revisa cómo afiliarse como independiente.
- Se queda sin servicio médico, porque no tiene patrón.
- Usa la credencial de una prima cuando se enferma.

**Caso 3. Ahorro con un conocido.** Un conocido ofrece a Memo guardar su ahorro de retiro «con buen interés». **¿Qué hace?**

- ✔ Ahorra en su Afore, a su nombre.
- Le da su ahorro al conocido, porque le ofrece más interés.
- Reparte su ahorro entre el conocido y la Afore.

## M6 U01. Piensa en pesos: tu presupuesto de regreso

**Caso 1. Los 18 dólares.** Memo compara su sueldo de allá con el de aquí. **¿Qué hace?**

- ✔ Hace su presupuesto en pesos.
- Se desanima y decide no hacer cuentas por ahora.
- Hace sus cuentas en dólares para compararlas con allá.

**Caso 2. El trabajo prometido.** A Don Rafa le prometen trabajo «en un mes». **¿Qué hace?**

- ✔ No cuenta ese sueldo en su presupuesto hasta que sea seguro.
- Lo cuenta completo desde ya, porque se lo prometieron.
- Pide prestado contando con ese sueldo.

**Caso 3. Todo en el primer mes.** Lupita quiere gastar todo su ahorro en amueblar la casa. **¿Qué hace?**

- ✔ Reparte su ahorro en tres meses.
- Gasta todo en amueblar, porque así ya queda lista la casa.
- Gasta la mitad en muebles y ve qué pasa.

## M6 U02. Los compromisos de bienvenida

**Caso 1. La fiesta.** La familia de Don Rafa quiere una fiesta que pagaría él. **¿Qué hace?**

- ✔ Propone algo sencillo con un tope.
- Paga la fiesta que quieran, porque así se acostumbra en la familia.
- Pide prestado para la fiesta.

**Caso 2. El compadre.** El compadre le pide 1,500 «porque viene de allá». **¿Qué hace?**

- ✔ Le dice con amabilidad: «Ahorita no, cuando tenga trabajo vemos».
- Le presta los 1,500 para no quedar mal con su compadre.
- Le presta la mitad para no quedar mal.

**Caso 3. La mamá de Lupita.** Lupita quiere ayudar a su mamá cada mes. **¿Qué hace?**

- ✔ Decide un monto fijo que pueda dar.
- Le da lo que pida cada mes, aunque se quede corta.
- No le da nada aunque pueda.

## M6 U03. Cuando dejan de llegar las remesas

**Caso 1. Sin remesa.** Chayo ya no recibe los 300 dólares. **¿Qué hace?**

- ✔ Hace con su esposo un presupuesto nuevo.
- Siguen gastando igual, esperando que pronto haya trabajo.
- Piden un préstamo para seguir igual.

**Caso 2. El cable y la escuela.** No alcanza para todo. **¿Qué hace?**

- ✔ Recortan lo no básico y cuidan la escuela.
- Sacan a su hija de la escuela mientras se acomodan.
- Recortan la comida y dejan el cable.

**Caso 3. La beca.** Su hija podría tener beca y no la han pedido. **¿Qué hace?**

- ✔ Revisa los requisitos de la beca y la solicita para su hija.
- No la pide, porque cree que no les van a dar nada.
- Le paga a alguien para que la tramite.

## M7 U01. Lo que sabes hacer vale

**Caso 1. «Le hago a todo».** Don Rafa no dice qué sabe hacer. **¿Qué hace?**

- ✔ Escribe su lista con oficio, años y pruebas.
- Sigue diciendo «le hago a todo», porque así parece que sabe más.
- Deja de buscar trabajo un tiempo.

**Caso 2. El inglés de Memo.** Memo habla inglés como nativo, pero no lo pone en su solicitud. **¿Qué hace?**

- ✔ Pone el inglés primero y busca trabajos que lo pidan.
- No pone el inglés en la solicitud para no parecer presumido.
- Lo menciona solo si le preguntan.

**Caso 3. Sin título.** Lupita cocinó 10 años en un restaurante, pero no tiene papel que lo diga. **¿Qué hace?**

- ✔ Busca certificarse con el CONOCER.
- Desiste de buscar en cocinas porque no tiene un título.
- Compra un título en internet.

## M7 U02. Compara ofertas: sueldo y prestaciones

**Caso 1. Los 300 pesos de diferencia.** Memo compara 2,400 con IMSS contra 2,700 sin papeles. **¿Qué hace?**

- ✔ Suma prestaciones y salud antes de decidir.
- Toma el de 2,700 sin pensarlo, porque paga más a la semana.
- Toma los dos trabajos a la vez.

**Caso 2. «Te doy de alta luego».** El patrón de Don Rafa le dice que lo dará de alta en tres meses. **¿Qué hace?**

- ✔ Pide su alta desde el primer día.
- Acepta esperar tres meses para que no le quiten el trabajo.
- Renuncia sin preguntar.

**Caso 3. Sin aguinaldo.** A Lupita le dicen que en su trabajo «no se usa» el aguinaldo. **¿Qué hace?**

- ✔ Sabe que el aguinaldo es un derecho y pregunta en la PROFEDET.
- Acepta quedarse sin aguinaldo, porque así se usa en ese trabajo.
- Pide un adelanto en lugar del aguinaldo.

## M7 U03. Un negocio chico sin arriesgar tu ahorro

**Caso 1. La taquería completa.** Lupita quiere invertir todo su ahorro de una vez. **¿Qué hace?**

- ✔ Vende primero por encargo unos fines de semana para probar.
- Invierte los 85,000 de una vez para abrir cuanto antes.
- Pide prestado para poner el local más grande.

**Caso 2. El precio.** Lupita no sabe cuánto le cuesta cada taco. **¿Qué hace?**

- ✔ Suma ingredientes, gas y empaque.
- Cobra lo mismo que cobraban en Houston, pero en pesos.
- Cobra lo que cobre el vecino.

**Caso 3. Todo en la misma bolsa.** Don Rafa usa el dinero de sus trabajos para la casa sin anotar. **¿Qué hace?**

- ✔ Separa el dinero del negocio.
- Sigue mezclando todo, porque al final es el mismo dinero.
- Lo guarda todo en su cartera.

## M8 U01. Gestores falsos

**Caso 1. El chaleco.** Un señor con chaleco ofrece agilizar todo por 1,500. **¿Qué hace?**

- ✔ Entra y pregunta en ventanilla.
- Le paga los 1,500 para que todo salga el mismo día.
- Le deja sus originales para que los lleve.

**Caso 2. El grupo de Facebook.** En un grupo de repatriados ofrecen «sacar tu apoyo» con tus datos. **¿Qué hace?**

- ✔ Tramita en la oficina del programa.
- Manda sus datos por mensaje para que le saquen el apoyo.
- Paga la cuota que pide el grupo.

**Caso 3. Los originales.** Le piden a Memo dejar su acta original «para el trámite». **¿Qué hace?**

- ✔ Entrega copia y conserva su original.
- Deja su acta original para que el trámite no se atore.
- Deja el original y pide un recibo.

## M8 U02. Fraudes y extorsión al que regresa

**Caso 1. El hermano detenido.** Le piden a Lupita 8,000 pesos para liberar a su hermano. **¿Qué hace?**

- ✔ Cuelga y llama ella a su hermano.
- Deposita los 8,000 de inmediato para que no le pase nada.
- Deposita la mitad para ganar tiempo.

**Caso 2. El trabajo con cuota.** A Don Rafa le ofrecen trabajo si paga 1,200 por el uniforme. **¿Qué hace?**

- ✔ No paga: un empleo real no cobra.
- Paga el uniforme para asegurar el trabajo antes que otro.
- Paga la mitad ahora y el resto después.

**Caso 3. Duplica tus dólares.** A Memo le ofrecen duplicar sus ahorros en tres meses. **¿Qué hace?**

- ✔ No invierte: nadie duplica dinero en tres meses sin riesgo.
- Invierte todo su ahorro para duplicarlo antes de fin de año.
- Invierte la mitad para probar.

## M8 U03. Tu plan de regreso en una página

**Caso 1. Tres cuadernos.** Don Rafa tiene notas regadas. **¿Qué hace?**

- ✔ Junta todo en su plan de una página.
- Sigue con sus tres cuadernos, porque ahí ya tiene todo.
- Lo deja todo en la memoria.

**Caso 2. Todo hoy.** Lupita quiere resolver las seis partes en un día. **¿Qué hace?**

- ✔ Escribe la siguiente acción y una fecha.
- Intenta resolver las seis partes hoy mismo.
- Deja todo para el próximo mes.

**Caso 3. El plan guardado.** Memo hizo su plan y lo olvidó en un cajón. **¿Qué hace?**

- ✔ Lo revisa cada mes y tacha lo que ya avanzó.
- Lo deja en el cajón, porque ya lo hizo una vez.
- Hace uno nuevo cada semana sin revisar el anterior.

# Parte 12. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Qué papel te da el INM al regresarte?

- ✔ La Constancia de Recepción de Mexicanos Repatriados
- Tu credencial del INE nueva, lista para votar
- Tu acta de nacimiento

*¡Correcto! Es tu identificación temporal.*

**M1 U01 P2.** ¿Cuál es la llave de casi todos los trámites?

- La credencial del trabajo de EE. UU.
- ✔ La CURP
- El recibo de luz

*¡Correcto! Casi todo la pide.*

**M1 U01 P3.** ¿Cuánto cuesta imprimir tu CURP en gob.mx?

- 500 pesos
- 150 pesos
- ✔ Nada

*¡Correcto! Es sin costo.*

**M1 U02 P1.** ¿Qué te piden para la INE?

- Pasaporte vigente de EE. UU.
- ✔ Acta, identificación con foto y comprobante de domicilio
- Un aval con casa propia y su comprobante de domicilio

*¡Correcto! Son los tres requisitos.*

**M1 U02 P2.** ¿Cuánto cuesta sacar la credencial del INE?

- ✔ Nada
- 300 pesos
- Depende del estado

*¡Correcto! Es sin costo.*

**M1 U02 P3.** No tienes recibos a tu nombre. ¿Qué haces?

- Esperas a tener casa propia
- Usas cualquier recibo de luz que encuentres en la calle, aunque no sea de tu casa
- ✔ Preguntas si aceptan el de tu familiar, testigos o constancia de residencia

*¡Correcto! Hay opciones.*

**M1 U03 P1.** Tu hijo nació en EE. UU. y tú eres mexicana. ¿Qué es tu hijo?

- Solo estadounidense
- ✔ También mexicano, si inscribes su nacimiento
- Extranjero hasta que cumpla 18 años y decida

*¡Correcto! Se inscribe su nacimiento.*

**M1 U03 P2.** ¿Qué haces antes de pagar apostilla o traducción?

- ✔ Preguntas si tu estado la pide
- Pagas la apostilla y la traducción más caras para ir seguro
- Nada, no hace falta registrar

*¡Correcto! No todos la piden.*

**M1 U03 P3.** La escuela pide CURP y está en trámite. ¿Qué haces?

- Esperas al próximo ciclo
- Lo inscribes el próximo año, cuando ya tenga su CURP
- ✔ Pides inscripción mientras se regulariza

*¡Correcto! La escuela no debe esperar.*

## Módulo 2

**M2 U01 P1.** ¿Qué es la Tarjeta Bienestar Paisano?

- ✔ Un apoyo único de 2,000 pesos
- Una pensión que llega cada mes a tu cuenta
- Un crédito

*¡Correcto! Es una sola vez.*

**M2 U01 P2.** ¿Qué tarjeta te sirve para recibir dinero de EE. UU.?

- Ninguna
- ✔ La FINABIEN Paisano
- La tarjeta de una tienda departamental

*¡Correcto! Es una cuenta.*

**M2 U01 P3.** Te piden el NIP «para activar». ¿Qué es?

- Un trámite normal
- Un requisito del banco
- ✔ Un fraude

*¡Correcto! Nadie pide el NIP.*

**M2 U02 P1.** ¿Cuál cuenta pides para no pagar comisiones?

- La tarjeta dorada
- ✔ La cuenta básica
- La de inversión

*¡Correcto! Sin comisiones.*

**M2 U02 P2.** Te ofrecen 4% al mes. ¿Qué haces primero?

- ✔ Revisas la institución en CONDUSEF
- Depositas todo, porque 4% al mes es buen rendimiento
- Invitas a tu familia

*¡Correcto! Verifica primero.*

**M2 U02 P3.** ¿Dónde vienen las comisiones?

- En el anuncio
- En lo que te dice en voz el ejecutivo de la ventanilla
- ✔ En la carátula del contrato

*¡Correcto! La carátula las resume.*

**M2 U03 P1.** ¿Qué das para que te paguen?

- Tu NIP
- ✔ Tu CLABE
- Tu contraseña de la app

*¡Correcto! Solo la CLABE.*

**M2 U03 P2.** ¿Qué pides al reclamar en el banco?

- ✔ Un folio
- Un descuento
- Nada

*¡Correcto! Es tu prueba.*

**M2 U03 P3.** El banco no te resuelve. ¿A dónde vas?

- A la policía de tránsito
- A otro banco
- ✔ A CONDUSEF

*¡Correcto! Defiende a usuarios.*

## Módulo 3

**M3 U01 P1.** Tenías buen crédito en Texas. ¿Cómo apareces en México?

- ✔ Sin historial
- Con el mismo puntaje
- Con mal crédito

*¡Correcto! Empiezas de cero.*

**M3 U01 P2.** ¿Cuántas veces al año es sin costo tu reporte especial?

- Ninguna
- ✔ Una
- Cada mes

*¡Correcto! Una vez cada 12 meses.*

**M3 U01 P3.** Aparece un crédito que no pediste. ¿Qué haces?

- Lo pagas para no tener problemas
- ✔ Presentas una reclamación
- Nada

*¡Correcto! Reclamas.*

**M3 U02 P1.** ¿Qué construye mejor tu historial?

- Muchas tarjetas abiertas al mismo tiempo
- ✔ Un crédito chico pagado a tiempo
- Pagar el mínimo

*¡Correcto! Chico y a tiempo.*

**M3 U02 P2.** Tu límite es 6,000. ¿Cuánto conviene usar como máximo?

- ✔ 2,000
- 6,000
- 4,500

*¡Correcto! Un tercio.*

**M3 U02 P3.** ¿Qué indicador compara el costo de dos créditos?

- El color de la tarjeta
- El pago mínimo
- ✔ El CAT

*¡Correcto! Junta intereses y comisiones.*

**M3 U03 P1.** Te prestan 3,000 y pagas 4,500 en dos semanas. ¿Cuánto te cuesta?

- 4,500
- ✔ 1,500
- Nada

*¡Correcto! 4,500 menos 3,000.*

**M3 U03 P2.** Una app pide tus contactos. ¿Qué haces?

- ✔ Lo niegas y no la usas
- Lo aceptas
- Le das los de tu familia

*¡Correcto! Es para presionarte.*

**M3 U03 P3.** ¿Qué debe decirte cualquier préstamo antes de firmar?

- Solo el pago semanal
- El nombre y el teléfono del cobrador
- ✔ Cuánto pagarás en total

*¡Correcto! El total.*

## Módulo 4

**M4 U01 P1.** Te deben una semana de sueldo en EE. UU. ¿Qué haces?

- ✔ Lo pides por depósito o cheque
- Lo das por perdido
- Le das tu contraseña a un gestor

*¡Correcto! Es tuyo.*

**M4 U01 P2.** ¿Qué puede pasar con una cuenta olvidada?

- Nada, nunca cambia
- ✔ Cobra comisiones y pasa al estado
- Te la cierran y te mandan el doble

*¡Correcto! Propiedad no reclamada.*

**M4 U01 P3.** ¿Quién puede orientarte si el patrón no paga?

- Un gestor de la plaza que conoce a los patrones
- ✔ El consulado de México
- Nadie

*¡Correcto! El consulado orienta.*

**M4 U02 P1.** ¿Qué forma te da el patrón con lo que ganaste y te retuvieron?

- ✔ La W-2
- La CURP
- El recibo de renta

*¡Correcto! La W-2.*

**M4 U02 P2.** ¿El IRS deposita en una cuenta de México?

- Sí, siempre
- Solo en una cuenta FINABIEN Paisano
- ✔ No; manda un cheque por correo

*¡Correcto! Cheque por correo.*

**M4 U02 P3.** ¿Generalmente cuánto tiempo tienes para reclamar un reembolso?

- Un mes
- ✔ Unos tres años
- Para siempre, no hay fecha límite

*¡Correcto! Unos tres años.*

**M4 U03 P1.** Tu 401(k) es de…

- Tu patrón
- ✔ Ti
- El gobierno de EE. UU.

*¡Correcto! Es tuyo.*

**M4 U03 P2.** Retiras tu 401(k) a los 35 años. ¿Qué pasa normalmente?

- Te dan un bono por sacarlo antes de tiempo
- Nada
- ✔ Pagas penalización y retención

*¡Correcto! Antes de 59 y medio.*

**M4 U03 P3.** ¿Cuántos créditos suelen pedirse para una pensión del Seguro Social de EE. UU.?

- ✔ 40
- 4
- 400

*¡Correcto! Unos 10 años.*

## Módulo 5

**M5 U01 P1.** Trabajaste en México con IMSS en 2005. ¿Tienes Afore?

- ✔ Probablemente sí
- No, se borró
- Solo si vives en México desde entonces

*¡Correcto! Si cotizaste, la tienes.*

**M5 U01 P2.** ¿Con qué localizas tu Afore?

- Con tu licencia de EE. UU.
- ✔ Con tu CURP
- Con tu recibo de luz

*¡Correcto! Con la CURP.*

**M5 U01 P3.** ¿Qué son los beneficiarios?

- ✔ Los que recibirían tu ahorro si faltas
- Los dueños y directivos de la Afore
- Tus jefes

*¡Correcto! Quienes la reciben.*

**M5 U02 P1.** Empezaste a cotizar en 1990. ¿Qué ley te toca?

- Ley 97
- ✔ Ley 73
- Ninguna

*¡Correcto! Antes de julio de 1997.*

**M5 U02 P2.** ¿Cuántas semanas pide la Ley 97 en 2026?

- 500
- 1,250
- ✔ 875

*¡Correcto! 875.*

**M5 U02 P3.** ¿Cuántas semanas suma un año completo de trabajo formal?

- ✔ Unas 52
- 12
- 365, una por cada día del año

*¡Correcto! Unas 52.*

**M5 U03 P1.** ¿Dónde puedes aportar a tu Afore?

- Solo en el banco donde te depositaba el patrón
- ✔ En tienda, app o domiciliado
- Solo al jubilarte

*¡Correcto! Tienes tres formas.*

**M5 U03 P2.** Ahorras 100 pesos por semana en tu Afore. ¿Cuánto en un año?

- 1,200
- ✔ 5,200
- 520

*¡Correcto! 52 semanas por 100.*

**M5 U03 P3.** ¿Qué te da afiliarte al IMSS como independiente?

- Un préstamo
- Una tarjeta de crédito con límite según tu cuota
- ✔ Servicio médico y semanas

*¡Correcto! Servicio médico y semanas.*

## Módulo 6

**M6 U01 P1.** ¿Para cuánto tiempo planeas al regresar?

- Una semana
- ✔ 90 días
- Un día

*¡Correcto! Los primeros meses.*

**M6 U01 P2.** Te prometen trabajo «en un mes». ¿Lo cuentas?

- Sí, todo
- La mitad, por si acaso sí te contratan
- ✔ No, hasta que sea seguro

*¡Correcto! Solo lo seguro.*

**M6 U01 P3.** ¿Cómo haces tus cuentas?

- ✔ En pesos con precios de aquí
- En dólares
- Con los precios de allá, para comparar mejor

*¡Correcto! En pesos.*

**M6 U02 P1.** Te piden prestado al llegar. ¿Qué te ayuda?

- Prestar todo
- ✔ Una respuesta corta y amable
- Pedir prestado para poder prestar a tu familia

*¡Correcto! Corta y amable.*

**M6 U02 P2.** ¿Cuándo decides cuánto ayudar?

- ✔ Antes, según tus 90 días
- Cuando te lo pidan, según lo que necesite cada quien
- Nunca

*¡Correcto! Antes.*

**M6 U02 P3.** Si ayudas con dinero, conviene darlo como…

- Préstamo con intereses
- Adelanto
- ✔ Regalo que puedes dar

*¡Correcto! Sin esperar cobrarlo.*

**M6 U03 P1.** Se acabó la remesa. ¿Qué hacen primero?

- ✔ Un presupuesto nuevo con lo que entra hoy
- Piden un préstamo para seguir gastando como antes
- Siguen igual

*¡Correcto! Con números reales.*

**M6 U03 P2.** ¿Qué gasto se protege?

- El cable
- ✔ La escuela
- El celular caro

*¡Correcto! Es básico.*

**M6 U03 P3.** ¿Qué más pueden revisar?

- Nada
- Las apuestas en línea para recuperar lo de la remesa
- ✔ Apoyos o becas a los que tengan derecho

*¡Correcto! Puede haber apoyos.*

## Módulo 7

**M7 U01 P1.** ¿Cómo presentas tu experiencia?

- «Le hago a todo»
- ✔ Oficio, años y pruebas
- Solo tu nombre y el país donde trabajaste

*¡Correcto! Concreto.*

**M7 U01 P2.** ¿Quién tiene bolsa de trabajo para repatriados?

- ✔ El Servicio Nacional de Empleo
- Un gestor
- Nadie

*¡Correcto! SNE.*

**M7 U01 P3.** Hablas inglés. ¿Qué haces?

- Lo escondes
- Lo dices solo si preguntan
- ✔ Lo pones primero

*¡Correcto! Es muy buscado.*

**M7 U02 P1.** ¿Qué NO te da un empleo informal?

- Sueldo
- ✔ IMSS y Afore
- Un pago por las horas que trabajas

*¡Correcto! No hay prestaciones.*

**M7 U02 P2.** Ganas 300 pesos diarios. ¿Cuál es tu aguinaldo mínimo?

- ✔ 4,500
- 300
- 9,000

*¡Correcto! 15 días.*

**M7 U02 P3.** ¿Desde cuándo deben darte de alta en el IMSS?

- ✔ Desde el primer día
- A los tres meses, cuando pases el periodo de prueba
- Al año

*¡Correcto! Desde el inicio.*

**M7 U03 P1.** ¿Qué haces antes de invertir tu ahorro en un negocio?

- ✔ Lo pruebas en pequeño
- Pides un préstamo
- Rentas el local más grande

*¡Correcto! Prueba primero.*

**M7 U03 P2.** Un producto te cuesta 25 y lo vendes en 40. ¿Cuánto te queda por pieza?

- 65
- ✔ 15
- 40

*¡Correcto! 40 menos 25.*

**M7 U03 P3.** ¿Por qué separar el dinero del negocio?

- Por gusto
- Porque la ley lo pide a todo negocio, aunque sea chico
- ✔ Para saber si ganas o pierdes

*¡Correcto! Para ver si ganas.*

## Módulo 8

**M8 U01 P1.** Te cobran por tramitar tu INE. ¿Qué es?

- ✔ Un gestor falso
- Lo normal
- Un trámite exprés legal

*¡Correcto! Es sin costo.*

**M8 U01 P2.** ¿Dónde verificas si alguien es de gobierno?

- En su chaleco
- ✔ Dentro de la oficina
- En su tarjeta de presentación

*¡Correcto! Pregunta dentro.*

**M8 U01 P3.** ¿Qué dejas para un trámite?

- Tus originales
- Tu NIP
- ✔ Copias, y muestras el original

*¡Correcto! Copias.*

**M8 U02 P1.** Te llaman: tu familiar está detenido y piden dinero ya. ¿Qué haces?

- ✔ Cuelgas y llamas tú a tu familiar
- Depositas
- Das tus datos

*¡Correcto! Verifica tú.*

**M8 U02 P2.** Un empleo te pide pagar el uniforme antes de empezar. ¿Qué es?

- Normal
- Una prestación que da el patrón para empezar
- ✔ Una señal de fraude

*¡Correcto! No se paga por trabajar.*

**M8 U02 P3.** ¿A qué número denuncias de forma anónima?

- 911 solo
- ✔ 089
- Al número que te llamó

*¡Correcto! 089.*

**M8 U03 P1.** ¿Qué lleva cada parte de tu plan?

- Solo lo que ya hiciste
- ✔ La siguiente acción y una fecha
- Un dibujo de cómo te ves en un año

*¡Correcto! Acción y fecha.*

**M8 U03 P2.** ¿Cada cuándo revisas tu plan?

- ✔ Cada mes
- Cada cinco años
- Nunca

*¡Correcto! Cada mes.*

**M8 U03 P3.** ¿Cuál de estas es una parte del plan?

- Tus redes sociales
- ✔ Tus papeles
- Tus vacaciones

*¡Correcto! Papeles.*
