# Tu Comunidad, Tu Dinero, Tu Futuro: contenido completo

Versión 1.0 · Desarrolla Talento. Todo lo que ve la persona participante: lecciones, libro de apoyo, actividades H5P y banco de preguntas.

# Parte 1. Personajes

| Personaje | Quién es |
|---|---|
| Doña Juana | 55 años. Cobra la Pensión Mujeres Bienestar en una comunidad de la Montaña de Guerrero. Habla náhuatl y poco español. |
| Rosa | 32 años. Tiene tres hijos; su esposo trabaja en Sinaloa y le manda dinero. No tiene cuenta a su nombre. |
| Don Pedro | 61 años. Ejidatario en Chiapas. Siembra maíz y café. |
| Marta | 24 años. Estudió la preparatoria; ayuda a su comunidad con trámites y habla tsotsil y español. |

## 2. Mapa de módulos

| Módulo | Resultado | Insignia |
|---|---|---|
| Módulo 1. Tu tarjeta y tus apoyos, sin intermediarios | Tus apoyos cobrados completos, sin pagar a nadie. | Mi apoyo completo |
| Módulo 2. Tu cuenta a tu nombre | Una cuenta a tu nombre, sobre todo si eres mujer. | Cuenta a mi nombre |
| Módulo 3. Recibir y enviar dinero sin perder | Tu dinero recibido y enviado con menos comisión y sin intermediarios. | Dinero que llega |
| Módulo 4. Ahorro en grupo con reglas claras | Las reglas escritas de tu grupo de ahorro. | Grupo con reglas |
| Módulo 5. Fraudes por teléfono y apps de préstamo | Tu regla para colgar y no instalar apps de préstamo. | No me engañan |
| Módulo 6. Tu tierra: lista de sucesión y beneficiarios | Tu lista de sucesión hecha y tus beneficiarios al día. | Mi tierra en orden |
| Módulo 7. Seguro de vida y gastos funerarios | Tu plan para los gastos funerarios sin endeudar a tu familia. | Familia protegida |

Al terminar todo el programa: insignia **Plan completo** y constancia con los temas: Apoyos sin intermediarios, Cuenta a mi nombre, Ahorro en grupo, Fraudes, Tierra y familia.

## 3. Lecciones

# Parte 2. Módulo 1. Tu tarjeta y tus apoyos, sin intermediarios

## M1 U01. Tu apoyo es tuyo, completo

**Lo que lograrás:** Cobrar tus apoyos completos, directo en tu tarjeta, sin pagar a nadie.

**Para empezar:** Cada bimestre, un señor lleva a Doña Juana a cobrar su pensión al pueblo grande. Le cobra 500 pesos «por el viaje y por ayudarla». Ella cree que así debe ser. En esta lección verás que tu apoyo es completo.

### Lo esencial (5 minutos)

#### Sin intermediarios

Los apoyos de los Programas para el Bienestar se entregan **directo** en la tarjeta del Banco del Bienestar. Nadie puede cobrarte por registrarte, por darte tu tarjeta o por cobrar.



#### Lo que es sin costo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Registrarte | En el módulo o la visita oficial. | Sin pagar. |
| Tu tarjeta | Te la entregan. | Sin pagar. |
| Cobrar | En el banco, cajero o donde indiquen. | Completo. |

#### El pasaje no es una comisión

Si alguien te lleva, puedes pagarle el pasaje que cuesta el viaje, pero no un porcentaje de tu apoyo. Mejor: vayan en grupo y compartan el transporte.



#### Un caso en un minuto

Doña Juana y otras señoras de su comunidad ahora van juntas en una camioneta y pagan el pasaje entre todas. Doña Juana ya no da 500 pesos de su pensión.

> **Idea clave:** tu apoyo llega completo a tu tarjeta; nadie puede cobrarte una parte por registrarte o por cobrar.



#### Comprueba lo que entendiste

1. ¿Te pueden cobrar por registrarte a un apoyo?
*Respuesta:* No; es sin costo.

2. Alguien te lleva a cobrar. ¿Qué le pagas?
*Respuesta:* Solo el pasaje que cuesta el viaje, no una parte de mi apoyo.


#### Para recordar

- Tu apoyo completo.
- Nadie cobra por registrarte.
- Vayan en grupo.



### Profundiza (5 minutos más)

#### Imagen de la lección

Una tarjeta del Banco del Bienestar con monedas completas, y una mano que intenta quitar una parte, tachada.



#### Organizarse para cobrar

En muchas comunidades, las personas que cobran se organizan para ir juntas, con una persona de confianza que conoce el camino. Así se cuidan entre todas y nadie cobra de más.



#### Casos


**Caso 1. Los 500 pesos**

Un señor cobra a Doña Juana 500 pesos por llevarla a cobrar.
- *¿Qué hace?* Va con otras señoras y comparten el pasaje.


**Caso 2. El registro con cuota**

Le piden a Rosa 200 pesos para registrarla a un programa.
- *¿Qué hace?* No paga: el registro es sin costo.


**Caso 3. «Yo te cobro y te doy»**

Alguien le pide a Don Pedro su tarjeta para cobrar por él.
- *¿Qué hace?* No la presta y cobra él mismo.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar una parte del apoyo | Pierdes dinero | Es completo |
| Pagar por registrarte | Fraude | Es sin costo |
| Prestar tu tarjeta | Te quitan dinero | Cobra tú |
| Ir solo con desconocidos | Riesgo | En grupo |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Juana, Rosa y Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuánto cuesta registrarte a un Programa para el Bienestar? a) Nada · b) 200 pesos · c) Una parte del primer pago
2. ¿Dónde llega tu apoyo? a) Con un gestor de la comunidad · b) Directo en tu tarjeta · c) En la tienda del pueblo
3. Alguien te lleva a cobrar. ¿Qué es justo pagarle? a) La mitad de tu apoyo, por la molestia · b) 500 pesos · c) Solo el pasaje del viaje
**Respuestas:** 1-a: es sin costo. 2-b: directo. 3-c: no una parte del apoyo.



#### Ponlo en práctica

Cobras 3,100 pesos y te quitan 500. ¿Cuánto debía llegarte completo?
**Respuesta:** 3,100 pesos; te quitaron 500 que eran tuyos.



#### A tu plan

Platiquen en su comunidad cómo ir juntas a cobrar y cuánto cuesta el pasaje.



### Para saber más

- **Programas para el Bienestar** (Secretaría de Bienestar · español): https://programasparaelbienestar.gob.mx — **Qué buscar:** «trámites sin costo».

### Palabras clave

- *Apoyo:* dinero que da el gobierno.
- *Intermediario:* persona que se mete entre tú y tu dinero.
- *Sin costo:* que no se paga.

### Fuentes

Secretaría de Bienestar, trámites sin costo y sin intermediarios; consultado el 5 de octubre de 2026.

---

## M1 U02. Si alguien se queda con tu dinero

**Lo que lograrás:** Identificar a quién avisar si alguien te cobra por tu apoyo o se queda con una parte.

**Para empezar:** En la comunidad de Rosa, una persona dice que «tiene palancas». Cobra 300 pesos a cada familia para que sigan recibiendo la beca de sus hijos. Si no pagan, dice que los dan de baja. En esta lección verás qué hacer.

### Lo esencial (5 minutos)

#### Eso no está permitido

Nadie puede darte de baja de un programa por no pagarle. Pedir dinero por los apoyos es un abuso y se puede reportar.



#### A quién avisar

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Línea de Bienestar | 800 639 4264. | Para reportar cobros. |
| Módulo o servidor de la nación | En tu municipio. | Con su gafete. |
| Autoridad de tu comunidad | Comisariado o agente. | Para que se sepa. |

#### Pueden avisar juntas

Si a varias familias les cobran, pueden avisar juntas. Así nadie queda sola y el aviso pesa más. No hace falta dar el nombre de cada persona si no quieren.



#### Un caso en un minuto

Las mamás de la comunidad de Rosa llamaron juntas a la Línea de Bienestar y avisaron en el módulo. Dejaron de pagar los 300 pesos y nadie perdió la beca.

> **Idea clave:** si alguien te cobra por tu apoyo, no pagues y avisa a la Línea de Bienestar, 800 639 4264.



#### Comprueba lo que entendiste

1. ¿Te pueden dar de baja por no pagarle a alguien?
*Respuesta:* No.

2. ¿A qué número avisas un cobro por apoyos?
*Respuesta:* A la Línea de Bienestar, 800 639 4264.


#### Para recordar

- No pagues.
- Línea de Bienestar.
- Avisen juntas.



### Profundiza (5 minutos más)

#### Imagen de la lección

Un grupo de mujeres con un teléfono, y el número 800 639 4264 grande.



#### Servidores de la nación

El personal oficial que visita las comunidades trae gafete y no cobra. Si dudas, pide su nombre y verifica en el módulo.



#### Casos


**Caso 1. «Tengo palancas»**

Le piden a Rosa 300 pesos para no perder la beca.
- *¿Qué hace?* No paga y avisa a la Línea de Bienestar.


**Caso 2. Miedo a la baja**

Doña Juana teme perder su pensión si no paga.
- *¿Qué hace?* Sabe que no la pueden dar de baja por eso y avisa.


**Caso 3. Varias familias**

A cinco familias les cobran lo mismo.
- *¿Qué hacen?* Avisan juntas en el módulo y a la línea.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar por miedo | Sigue el abuso | No pagues |
| Callar | Les pasa a más | Avisa |
| Avisar sola con miedo | Te sientes expuesta | Avisen juntas |
| Creer en «palancas» | Te engañan | Nadie puede darte de baja por eso |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Doña Juana y varias familias. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te cobran para no darte de baja de un apoyo. ¿Qué es? a) Un abuso que se puede reportar · b) Una regla del programa · c) Una cooperación normal para la comunidad
2. ¿Cuál es el número de la Línea de Bienestar? a) 911 · b) 800 639 4264 · c) El del señor que cobra
3. ¿Qué ayuda si a varias familias les cobran? a) Pagar todas para que no las den de baja · b) Callar · c) Avisar juntas
**Respuestas:** 1-a: es abuso. 2-b: Línea de Bienestar. 3-c: juntas pesa más.



#### Ponlo en práctica

A 12 familias les cobran 300 pesos. ¿Cuánto dinero se lleva esa persona?
**Respuesta:** 3,600 pesos.



#### A tu plan

Guarda el número 800 639 4264 y compártelo con tu comunidad.



### Para saber más

- **Línea de Bienestar** (Secretaría de Bienestar · español): 800 639 4264.

### Palabras clave

- *Abuso:* cuando alguien se aprovecha de ti.
- *Dar de baja:* sacarte de un programa.
- *Reportar:* avisar a la autoridad.

### Fuentes

Secretaría de Bienestar, Línea de Bienestar y alertas de fraude; consultados el 5 de octubre de 2026.

---


# Parte 3. Módulo 2. Tu cuenta a tu nombre

## M2 U01. ¿Por qué una cuenta a tu nombre?

**Lo que lograrás:** Explicar por qué conviene que cada mujer tenga una cuenta a su nombre.

**Para empezar:** El dinero que manda el esposo de Rosa llega a la cuenta de su suegro. Cada vez que Rosa necesita algo para los niños, tiene que pedírselo. A veces le dice que no hay. En esta lección verás por qué tu cuenta te protege.

### Lo esencial (5 minutos)

#### Tu dinero, en tu cuenta

Una cuenta a tu nombre es un lugar donde el dinero es tuyo. Solo tú lo puedes sacar con tu tarjeta y tu NIP. Nadie tiene que darte permiso.



#### Lo que te da tu cuenta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Seguridad | Tu dinero no está en la casa. | Menos robo. |
| Control | Tú decides. | Sin pedir permiso. |
| Ahorro | Puedes dejar una parte. | Para emergencias. |
| Recibir | Remesas y pagos directo. | Sin terceros. |

#### En el país, la brecha es grande

Entre quienes hablan una lengua indígena, las mujeres tienen 15 puntos menos de acceso a productos financieros que los hombres. Una cuenta a tu nombre ayuda a cerrar esa diferencia.



#### Un caso en un minuto

Rosa abrió una cuenta a su nombre. Ahora su esposo le manda directo a ella. Ella decide qué se compra para los niños y deja un poco ahorrado.

> **Idea clave:** una cuenta a tu nombre es tu dinero bajo tu control: tú decides, sin pedir permiso.



#### Comprueba lo que entendiste

1. ¿Quién puede sacar el dinero de tu cuenta?
*Respuesta:* Solo yo, con mi tarjeta y mi NIP.

2. ¿Qué te da una cuenta a tu nombre?
*Respuesta:* Seguridad, control, ahorro y recibir dinero directo.


#### Para recordar

- Tu cuenta, tu dinero.
- Tú decides.
- Recibe directo.



### Profundiza (5 minutos más)

#### Imagen de la lección

Una mujer con su propia tarjeta en la mano y una flecha de dinero que llega directo a ella.



#### No es desconfianza

Tener tu propia cuenta no es pelear con tu familia. Es tener un lugar seguro para lo que es tuyo y para los gastos de tus hijos.



#### Casos


**Caso 1. El dinero en la cuenta del suegro**

A Rosa le llega el dinero a la cuenta del suegro.
- *¿Qué hace?* Abre una cuenta a su nombre y pide que le manden ahí.


**Caso 2. «Para qué, si no tienes dinero»**

Le dicen a Doña Juana que no necesita cuenta porque gana poco.
- *¿Qué hace?* Sabe que ya tiene su tarjeta de pensión y la usa también para ahorrar.


**Caso 3. La hija que se va**

Marta se irá a trabajar a la ciudad.
- *¿Qué hace?* Abre su propia cuenta antes de irse.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dejar tu dinero a nombre de otro | Pierdes el control | A tu nombre |
| Creer que es solo para quien tiene mucho | No la abres | Es para todas |
| Guardar todo en la casa | Riesgo de robo | En tu cuenta |
| Pensar que es desconfianza | No la abres | Es protección |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Doña Juana y Marta. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Por qué una cuenta a tu nombre? a) Para que decidas tú sobre tu dinero · b) Para que otra persona de la familia la administre · c) Porque lo pide la escuela
2. ¿Quién puede sacar dinero de tu cuenta? a) Tu suegro · b) Tú, con tu tarjeta y tu NIP · c) Cualquiera que sepa tu nombre
3. ¿Tener tu cuenta es pelear con tu familia? a) Sí · b) Solo si eres joven · c) No, es protección
**Respuestas:** 1-a: tú decides. 2-b: solo tú. 3-c: es protección.



#### Ponlo en práctica

Te mandan 2,500 al mes y dejas 250 en la cuenta. ¿Cuánto ahorras en 6 meses?
**Respuesta:** 1,500 pesos.



#### A tu plan

Si no tienes cuenta a tu nombre, decide esta semana dónde la abrirás (lección siguiente).



### Para saber más

- **Inclusión financiera de las mujeres** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «mujeres».

### Palabras clave

- *Cuenta:* lugar en el banco donde guardas tu dinero.
- *A tu nombre:* que es tuyo y solo tú lo controlas.
- *NIP:* número secreto de tu tarjeta.

### Fuentes

INEGI y CNBV, ENIF 2024; CONAIF, PNIF 2025-2030; consultados el 5 de octubre de 2026.

---

## M2 U02. Abrir y usar tu cuenta

**Lo que lograrás:** Identificar qué llevar para abrir una cuenta básica y dónde usarla cerca de tu comunidad.

**Para empezar:** Rosa fue al banco del municipio y le pidieron muchos papeles. Le dijeron que volviera. No sabe que hay cuentas con muy pocos requisitos. En esta lección verás cuáles.

### Lo esencial (5 minutos)

#### Cuentas con pocos requisitos

Hay cuentas básicas o de bajo monto que se abren solo con identificación oficial y CURP. No cobran comisión por manejo. Pide esa cuenta por su nombre: «cuenta básica».



#### Dónde usar tu cuenta cerca

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Corresponsales | Tiendas y farmacias que funcionan como banco. | Depositar y retirar. |
| Cajeros | Del banco o de la red. | Pregunta cuáles no cobran. |
| En el celular | Si hay señal. | Solo la app oficial. |

#### Verifica antes de firmar

Pregunta si cobra por manejo y si pide saldo mínimo. Revisa que la institución esté autorizada en CONDUSEF. No te recomendamos un banco: tú eliges.



#### Un caso en un minuto

Marta acompañó a Rosa. Pidieron la cuenta básica con su INE y su CURP. Ahora Rosa deposita y retira en la tienda corresponsal de su comunidad.

> **Idea clave:** pide una cuenta básica con tu INE y tu CURP, y úsala en corresponsales cerca de tu comunidad.



#### Comprueba lo que entendiste

1. ¿Qué cuenta pides para que no te cobren por manejo?
*Respuesta:* La cuenta básica.

2. ¿Qué es un corresponsal?
*Respuesta:* Una tienda o farmacia donde puedes depositar y retirar.


#### Para recordar

- Cuenta básica.
- INE y CURP.
- Corresponsales cerca.



### Profundiza (5 minutos más)

#### Imagen de la lección

Una tienda de la comunidad con el letrero de un banco y una mujer depositando.



#### Si no entiendes algo

Tienes derecho a que te expliquen. Ve con alguien de confianza que hable español y tu lengua, y pide que te expliquen las comisiones.



#### Casos


**Caso 1. Muchos papeles**

A Rosa le piden muchos papeles en el banco.
- *¿Qué hace?* Pide la cuenta básica, con INE y CURP.


**Caso 2. El cajero lejos**

El cajero más cercano está a dos horas.
- *¿Qué hace Doña Juana?* Pregunta qué tienda de su comunidad es corresponsal.


**Caso 3. No entiende el contrato**

Don Pedro no entiende lo que dice el contrato.
- *¿Qué hace?* Va con Marta y pide que le expliquen las comisiones.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Desistir por los papeles | No abres cuenta | Cuenta básica |
| Viajar lejos para retirar | Gasto de pasaje | Corresponsal |
| Firmar sin entender | Comisiones | Pide explicación |
| Usar apps no oficiales | Robo | Solo la oficial |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Doña Juana y Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué llevas para abrir una cuenta básica? a) Escrituras · b) INE y CURP · c) Un aval
2. ¿Dónde puedes depositar cerca de tu comunidad? a) En una tienda corresponsal · b) Solo en la sucursal de la capital del estado · c) Con un vecino
3. No entiendes el contrato. ¿Qué haces? a) Firmas · b) Te vas y no vuelves · c) Pides que te expliquen, con alguien de confianza
**Respuestas:** 1-b: INE y CURP. 2-a: corresponsal. 3-c: tienes derecho.



#### Ponlo en práctica

El pasaje al cajero cuesta 120 pesos ida y vuelta. Si vas dos veces al mes, ¿cuánto te ahorras al año usando la tienda corresponsal?
**Respuesta:** 2,880 pesos.



#### A tu plan

Pregunta qué tienda o farmacia de tu comunidad es corresponsal y anota su nombre.



### Para saber más

- **Cuentas básicas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «cuenta básica».
- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.

### Palabras clave

- *Cuenta básica:* cuenta sin comisión por manejo.
- *Corresponsal:* tienda que hace operaciones de banco.
- *Comisión:* cobro por un servicio.

### Fuentes

CONDUSEF, cuentas básicas y corresponsales bancarios; CNBV; consultados el 5 de octubre de 2026.

---


# Parte 4. Módulo 3. Recibir y enviar dinero sin perder

## M3 U01. Recibir dinero sin perder

**Lo que lograrás:** Recibir el dinero de tu familia con menos comisión y directo a tu cuenta.

**Para empezar:** El esposo de Rosa le manda dinero desde Sinaloa a través de un conocido que cobra 10% «por la entrega». Cada mes se pierden 300 pesos. En esta lección verás otras formas.

### Lo esencial (5 minutos)

#### Envío directo a tu cuenta

Con una cuenta a tu nombre, tu familia puede mandarte por transferencia o por una empresa de envíos. Llega directo, sin que nadie lo cargue en la mano.



#### Lo que comparas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Comisión | Lo que cobran por enviar. | Por envío. |
| Tipo de cambio | Si viene de Estados Unidos. | Cuántos pesos por dólar. |
| Dónde lo cobras | En tu cuenta o en un corresponsal cercano. | Sin viajar lejos. |

#### Desde Estados Unidos, usa el comparador

Si el dinero viene de EE. UU., PROFECO tiene el comparador **Quién es Quién en el Envío de Dinero**. Muestra cuántos pesos llegan con cada empresa.



#### Un caso en un minuto

Ahora el esposo de Rosa le transfiere directo a su cuenta. Ya no paga 300 pesos al conocido. En un año son 3,600 pesos más para la familia.

> **Idea clave:** pide que te manden directo a tu cuenta y compara la comisión; cada peso que no se pierde es para tu familia.



#### Comprueba lo que entendiste

1. ¿Cómo te pueden mandar dinero directo?
*Respuesta:* Por transferencia a mi cuenta o por una empresa de envíos.

2. ¿Qué comparador usas si viene de EE. UU.?
*Respuesta:* Quién es Quién en el Envío de Dinero, de PROFECO.


#### Para recordar

- Directo a tu cuenta.
- Compara la comisión.
- Comparador de PROFECO.



### Profundiza (5 minutos más)

#### Lo que se perdía Rosa

- Envío al mes: **3,000**
- Lo que cobraba el conocido: **10%**
- Pesos perdidos cada mes: **300**


#### Imagen de la lección

Una flecha que va directo de un trabajador a la tarjeta de su esposa, sin una mano en medio.



#### Casos


**Caso 1. El conocido que cobra 10%**

Rosa pierde 300 pesos al mes.
- *¿Qué hace?* Pide a su esposo que le transfiera directo a su cuenta.


**Caso 2. Desde EE. UU.**

El hijo de Don Pedro le manda desde Oregon.
- *¿Qué hacen?* Comparan en el programa de PROFECO.


**Caso 3. Cobrar lejos**

Doña Juana tiene que viajar para cobrar su envío.
- *¿Qué hace?* Pide que le manden a su cuenta y retira en el corresponsal.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mandar con conocidos | Comisión alta y riesgo | Directo a tu cuenta |
| No comparar | Llegan menos pesos | Compara |
| Viajar lejos | Gasto extra | Corresponsal |
| Dar tu NIP a quien envía | Riesgo | Solo tu número de cuenta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Don Pedro y Doña Juana. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es la forma más segura de recibir dinero? a) Con un conocido · b) Directo a tu cuenta · c) En un sobre por paquetería
2. Te cobran 10% de 2,000. ¿Cuánto pierdes? a) 200 · b) 20 · c) 2,000
3. ¿Qué das a quien te manda dinero? a) Tu NIP · b) Tu tarjeta para que la registre · c) Tu número de cuenta
**Respuestas:** 1-b: directo. 2-a: 10% de 2,000. 3-c: solo el número de cuenta.



#### Ponlo en práctica

Pierdes 250 pesos por envío y recibes 12 envíos al año. ¿Cuánto pierdes al año?
**Respuesta:** 3,000 pesos.



#### A tu plan

Platica con quien te manda dinero para que lo mande directo a tu cuenta.



### Para saber más

- **Quién es Quién en el Envío de Dinero** (PROFECO · español): https://qqed.profeco.gob.mx — **Qué buscar:** compara cuánto recibe tu familia con cada empresa, no solo la comisión.

### Palabras clave

- *Transferencia:* envío de dinero de una cuenta a otra.
- *Comisión:* cobro por enviar.
- *Tipo de cambio:* cuántos pesos dan por un dólar.

### Fuentes

PROFECO, Quién es Quién en el Envío de Dinero; consultado el 5 de octubre de 2026.

---

## M3 U02. Mandar dinero a tu familia

**Lo que lograrás:** Mandar dinero a un familiar en otra comunidad o ciudad de forma segura.

**Para empezar:** Marta trabaja en San Cristóbal y quiere mandar 1,000 pesos a su mamá cada quincena. Su prima le dice que se los dé al chofer de la combi. Una vez el chofer «perdió» el sobre. En esta lección verás opciones más seguras.

### Lo esencial (5 minutos)

#### Formas seguras

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Transferencia | De tu cuenta a la de tu familiar. | Con su número de cuenta o tarjeta. |
| Depósito en corresponsal | En la tienda, a la tarjeta de tu familiar. | Pide comprobante. |
| App del banco | Si hay señal. | Solo la oficial. |

#### Guarda el comprobante

Cada vez que mandes, guarda el comprobante o una foto. Si algo falla, con eso reclamas.



#### Revisa el número antes de mandar

Un número equivocado manda el dinero a otra persona. Pídele a tu familiar su número por escrito y revísalo dos veces.



#### Un caso en un minuto

Marta deposita en la tienda corresponsal a la tarjeta de su mamá y guarda el comprobante. Su mamá lo retira en su comunidad. Nadie carga sobres.

> **Idea clave:** manda por transferencia o depósito a la tarjeta de tu familiar, revisa el número y guarda el comprobante.



#### Comprueba lo que entendiste

1. ¿Qué guardas cada vez que mandas?
*Respuesta:* El comprobante.

2. ¿Por qué revisar el número dos veces?
*Respuesta:* Porque un número equivocado manda el dinero a otra persona.


#### Para recordar

- Transferencia o depósito.
- Revisa el número.
- Guarda el comprobante.



### Profundiza (5 minutos más)

#### Imagen de la lección

Un comprobante de depósito y una palomita junto al número de tarjeta.



#### Si te equivocaste de número

Llama de inmediato a tu banco con el comprobante. Mientras más rápido, más posibilidades de recuperarlo.



#### Casos


**Caso 1. El sobre en la combi**

La prima de Marta le dice que mande el dinero con el chofer.
- *¿Qué hace?* Lo deposita a la tarjeta de su mamá en el corresponsal.


**Caso 2. Sin comprobante**

Rosa mandó dinero y tiró el papel.
- *¿Qué hace la próxima vez?* Guarda el comprobante o le toma foto.


**Caso 3. Un número diferente**

Don Pedro no está seguro del número de su hijo.
- *¿Qué hace?* Le pide el número por escrito y lo revisa antes de mandar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mandar en sobres | Se pierde | Depósito |
| Tirar el comprobante | No puedes reclamar | Guárdalo |
| No revisar el número | Se va a otro | Revisa dos veces |
| Esperar para reclamar | Más difícil | Llama de inmediato |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Marta, Rosa y Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál es la forma más segura de mandar dinero? a) En un sobre con el chofer · b) Depósito a la tarjeta de tu familiar · c) Con un vecino que va para allá cada semana
2. ¿Qué haces con el comprobante? a) Lo guardas · b) Lo tiras · c) Lo regalas
3. Te equivocaste de número. ¿Qué haces? a) Esperas una semana · b) Mandas otra vez al mismo número para ver si llega · c) Llamas de inmediato al banco
**Respuestas:** 1-b: depósito. 2-a: lo guardas. 3-c: de inmediato.



#### Ponlo en práctica

Mandas 1,000 cada quincena. ¿Cuánto mandas en un mes?
**Respuesta:** 2,000 pesos.



#### A tu plan

Pide a tu familiar su número de tarjeta por escrito y guárdalo.



### Para saber más

- **Transferencias** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «transferencias».

### Palabras clave

- *Depósito:* poner dinero en una cuenta.
- *Comprobante:* papel que muestra que mandaste el dinero.
- *Número de tarjeta:* los 16 números de la tarjeta.

### Fuentes

CONDUSEF, transferencias y depósitos; consultado el 5 de octubre de 2026.

---


# Parte 5. Módulo 4. Ahorro en grupo con reglas claras

## M4 U01. Reglas claras para ahorrar en grupo

**Lo que lograrás:** Acordar y escribir las reglas de un grupo de ahorro o tanda.

**Para empezar:** En la comunidad de Doña Juana hicieron una tanda de diez señoras. A la mitad, una dejó de pagar y no había reglas para ese caso. Se pelearon y tres perdieron su dinero. En esta lección escribirán sus reglas.

### Lo esencial (5 minutos)

#### El grupo funciona con reglas

Ahorrar en grupo ayuda: unas a otras se animan. Pero sin reglas escritas, cuando algo sale mal, nadie sabe qué hacer.



#### Las reglas básicas

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuánto y cada cuándo | Lo que paga cada quien. | Fecha fija. |
| El orden | Quién cobra primero. | Por sorteo o acuerdo. |
| Si alguien no paga | Qué pasa y quién responde. | Acordado antes. |
| Quién anota | Una persona lleva la libreta. | Otra revisa. |

#### Escríbanlo y firmen

Escriban las reglas en una hoja, léanlas en voz alta (con intérprete si hace falta) y que todas firmen o pongan su huella. Cada una se queda con una copia o una foto.



#### Un caso en un minuto

En la nueva tanda, Doña Juana y sus compañeras acordaron que quien no pague pierde su turno y la persona que la invitó responde. Lo escribieron y pusieron su huella. Terminaron sin pleitos.

> **Idea clave:** antes de empezar, escriban cuánto, cuándo, el orden y qué pasa si alguien no paga.



#### Comprueba lo que entendiste

1. ¿Qué cuatro cosas lleva el acuerdo?
*Respuesta:* Cuánto y cuándo, el orden, qué pasa si alguien no paga y quién anota.

2. ¿Cómo hacen válido el acuerdo entre ustedes?
*Respuesta:* Lo escriben, lo leen en voz alta y todas firman o ponen su huella.


#### Para recordar

- Cuánto y cuándo.
- El orden.
- Si alguien no paga.



### Profundiza (5 minutos más)

#### Nuestras reglas

| Regla | Lo que acordamos |
|---|---|
| Cuánto paga cada quien | |
| Cada cuándo | |
| Orden para cobrar | |
| Si alguien no paga | |
| Quién anota y quién revisa | |



#### Imagen de la lección

Un círculo de mujeres con una hoja al centro y sus huellas.



#### Casos


**Caso 1. Sin reglas**

Una compañera deja de pagar la tanda.
- *¿Qué hacen la próxima vez?* Escriben antes qué pasa si alguien no paga.


**Caso 2. Personas que no conocen**

Invitan a Rosa a una tanda con gente de otro pueblo.
- *¿Qué hace?* Solo entra si conoce a las personas y hay reglas escritas.


**Caso 3. Una sola anota**

Una sola persona lleva las cuentas y nadie revisa.
- *¿Qué hacen?* Nombran a otra persona para revisar la libreta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Sin reglas | Pleitos y pérdidas | Escríbanlas |
| Gente desconocida | Riesgo | Personas de confianza |
| Una sola anota | Errores o abusos | Otra revisa |
| No dejar copia | No hay prueba | Foto o copia |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Juana, Rosa y el grupo. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuándo se acuerda qué pasa si alguien no paga? a) Antes de empezar · b) Cuando ya pasó, según el caso · c) Nunca
2. Diez personas pagan 200 por semana. ¿Cuánto cobra cada una en su turno? a) 200 · b) 2,000 · c) 1,000
3. ¿Qué hace la persona que revisa? a) Cobra primero porque trabaja más · b) Revisa la libreta que lleva otra · c) Nada
**Respuestas:** 1-a: antes. 2-b: 10 por 200. 3-b: revisa.



#### Ponlo en práctica

Ocho personas pagan 250 por quincena. ¿Cuánto cobra cada una en su turno?
**Respuesta:** 2,000 pesos.



#### A tu plan

Si están en una tanda, escriban sus reglas en la tabla y pongan su firma o huella.



### Para saber más

- **Tandas** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «tandas».

### Palabras clave

- *Tanda:* ahorro en grupo en el que cada quien cobra por turno.
- *Acuerdo:* lo que el grupo decide junto.
- *Huella:* marca del dedo en lugar de la firma.

### Fuentes

CONDUSEF, recomendaciones sobre tandas; consultado el 5 de octubre de 2026.

---

## M4 U02. El dinero del grupo, seguro

**Lo que lograrás:** Guardar el ahorro del grupo en un lugar seguro y no prestarlo a gente de fuera.

**Para empezar:** El grupo de ahorro de la comunidad de Don Pedro guardaba 40,000 pesos en la casa de la tesorera. Una noche robaron la casa. Nadie sabía qué hacer. En esta lección verás cómo cuidar el dinero del grupo.

### Lo esencial (5 minutos)

#### En la casa, el riesgo es alto

Mucho dinero en una casa se puede perder por robo, fuego o agua. Y pone en peligro a quien lo guarda.



#### Formas más seguras

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Cuenta del grupo | Algunas instituciones abren cuentas para grupos. | Pregunta requisitos. |
| Dos firmas | Para sacar, que firmen dos personas. | Se cuidan. |
| Repartir pronto | Que el dinero no se junte mucho tiempo. | Tanda que paga rápido. |

#### No presten a gente de fuera

Prestar el dinero del grupo a personas o negocios de fuera con promesa de «buen interés» pone en riesgo el ahorro de todas. Si lo hacen, que sea con acuerdo de todo el grupo y por escrito.



#### Un caso en un minuto

El grupo de Don Pedro abrió una cuenta a nombre de dos personas que tienen que firmar juntas. Cada mes, la tesorera muestra el estado de cuenta en la asamblea.

> **Idea clave:** no guarden mucho dinero del grupo en una casa; usen una cuenta con dos firmas y muestren las cuentas a todo el grupo.



#### Comprueba lo que entendiste

1. ¿Por qué no guardar mucho dinero del grupo en una casa?
*Respuesta:* Por robo, fuego o agua, y porque pone en peligro a quien lo guarda.

2. ¿Qué ayuda a cuidar una cuenta del grupo?
*Respuesta:* Que para sacar firmen dos personas y se muestre el estado de cuenta.


#### Para recordar

- No en la casa.
- Dos firmas.
- Cuentas a la vista.



### Profundiza (5 minutos más)

#### Imagen de la lección

Dos manos firmando juntas frente a una caja fuerte del banco.



#### Si les ofrecen invertir el ahorro

Desconfíen de quien promete duplicar el dinero del grupo. Revisen en el SIPRES de CONDUSEF que la institución esté autorizada antes de depositar.



#### Casos


**Caso 1. El robo**

Robaron el ahorro del grupo de la casa de la tesorera.
- *¿Qué hacen ahora?* Abren una cuenta con dos firmas.


**Caso 2. El préstamo con buen interés**

Un comerciante pide prestado el ahorro del grupo con «buen interés».
- *¿Qué hacen?* No prestan sin acuerdo de todo el grupo y por escrito.


**Caso 3. Cuentas a la vista**

Nadie sabe cuánto hay en la cuenta del grupo.
- *¿Qué hacen?* La tesorera muestra el estado de cuenta en cada asamblea.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Mucho dinero en casa | Robo | Cuenta del grupo |
| Una sola firma | Abusos | Dos firmas |
| Prestar a gente de fuera | Pueden perderlo | Acuerdo de todas |
| No mostrar las cuentas | Desconfianza | En la asamblea |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con el grupo de Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde es más seguro el dinero del grupo? a) En la casa de la tesorera · b) En una cuenta con dos firmas · c) Enterrado en el patio, donde nadie lo encuentre
2. Les ofrecen duplicar el ahorro del grupo. ¿Qué hacen? a) Desconfían y verifican en CONDUSEF · b) Invierten todo · c) Invierten la mitad para probar si es cierto
3. ¿Cada cuándo muestran las cuentas? a) Nunca · b) Solo al final del año · c) En cada asamblea
**Respuestas:** 1-b: cuenta con dos firmas. 2-a: verifican. 3-c: en cada asamblea.



#### Ponlo en práctica

El grupo tiene 40,000 pesos. Si los dejan en casa y se pierden, ¿cuánto pierde cada una de las 20 personas?
**Respuesta:** 2,000 pesos cada una.



#### A tu plan

Platiquen en su grupo dónde guardan el dinero y si necesitan una cuenta con dos firmas.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.
- **Ahorro en grupo** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «grupos de ahorro».

### Palabras clave

- *Tesorera:* quien cuida el dinero del grupo.
- *Dos firmas:* que se necesiten dos personas para sacar dinero.
- *Asamblea:* reunión de todo el grupo.

### Fuentes

CONDUSEF, recomendaciones para grupos de ahorro; consultado el 5 de octubre de 2026.

---


# Parte 6. Módulo 5. Fraudes por teléfono y apps de préstamo

## M5 U01. Las llamadas que piden dinero

**Lo que lograrás:** Reconocer las llamadas falsas y colgar antes de dar datos o dinero.

**Para empezar:** A Doña Juana le llamaron en español rápido: «Le habla el banco, su tarjeta está bloqueada, dígame los números». Ella no entendió todo y dio los números. Al otro día no tenía su pensión. En esta lección verás qué hacer.

### Lo esencial (5 minutos)

#### Nadie te pide números por teléfono

El banco y los programas del gobierno **nunca** te piden por teléfono los números de tu tarjeta ni tu NIP. Tampoco los códigos que te lleguen por mensaje.



#### Señales de una llamada falsa

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Prisa | «Ahorita», «no cuelgue». | Para que no pienses. |
| Piden números | Tarjeta, NIP, código. | Nunca los des. |
| Premios o apoyos | «Ganó», «le toca un apoyo». | Piden pago o datos. |
| Familiar en peligro | Piden depósito urgente. | Verifica. |

#### Cuelga y pregunta

Si no entiendes o te apuran, cuelga. Pregunta a alguien de confianza o llama tú al número de atrás de tu tarjeta.



#### Un caso en un minuto

Después de lo que pasó, Doña Juana aprendió la regla: cuelga y pregunta. La siguiente vez que llamaron, colgó y le preguntó a Marta. Era otra llamada falsa.

> **Idea clave:** nadie del banco ni del gobierno te pide los números de tu tarjeta por teléfono; cuelga y pregunta.



#### Comprueba lo que entendiste

1. ¿El banco te pide tu NIP por teléfono?
*Respuesta:* No, nunca.

2. ¿Qué haces si no entiendes una llamada o te apuran?
*Respuesta:* Cuelgo y pregunto a alguien de confianza.


#### Para recordar

- Nunca des números.
- Cuelga.
- Pregunta.



### Profundiza (5 minutos más)

#### Imagen de la lección

Un teléfono con una tarjeta tachada y una mano que cuelga.



#### Si ya diste los números

Llama de inmediato al banco para bloquear tu tarjeta. Si fue tu tarjeta del Bienestar, avisa también a la Línea de Bienestar, 800 639 4264.



#### Casos


**Caso 1. «Su tarjeta está bloqueada»**

A Doña Juana le piden los números de su tarjeta.
- *¿Qué hace?* Cuelga y pregunta a alguien de confianza.


**Caso 2. «Ganó un apoyo»**

A Rosa le dicen que ganó un apoyo y debe pagar 300 para recibirlo.
- *¿Qué hace?* Cuelga: los apoyos no se pagan.


**Caso 3. Ya dio los números**

Don Pedro dio los números y se dio cuenta después.
- *¿Qué hace?* Llama al banco de inmediato para bloquear la tarjeta.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Dar los números | Te vacían la tarjeta | Nunca |
| Seguir en la llamada | Te convencen | Cuelga |
| Pagar por un apoyo | Fraude | Los apoyos no se pagan |
| Esperar para avisar | Pierdes más | Bloquea de inmediato |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Juana, Rosa y Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Te piden los números de tu tarjeta por teléfono. ¿Qué haces? a) Cuelgas · b) Los das · c) Das solo la mitad
2. Te dicen que ganaste un apoyo y debes pagar. ¿Qué es? a) Normal · b) Un fraude · c) Una cuota oficial
3. Ya diste los números. ¿Qué haces? a) Esperas · b) Nada · c) Llamas al banco para bloquear tu tarjeta
**Respuestas:** 1-a: nunca los des. 2-b: los apoyos no se pagan. 3-c: bloquea.



#### Ponlo en práctica

Escribe tu frase para colgar.
**Respuesta:** Ejemplo: «No doy datos por teléfono», y cuelgo.



#### A tu plan

Guarda en tu teléfono el número de tu banco y el 800 639 4264.



### Para saber más

- **Fraudes** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «fraude telefónico».
- **Línea de Bienestar:** 800 639 4264.

### Palabras clave

- *Llamada falsa:* llamada para engañarte y quitarte dinero.
- *Bloquear:* que nadie pueda usar tu tarjeta.
- *Código:* números que te llegan por mensaje para confirmar algo.

### Fuentes

CONDUSEF; Secretaría de Bienestar, alertas de fraude; consultados el 5 de octubre de 2026.

---

## M5 U02. Apps de préstamo que te persiguen

**Lo que lograrás:** Reconocer las apps de préstamo abusivas y no instalarlas.

**Para empezar:** Marta necesitaba 2,000 pesos para la inscripción de su hermano. Una app le prestó en minutos. A la semana le exigían 3,400 y mandaron mensajes a todos sus contactos diciendo que era ratera. En esta lección verás cómo evitarlo.

### Lo esencial (5 minutos)

#### Rápido no es bueno

Algunas apps prestan en minutos, pero cobran muchísimo, piden pagar en una semana y se meten a tus contactos y fotos para presionarte.



#### Señales

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Plazo de una semana | Casi imposible pagar. | Mala señal. |
| Piden tus contactos | Para avergonzarte. | No lo permitas. |
| No dicen el total | No sabes cuánto pagarás. | No firmes. |
| No está registrada | No aparece en CONDUSEF. | No la uses. |

#### Mejor pedir en tu comunidad con acuerdo

Un préstamo de tu grupo de ahorro o de un familiar, con acuerdo claro, casi siempre cuesta menos que una app.



#### Un caso en un minuto

Marta pagó lo que debía, borró la app y reportó a CONDUSEF. Ahora, para emergencias, el grupo de ahorro presta con reglas escritas.

> **Idea clave:** si una app pide tus contactos o no te dice cuánto pagarás, no la instales.



#### Comprueba lo que entendiste

1. ¿Por qué una app pide tus contactos?
*Respuesta:* Para presionarte y avergonzarte si te atrasas.

2. ¿Qué opción suele costar menos que una app?
*Respuesta:* Un préstamo del grupo de ahorro o de un familiar con acuerdo claro.


#### Para recordar

- No des tus contactos.
- Pregunta el total.
- Mejor tu grupo.



### Profundiza (5 minutos más)

#### La app de Marta

- Lo que le exigían: **3,400**
- Lo que le prestaron: **2,000**
- Lo que costó, en una semana: **1,400**


#### Imagen de la lección

Un celular con una cadena y una mano que lo deja; junto, un grupo de mujeres con una libreta.



#### Casos


**Caso 1. La app rápida**

Marta necesita dinero y ve una app que presta en minutos.
- *¿Qué hace?* Pregunta el total y como pide contactos, no la usa.


**Caso 2. Mensajes a la familia**

A Rosa le mandan mensajes a su familia por una deuda de app.
- *¿Qué hace?* Guarda capturas y reporta a CONDUSEF.


**Caso 3. Emergencia**

Don Pedro necesita 1,500 para medicinas.
- *¿Qué hace?* Pide al grupo de ahorro con acuerdo escrito.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Instalar apps rápidas | Deuda cara y acoso | No las instales |
| Dar contactos | Avergüenzan a tu familia | Niégalo |
| Pagar a cuentas personales | Fraude | Solo a la empresa |
| Callar el acoso | Sigue | Reporta |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Marta, Rosa y Don Pedro. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Una app pide tus contactos. ¿Qué haces? a) No la instalas · b) Aceptas · c) Das solo algunos
2. Te prestan 2,000 y pagas 3,400. ¿Cuánto cuesta? a) 3,400 · b) 1,400 · c) 2,000
3. ¿A dónde reportas el acoso de una app? a) A CONDUSEF · b) A la tienda · c) A nadie
**Respuestas:** 1-a: no la instales. 2-b: 3,400 menos 2,000. 3-a: CONDUSEF.



#### Ponlo en práctica

Te prestan 1,000 y pagas 1,700 en una semana. ¿Cuánto cuesta el préstamo?
**Respuesta:** 700 pesos.



#### A tu plan

Platiquen en su grupo de ahorro cómo prestar para emergencias, con reglas escritas.



### Para saber más

- **Apps de préstamo** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «apps de préstamo».

### Palabras clave

- *App:* programa del celular.
- *Acoso:* molestar o presionar para que pagues.
- *Préstamo con acuerdo:* préstamo con reglas claras escritas.

### Fuentes

CONDUSEF, alertas sobre apps de préstamo; consultado el 5 de octubre de 2026.

---


# Parte 7. Módulo 6. Tu tierra: lista de sucesión y beneficiarios

## M6 U01. La lista de sucesión de tu tierra

**Lo que lograrás:** Hacer la lista de sucesión de tus derechos ejidales para que tu familia no los pierda.

**Para empezar:** Cuando murió el hermano de Don Pedro, no había lista de sucesión. Su esposa y sus hijos tardaron años en juicio para conservar la parcela. Don Pedro no quiere eso para su familia. En esta lección verás cómo hacer la lista.

### Lo esencial (5 minutos)

#### Qué es la lista de sucesión

Es la lista donde el ejidatario dice quién se queda con sus derechos sobre la parcela cuando él falte, y en qué orden. La ley la reconoce: es el artículo 17 de la Ley Agraria.



#### Cómo se hace

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Nombres y orden | Quién primero, quién después. | Nombres completos. |
| Depósito en el RAN | En el Registro Agrario Nacional. | O ante notario. |
| Se puede cambiar | Vale la de fecha más reciente. | Revísala. |

#### Piensa en tu esposa y tus hijas

Muchas mujeres trabajan la tierra y quedan fuera de la herencia. Al hacer tu lista, piensa en quién la trabaja y en tu esposa.



#### Un caso en un minuto

Don Pedro fue al Registro Agrario Nacional con su comisariado. Puso a su esposa primero y a su hija después. Depositó su lista y se lo contó a la familia.

> **Idea clave:** haz tu lista de sucesión y deposítala en el RAN o ante notario; así tu familia conserva la tierra.



#### Comprueba lo que entendiste

1. ¿Dónde se deposita la lista de sucesión?
*Respuesta:* En el Registro Agrario Nacional o ante notario.

2. Si haces dos listas, ¿cuál vale?
*Respuesta:* La de fecha más reciente.


#### Para recordar

- Nombres y orden.
- RAN o notario.
- Vale la más reciente.



### Profundiza (5 minutos más)

#### Imagen de la lección

Una parcela con un papel y una flecha hacia la esposa y la hija.



#### Bienes comunales

En las comunidades con bienes comunales, las reglas pueden depender del estatuto de la comunidad. Pregunta en tu asamblea y en el RAN.



#### Casos


**Caso 1. Sin lista**

El hermano de Don Pedro murió sin lista.
- *¿Qué hace Don Pedro?* Hace su lista y la deposita en el RAN.


**Caso 2. La hija que trabaja la tierra**

La hija de Don Pedro es quien siembra con él.
- *¿Qué hace?* La considera en su lista de sucesión.


**Caso 3. La lista vieja**

Don Pedro hizo una lista hace 20 años y su familia cambió.
- *¿Qué hace?* Hace una nueva; vale la más reciente.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No hacer la lista | Juicios largos | Hazla |
| Olvidar a las mujeres | Quedan fuera | Piensa en quién la trabaja |
| Lista vieja | No refleja tu familia | Actualízala |
| No avisar a la familia | Sorpresas | Cuéntales |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pedro y su familia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Qué es la lista de sucesión? a) La lista de quién hereda tus derechos ejidales · b) Una lista de compras para la siembra · c) La lista de la asamblea
2. ¿Dónde la depositas? a) En el banco donde tienes tu cuenta · b) En el RAN o ante notario · c) En tu casa
3. Hiciste dos listas. ¿Cuál vale? a) La primera · b) Ninguna, porque se contradicen · c) La más reciente
**Respuestas:** 1-a: quién hereda. 2-b: RAN o notario. 3-c: la más reciente.



#### Ponlo en práctica

Escribe en orden a dos personas que pondrías en tu lista.
**Respuesta:** Respuesta personal, por ejemplo: «1. Mi esposa. 2. Mi hija».



#### A tu plan

Si eres ejidatario, pregunta en tu comisariado o en el RAN cómo depositar tu lista.



### Para saber más

- **Lista de sucesión** (Registro Agrario Nacional · español): https://www.gob.mx/ran — **Qué buscar:** «lista de sucesión».
- **Procuraduría Agraria** (español): https://www.gob.mx/pa — **Qué buscar:** «lista de sucesión».

### Palabras clave

- *Ejidatario:* persona con derechos en el ejido.
- *Lista de sucesión:* lista de quién hereda tus derechos.
- *RAN:* Registro Agrario Nacional.

### Fuentes

Ley Agraria, artículo 17; Registro Agrario Nacional; Procuraduría Agraria; consultados el 5 de octubre de 2026.

---

## M6 U02. Beneficiarios de tu cuenta

**Lo que lograrás:** Poner beneficiarios en tu cuenta para que tu familia reciba tu dinero si faltas.

**Para empezar:** Cuando murió el esposo de Doña Juana, tenía ahorros en su cuenta. No había puesto beneficiarios y Doña Juana tardó mucho en poder sacar ese dinero. En esta lección pondrás los tuyos.

### Lo esencial (5 minutos)

#### Qué es un beneficiario

Es la persona que recibe el dinero de tu cuenta si tú faltas. Se pone en el banco, aparte de la lista de sucesión de la tierra.



#### Cómo hacerlo

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| En el banco | Con tu INE. | Pide el formato. |
| Porcentajes | Cuánto para cada quien. | Suman 100%. |
| Actualízalo | Si cambia tu familia. | Revisa. |

#### Pregunta qué tienes

Pregunta en tu banco si ya tienes beneficiarios y quiénes son. Muchas personas no se acuerdan.



#### Un caso en un minuto

Doña Juana fue al banco con Marta. Puso a sus dos hijas, 50% cada una. Ahora sabe que, si ella falta, sus hijas no tendrán que hacer trámites largos.

> **Idea clave:** pon beneficiarios en tu cuenta y revisa que estén al día.



#### Comprueba lo que entendiste

1. ¿Qué es un beneficiario?
*Respuesta:* Quien recibe el dinero de mi cuenta si yo falto.

2. ¿Cuánto deben sumar los porcentajes?
*Respuesta:* 100%.


#### Para recordar

- Pon beneficiarios.
- Suman 100%.
- Actualízalos.



### Profundiza (5 minutos más)

#### Imagen de la lección

Una tarjeta con dos flechas hacia dos hijas, cada una con «50%».



#### Tu seguro también

Si tienes un seguro, también tiene beneficiarios. Revísalos igual (módulo 7).



#### Casos


**Caso 1. Sin beneficiarios**

El esposo de Doña Juana no puso beneficiarios.
- *¿Qué hace Doña Juana con su cuenta?* Pone a sus hijas como beneficiarias.


**Caso 2. No se acuerda**

Don Pedro no sabe si puso beneficiarios.
- *¿Qué hace?* Pregunta en su banco.


**Caso 3. Tres hijos**

Rosa quiere repartir entre sus tres hijos.
- *¿Qué hace?* Pone a los tres con su porcentaje, que sume 100%.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No ponerlos | Trámites largos | Ponlos |
| No saber si los tienes | Sorpresa | Pregunta |
| Porcentajes que no suman | Problemas | Que sumen 100% |
| No actualizar | El dinero va a otro | Revisa |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Doña Juana, Don Pedro y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Dónde pones los beneficiarios de tu cuenta? a) En el banco · b) En el RAN · c) En la asamblea
2. Repartes entre dos hijas por igual. ¿Cuánto a cada una? a) 50% · b) 100% · c) 25%
3. No sabes si tienes beneficiarios. ¿Qué haces? a) Nada · b) Abres otra cuenta para estar seguro · c) Preguntas en tu banco
**Respuestas:** 1-a: en el banco. 2-a: 50%. 3-c: pregunta.



#### Ponlo en práctica

Repartes entre cuatro hijos por igual. ¿Qué porcentaje para cada uno?
**Respuesta:** 25%.



#### A tu plan

Ve a tu banco y pregunta quiénes son tus beneficiarios.



### Para saber más

- **Beneficiarios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «designación de beneficiarios».

### Palabras clave

- *Beneficiario:* quien recibe tu dinero si faltas.
- *Porcentaje:* parte de cada 100.
- *Formato:* hoja que se llena en el banco.

### Fuentes

CONDUSEF, designación de beneficiarios; consultado el 5 de octubre de 2026.

---


# Parte 8. Módulo 7. Seguro de vida y gastos funerarios

## M7 U01. Que un funeral no endeude a tu familia

**Lo que lograrás:** Prepararse para los gastos funerarios con ahorro o seguro.

**Para empezar:** Cuando murió la mamá de Rosa, la familia pidió prestado para el velorio, la comida y el traslado. Tardaron dos años en pagar. En esta lección verás cómo prepararse.

### Lo esencial (5 minutos)

#### Un gasto que llega a todas las familias

Los gastos funerarios llegan de golpe: velorio, comida para la comunidad, traslado, panteón. Si no hay nada preparado, se pide prestado caro.



#### Tres formas de prepararse

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| Ahorro propio | Un poco cada mes. | Aparte. |
| Ahorro comunitario | Algunos grupos juntan para estos gastos. | Con reglas. |
| Seguro funerario o de vida | Paga cuando alguien falta. | Revisa qué cubre. |

#### Hablarlo en familia

Hablar de estos gastos no trae mala suerte. Ayuda a que la familia sepa qué hay y qué hacer.



#### Un caso en un minuto

Rosa y sus hermanos ahora apartan cada mes un poco para su papá. También platicaron con su grupo de ahorro para tener un fondo para estos gastos.

> **Idea clave:** prepárense con ahorro, un fondo del grupo o un seguro, para que un funeral no endeude a la familia.



#### Comprueba lo que entendiste

1. ¿Cuáles son las tres formas de prepararse?
*Respuesta:* Ahorro propio, ahorro comunitario y seguro funerario o de vida.

2. ¿Hablar de estos gastos trae mala suerte?
*Respuesta:* No; ayuda a la familia a saber qué hacer.


#### Para recordar

- Ahorro propio.
- Fondo del grupo.
- Seguro.



### Profundiza (5 minutos más)

#### El ahorro de los hermanos de Rosa

- Cada hermano al mes: **150**
- Hermanos: **3**
- Al mes entre los tres: **450**
- Meses: **12**
- En un año: **5,400**


#### Imagen de la lección

Una familia sentada platicando, con una alcancía al centro.



#### Casos


**Caso 1. El préstamo para el velorio**

La familia de Rosa pidió prestado y tardó dos años en pagar.
- *¿Qué hacen ahora?* Apartan cada mes entre los hermanos.


**Caso 2. El fondo del grupo**

El grupo de ahorro de Doña Juana quiere apoyar en funerales.
- *¿Qué hacen?* Acuerdan reglas escritas para ese fondo.


**Caso 3. «Trae mala suerte»**

El papá de Rosa no quiere hablar del tema.
- *¿Qué hace Rosa?* Platica con calma para que la familia sepa qué hay.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| No prepararse | Préstamos caros | Ahorro o seguro |
| Fondo sin reglas | Pleitos | Reglas escritas |
| No hablarlo | Nadie sabe qué hacer | Platíquenlo |
| Esperar a que pase | Prisa y deuda | Empiecen ya |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Rosa, Doña Juana y su familia. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. ¿Cuál NO es una forma de prepararse? a) Ahorro propio · b) Pedir prestado cuando pase · c) Un seguro funerario
2. Tres hermanos apartan 100 al mes cada uno. ¿Cuánto juntan en un año? a) 1,200 · b) 3,600 · c) 300
3. ¿Qué necesita un fondo del grupo para funerales? a) Reglas escritas · b) Una sola persona que decida · c) Nada
**Respuestas:** 1-b: eso es deuda. 2-b: 300 al mes por 12. 3-a: reglas.



#### Ponlo en práctica

Apartas 200 al mes. ¿Cuánto tienes en 18 meses?
**Respuesta:** 3,600 pesos.



#### A tu plan

Platiquen en familia cómo se prepararán: ahorro, fondo del grupo o seguro.



### Para saber más

- **Seguros de gastos funerarios** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro funerario».

### Palabras clave

- *Gastos funerarios:* lo que cuesta un velorio y un entierro.
- *Fondo comunitario:* dinero que junta el grupo para algo.
- *Seguro de vida:* seguro que paga a tu familia si faltas.

### Fuentes

CONDUSEF, seguros de gastos funerarios; consultado el 5 de octubre de 2026.

---

## M7 U02. Antes de contratar un seguro

**Lo que lograrás:** Preguntar lo necesario antes de contratar un seguro de vida o funerario y verificar a quien lo vende.

**Para empezar:** Un vendedor llegó a la comunidad de Don Pedro ofreciendo un seguro funerario. Cobraba 150 pesos al mes en efectivo y daba un recibo hecho a mano. Varias familias pagaron. En esta lección verás qué preguntar.

### Lo esencial (5 minutos)

#### Antes de pagar, pregunta

| Tipo | Descripción | Qué significa para ti |
|---|---|---|
| ¿Qué cubre? | Velorio, traslado, panteón o dinero. | Por escrito. |
| ¿Cuánto y cómo pago? | Al mes o al año. | Con comprobante. |
| ¿Hasta qué edad? | Muchos tienen límite. | Pregunta. |
| ¿Qué aseguradora es? | Nombre de la empresa. | Verifícala. |

#### Verifica la aseguradora

Busca el nombre de la aseguradora en el SIPRES de CONDUSEF. Pide una póliza por escrito, no solo un recibo a mano.



#### Que tu familia sepa

Pon a tus beneficiarios y diles que tienen ese seguro, dónde está la póliza y a qué teléfono llamar.



#### Un caso en un minuto

Don Pedro pidió el nombre de la aseguradora. No aparecía en CONDUSEF. Avisó a su comunidad y nadie más pagó. Después, en asamblea, compararon dos seguros verificados.

> **Idea clave:** antes de pagar un seguro, pide póliza por escrito y verifica la aseguradora en CONDUSEF.



#### Comprueba lo que entendiste

1. ¿Qué pides además del recibo?
*Respuesta:* La póliza por escrito.

2. ¿Dónde verificas la aseguradora?
*Respuesta:* En el SIPRES de CONDUSEF.


#### Para recordar

- ¿Qué cubre?
- Póliza por escrito.
- Verifica la aseguradora.



### Profundiza (5 minutos más)

#### Imagen de la lección

Un recibo a mano tachado y una póliza con sello, con una palomita.



#### Si ya pagaste a un falso vendedor

Junta tus recibos y avisa a CONDUSEF y a la autoridad de tu comunidad para que no le pase a más familias.



#### Casos


**Caso 1. El recibo a mano**

El vendedor da recibos hechos a mano.
- *¿Qué hace Don Pedro?* Pide el nombre de la aseguradora y la verifica.


**Caso 2. Hasta qué edad**

Doña Juana tiene 55 años y quiere un seguro.
- *¿Qué hace?* Pregunta hasta qué edad la cubre.


**Caso 3. La familia no sabe**

Rosa tiene un seguro, pero su familia no sabe.
- *¿Qué hace?* Les dice dónde está la póliza y a quién llamar.


#### Errores frecuentes

| Error | Qué pasa | Qué hacer |
|---|---|---|
| Pagar con recibo a mano | Puede ser fraude | Póliza |
| No verificar | Pierdes dinero | SIPRES |
| No preguntar el límite de edad | Te quedas sin cobertura | Pregunta |
| Familia sin saber | Nadie cobra | Cuéntales |

### Practica

#### Actividad interactiva

**¿Qué harías? (H5P):** tres situaciones de esta lección con Don Pedro, Doña Juana y Rosa. Elige la mejor decisión en cada una; si fallas, puedes intentarlo de nuevo.



#### Quiz

1. Un vendedor da recibos a mano. ¿Qué haces? a) Verificas la aseguradora en CONDUSEF · b) Pagas · c) Pagas dos meses para ver si es cierto
2. ¿Qué papel debe darte un seguro? a) Un recibo a mano con la firma del vendedor · b) Una póliza por escrito · c) Ninguno
3. ¿Quién debe saber que tienes seguro? a) Nadie · b) Solo el vendedor y la aseguradora · c) Tu familia y tus beneficiarios
**Respuestas:** 1-a: verifica. 2-b: póliza. 3-c: tu familia.



#### Ponlo en práctica

Pagas 150 al mes. ¿Cuánto pagas en un año?
**Respuesta:** 1,800 pesos.



#### A tu plan

Si tienes o quieres un seguro, escribe las cuatro preguntas y verifica la aseguradora.



### Para saber más

- **SIPRES** (CONDUSEF · español): https://webapps.condusef.gob.mx/SIPRES — **Qué buscar:** escribe el nombre de la institución y revisa que aparezca como autorizada y para qué productos.
- **Seguros** (CONDUSEF · español): https://www.condusef.gob.mx — **Qué buscar:** «seguro de vida».

### Palabras clave

- *Póliza:* contrato del seguro.
- *Aseguradora:* empresa del seguro.
- *Cobertura:* lo que paga el seguro.

### Fuentes

CONDUSEF, seguros de vida y funerarios; consultado el 5 de octubre de 2026.

---


# Parte 9. Materiales de apoyo

## Bienvenida

**Tu Comunidad, Tu Dinero, Tu Futuro** — Programa de bienestar financiero diseñado para pueblos indígenas: cobrar apoyos y remesas sin intermediarios, una cuenta a nombre de cada mujer, ahorro en grupo con reglas, protección contra fraudes, la tierra y la familia. 7 módulos y 14 lecciones cortas en español, para sesiones presenciales con intérprete o facilitadora bilingüe.

Versión 0.1 · Octubre de 2026.

### Lo que vas a lograr

- **Tu tarjeta y tus apoyos, sin intermediarios:** Tus apoyos cobrados completos, sin pagar a nadie.
- **Tu cuenta a tu nombre:** Una cuenta a tu nombre, sobre todo si eres mujer.
- **Recibir y enviar dinero sin perder:** Tu dinero recibido y enviado con menos comisión y sin intermediarios.
- **Ahorro en grupo con reglas claras:** Las reglas escritas de tu grupo de ahorro.
- **Fraudes por teléfono y apps de préstamo:** Tu regla para colgar y no instalar apps de préstamo.
- **Tu tierra: lista de sucesión y beneficiarios:** Tu lista de sucesión hecha y tus beneficiarios al día.
- **Seguro de vida y gastos funerarios:** Tu plan para los gastos funerarios sin endeudar a tu familia.

### Cómo está hecha cada lección

| Parte | Qué encuentras |
|---|---|
| **Empieza** | Una situación corta y lo que vas a lograr. |
| **Lo esencial** | Lo indispensable, con los errores más comunes. |
| **Profundiza** | Cuentas, casos y más datos, si quieres saber más. |
| **Practica** | «¿Qué harías?», tres preguntas y tu plan para esta semana. |

Cada lección toma entre **7 y 8 minutos** con la práctica. Son 14 lecciones en 7 partes. Al final de cada parte hay una autoevaluación: apruebas con 70% y puedes intentarlo las veces que quieras.

### Los personajes

- **Doña Juana:** 55 años. Cobra la Pensión Mujeres Bienestar en una comunidad de la Montaña de Guerrero. Habla náhuatl y poco español.
- **Rosa:** 32 años. Tiene tres hijos; su esposo trabaja en Sinaloa y le manda dinero. No tiene cuenta a su nombre.
- **Don Pedro:** 61 años. Ejidatario en Chiapas. Siembra maíz y café.
- **Marta:** 24 años. Estudió la preparatoria; ayuda a su comunidad con trámites y habla tsotsil y español.

### Reglas del programa

1. **Nunca te pediremos datos personales**, contraseñas, NIP, tu CURP ni montos reales.
2. **No te vendemos nada** ni te recomendamos instituciones: te enseñamos a verificarlas.
3. **Tu información es tuya.** Si una organización te ofrece el curso, no recibe tus datos personales ni financieros.
4. **No se dice que el programa está en lenguas indígenas:** el material está en español y lo imparte un intérprete o una facilitadora bilingüe de la comunidad.
5. **Pocas palabras y muchas ilustraciones:** cada idea cabe en una imagen; las hojas de trabajo se llenan con marcas, no con texto largo.
6. **Respeto a las formas de la comunidad:** asambleas, cargos y acuerdos comunitarios se toman en cuenta al hablar de dinero y tierra.

### Los datos cambian

Los datos del programa se consultaron el **5 de octubre de 2026** y cada lección indica sus fuentes. Antes de decidir, revisa la información vigente en el sitio oficial.

### Puntos, insignias y constancia

Ganas puntos al completar cada actividad y hay 8 insignias. Al aprobar todas las autoevaluaciones recibes la insignia **Plan completo** y tu **constancia de conclusión**. Es un reconocimiento educativo, no una licencia ni una acreditación oficial.


## Casos integradores

Los casos usan datos inventados. Resuelve cada caso antes de abrir la clave.

### E1. El apoyo de Doña Juana (Módulos 1 y 2)

**Datos.** A Doña Juana le llega su pensión a su tarjeta. Un señor de la comunidad le dice que, para «seguir en la lista», le tiene que dar 300 pesos cada vez que cobre. Rosa no tiene cuenta a su nombre y su esposo le manda el dinero a la cuenta de su cuñado.

**Tareas.**

1. ¿Tiene que pagarle al señor?
2. ¿A dónde avisa Doña Juana?
3. ¿Por qué le conviene a Rosa una cuenta a su nombre?
4. ¿Qué lleva Rosa para abrirla?

**Clave.**

- No: el apoyo llega completo y nadie puede cobrarle por registrarse o por cobrar.
- A la Línea de Bienestar: 800 639 4264.
- Porque es su dinero bajo su control: decide ella, sin pedir permiso.
- Su INE y su CURP; pide una cuenta básica.

### E2. El dinero que viene de Sinaloa (Módulo 3)

**Datos.** El esposo de Rosa le manda 3,000 al mes. Hoy lo recoge en efectivo en un lugar que cobra 120 por envío y gasta 80 de pasaje para ir. Si se lo manda a su nueva cuenta, el envío cuesta 20 y puede retirar en un corresponsal de su comunidad.

**Tareas.**

1. ¿Cuánto pierde hoy cada mes?
2. ¿Cuánto pierde con la cuenta?
3. ¿Cuánto ahorra al año?
4. ¿Qué guarda cada vez que recibe o manda dinero?

**Clave.**

- 120 más 80: 200.
- 20.
- 180 al mes por 12: 2,160 al año.
- El comprobante, y revisa el número antes de mandar.

### E3. El ahorro del grupo de mujeres (Módulos 4 y 5)

**Datos.** Diez mujeres ahorran 200 cada semana durante 20 semanas. La que guarda el dinero lo tiene en su casa. Una de ellas recibe una llamada: «Habla el banco, dígame los números de su tarjeta para proteger su ahorro».

**Tareas.**

1. ¿Cuánto junta el grupo en total?
2. ¿Qué deben escribir antes de empezar?
3. ¿Dónde guardan el dinero?
4. ¿Qué hace con la llamada?

**Clave.**

- 10 por 200 por 20: 40,000.
- Cuánto, cuándo, el orden y qué pasa si alguien no paga.
- En una cuenta con dos firmas, y muestran las cuentas a todo el grupo.
- Cuelga: nadie del banco ni del gobierno pide los números de la tarjeta por teléfono. Pregunta en la sucursal o con Marta.

### E4. La tierra y la familia de Don Pedro (Módulos 6 y 7)

**Datos.** Don Pedro es ejidatario y no ha hecho su lista de sucesión. Tiene una cuenta sin beneficiarios. En su comunidad, un funeral cuesta unos 15,000 y la última vez una familia se endeudó con un prestamista.

**Tareas.**

1. ¿Qué hace para que su familia conserve la tierra?
2. ¿Dónde deposita ese documento?
3. ¿Qué hace con su cuenta?
4. ¿Cómo se preparan para un funeral sin endeudarse?

**Clave.**

- Su lista de sucesión.
- En el RAN o ante notario.
- Pone beneficiarios y revisa que estén al día.
- Con ahorro, un fondo del grupo o un seguro; antes de pagar un seguro, piden la póliza por escrito y verifican la aseguradora en la CONDUSEF.


## Prácticas de cálculo

Resuelve cada práctica. Las respuestas están al final.

| Clave | Lección | Práctica |
|---|---|---|
| P01 | M1 U01 | Cobras 3,100 pesos y te quitan 500. ¿Cuánto debía llegarte completo? |
| P02 | M1 U02 | A 12 familias les cobran 300 pesos. ¿Cuánto dinero se lleva esa persona? |
| P03 | M2 U01 | Te mandan 2,500 al mes y dejas 250 en la cuenta. ¿Cuánto ahorras en 6 meses? |
| P04 | M2 U02 | El pasaje al cajero cuesta 120 pesos ida y vuelta. Si vas dos veces al mes, ¿cuánto te ahorras al año usando la tienda corresponsal? |
| P05 | M3 U01 | Pierdes 250 pesos por envío y recibes 12 envíos al año. ¿Cuánto pierdes al año? |
| P06 | M3 U02 | Mandas 1,000 cada quincena. ¿Cuánto mandas en un mes? |
| P07 | M4 U01 | Ocho personas pagan 250 por quincena. ¿Cuánto cobra cada una en su turno? |
| P08 | M4 U02 | El grupo tiene 40,000 pesos. Si los dejan en casa y se pierden, ¿cuánto pierde cada una de las 20 personas? |
| P09 | M5 U01 | Escribe tu frase para colgar. |
| P10 | M5 U02 | Te prestan 1,000 y pagas 1,700 en una semana. ¿Cuánto cuesta el préstamo? |
| P11 | M6 U01 | Escribe en orden a dos personas que pondrías en tu lista. |
| P12 | M6 U02 | Repartes entre cuatro hijos por igual. ¿Qué porcentaje para cada uno? |
| P13 | M7 U01 | Apartas 200 al mes. ¿Cuánto tienes en 18 meses? |
| P14 | M7 U02 | Pagas 150 al mes. ¿Cuánto pagas en un año? |

### Respuestas

- **P01:** 3,100 pesos; te quitaron 500 que eran tuyos.
- **P02:** 3,600 pesos.
- **P03:** 1,500 pesos.
- **P04:** 2,880 pesos.
- **P05:** 3,000 pesos.
- **P06:** 2,000 pesos.
- **P07:** 2,000 pesos.
- **P08:** 2,000 pesos cada una.
- **P09:** Ejemplo: «No doy datos por teléfono», y cuelgo.
- **P10:** 700 pesos.
- **P11:** Respuesta personal, por ejemplo: «1. Mi esposa. 2. Mi hija».
- **P12:** 25%.
- **P13:** 3,600 pesos.
- **P14:** 1,800 pesos.


## Glosario

Definiciones en lenguaje sencillo de las palabras del curso, agrupadas por módulo.

### Tu tarjeta y tus apoyos, sin intermediarios

- **Abuso:** cuando alguien se aprovecha de ti.
- **Apoyo:** dinero que da el gobierno.
- **Dar de baja:** sacarte de un programa.
- **Intermediario:** persona que se mete entre tú y tu dinero.
- **Reportar:** avisar a la autoridad.
- **Sin costo:** que no se paga.

### Tu cuenta a tu nombre

- **A tu nombre:** que es tuyo y solo tú lo controlas.
- **Comisión:** cobro por un servicio.
- **Corresponsal:** tienda que hace operaciones de banco.
- **Cuenta básica:** cuenta sin comisión por manejo.
- **Cuenta:** lugar en el banco donde guardas tu dinero.
- **NIP:** número secreto de tu tarjeta.

### Recibir y enviar dinero sin perder

- **Comprobante:** papel que muestra que mandaste el dinero.
- **Depósito:** poner dinero en una cuenta.
- **Número de tarjeta:** los 16 números de la tarjeta.
- **Tipo de cambio:** cuántos pesos dan por un dólar.
- **Transferencia:** envío de dinero de una cuenta a otra.

### Ahorro en grupo con reglas claras

- **Acuerdo:** lo que el grupo decide junto.
- **Asamblea:** reunión de todo el grupo.
- **Dos firmas:** que se necesiten dos personas para sacar dinero.
- **Huella:** marca del dedo en lugar de la firma.
- **Tanda:** ahorro en grupo en el que cada quien cobra por turno.
- **Tesorera:** quien cuida el dinero del grupo.

### Fraudes por teléfono y apps de préstamo

- **Acoso:** molestar o presionar para que pagues.
- **App:** programa del celular.
- **Bloquear:** que nadie pueda usar tu tarjeta.
- **Código:** números que te llegan por mensaje para confirmar algo.
- **Llamada falsa:** llamada para engañarte y quitarte dinero.
- **Préstamo con acuerdo:** préstamo con reglas claras escritas.

### Tu tierra: lista de sucesión y beneficiarios

- **Beneficiario:** quien recibe tu dinero si faltas.
- **Ejidatario:** persona con derechos en el ejido.
- **Formato:** hoja que se llena en el banco.
- **Lista de sucesión:** lista de quién hereda tus derechos.
- **Porcentaje:** parte de cada 100.
- **RAN:** Registro Agrario Nacional.

### Seguro de vida y gastos funerarios

- **Aseguradora:** empresa del seguro.
- **Cobertura:** lo que paga el seguro.
- **Fondo comunitario:** dinero que junta el grupo para algo.
- **Gastos funerarios:** lo que cuesta un velorio y un entierro.
- **Póliza:** contrato del seguro.
- **Seguro de vida:** seguro que paga a tu familia si faltas.


## Dónde encontrar ayuda

Fuentes oficiales y sin costo que aparecen en las lecciones. Información consultada el 5 de octubre de 2026; confírmala en el sitio oficial.

| Tema | Dónde | Qué buscar | Lecciones |
|---|---|---|---|
| Programas para el Bienestar | Secretaría de Bienestar: https://programasparaelbienestar.gob.mx | «trámites sin costo» | M1 U01 |
| Línea de Bienestar | Secretaría de Bienestar: 800 639 4264 | — | M1 U02 |
| Inclusión financiera de las mujeres | CONDUSEF: https://www.condusef.gob.mx | «mujeres» | M2 U01 |
| Cuentas básicas | CONDUSEF: https://www.condusef.gob.mx | «cuenta básica» | M2 U02 |
| SIPRES | CONDUSEF: https://webapps.condusef.gob.mx/SIPRES | — | M2 U02, M4 U02, M7 U02 |
| Quién es Quién en el Envío de Dinero | PROFECO: https://qqed.profeco.gob.mx | — | M3 U01 |
| Transferencias | CONDUSEF: https://www.condusef.gob.mx | «transferencias» | M3 U02 |
| Tandas | CONDUSEF: https://www.condusef.gob.mx | «tandas» | M4 U01 |
| Ahorro en grupo | CONDUSEF: https://www.condusef.gob.mx | «grupos de ahorro» | M4 U02 |
| Fraudes | CONDUSEF: https://www.condusef.gob.mx | «fraude telefónico» | M5 U01 |
| Apps de préstamo | CONDUSEF: https://www.condusef.gob.mx | «apps de préstamo» | M5 U02 |
| Lista de sucesión | Registro Agrario Nacional: https://www.gob.mx/ran | «lista de sucesión» | M6 U01 |
| Procuraduría Agraria | español: https://www.gob.mx/pa | «lista de sucesión» | M6 U01 |
| Beneficiarios | CONDUSEF: https://www.condusef.gob.mx | «designación de beneficiarios» | M6 U02 |
| Seguros de gastos funerarios | CONDUSEF: https://www.condusef.gob.mx | «seguro funerario» | M7 U01 |
| Seguros | CONDUSEF: https://www.condusef.gob.mx | «seguro de vida» | M7 U02 |

---

## Preguntas frecuentes

**¿Tengo que dar datos reales?** No. Usa números inventados o redondeados; el curso nunca te pide datos personales.

**¿El curso me presta dinero o me recomienda una institución?** No. Te enseña a comparar y a verificar en el SIPRES de la CONDUSEF.

**¿Alguien me puede cobrar por los trámites del curso?** Los trámites oficiales que vemos son sin costo. Si alguien te cobra por ellos, desconfía y pregunta en la ventanilla oficial.

**¿Puedo tomar el curso en el celular?** Sí. Está hecho para eso.

**¿La constancia tiene validez oficial?** Es un reconocimiento educativo, verificable en línea. No es una licencia ni una acreditación oficial.

**¿Dónde reclamo si una institución financiera me cobra mal?** Primero en la institución, con folio; si no te resuelven, en la CONDUSEF: 55 5340 0999.

**¿Y si estoy pasando por un momento muy difícil?** Llama a la Línea de la Vida: 800 911 2000, sin costo y las 24 horas.


## Referencias

Fuentes que usamos en el curso, consultadas el 5 de octubre de 2026.

### Tu tarjeta y tus apoyos, sin intermediarios

- **M1 U01 · Tu apoyo es tuyo, completo.** Secretaría de Bienestar, trámites sin costo y sin intermediarios; consultado el 5 de octubre de 2026.
- **M1 U02 · Si alguien se queda con tu dinero.** Secretaría de Bienestar, Línea de Bienestar y alertas de fraude; consultados el 5 de octubre de 2026.

### Tu cuenta a tu nombre

- **M2 U01 · ¿Por qué una cuenta a tu nombre?.** INEGI y CNBV, ENIF 2024; CONAIF, PNIF 2025-2030; consultados el 5 de octubre de 2026.
- **M2 U02 · Abrir y usar tu cuenta.** CONDUSEF, cuentas básicas y corresponsales bancarios; CNBV; consultados el 5 de octubre de 2026.

### Recibir y enviar dinero sin perder

- **M3 U01 · Recibir dinero sin perder.** PROFECO, Quién es Quién en el Envío de Dinero; consultado el 5 de octubre de 2026.
- **M3 U02 · Mandar dinero a tu familia.** CONDUSEF, transferencias y depósitos; consultado el 5 de octubre de 2026.

### Ahorro en grupo con reglas claras

- **M4 U01 · Reglas claras para ahorrar en grupo.** CONDUSEF, recomendaciones sobre tandas; consultado el 5 de octubre de 2026.
- **M4 U02 · El dinero del grupo, seguro.** CONDUSEF, recomendaciones para grupos de ahorro; consultado el 5 de octubre de 2026.

### Fraudes por teléfono y apps de préstamo

- **M5 U01 · Las llamadas que piden dinero.** CONDUSEF; Secretaría de Bienestar, alertas de fraude; consultados el 5 de octubre de 2026.
- **M5 U02 · Apps de préstamo que te persiguen.** CONDUSEF, alertas sobre apps de préstamo; consultado el 5 de octubre de 2026.

### Tu tierra: lista de sucesión y beneficiarios

- **M6 U01 · La lista de sucesión de tu tierra.** Ley Agraria, artículo 17; Registro Agrario Nacional; Procuraduría Agraria; consultados el 5 de octubre de 2026.
- **M6 U02 · Beneficiarios de tu cuenta.** CONDUSEF, designación de beneficiarios; consultado el 5 de octubre de 2026.

### Seguro de vida y gastos funerarios

- **M7 U01 · Que un funeral no endeude a tu familia.** CONDUSEF, seguros de gastos funerarios; consultado el 5 de octubre de 2026.
- **M7 U02 · Antes de contratar un seguro.** CONDUSEF, seguros de vida y funerarios; consultado el 5 de octubre de 2026.


# Parte 10. Actividades H5P «¿Qué harías?»

Una por lección. La opción marcada con ✔ es la correcta; en la plataforma las opciones aparecen en orden aleatorio.

## M1 U01. Tu apoyo es tuyo, completo

**Caso 1. Los 500 pesos.** Un señor cobra a Doña Juana 500 pesos por llevarla a cobrar. **¿Qué hace?**

- ✔ Va con otras señoras y comparten el pasaje.
- Le sigue pagando 500, porque así se ha hecho siempre.
- Deja de cobrar su pensión.

**Caso 2. El registro con cuota.** Le piden a Rosa 200 pesos para registrarla a un programa. **¿Qué hace?**

- ✔ No paga: el registro es sin costo.
- Paga los 200 para que no la dejen fuera.
- Paga la mitad ahora y la otra después.

**Caso 3. «Yo te cobro y te doy».** Alguien le pide a Don Pedro su tarjeta para cobrar por él. **¿Qué hace?**

- ✔ Cobra él mismo.
- Le presta la tarjeta, porque es de la comunidad y se conocen.
- Le presta la tarjeta y le da su NIP para que no batalle.

## M1 U02. Si alguien se queda con tu dinero

**Caso 1. «Tengo palancas».** Le piden a Rosa 300 pesos para no perder la beca. **¿Qué hace?**

- ✔ No paga y avisa a la Línea de Bienestar.
- Paga los 300 para no perder la beca de sus hijos.
- Paga y no le dice a nadie.

**Caso 2. Miedo a la baja.** Doña Juana teme perder su pensión si no paga. **¿Qué hace?**

- ✔ Avisa: no la pueden dar de baja por eso.
- Paga por miedo a perder su pensión.
- Deja de cobrar para no tener problemas.

**Caso 3. Varias familias.** A cinco familias les cobran lo mismo. **¿Qué hacen?**

- ✔ Avisan juntas en el módulo y a la línea.
- Cada familia paga y se queda callada.
- Juntan el dinero entre todas para pagar menos.

## M2 U01. ¿Por qué una cuenta a tu nombre?

**Caso 1. El dinero en la cuenta del suegro.** A Rosa le llega el dinero a la cuenta del suegro. **¿Qué hace?**

- ✔ Abre una cuenta a su nombre.
- Deja que el dinero siga llegando a la cuenta del suegro, para no pelear.
- Pide que le manden en efectivo con un conocido.

**Caso 2. «Para qué, si no tienes dinero».** Le dicen a Doña Juana que no necesita cuenta porque gana poco. **¿Qué hace?**

- ✔ Usa su tarjeta también para ahorrar.
- Deja de usar su tarjeta porque gana poco.
- Le da su tarjeta a su hijo para que la administre.

**Caso 3. La hija que se va.** Marta se irá a trabajar a la ciudad. **¿Qué hace?**

- ✔ Abre su propia cuenta antes de irse.
- Usa la cuenta de su papá cuando esté en la ciudad.
- Lleva todo su dinero en efectivo.

## M2 U02. Abrir y usar tu cuenta

**Caso 1. Muchos papeles.** A Rosa le piden muchos papeles en el banco. **¿Qué hace?**

- ✔ Pide la cuenta básica.
- Desiste, porque piensa que nunca va a juntar todos esos papeles.
- Pide a su suegro que abra la cuenta por ella.

**Caso 2. El cajero lejos.** El cajero más cercano está a dos horas. **¿Qué hace Doña Juana?**

- ✔ Busca una tienda corresponsal en su comunidad.
- Sigue viajando dos horas al cajero cada vez.
- Le encarga a un vecino que retire por ella.

**Caso 3. No entiende el contrato.** Don Pedro no entiende lo que dice el contrato. **¿Qué hace?**

- ✔ Va con Marta y pide que le expliquen.
- Firma sin entender para no hacer esperar a nadie.
- Se va sin cuenta.

## M3 U01. Recibir dinero sin perder

**Caso 1. El conocido que cobra 10%.** Rosa pierde 300 pesos al mes. **¿Qué hace?**

- ✔ Pide que le transfieran directo.
- Sigue mandando con el conocido, porque así llega a la puerta de la casa.
- Pide que le manden en sobre por paquetería.

**Caso 2. Desde EE. UU..** El hijo de Don Pedro le manda desde Oregon. **¿Qué hacen?**

- ✔ Comparan con el programa de PROFECO.
- Usan siempre la misma empresa sin comparar.
- Eligen la que tenga el anuncio más grande.

**Caso 3. Cobrar lejos.** Doña Juana tiene que viajar para cobrar su envío. **¿Qué hace?**

- ✔ Pide que le manden a su cuenta y retira en el corresponsal.
- Sigue viajando lejos para cobrar.
- Le pide a un vecino que cobre por ella.

## M3 U02. Mandar dinero a tu familia

**Caso 1. El sobre en la combi.** La prima de Marta le dice que mande el dinero con el chofer. **¿Qué hace?**

- ✔ Lo deposita en el corresponsal a la tarjeta de su mamá.
- Lo manda con el chofer de la combi, como su prima.
- Lo guarda y se lo lleva cuando pueda ir.

**Caso 2. Sin comprobante.** Rosa mandó dinero y tiró el papel. **¿Qué hace la próxima vez?**

- ✔ Guarda el comprobante.
- Tira el papel, porque su mamá le avisará si llegó o no llegó.
- Le pide al de la tienda que se acuerde.

**Caso 3. Un número diferente.** Don Pedro no está seguro del número de su hijo. **¿Qué hace?**

- ✔ Le pide el número por escrito y lo revisa.
- Manda al número que cree recordar.
- Manda la mitad para probar.

## M4 U01. Reglas claras para ahorrar en grupo

**Caso 1. Sin reglas.** Una compañera deja de pagar la tanda. **¿Qué hacen la próxima vez?**

- ✔ Escriben antes qué pasa si alguien no paga.
- Hacen otra tanda igual, confiando en que esta vez sí paguen todas.
- Dejan de ahorrar en grupo.

**Caso 2. Personas que no conocen.** Invitan a Rosa a una tanda con gente de otro pueblo. **¿Qué hace?**

- ✔ Solo entra si conoce a las personas y hay reglas.
- Entra porque le ofrecen el primer turno.
- Entra con dos números para cobrar más.

**Caso 3. Una sola anota.** Una sola persona lleva las cuentas y nadie revisa. **¿Qué hacen?**

- ✔ Nombran a otra persona para revisar.
- Dejan que la misma persona lleve todo, como siempre.
- Cada quien anota en su cuaderno sin juntarse.

## M4 U02. El dinero del grupo, seguro

**Caso 1. El robo.** Robaron el ahorro del grupo de la casa de la tesorera. **¿Qué hacen ahora?**

- ✔ Abren una cuenta con dos firmas.
- Guardan el dinero en la casa de otra persona del grupo.
- Reparten el dinero y dejan de ahorrar.

**Caso 2. El préstamo con buen interés.** Un comerciante pide prestado el ahorro del grupo con «buen interés». **¿Qué hacen?**

- ✔ No prestan sin acuerdo de todas y por escrito.
- Le prestan todo porque promete buen interés.
- Le prestan la mitad para ver si paga.

**Caso 3. Cuentas a la vista.** Nadie sabe cuánto hay en la cuenta del grupo. **¿Qué hacen?**

- ✔ La tesorera muestra el estado de cuenta en cada asamblea.
- Confían en la tesorera sin preguntar.
- Revisan solo al final del año.

## M5 U01. Las llamadas que piden dinero

**Caso 1. «Su tarjeta está bloqueada».** A Doña Juana le piden los números de su tarjeta. **¿Qué hace?**

- ✔ Cuelga y pregunta a alguien de confianza.
- Da los números, porque le dicen que es del banco y que su tarjeta está bloqueada.
- Da solo los primeros números.

**Caso 2. «Ganó un apoyo».** A Rosa le dicen que ganó un apoyo y debe pagar 300 para recibirlo. **¿Qué hace?**

- ✔ Cuelga: los apoyos no se pagan.
- Paga los 300 para recibir el apoyo.
- Pide que le descuenten los 300 del apoyo.

**Caso 3. Ya dio los números.** Don Pedro dio los números y se dio cuenta después. **¿Qué hace?**

- ✔ Llama de inmediato al banco para bloquear.
- Espera a ver si le quitan algo.
- Vuelve a llamar al número que le marcó.

## M5 U02. Apps de préstamo que te persiguen

**Caso 1. La app rápida.** Marta necesita dinero y ve una app que presta en minutos. **¿Qué hace?**

- ✔ No la usa: pide contactos.
- La usa porque presta en minutos y necesita el dinero hoy.
- La usa y paga solo lo que pueda.

**Caso 2. Mensajes a la familia.** A Rosa le mandan mensajes a su familia por una deuda de app. **¿Qué hace?**

- ✔ Guarda capturas y reporta a CONDUSEF.
- Paga a la cuenta personal que le mandan.
- Cambia de número y no dice nada.

**Caso 3. Emergencia.** Don Pedro necesita 1,500 para medicinas. **¿Qué hace?**

- ✔ Pide al grupo de ahorro con acuerdo escrito.
- Instala una app de préstamo rápido.
- Empeña la tarjeta de su pensión.

## M6 U01. La lista de sucesión de tu tierra

**Caso 1. Sin lista.** El hermano de Don Pedro murió sin lista. **¿Qué hace Don Pedro?**

- ✔ Hace su lista y la deposita en el RAN.
- Le dice de palabra a su familia quién se queda con la parcela.
- Lo deja para cuando esté enfermo.

**Caso 2. La hija que trabaja la tierra.** La hija de Don Pedro es quien siembra con él. **¿Qué hace?**

- ✔ La considera en su lista.
- La deja fuera porque es mujer y se va a casar.
- Le deja todo al hijo mayor, como se acostumbra.

**Caso 3. La lista vieja.** Don Pedro hizo una lista hace 20 años y su familia cambió. **¿Qué hace?**

- ✔ Hace una nueva lista.
- Deja la vieja porque ya está hecha.
- Tacha a mano la vieja y la guarda en su casa.

## M6 U02. Beneficiarios de tu cuenta

**Caso 1. Sin beneficiarios.** El esposo de Doña Juana no puso beneficiarios. **¿Qué hace Doña Juana con su cuenta?**

- ✔ Pone a sus hijas como beneficiarias.
- No pone a nadie, porque piensa que el banco ya sabe quién es su familia.
- Le da su NIP a su hija mayor.

**Caso 2. No se acuerda.** Don Pedro no sabe si puso beneficiarios. **¿Qué hace?**

- ✔ Pregunta en su banco.
- Supone que sí los puso.
- Abre otra cuenta para estar seguro.

**Caso 3. Tres hijos.** Rosa quiere repartir entre sus tres hijos. **¿Qué hace?**

- ✔ Pone a los tres con su porcentaje.
- Pone solo al mayor para que reparta.
- Pone a los tres con 50% cada uno.

## M7 U01. Que un funeral no endeude a tu familia

**Caso 1. El préstamo para el velorio.** La familia de Rosa pidió prestado y tardó dos años en pagar. **¿Qué hacen ahora?**

- ✔ Apartan cada mes entre los hermanos.
- Esperan a que pase y vuelven a pedir prestado.
- Dejan que la comunidad pague todo.

**Caso 2. El fondo del grupo.** El grupo de ahorro de Doña Juana quiere apoyar en funerales. **¿Qué hacen?**

- ✔ Acuerdan reglas escritas.
- Juntan el dinero sin reglas, porque todas se conocen desde siempre.
- Dejan que una persona decida a quién apoyar.

**Caso 3. «Trae mala suerte».** El papá de Rosa no quiere hablar del tema. **¿Qué hace Rosa?**

- ✔ Platica con calma.
- No vuelve a tocar el tema para no molestar a su papá.
- Decide todo sin decirle nada.

## M7 U02. Antes de contratar un seguro

**Caso 1. El recibo a mano.** El vendedor da recibos hechos a mano. **¿Qué hace Don Pedro?**

- ✔ Verifica la aseguradora.
- Paga porque el vendedor se ve formal y ya pagaron otras familias.
- Paga dos meses para ver si es cierto.

**Caso 2. Hasta qué edad.** Doña Juana tiene 55 años y quiere un seguro. **¿Qué hace?**

- ✔ Pregunta hasta qué edad la cubre.
- Contrata el primero que le ofrecen.
- Contrata el más barato sin preguntar.

**Caso 3. La familia no sabe.** Rosa tiene un seguro, pero su familia no sabe. **¿Qué hace?**

- ✔ Les dice dónde está la póliza.
- No dice nada, porque es un tema triste y no quiere preocupar a nadie.
- Guarda la póliza escondida.

# Parte 11. Banco de preguntas

La opción marcada con ✔ es la correcta; debajo va la retroalimentación.

## Módulo 1

**M1 U01 P1.** ¿Cuánto cuesta registrarte a un Programa para el Bienestar?

- ✔ Nada
- 200 pesos
- Una parte del primer pago

*¡Correcto! Es sin costo.*

**M1 U01 P2.** ¿Dónde llega tu apoyo?

- Con un gestor de la comunidad
- ✔ Directo en tu tarjeta
- En la tienda del pueblo

*¡Correcto! Directo.*

**M1 U01 P3.** Alguien te lleva a cobrar. ¿Qué es justo pagarle?

- La mitad de tu apoyo, por la molestia
- 500 pesos
- ✔ Solo el pasaje del viaje

*¡Correcto! No una parte del apoyo.*

**M1 U02 P1.** Te cobran para no darte de baja de un apoyo. ¿Qué es?

- ✔ Un abuso que se puede reportar
- Una regla del programa
- Una cooperación normal para la comunidad

*¡Correcto! Es abuso.*

**M1 U02 P2.** ¿Cuál es el número de la Línea de Bienestar?

- 911
- ✔ 800 639 4264
- El del señor que cobra

*¡Correcto! Línea de Bienestar.*

**M1 U02 P3.** ¿Qué ayuda si a varias familias les cobran?

- Pagar todas para que no las den de baja
- Callar
- ✔ Avisar juntas

*¡Correcto! Juntas pesa más.*

## Módulo 2

**M2 U01 P1.** ¿Por qué una cuenta a tu nombre?

- ✔ Para que decidas tú sobre tu dinero
- Para que otra persona de la familia la administre
- Porque lo pide la escuela

*¡Correcto! Tú decides.*

**M2 U01 P2.** ¿Quién puede sacar dinero de tu cuenta?

- Tu suegro
- ✔ Tú, con tu tarjeta y tu NIP
- Cualquiera que sepa tu nombre

*¡Correcto! Solo tú.*

**M2 U01 P3.** ¿Tener tu cuenta es pelear con tu familia?

- Sí
- Solo si eres joven
- ✔ No, es protección

*¡Correcto! Es protección.*

**M2 U02 P1.** ¿Qué llevas para abrir una cuenta básica?

- Escrituras
- ✔ INE y CURP
- Un aval

*¡Correcto! INE y CURP.*

**M2 U02 P2.** ¿Dónde puedes depositar cerca de tu comunidad?

- ✔ En una tienda corresponsal
- Solo en la sucursal de la capital del estado
- Con un vecino

*¡Correcto! Corresponsal.*

**M2 U02 P3.** No entiendes el contrato. ¿Qué haces?

- Firmas
- Te vas y no vuelves
- ✔ Pides que te expliquen, con alguien de confianza

*¡Correcto! Tienes derecho.*

## Módulo 3

**M3 U01 P1.** ¿Cuál es la forma más segura de recibir dinero?

- Con un conocido
- ✔ Directo a tu cuenta
- En un sobre por paquetería

*¡Correcto! Directo.*

**M3 U01 P2.** Te cobran 10% de 2,000. ¿Cuánto pierdes?

- ✔ 200
- 20
- 2,000

*¡Correcto! 10% de 2,000.*

**M3 U01 P3.** ¿Qué das a quien te manda dinero?

- Tu NIP
- Tu tarjeta para que la registre
- ✔ Tu número de cuenta

*¡Correcto! Solo el número de cuenta.*

**M3 U02 P1.** ¿Cuál es la forma más segura de mandar dinero?

- En un sobre con el chofer
- ✔ Depósito a la tarjeta de tu familiar
- Con un vecino que va para allá cada semana

*¡Correcto! Depósito.*

**M3 U02 P2.** ¿Qué haces con el comprobante?

- ✔ Lo guardas
- Lo tiras
- Lo regalas

*¡Correcto! Lo guardas.*

**M3 U02 P3.** Te equivocaste de número. ¿Qué haces?

- Esperas una semana
- Mandas otra vez al mismo número para ver si llega
- ✔ Llamas de inmediato al banco

*¡Correcto! De inmediato.*

## Módulo 4

**M4 U01 P1.** ¿Cuándo se acuerda qué pasa si alguien no paga?

- ✔ Antes de empezar
- Cuando ya pasó, según el caso
- Nunca

*¡Correcto! Antes.*

**M4 U01 P2.** Diez personas pagan 200 por semana. ¿Cuánto cobra cada una en su turno?

- 200
- ✔ 2,000
- 1,000

*¡Correcto! 10 por 200.*

**M4 U01 P3.** ¿Qué hace la persona que revisa?

- Cobra primero porque trabaja más
- ✔ Revisa la libreta que lleva otra
- Nada

*¡Correcto! Revisa.*

**M4 U02 P1.** ¿Dónde es más seguro el dinero del grupo?

- En la casa de la tesorera
- ✔ En una cuenta con dos firmas
- Enterrado en el patio, donde nadie lo encuentre

*¡Correcto! Cuenta con dos firmas.*

**M4 U02 P2.** Les ofrecen duplicar el ahorro del grupo. ¿Qué hacen?

- ✔ Desconfían y verifican en CONDUSEF
- Invierten todo
- Invierten la mitad para probar si es cierto

*¡Correcto! Verifican.*

**M4 U02 P3.** ¿Cada cuándo muestran las cuentas?

- Nunca
- Solo al final del año
- ✔ En cada asamblea

*¡Correcto! En cada asamblea.*

## Módulo 5

**M5 U01 P1.** Te piden los números de tu tarjeta por teléfono. ¿Qué haces?

- ✔ Cuelgas
- Los das
- Das solo la mitad

*¡Correcto! Nunca los des.*

**M5 U01 P2.** Te dicen que ganaste un apoyo y debes pagar. ¿Qué es?

- Normal
- ✔ Un fraude
- Una cuota oficial

*¡Correcto! Los apoyos no se pagan.*

**M5 U01 P3.** Ya diste los números. ¿Qué haces?

- Esperas
- Nada
- ✔ Llamas al banco para bloquear tu tarjeta

*¡Correcto! Bloquea.*

**M5 U02 P1.** Una app pide tus contactos. ¿Qué haces?

- ✔ No la instalas
- Aceptas
- Das solo algunos

*¡Correcto! No la instales.*

**M5 U02 P2.** Te prestan 2,000 y pagas 3,400. ¿Cuánto cuesta?

- 3,400
- ✔ 1,400
- 2,000

*¡Correcto! 3,400 menos 2,000.*

**M5 U02 P3.** ¿A dónde reportas el acoso de una app?

- ✔ A CONDUSEF
- A la tienda
- A nadie

*¡Correcto! CONDUSEF.*

## Módulo 6

**M6 U01 P1.** ¿Qué es la lista de sucesión?

- ✔ La lista de quién hereda tus derechos ejidales
- Una lista de compras para la siembra
- La lista de la asamblea

*¡Correcto! Quién hereda.*

**M6 U01 P2.** ¿Dónde la depositas?

- En el banco donde tienes tu cuenta
- ✔ En el RAN o ante notario
- En tu casa

*¡Correcto! RAN o notario.*

**M6 U01 P3.** Hiciste dos listas. ¿Cuál vale?

- La primera
- Ninguna, porque se contradicen
- ✔ La más reciente

*¡Correcto! La más reciente.*

**M6 U02 P1.** ¿Dónde pones los beneficiarios de tu cuenta?

- ✔ En el banco
- En el RAN
- En la asamblea

*¡Correcto! En el banco.*

**M6 U02 P2.** Repartes entre dos hijas por igual. ¿Cuánto a cada una?

- ✔ 50%
- 100%
- 25%

*¡Correcto! 50%.*

**M6 U02 P3.** No sabes si tienes beneficiarios. ¿Qué haces?

- Nada
- Abres otra cuenta para estar seguro
- ✔ Preguntas en tu banco

*¡Correcto! Pregunta.*

## Módulo 7

**M7 U01 P1.** ¿Cuál NO es una forma de prepararse?

- Ahorro propio
- ✔ Pedir prestado cuando pase
- Un seguro funerario

*¡Correcto! Eso es deuda.*

**M7 U01 P2.** Tres hermanos apartan 100 al mes cada uno. ¿Cuánto juntan en un año?

- 1,200
- ✔ 3,600
- 300

*¡Correcto! 300 al mes por 12.*

**M7 U01 P3.** ¿Qué necesita un fondo del grupo para funerales?

- ✔ Reglas escritas
- Una sola persona que decida
- Nada

*¡Correcto! Reglas.*

**M7 U02 P1.** Un vendedor da recibos a mano. ¿Qué haces?

- ✔ Verificas la aseguradora en CONDUSEF
- Pagas
- Pagas dos meses para ver si es cierto

*¡Correcto! Verifica.*

**M7 U02 P2.** ¿Qué papel debe darte un seguro?

- Un recibo a mano con la firma del vendedor
- ✔ Una póliza por escrito
- Ninguno

*¡Correcto! Póliza.*

**M7 U02 P3.** ¿Quién debe saber que tienes seguro?

- Nadie
- Solo el vendedor y la aseguradora
- ✔ Tu familia y tus beneficiarios

*¡Correcto! Tu familia.*
