# Lesson and evidence traceability

Every lesson has an explanation, practice with feedback and an action for the plan. The module's portfolio E checks integration. The item bank samples learning; it does not replace the 59 practices.

| Lesson | Question | Observable outcome | Evidence |
|---|---|---|---|
| M1 U01 | Is all the money I receive money I earned? | Tell apart money you earn, money you borrow, money you only move and money that is returned to you. | M1 U01 practice and quiz; plan action; portfolio E1 |
| M1 U02 | Why doesn't the same money go as far anymore? | Calculate percentages, inflation and simple and compound interest, and use them to understand your decisions. | M1 U02 practice and quiz; plan action; portfolio E1 |
| M1 U03 | What do I need to take care of first? | Set priorities according to your values and your situation, without blaming yourself. | M1 U03 practice and quiz; plan action; portfolio E1 |
| M1 U04 | Is getting paid every week the same as every month? | Calculate your real income based on pay frequency, ups and downs, and the costs of working. | M1 U04 practice and quiz; plan action; portfolio E1 |
| M1 U05 | Why is my deposit smaller than what I earned? | Read your pay stub and know when and where to ask for clarification. | M1 U05 practice and quiz; plan action; portfolio E1 |
| M1 U06 | Can a small purchase add up to a lot? | Measure the real weight of your big and small expenses and choose changes you can actually keep. | M1 U06 practice and quiz; plan action; portfolio E1 |
| M1 U07 | Why am I short on money if I earn enough this month? | Find shortfalls by date, even when the monthly total looks like enough. | M1 U07 practice and quiz; plan action; portfolio E1 |
| M1 U08 | How do I decide what my money is for? | Build a budget that works with your real resources and can be adjusted if your life changes. | M1 U08 practice and quiz; plan action; portfolio E1 |
| M1 U09 | Does filing taxes mean I will get money back? | Tell apart filing, paying and getting a refund, and know which questions to ask. | M1 U09 practice and quiz; plan action; portfolio E1 |
| M1 U10 | Is everything I collect working for myself mine to spend? | Organize your records by type of income (wages, self-employment or mixed). | M1 U10 practice and quiz; plan action; portfolio E1 |
| M1 U11 | What tax benefits exist if I file with an ITIN? | Learn how to get an ITIN, which credits may apply to your household and where to get free help filing. | M1 U11 practice and quiz; plan action; portfolio E1 |
| M1 U12 | How do I choose someone to help with my taxes? | Compare tax preparation services and recognize dangerous practices. | M1 U12 practice and quiz; plan action; portfolio E1 |
| M1 U13 | What should I know before applying for public benefits? | Understand what "public charge" is, what support exists and where to confirm your case before deciding. | M1 U13 practice and quiz; plan action; portfolio E1 |
| M1 U14 | How do I turn what I learned into something I can actually do? | Build a 90-day plan with concrete actions, dates and an alternative if something changes. | M1 U14 practice and quiz; plan action; portfolio E1 |
| M2 U01 | Who holds my money and who provides the service? | Tell apart what each institution does (bank, credit union, insurer, remittance company, app) and who is responsible if there is a problem. | M2 U01 practice and quiz; plan action; portfolio E2 |
| M2 U02 | Is a money app always a bank? | Compare banks, credit unions and apps by who holds your money, what protection it has and how it works in your life. | M2 U02 practice and quiz; plan action; portfolio E2 |
| M2 U03 | What ID can I use for financial services? | Learn which documents banks, credit unions and remittance companies usually accept, and how to get the ones you are missing safely. | M2 U03 practice and quiz; plan action; portfolio E2 |
| M2 U04 | What do I need to open an account and what does it cost to keep it? | Compare accounts by your need, your documents and how you use money. | M2 U04 practice and quiz; plan action; portfolio E2 |
| M2 U05 | Is all the balance I see free to spend? | Use your payment methods knowing when money is available and how to dispute a charge. | M2 U05 practice and quiz; plan action; portfolio E2 |
| M2 U06 | How do I support my family without deciding at the last minute? | Identify what the person receiving needs and what you can sustain, so you can plan your remittances. | M2 U06 practice and quiz; plan action; portfolio E2 |
| M2 U07 | How much can I send, and when? | Calculate your sending capacity by date, without neglecting your obligations. | M2 U07 practice and quiz; plan action; portfolio E2 |
| M2 U08 | Does "no fee" always mean more money arrives? | Compare transfers by what leaves your pocket and what reaches your family. | M2 U08 practice and quiz; plan action; portfolio E2 |
| M2 U09 | What should I check before sending, and what if something goes wrong? | Verify the remittance company, know your rights and know what to do if there is a problem. | M2 U09 practice and quiz; plan action; portfolio E2 |
| M2 U10 | What happens when I borrow to send money? | Calculate the effect of going into debt to send money. | M2 U10 practice and quiz; plan action; portfolio E2 |
| M2 U11 | How do I say how much I can help without overpromising? | Communicate your capacity respectfully and agree on how to verify emergencies. | M2 U11 practice and quiz; plan action; portfolio E2 |
| M2 U12 | How do I save for something paid in pesos? | Plan goals in another country taking into account the exchange rate, ownership and documents. | M2 U12 practice and quiz; plan action; portfolio E2 |
| M2 U13 | How do I bring my account and remittances into one plan? | Bring together your account, payments, remittances and family agreement in a plan you can review. | M2 U13 practice and quiz; plan action; portfolio E2 |
| M3 U01 | Does getting approved mean I can afford it? | Tell a loan approval apart from your real ability to pay. | M3 U01 practice and quiz; plan action; portfolio E3 |
| M3 U02 | How do I know what information they use about my debts? | Read your credit report, spot errors and dispute them correctly. | M3 U02 practice and quiz; plan action; portfolio E3 |
| M3 U03 | How do I start if I have no credit history? | Compare options to build credit history without taking on too much debt. | M3 U03 practice and quiz; plan action; portfolio E3 |
| M3 U04 | Does improving my credit mean erasing everything? | Choose valid actions to rebuild your history and recognize false promises. | M3 U04 practice and quiz; plan action; portfolio E3 |
| M3 U05 | Why can a small payment end up costing more? | Compare loans and cards by their total cost, not the monthly payment. | M3 U05 practice and quiz; plan action; portfolio E3 |
| M3 U06 | Which debt do I start with? | Make an inventory of your debts and choose a strategy. | M3 U06 practice and quiz; plan action; portfolio E3 |
| M3 U07 | What do I do if I know I can't pay? | Prepare a documented response when you cannot keep up, and know what to do about collections or a lawsuit. | M3 U07 practice and quiz; plan action; portfolio E3 |
| M3 U08 | Can signing to help leave me with a debt? | Weigh the risks of signing, lending or borrowing for your family. | M3 U08 practice and quiz; plan action; portfolio E3 |
| M3 U09 | Can a tanda help me build credit? | Compare the traditional tanda with lending circles that report to the credit bureaus, and use both with less risk. | M3 U09 practice and quiz; plan action; portfolio E3 |
| M3 U10 | What is my next step with credit? | Choose your credit pathway and build a 30- to 90-day plan. | M3 U10 practice and quiz; plan action; portfolio E3 |
| M4 U01 | Why is someone insisting that I act right now? | Recognize how scams work and verify on your own before acting. | M4 U01 practice and quiz; plan action; portfolio E4 |
| M4 U02 | Who can really help me with an immigration matter? | Recognize the fraud that most affects immigrants (notarios, fake lawyers and government impersonators) and know where to verify. | M4 U02 practice and quiz; plan action; portfolio E4 |
| M4 U03 | What protects my accounts besides a password? | Protect your access, your devices and how you recover your accounts. | M4 U03 practice and quiz; plan action; portfolio E4 |
| M4 U04 | What do I do if I already shared information or see something strange? | Respond quickly and in order to fraud or identity theft. | M4 U04 practice and quiz; plan action; portfolio E4 |
| M4 U05 | Is talking about money the same as controlling someone? | Recognize economic abuse and know safe support options. | M4 U05 practice and quiz; plan action; portfolio E4 |
| M4 U06 | What is the point of setting a little money aside? | Build reserves in stages according to their purpose. | M4 U06 practice and quiz; plan action; portfolio E4 |
| M4 U07 | Does having insurance mean I won't pay anything? | Read a policy and compare insurance by what it actually covers. | M4 U07 practice and quiz; plan action; portfolio E4 |
| M4 U08 | Is this medical document asking me to pay? | Review medical bills, ask for financial assistance and file a complaint if something is wrong. | M4 U08 practice and quiz; plan action; portfolio E4 |
| M4 U09 | How do I pay for the essentials if I can't work for a few days? | Prepare your finances for a disaster, an accident or a temporary loss of income. | M4 U09 practice and quiz; plan action; portfolio E4 |
| M4 U10 | What happens to my family and my money if I can't be there? | Build a family preparedness plan: who takes care of your children, where your documents are and how bills get paid if you cannot do it. | M4 U10 practice and quiz; plan action; portfolio E4 |
| M4 U11 | How do I know if my protection plan works? | Bring together prevention, protection and response, and test your plan with a drill. | M4 U11 practice and quiz; plan action; portfolio E4 |
| M5 U01 | How do I turn a wish into a goal? | Measure your net worth and set goals with an amount, a date and a priority, without counting the same money twice. | M5 U01 practice and quiz; plan action; portfolio E5 |
| M5 U02 | If I have more money, did my investment earn it? | Choose between saving and investing based on time frame, risk and access, and calculate returns without fooling yourself. | M5 U02 practice and quiz; plan action; portfolio E5 |
| M5 U03 | Does opening an account mean I already invested? | Tell apart the account (the container) from the investment (the contents) and verify whoever sells it to you. | M5 U03 practice and quiz; plan action; portfolio E5 |
| M5 U04 | Rent or buy? What rights do I have as a tenant? | Know your basic rights as a tenant in California and the real costs of buying a home, including with an ITIN. | M5 U04 practice and quiz; plan action; portfolio E5 |
| M5 U05 | Is the advertised price all it costs? | Compare a car or a course by its total cost and flexibility. | M5 U05 practice and quiz; plan action; portfolio E5 |
| M5 U06 | What will I live on when I work less or stop working? | Identify your possible sources of retirement income and the questions you need to verify. | M5 U06 practice and quiz; plan action; portfolio E5 |
| M5 U07 | Do my accounts and rights work the same in two countries? | Map what you own and owe in each country, and prepare questions for the right institutions. | M5 U07 practice and quiz; plan action; portfolio E5 |
| M5 U08 | Who can receive or handle things if I can't? | Organize beneficiaries, documents and authorizations so your resources can be found. | M5 U08 practice and quiz; plan action; portfolio E5 |
| M5 U09 | What do I do if my job or my family changes? | Recalculate your plan when your income or responsibilities change. | M5 U09 practice and quiz; plan action; portfolio E5 |
| M5 U10 | How do I start a business if I have an ITIN? | Learn the first steps to formalize a small business and separate your personal finances from the business's. | M5 U10 practice and quiz; plan action; portfolio E5 |
| M5 U11 | How do I know all the parts of my plan fit together? | Bring the five modules together into one plan with review dates and alternatives. | M5 U11 practice and quiz; plan action; portfolio E5 |
