# Trazabilidad de lecciones y evidencias

Cada lección tiene explicación, práctica con retroalimentación y una acción para el plan. El expediente E del módulo verifica la integración. El banco de reactivos toma una muestra del aprendizaje; no sustituye las 59 prácticas.

| Lección | Pregunta | Resultado observable | Evidencia |
|---|---|---|---|
| M1 U01 | ¿Todo el dinero que recibo es dinero que gané? | Distinguir el dinero que ganas del dinero que te prestan, el que solo cambias de lugar y el que te devuelven. | Práctica y quiz de M1 U01; acción en el plan; expediente E1 |
| M1 U02 | ¿Por qué el mismo dinero ya no alcanza? | Calcular porcentajes, inflación e intereses simples y compuestos, y usarlos para entender tus decisiones. | Práctica y quiz de M1 U02; acción en el plan; expediente E1 |
| M1 U03 | ¿Qué necesito cuidar primero? | Ordenar prioridades según tus valores y tu situación, sin culparte. | Práctica y quiz de M1 U03; acción en el plan; expediente E1 |
| M1 U04 | ¿Cobrar cada semana es lo mismo que cobrar cada mes? | Calcular tu ingreso real según la frecuencia de cobro, la variación y los costos de trabajar. | Práctica y quiz de M1 U04; acción en el plan; expediente E1 |
| M1 U05 | ¿Por qué me depositan menos de lo que gané? | Leer tu recibo de pago y saber cuándo y dónde pedir una aclaración. | Práctica y quiz de M1 U05; acción en el plan; expediente E1 |
| M1 U06 | ¿Una compra pequeña puede sumar mucho? | Medir el peso real de tus gastos grandes y pequeños, y elegir ajustes que sí puedas sostener. | Práctica y quiz de M1 U06; acción en el plan; expediente E1 |
| M1 U07 | ¿Por qué me falta dinero si este mes gano suficiente? | Detectar faltantes por fechas, aunque el total del mes parezca suficiente. | Práctica y quiz de M1 U07; acción en el plan; expediente E1 |
| M1 U08 | ¿Cómo decido para qué usar mi dinero? | Armar un presupuesto que funcione con tus recursos reales y que se pueda ajustar si cambia tu vida. | Práctica y quiz de M1 U08; acción en el plan; expediente E1 |
| M1 U09 | ¿Presentar impuestos significa que me devolverán dinero? | Distinguir declaración, pago y reembolso, y saber qué preguntas hacer. | Práctica y quiz de M1 U09; acción en el plan; expediente E1 |
| M1 U10 | ¿Todo lo que cobro por mi cuenta es para gastar? | Organizar tus registros según tu tipo de ingreso (salario, trabajo independiente o mixto). | Práctica y quiz de M1 U10; acción en el plan; expediente E1 |
| M1 U11 | ¿Qué apoyos fiscales existen si declaro con ITIN? | Conocer cómo se obtiene el ITIN, qué créditos pueden aplicar a tu hogar y dónde conseguir ayuda gratuita para declarar. | Práctica y quiz de M1 U11; acción en el plan; expediente E1 |
| M1 U12 | ¿Cómo elijo a alguien que me ayude con impuestos? | Comparar servicios de preparación de impuestos y reconocer prácticas peligrosas. | Práctica y quiz de M1 U12; acción en el plan; expediente E1 |
| M1 U13 | ¿Qué debo saber antes de pedir un apoyo público? | Entender qué es la "carga pública", qué apoyos existen y dónde confirmar tu caso antes de decidir. | Práctica y quiz de M1 U13; acción en el plan; expediente E1 |
| M1 U14 | ¿Cómo convierto lo aprendido en algo que sí puedo hacer? | Armar un plan de 90 días con acciones concretas, fechas y una alternativa si algo cambia. | Práctica y quiz de M1 U14; acción en el plan; expediente E1 |
| M2 U01 | ¿Quién cuida mi dinero y quién me presta el servicio? | Distinguir qué hace cada institución (banco, cooperativa, aseguradora, remesadora, app) y quién responde si hay un problema. | Práctica y quiz de M2 U01; acción en el plan; expediente E2 |
| M2 U02 | ¿Una app de dinero es siempre un banco? | Comparar bancos, cooperativas y apps según quién guarda tu dinero, qué protección tiene y cómo funciona en tu vida. | Práctica y quiz de M2 U02; acción en el plan; expediente E2 |
| M2 U03 | ¿Qué identificación me sirve para trámites financieros? | Conocer qué documentos suelen aceptar bancos, cooperativas y remesadoras, y cómo tramitar los que te faltan sin riesgos. | Práctica y quiz de M2 U03; acción en el plan; expediente E2 |
| M2 U04 | ¿Qué necesito para abrir una cuenta y cuánto cuesta mantenerla? | Comparar cuentas según tu necesidad, tus documentos y tu forma de usar el dinero. | Práctica y quiz de M2 U04; acción en el plan; expediente E2 |
| M2 U05 | ¿Todo el saldo que veo está libre para gastar? | Usar tus medios de pago sabiendo cuándo está disponible el dinero y cómo reclamar. | Práctica y quiz de M2 U05; acción en el plan; expediente E2 |
| M2 U06 | ¿Cómo apoyo a mi familia sin decidir a última hora? | Identificar las necesidades de quien recibe y lo que tú puedes sostener, para planear tus remesas. | Práctica y quiz de M2 U06; acción en el plan; expediente E2 |
| M2 U07 | ¿Cuánto puedo enviar y cuándo? | Calcular tu capacidad de envío por fecha, sin descuidar tus obligaciones. | Práctica y quiz de M2 U07; acción en el plan; expediente E2 |
| M2 U08 | ¿Sin comisión siempre llega más dinero? | Comparar envíos por lo que sale de tu bolsillo y lo que llega a tu familia. | Práctica y quiz de M2 U08; acción en el plan; expediente E2 |
| M2 U09 | ¿Qué reviso antes de enviar y qué hago si algo falla? | Verificar a la remesadora, conocer tus derechos y saber qué hacer si hay un problema. | Práctica y quiz de M2 U09; acción en el plan; expediente E2 |
| M2 U10 | ¿Qué pasa cuando pido prestado para enviar? | Calcular el efecto de endeudarte para enviar dinero. | Práctica y quiz de M2 U10; acción en el plan; expediente E2 |
| M2 U11 | ¿Cómo digo cuánto puedo ayudar sin prometer de más? | Comunicar tu capacidad con respeto y acordar cómo verificar emergencias. | Práctica y quiz de M2 U11; acción en el plan; expediente E2 |
| M2 U12 | ¿Cómo ahorro para algo que se pagará en pesos? | Planear metas en otro país considerando el tipo de cambio, la propiedad y los documentos. | Práctica y quiz de M2 U12; acción en el plan; expediente E2 |
| M2 U13 | ¿Cómo junto cuenta y remesas en un solo plan? | Integrar cuenta, pagos, remesas y acuerdo familiar en un plan que puedas revisar. | Práctica y quiz de M2 U13; acción en el plan; expediente E2 |
| M3 U01 | ¿Que me presten significa que puedo pagar? | Diferenciar la aprobación de un préstamo de tu capacidad real de pago. | Práctica y quiz de M3 U01; acción en el plan; expediente E3 |
| M3 U02 | ¿Cómo sé qué información usan sobre mis deudas? | Leer tu reporte de crédito, identificar errores y disputarlos correctamente. | Práctica y quiz de M3 U02; acción en el plan; expediente E3 |
| M3 U03 | ¿Cómo empiezo si no tengo historial? | Comparar opciones para crear historial de crédito sin endeudarte de más. | Práctica y quiz de M3 U03; acción en el plan; expediente E3 |
| M3 U04 | ¿Mejorar mi crédito significa borrar todo? | Elegir acciones válidas para recuperar tu historial y reconocer promesas falsas. | Práctica y quiz de M3 U04; acción en el plan; expediente E3 |
| M3 U05 | ¿Por qué un pago pequeño puede salir más caro? | Comparar préstamos y tarjetas por su costo total, no por la mensualidad. | Práctica y quiz de M3 U05; acción en el plan; expediente E3 |
| M3 U06 | ¿Por cuál deuda empiezo? | Hacer un inventario de tus deudas y elegir una estrategia. | Práctica y quiz de M3 U06; acción en el plan; expediente E3 |
| M3 U07 | ¿Qué hago si sé que no podré pagar? | Preparar una respuesta documentada cuando no puedas cumplir, y saber qué hacer ante una cobranza o una demanda. | Práctica y quiz de M3 U07; acción en el plan; expediente E3 |
| M3 U08 | ¿Firmar para ayudar puede dejarme una deuda? | Evaluar los riesgos de firmar, prestar o endeudarte por tu familia. | Práctica y quiz de M3 U08; acción en el plan; expediente E3 |
| M3 U09 | ¿Una tanda me ayuda a construir crédito? | Comparar la tanda tradicional con los círculos de préstamo que reportan a buró, y usar ambos con menos riesgo. | Práctica y quiz de M3 U09; acción en el plan; expediente E3 |
| M3 U10 | ¿Cuál es mi siguiente paso con el crédito? | Elegir tu ruta de crédito y armar un plan de 30 a 90 días. | Práctica y quiz de M3 U10; acción en el plan; expediente E3 |
| M4 U01 | ¿Por qué alguien insiste en que actúe ahora mismo? | Reconocer cómo funcionan las estafas y verificar por tu cuenta antes de actuar. | Práctica y quiz de M4 U01; acción en el plan; expediente E4 |
| M4 U02 | ¿Quién puede ayudarme de verdad con un trámite migratorio? | Reconocer los fraudes que más afectan a migrantes (notarios, falsos abogados y personas que se hacen pasar por el gobierno) y saber dónde verificar. | Práctica y quiz de M4 U02; acción en el plan; expediente E4 |
| M4 U03 | ¿Qué protege mis cuentas además de una contraseña? | Proteger tu acceso, tus dispositivos y tu forma de recuperar tus cuentas. | Práctica y quiz de M4 U03; acción en el plan; expediente E4 |
| M4 U04 | ¿Qué hago si ya compartí datos o veo algo extraño? | Responder rápido y con orden ante un fraude o robo de identidad. | Práctica y quiz de M4 U04; acción en el plan; expediente E4 |
| M4 U05 | ¿Hablar de dinero es lo mismo que controlar a alguien? | Reconocer el abuso económico y conocer opciones de apoyo seguro. | Práctica y quiz de M4 U05; acción en el plan; expediente E4 |
| M4 U06 | ¿Para qué sirve separar un poco de dinero? | Construir reservas por etapas según su propósito. | Práctica y quiz de M4 U06; acción en el plan; expediente E4 |
| M4 U07 | ¿Tener seguro significa que ya no pagaré nada? | Leer una póliza y comparar seguros por lo que realmente cubren. | Práctica y quiz de M4 U07; acción en el plan; expediente E4 |
| M4 U08 | ¿Este documento médico me está pidiendo pagar? | Revisar facturas médicas, pedir ayuda financiera y reclamar si algo está mal. | Práctica y quiz de M4 U08; acción en el plan; expediente E4 |
| M4 U09 | ¿Cómo pago lo indispensable si no puedo trabajar unos días? | Preparar tus finanzas ante un desastre, un accidente o una pérdida temporal de ingreso. | Práctica y quiz de M4 U09; acción en el plan; expediente E4 |
| M4 U10 | ¿Qué pasa con mi familia y mi dinero si no puedo estar? | Armar un plan de preparación familiar: quién cuida a tus hijos, dónde están tus documentos y cómo se pagan las cuentas si tú no puedes hacerlo. | Práctica y quiz de M4 U10; acción en el plan; expediente E4 |
| M4 U11 | ¿Cómo sé si mi plan de protección funciona? | Integrar prevención, protección y respuesta, y probar tu plan con un simulacro. | Práctica y quiz de M4 U11; acción en el plan; expediente E4 |
| M5 U01 | ¿Cómo convierto un deseo en una meta? | Medir tu patrimonio y definir metas con monto, fecha y prioridad, sin contar el mismo dinero dos veces. | Práctica y quiz de M5 U01; acción en el plan; expediente E5 |
| M5 U02 | ¿Tener más dinero significa que mi inversión ganó? | Elegir entre ahorrar e invertir según el plazo, el riesgo y el acceso, y calcular rendimientos sin engañarte. | Práctica y quiz de M5 U02; acción en el plan; expediente E5 |
| M5 U03 | ¿Abrir una cuenta significa que ya invertí? | Distinguir la cuenta (el recipiente) de la inversión (el contenido) y verificar a quien te la vende. | Práctica y quiz de M5 U03; acción en el plan; expediente E5 |
| M5 U04 | ¿Rentar o comprar? ¿Qué derechos tengo como inquilino? | Conocer tus derechos básicos como inquilino en California y los costos reales de comprar una vivienda, incluso con ITIN. | Práctica y quiz de M5 U04; acción en el plan; expediente E5 |
| M5 U05 | ¿El precio anunciado es todo lo que cuesta? | Comparar un auto o un curso por su costo total y su flexibilidad. | Práctica y quiz de M5 U05; acción en el plan; expediente E5 |
| M5 U06 | ¿De qué viviré cuando trabaje menos o deje de trabajar? | Identificar tus posibles fuentes de ingreso para el retiro y las preguntas que debes verificar. | Práctica y quiz de M5 U06; acción en el plan; expediente E5 |
| M5 U07 | ¿Mis cuentas y derechos funcionan igual en dos países? | Hacer un mapa de lo que tienes y debes en cada país, y preparar preguntas para las instituciones correctas. | Práctica y quiz de M5 U07; acción en el plan; expediente E5 |
| M5 U08 | ¿Quién puede recibir o atender algo si yo no puedo? | Organizar beneficiarios, documentos y autorizaciones para que tus recursos se puedan localizar. | Práctica y quiz de M5 U08; acción en el plan; expediente E5 |
| M5 U09 | ¿Qué hago si cambia mi trabajo o mi familia? | Recalcular tu plan cuando cambian tus ingresos o tus responsabilidades. | Práctica y quiz de M5 U09; acción en el plan; expediente E5 |
| M5 U10 | ¿Cómo empiezo un negocio si tengo ITIN? | Conocer los primeros pasos para formalizar un negocio pequeño y separar tus finanzas personales de las del negocio. | Práctica y quiz de M5 U10; acción en el plan; expediente E5 |
| M5 U11 | ¿Cómo sé que todas las partes de mi plan caben juntas? | Integrar los cinco módulos en un solo plan con fechas de revisión y alternativas. | Práctica y quiz de M5 U11; acción en el plan; expediente E5 |
